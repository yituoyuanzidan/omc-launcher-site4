# -*- coding: utf-8 -*-
"""OMC 反馈收件箱 —— 作者专用，把玩家匿名发来的反馈拉下来看。

玩家在启动器里点「直接匿名发送」，消息进公共收集通道；这个工具负责拉取、
去重、落到本地数据库，所以服务器那边的缓存过期也不会丢。
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PySide6.QtCore import QThread, Qt, Signal              # noqa: E402
from PySide6.QtGui import QFont, QIcon                     # noqa: E402
from PySide6.QtWidgets import (QApplication, QHBoxLayout,   # noqa: E402
                               QHeaderView, QLabel, QMainWindow, QMessageBox,
                               QPushButton, QSplitter, QTableWidget,
                               QTableWidgetItem, QTextEdit, QVBoxLayout,
                               QWidget)

from core import feedback                                   # noqa: E402


class SyncWorker(QThread):
    done = Signal(int, int, str)     # added, total, error

    def run(self):
        try:
            added, total = feedback.sync_local()
            self.done.emit(added, total, "")
        except Exception as e:
            self.done.emit(0, 0, "%s: %s" % (type(e).__name__, e))


class InboxWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OMC 反馈收件箱")
        self.resize(1080, 700)
        self._rows = []
        self._worker = None
        self._build()
        self.reload_local()
        self.sync()

    def _build(self):
        root = QWidget()
        v = QVBoxLayout(root)
        v.setContentsMargins(14, 14, 14, 14)
        v.setSpacing(10)

        head = QHBoxLayout()
        title = QLabel("OMC 反馈收件箱")
        f = QFont()
        f.setPointSize(15)
        f.setBold(True)
        title.setFont(f)
        head.addWidget(title)
        head.addStretch(1)
        self.btn_sync = QPushButton("从服务器收一次")
        self.btn_sync.clicked.connect(self.sync)
        head.addWidget(self.btn_sync)
        self.btn_export = QPushButton("导出全部为 TXT")
        self.btn_export.clicked.connect(self.export)
        head.addWidget(self.btn_export)
        self.btn_del = QPushButton("删掉选中")
        self.btn_del.clicked.connect(self.delete_selected)
        head.addWidget(self.btn_del)
        self.btn_dir = QPushButton("打开数据目录")
        self.btn_dir.clicked.connect(self.open_dir)
        head.addWidget(self.btn_dir)
        v.addLayout(head)

        self.label_state = QLabel("")
        self.label_state.setWordWrap(True)
        v.addWidget(self.label_state)

        split = QSplitter(Qt.Horizontal)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["时间", "类型", "版本", "内容"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self.show_detail)
        split.addWidget(self.table)

        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setPlaceholderText("左边点一条，这里看全文")
        split.addWidget(self.detail)
        split.setSizes([620, 440])
        v.addWidget(split, 1)

        self.setCentralWidget(root)

    # ---------- 数据
    def reload_local(self):
        self._rows = feedback.load_local()
        self.table.setRowCount(len(self._rows))
        for i, row in enumerate(self._rows):
            p = row.get("payload") or {}
            when = str(p.get("time") or "")
            kind = str(p.get("kind") or "")
            ver = "%s %s" % (p.get("app") or "OMC", p.get("ver") or "")
            text = str(p.get("text") or "").replace("\n", " ")
            for col, val in enumerate((when, kind, ver, text[:120])):
                item = QTableWidgetItem(val)
                item.setToolTip(text)
                self.table.setItem(i, col, item)
        if self._rows and self.table.currentRow() < 0:
            self.table.selectRow(0)
        return len(self._rows)

    def show_detail(self):
        i = self.table.currentRow()
        if i < 0 or i >= len(self._rows):
            return
        self.detail.setPlainText(feedback.as_text(self._rows[i]))

    # ---------- 同步
    def sync(self):
        if self._worker is not None and self._worker.isRunning():
            return
        self.btn_sync.setEnabled(False)
        self.label_state.setText("正在从服务器收反馈......")
        w = SyncWorker(self)
        w.done.connect(self._on_synced)
        self._worker = w
        w.start()

    def _on_synced(self, added, total, err):
        self.btn_sync.setEnabled(True)
        self._worker = None
        if err:
            n = self.reload_local()
            self.label_state.setText(
                "连不上服务器（%s）。本地已有 %d 条，先看本地的。" % (err, n))
            return
        n = self.reload_local()
        self.label_state.setText(
            "服务器新收到 %d 条，本地共 %d 条。上次同步：%s"
            % (added, n, feedback.now_text()))

    # ---------- 导出
    def export(self):
        if not self._rows:
            QMessageBox.information(self, "没有反馈", "本地还没有收到任何反馈。")
            return
        p = os.path.join(feedback.inbox_dir(),
                         "反馈导出-%s.txt" % time.strftime("%Y%m%d-%H%M%S"))
        parts = []
        for row in self._rows:
            parts.append("=" * 56)
            parts.append(feedback.as_text(row))
        try:
            with open(p, "w", encoding="utf-8") as f:
                f.write("\n".join(parts))
        except Exception as e:
            QMessageBox.warning(self, "导出失败", str(e))
            return
        self.label_state.setText("已导出：" + p)

    def open_dir(self):
        try:
            os.startfile(feedback.inbox_dir())   # noqa: S606
        except Exception:
            pass

    def delete_selected(self):
        """只从这个收件箱里删掉，服务器上那条还在但过期就没了。"""
        idx = self.table.currentRow()
        if idx < 0 or idx >= len(self._rows):
            return
        rid = self._rows[idx].get("id") or ""
        if not rid:
            return
        rows = [r for r in feedback.load_local() if (r.get("id") or "") != rid]
        tmp = feedback.inbox_path() + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                for r in rows:
                    f.write(__import__("json").dumps(r, ensure_ascii=False) + "\n")
            os.replace(tmp, feedback.inbox_path())
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self.reload_local()
        self.label_state.setText("已删除 1 条，本地还剩 %d 条。" % len(rows))


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("OMC 反馈收件箱")
    win = InboxWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
