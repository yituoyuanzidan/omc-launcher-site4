# -*- mode: python ; coding: utf-8 -*-
"""三平台通用打包脚本。

用法（在各自系统上执行，PyInstaller 不能交叉编译）：
  Windows : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC/OMC.exe
  macOS   : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC.app
  Linux   : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC/OMC
"""
import glob
import os
import sys

APP_NAME = "OMC"
IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"

# 版本号从 core/update.py 读，别在 app 的 Info.plist 里写死
APP_VER = "1.0"
try:
    import io
    import re
    with io.open(os.path.join(SPECPATH, "core", "update.py"), encoding="utf-8") as _f:
        _m = re.search(r'VERSION\s*=\s*"([^"]+)"', _f.read())
        if _m:
            APP_VER = _m.group(1)
except Exception:
    pass

# 资源全部带上（Windows 要 .ico，macOS/Linux 要 PNG）
# assets/ 下的子目录（比如 avatars/ 头像包）要按目录打包，保留里面的层级
datas = []
for p in glob.glob(os.path.join(SPECPATH, "assets", "*")):
    if os.path.isdir(p):
        datas.append((p, os.path.join("assets", os.path.basename(p))))
    else:
        datas.append((p, "assets"))

# 本地种子计算器（cubiomes 编出来的 Windows exe），只在 Windows 包里有意义。
# Linux/macOS 上这个 exe 跑不了，收进去反而会让打包器去分析一个跨平台的 PE 文件。
binaries = []
_calc = os.path.join(SPECPATH, "bin", "omcseeds.exe")
if IS_WIN and os.path.exists(_calc):
    binaries.append((_calc, "bin"))

# Linux：Qt 6.5+ 的 xcb 平台插件依赖 libxcb-cursor.so.0，很多发行版默认不装。
# 这里直接把这个库打进包，用户就不需要自己 apt install。
if not IS_WIN and not IS_MAC:
    for _lib in glob.glob(os.path.join(SPECPATH, "bin", "linux", "libxcb-cursor.so*")):
        binaries.append((_lib, "."))

# Qt 多媒体插件（启动页预告片 mp4 要能播）：打包器不保证收 plugins/multimedia
try:
    import PySide6 as _pyside
    _qtmm = os.path.join(os.path.dirname(_pyside.__file__), "plugins", "multimedia")
    if os.path.isdir(_qtmm):
        datas.append((_qtmm, os.path.join("PySide6", "plugins", "multimedia")))
except Exception:
    pass

icon = None
if IS_WIN and os.path.exists(os.path.join(SPECPATH, "assets", "sword.ico")):
    icon = os.path.join(SPECPATH, "assets", "sword.ico")
elif IS_MAC and os.path.exists(os.path.join(SPECPATH, "assets", "sword.icns")):
    icon = os.path.join(SPECPATH, "assets", "sword.icns")

a = Analysis(
    [os.path.join(SPECPATH, "main.py")],
    pathex=[SPECPATH],
    binaries=binaries,
    datas=datas,
    hiddenimports=["PIL", "PIL.Image", "PIL.ImageDraw", "PIL.ImageFont",
                   "qrcode", "qrcode.image.pil", "qrcode.image.base"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
              "PySide6.QtQml", "PySide6.QtQuick", "PySide6.Qt3DCore"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=[icon] if icon else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name=APP_NAME,
)

if IS_MAC:
    app = BUNDLE(
        coll,
        name=APP_NAME + ".app",
        icon=icon,
        bundle_identifier="com.omc.launcher",
        info_plist={
            "CFBundleName": "OMC",
            "CFBundleDisplayName": "OMC 启动器",
            "CFBundleShortVersionString": APP_VER,
            "CFBundleVersion": APP_VER,
            "NSHighResolutionCapable": True,
            "LSMinimumSystemVersion": "11.0",
        },
    )
