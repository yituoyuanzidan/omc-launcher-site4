# -*- mode: python ; coding: utf-8 -*-
"""三平台通用打包脚本。

用法（在各自系统上执行，PyInstaller 不能交叉编译）：
  Windows : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC/OMC.exe
  macOS   : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC.app
  Linux   : python -m PyInstaller --noconfirm OMC.spec   -> dist/OMC/OMC
"""
import glob
import os
import sys

APP_NAME = "OMC"
IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"

# 版本号从 core/update.py 读，别在 app 的 Info.plist 里写死
APP_VER = "1.0"
try:
    import io
    import re
    with io.open(os.path.join(SPECPATH, "core", "update.py"), encoding="utf-8") as _f:
        _m = re.search(r'VERSION\s*=\s*"([^"]+)"', _f.read())
        if _m:
            APP_VER = _m.group(1)
except Exception:
    pass

# 资源全部带上（Windows 要 .ico，macOS/Linux 要 PNG）
# assets/ 下的子目录（比如 avatars/ 头像包）要按目录打包，保留里面的层级
datas = []
for p in glob.glob(os.path.join(SPECPATH, "assets", "*")):
    if os.path.isdir(p):
        datas.append((p, os.path.join("assets", os.path.basename(p))))
    else:
        datas.append((p, "assets"))

# 本地种子计算器（cubiomes 编出来的 Windows exe），只在 Windows 包里有意义。
# Linux/macOS 上这个 exe 跑不了，收进去反而会让打包器去分析一个跨平台的 PE 文件。
binaries = []
_calc = os.path.join(SPECPATH, "bin", "omcseeds.exe")
if IS_WIN and os.path.exists(_calc):
    binaries.append((_calc, "bin"))

# Linux：Qt 6.5+ 的 xcb 平台插件依赖 libxcb-cursor.so.0，很多发行版默认不装。
# 这里直接把这个库打进包，用户就不需要自己 apt install。
if not IS_WIN and not IS_MAC:
    for _lib in glob.glob(os.path.join(SPECPATH, "bin", "linux", "libxcb-cursor.so*")):
        binaries.append((_lib, "."))

# Qt 多媒体插件（启动页预告片 mp4 要能播）：打包器不保证收 plugins/multimedia
try:
    import PySide6 as _pyside
    _qtmm = os.path.join(os.path.dirname(_pyside.__file__), "plugins", "multimedia")
    if os.path.isdir(_qtmm):
        datas.append((_qtmm, os.path.join("PySide6", "plugins", "multimedia")))
except Exception:
    pass

icon = None
if IS_WIN and os.path.exists(os.path.join(SPECPATH, "assets", "sword.ico")):
    icon = os.path.join(SPECPATH, "assets", "sword.ico")
elif IS_MAC and os.path.exists(os.path.join(SPECPATH, "assets", "sword.icns")):
    icon = os.path.join(SPECPATH, "assets", "sword.icns")

# 自定义 manifest：声明支持的 Windows 版本（Win7 → Win11），打开长路径，
# 按 per-monitor v2 处理高分屏。PyInstaller 自带的默认 manifest 只写一句
# asInvoker，没有 supportedOS，系统会把这个 exe 当成"未声明兼容性"的老程序，
# 一部分启发式引擎正是从这点判断"可疑"的。
_manifest = None
_mf = os.path.join(SPECPATH, "omc.manifest")
if IS_WIN and os.path.exists(_mf):
    try:
        import io as _io2
        _manifest = _io2.open(_mf, encoding="utf-8").read()
        print("manifest -> omc.manifest")
    except Exception as _e:
        print("读 manifest 失败：%s" % _e)
        _manifest = None

# 录屏剪辑用的 PyAV（自带 ffmpeg 编解码库）：core/videocut.py 运行时会把这个
# 目录插进 sys.path，所以整目录原样带进包，不能交给打包器重排 pyd/dll 位置。
_libs = os.path.join(SPECPATH, "_libs")
if os.path.isdir(_libs):
    datas.append((_libs, "_libs"))

# yt-dlp 内核（_tools/yt-dlp.pyz）：YouTube 现在对裸 API 一律要求"登录验证"，
# 只有 yt-dlp 带齐 client 参数能拿到自带音轨的直链。core/videofeed._dlp_zip()
# 会先找 sys._MEIPASS、再找 exe 同级的 _tools/，所以这里必须随包带上，
# 不然「装了新版的用户点开油管视频还是播不了」。
_dlp = os.path.join(SPECPATH, "_tools", "yt-dlp.pyz")
if os.path.exists(_dlp):
    datas.append((_dlp, "_tools"))

# 语音转文字用的 faster-whisper：ctranslate2 的 libctranslate2.dll、
# onnxruntime 的运行时、sounddevice 的 PortAudio、av 自带的 ffmpeg 编解码库，
# 全是静态分析看不见的东西，只能整包收进来。收不全会让 core/stt.py 退回
# 老的 Windows 离线识别（不会崩，但识别质量掉回命令词水平）。
_hidden = ["PIL", "PIL.Image", "PIL.ImageDraw", "PIL.ImageFont",
           "qrcode", "qrcode.image.pil", "qrcode.image.base",
           # 启动前自检模块：它在 main.py 最前面被导入（早于 Qt），
           # 必须确保一定打进去，否则老系统上会先报 ModuleNotFound
           "core.syscheck",
           # 单实例锁与任务栏注册都是在 main() 里延迟导入的，
           # 显式列出来免得被静态分析漏掉
           "core.single", "core.taskbar",
           # 音乐页下载线程里用到 urllib 的 os/ssl 分支，显式带上更保险
           "urllib.request", "ssl"]
_extra_data, _extra_bin = [], []
try:
    from PyInstaller.utils.hooks import collect_all
    for _pkg in ("faster_whisper", "ctranslate2", "tokenizers", "sounddevice",
                 "onnxruntime", "huggingface_hub", "zhconv", "av", "numpy"):
        try:
            _d, _b, _h = collect_all(_pkg)
            _extra_data += _d
            _extra_bin += _b
            _hidden += _h
        except Exception:
            pass
except Exception:
    pass
datas += _extra_data
binaries += _extra_bin

# 包里自带版本号：客户端下载更新包后先读它核对，避免清单/CDN 缓存把旧包
# 当成新版本装上去（装完版本不变、下次启动又提示更新，就是这件事）。
try:
    import io
    import tempfile
    _vdir = tempfile.mkdtemp(prefix="omc_ver_")
    _vfile = os.path.join(_vdir, "omc_version.txt")
    with io.open(_vfile, "w", encoding="utf-8") as _f:
        _f.write(str(APP_VER))
    datas.append((_vfile, "."))
    print("omc_version.txt -> %s" % APP_VER)
except Exception as _e:
    print("写 omc_version.txt 失败：%s" % _e)

# exe 的版本资源（属性页/任务栏/任务管理器读的就是它）。
# 以前没这块，exe 的 FileDescription、ProductName、FileVersion 全是空字符串，
# Windows 拿不到程序名，只能退回「未知程序 / 像崩了」的占位图标和文件名。
_verfile = None
try:
    import io as _io
    import tempfile as _tf
    _parts = str(APP_VER).split(".")
    while len(_parts) < 4:
        _parts.append("0")
    _tup = ",".join(str(int(p)) if str(p).isdigit() else "0"
                    for p in _parts[:4])
    _ver_text = """VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=(%s),
    prodvers=(%s),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable('080404b0', [
        StringStruct('CompanyName', 'OMC'),
        StringStruct('FileDescription', '\u004f\u004d\u0043 \u542f\u52a8\u5668'),
        StringStruct('FileVersion', '%s'),
        StringStruct('InternalName', 'OMC'),
        StringStruct('LegalCopyright', 'Copyright (C) 2026 OMC'),
        StringStruct('LegalTrademarks', 'OMC'),
        StringStruct('OriginalFilename', 'OMC.exe'),
        StringStruct('PrivateBuild', 'OMC Launcher'),
        StringStruct('ProductName', '\u004f\u004d\u0043 \u542f\u52a8\u5668'),
        StringStruct('ProductVersion', '%s'),
        StringStruct('Comments', 'Minecraft launcher')
      ])
    ]),
    VarFileInfo([VarStruct('Translation', [2052, 1200])])
  ]
)
""" % (_tup, _tup, APP_VER, APP_VER)
    _vdir2 = _tf.mkdtemp(prefix="omc_verinfo_")
    _verfile = os.path.join(_vdir2, "version_info.txt")
    with _io.open(_verfile, "w", encoding="utf-8") as _f:
        _f.write(_ver_text)
    print("version_info.txt -> %s" % APP_VER)
except Exception as _e:
    print("写 version_info.txt 失败：%s" % _e)

a = Analysis(
    [os.path.join(SPECPATH, "main.py")],
    pathex=[SPECPATH],
    binaries=binaries,
    datas=datas,
    hiddenimports=_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # 打包时带一堆用不上的东西（标准库里的演示/文档工具）会让杀软看到更多
    # 可疑特征字符串，也白占体积。这里只排明确用不到的模块；setuptools /
    # distutils / pkg_resources 不能排，PyInstaller 的 hook 会冲突。
    excludes=["tkinter", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
              "PySide6.QtQml", "PySide6.QtQuick", "PySide6.Qt3DCore",
              "idlelib", "turtle", "turtledemo", "lib2to3", "pydoc_data",
              "xmlrpc", "this"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # 这里必须是字符串路径。以前写成 icon=[icon]（列表），PyInstaller 6 会
    # 当成无效值直接跳过，打出来的 exe 一点图标都没嵌，任务栏和资源管理器
    # 里就显示成系统默认那个「空白程序 / 像崩了」的占位图标。
    icon=icon if icon else None,
    version=_verfile,
    manifest=_manifest,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name=APP_NAME,
)

if IS_MAC:
    app = BUNDLE(
        coll,
        name=APP_NAME + ".app",
        icon=icon,
        bundle_identifier="com.omc.launcher",
        info_plist={
            "CFBundleName": "OMC",
            "CFBundleDisplayName": "OMC 启动器",
            "CFBundleShortVersionString": APP_VER,
            "CFBundleVersion": APP_VER,
            "NSHighResolutionCapable": True,
            "LSMinimumSystemVersion": "11.0",
        },
    )
