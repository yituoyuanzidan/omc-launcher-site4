# -*- coding: utf-8 -*-
"""OMC 自建第三方登录服务器（Yggdrasil 协议最小实现，只用标准库）。

启动：
    python omc_auth_server.py            # 默认 0.0.0.0:8080
    python omc_auth_server.py 9000       # 换端口

启动器里第三方登录地址填：
    http://你的IP:8080/api/yggdrasil
    （本机调试就填 http://127.0.0.1:8080/api/yggdrasil）

支持的端点：
    GET  /                                  服务器元信息（authlib-injector 靠它拿 serverName）
    POST /authserver/register               注册（本工程扩展，标准 Yggdrasil 没有这个）
    POST /authserver/authenticate           登录
    POST /authserver/refresh                accessToken 续期
    POST /authserver/validate               校验 token 是否有效
    POST /authserver/invalidate             注销 token
    GET  /sessionserver/session/minecraft/profile/<uuid>   角色资料（皮肤/披风留空）

数据存在同目录 users.json，删了就是全清空。密码用 PBKDF2 存哈希，不存明文。
公网部署请务必套一层 HTTPS 反向代理（nginx / caddy），否则 token 明文走网络。
"""
import hashlib
import json
import os
import secrets
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
STORE = os.path.join(HERE, "users.json")
LOCK = threading.Lock()
PBKDF_ROUNDS = 120000
TOKEN_TTL = 30 * 3600          # accessToken 有效 30 小时
PREFIXES = ("/api/yggdrasil", "/api/authlib-injector", "")   # 都当同一个 API 根


# ---------------- 存储 ----------------
def _load():
    if not os.path.isfile(STORE):
        return {"v": 1, "users": {}}
    try:
        with open(STORE, "r", encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("users", {})
        return data
    except Exception:
        return {"v": 1, "users": {}}


def _save(data):
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STORE)


def _hash(pwd, salt=None):
    salt = salt or secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pwd.encode("utf-8"),
                            salt.encode("utf-8"), PBKDF_ROUNDS).hex()
    return salt, h


def _uid():
    return uuid.uuid4().hex


# ---------------- HTTP ----------------
class Handler(BaseHTTPRequestHandler):
    server_version = "OMCAuth/1.0"

    def log_message(self, fmt, *args):
        sys.stdout.write("%s %s\n" % (time.strftime("%H:%M:%S"), fmt % args))
        sys.stdout.flush()

    # ---- 工具 ----
    def _send(self, code, payload=None, ctype="application/json; charset=utf-8"):
        body = (json.dumps(payload, ensure_ascii=False)
                if payload is not None else "").encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, code, message, err="ForbiddenOperationException"):
        self._send(code, {"error": err, "errorMessage": message})

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            return json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return {}

    def _path(self):
        p = self.path.split("?", 1)[0]
        for pre in PREFIXES:
            if not pre:
                continue
            if p == pre or p == pre + "/":
                return "/"
            if p.startswith(pre + "/"):
                return p[len(pre):]
        return p

    # ---- 路由 ----
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.end_headers()

    def do_GET(self):
        path = self._path()
        if path in ("/", ""):
            host = self.headers.get("Host") or "127.0.0.1:8080"
            self._send(200, {
                "meta": {
                    "serverName": "OMC 自建登录",
                    "implementationName": "omc-auth-server",
                    "implementationVersion": "1.0",
                    "feature.non_email_login": True,
                    "feature.open_registration": True,
                },
                "skinDomains": [],
                "signaturePublickey": "",
            })
            return
        if path.startswith("/sessionserver/session/minecraft/profile/"):
            pid = path.rsplit("/", 1)[-1].replace("-", "").lower()
            with LOCK:
                data = _load()
            for name, u in (data.get("users") or {}).items():
                if u.get("uuid", "").lower() == pid:
                    self._send(200, {
                        "id": u["uuid"],
                        "name": name,
                        "properties": [],
                    })
                    return
            self._send(204)
            return
        self._send(404, {"error": "NotFound", "errorMessage": "没有这个接口"})

    def do_POST(self):
        path = self._path()
        body = self._body()
        if path == "/authserver/register":
            self._register(body)
        elif path == "/authserver/authenticate":
            self._authenticate(body)
        elif path == "/authserver/refresh":
            self._refresh(body)
        elif path == "/authserver/validate":
            self._validate(body)
        elif path == "/authserver/invalidate":
            self._invalidate(body)
        else:
            self._send(404, {"error": "NotFound", "errorMessage": "没有这个接口"})

    # ---- 业务 ----
    def _register(self, body):
        email = (body.get("email") or "").strip()
        pwd = body.get("password") or ""
        user = (body.get("username") or email).strip()
        if not email or "@" not in email:
            return self._err(400, "邮箱格式不对")
        if not user or len(user) > 16:
            return self._err(400, "用户名要 1-16 个字符")
        if len(pwd) < 6:
            return self._err(400, "密码至少 6 位")
        with LOCK:
            data = _load()
            users = data["users"]
            if user.lower() in {k.lower() for k in users}:
                return self._err(409, "这个用户名已经注册了")
            for u in users.values():
                if (u.get("email") or "").lower() == email.lower():
                    return self._err(409, "这个邮箱已经注册过了")
            salt, h = _hash(pwd)
            users[user] = {
                "email": email, "salt": salt, "hash": h,
                "uuid": _uid(), "tokens": [], "created": int(time.time()),
            }
            # 顺手发个 token：客户端注册完不用再跑一次登录请求，少一次往返
            token = secrets.token_hex(16)
            users[user]["tokens"].append(
                {"token": token, "expire": int(time.time()) + TOKEN_TTL})
            uuid_ = users[user]["uuid"]
            _save(data)
        print("[register] %s <%s>" % (user, email))
        self._send(200, {
            "ok": True, "username": user, "uuid": uuid_, "name": user,
            "accessToken": token,
            "clientToken": secrets.token_hex(16),
        })

    def _authenticate(self, body):
        user = (body.get("username") or "").strip()
        pwd = body.get("password") or ""
        if not user or not pwd:
            return self._err(400, "用户名和密码都要填")
        with LOCK:
            data = _load()
            users = data.get("users") or {}
            # 支持用邮箱登录
            rec = users.get(user)
            if rec is None:
                for k, u in users.items():
                    if (u.get("email") or "").lower() == user.lower():
                        rec, user = u, k
                        break
            if rec is None:
                return self._err(403, "用户名或密码不对，或者这个账号还没注册")
            if _hash(pwd, rec.get("salt"))[1] != rec.get("hash"):
                return self._err(403, "用户名或密码不对，或者这个账号还没注册")
            token = secrets.token_hex(16)
            rec.setdefault("tokens", []).append(
                {"token": token, "expire": int(time.time()) + TOKEN_TTL})
            rec["tokens"] = [t for t in rec["tokens"] if t["expire"] > time.time()]
            _save(data)
            uuid_ = rec["uuid"]
        print("[login] %s" % user)
        self._send(200, {
            "accessToken": token,
            "clientToken": body.get("clientToken") or secrets.token_hex(16),
            "availableProfiles": [{"id": uuid_, "name": user}],
            "selectedProfile": {"id": uuid_, "name": user},
            "user": {"id": uuid_, "properties": []},
        })

    def _refresh(self, body):
        token = body.get("accessToken") or ""
        with LOCK:
            data = _load()
            for name, rec in (data.get("users") or {}).items():
                for t in rec.get("tokens") or []:
                    if t.get("token") == token:
                        if t.get("expire", 0) <= time.time():
                            return self._err(403, "token 过期了，重新登录")
                        t["expire"] = int(time.time()) + TOKEN_TTL
                        _save(data)
                        self._send(200, {
                            "accessToken": token,
                            "clientToken": body.get("clientToken") or "",
                            "selectedProfile": {"id": rec["uuid"], "name": name},
                            "user": {"id": rec["uuid"], "properties": []},
                        })
                        return
        self._err(403, "token 无效，重新登录")

    def _validate(self, body):
        token = body.get("accessToken") or ""
        with LOCK:
            for rec in (_load().get("users") or {}).values():
                for t in rec.get("tokens") or []:
                    if t.get("token") == token and t.get("expire", 0) > time.time():
                        return self._send(204)
        self._err(403, "token 无效")

    def _invalidate(self, body):
        token = body.get("accessToken") or ""
        with LOCK:
            data = _load()
            hit = False
            for rec in (data.get("users") or {}).values():
                keep = [t for t in rec.get("tokens") or [] if t.get("token") != token]
                hit = hit or len(keep) != len(rec.get("tokens") or [])
                rec["tokens"] = keep
            if hit:
                _save(data)
        self._send(204)


def _lan_ip():
    """猜一个本机局域网 IP（不联网，只借 UDP 路由表）。"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def _is_admin():
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _firewall_rule_exists(name):
    import subprocess
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule",
                            "name=%s" % name],
                           capture_output=True, text=True, timeout=8)
        return "OMC" in (r.stdout or "")
    except Exception:
        return False


def _add_firewall_rule(name, port):
    """加一条入站放行规则；没管理员权限会失败（返回 False）。"""
    import subprocess
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "add", "rule",
                            "name=%s" % name, "dir=in", "action=allow",
                            "protocol=TCP", "localport=%d" % port],
                           capture_output=True, text=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False


def ensure_firewall(port):
    """Windows 下把本端口加入站放行，解决「别的机器连不上 / 防火墙不让进」。"""
    if os.name != "win32":
        return
    name = "OMC 自建登录 %d" % port
    if _firewall_rule_exists(name):
        print("[防火墙] 放行规则已存在：%s" % name)
        return
    if _add_firewall_rule(name, port):
        print("[防火墙] 已自动放行 TCP %d（规则名：%s）" % (port, name))
        return
    print("[防火墙] 自动放行失败（多半是没管理员权限）。")
    if not _is_admin():
        print("         → 右键「以管理员身份运行」这个命令行，或直接跑下面这条：")
    print('         netsh advfirewall firewall add rule name="%s" dir=in action=allow '
          'protocol=TCP localport=%d' % (name, port))
    print("        （云服务器还要在安全组里放行同一个端口，这步程序改不了）")


def main():
    port = 8080
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if args:
        try:
            port = int(args[0])
        except ValueError:
            pass
    no_fw = "--no-firewall" in sys.argv
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    except OSError as e:
        print("端口 %d 起不来：%s" % (port, e))
        print("  多半是被占用了（查：netstat -ano | findstr :%d），换个端口试：" % port)
        print("  python omc_auth_server.py 8081")
        return
    local = "http://127.0.0.1:%d/api/yggdrasil" % port
    lan = _lan_ip()
    print("OMC 自建登录服务已启动，监听 0.0.0.0:%d" % port)
    print("  本机填：%s" % local)
    if lan:
        print("  局域网/别的机器填：http://%s:%d/api/yggdrasil" % (lan, port))
    print("  公网填：http://<你的公网IP>:%d/api/yggdrasil（建议套 HTTPS）" % port)
    print("数据文件：%s" % STORE)
    if not no_fw:
        ensure_firewall(port)
    print("-" * 56)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")


if __name__ == "__main__":
    main()
