# -*- coding: utf-8 -*-
"""游戏截图：扫描 screenshots 目录，供版本详情查看、打开文件夹、设为启动器背景。"""
import os

EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".webp")


def screenshots_dir(game_dir):
    return os.path.join(game_dir, "screenshots")


def list_shots(game_dir):
    """返回 [(path, mtime, size_kb)]，按时间倒序（最新在前）。"""
    d = screenshots_dir(game_dir)
    if not os.path.isdir(d):
        return []
    rows = []
    for name in os.listdir(d):
        if not name.lower().endswith(EXTS):
            continue
        p = os.path.join(d, name)
        try:
            rows.append((p, os.path.getmtime(p),
                         round(os.path.getsize(p) / 1024.0, 1)))
        except OSError:
            continue
    rows.sort(key=lambda r: r[1], reverse=True)
    return rows


def open_dir(game_dir):
    d = screenshots_dir(game_dir)
    os.makedirs(d, exist_ok=True)
    return d


def latest(game_dir):
    rows = list_shots(game_dir)
    return rows[0][0] if rows else None
