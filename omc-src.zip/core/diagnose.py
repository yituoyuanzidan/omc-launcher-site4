# -*- coding: utf-8 -*-
"""崩溃修复：找出「加载器不符」的模组和「缺前置」的依赖，给出可确认的处置清单。

只做扫描和计划，不擅自删文件；删除和安装都由界面二次确认后调用。
"""
import json
import os
import zipfile

BUILTIN = {"minecraft", "java", "fabricloader", "quilt_loader", "forge",
           "neoforge", "modloader", "liteloader"}
LOADER_LABELS = {"fabric": "Fabric", "quilt": "Quilt", "forge": "Forge",
                 "neoforge": "NeoForge", "": "未知"}


def _read_json(z, member):
    try:
        return json.loads(z.read(member).decode("utf-8", "replace"))
    except Exception:
        return None


def _fabric(z, names):
    if "fabric.mod.json" not in names:
        return None
    data = _read_json(z, "fabric.mod.json")
    if not data:
        return None
    deps = []
    for key in (data.get("depends") or {}):
        deps.append((key, True))
    for key in (data.get("recommends") or {}):
        deps.append((key, False))
    loaders = {"fabric", "quilt"}
    return {
        "id": data.get("id", ""),
        "name": data.get("name") or data.get("id", ""),
        "loaders": loaders,
        "deps": deps,
    }


def _toml(z, member, loader):
    try:
        import tomllib
        data = tomllib.loads(z.read(member).decode("utf-8", "replace"))
    except Exception:
        return None
    mods = data.get("mods") or []
    if isinstance(mods, dict):
        mods = [mods]
    if not mods:
        return None
    m = mods[0]
    deps = []
    for _own, entries in (data.get("dependencies") or {}).items():
        if isinstance(entries, dict):
            entries = [entries]
        for e in entries or []:
            if not isinstance(e, dict):
                continue
            mid = e.get("modId")
            if mid:
                deps.append((mid, bool(e.get("mandatory", True))))
    return {
        "id": (m.get("modId") or "").lower(),
        "name": m.get("displayName") or m.get("modId", ""),
        "loaders": {loader},
        "deps": deps,
    }


def mod_meta(path):
    """读单个 jar：返回 {id, name, loaders(set), deps[(modid, mandatory)]}。"""
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            info = _fabric(z, names)
            toml_info = None
            if "META-INF/neoforge.mods.toml" in names:
                toml_info = _toml(z, "META-INF/neoforge.mods.toml", "neoforge")
            elif "META-INF/mods.toml" in names:
                toml_info = _toml(z, "META-INF/mods.toml", "forge")
            if info and toml_info:
                # 同时带两套描述的多加载器模组
                info["loaders"] = info["loaders"] | toml_info["loaders"]
                info["deps"] = info["deps"] + toml_info["deps"]
                return info
            if info:
                return info
            if toml_info:
                return toml_info
    except Exception:
        pass
    return {"id": "", "name": os.path.basename(path), "loaders": set(),
            "deps": []}


def scan(game_dir):
    """扫描 mods 目录，返回每个 jar 的元数据列表。"""
    d = os.path.join(game_dir, "mods")
    if not os.path.isdir(d):
        return []
    rows = []
    for name in sorted(os.listdir(d)):
        if not name.lower().endswith(".jar"):
            continue
        p = os.path.join(d, name)
        meta = mod_meta(p)
        meta["file"] = name
        meta["path"] = p
        rows.append(meta)
    return rows


def plan(game_dir, instance_loader):
    """instance_loader: fabric/quilt/forge/neoforge 或 None（原版）。

    返回 {'mismatch': [...], 'missing': [...], 'anonymous': [...], 'total': n}
    """
    rows = scan(game_dir)
    installed_ids = {r["id"].lower() for r in rows if r["id"]}

    mismatch = []
    anonymous = []
    needed = {}
    for r in rows:
        if not r["id"] and not r["loaders"]:
            anonymous.append({"file": r["file"]})
            continue
        if instance_loader:
            ok = instance_loader in (r["loaders"] or set())
            # 原版实例装任何带加载器元数据的模组都算不符
            if not ok and r["loaders"]:
                mismatch.append({
                    "file": r["file"],
                    "supports": sorted(r["loaders"]),
                    "want": instance_loader,
                })
        for dep_id, mandatory in r["deps"]:
            low = dep_id.lower()
            if low in BUILTIN or low in installed_ids:
                continue
            if low in needed:
                if mandatory:
                    needed[low]["mandatory"] = True
                needed[low]["by"].append(r["file"])
            else:
                needed[low] = {"id": low, "mandatory": bool(mandatory),
                               "by": [r["file"]]}

    missing = [v for v in needed.values() if v["mandatory"]]
    return {
        "mismatch": mismatch,
        "missing": missing,
        "anonymous": anonymous,
        "total": len(rows),
    }


def delete_files(paths, log=None):
    """删除指定 jar；仅由界面在二次确认后调用。"""
    log = log or (lambda _m: None)
    done = 0
    for p in paths:
        try:
            os.remove(p)
            log("已删除模组：" + os.path.basename(p))
            done += 1
        except Exception as e:
            log("删除失败 %s：%s" % (os.path.basename(p), e))
    return done


def resolve_dependency(modid, mc_version="", loader=""):
    """用 Modrinth 搜索按 modid 猜项目，返回 (project_id, title) 或 None。"""
    from . import modrinth
    try:
        hits, _total = modrinth.search("mod", mc_version, modid, loader or None)
    except Exception:
        return None
    if not hits:
        return None
    # 优先 slug / title 里真的含这个 modid 的结果
    low = modid.lower()
    for h in hits:
        slug = (h.get("slug") or "").lower()
        title = (h.get("title") or "").lower()
        if low in slug or low in title:
            return h.get("project_id"), h.get("title") or modid
    return hits[0].get("project_id"), hits[0].get("title") or modid
