# -*- coding: utf-8 -*-
"""跨平台差异集中在这里，别处一律调用本模块，避免散落的 Windows 专用写法。

覆盖三件事：
1. 系统判定与子进程细节（无窗口标志、命令行输出解码）
2. 系统交互（用默认程序打开文件/文件夹、配置目录、字体）
3. 进程与端口探测（Windows 用 tasklist/netstat，Linux 用 /proc 与 ss，macOS 用 lsof）
"""
import glob
import os
import platform
import shutil
import struct
import subprocess
import sys

WINDOWS = os.name == "nt"
MACOS = sys.platform == "darwin"
LINUX = sys.platform.startswith("linux")


def _mojang_os_name():
    """Mojang version json 里的系统名：windows / osx / linux。"""
    if WINDOWS:
        return "windows"
    if MACOS:
        return "osx"
    return "linux"


def _mojang_arch():
    """Mojang 规则里的架构名：x86 / x86_64 / arm64。"""
    machine = platform.machine().lower()
    if WINDOWS and struct.calcsize("P") * 8 == 32:
        return "x86"
    if machine in ("amd64", "x86_64", "x64"):
        return "x86_64"
    if machine in ("arm64", "aarch64"):
        return "arm64"
    return "x86"


OS_NAME = _mojang_os_name()
OS_ARCH = _mojang_arch()

# 本机动态库扩展名（natives 解压后的判断依据）
NATIVE_EXT = ".dll" if WINDOWS else (".dylib" if MACOS else ".so")
NATIVE_EXTS = (".dll", ".so", ".dylib")

# JVM 的 -cp / -Djava.library.path 分隔符：Windows 用分号，类 Unix 用冒号
CP_SEP = ";" if WINDOWS else ":"


def no_window_flags():
    """Windows 下隐藏子进程黑窗；其它系统没有这个常量，一律 0。"""
    if WINDOWS:
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def run_text(args, timeout=12):
    """跑一个命令并返回文本。Windows 命令行输出是本地代码页，按字节读再解码。"""
    try:
        raw = subprocess.run(args, capture_output=True, timeout=timeout,
                             creationflags=no_window_flags()).stdout
    except Exception:
        return ""
    if not raw:
        return ""
    for enc in ("gbk", "utf-8", "mbcs"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def open_path(path):
    """用系统默认程序打开文件或文件夹，三平台各走各的方式。"""
    p = os.path.abspath(path)
    if not os.path.exists(p):
        return False
    try:
        if WINDOWS:
            os.startfile(p)  # noqa: 仅 Windows 存在
            return True
        if MACOS:
            subprocess.Popen(["open", p])
            return True
        opener = shutil.which("xdg-open")
        if opener:
            subprocess.Popen([opener, p])
            return True
    except Exception:
        return False
    return False


def data_dir():
    """配置与缓存目录。macOS 走 Library，其余沿用 ~/.simple_mc_launcher（老用户不丢配置）。"""
    home = os.path.expanduser("~")
    legacy = os.path.join(home, ".simple_mc_launcher")
    if MACOS:
        std = os.path.join(home, "Library", "Application Support", "OMCLauncher")
        # 老目录已存在就继续用，避免升级后配置消失
        if os.path.isdir(legacy) and not os.path.isdir(std):
            return legacy
        try:
            os.makedirs(std, exist_ok=True)
        except Exception:
            pass
        return std
    try:
        os.makedirs(legacy, exist_ok=True)
    except Exception:
        pass
    return legacy


def font_family():
    """QSS 里用的字体候选串，按系统给最像样的那几个。"""
    if WINDOWS:
        return '"Segoe UI", "Microsoft YaHei UI", "Microsoft YaHei", sans-serif'
    if MACOS:
        return ('"Helvetica Neue", "PingFang SC", "Hiragino Sans GB", '
                '"STHeiti", sans-serif')
    return ('"Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Micro Hei", '
            '"DejaVu Sans", sans-serif')


def mono_family():
    """日志/终端用的等宽字体候选串。"""
    if WINDOWS:
        return 'Consolas, "Cascadia Mono", monospace'
    if MACOS:
        return '"SF Mono", Menlo, Monaco, monospace'
    return '"DejaVu Sans Mono", "Noto Sans Mono", monospace'


def java_binary_name():
    """Java 可执行文件名：Windows 是 java.exe，类 Unix 是 java。"""
    return "java.exe" if WINDOWS else "java"


def java_search_dirs():
    """各系统常见的 JDK 安装根目录（只返回真实存在的）。"""
    home = os.path.expanduser("~")
    if WINDOWS:
        roots = [
            r"C:\Program Files\Java", r"C:\Program Files\Eclipse Adoptium",
            r"C:\Program Files\Microsoft", r"C:\Program Files\Zulu",
            r"C:\Program Files\Amazon Corretto", r"C:\Program Files\BellSoft",
            os.path.join(home, ".jdks"),
            os.path.join(home, "scoop", "apps"),
            r"D:\Java", r"D:\Program Files\Java",
        ]
    elif MACOS:
        roots = [
            "/Library/Java/JavaVirtualMachines",
            "/System/Library/Java/JavaVirtualMachines",
            os.path.join(home, "Library", "Java", "JavaVirtualMachines"),
            "/opt/homebrew/opt", "/usr/local/opt",
            os.path.join(home, ".jdks"),
        ]
    else:
        roots = [
            "/usr/lib/jvm", "/usr/java", "/opt/java", "/opt/jdk",
            "/usr/local/java", os.path.join(home, ".jdks"),
            os.path.join(home, ".sdkman", "candidates", "java"),
            os.path.join(home, ".local", "share", "jetbrains"),
        ]
    return [r for r in roots if os.path.isdir(r)]


def java_extra_candidates():
    """PATH 之外的兜底候选：mac 的 java_home、各系统常见位置。"""
    found = []
    binname = java_binary_name()
    if MACOS:
        try:
            out = run_text(["/usr/libexec/java_home"], timeout=8).strip()
            if out:
                found.append(os.path.join(out, "bin", "java"))
        except Exception:
            pass
    for root in java_search_dirs():
        found.extend(glob.glob(os.path.join(root, "*", "bin", binname)))
        found.extend(glob.glob(os.path.join(root, "*", "*", "bin", binname)))
        found.extend(glob.glob(os.path.join(root, "*", "*", "*", "bin", binname)))
    # 启动器自己下载安装的 Java（数据目录/java/jdkXX 下）
    try:
        jroot = os.path.join(data_dir(), "java")
        found.extend(glob.glob(os.path.join(jroot, "*", "bin", binname)))
        found.extend(glob.glob(os.path.join(jroot, "*", "*", "bin", binname)))
        found.extend(glob.glob(os.path.join(jroot, "*", "*", "*", "bin", binname)))
    except Exception:
        pass
    home = os.path.expanduser("~")
    found.extend(glob.glob(os.path.join(home, "*", "bin", binname)))
    found.extend(glob.glob(os.path.join(home, "*", "*", "bin", binname)))
    return found


def java_pids():
    """当前存活的 java 进程 pid。游戏端口一定挂在这些进程下面。"""
    pids = set()
    if WINDOWS:
        for image in ("java.exe", "javaw.exe"):
            out = run_text(["tasklist", "/FI", "IMAGENAME eq " + image,
                            "/FO", "CSV", "/NH"])
            for line in out.splitlines():
                cols = [c.strip('"') for c in line.split(",")]
                if len(cols) >= 2 and cols[1].isdigit():
                    pids.add(int(cols[1]))
        return pids
    if MACOS:
        out = run_text(["ps", "-Ao", "pid=,comm="], timeout=10)
        for line in out.splitlines():
            parts = line.split(None, 1)
            if len(parts) == 2 and parts[0].isdigit():
                name = os.path.basename(parts[1].strip())
                if name.startswith("java"):
                    pids.add(int(parts[0]))
        return pids
    # Linux：直接读 /proc，不依赖 ps
    try:
        for pid_dir in os.listdir("/proc"):
            if not pid_dir.isdigit():
                continue
            try:
                with open("/proc/%s/comm" % pid_dir, "r", encoding="utf-8",
                          errors="ignore") as f:
                    comm = f.read().strip()
            except Exception:
                continue
            if comm.startswith("java"):
                pids.add(int(pid_dir))
    except Exception:
        pass
    return pids


def _parse_ss(out):
    """解析 Linux `ss -ltnp` 输出：LISTEN 0 128 0.0.0.0:25565 ... users:(("java",pid=1234,fd=88))"""
    result = {}
    for line in out.splitlines():
        if "LISTEN" not in line:
            continue
        tokens = line.split()
        if len(tokens) < 4:
            continue
        local = tokens[3]
        if ":" not in local:
            continue
        try:
            port = int(local.rsplit(":", 1)[1])
        except ValueError:
            continue
        pid = 0
        if "pid=" in line:
            frag = line.split("pid=", 1)[1]
            digits = ""
            for ch in frag:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            if digits:
                pid = int(digits)
        result[port] = pid
    return result


def _parse_lsof(out):
    """解析 macOS `lsof -nP -iTCP -sTCP:LISTEN`：java 1234 me 99u IPv4 ... TCP *:25565 (LISTEN)"""
    result = {}
    for line in out.splitlines():
        if "(LISTEN)" not in line:
            continue
        tokens = line.split()
        if len(tokens) < 2 or not tokens[1].isdigit():
            continue
        pid = int(tokens[1])
        local = ""
        for tk in tokens:
            if ":" in tk and "->" not in tk:
                local = tk
                break
        if not local:
            continue
        try:
            port = int(local.rsplit(":", 1)[1])
        except ValueError:
            continue
        result[port] = pid
    return result


def _proc_net_listen():
    """Linux 兜底：直接读 /proc/net/tcp{,6}，只拿 LISTEN 的端口（无 pid）。"""
    result = {}
    for name in ("tcp", "tcp6"):
        path = "/proc/net/" + name
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()[1:]
        except Exception:
            continue
        for line in lines:
            parts = line.split()
            if len(parts) < 4:
                continue
            if parts[3] != "0A":  # 0A = LISTEN
                continue
            local = parts[1]
            if ":" not in local:
                continue
            try:
                port = int(local.rsplit(":", 1)[1], 16)
            except ValueError:
                continue
            result.setdefault(port, 0)
    return result


def listening_ports():
    """所有处于 LISTEN 的 TCP 端口 -> {port: pid}（拿不到 pid 时记为 0）。"""
    if WINDOWS:
        result = {}
        out = run_text(["netstat", "-ano"], timeout=15)
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 5 or parts[3].upper() != "LISTENING":
                continue
            if not parts[0].upper().startswith("TCP"):
                continue
            local, pid = parts[1], parts[4]
            if not pid.isdigit() or ":" not in local:
                continue
            try:
                port = int(local.rsplit(":", 1)[1])
            except ValueError:
                continue
            result[port] = int(pid)
        return result
    if MACOS:
        out = run_text(["lsof", "-nP", "-iTCP", "-sTCP:LISTEN"], timeout=20)
        return _parse_lsof(out)
    ss = shutil.which("ss")
    if ss:
        out = run_text([ss, "-ltnp"], timeout=15)
        parsed = _parse_ss(out)
        if parsed:
            return parsed
    return _proc_net_listen()
