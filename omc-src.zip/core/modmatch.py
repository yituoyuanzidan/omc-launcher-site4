# -*- coding: utf-8 -*-
"""从视频标题认出「这是哪个模组」，再去 Modrinth 查真实项目。

为什么要这么绕：视频标题都是人话（「我的世界最变态的模组」「机械动力生存第 3 期」
「Create 自动化农场教程」），直接把整句丢给模组站搜，返回的多半是不相关的热门
项目。这个模块的做法是：

1. 先把标题里「像模组名」的片段抽出来：书名号、引号、`XX 模组` 前面的词、
   连续的英文词组，再配一张常见中文译名表（机械动力 → create 之类）；
2. 每个候选单独去 Modrinth 搜，拿回来的项目跟候选做**双向包含**比对，
   标题完全相等 / 互相包含才认，光描述里蹭到关键词不算；
3. 分数不到线的直接不返回。

所以可能一条都给不出来 —— 这是故意的：宁可说「这条没提具体模组」，
也不要把不相干的模组塞给用户。
"""
import re
from concurrent.futures import ThreadPoolExecutor

from . import modrinth

# 常见中文译名 → 英文检索词。
# Modrinth 上的项目标题基本是英文，直接拿中文去搜几乎搜不到东西，
# 必须换成对应的英文关键词。键都写长一点，避免「创造」这种泛词误判。
ALIAS = {
    "机械动力": "create",
    "机械动力附属": "create addon",
    "匠魂": "tinkers construct",
    "暮色森林": "twilight forest",
    "虚无世界": "advent of ascension",
    "更多生物": "alexs mobs",
    "生物图鉴": "alexs mobs",
    "工业时代": "industrial craft",
    "工业时代2": "industrial craft 2",
    "植物魔法": "botania",
    "星辉魔法": "astral sorcery",
    "血魔法": "blood magic",
    "神秘时代": "thaumcraft",
    "深渊国度": "abyssalcraft",
    "应用能源": "applied energistics",
    "应用能源2": "applied energistics 2",
    "热力膨胀": "thermal expansion",
    "存储抽屉": "storage drawers",
    "抽屉": "storage drawers",
    "农夫乐事": "farmers delight",
    "小地图": "xaeros minimap",
    "旅行地图": "journeymap",
    "沉浸工程": "immersive engineering",
    "宝可梦": "pixelmon",
    "无尽贪婪": "avaritia",
    "等价交换": "projecte",
    "突变生物": "mutant monsters",
    "灾变": "cataclysm",
    "精妙背包": "sophisticated backpacks",
    "精妙核心": "sophisticated core",
    "机械动力：铁路": "create steam n rails",
    "铁路": "create steam n rails",
    "地牢": "dungeons",
    "远程传送": "waystones",
    "传送石碑": "waystones",
    "树叶快速腐烂": "fast leaf decay",
    "砍树": "treecapitator",
    "苹果皮": "apple skin",
    "苹果皮模组": "apple skin",
    "血量显示": "jade",
    "方块信息": "jade",
    "钠": "sodium",
    "锂": "lithium",
    "铱": "iris",
    "光影加载": "iris",
    "优化": "sodium",
    "自动钓鱼": "autofish",
    "墓碑": "gravestone",
    "背包": "sophisticated backpacks",
    "更多附魔": "apotheosis",
    "附魔描述": "enchantment descriptions",
    "更多箱子": "iron chests",
    "铁箱子": "iron chests",
    "自然指南针": "natures compass",
    "结构指南针": "explorers compass",
    "探险者指南针": "explorers compass",
    "任务书": "ftb quests",
    "FTB任务": "ftb quests",
    "小精灵": "cobblemon",
    "精灵宝可梦": "cobblemon",
    "融合工业": "mekanism",
    "通用机械": "mekanism",
    "机械动力：航空": "create aeronautics",
}

# 英文里当成噪音的词：出现在候选里就说明这段不是模组名
STOP_EN = {
    "minecraft", "minecrafts", "mc", "mod", "mods", "modded", "modpack",
    "java", "bedrock", "edition", "pe", "video", "videos", "shorts",
    "the", "and", "for", "with", "from", "you", "your", "our", "his", "her",
    "how", "what", "why", "when", "best", "top", "new", "old", "more", "most",
    "survival", "creative", "hardcore", "series", "episode", "ep", "part",
    "update", "version", "tutorial", "guide", "tips", "tricks", "challenge",
    "world", "seed", "seeds", "build", "builds", "let", "lets", "play", "plays",
    "playing", "game", "games", "gaming", "live", "stream", "streaming",
    "full", "free", "download", "official", "trailer", "music", "sound",
    "funny", "fails", "moments", "reaction", "review", "first", "last",
    "day", "days", "night", "hour", "hours", "minute", "minutes",
    "vs", "and", "of", "in", "on", "at", "to", "is", "are", "was", "were",
    "i", "we", "they", "he", "she", "it", "my", "me", "us", "them",
    "this", "that", "these", "those", "be", "been", "will", "would", "can",
    "could", "should", "do", "does", "did", "have", "has", "had", "not",
    "no", "yes", "all", "any", "some", "one", "two", "three", "ten",
    "100", "1000", "2023", "2024", "2025", "2026", "hd", "4k", "1080p",
}

# 中文标题里几乎不可能是模组名的词
STOP_ZH = ("我的世界", "模组", "整合包", "生存", "实况", "教程", "视频",
           "系列", "第", "期", "集", "合集", "地图", "种子", "服务器",
           "联机", "小游戏", "建筑", "红石", "皮肤", "材质", "光影",
           "挑战", "攻略", "解说", "整活", "搞笑", "版本", "更新",
           "下载", "介绍", "推荐", "盘点", "排行", "十大", "最强",
           "最新", "怎么", "如何", "为什么", "什么", "这个", "那个")

RE_QUOTED = re.compile(r"[《「『“\"]([^》」』”\"]{2,28})[》」』”\"]")
RE_ZH_MOD = re.compile(r"([\u4e00-\u9fa5A-Za-z0-9][\u4e00-\u9fa5A-Za-z0-9:：·\.\-\s]{1,18}?)"
                       r"\s*(?:模组|MOD|mod|Mod)")
RE_EN_CHUNK = re.compile(r"[A-Za-z][A-Za-z0-9'’\.\-]*(?:\s+[A-Za-z][A-Za-z0-9'’\.\-]*){0,3}")


def _norm(s):
    s = (s or "").lower()
    s = s.replace("’", "'")
    s = re.sub(r"[\s\-_·,\.'\"!?~:;+&/\\()\[\]（）【】《》「」]", "", s)
    return s.strip()


def _clean_zh(word):
    w = (word or "").strip()
    w = re.sub(r"^[0-9\s\-—:：·]+", "", w)
    w = re.sub(r"[\s\-—:：·]+$", "", w)
    w = w.replace("的", "") if len(w) > 4 else w
    return w


def candidates(title, desc="", tags=""):
    """抽出「可能是模组名」的候选，按可信度排序返回 [(原文, 英文检索词, 来源)]。"""
    text = "%s %s %s" % (title or "", desc or "", tags or "")
    out = []
    seen = set()

    def push(name, query, src):
        name = (name or "").strip()
        if not name or len(name) < 2:
            return
        key = _norm(query)
        if not key or key in seen:
            return
        seen.add(key)
        out.append((name, query, src))

    # 1) 书名号 / 引号里的东西最像专名
    for m in RE_QUOTED.finditer(text):
        w = m.group(1).strip()
        if len(w) >= 2 and not any(k in w for k in STOP_ZH if len(k) > 2):
            push(w, ALIAS.get(w, w), "引号")

    # 2) 中文译名表：命中即高可信
    for zh, en in ALIAS.items():
        if zh in text:
            push(zh, en, "译名")

    # 3) 「XX 模组」前面的那段
    for m in RE_ZH_MOD.finditer(title or ""):
        w = _clean_zh(m.group(1))
        if len(w) < 2:
            continue
        if any(w == k or (k in w and len(k) >= 2) for k in STOP_ZH):
            # 只剩「恐怖模组」这种泛词，不当作模组名
            if not any(k in w for k in ALIAS):
                continue
        push(w, ALIAS.get(w, w), "标题")

    # 4) 英文词组：挑不像普通单词的
    for m in RE_EN_CHUNK.finditer(title or ""):
        w = m.group(0).strip()
        words = [x for x in re.split(r"\s+", w) if x]
        if not words or any(x.lower() in STOP_EN for x in words):
            continue
        if len(words) == 1 and len(words[0]) < 4:
            continue
        if len(words) == 1 and not re.search(r"[A-Z]", words[0]) \
                and not re.search(r"'", words[0]):
            # 全小写单词很可能是普通词，除非它很长
            if len(words[0]) < 7:
                continue
        push(w, w, "英文")
    return out[:10]


def _hit_score(hit, cand, video_text):
    """候选与 Modrinth 项目像不像同一件事。返回 0~105。"""
    title = (hit.get("title") or "").strip()
    slug = (hit.get("slug") or "").strip()
    desc = (hit.get("description") or "").strip()
    nt, ns, nc = _norm(title), _norm(slug), _norm(cand)
    if not nc:
        return 0
    if nc == nt or nc == ns:
        return 100
    if len(nc) >= 3 and (nc in nt or nt in nc):
        return 88
    if len(ns) >= 3 and (nc in ns or ns in nc):
        return 84
    # 项目名整个出现在视频标题里（「Create 自动化农场」里的 Create）
    nv = _norm(video_text)
    if len(nt) >= 4 and nt in nv:
        return 85
    # 只有描述里蹭到：不算，最多给点分让它排后面（低于阈值，实际会被丢掉）
    if len(nc) >= 5 and nc in _norm(desc):
        return 40
    return 0


def _fmt_downloads(n):
    try:
        n = int(n or 0)
    except Exception:
        n = 0
    if n >= 1000000:
        return "%.1fM" % (n / 1000000.0)
    if n >= 1000:
        return "%.0fK" % (n / 1000.0)
    return str(n)


def find(video, limit=6, min_score=82):
    """给一条视频找相关模组。返回 dict：items / note / used。

    宁缺勿错：没有任何项目能跟候选对上名字时，items 就是空的，
    note 会说明原因，界面照实显示，不硬凑。
    """
    title = (video.get("title") or "").strip()
    desc = (video.get("desc") or "") or (video.get("description") or "")
    tags = video.get("tags") or ""
    video_text = " ".join((title, desc if isinstance(desc, str) else "", str(tags)))
    if not title:
        return {"items": [], "used": [], "note": "这条没有标题，认不出模组"}

    cands = candidates(title, desc if isinstance(desc, str) else "", str(tags))
    if not cands:
        return {"items": [], "used": [],
                "note": "标题里没出现具体的模组名（只有主题词），认不出来"}

    def one(cand):
        name, query, src = cand
        try:
            hits, _total = modrinth.search("mod", None, query, None, 0, 12)
        except Exception:
            return cand, []
        scored = []
        for h in hits:
            s = _hit_score(h, query, video_text)
            if s < min_score:
                continue
            scored.append((s, h))
        # 同一档位（比如都只是名字互相包含）时，下载量大的更像「正主」：
        # 官方 The Twilight Forest 和二创 Twilight Forest - Dungeons & Villages
        # 名字都含 twilight forest，得分一样，靠下载量才分得出来。
        scored.sort(key=lambda x: (-x[0], -(int(x[1].get("downloads") or 0))))
        return cand, scored

    found = {}
    with ThreadPoolExecutor(max_workers=4) as ex:
        for cand, scored in list(ex.map(one, cands)):
            name, query, src = cand
            for s, h in scored[:2]:
                slug = h.get("slug") or ""
                key = slug or _norm(h.get("title"))
                if not key:
                    continue
                cur = found.get(key)
                if cur is None or s > cur["score"]:
                    found[key] = {
                        "title": h.get("title") or "",
                        "slug": slug,
                        "desc": (h.get("description") or "")[:180],
                        "icon": h.get("icon_url") or "",
                        "downloads": int(h.get("downloads") or 0),
                        "downloads_text": _fmt_downloads(h.get("downloads")),
                        "loaders": h.get("categories") or [],
                        "matched": name,
                        "matched_by": src,
                        "score": s,
                        "level": ("完全同名" if s >= 100 else
                                  "名字包含" if s >= 88 else
                                  "标题提到"),
                        "url": "https://modrinth.com/mod/%s" % slug if slug else "",
                    }

    items = sorted(found.values(),
                   key=lambda x: (-x["score"], -x["downloads"]))[:limit]
    if not items:
        return {"items": [], "used": [c[0] for c in cands[:4]],
                "note": "认出了「%s」这些词，但模组站上没有对得上的项目"
                        % "、".join(c[0] for c in cands[:3])}
    return {"items": items, "used": [i["matched"] for i in items],
            "note": ""}
