# -*- coding: utf-8 -*-
"""娱乐页的联机传输：邀请好友、随机匹配、房间内同步棋步。

还是走公共中转（ntfy），和聊天同一套思路，但用独立的频道前缀，
不往聊天记录里塞东西：
  * 邀请频道  omc-ginv-<双方名字哈希>
  * 匹配频道  omc-gmatch-<游戏 id>
  * 房间频道  omc-game-<房间号哈希>

消息都是小 json：
  {"t":"inv","f":我,"game":..,"bet":..,"room":..}         邀请
  {"t":"ack","f":他,"room":..,"yes":1}                     接受/拒绝
  {"t":"m","f":我,"room":..}                               进匹配池
  {"t":"join","f":我,"room":..,"to":房主,"game":..,"bet":..} 抢房间
  {"t":"start","f":房主,"x":先手,"o":后手,"game":..,"bet":..}
  {"t":"mv","f":我,"m":{...}}                              棋步
  {"t":"res","f":我,"win":1/2/0}                           结算
  {"t":"bye","f":我}
真人对局里的棋步没做加密，也不做权威校验 —— 谁作弊都能改本地结果，
所以这里的积分只当娱乐，别当钱看。
"""
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request

BASE = "https://ntfy.sh"
UA = "OMC/1.0"
TIMEOUT = 8


def _h(s):
    return hashlib.md5(s.encode("utf-8")).hexdigest()[:12]


def inbox_topic(name):
    """每个人的邀请收件箱：所有发给我的邀请都进这一个频道。

    以前是按「双方名字哈希」建频道 —— 好友有 N 个就得轮询 N 个频道，
    N 个 HTTP 串在主线程里，好友一多界面就卡死；而且双方共用一个频道，
    自己发出去的邀请会被自己读回来当成「别人发来的邀请」（显示成自己邀自己）。
    改成一人一个收件箱后：一次请求收全部邀请，再按消息里的 to 字段判断是不是给我的。
    """
    return "omc-ginv2-" + _h("omc-ginv2-v1|" + (name or "").strip().lower())


def inv_topic(me, peer):
    """老协议（双方共用频道），只为兼容旧版客户端保留，新代码不要用。"""
    pair = sorted([(me or "").strip().lower(), (peer or "").strip().lower()])
    return "omc-ginv-" + _h("omc-ginv-v1|" + "|".join(pair))


def match_topic(game):
    return "omc-gmatch-" + _h("omc-gmatch-v1|" + (game or ""))


def room_topic(room):
    return "omc-game-" + _h("omc-game-v1|" + (room or ""))


def new_room():
    return _h(str(time.time()) + os.urandom(8).hex())


def _post(tp, payload, timeout=TIMEOUT):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BASE + "/" + tp, data=body, method="POST",
        headers={"Title": "OMC", "User-Agent": UA,
                 "Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return 200 <= r.getcode() < 300


def _pull(tp, since="40s", timeout=TIMEOUT, kinds=None):
    q = urllib.parse.urlencode({"poll": "1", "since": since})
    url = "%s/%s/json?%s" % (BASE, tp, q)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
    except Exception:
        return []
    out = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception:
            continue
        if item.get("event") and item.get("event") != "message":
            continue
        try:
            p = json.loads(item.get("message") or "{}")
        except Exception:
            continue
        if not isinstance(p, dict) or not p.get("t"):
            continue
        if kinds and p.get("t") not in kinds:
            continue
        p["_ts"] = int(item.get("time") or 0)
        p["_nid"] = item.get("id") or ""
        out.append(p)
    return out


# ---------- 邀请 ----------
def send_invite(me, peer, game, bet, room, timeout=TIMEOUT):
    """给好友发一个对局邀请（写进对方收件箱）。返回 (ok, 说明)。"""
    if not me or not peer:
        return False, "还没登录或没选好友"
    try:
        _post(inbox_topic(peer),
              {"t": "inv", "f": me, "to": peer, "game": game,
               "bet": int(bet), "room": room}, timeout=timeout)
    except Exception as e:
        return False, "邀请没发出去：%s" % e
    return True, "邀请已发给 %s，等他在娱乐页点「接受」" % peer


def poll_inbox(me, since="60s", timeout=TIMEOUT):
    """读自己的收件箱：只留「发给我的、且不是我发的」邀请和答复。

    这个 to / f 过滤是「发起邀请显示成自己邀请自己」的根因修复：
    以前双方共用频道，自己发出的 inv 会被自己读回来当成收到的邀请。
    """
    me_l = (me or "").strip().lower()
    if not me_l:
        return []
    rows = _pull(inbox_topic(me), since=since, timeout=timeout,
                 kinds=("inv", "ack"))
    out = []
    for r in rows:
        to_l = (r.get("to") or "").strip().lower()
        if to_l and to_l != me_l:
            continue
        f_l = (r.get("f") or "").strip().lower()
        if not f_l or f_l == me_l:
            continue
        out.append(r)
    return out


def poll_invite(me, peer, since="90s", timeout=TIMEOUT):
    """兼容旧调用：现在等价于读自己的收件箱。"""
    return poll_inbox(me, since=since, timeout=timeout)


def send_ack(me, peer, room, yes, timeout=TIMEOUT):
    """答复发进邀请者（peer）的收件箱。"""
    try:
        _post(inbox_topic(peer),
              {"t": "ack", "f": me, "to": peer, "room": room,
               "yes": 1 if yes else 0}, timeout=timeout)
        return True
    except Exception:
        return False


# ---------- 匹配 ----------
def join_pool(me, game, room, bet, timeout=TIMEOUT):
    """把自己的房间号扔进匹配池。"""
    try:
        _post(match_topic(game),
              {"t": "m", "f": me, "room": room, "game": game,
               "bet": int(bet)}, timeout=timeout)
        return True, ""
    except Exception as e:
        return False, "匹配没发出去：%s" % e


def poll_pool(game, me, room, since="20s", timeout=TIMEOUT, fresh=15):
    """看池子里的别人。返回 [{f, room, bet}]（不含自己这间的）。

    fresh：只认最近 fresh 秒内的广播。池子是公共频道，会翻出几小时前别人
    早就走掉的旧消息，不过滤就会匹配到一个根本不在的人（配上就卡住）。
    """
    rows = _pull(match_topic(game), since=since, timeout=timeout, kinds=("m",))
    now = time.time()
    me_l = (me or "").strip().lower()
    out = []
    for r in rows:
        ts = int(r.get("_ts") or 0)
        if ts and now - ts > fresh:
            continue
        f = (r.get("f") or "").strip()
        if not f or f.lower() == me_l:
            continue
        if (r.get("room") or "") == room:
            continue
        out.append({"f": f, "room": r.get("room") or "",
                    "bet": int(r.get("bet") or 0)})
    return out


def match_round(me, game, my_room, bet, timeout=TIMEOUT):
    """匹配一轮：先把自己广播进池子，再挑一个确定的对手发进房请求。

    两边同时看见对方时不能互相发 join（会开出两局），所以约定
    「房间号小的当房主、房间号大的去敲门」：room 是随机 md5，双方算出来的
    大小关系是同一个，天然只有一方会发请求。
    返回 (对手 dict 或 None)。
    """
    join_pool(me, game, my_room, bet, timeout=timeout)
    for r in poll_pool(game, me, my_room, timeout=timeout):
        if (r.get("room") or "") < (my_room or ""):
            send_room(r["room"], {"t": "join", "f": me, "to": r["f"],
                                  "room": r["room"], "game": game,
                                  "bet": int(bet)}, timeout=timeout)
            return r
    return None


# ---------- 后台轮询（主线程只负责把快照丢进来、再接结果） ----------
def poll_all(snap, timeout=TIMEOUT):
    """一次取回收件箱 / 房间 / 匹配池。纯网络，不碰任何 Qt 对象。

    snap: {me, room, room_since, inv_since, game, bet, searching, pool_room}
    返回: {inv:[], room:[], matched:None|{f,room,bet}, err:""}
    """
    out = {"inv": [], "room": [], "matched": None, "err": ""}
    me = (snap.get("me") or "").strip()
    if not me:
        return out
    try:
        out["inv"] = poll_inbox(me, since=snap.get("inv_since") or "60s",
                                timeout=timeout)
    except Exception as e:
        out["err"] = "收件箱：%s" % e
    room = snap.get("room") or ""
    if room:
        try:
            out["room"] = poll_room(room, since=snap.get("room_since") or "25s",
                                    timeout=timeout)
        except Exception as e:
            out["err"] = "房间：%s" % e
    if snap.get("searching"):
        try:
            out["matched"] = match_round(me, snap.get("game") or "",
                                         snap.get("pool_room") or "",
                                         snap.get("bet") or 0, timeout=timeout)
        except Exception as e:
            out["err"] = "匹配：%s" % e
    return out


# ---------- 房间 ----------
def send_room(room, payload, timeout=TIMEOUT):
    try:
        _post(room_topic(room), payload, timeout=timeout)
        return True
    except Exception:
        return False


def poll_room(room, since="25s", timeout=TIMEOUT):
    return _pull(room_topic(room), since=since, timeout=timeout)


def send_move(room, me, move, timeout=TIMEOUT):
    return send_room(room, {"t": "mv", "f": me, "m": move}, timeout=timeout)


def send_result(room, me, win, amt=0, timeout=TIMEOUT):
    """广播结算。amt 是输家这一局实际扣掉的积分，赢家据此给自己加账。"""
    return send_room(room, {"t": "res", "f": me, "win": int(win),
                            "amt": int(amt or 0)}, timeout=timeout)


def send_bye(room, me, timeout=TIMEOUT):
    return send_room(room, {"t": "bye", "f": me}, timeout=timeout)
