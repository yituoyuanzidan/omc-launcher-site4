# -*- coding: utf-8 -*-
"""手机想真玩 MC：给串流方案做一个状态检测（Sunshine 服务端）。

手机端那台设备跑不动 Java 版，唯一可行的是把电脑画面串到手机：
电脑装 Sunshine（开源 GameStream 服务端），手机装 Moonlight（客户端）。
这里只做「有没有装、有没有在跑、手机该点哪个地址」，不代替用户去装。
"""
import os
import socket
import subprocess

EXE_HINTS = (
    os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                 "Sunshine", "sunshine.exe"),
    os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 "Sunshine", "sunshine.exe"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Sunshine", "sunshine.exe"),
)
WEB_PORT = 47990          # Sunshine 的网页管理台（https）
GAME_PORT = 47989         # Moonlight 走的 HTTP 端口
PAIR_PORT = 47984         # Moonlight 走的 HTTPS 端口


def _port_open(port, timeout=0.35):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def find_exe():
    for p in EXE_HINTS:
        try:
            if p and os.path.isfile(p):
                return p
        except Exception:
            pass
    # 兜底：PATH 里能查到
    try:
        for d in (os.environ.get("PATH") or "").split(os.pathsep):
            p = os.path.join(d, "sunshine.exe")
            if os.path.isfile(p):
                return p
    except Exception:
        pass
    return ""


def is_running():
    if _port_open(GAME_PORT) or _port_open(PAIR_PORT) or _port_open(WEB_PORT):
        return True
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq sunshine.exe", "/NH"],
            capture_output=True, timeout=6,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        txt = (out.stdout or b"").decode("mbcs", "replace").lower()
        return "sunshine.exe" in txt
    except Exception:
        return False


def detect(lan_ip=""):
    """返回给手机端渲染用的状态。"""
    exe = find_exe()
    running = is_running() if exe else _port_open(GAME_PORT)
    ip = lan_ip or ""
    web = ""
    if ip:
        web = "https://%s:%d" % (ip, WEB_PORT)
    if running and ip:
        msg = "串流服务在跑。手机装 Moonlight，搜到这台电脑就能连上玩。"
    elif exe:
        msg = "电脑上装了 Sunshine，但没在运行。启动它以后手机用 Moonlight 连。"
    else:
        msg = "电脑上还没装串流服务。想用手机玩就得装 Sunshine（免费开源）。"
    return {"installed": bool(exe), "running": bool(running),
            "exe": exe, "web": web, "ip": ip,
            "game_port": GAME_PORT, "web_port": WEB_PORT,
            "msg": msg}
