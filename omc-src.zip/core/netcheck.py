# -*- coding: utf-8 -*-
"""网络自检：把「下载慢 / 登录慢 / 扫码打不开」拆成能单独判断的几项。

不做诊断结论的猜测，只报每一项的实测数字：
- 本机局域网地址（手机扫码要用的那个）
- 扫码确认页端口能不能绑上（80 / 8080 / 8901）
- 域名解析耗时
- 站点与两条下载短链的响应耗时和状态码

调用方拿到 dict 自己拼文本，模块里不碰 Qt。
"""
import socket
import time
import urllib.request

SITE_URL = "https://yituoyuanzidan.github.io/omc-launcher-site4/"
CDN_URLS = (
    ("标准版短链", "https://aka.doubaocdn.com/s/gA2cVWpG35"),
    ("老系统版短链", "https://aka.doubaocdn.com/s/vgTQuIDLMZ"),
)


def _opener():
    # 直连：本地系统代理经常把测速结果算成代理的耗时，这里绕开它
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _timed_tcp(host, port, timeout=4.0):
    t = time.time()
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        try:
            s.close()
        except Exception:
            pass
        return time.time() - t, ""
    except Exception as e:
        return time.time() - t, "%s: %s" % (type(e).__name__, e)


def _timed_http(url, timeout=8.0, headers=None):
    t = time.time()
    try:
        req = urllib.request.Request(url, headers=headers or {
            "User-Agent": "OMC-netcheck/1.0"})
        with _opener().open(req, timeout=timeout) as r:
            n = len(r.read(2048))
            return time.time() - t, r.getcode(), n, ""
    except Exception as e:
        return time.time() - t, 0, 0, "%s: %s" % (type(e).__name__, e)


def _port_free(port, host="0.0.0.0"):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port))
        return True, ""
    except Exception as e:
        return False, str(e)
    finally:
        try:
            s.close()
        except Exception:
            pass


def check(ports=(80, 8080, 8901), timeout=8.0):
    """跑一遍全部检查，返回结果 dict（不抛异常）。"""
    res = {"lan": "", "lan_err": "", "dns": None, "dns_name": "",
           "site": None, "cdn": [], "ports": [], "at": time.strftime(
               "%Y-%m-%d %H:%M:%S"), "host": ""}

    # 1) 局域网地址（复用扫码模块那套网卡打分逻辑）
    try:
        from core import qrlogin
        t = time.time()
        res["lan"] = qrlogin.lan_ip(force=True)
        res["lan_cost"] = time.time() - t
        res["host"] = socket.gethostname()
    except Exception as e:
        res["lan_err"] = "%s: %s" % (type(e).__name__, e)

    # 2) 扫码端口
    for p in ports:
        ok, err = _port_free(p)
        res["ports"].append({"port": p, "free": ok, "err": err})

    # 3) 域名解析
    host = "yituoyuanzidan.github.io"
    res["dns_name"] = host
    t = time.time()
    try:
        socket.getaddrinfo(host, 443, socket.AF_INET, socket.SOCK_STREAM)
        res["dns"] = time.time() - t
    except Exception as e:
        res["dns"] = -1.0
        res["dns_err"] = "%s: %s" % (type(e).__name__, e)

    # 4) 站点首页
    cost, code, n, err = _timed_http(SITE_URL, timeout=timeout)
    res["site"] = {"cost": cost, "code": code, "bytes": n, "err": err}

    # 5) 两条下载短链（只取 1KB，别真拉几百兆）
    for name, url in CDN_URLS:
        cost, code, n, err = _timed_http(
            url, timeout=timeout, headers={"Range": "bytes=0-1023",
                                           "User-Agent": "OMC-netcheck/1.0"})
        res["cdn"].append({"name": name, "url": url, "cost": cost,
                           "code": code, "bytes": n, "err": err})
    return res


def report_text(res):
    """把结果拼成一段人能读、能直接复制发出去的文本。"""
    lines = ["OMC 网络自检  %s" % res.get("at", ""),
             "主机名：%s" % (res.get("host") or "（取不到）")]
    if res.get("lan"):
        lines.append("局域网地址：%s（手机扫码用的就是这个）" % res["lan"])
    else:
        lines.append("局域网地址：取不到（%s）" % (res.get("lan_err") or "原因未知"))
    lines.append("")

    lines.append("扫码端口：")
    for p in res.get("ports") or []:
        if p["free"]:
            lines.append("  %d 可用（扫码会优先用它）" % p["port"])
        else:
            lines.append("  %d 被占用（%s）" % (p["port"], p["err"]))
    lines.append("")

    dns = res.get("dns")
    if dns is None:
        lines.append("域名解析：未执行")
    elif dns < 0:
        lines.append("域名解析：失败（%s）" % (res.get("dns_err") or ""))
    else:
        lines.append("域名解析：%s 用时 %.0f ms%s"
                     % (res.get("dns_name"), dns * 1000,
                        "" if dns < 1.0 else "（偏慢，>1 秒）"))
    lines.append("")

    site = res.get("site") or {}
    if site.get("err"):
        lines.append("更新站点：失败 %.1f 秒（%s）" % (site.get("cost", 0), site["err"]))
    else:
        lines.append("更新站点：HTTP %s，%.0f ms，首个 %d 字节"
                     % (site.get("code"), site.get("cost", 0) * 1000,
                        site.get("bytes", 0)))
    lines.append("")

    lines.append("下载短链（只取前 1KB）：")
    for c in res.get("cdn") or []:
        if c.get("err"):
            lines.append("  %s：失败 %.1f 秒（%s）" % (c["name"], c["cost"], c["err"]))
        else:
            lines.append("  %s：HTTP %s，%.0f ms" % (c["name"], c["code"],
                                                  c["cost"] * 1000))
    lines.append("")
    lines.append("判读：扫码端口空着而页面仍打不开，多半是路由器开了设备隔离"
                 "（换手机热点）；域名解析 >1 秒说明 DNS 慢，换 114.114.114.114 "
                 "或 223.5.5.5；短链失败但站点正常，说明 CDN 那条路被拦，"
                 "让启动器走站点直链。")
    return "\n".join(lines)
