# -*- coding: utf-8 -*-
"""缓存清理。

启动器攒下来的东西分两类：
  1. 删了会自动重建的 —— 联网缓存、预告片、临时解压残留、下载残片；
  2. 删了就回不来的 —— 在线搜歌下载下来的音乐缓存。
第二类单独列出来、默认不勾，免得一键清理把玩家存的歌一起清了。
"""
import os
import shutil
import stat
import tempfile

from core.config import app_dir

# 下载中断会在这些目录里留下 *.part 半截文件
_PART_DIRS = ("mods", "versions", "libraries", "resourcepacks",
              "shaderpacks", "saves", "datapacks")


def _temp_dirs():
    """系统临时目录下我们自己建的 omc_* 残留。"""
    out = []
    try:
        root = tempfile.gettempdir()
        for name in os.listdir(root):
            if name.lower().startswith("omc_"):
                p = os.path.join(root, name)
                if os.path.isdir(p):
                    out.append(p)
    except Exception:
        pass
    return out


def _part_files(game_dir, limit=300):
    """游戏目录里下载中断留下的 *.part（只往下看 3 层，别把大目录全扫一遍）。"""
    out = []
    if not game_dir or not os.path.isdir(game_dir):
        return out
    for sub in _PART_DIRS:
        base = os.path.join(game_dir, sub)
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            depth = root[len(base):].count(os.sep)
            if depth >= 3:
                dirs[:] = []
            for name in files:
                if name.lower().endswith(".part"):
                    out.append(os.path.join(root, name))
                    if len(out) >= limit:
                        return out
    return out


def targets(game_dir=""):
    """所有可清理项。default=False 的项默认不勾（删了就没了）。"""
    d = app_dir()
    return [
        {"id": "net", "name": "联网缓存",
         "desc": "官方版本号列表、Modrinth 封面等，删掉后下次联网会自动重新拉。",
         "paths": [os.path.join(d, "cache")], "default": True},
        {"id": "trailer", "name": "预告片缓存",
         "desc": "启动页那支宣传片，删掉后下次回启动页会自动重新下。",
         "paths": [os.path.join(d, "trailer")], "default": True},
        {"id": "temp", "name": "临时解压残留",
         "desc": "导入模组/存档中途失败留下的临时目录，正常退出会自动删，异常退出才会有。",
         "paths": _temp_dirs(), "default": True},
        {"id": "part", "name": "下载残片（.part）",
         "desc": "游戏文件下载中断留下的半截文件，删掉后重新下载会自己补齐。",
         "paths": _part_files(game_dir), "default": True},
        {"id": "music", "name": "音乐缓存",
         "desc": "在线搜歌下载下来的歌。删掉后「我的列表」里的歌要重新下载才能听。",
         "paths": [os.path.join(d, "music_cache")], "default": False},
    ]


def measure(paths):
    """统计总字节数与文件个数，读不到的跳过（不因为一个坏链接整个扫不动）。"""
    total = 0
    count = 0
    for p in paths:
        try:
            if os.path.isdir(p):
                for root, _dirs, files in os.walk(p):
                    for name in files:
                        try:
                            total += os.path.getsize(os.path.join(root, name))
                            count += 1
                        except OSError:
                            pass
            elif os.path.isfile(p):
                total += os.path.getsize(p)
                count += 1
        except OSError:
            pass
    return total, count


def _rmtree(path):
    """shutil.rmtree 遇到只读文件会半路失败，这里先解锁再删。"""
    def _on_error(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass
    shutil.rmtree(path, onerror=_on_error)


def _walk_files(paths):
    """把要删的东西展开成文件清单，用来算进度。"""
    out = []
    for p in paths:
        try:
            if os.path.isdir(p):
                for root, _dirs, files in os.walk(p):
                    for name in files:
                        out.append(os.path.join(root, name))
            elif os.path.isfile(p):
                out.append(p)
        except OSError:
            pass
    return out


def clean(paths, progress=None):
    """删掉给定的路径。返回 (文件数, 字节数, 失败路径列表)。

    progress：给了就每删掉一个文件回调一次 progress(已删, 总数, 当前文件)，
    工具箱那一页拿它推进度条 —— 大缓存不至于点一下卡十几秒没反应。
    """
    files_list = _walk_files(paths)
    total = len(files_list)
    files = 0
    size = 0
    fail = []
    done = 0
    if progress:
        try:
            progress(0, total, "")
        except Exception:
            progress = None
    for fp in files_list:
        try:
            s = os.path.getsize(fp)
        except OSError:
            s = 0
        try:
            os.remove(fp)
            files += 1
            size += s
        except OSError:
            # 只读文件先解锁再删
            try:
                os.chmod(fp, stat.S_IWRITE)
                os.remove(fp)
                files += 1
                size += s
            except Exception:
                if os.path.dirname(fp) not in fail:
                    fail.append(os.path.dirname(fp))
        done += 1
        if progress and (done % 20 == 0 or done == total):
            try:
                progress(done, total, fp)
            except Exception:
                progress = None
    # 文件清完，把空目录收拾掉
    for p in paths:
        try:
            if os.path.isdir(p):
                _rmtree(p)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            if p not in fail:
                fail.append(p)
    if progress:
        try:
            progress(total, total, "")
        except Exception:
            pass
    return files, size, fail


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0
    return "%.1f GB" % n
