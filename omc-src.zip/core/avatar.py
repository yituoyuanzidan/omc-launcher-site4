# -*- coding: utf-8 -*-
"""账号头像：内置像素头像 + 自己导入图片 + 聊天里用的迷你头像。

存放：
  ~/.simple_mc_launcher/avatars/me/<账号哈希>.png     自己的头像（96×96）
  ~/.simple_mc_launcher/avatars/remote/<名字哈希>.png  别处发过来的（32×32）
一切都在本机，跨设备靠聊天/目录消息里捎带一个 32×32 的小图（base64），
因为公共中转单条消息只有 4KB，只能放这么小。
"""
import base64
import hashlib
import io
import os
import sys

try:
    from PIL import Image, ImageDraw
except Exception:      # 没有 Pillow 时功能降级，不崩
    Image = None
    ImageDraw = None

SIZE = 96
MINI = 32
USER_DIR = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
AV_DIR = os.path.join(USER_DIR, "avatars")
ME_DIR = os.path.join(AV_DIR, "me")
REMOTE_DIR = os.path.join(AV_DIR, "remote")

# 内置头像：编号 -> (背景, 皮肤, 头发, 衣服)
BUILTIN = {
    "b1": ("#4C8BF5", "#F0C8A0", "#3B2A1E", "#2E5B45"),
    "b2": ("#8E6BE0", "#F0C8A0", "#6B3F1D", "#3A3F55"),
    "b3": ("#3FB950", "#E8B58C", "#12100E", "#5A3A2A"),
    "b4": ("#F2A03D", "#F6D2B0", "#A0522D", "#2B3A55"),
    "b5": ("#E5526B", "#D79A6E", "#20160F", "#4A2E5A"),
    "b6": ("#2FC4C4", "#FFE0C2", "#C0392B", "#1F2A33"),
    "b7": ("#B9C43A", "#C98B5E", "#2F2A26", "#452B33"),
    "b8": ("#7A8593", "#EFD3B8", "#5E4B8B", "#26303A"),
}


def _ensure():
    for d in (AV_DIR, ME_DIR, REMOTE_DIR):
        os.makedirs(d, exist_ok=True)


def _key(name):
    return hashlib.md5((name or "").strip().lower().encode("utf-8")).hexdigest()[:16]


def _draw_builtin(bid):
    bg, skin, hair, cloth = BUILTIN.get(bid, BUILTIN["b1"])
    img = Image.new("RGB", (16, 16), bg)
    d = ImageDraw.Draw(img)
    # 肩膀
    d.rectangle([2, 12, 13, 15], fill=cloth)
    d.rectangle([6, 11, 9, 12], fill=skin)
    # 脸
    d.rectangle([4, 3, 11, 11], fill=skin)
    # 头发（上沿 + 两侧）
    d.rectangle([4, 2, 11, 4], fill=hair)
    d.rectangle([3, 3, 4, 7], fill=hair)
    d.rectangle([11, 3, 12, 7], fill=hair)
    # 眼睛
    d.point([(6, 6)], fill="#20242C")
    d.point([(9, 6)], fill="#20242C")
    image = img.resize((SIZE, SIZE), Image.NEAREST)
    return image


def builtin_ids():
    return list(BUILTIN.keys())


def builtin_image(bid):
    return _draw_builtin(bid)


def me_path(name):
    return os.path.join(ME_DIR, _key(name) + ".png")


def remote_path(name):
    return os.path.join(REMOTE_DIR, _key(name) + ".png")


def has_avatar(name):
    return bool(name) and os.path.isfile(me_path(name))


def save_builtin(name, bid):
    """把自己头像设成某个内置头像。"""
    if Image is None:
        return False
    _ensure()
    img = _draw_builtin(bid)
    img.save(me_path(name), "PNG")
    return True


def save_from_file(name, src):
    """导入一张本地图片当头像：居中裁成正方形，缩到 96×96。"""
    if Image is None:
        return False, "缺少 Pillow，不能导入图片"
    try:
        img = Image.open(src).convert("RGB")
    except Exception as e:
        return False, "打不开这张图：%s" % e
    w, h = img.size
    side = min(w, h)
    img = img.crop(((w - side) // 2, (h - side) // 2,
                    (w - side) // 2 + side, (h - side) // 2 + side))
    img = img.resize((SIZE, SIZE), Image.LANCZOS)
    _ensure()
    img.save(me_path(name), "PNG")
    return True, ""


def clear(name):
    try:
        if os.path.isfile(me_path(name)):
            os.remove(me_path(name))
    except Exception:
        pass


def lookup(name):
    """本地能找到的头像路径：先自己的，再别人发来的。找不到返回空串。"""
    for p in (me_path(name), remote_path(name)):
        if name and os.path.isfile(p):
            return p
    return ""


def mini_b64(name):
    """把头像压成 32×32，返回 base64 字符串；给别人捎带用。"""
    p = lookup(name)
    if not p or Image is None:
        return ""
    try:
        img = Image.open(p)
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGBA")
            bg = Image.new("RGB", img.size, "#FFFFFF")
            bg.paste(img, mask=img.split()[-1])
            img = bg
        else:
            img = img.convert("RGB")
        img = img.resize((MINI, MINI), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=62)
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return ""


def save_remote(name, b64):
    """收到别人捎带的头像，缓存到本地。"""
    if not name or not b64 or Image is None:
        return False
    try:
        raw = base64.b64decode(b64.encode("ascii"))
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        img = img.resize((MINI, MINI), Image.LANCZOS)
        _ensure()
        img.save(remote_path(name), "PNG")
        return True
    except Exception:
        return False


def default_color(name):
    """没有头像时，用名字算一个稳定的底色画圆。"""
    h = hashlib.md5((name or "?").strip().lower().encode("utf-8")).hexdigest()
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


# ---------------------------------------------------------------- 头像包
# assets/avatars/<分类>/gNN.png：男生 / 女生 / 二次元 / 动漫 / 可爱
# 来源是开源头像引擎 DiceBear（MIT 许可、无水印），文件随包分发，离线可用。
PACK_ORDER = ("男生", "女生", "二次元", "动漫", "可爱")


def assets_dir():
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "assets")


def pack_dir():
    return os.path.join(assets_dir(), "avatars")


def pack_categories():
    """[(分类, [png 绝对路径, ...]), ...]，按固定顺序，缺目录就跳过。"""
    root = pack_dir()
    out = []
    if not os.path.isdir(root):
        return out
    names = list(PACK_ORDER)
    try:
        for n in sorted(os.listdir(root)):
            d = os.path.join(root, n)
            if os.path.isdir(d) and n not in names:
                names.append(n)
    except Exception:
        pass
    for cat in names:
        d = os.path.join(root, cat)
        if not os.path.isdir(d):
            continue
        fs = [os.path.join(d, f) for f in sorted(os.listdir(d))
              if f.lower().endswith(".png")
              and os.path.getsize(os.path.join(d, f)) > 1000]
        if fs:
            out.append((cat, fs))
    return out


def save_pack(name, src):
    """把头像包里的一张图设成自己的头像（保留透明圆角）。"""
    if Image is None:
        return False
    try:
        img = Image.open(src)
        if img.mode not in ("RGBA", "RGB"):
            img = img.convert("RGBA")
        img = img.resize((SIZE, SIZE), Image.LANCZOS)
        _ensure()
        img.save(me_path(name), "PNG")
        return True
    except Exception:
        return False


def initial(name):
    s = (name or "?").strip()
    return s[0].upper() if s else "?"
