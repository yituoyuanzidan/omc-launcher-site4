# -*- coding: utf-8 -*-
"""模组加载器：Fabric / Quilt / Forge / NeoForge 的版本列表与安装。"""
import os
import re
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET

from . import http, platform_utils
from .version_json import json_path

FABRIC_META = ["https://meta.fabricmc.net",
               "https://bmclapi2.bangbang93.com/fabric-meta"]
QUILT_META = ["https://meta.quiltmc.org"]

# Forge 官方 maven 经常超时，BMCL 镜像同路径放在后面兜底
FORGE_MAVEN = ["https://maven.minecraftforge.net",
               "https://bmclapi2.bangbang93.com/maven"]
NEOFORGE_MAVEN = ["https://maven.neoforged.net/releases",
                  "https://bmclapi2.bangbang93.com/maven"]

LOADERS = ("fabric", "quilt", "forge", "neoforge")

LABELS = {"fabric": "Fabric", "quilt": "Quilt",
          "forge": "Forge", "neoforge": "NeoForge"}


def _first(base_list, path, mirror, timeout=30):
    last = None
    for base in base_list:
        try:
            return http.fetch_json(base + path, mirror, timeout=timeout)
        except Exception as e:
            last = e
    raise last if last else RuntimeError("无法访问元数据服务")


# ---------- Fabric / Quilt ----------
def meta_loaders(kind, mc, mirror="official"):
    if kind == "fabric":
        raw = _first(FABRIC_META, "/v2/versions/loader/%s" % mc, mirror)
        versions = [d.get("loader", {}).get("version") for d in raw]
        stable = [d.get("loader", {}).get("version") for d in raw
                  if d.get("loader", {}).get("stable")]
    else:
        raw = _first(QUILT_META, "/v3/versions/loader/%s" % mc, mirror)
        versions = [d.get("loader", {}).get("version") for d in raw]
        stable = []
    versions = [v for v in versions if v]
    return versions, stable


def _maven_path(maven_name):
    parts = maven_name.split(":")
    if len(parts) != 3:
        return None
    group, artifact, version = parts
    return "%s/%s/%s/%s-%s.jar" % (group.replace(".", "/"), artifact,
                                   version, artifact, version)


class _Reporter(object):
    """把「下载了多少字节 / 一共多少 / 现在多快」算出来，喂给界面上的进度条。

    以前这里只回传「第几个文件 / 一共几个文件」，界面上既看不出还剩多久，
    也不知道是不是卡死了（文件少的时候一直 1/3、2/3 跳）。改成字节之后
    百分比是真的，速度也能实时算出来。
    """

    def __init__(self, progress, total_bytes, allow_single=False):
        self.progress = progress or (lambda *a: None)
        self.total = max(0, int(total_bytes or 0))
        self.known = self.total > 0        # 总量未知时不假装有百分比
        # 只有一个文件要下（比如安装器 jar）时，这个文件的大小就是总量
        self.allow_single = bool(allow_single) and not self.known
        self.base = 0
        self.done = 0
        self.speed = 0.0
        self._t = time.time()
        self._b = 0
        self._last_emit = 0.0

    def start_file(self, base):
        self.base = int(base or 0)
        if self.done < self.base:
            self.done = self.base
        self._emit(force=True)

    def __call__(self, received, total):
        self.done = self.base + int(received or 0)
        if self.allow_single and not self.known:
            t = int(total or 0)
            if t > 0:                       # 单文件：Content-Length 就是总量
                self.total = t
                self.known = True
                self.allow_single = False
        now = time.time()
        dt = now - self._t
        if dt >= 0.5:                       # 半秒一算，太快了数字乱跳
            self.speed = max(0.0, (self.done - self._b) / dt)
            self._t = now
            self._b = self.done
        # 同一个文件里刷得太密会拖慢界面，200ms 一次足够
        if now - self._last_emit >= 0.2:
            self._emit()

    def _emit(self, force=False):
        self._last_emit = time.time()
        try:
            if self.known:
                self.progress(min(self.done, self.total), self.total, self.speed)
            else:
                self.progress(self.done, 0, self.speed)
        except Exception:
            pass

    def finish(self):
        if self.known:
            self.done = self.total
        self.speed = 0.0
        self._emit(force=True)


def _fmt_size(n):
    n = float(n or 0)
    if n >= 1024 * 1024 * 1024:
        return "%.1f GB" % (n / 1073741824.0)
    if n >= 1024 * 1024:
        return "%.1f MB" % (n / 1048576.0)
    if n >= 1024:
        return "%.0f KB" % (n / 1024.0)
    return "%d B" % int(n)


def format_speed(bps):
    """给界面用的一行速度文本。"""
    return (_fmt_size(bps) + "/s") if bps and bps > 0 else ""


def _lib_parts(lib):
    """从一个 library 条目拆出（名字, 相对路径, 下载地址, 声明大小, sha1）。"""
    name = lib.get("name") or ""
    art = (lib.get("downloads") or {}).get("artifact") or {}
    path = art.get("path") or _maven_path(name)
    url = art.get("url")
    if path and not url:
        base_url = lib.get("url") or "https://maven.fabricmc.net/"
        if not base_url.endswith("/"):
            base_url += "/"
        url = base_url + path
    return name, path, url, int(art.get("size") or 0), art.get("sha1")


def _probe_lib_sizes(parts, game_dir, mirror):
    """Fabric 的 profile 根本不写 size，总量得自己探 Content-Length。

    不探也能下，只是进度条只能显示「已下载多少」，看不到百分比。
    探不到就放过，不影响下载本身。
    """
    from concurrent.futures import ThreadPoolExecutor
    todo = []
    for p in parts:
        name, path, url, size, _sha = p
        if size or not (path and url):
            continue
        dest = os.path.join(game_dir, "libraries", path.replace("/", os.sep))
        if os.path.isfile(dest) and os.path.getsize(dest) > 0:
            continue                        # 已在本地，不用探
        todo.append(url)
    if not todo:
        return {}

    def one(url):
        try:
            cands = http._candidates(url, mirror) or [url]
            _final, total, _r = http._probe(cands[0], 10)
            return url, int(total or 0)
        except Exception:
            return url, 0

    with ThreadPoolExecutor(max_workers=6) as ex:
        got = list(ex.map(one, todo))
    return dict(got)


def _download_profile_libraries(profile, game_dir, log, progress, mirror):
    libs = profile.get("libraries") or []
    parts = [_lib_parts(lib) for lib in libs]
    probed = _probe_lib_sizes(parts, game_dir, mirror)
    sizes = [p[3] or probed.get(p[2] or "", 0) for p in parts]
    total = sum(sizes)
    if total > 0:
        log("要下载的库一共 %s" % _fmt_size(total))
    rep = _Reporter(progress, total)
    base = 0
    for (name, path, url, _size, sha1), size in zip(parts, sizes):
        if not path:
            base += size
            rep.start_file(base)
            continue
        dest = os.path.join(game_dir, "libraries", path.replace("/", os.sep))
        # 已经下过的库直接跳过：装第二个整合包时不用再等一遍
        if os.path.isfile(dest) and os.path.getsize(dest) > 0:
            log("已在本地，跳过：%s" % name)
            base += size
            rep.start_file(base)
            continue
        rep.start_file(base)
        log("下载库：%s（%s）" % (name, _fmt_size(size) if size else "大小未知"))
        try:
            http.download_file(url, dest, mirror, sha1=sha1, progress=rep)
        except Exception as e:
            log("下载加载器库失败 %s：%s" % (name, e))
        base += size
    rep.finish()


def install_meta_loader(kind, mc, loader, game_dir, log, progress, mirror="official"):
    if kind == "fabric":
        profile = _first(FABRIC_META,
                         "/v2/versions/loader/%s/%s/profile/json" % (mc, loader), mirror)
    else:
        profile = _first(QUILT_META,
                         "/v3/versions/loader/%s/%s/profile/json" % (mc, loader), mirror)

    vid = profile["id"]
    dest_dir = os.path.join(game_dir, "versions", vid)
    os.makedirs(dest_dir, exist_ok=True)
    with open(json_path(game_dir, vid), "w", encoding="utf-8") as f:
        import json
        json.dump(profile, f, ensure_ascii=False, indent=2)

    log("正在下载 %s %s 的库文件..." % (LABELS[kind], loader))
    _download_profile_libraries(profile, game_dir, log, progress, mirror)
    return vid


# ---------- Forge / NeoForge ----------
def _maven_versions(base_list, path, mirror, retries=2):
    """逐个 maven 源尝试，带重试，返回全部版本号。"""
    last = None
    for base in base_list:
        url = base + path
        for attempt in range(retries + 1):
            try:
                body = http.fetch_text(url, mirror, timeout=45)
                root = ET.fromstring(body)
                return [v.text for v in root.iter("version") if v.text]
            except Exception as e:
                last = e
                time.sleep(1 + attempt)
    raise last if last else RuntimeError("无法获取版本元数据")


def forge_versions(mc, mirror="official"):
    allv = _maven_versions(FORGE_MAVEN,
                           "/net/minecraftforge/forge/maven-metadata.xml", mirror)
    prefix = mc + "-"
    vers = [v[len(prefix):] for v in allv if v.startswith(prefix)]
    return vers, vers[-1:]  # 最后一个当作推荐版


def neoforge_versions(mc, mirror="official"):
    allv = _maven_versions(NEOFORGE_MAVEN,
                           "/net/neoforged/neoforge/maven-metadata.xml", mirror)
    # NeoForge 版本号形如 21.11.0-beta / 21.11.0，需按 MC 版本换算前缀
    mm = re.match(r"1\.(\d+)\.?(\d*)", mc)
    if not mm:
        return [], []
    minor = mm.group(1)
    patch = mm.group(2) or "0"
    prefix = "%s.%s." % (minor, patch)
    vers = [v for v in allv if v.startswith(prefix)]
    return vers, vers[-1:]


def _ensure_launcher_profiles(game_dir):
    path = os.path.join(game_dir, "launcher_profiles.json")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write('{"profiles":{},"settings":{"enableSnapshots":false},'
                    '"version":2}')


def _run_installer(installer_jar, game_dir, java_path, log):
    cmd = [java_path, "-jar", installer_jar, "--installClient", game_dir]
    log("运行安装器：%s" % os.path.basename(installer_jar))
    flags = platform_utils.no_window_flags()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900,
                          cwd=game_dir, creationflags=flags)
    out = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, out


def install_forge(mc, ver, game_dir, java_path, log, progress, mirror="official"):
    path = "/net/minecraftforge/forge/%s-%s/forge-%s-%s-installer.jar" % (
        mc, ver, mc, ver)
    jar_name = "forge-%s-%s-installer.jar" % (mc, ver)
    return _install_with_jar(FORGE_MAVEN, path, jar_name, mc, game_dir,
                             java_path, log, progress, mirror)


def install_neoforge(mc, ver, game_dir, java_path, log, progress, mirror="official"):
    path = "/net/neoforged/neoforge/%s/neoforge-%s-installer.jar" % (ver, ver)
    jar_name = "neoforge-%s-installer.jar" % ver
    return _install_with_jar(NEOFORGE_MAVEN, path, jar_name, mc, game_dir,
                             java_path, log, progress, mirror)


def _install_with_jar(base_list, path, jar_name, mc, game_dir, java_path,
                      log, progress, mirror):
    tmp = os.path.join(tempfile.gettempdir(), jar_name)
    log("下载安装器...")
    # 安装器 jar 本身能拿到字节进度；之后跑 Java 安装器那一段没法逐字节统计，
    # 所以先用「不确定」状态（0/0）告诉界面别盯百分比。
    rep = _Reporter(progress, 0, allow_single=True)
    last = None
    for base in base_list:
        try:
            http.download_file(base + path, tmp, mirror, progress=rep)
            last = None
            break
        except Exception as e:
            last = e
    if last:
        raise last
    _ensure_launcher_profiles(game_dir)
    # 接下来交给 Java 安装器自己下载：字节进度到此为止，界面切成「不确定」
    try:
        progress(0, 0, 0.0)
    except Exception:
        pass

    before = set(os.listdir(os.path.join(game_dir, "versions")))
    code, out = _run_installer(tmp, game_dir, java_path, log)
    after = set(os.listdir(os.path.join(game_dir, "versions")))
    new_dirs = [d for d in (after - before)
                if os.path.isdir(os.path.join(game_dir, "versions", d))]

    if code != 0:
        tail = "\n".join(out.strip().splitlines()[-6:])
        raise RuntimeError("安装器返回 %s：%s" % (code, tail))

    # 新版安装器常常不新增目录而是原地生成，按命名规则兜底
    candidates = new_dirs or [d for d in after
                              if d.lower().startswith(mc.lower())]
    if not candidates:
        raise RuntimeError("安装器没有生成版本目录，日志：%s" % out.strip()[-300:])
    vid = sorted(candidates)[-1]
    log("安装完成：%s" % vid)
    return vid


def list_versions(kind, mc, mirror="official"):
    """返回 (全部版本列表, 推荐版本列表)。"""
    if kind in ("fabric", "quilt"):
        return meta_loaders(kind, mc, mirror)
    if kind == "forge":
        return forge_versions(mc, mirror)
    if kind == "neoforge":
        return neoforge_versions(mc, mirror)
    return [], []


def install(kind, mc, ver, game_dir, java_path, log, progress, mirror="official"):
    if kind in ("fabric", "quilt"):
        return install_meta_loader(kind, mc, ver, game_dir, log, progress, mirror)
    if kind == "forge":
        return install_forge(mc, ver, game_dir, java_path, log, progress, mirror)
    if kind == "neoforge":
        return install_neoforge(mc, ver, game_dir, java_path, log, progress, mirror)
    raise RuntimeError("不支持的加载器：%s" % kind)
