# -*- coding: utf-8 -*-
"""模组加载器：Fabric / Quilt / Forge / NeoForge 的版本列表与安装。"""
import os
import re
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET

from . import http, platform_utils
from .version_json import json_path

FABRIC_META = ["https://meta.fabricmc.net",
               "https://bmclapi2.bangbang93.com/fabric-meta"]
QUILT_META = ["https://meta.quiltmc.org"]

# Forge 官方 maven 经常超时，BMCL 镜像同路径放在后面兜底
FORGE_MAVEN = ["https://maven.minecraftforge.net",
               "https://bmclapi2.bangbang93.com/maven"]
NEOFORGE_MAVEN = ["https://maven.neoforged.net/releases",
                  "https://bmclapi2.bangbang93.com/maven"]

LOADERS = ("fabric", "quilt", "forge", "neoforge")

LABELS = {"fabric": "Fabric", "quilt": "Quilt",
          "forge": "Forge", "neoforge": "NeoForge"}


def _first(base_list, path, mirror, timeout=30):
    last = None
    for base in base_list:
        try:
            return http.fetch_json(base + path, mirror, timeout=timeout)
        except Exception as e:
            last = e
    raise last if last else RuntimeError("无法访问元数据服务")


# ---------- Fabric / Quilt ----------
def meta_loaders(kind, mc, mirror="official"):
    if kind == "fabric":
        raw = _first(FABRIC_META, "/v2/versions/loader/%s" % mc, mirror)
        versions = [d.get("loader", {}).get("version") for d in raw]
        stable = [d.get("loader", {}).get("version") for d in raw
                  if d.get("loader", {}).get("stable")]
    else:
        raw = _first(QUILT_META, "/v3/versions/loader/%s" % mc, mirror)
        versions = [d.get("loader", {}).get("version") for d in raw]
        stable = []
    versions = [v for v in versions if v]
    return versions, stable


def _maven_path(maven_name):
    parts = maven_name.split(":")
    if len(parts) != 3:
        return None
    group, artifact, version = parts
    return "%s/%s/%s/%s-%s.jar" % (group.replace(".", "/"), artifact,
                                   version, artifact, version)


def _download_profile_libraries(profile, game_dir, log, progress, mirror):
    libs = profile.get("libraries") or []
    total = len(libs)
    for i, lib in enumerate(libs, 1):
        name = lib.get("name") or ""
        path = (lib.get("downloads") or {}).get("artifact", {}).get("path") \
            or _maven_path(name)
        if not path:
            progress(i, total)
            continue
        dest = os.path.join(game_dir, "libraries", path.replace("/", os.sep))
        url = (lib.get("downloads") or {}).get("artifact", {}).get("url")
        if not url:
            base = lib.get("url") or "https://maven.fabricmc.net/"
            if not base.endswith("/"):
                base += "/"
            url = base + path
        sha1 = (lib.get("downloads") or {}).get("artifact", {}).get("sha1")
        try:
            http.download_file(url, dest, mirror, sha1=sha1)
        except Exception as e:
            log("下载加载器库失败 %s：%s" % (name, e))
        progress(i, total)


def install_meta_loader(kind, mc, loader, game_dir, log, progress, mirror="official"):
    if kind == "fabric":
        profile = _first(FABRIC_META,
                         "/v2/versions/loader/%s/%s/profile/json" % (mc, loader), mirror)
    else:
        profile = _first(QUILT_META,
                         "/v3/versions/loader/%s/%s/profile/json" % (mc, loader), mirror)

    vid = profile["id"]
    dest_dir = os.path.join(game_dir, "versions", vid)
    os.makedirs(dest_dir, exist_ok=True)
    with open(json_path(game_dir, vid), "w", encoding="utf-8") as f:
        import json
        json.dump(profile, f, ensure_ascii=False, indent=2)

    log("正在下载 %s %s 的库文件..." % (LABELS[kind], loader))
    _download_profile_libraries(profile, game_dir, log, progress, mirror)
    return vid


# ---------- Forge / NeoForge ----------
def _maven_versions(base_list, path, mirror, retries=2):
    """逐个 maven 源尝试，带重试，返回全部版本号。"""
    last = None
    for base in base_list:
        url = base + path
        for attempt in range(retries + 1):
            try:
                body = http.fetch_text(url, mirror, timeout=45)
                root = ET.fromstring(body)
                return [v.text for v in root.iter("version") if v.text]
            except Exception as e:
                last = e
                time.sleep(1 + attempt)
    raise last if last else RuntimeError("无法获取版本元数据")


def forge_versions(mc, mirror="official"):
    allv = _maven_versions(FORGE_MAVEN,
                           "/net/minecraftforge/forge/maven-metadata.xml", mirror)
    prefix = mc + "-"
    vers = [v[len(prefix):] for v in allv if v.startswith(prefix)]
    return vers, vers[-1:]  # 最后一个当作推荐版


def neoforge_versions(mc, mirror="official"):
    allv = _maven_versions(NEOFORGE_MAVEN,
                           "/net/neoforged/neoforge/maven-metadata.xml", mirror)
    # NeoForge 版本号形如 21.11.0-beta / 21.11.0，需按 MC 版本换算前缀
    mm = re.match(r"1\.(\d+)\.?(\d*)", mc)
    if not mm:
        return [], []
    minor = mm.group(1)
    patch = mm.group(2) or "0"
    prefix = "%s.%s." % (minor, patch)
    vers = [v for v in allv if v.startswith(prefix)]
    return vers, vers[-1:]


def _ensure_launcher_profiles(game_dir):
    path = os.path.join(game_dir, "launcher_profiles.json")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write('{"profiles":{},"settings":{"enableSnapshots":false},'
                    '"version":2}')


def _run_installer(installer_jar, game_dir, java_path, log):
    cmd = [java_path, "-jar", installer_jar, "--installClient", game_dir]
    log("运行安装器：%s" % os.path.basename(installer_jar))
    flags = platform_utils.no_window_flags()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900,
                          cwd=game_dir, creationflags=flags)
    out = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, out


def install_forge(mc, ver, game_dir, java_path, log, progress, mirror="official"):
    path = "/net/minecraftforge/forge/%s-%s/forge-%s-%s-installer.jar" % (
        mc, ver, mc, ver)
    jar_name = "forge-%s-%s-installer.jar" % (mc, ver)
    return _install_with_jar(FORGE_MAVEN, path, jar_name, mc, game_dir,
                             java_path, log, progress, mirror)


def install_neoforge(mc, ver, game_dir, java_path, log, progress, mirror="official"):
    path = "/net/neoforged/neoforge/%s/neoforge-%s-installer.jar" % (ver, ver)
    jar_name = "neoforge-%s-installer.jar" % ver
    return _install_with_jar(NEOFORGE_MAVEN, path, jar_name, mc, game_dir,
                             java_path, log, progress, mirror)


def _install_with_jar(base_list, path, jar_name, mc, game_dir, java_path,
                      log, progress, mirror):
    tmp = os.path.join(tempfile.gettempdir(), jar_name)
    log("下载安装器...")
    last = None
    for base in base_list:
        try:
            http.download_file(base + path, tmp, mirror)
            last = None
            break
        except Exception as e:
            last = e
    if last:
        raise last
    _ensure_launcher_profiles(game_dir)

    before = set(os.listdir(os.path.join(game_dir, "versions")))
    code, out = _run_installer(tmp, game_dir, java_path, log)
    after = set(os.listdir(os.path.join(game_dir, "versions")))
    new_dirs = [d for d in (after - before)
                if os.path.isdir(os.path.join(game_dir, "versions", d))]

    if code != 0:
        tail = "\n".join(out.strip().splitlines()[-6:])
        raise RuntimeError("安装器返回 %s：%s" % (code, tail))

    # 新版安装器常常不新增目录而是原地生成，按命名规则兜底
    candidates = new_dirs or [d for d in after
                              if d.lower().startswith(mc.lower())]
    if not candidates:
        raise RuntimeError("安装器没有生成版本目录，日志：%s" % out.strip()[-300:])
    vid = sorted(candidates)[-1]
    log("安装完成：%s" % vid)
    return vid


def list_versions(kind, mc, mirror="official"):
    """返回 (全部版本列表, 推荐版本列表)。"""
    if kind in ("fabric", "quilt"):
        return meta_loaders(kind, mc, mirror)
    if kind == "forge":
        return forge_versions(mc, mirror)
    if kind == "neoforge":
        return neoforge_versions(mc, mirror)
    return [], []


def install(kind, mc, ver, game_dir, java_path, log, progress, mirror="official"):
    if kind in ("fabric", "quilt"):
        return install_meta_loader(kind, mc, ver, game_dir, log, progress, mirror)
    if kind == "forge":
        return install_forge(mc, ver, game_dir, java_path, log, progress, mirror)
    if kind == "neoforge":
        return install_neoforge(mc, ver, game_dir, java_path, log, progress, mirror)
    raise RuntimeError("不支持的加载器：%s" % kind)
