# -*- coding: utf-8 -*-
"""下载新版本并把当前安装替换掉，然后自动重启。

Windows 上运行中的 exe 不能覆盖自己，所以写一个 ps1：
等本进程退出 -> 把新文件复制进安装目录 -> 重新启动。
macOS 的 .app 结构不适合这样替换，只做下载提示（不冒险）。
"""
import os
import subprocess
import sys
import tempfile
import time
import zipfile

from . import http, platform_utils

APP_EXE = "OMC.exe"
APP_BIN = "OMC"

_NO_WIN = 0x08000000   # CREATE_NO_WINDOW
_DETACH = 0x00000008   # DETACHED_PROCESS


def install_dir():
    """打包后的安装目录；源码运行返回空。"""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return ""


def can_auto_update():
    """能不能自己替换自己（源码运行 / macOS 都不行）。"""
    if not install_dir():
        return False
    if platform_utils.MACOS:
        return False
    return True


def _payload_dir(root):
    """在解压结果里找到放着主程序的那一层。"""
    for cur, _dirs, files in os.walk(root):
        if APP_EXE in files or APP_BIN in files:
            return cur
    return ""


def download_package(url, log=None, progress=None, stage=None):
    """下载更新包并解压，返回 (payload_dir, work_dir)。

    stage(name, pct)：阶段进度，name 是「下载 / 校验 / 解压」，pct 是 0-100。
    progress(cur, total)：字节级进度，只覆盖下载阶段。
    """
    log = log or (lambda _m: None)
    stage = stage or (lambda _n, _p: None)
    if not url:
        raise RuntimeError("更新清单里没有下载地址")
    work = os.path.join(tempfile.gettempdir(),
                        "omc_update_%d" % int(time.time()))
    os.makedirs(work, exist_ok=True)
    zip_path = os.path.join(work, "update.zip")
    log("正在下载新版本......")

    def on_prog(cur, tot):
        if progress:
            progress(cur, tot)
        if tot:
            stage("下载", int(cur * 100 / tot))

    stage("下载", 0)
    try:
        # 60MB+ 的包单连接常常只有几十 KB/s，先开 6 路分块并行
        http.download_file_multi(url, zip_path, mirror="official",
                                 progress=on_prog, parts=6, timeout=60,
                                 retries=2)
    except Exception as e:
        log("分块下载没成（%s），改单连接继续" % e)
        http.download_file(url, zip_path, mirror="official", progress=on_prog,
                           retries=3, timeout=300)
    if not zipfile.is_zipfile(zip_path):
        raise RuntimeError("更新包不是有效的 zip")
    # 大小对不上就是不完整，早点发现别等解压出一半才崩
    try:
        expect = os.path.getsize(zip_path)
    except OSError:
        expect = 0
    if expect and expect < (1 << 20):
        raise RuntimeError("更新包太小（%d 字节），不像完整包" % expect)

    payload = os.path.join(work, "payload")
    os.makedirs(payload, exist_ok=True)
    stage("校验", 0)
    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError("更新包损坏：" + str(bad))
        stage("校验", 100)
        members = zf.infolist()
        total_m = len(members) or 1
        step = max(1, total_m // 40)      # 最多回 40 次，别把界面刷爆
        stage("解压", 0)
        for i, m in enumerate(members, 1):
            zf.extract(m, payload)
            if i % step == 0 or i == total_m:
                stage("解压", int(i * 100 / total_m))
    inner = _payload_dir(payload)
    if not inner:
        raise RuntimeError("更新包里没找到主程序")
    log("新版本已解压好：%s" % inner)
    return inner, work


def schedule_update(payload_dir, target_dir=None):
    """安排“退出后替换并重启”。返回 True 表示已排好。"""
    target = target_dir or install_dir()
    if not target or not os.path.isdir(target):
        raise RuntimeError("当前不是打包版，无法自动替换")
    if platform_utils.MACOS:
        raise RuntimeError("macOS 请手动把新的 OMC.app 拖进应用程序目录")
    if platform_utils.WINDOWS:
        return _schedule_windows(payload_dir, target)
    return _schedule_posix(payload_dir, target)


def _schedule_windows(payload_dir, target):
    script = os.path.join(os.path.dirname(payload_dir), "omc_update.ps1")
    log_path = os.path.join(target, "update_log.txt")
    prog_path = os.path.join(target, "omc_update_progress.txt")
    timing_path = os.path.join(target, "update_timing.txt")
    pid = os.getpid()
    body = (
        "$ErrorActionPreference='Continue'\r\n"
        "$t0=Get-Date\r\n"
        "$src='{src}'\r\n"
        "$dst='{dst}'\r\n"
        "$log='{log}'\r\n"
        "$prog='{prog}'\r\n"
        "function W($m){{ ('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $m) "
        "| Out-File -FilePath $log -Append -Encoding utf8 }}\r\n"
        "function P($st,$pc){{ ($st + '|' + $pc) "
        "| Out-File -FilePath $prog -Encoding utf8 }}\r\n"
        "P '等待退出' 2\r\n"
        "W '更新脚本启动，等待旧进程退出'\r\n"
        # 100ms 一轮，退出即可接手，不再固定干等
        "for($i=0;$i -lt 300;$i++){{\r\n"
        "  if(-not (Get-Process -Id {pid} -ErrorAction SilentlyContinue)){{break}}\r\n"
        "  Start-Sleep -Milliseconds 100\r\n"
        "}}\r\n"
        "Start-Sleep -Milliseconds 120\r\n"
        "P '替换文件' 10\r\n"
        "W '旧进程已退出，开始替换文件'\r\n"
        # 进程退出后 exe 句柄可能还没释放，先确认能独占打开再复制
        "$locked=$true\r\n"
        "$targetExe = Join-Path $dst '{exe}'\r\n"
        "if(-not (Test-Path $targetExe)){{ $locked=$false }}\r\n"
        "for($j=0;$j -lt 20;$j++){{\r\n"
        "  if($locked){{ try {{\r\n"
        "    $fs=[System.IO.File]::Open($targetExe,'Open','ReadWrite','None')\r\n"
        "    $fs.Close(); $locked=$false; break\r\n"
        "  }} catch {{ Start-Sleep -Milliseconds 150 }} }} else {{ break }}\r\n"
        "}}\r\n"
        "if($locked){{ W '主程序仍被占用，仍继续尝试替换' }}\r\n"
        "P '替换文件' 30\r\n"
        "$ok=$false\r\n"
        "for($r=0;$r -lt 3;$r++){{\r\n"
        "  $out = robocopy $src $dst /E /IS /IT /NFL /NDL /NJH /NJS /R:1 /W:1\r\n"
        "  $code = $LASTEXITCODE\r\n"
        "  W ('robocopy 第' + ($r+1) + ' 次，返回码 ' + $code)\r\n"
        "  if($code -lt 8){{ $ok=$true; break }}\r\n"
        "  if($code -ge 16){{ Start-Sleep -Milliseconds 600 }}\r\n"
        "}}\r\n"
        "if(-not $ok){{ W '替换失败：文件可能仍被占用' }}\r\n"
        "P '替换文件' 85\r\n"
        "$exe = Join-Path $dst '{exe}'\r\n"
        "if(Test-Path $exe){{\r\n"
        "  P '启动' 92\r\n"
        "  $launched=$false\r\n"
        "  for($k=0;$k -lt 3;$k++){{\r\n"
        "    try {{\r\n"
        "      Start-Process -FilePath $exe -WorkingDirectory $dst\r\n"
        "      W ('已启动新版本，第' + ($k+1) + '次尝试')\r\n"
        "      $launched=$true\r\n"
        "      break\r\n"
        "    }} catch {{\r\n"
        "      W ('启动失败：' + $_.Exception.Message)\r\n"
        "      Start-Sleep -Milliseconds 900\r\n"
        "    }}\r\n"
        "  }}\r\n"
        "  if(-not $launched){{ W '三次启动失败，请手动双击 OMC.exe' }}\r\n"
        "}} else {{ W '没找到主程序，无法重启' }}\r\n"
        "P '完成' 100\r\n"
        "$sec = [int]((Get-Date)-$t0).TotalSeconds\r\n"
        "('took=' + $sec) | Out-File -FilePath '{timing}' -Encoding utf8\r\n"
        "W ('替换流程结束，耗时 ' + $sec + ' 秒')\r\n"
        "try {{ Start-Process -FilePath 'ie4uinit.exe' -ArgumentList '-show' "
        "-WindowStyle Hidden }} catch {{ }}\r\n"
    ).format(src=payload_dir.replace("'", "''"),
             dst=target.replace("'", "''"),
             log=log_path.replace("'", "''"),
             prog=prog_path.replace("'", "''"),
             timing=timing_path.replace("'", "''"),
             pid=pid,
             exe=APP_EXE)
    # PowerShell 5.1 读无 BOM 的 UTF-8 会按 ANSI 解析，中文路径必错，所以带 BOM
    with open(script, "w", encoding="utf-8-sig") as f:
        f.write(body)
    _spawn_ps(script)
    return True


def _spawn_ps(script):
    """启动替换脚本。

    只用 CREATE_NO_WINDOW，不加 DETACHED_PROCESS —— 在部分 Windows 上
    两者叠加会让 powershell 直接退不出来（表现为“点了重启没反应/没替换”）。
    子进程独立于父进程，父进程 os._exit 后它照样跑完。
    """
    devnull = open(os.devnull, "wb")
    cmd = ["powershell", "-NoProfile", "-NonInteractive",
           "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
           "-File", script]
    try:
        subprocess.Popen(cmd, creationflags=_NO_WIN, close_fds=True,
                         stdin=devnull, stdout=devnull, stderr=devnull,
                         cwd=os.path.dirname(script))
    finally:
        try:
            devnull.close()
        except Exception:
            pass


def _schedule_posix(payload_dir, target):
    script = os.path.join(os.path.dirname(payload_dir), "omc_update.sh")
    pid = os.getpid()
    body = (
        "#!/bin/sh\n"
        "while kill -0 %d 2>/dev/null; do sleep 0.25; done\n"
        "sleep 0.3\n"
        "cp -a '%s/.' '%s/'\n"
        "'%s/%s' &\n"
    ) % (pid, payload_dir, target, target, APP_BIN)
    with open(script, "w", encoding="utf-8") as f:
        f.write(body)
    os.chmod(script, 0o755)
    subprocess.Popen(["/bin/sh", script], start_new_session=True)
    return True
