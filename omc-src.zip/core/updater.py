# -*- coding: utf-8 -*-
"""下载新版本并把当前安装替换掉，然后自动重启。

Windows 上运行中的 exe 不能覆盖自己，所以写一个 ps1：
等本进程退出 -> 把新文件复制进安装目录 -> 重新启动。
macOS 的 .app 结构不适合这样替换，只做下载提示（不冒险）。
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

from . import http, platform_utils

APP_EXE = "OMC.exe"
APP_BIN = "OMC"
# Win7 老系统包的 exe 叫 OMC-Win7.exe。以前这里写死 OMC.exe，导致老系统版
# 自动更新时「更新包里没找到主程序」/替换完找不到 exe 启动，表现就是
# 「更新完还是旧版本」「更新后重启没反应」。
APP_EXE_ALT = "OMC-Win7.exe"

_NO_WIN = 0x08000000   # CREATE_NO_WINDOW
_DETACH = 0x00000008   # DETACHED_PROCESS

# 替换脚本判定「这次没换成功」时留下的标记，下次启动读它并明说，
# 免得用户以为是自己被反复要求更新。
FAIL_FLAG = "update_failed.flag"
# 排替换前把「这次要换上哪个版本」记下来，下次启动拿它和实际版本比：
# 一样就说明真换上了，不一样就说明这次更新根本没生效（包是旧的、或者
# 文件被占用没替换成功），不能默默再提示一次「有新版本」。
PENDING_FILE = "pending_update.txt"


def exe_name():
    """当前正在跑的主程序文件名（打包后就是安装目录里那个 exe）。"""
    try:
        name = os.path.basename(sys.executable or "")
        if name and name.lower().endswith(".exe") and \
                name.lower() != "python.exe":
            return name
    except Exception:
        pass
    return APP_EXE


def install_dir():
    """打包后的安装目录；源码运行返回空。"""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return ""


def can_auto_update():
    """能不能自己替换自己（源码运行 / macOS 都不行）。"""
    if not install_dir():
        return False
    if platform_utils.MACOS:
        return False
    return True


def _payload_dir(root):
    """在解压结果里找到放着主程序的那一层。"""
    names = {APP_EXE.lower(), APP_EXE_ALT.lower(), APP_BIN.lower(),
             exe_name().lower()}
    for cur, _dirs, files in os.walk(root):
        lower = set(f.lower() for f in files)
        if lower & names:
            return cur
    return ""


def payload_has_version(payload, latest):
    """包里带了 omc_version.txt 就核对版本号；没有这个文件就跳过。

    版本号是编进主程序的字符串常量，但打包后是压缩在 PYZ 里的，不能靠
    二进制扫描判断包是不是最新版。所以真正的兜底是 pending_update.txt：
    排替换前记下目标版本，下次启动用实际版本比对。
    """
    if not latest:
        return True
    p = os.path.join(payload, "omc_version.txt")
    if not os.path.isfile(p):
        return True
    try:
        with open(p, "r", encoding="utf-8") as f:
            v = f.read().strip()
    except Exception:
        return True
    return (not v) or v == str(latest)


def pending_path(target=None):
    d = target or install_dir()
    return os.path.join(d, PENDING_FILE) if d else ""


def set_pending(latest, target=None):
    """排替换前记下「这次要换上哪个版本」。"""
    p = pending_path(target)
    if not p or not latest:
        return False
    try:
        with open(p, "w", encoding="utf-8") as f:
            f.write(str(latest))
        return True
    except Exception:
        return False


def read_pending(target=None):
    p = pending_path(target)
    if not p or not os.path.isfile(p):
        return ""
    try:
        with open(p, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def clear_pending(target=None):
    p = pending_path(target)
    try:
        if p and os.path.isfile(p):
            os.remove(p)
    except Exception:
        pass


def cleanup_workdirs(keep=None):
    """删掉以前更新留下的临时目录：一个包一百多兆，堆几次就是几百兆。"""
    root = tempfile.gettempdir()
    try:
        names = os.listdir(root)
    except Exception:
        return 0
    keep_abs = os.path.abspath(keep) if keep else ""
    n = 0
    for name in names:
        if not name.startswith("omc_update_"):
            continue
        p = os.path.join(root, name)
        if keep_abs and os.path.abspath(p) == keep_abs:
            continue
        try:
            shutil.rmtree(p, ignore_errors=True)
            n += 1
        except Exception:
            pass
    return n


def fail_flag_path(target=None):
    d = target or install_dir()
    return os.path.join(d, FAIL_FLAG) if d else ""


def read_fail_flag(target=None):
    """上次替换失败的记录（版本号）；没有就返回空串。读完即删。"""
    p = fail_flag_path(target)
    if not p or not os.path.isfile(p):
        return ""
    try:
        with open(p, "r", encoding="utf-8") as f:
            info = f.read().strip()
    except Exception:
        info = ""
    try:
        os.remove(p)
    except Exception:
        pass
    return info


def download_package(url, log=None, progress=None, stage=None):
    """下载更新包并解压，返回 (payload_dir, work_dir)。

    stage(name, pct)：阶段进度，name 是「下载 / 校验 / 解压」，pct 是 0-100。
    progress(cur, total)：字节级进度，只覆盖下载阶段。
    """
    log = log or (lambda _m: None)
    stage = stage or (lambda _n, _p: None)
    if not url:
        raise RuntimeError("更新清单里没有下载地址")
    # 先把以前几次更新残留的临时包清掉，再建这次的工作目录
    cleanup_workdirs()
    work = os.path.join(tempfile.gettempdir(),
                        "omc_update_%d" % int(time.time()))
    os.makedirs(work, exist_ok=True)
    zip_path = os.path.join(work, "update.zip")
    log("正在下载新版本......")

    def on_prog(cur, tot):
        if progress:
            progress(cur, tot)
        if tot:
            stage("下载", int(cur * 100 / tot))

    stage("下载", 0)
    try:
        # 60MB+ 的包单连接常常只有几十 KB/s，先开 6 路分块并行
        http.download_file_multi(url, zip_path, mirror="official",
                                 progress=on_prog, parts=6, timeout=60,
                                 retries=2)
    except Exception as e:
        log("分块下载没成（%s），改单连接继续" % e)
        http.download_file(url, zip_path, mirror="official", progress=on_prog,
                           retries=3, timeout=300)
    if not zipfile.is_zipfile(zip_path):
        raise RuntimeError("更新包不是有效的 zip")
    # 大小对不上就是不完整，早点发现别等解压出一半才崩
    try:
        expect = os.path.getsize(zip_path)
    except OSError:
        expect = 0
    if expect and expect < (1 << 20):
        raise RuntimeError("更新包太小（%d 字节），不像完整包" % expect)

    payload = os.path.join(work, "payload")
    os.makedirs(payload, exist_ok=True)
    stage("校验", 0)
    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError("更新包损坏：" + str(bad))
        stage("校验", 100)
        members = zf.infolist()
        total_m = len(members) or 1
        step = max(1, total_m // 40)      # 最多回 40 次，别把界面刷爆
        stage("解压", 0)
        for i, m in enumerate(members, 1):
            zf.extract(m, payload)
            if i % step == 0 or i == total_m:
                stage("解压", int(i * 100 / total_m))
    inner = _payload_dir(payload)
    if not inner:
        raise RuntimeError("更新包里没找到主程序")
    log("新版本已解压好：%s" % inner)
    return inner, work


def schedule_update(payload_dir, target_dir=None, latest=""):
    """安排“退出后替换并重启”。返回 True 表示已排好。

    latest：这次要换上的版本号，先记到 pending_update.txt，下次启动核对
    实际版本用（核对不上就说明这次更新没生效）。
    """
    target = target_dir or install_dir()
    if not target or not os.path.isdir(target):
        raise RuntimeError("当前不是打包版，无法自动替换")
    if platform_utils.MACOS:
        raise RuntimeError("macOS 请手动把新的 OMC.app 拖进应用程序目录")
    set_pending(latest, target)
    if platform_utils.WINDOWS:
        return _schedule_windows(payload_dir, target, latest)
    return _schedule_posix(payload_dir, target)


def _schedule_windows(payload_dir, target, latest=""):
    script = os.path.join(os.path.dirname(payload_dir), "omc_update.ps1")
    log_path = os.path.join(target, "update_log.txt")
    prog_path = os.path.join(target, "omc_update_progress.txt")
    timing_path = os.path.join(target, "update_timing.txt")
    pid = os.getpid()
    body = (
        "$ErrorActionPreference='Continue'\r\n"
        "$t0=Get-Date\r\n"
        "$src='{src}'\r\n"
        "$dst='{dst}'\r\n"
        "$log='{log}'\r\n"
        "$prog='{prog}'\r\n"
        "function W($m){{ ('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $m) "
        "| Out-File -FilePath $log -Append -Encoding utf8 }}\r\n"
        "function P($st,$pc){{ ($st + '|' + $pc) "
        "| Out-File -FilePath $prog -Encoding utf8 }}\r\n"
        "P '等待退出' 2\r\n"
        "W '更新脚本启动，等待旧进程退出'\r\n"
        # 100ms 一轮，退出即可接手，不再固定干等
        "for($i=0;$i -lt 300;$i++){{\r\n"
        "  if(-not (Get-Process -Id {pid} -ErrorAction SilentlyContinue)){{break}}\r\n"
        "  Start-Sleep -Milliseconds 100\r\n"
        "}}\r\n"
        "Start-Sleep -Milliseconds 120\r\n"
        "P '替换文件' 10\r\n"
        "W '旧进程已退出，开始替换文件'\r\n"
        "$dstExe = Join-Path $dst '{exe}'\r\n"
        "$pname = '{pname}'\r\n"
        # 同一安装目录里可能还开着一堆旧实例（实测同时 7 个），它们的 exe 映像
        # 一直锁着文件，robocopy 只会回 11 然后永远复制不过去——这就是
        # 「更新完还是旧版本、下次启动又提示更新」的头号原因。先按路径精确
        # 关掉同一目录的其它实例（别的目录里的 OMC 一律不碰），把占用让出来。
        "function KillOthers {{\r\n"
        "  $n = 0\r\n"
        "  try {{\r\n"
        "    $ps = @(Get-Process -Name $pname -ErrorAction SilentlyContinue)\r\n"
        "    foreach ($pp in $ps) {{\r\n"
        "      if ($pp.Id -eq {pid}) {{ continue }}\r\n"
        "      try {{\r\n"
        "        $ppath = $pp.Path\r\n"
        "        if ($ppath -and ($ppath -ieq $dstExe)) {{\r\n"
        "          Stop-Process -Id $pp.Id -Force\r\n"
        "          $n = $n + 1\r\n"
        "        }}\r\n"
        "      }} catch {{ }}\r\n"
        "    }}\r\n"
        "  }} catch {{ }}\r\n"
        "  return $n\r\n"
        "}}\r\n"
        "$k1 = KillOthers\r\n"
        "if($k1 -gt 0){{ W ('已关掉同目录其它 ' + $k1 + ' 个实例，释放主程序占用') }}\r\n"
        # 进程退出后 exe 句柄可能还没释放，先确认能独占打开再复制；
        # 15 秒内每 5 秒再清一次同类实例，别一上来就判死
        "$locked=$true\r\n"
        "if(-not (Test-Path $dstExe)){{ $locked=$false }}\r\n"
        "for($j=0;$j -lt 30;$j++){{\r\n"
        "  if(-not $locked){{ break }}\r\n"
        "  try {{\r\n"
        "    $fs=[System.IO.File]::Open($dstExe,'Open','ReadWrite','None')\r\n"
        "    $fs.Close(); $locked=$false; break\r\n"
        "  }} catch {{\r\n"
        "    Start-Sleep -Milliseconds 500\r\n"
        "    if($j % 10 -eq 0){{ KillOthers | Out-Null }}\r\n"
        "  }}\r\n"
        "}}\r\n"
        "if($locked){{ W '主程序仍被占用，仍继续尝试替换' }}\r\n"
        "P '替换文件' 30\r\n"
        "$ok=$false\r\n"
        # /R:0 /W:0：被锁的文件立刻失败，重试节奏由我们自己控（原来 /R:1 /W:1
        # 会让一次 robocopy 卡满 60 秒，三次重试就是三分多钟，用户早关了）
        "for($r=0;$r -lt 8;$r++){{\r\n"
        "  $out = robocopy $src $dst /E /IS /IT /NFL /NDL /NJH /NJS /R:0 /W:0\r\n"
        "  $code = $LASTEXITCODE\r\n"
        "  W ('robocopy 第' + ($r+1) + ' 次，返回码 ' + $code)\r\n"
        "  if($code -lt 8){{ $ok=$true; break }}\r\n"
        "  $kx = KillOthers\r\n"
        "  if($kx -gt 0){{ W ('再关掉 ' + $kx + ' 个实例后重试') }}\r\n"
        "  Start-Sleep -Milliseconds 1000\r\n"
        "}}\r\n"
        "if(-not $ok){{ W '替换失败：文件可能仍被占用' }}\r\n"
        "P '替换文件' 85\r\n"
        # 覆盖完再看一眼主程序到底换没换：先比大小，大小一样再比 SHA256。
        # 同版本重打包的 exe 大小可能完全一致，只比大小会把「没换上」判成成功，
        # 于是用户下次启动看到的还是旧版本、又被提示更新一次，像「更新了还要更新」。
        "$newExe = Join-Path $src '{exe}'\r\n"
        "$sizeOk=$false\r\n"
        # 不用 Get-FileHash：实测在这套脚本环境里它并非总能解析到（PSModulePath
        # 不完整时报「无法识别为 cmdlet」），直接用 .NET 算，一定在
        "function HashOf($p) {{\r\n"
        "  $sha = [System.Security.Cryptography.SHA256]::Create()\r\n"
        "  $fs = [System.IO.File]::OpenRead($p)\r\n"
        "  try {{\r\n"
        "    $b = $sha.ComputeHash($fs)\r\n"
        "    return ([BitConverter]::ToString($b) -replace '-', '')\r\n"
        "  }} finally {{ $fs.Dispose(); $sha.Dispose() }}\r\n"
        "}}\r\n"
        "if((Test-Path $newExe) -and (Test-Path $dstExe)){{\r\n"
        "  $nl=(Get-Item $newExe).Length\r\n"
        "  $dl=(Get-Item $dstExe).Length\r\n"
        "  W ('主程序大小：新包 ' + $nl + ' / 现装 ' + $dl)\r\n"
        "  if($nl -eq $dl){{\r\n"
        "    try {{\r\n"
        "      $nh=(HashOf $newExe).Substring(0,12)\r\n"
        "      $dh=(HashOf $dstExe).Substring(0,12)\r\n"
        "      W ('主程序 SHA：新包 ' + $nh + ' / 现装 ' + $dh)\r\n"
        "      if($nh -eq $dh){{ $sizeOk=$true }} else {{ W '大小一致但内容不同，判定没换上' }}\r\n"
        "    }} catch {{ W ('SHA 比对失败，退回按大小判定：' + $_.Exception.Message); $sizeOk=$true }}\r\n"
        "  }}\r\n"
        "}}\r\n"
        "if($ok -and $sizeOk){{\r\n"
        "  W '主程序已替换成功'\r\n"
        "  try {{ Remove-Item '{flag}' -ErrorAction SilentlyContinue }} catch {{ }}\r\n"
        "}} else {{\r\n"
        "  W '替换没完全成功，写标记：下次启动提示手动下载'\r\n"
        "  try {{ ('文件被占用，没换上 {latest}|' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) "
        "| Out-File -FilePath '{flag}' -Encoding utf8 }} catch {{ }}\r\n"
        "}}\r\n"
        "$exe = Join-Path $dst '{exe}'\r\n"
        "if(Test-Path $exe){{\r\n"
        "  P '启动' 92\r\n"
        "  $launched=$false\r\n"
        "  for($k=0;$k -lt 3;$k++){{\r\n"
        "    try {{\r\n"
        "      Start-Process -FilePath $exe -WorkingDirectory $dst\r\n"
        "      W ('已启动新版本，第' + ($k+1) + '次尝试')\r\n"
        "      $launched=$true\r\n"
        "      break\r\n"
        "    }} catch {{\r\n"
        "      W ('启动失败：' + $_.Exception.Message)\r\n"
        "      Start-Sleep -Milliseconds 900\r\n"
        "    }}\r\n"
        "  }}\r\n"
        "  if(-not $launched){{ W '三次启动失败，请手动双击 OMC.exe' }}\r\n"
        "}} else {{ W '没找到主程序，无法重启' }}\r\n"
        "P '完成' 100\r\n"
        "$sec = [int]((Get-Date)-$t0).TotalSeconds\r\n"
        "('took=' + $sec) | Out-File -FilePath '{timing}' -Encoding utf8\r\n"
        "W ('替换流程结束，耗时 ' + $sec + ' 秒')\r\n"
        "try {{ Start-Process -FilePath 'ie4uinit.exe' -ArgumentList '-show' "
        "-WindowStyle Hidden }} catch {{ }}\r\n"
    ).format(src=payload_dir.replace("'", "''"),
             dst=target.replace("'", "''"),
             log=log_path.replace("'", "''"),
             prog=prog_path.replace("'", "''"),
             timing=timing_path.replace("'", "''"),
             flag=os.path.join(target, FAIL_FLAG).replace("'", "''"),
             pid=pid,
             pname=os.path.splitext(exe_name())[0],
             latest=str(latest or "").replace("'", "''"),
             exe=exe_name())
    # PowerShell 5.1 读无 BOM 的 UTF-8 会按 ANSI 解析，中文路径必错，所以带 BOM
    with open(script, "w", encoding="utf-8-sig") as f:
        f.write(body)
    _spawn_ps(script)
    return True


def _spawn_ps(script):
    """启动替换脚本。

    只用 CREATE_NO_WINDOW，不加 DETACHED_PROCESS —— 在部分 Windows 上
    两者叠加会让 powershell 直接退不出来（表现为“点了重启没反应/没替换”）。
    子进程独立于父进程，父进程 os._exit 后它照样跑完。
    """
    devnull = open(os.devnull, "wb")
    cmd = ["powershell", "-NoProfile", "-NonInteractive",
           "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
           "-File", script]
    try:
        subprocess.Popen(cmd, creationflags=_NO_WIN, close_fds=True,
                         stdin=devnull, stdout=devnull, stderr=devnull,
                         cwd=os.path.dirname(script))
    finally:
        try:
            devnull.close()
        except Exception:
            pass


def _schedule_posix(payload_dir, target):
    script = os.path.join(os.path.dirname(payload_dir), "omc_update.sh")
    pid = os.getpid()
    body = (
        "#!/bin/sh\n"
        "while kill -0 %d 2>/dev/null; do sleep 0.25; done\n"
        "sleep 0.3\n"
        "cp -a '%s/.' '%s/'\n"
        "'%s/%s' &\n"
    ) % (pid, payload_dir, target, target, APP_BIN)
    with open(script, "w", encoding="utf-8") as f:
        f.write(body)
    os.chmod(script, 0o755)
    subprocess.Popen(["/bin/sh", script], start_new_session=True)
    return True
