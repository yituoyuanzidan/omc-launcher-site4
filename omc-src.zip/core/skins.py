# -*- coding: utf-8 -*-
"""皮肤库：导入的 PNG 统一存在启动器配置目录，方便下次直接选用。"""
import os
import shutil
import time

from .config import app_dir

PNG_SIG = b"\x89PNG\r\n\x1a\n"


def skins_dir():
    d = os.path.join(app_dir(), "skins")
    os.makedirs(d, exist_ok=True)
    return d


def list_skins():
    d = skins_dir()
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))


def skin_path(name):
    return os.path.join(skins_dir(), name)


def import_skin(path):
    """校验 PNG 后复制进皮肤库，返回库内路径；同名自动加时间戳。"""
    with open(path, "rb") as f:
        if f.read(8) != PNG_SIG:
            raise RuntimeError("不是有效的 PNG 图片")
    base = os.path.basename(path)
    dest = os.path.join(skins_dir(), base)
    if os.path.exists(dest):
        stem, ext = os.path.splitext(base)
        dest = os.path.join(skins_dir(),
                            "%s_%d%s" % (stem, int(time.time()), ext))
    shutil.copy2(path, dest)
    return dest
