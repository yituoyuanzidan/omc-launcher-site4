# -*- coding: utf-8 -*-
"""内存推荐：按物理内存、已装模组数量和游戏版本给一个不易崩档的 -Xmx 值。

原则：留够系统和其他程序的空间，模组越多给得越多，但不超过物理内存的 60%，
并且封顶 12GB（再高对 Java 版收益很小，反而更容易因 GC 卡顿）。
"""
import os


def total_ram_mb():
    """物理内存总量（MB），拿不到返回 0。"""
    # Windows
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return int(stat.ullTotalPhys / 1048576)
    except Exception:
        pass
    # Linux
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    # macOS
    try:
        import subprocess
        out = subprocess.check_output(["sysctl", "-n", "hw.memsize"],
                                      stderr=subprocess.DEVNULL)
        return int(out.strip()) // 1048576
    except Exception:
        pass
    return 0


def mod_count(game_dir):
    d = os.path.join(game_dir, "mods")
    if not os.path.isdir(d):
        return 0
    return len([f for f in os.listdir(d) if f.lower().endswith(".jar")])


def recommend(game_dir, mc_version=""):
    """返回 (建议内存 MB, 说明文字)。"""
    total = total_ram_mb()
    mods = mod_count(game_dir)
    major = 0
    try:
        parts = (mc_version or "").split(".")
        if parts and parts[0].isdigit():
            major = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    except Exception:
        major = 0

    if total and total < 7000:
        base = 2048
    elif total and total < 12000:
        base = 4096
    else:
        base = 4096

    if mods >= 80:
        base = max(base, 8192)
    elif mods >= 40:
        base = max(base, 6144)
    elif mods >= 15:
        base = max(base, 5120)

    # 1.18 之后地形生成吃内存，加一档
    if major >= 18 and base < 6144:
        base = 6144

    if total:
        cap = int(total * 0.6)
        base = min(base, cap)
    base = min(base, 12288)
    base = max(1024, base - (base % 512))

    total_txt = ("%.1f GB" % (total / 1024.0)) if total else "未知"
    reason = ("物理内存 %s，已装模组 %d 个，版本 %s -> 建议 %d MB"
              % (total_txt, mods, mc_version or "未知", base))
    if total and total < 7000:
        reason += "（内存偏小，模组别开太多）"
    return base, reason
