# -*- coding: utf-8 -*-
"""单实例锁：同一个人别把启动器开成一堆。

以前反复双击桌面图标，每点一次就新起一个进程（实测堆到 15 个），它们共用
同一个 AppUserModelID，任务栏把它们合成一个按钮，图标还会被后启动的那个
改写——看着就像图标坏了。这里用一把文件锁挡住第二个实例，并把它要的窗口
（已经开着的那个）提到前面。
"""
import os
import sys


def _lock_path():
    d = os.path.abspath(os.path.expanduser("~/.simple_mc_launcher"))
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        return ""
    return os.path.join(d, "omc.launcher.lock")


def raise_existing():
    """把已经开着的启动器窗口提到前面（跨进程，纯 Win32）。"""
    if not sys.platform.startswith("win"):
        return False
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    found = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(
        wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def _cb(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        title = buf.value or ""
        if "OMC" not in title and "启动器" not in title:
            return True
        pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        h = kernel32.OpenProcess(0x1000, False, pid.value)   # QUERY_LIMITED_INFORMATION
        if not h:
            return True
        try:
            pbuf = ctypes.create_unicode_buffer(1024)
            size = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(h, 0, pbuf, ctypes.byref(size)):
                if os.path.basename(pbuf.value).lower() == "omc.exe":
                    found.append(hwnd)
        finally:
            kernel32.CloseHandle(h)
        return True

    try:
        user32.EnumWindows(WNDENUMPROC(_cb), 0)
    except Exception:
        return False
    if not found:
        return False
    hwnd = found[0]
    try:
        user32.ShowWindow(hwnd, 9)          # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def acquire():
    """拿到锁返回 QLockFile 对象（调用方要留着引用）；已有实例返回 False。

    锁信息读不出来时按「能开」处理——宁可多开一个，也不要让用户点不开程序。
    """
    p = _lock_path()
    if not p:
        return None
    try:
        from PySide6.QtCore import QLockFile

        lock = QLockFile(p)
        # 不按文件时间判过期：自己写的锁没有谁来刷新 mtime，设了秒数反而会
        # 在程序正常开着的时候被判成过期，又多开一个。
        lock.setStaleLockTime(0)
        if lock.tryLock(0):
            return lock
        kind = lock.error()
        if kind == QLockFile.LockFailedError:
            # 能把老窗口提到前面才算「真的已经有实例」；提不到（多半是上回
            # 被强杀留下的无窗口残留进程）就放行，别把用户挡在门外。
            return False if raise_existing() else None
        try:
            lock.removeStaleLockFile()
            if lock.tryLock(0):
                return lock
        except Exception:
            pass
        return None
    except Exception:
        return None
