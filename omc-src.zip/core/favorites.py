# -*- coding: utf-8 -*-
"""收藏夹：模组 / 光影 / 资源包 / 存档 / 版本 / 歌曲，都往一个 json 里存。

key 用「类型:标识」拼，标识通常是 modId、文件名或版本 id，
所以同一个东西换目录也还认得。
"""
import json
import os
import threading
import time

from . import platform_utils

_LOCK = threading.Lock()

KINDS = {
    "mod": "模组",
    "shader": "光影",
    "resourcepack": "资源包",
    "world": "存档",
    "version": "版本",
    "music": "歌曲",
}


def _path():
    return os.path.join(platform_utils.data_dir(), "favorites.json")


def load():
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except Exception:
        pass
    return {"items": [], "updated": 0}


def save(data):
    data["updated"] = int(time.time())
    try:
        os.makedirs(os.path.dirname(_path()), exist_ok=True)
        with open(_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _key(kind, key):
    return "%s:%s" % (kind, key)


def toggle(kind, key, meta=None):
    """加了返回 True，取消了返回 False。"""
    with _LOCK:
        data = load()
        full = _key(kind, key)
        items = data.get("items") or []
        for i, it in enumerate(items):
            if it.get("k") == full:
                items.pop(i)
                save(data)
                return False
        rec = {"k": full, "kind": kind, "id": key, "at": int(time.time())}
        if meta:
            rec.update({k: v for k, v in meta.items()
                        if k in ("name", "desc", "icon", "path", "ver", "extra")})
        items.append(rec)
        data["items"] = items
        save(data)
        return True


def has(kind, key):
    for it in load().get("items") or []:
        if it.get("k") == _key(kind, key):
            return True
    return False


def remove(kind, key):
    with _LOCK:
        data = load()
        data["items"] = [it for it in (data.get("items") or [])
                         if it.get("k") != _key(kind, key)]
        save(data)


def listing(kind=None):
    """按类型列收藏，最新的在前。"""
    items = (load().get("items") or [])
    if kind:
        items = [it for it in items if it.get("kind") == kind]
    items.sort(key=lambda it: it.get("at") or 0, reverse=True)
    return items


def counts():
    data = load()
    out = dict((k, 0) for k in KINDS)
    for it in data.get("items") or []:
        kind = it.get("kind")
        if kind in out:
            out[kind] += 1
    out["total"] = len(data.get("items") or [])
    return out


def export_all():
    return json.dumps(load(), ensure_ascii=False, indent=2)


def import_text(text, merge=True):
    """导入一份收藏 json；merge=True 时并进现有收藏。"""
    data = json.loads(text)
    incoming = data.get("items") if isinstance(data, dict) else data
    if not isinstance(incoming, list):
        raise ValueError("这不是收藏文件")
    if not merge:
        save({"items": incoming})
        return len(incoming)
    with _LOCK:
        cur = load()
        have = {it.get("k") for it in (cur.get("items") or [])}
        added = 0
        for it in incoming:
            if not isinstance(it, dict) or not it.get("k"):
                continue
            if it["k"] in have:
                continue
            cur.setdefault("items", []).append(it)
            have.add(it["k"])
            added += 1
        save(cur)
        return added
