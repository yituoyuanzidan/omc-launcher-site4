# -*- coding: utf-8 -*-
"""版本 JSON 读取与 inheritsFrom 合并（Fabric / Quilt / Forge / NeoForge 都靠它）。"""
import json
import os


def json_path(game_dir, version_id):
    return os.path.join(game_dir, "versions", version_id, version_id + ".json")


def load_raw(game_dir, version_id):
    with open(json_path(game_dir, version_id), "r", encoding="utf-8") as f:
        return json.load(f)


def _merge(base, child):
    """把子版本（加载器）合并到父版本（原版）上。"""
    merged = dict(base)
    for key, value in child.items():
        if key in ("libraries", "arguments", "inheritsFrom"):
            continue
        merged[key] = value

    libs = list(base.get("libraries") or [])
    libs.extend(child.get("libraries") or [])
    dedup = {}
    for lib in libs:
        name = lib.get("name") or json.dumps(lib, sort_keys=True)
        dedup[name] = lib
    merged["libraries"] = list(dedup.values())

    args = {}
    for src in (base, child):
        if isinstance(src.get("arguments"), dict):
            for kind in ("jvm", "game"):
                if kind in src["arguments"]:
                    args.setdefault(kind, []).extend(src["arguments"][kind])
    if args:
        merged["arguments"] = args
    if "minecraftArguments" in child:
        merged["minecraftArguments"] = child["minecraftArguments"]
    return merged


def load_merged(game_dir, version_id, depth=0):
    """返回 (合并后的 vj, client jar 路径, natives 目录)。

    加载器版本本身没有 jar 和 natives，必须用父版本（原版）的。
    """
    vj = load_raw(game_dir, version_id)
    parent = vj.get("inheritsFrom")
    if parent and depth < 4 and os.path.exists(json_path(game_dir, parent)):
        base, base_jar, base_natives = load_merged(game_dir, parent, depth + 1)
        merged = _merge(base, vj)
        merged["id"] = version_id
        return merged, base_jar, base_natives

    jar = os.path.join(game_dir, "versions", version_id, version_id + ".jar")
    natives = os.path.join(game_dir, "versions", version_id, "natives")
    return vj, jar, natives
