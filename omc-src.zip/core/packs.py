# -*- coding: utf-8 -*-
"""局内资源包：直接读写游戏目录 options.txt 的 resourcePacks 列表。

options.txt 里 resourcePacks 的写法是 JSON 风格的一行：
    resourcePacks:["vanilla","file/某材质包.zip"]
列表顺序就是游戏内「已选」顺序，越靠后优先级越高（显示在最上层）。
这里只改这一行，其余设置原样保留。
"""
import json
import os
import re

VANILLA = "vanilla"
_LINE = re.compile(r'^resourcePacks\s*:\s*(.*)$')


def options_path(game_dir):
    return os.path.join(game_dir, "options.txt")


def _read_lines(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read().splitlines()
    except Exception:
        return []


def read_enabled(game_dir):
    """返回当前启用列表（含 vanilla），读不到返回 []。"""
    path = options_path(game_dir)
    for line in _read_lines(path):
        m = _LINE.match(line.strip())
        if not m:
            continue
        raw = m.group(1).strip()
        try:
            data = json.loads(raw)
        except Exception:
            # 有些版本写的是 resourcePacks:["vanilla","file/a.zip"]
            items = re.findall(r'"([^"]+)"', raw)
            return items
        if isinstance(data, list):
            return [str(x) for x in data]
    return []


def _pack_id(name):
    """资源包在 options.txt 里的写法：zip 加 file/ 前缀，文件夹直接写名字。"""
    if name.lower().endswith(".zip"):
        return "file/" + name
    return name


def available(game_dir):
    """目录里所有可用的资源包文件名（zip 与文件夹）。"""
    d = os.path.join(game_dir, "resourcepacks")
    if not os.path.isdir(d):
        return []
    out = []
    for name in os.listdir(d):
        p = os.path.join(d, name)
        if os.path.isdir(p) or name.lower().endswith(".zip"):
            out.append(name)
    return sorted(out)


def pack_id(name):
    return _pack_id(name)


def display_name(pack_id):
    """把 file/xxx.zip 还原成文件名，vanilla 显示成「原版」。"""
    if pack_id == VANILLA:
        return "原版（vanilla）"
    if pack_id.startswith("file/"):
        return pack_id[5:]
    return pack_id


def write_enabled(game_dir, enabled):
    """写入启用列表；enabled 里不含 vanilla 时自动补到最前。"""
    path = options_path(game_dir)
    if not os.path.exists(path):
        raise RuntimeError("找不到 options.txt，先进一次游戏再改资源包")
    lines = _read_lines(path)
    if not enabled or VANILLA not in enabled:
        enabled = [VANILLA] + list(enabled)
    new_line = "resourcePacks:" + json.dumps(list(enabled), ensure_ascii=False)
    replaced = False
    out = []
    for line in lines:
        if _LINE.match(line.strip()):
            out.append(new_line)
            replaced = True
        else:
            out.append(line)
    if not replaced:
        out.append(new_line)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")
    return list(enabled)
