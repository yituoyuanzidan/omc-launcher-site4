# -*- coding: utf-8 -*-
"""存档定时自动备份：后台盯着 saves 目录，一有变化就压一份。

和「启动前备份一次」不同，这里在整个游戏时长里都会看着：
每 interval_min 分钟比一次每个存档的 level.dat（mtime + size），
只要变了就调 backup.backup_all()，并且按 keep 保留最近几份。

interval_min <= 0 视为关闭，线程直接不启动。
"""
import os
import threading
import time

from . import backup


def _signature(game_dir):
    """把所有存档的 level.dat 指纹拼成一个可比较的字符串。"""
    saves = backup.saves_dir(game_dir)
    if not os.path.isdir(saves):
        return ""
    parts = []
    for name in sorted(os.listdir(saves)):
        lvl = os.path.join(saves, name, "level.dat")
        try:
            st = os.stat(lvl)
            parts.append("%s:%d:%d" % (name, int(st.st_mtime), st.st_size))
        except OSError:
            continue
    return "|".join(parts)


class Watcher(threading.Thread):
    """后台线程，靠 Event.wait 睡眠，stop() 能立刻打断。"""

    def __init__(self, game_dir, interval_min=5, keep=5, log=None, on_backup=None):
        threading.Thread.__init__(self, daemon=True, name="omc-autobackup")
        self.game_dir = game_dir
        self.interval = max(30, int(interval_min * 60)) if interval_min else 0
        self.keep = keep or 5
        self._log = log or (lambda _m: None)
        self._on_backup = on_backup or (lambda _n: None)
        self._stop = threading.Event()
        self._last_sig = _signature(game_dir)
        self.last_run = 0.0
        self.runs = 0

    def stop(self):
        self._stop.set()

    def run_once(self):
        try:
            n = backup.backup_all(self.game_dir, keep=self.keep, log=self._log)
            if n:
                self.runs += 1
                self.last_run = time.time()
                self._on_backup(n)
                return n
        except Exception as e:
            self._log("自动备份出错：%s" % e)
        return 0

    def run(self):
        if not self.interval:
            return
        self._log("存档自动备份已开启：每 %d 分钟检查一次，每个存档保留最近 %d 份"
                  % (self.interval // 60, self.keep))
        # 先等一轮再开始查，别和启动本身抢磁盘
        if self._stop.wait(min(90, self.interval)):
            return
        while not self._stop.is_set():
            sig = _signature(self.game_dir)
            if sig and sig != self._last_sig:
                self._last_sig = sig
                self.run_once()
            if self._stop.wait(self.interval):
                break


def start(game_dir, interval_min=5, keep=5, log=None, on_backup=None):
    """建一个 Watcher；配置为关闭时返回 None。"""
    if not interval_min or interval_min <= 0:
        return None
    w = Watcher(game_dir, interval_min=interval_min, keep=keep, log=log,
                on_backup=on_backup)
    w.start()
    return w
