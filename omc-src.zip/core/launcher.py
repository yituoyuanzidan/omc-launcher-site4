# -*- coding: utf-8 -*-
"""启动逻辑：拼装 JVM 与游戏参数，支持离线与正版账号。"""
import json
import os
import subprocess
import uuid

from . import platform_utils
from .downloader import _rules_allowed
from .version_json import load_merged

# 类路径分隔符：Windows 分号，macOS/Linux 冒号
CP_SEP = platform_utils.CP_SEP


def offline_account(username):
    return {
        "type": "offline",
        "name": username,
        "uuid": str(uuid.UUID(bytes=__import__("hashlib").md5(
            ("OfflinePlayer:" + username).encode("utf-8")).digest())),
        "mc_token": "0",
    }


def format_uuid(value):
    """正版 profile id 为 32 位无横线，转成标准带横线格式。"""
    if "-" in value:
        return value
    return "%s-%s-%s-%s-%s" % (value[0:8], value[8:12], value[12:16],
                               value[16:20], value[20:32])


def _substitute(token, mapping):
    for k, v in mapping.items():
        token = token.replace("${%s}" % k, str(v))
    return token


def _filter_args(args):
    result = []
    for item in args:
        if isinstance(item, str):
            result.append(item)
        elif isinstance(item, dict):
            if _rules_allowed(item.get("rules")):
                value = item.get("value")
                if isinstance(value, list):
                    result.extend(value)
                else:
                    result.append(value)
    return result


def build_command(version_json_path, game_dir, java_path, memory_mb, account,
                  extra_jvm="", extra_game=""):
    if account is None:
        account = {"type": "offline", "name": "Player", "uuid": str(uuid.uuid4())}
    with open(version_json_path, "r", encoding="utf-8") as f:
        vj = json.load(f)

    version_id = vj["id"]
    # 加载器版本（Fabric/Quilt/Forge/NeoForge）通过 inheritsFrom 指向原版，
    # 合并后才有完整的库、主类、参数，jar 与 natives 也要用父版本的
    if vj.get("inheritsFrom"):
        vj, client_jar, natives_dir = load_merged(game_dir, version_id)
        version_id = vj["id"]
    else:
        natives_dir = os.path.join(game_dir, "versions", version_id, "natives")
        client_jar = os.path.join(game_dir, "versions", version_id, version_id + ".jar")

    cp_items = []
    for lib in vj.get("libraries", []):
        if not _rules_allowed(lib.get("rules")):
            continue
        artifact = lib.get("downloads", {}).get("artifact")
        if artifact:
            cp_items.append(os.path.join(game_dir, "libraries", artifact["path"]))
    cp_items.append(client_jar)
    classpath = CP_SEP.join(cp_items)

    is_msa = account.get("type") == "msa"
    mapping = {
        "auth_player_name": account["name"],
        "version_name": version_id,
        "game_directory": game_dir,
        "assets_root": os.path.join(game_dir, "assets"),
        "game_assets": os.path.join(game_dir, "assets", "virtual", "legacy"),
        "assets_index_name": vj.get("assets", version_id),
        "auth_uuid": format_uuid(account["uuid"]),
        "access_token": account.get("mc_token", "0"),
        "auth_xuid": account.get("xuid", "0"),
        "clientid": str(uuid.uuid4()),
        "user_type": "msa" if is_msa else "legacy",
        "version_type": vj.get("type", "release"),
        "user_properties": "{}",
        "natives_directory": natives_dir,
        "library_directory": os.path.join(game_dir, "libraries"),
        "classpath": classpath,
        "launcher_name": "simple-mc-launcher",
        "launcher_version": "1.0",
    }

    jvm_args = ["-Xmx%dM" % memory_mb]
    # macOS 上 GLFW/LWJGL 要求 JVM 在主线程运行，缺这个参数窗口起不来
    if platform_utils.MACOS and not any("-XstartOnFirstThread" in a for a in jvm_args):
        jvm_args.insert(0, "-XstartOnFirstThread")
    if "arguments" in vj and "jvm" in vj["arguments"]:
        jvm_args.extend(_filter_args(vj["arguments"]["jvm"]))
    else:
        jvm_args.extend(["-Djava.library.path=%s" % natives_dir, "-cp", classpath])
    if extra_jvm.strip():
        jvm_args.extend(extra_jvm.strip().split())
    # 第三方账号：挂载 authlib-injector 让游戏接受外置令牌
    if account.get("type") == "third_party":
        from .yggdrasil import injector_path
        jvm_args.append(
            "-javaagent:%s=%s" % (injector_path(), account["api_url"]))

    if "arguments" in vj and "game" in vj["arguments"]:
        game_args = _filter_args(vj["arguments"]["game"])
    else:
        game_args = vj["minecraftArguments"].split()

    parts = [java_path]
    for t in jvm_args + [vj["mainClass"]] + game_args:
        parts.append(_substitute(t, mapping))
    if extra_game.strip():
        parts.extend(extra_game.strip().split())
    return parts


def launch(version_json_path, game_dir, java_path, memory_mb, account, extra_jvm="",
           extra_game="", log_path=None):
    os.makedirs(game_dir, exist_ok=True)
    cmd = build_command(version_json_path, game_dir, java_path, memory_mb,
                        account, extra_jvm, extra_game)
    # 窗口化启动器本身没有控制台，不加这个标志会给 java 弹出黑色控制台窗口
    creationflags = platform_utils.no_window_flags()
    if log_path:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        handle = open(log_path, "w", encoding="utf-8", errors="replace")
        return subprocess.Popen(cmd, cwd=game_dir, stdout=handle,
                                stderr=subprocess.STDOUT,
                                creationflags=creationflags)
    return subprocess.Popen(cmd, cwd=game_dir, creationflags=creationflags)


def required_java_major(version_json_path):
    """版本要求的 Java 主版本号，没有声明时去父版本里找。"""
    try:
        with open(version_json_path, "r", encoding="utf-8") as f:
            vj = json.load(f)
        major = int((vj.get("javaVersion") or {}).get("majorVersion") or 0)
        if major:
            return major
        parent = vj.get("inheritsFrom")
        if parent:
            game_dir = os.path.dirname(os.path.dirname(os.path.dirname(
                version_json_path)))
            from .version_json import json_path
            ppath = json_path(game_dir, parent)
            if os.path.exists(ppath):
                return required_java_major(ppath)
        return 0
    except Exception:
        return 0


def check_ready(version_json_path, game_dir):
    """启动前检查，返回问题列表；空列表表示可以启动。"""
    from . import downloader
    version_id = os.path.basename(version_json_path)[:-5]
    return downloader.check_version(game_dir, version_id)
