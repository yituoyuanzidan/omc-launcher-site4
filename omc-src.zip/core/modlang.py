# -*- coding: utf-8 -*-
"""把模组里的英文语言文件翻成中文，做成一个资源包。

思路（不碰模组本体，出问题删掉资源包就恢复）：
1. 扫 mods 目录下每个 jar，读里面的 assets/<模组id>/lang/en_us.json
2. 已经有 zh_cn.json 的模组跳过（人家自带中文，别覆盖）
3. 翻译缺的条目（术语表优先，剩下的走翻译接口）
4. 生成 resourcepacks/<名字>.zip：pack.mcmeta + assets/<id>/lang/zh_cn.json
   游戏里启用这个资源包，模组里的英文就变中文
"""
import concurrent.futures
import json
import os
import re
import ssl
import time
import urllib.parse
import urllib.request
import zipfile

CACHE_NAME = "lang_cache.json"
TIMEOUT = 8
BATCH = 24               # 一次请求塞多少条
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
GT = ("https://translate.googleapis.com/translate_a/single?client=gtx"
      "&sl=en&tl=zh-CN&dt=t&q=")
MYMEM = ("https://api.mymemory.translated.net/get?q=%s&langpair=en|zh-CN")

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE


def _app_dir():
    return os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")


def _cache_path():
    d = _app_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return os.path.join(d, CACHE_NAME)


_CACHE = None


def cache():
    global _CACHE
    if _CACHE is None:
        try:
            with open(_cache_path(), "r", encoding="utf-8") as f:
                _CACHE = json.load(f)
        except Exception:
            _CACHE = {}
        if not isinstance(_CACHE, dict):
            _CACHE = {}
    return _CACHE


def save_cache():
    try:
        p = _cache_path()
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache(), f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        pass


# ---------------- 术语表 ----------------
# 这些词硬编码，别交给机器翻译（翻出来反而看不懂）
TERMS = {
    "ore": "矿石", "ingot": "锭", "nugget": "粒", "dust": "粉", "gear": "齿轮",
    "plate": "板", "rod": "杆", "block": "块", "stairs": "楼梯", "slab": "台阶",
    "wall": "墙", "fence": "栅栏", "gate": "栅栏门", "door": "门", "trapdoor": "活板门",
    "pickaxe": "镐", "axe": "斧", "shovel": "锹", "sword": "剑", "hoe": "锄",
    "helmet": "头盔", "chestplate": "胸甲", "leggings": "护腿", "boots": "靴子",
    "hammer": "锤", "staff": "法杖", "wand": "魔杖", "bow": "弓", "crossbow": "弩",
    "arrow": "箭", "bucket": "桶", "button": "按钮", "pressure plate": "压力板",
    "cable": "线缆", "pipe": "管道", "machine": "机器", "engine": "引擎",
    "generator": "发电机", "battery": "电池", "solar panel": "太阳能板",
    "tank": "储罐", "crusher": "粉碎机", "furnace": "熔炉", "smelter": "熔炼炉",
    "upgrade": "升级", "module": "模块", "tooltip": "提示",
    "item": "物品", "items": "物品", "entity": "实体", "fluids": "流体",
    "creative": "创造模式", "survival": "生存模式", "nether": "下界", "end": "末地",
    "overworld": "主世界", "diamond": "钻石", "emerald": "绿宝石",
    "gold": "金", "iron": "铁", "copper": "铜", "netherite": "下界合金",
    "lapis": "青金石", "redstone": "红石", "quartz": "石英", "amethyst": "紫水晶",
    "coal": "煤炭", "charcoal": "木炭", "tier": "等级", "durability": "耐久",
    "enchant": "附魔", "enchanted": "附魔", "experience": "经验",
}

# 常见属性/界面词
UI_TERMS = {
    "range": "范围", "speed": "速度", "damage": "伤害", "heal": "治疗",
    "energy": "能量", "power": "功率", "config": "设置", "configuration": "配置",
    "settings": "设置", "enable": "启用", "disable": "禁用", "disabled": "已禁用",
    "enabled": "已启用", "on": "开", "off": "关", "click": "点击",
    "right click": "右键点击", "shift": "Shift", "sneak": "潜行",
    "requires": "需要", "requirement": "需求", "max": "最大", "min": "最小",
    "chance": "几率", "level": "等级", "version": "版本", "recipe": "配方",
    "recipe category": "配方分类", "creative tab": "创造模式物品栏",
    "amount": "数量", "storage": "存储", "fluid": "流体", "liquid": "液体",
}

# 纯技术键后缀（这些键多半是内部名，不值当翻）
SKIP_RE = re.compile(r"(\.desc_(?:[12])?$|\._comment|\.debug\b)", re.I)


def _strip_codes(text):
    """Minecraft 的 § 颜色码和 %s / %d 占位符要原样保留。"""
    return re.sub(r"§.", "", text)


def _protected_tokens(text):
    return re.findall(r"%[sd]|%\d+\$[sd]|\{[^{}]*\}", text)


def glossary_text(text):
    """整条能对上术语表就对术语表，否则返回 None。"""
    t = _strip_codes(text).strip()
    low = t.lower()
    if low in TERMS:
        return TERMS[low]
    if low in UI_TERMS:
        return UI_TERMS[low]
    return None


def _http(url, timeout=None, data=None, headers=None):
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h)
    with op.open(req, timeout=timeout or TIMEOUT) as r:
        return r.read().decode("utf-8", "replace")


def _parse_gt(body):
    """解析 Google gtx 返回：[[[译文, 原文, ...], ...], ...]"""
    d = json.loads(body)
    segs = d[0] if d and isinstance(d[0], list) else []
    out = []
    for s in segs:
        if isinstance(s, list) and s:
            out.append(s[0] or "")
    return "".join(out)


# ---------------- 翻译源 ----------------
# 国内网络下 translate.googleapis.com 连不上（实测一条要等 12 秒超时），
# 以前每条都先等它超时再试备选，于是「点了翻译半天不动」。
# 现在先并发探测一遍，把能用的源排好序，之后只打可用的那个。
_BING = {"ts": 0.0, "ig": "", "iid": "", "token": "", "key": ""}
_SRC = {"ts": 0.0, "order": []}
_SRC_TTL = 300.0


def _bing_session(force=False):
    """从 Bing 翻译页拿 IG / IID / token / key（能用一个小时左右）。"""
    now = time.time()
    if not force and _BING["ig"] and now - _BING["ts"] < 1800:
        return _BING
    html_ = _http("https://cn.bing.com/translator", timeout=6)
    ig = re.search(r'IG:"([0-9A-Fa-f]+)"', html_)
    iid = re.search(r'data-iid="(translator\.[\d.]+)"', html_)
    abuse = re.search(r'params_AbusePreventionHelper\s*=\s*\[(\d+),"([^"]+)",(\d+)\]',
                      html_)
    if not ig or not abuse:
        return None
    _BING.update(ts=now, ig=ig.group(1),
                 iid=(iid.group(1) if iid else "translator.5023"),
                 key=abuse.group(1), token=abuse.group(2))
    return _BING


def _bing_one(text, sess=None):
    """Bing 网页翻译接口：一条一次 POST，国内直连很快。"""
    s = sess or _bing_session()
    if not s:
        return ""
    url = ("https://cn.bing.com/ttranslatev3?isVertical=1&&IG=%s&IID=%s.1"
           % (s["ig"], s["iid"]))
    data = urllib.parse.urlencode({
        "fromLang": "en", "to": "zh-Hans", "text": text[:4000],
        "token": s["token"], "key": s["key"],
    }).encode()
    body = _http(url, timeout=6, data=data, headers={
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://cn.bing.com/translator",
        "Origin": "https://cn.bing.com",
    })
    d = json.loads(body)
    if isinstance(d, list) and d:
        tr = (d[0].get("translations") or [])
        if tr:
            return (tr[0].get("text") or "").strip()
    return ""


def _mymemory_one(text):
    body = _http(MYMEM % urllib.parse.quote(text[:400]), timeout=6)
    d = json.loads(body)
    return ((d.get("responseData") or {}).get("translatedText") or "").strip()


def _google_one(text):
    body = _http(GT + urllib.parse.quote(text), timeout=4)
    return _parse_gt(body).strip()


_ONE = {"bing": _bing_one, "mymemory": _mymemory_one, "google": _google_one}


def _probe_one(name):
    try:
        zh = _ONE[name]("iron sword")
        return bool(zh)
    except Exception:
        return False


def _source_order(force=False):
    """探测出可用源，按「快而稳」排序；结果缓存 5 分钟。"""
    now = time.time()
    if not force and _SRC["order"] and now - _SRC["ts"] < _SRC_TTL:
        return _SRC["order"]
    names = ["bing", "mymemory", "google"]
    ok = []
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
            res = list(ex.map(_probe_one, names))
        ok = [n for n, r in zip(names, res) if r]
    except Exception:
        ok = []
    # 探测全失败也别死心：仍按顺序试一遍（可能是偶发抖动）
    _SRC.update(ts=now, order=ok or names)
    return _SRC["order"]


def _one(text):
    """翻一条：按探测出来的可用源顺序试，第一个给出结果的就用。"""
    raw = _strip_codes(text)
    for src in _source_order():
        fn = _ONE.get(src)
        if not fn:
            continue
        try:
            zh = fn(raw)
        except Exception:
            continue
        if zh and zh.lower() != raw.lower():
            return zh
    return ""


def _batch(texts):
    """Google 在境外能用批量（换行分隔），对不上条数就返回空。"""
    if not texts or "google" not in _source_order():
        return {}
    if _source_order()[0] != "google":
        return {}
    lines = [_strip_codes(t).replace("\n", " ") for t in texts]
    joined = "\n".join(lines)
    if len(joined) > 1600:
        return {}
    try:
        body = _http(GT + urllib.parse.quote(joined), timeout=6)
        d = json.loads(body)
        segs = d[0] if d and isinstance(d[0], list) else []
        parts = [""]
        for s in segs:
            if not isinstance(s, list) or not s:
                continue
            piece = s[0] or ""
            if piece.endswith("\n"):
                parts.append("")
                parts[-2] += piece.rstrip("\n")
            else:
                parts[-1] += piece
        parts = [p.strip() for p in parts]
        while len(parts) > len(texts) and not parts[-1]:
            parts.pop()
        if len(parts) == len(texts):
            return dict(zip(texts, parts))
    except Exception:
        pass
    return {}


def translate_texts(texts, progress=None, workers=6):
    """翻一批字符串，返回 {原文: 译文}。命中的进缓存。"""
    c = cache()
    todo = []
    for t in texts:
        if not t or not isinstance(t, str):
            continue
        g = glossary_text(t)
        if g:
            continue
        if t in c and c[t]:
            continue
        if todo.count(t) == 0:
            todo.append(t)
    total = len(todo)
    done = 0
    result = {}
    for t in texts:
        if not isinstance(t, str):
            continue
        g = glossary_text(t)
        if g:
            result[t] = g
        elif c.get(t):
            result[t] = c[t]
    if progress:
        progress(0, total, "待翻译 %d 条（术语表已命中 %d 条）"
                 % (total, len(result)))

    # 挑源：Google 能用就走批量（最快），否则并发逐条（Bing / MyMemory 都很快）
    order = _source_order()
    if progress and not order:
        progress(0, total, "翻译接口连不上，先只做术语表")
    batches = [todo[i:i + BATCH] for i in range(0, len(todo), BATCH)]

    def run_batch(b):
        if "google" in order and order[0] == "google":
            got = _batch(b)
            if len(got) == len(b):
                return got
        out = {}
        for t in b:
            r = _one(t)
            if r:
                out[t] = r
        return out

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        for got in ex.map(run_batch, batches):
            for k, v in got.items():
                if v:
                    result[k] = v
                    c[k] = v
            done += len(got) if got else 0
            if progress:
                n = min(done, total)
                progress(n, total, "已翻 %d / %d 条（源：%s）"
                         % (n, total, "、".join(order) if order else "无"))
    save_cache()
    return result


# ---------------- 扫模组 ----------------
def mods_dir(game_dir, vid=""):
    cand = []
    if vid and game_dir:
        cand.append(os.path.join(game_dir, "versions", vid, "mods"))
    if game_dir:
        cand.append(os.path.join(game_dir, "mods"))
    for p in cand:
        if os.path.isdir(p):
            return p
    return cand[0] if cand else ""


def scan_jars(mdir):
    out = []
    if not mdir or not os.path.isdir(mdir):
        return out
    for name in os.listdir(mdir):
        if not name.lower().endswith(".jar"):
            continue
        p = os.path.join(mdir, name)
        try:
            out.append({"name": name, "path": p,
                        "size": os.path.getsize(p),
                        "mtime": int(os.path.getmtime(p))})
        except OSError:
            continue
    out.sort(key=lambda x: x["name"].lower())
    return out


def read_langs(jar_path):
    """读一个模组 jar 里的语言文件。

    返回 {"en": {namespace: {key: text}}, "zh": set(namespace)}
    """
    en = {}
    zh = set()
    try:
        with zipfile.ZipFile(jar_path) as z:
            names = z.namelist()
            for n in names:
                m = re.match(r"assets/([^/]+)/lang/(en_us|zh_cn)\.json$", n, re.I)
                if not m:
                    continue
                ns = m.group(1).lower()
                kind = m.group(2).lower()
                if kind == "zh_cn":
                    zh.add(ns)
                    continue
                try:
                    data = json.loads(z.read(n).decode("utf-8", "replace"))
                except Exception:
                    continue
                if isinstance(data, dict):
                    en[ns] = {k: v for k, v in data.items()
                              if isinstance(v, str)}
    except Exception:
        return {"en": {}, "zh": set()}
    return {"en": en, "zh": zh}


def collect(mods):
    """把所有模组的英文条目汇总。返回 (entries, stats)。"""
    entries = {}      # namespace -> {key: en}
    stats = {"mods": len(mods), "with_en": 0, "has_zh": 0, "keys": 0}
    for m in mods:
        info = read_langs(m["path"])
        en = info.get("en") or {}
        if not en:
            continue
        stats["with_en"] += 1
        if info.get("zh"):
            stats["has_zh"] += 1
        for ns, kv in en.items():
            if ns in info.get("zh"):
                continue          # 这个模组自己就有中文，别覆盖
            tgt = entries.setdefault(ns, {})
            for k, v in kv.items():
                if not SKIP_RE.search(k):
                    tgt[k] = v
    stats["keys"] = sum(len(v) for v in entries.values())
    return entries, stats


# ---------------- 生成资源包 ----------------
def build_pack(entries, texts_map, out_zip, title="OMC 模组汉化"):
    """生成资源包 zip，返回写进去的文件数。"""
    os.makedirs(os.path.dirname(out_zip) or ".", exist_ok=True)
    meta = {
        "pack": {
            "pack_format": 15,
            "description": "%s（OMC 用机器翻译生成，仅供阅读参考）" % title,
            "supported_formats": {"min_inclusive": 1, "max_inclusive": 999},
        }
    }
    count = 0
    tmp = out_zip + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("pack.mcmeta", json.dumps(meta, ensure_ascii=False))
        for ns, kv in entries.items():
            zh = {}
            for k, en in kv.items():
                t = texts_map.get(en)
                if t and t != en:
                    zh[k] = t
            if not zh:
                continue
            z.writestr("assets/%s/lang/zh_cn.json" % ns,
                       json.dumps(zh, ensure_ascii=False, indent=2))
            count += 1
        z.writestr("omc_readme.txt",
                   "由 OMC 启动器生成。想撤销：删掉这个资源包，游戏里关掉它即可。\n"
                   "机器翻译可能有怪词，术语表里的常见词是人工对的。\n")
    os.replace(tmp, out_zip)
    return count


def resourcepacks_dir(game_dir):
    p = os.path.join(game_dir or ".", "resourcepacks")
    try:
        os.makedirs(p, exist_ok=True)
    except OSError:
        pass
    return p


def default_pack_path(game_dir):
    return os.path.join(resourcepacks_dir(game_dir), "OMC-模组汉化.zip")


def quick_stats(game_dir, vid=""):
    """不做翻译，只统计能翻多少（给界面显示用，很快）。"""
    mdir = mods_dir(game_dir, vid)
    jars = scan_jars(mdir)
    entries, stats = collect(jars)
    stats["dir"] = mdir
    stats["pack"] = default_pack_path(game_dir)
    stats["exists"] = os.path.isfile(stats["pack"])
    if stats["exists"]:
        try:
            stats["pack_size"] = os.path.getsize(stats["pack"])
        except OSError:
            stats["pack_size"] = 0
    return stats, entries
