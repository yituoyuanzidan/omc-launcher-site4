# -*- coding: utf-8 -*-
"""种子 / 存档地图：读 region 文件里的生物群系，画成彩色小地图。

不依赖任何外部库：自己解析 mca（区域文件）与 NBT 里用得到的部分。
能读 1.18+ 的 sections.biomes，也能读旧版的 Level.Biomes。
"""
import os
import struct
import zlib

# 生物群系代表色（够看就行，不求跟游戏里一模一样）
BIOME_COLORS = {
    "minecraft:ocean": (28, 70, 130),
    "minecraft:deep_ocean": (18, 50, 100),
    "minecraft:warm_ocean": (40, 120, 150),
    "minecraft:lukewarm_ocean": (45, 105, 150),
    "minecraft:cold_ocean": (32, 82, 130),
    "minecraft:deep_cold_ocean": (24, 62, 110),
    "minecraft:frozen_ocean": (110, 150, 180),
    "minecraft:deep_frozen_ocean": (90, 130, 165),
    "minecraft:river": (60, 110, 175),
    "minecraft:frozen_river": (130, 170, 200),
    "minecraft:beach": (230, 220, 160),
    "minecraft:snowy_beach": (235, 240, 245),
    "minecraft:stony_shore": (120, 120, 115),
    "minecraft:plains": (140, 190, 90),
    "minecraft:sunflower_plains": (165, 200, 85),
    "minecraft:snowy_plains": (240, 245, 250),
    "minecraft:ice_spikes": (215, 235, 250),
    "minecraft:desert": (235, 210, 130),
    "minecraft:swamp": (90, 120, 60),
    "minecraft:mangrove_swamp": (70, 110, 70),
    "minecraft:forest": (70, 130, 60),
    "minecraft:flower_forest": (120, 160, 80),
    "minecraft:birch_forest": (140, 175, 105),
    "minecraft:old_growth_birch_forest": (130, 165, 95),
    "minecraft:dark_forest": (55, 95, 45),
    "minecraft:taiga": (85, 130, 100),
    "minecraft:snowy_taiga": (150, 175, 175),
    "minecraft:old_growth_pine_taiga": (75, 110, 85),
    "minecraft:old_growth_spruce_taiga": (80, 115, 90),
    "minecraft:jungle": (60, 145, 50),
    "minecraft:sparse_jungle": (110, 165, 70),
    "minecraft:bamboo_jungle": (95, 160, 65),
    "minecraft:savanna": (190, 175, 95),
    "minecraft:savanna_plateau": (175, 165, 100),
    "minecraft:windswept_savanna": (180, 160, 100),
    "minecraft:badlands": (180, 110, 70),
    "minecraft:eroded_badlands": (170, 95, 60),
    "minecraft:wooded_badlands": (150, 110, 70),
    "minecraft:meadow": (150, 195, 120),
    "minecraft:cherry_grove": (235, 175, 190),
    "minecraft:grove": (155, 180, 170),
    "minecraft:snowy_slopes": (225, 235, 240),
    "minecraft:frozen_peaks": (235, 245, 250),
    "minecraft:jagged_peaks": (200, 200, 205),
    "minecraft:stony_peaks": (150, 150, 150),
    "minecraft:mushroom_fields": (200, 175, 190),
    "minecraft:dripstone_caves": (140, 120, 105),
    "minecraft:lush_caves": (95, 150, 90),
    "minecraft:deep_dark": (40, 45, 60),
    "minecraft:nether_wastes": (110, 50, 50),
    "minecraft:soul_sand_valley": (85, 65, 60),
    "minecraft:crimson_forest": (140, 40, 60),
    "minecraft:warped_forest": (40, 110, 105),
    "minecraft:basalt_deltas": (70, 70, 75),
    "minecraft:the_end": (215, 200, 170),
    "minecraft:small_end_islands": (200, 190, 165),
    "minecraft:end_midlands": (205, 195, 170),
    "minecraft:end_highlands": (195, 185, 160),
    "minecraft:end_barrens": (185, 175, 155),
}
UNKNOWN_COLOR = (95, 95, 95)


def color_for(biome):
    key = (biome or "").strip()
    if not key.startswith("minecraft:"):
        key = "minecraft:" + key.split(":")[-1] if ":" in key else "minecraft:" + key
    return BIOME_COLORS.get(key, UNKNOWN_COLOR)


def java_seed(text):
    """数字当种子；文本按 Java String.hashCode 转成 64 位数。"""
    t = (text or "").strip()
    if not t:
        return 0
    try:
        return int(t)
    except ValueError:
        pass
    h = 0
    for ch in t:
        h = (31 * h + ord(ch)) & 0xFFFFFFFF
    if h >= 0x80000000:
        h -= 0x100000000
    return h


def read_world_seed(world_dir):
    """从存档的 level.dat 读出种子（读不出来返回 None）。

    新版把种子放在 Data.WorldGenSettings.seed，1.16 以前在 Data.Seed。
    """
    import gzip
    p = os.path.join(world_dir or "", "level.dat")
    if not os.path.isfile(p):
        return None
    try:
        with gzip.open(p, "rb") as f:
            raw = f.read()
        root = parse_nbt(raw)
    except Exception:
        return None
    data = root.get("Data") or root.get("data") or {}
    seed = data.get("Seed")
    if seed is None:
        wgs = data.get("WorldGenSettings") or {}
        seed = wgs.get("seed")
    if seed is None:
        return None
    try:
        return int(seed)
    except Exception:
        return None


# ---------- NBT ----------
def _read_tag(data, pos, tag_type):
    """读一个 tag 的值，返回 (value, 新位置)。"""
    if tag_type == 1:
        return struct.unpack(">b", data[pos:pos + 1])[0], pos + 1
    if tag_type == 2:
        return struct.unpack(">h", data[pos:pos + 2])[0], pos + 2
    if tag_type == 3:
        return struct.unpack(">i", data[pos:pos + 4])[0], pos + 4
    if tag_type == 4:
        return struct.unpack(">q", data[pos:pos + 8])[0], pos + 8
    if tag_type == 5:
        return struct.unpack(">f", data[pos:pos + 4])[0], pos + 4
    if tag_type == 6:
        return struct.unpack(">d", data[pos:pos + 8])[0], pos + 8
    if tag_type == 7:
        n = struct.unpack(">i", data[pos:pos + 4])[0]
        pos += 4
        return list(data[pos:pos + n]), pos + n
    if tag_type == 8:
        n = struct.unpack(">h", data[pos:pos + 2])[0]
        pos += 2
        return data[pos:pos + n].decode("utf-8", "replace"), pos + n
    if tag_type == 9:
        inner = struct.unpack(">b", data[pos + 0:pos + 1])[0]
        n = struct.unpack(">i", data[pos + 1:pos + 5])[0]
        pos += 5
        out = []
        for _ in range(max(0, n)):
            v, pos = _read_tag(data, pos, inner)
            out.append(v)
        return out, pos
    if tag_type == 10:
        out = {}
        while True:
            t = struct.unpack(">b", data[pos:pos + 1])[0]
            pos += 1
            if t == 0:
                return out, pos
            nlen = struct.unpack(">h", data[pos:pos + 2])[0]
            pos += 2
            name = data[pos:pos + nlen].decode("utf-8", "replace")
            pos += nlen
            v, pos = _read_tag(data, pos, t)
            out[name] = v
    if tag_type == 11:
        n = struct.unpack(">i", data[pos:pos + 4])[0]
        pos += 4
        out = []
        for _ in range(max(0, n)):
            out.append(struct.unpack(">i", data[pos:pos + 4])[0])
            pos += 4
        return out, pos
    if tag_type == 12:
        n = struct.unpack(">i", data[pos:pos + 4])[0]
        pos += 4
        out = []
        for _ in range(max(0, n)):
            out.append(struct.unpack(">q", data[pos:pos + 8])[0])
            pos += 8
        return out, pos
    raise ValueError("unknown tag %d" % tag_type)


def parse_nbt(raw):
    pos = 0
    t = struct.unpack(">b", raw[pos:pos + 1])[0]
    pos += 1
    if t == 0:
        return {}
    nlen = struct.unpack(">h", raw[pos:pos + 2])[0]
    pos += 2
    pos += nlen
    val, _ = _read_tag(raw, pos, t)
    return val if isinstance(val, dict) else {}


def read_chunk(nbt_root):
    """从一个区块 NBT 里取出 {(gx,gz): biome} 和区块坐标。"""
    x = nbt_root.get("xPos")
    z = nbt_root.get("zPos")
    if "sections" in nbt_root:
        return _biomes_modern(nbt_root, x, z), x, z
    lvl = nbt_root.get("Level") or nbt_root.get("level") or {}
    if lvl and ("Biomes" in lvl or "biomes" in lvl):
        return _biomes_legacy(lvl, x, z), x, z
    return None, x, z


def _unpack_longs(longs, bits, count):
    """把打包的 long 数组按 bits 宽度解出来。"""
    if not longs or count <= 0:
        return []
    out = []
    mask = (1 << bits) - 1
    total_bits = len(longs) * 64
    for i in range(min(count, total_bits // bits)):
        start = i * bits
        li = start // 64
        off = start % 64
        v = longs[li] & 0xFFFFFFFFFFFFFFFF
        if off + bits > 64:
            nxt = longs[li + 1] & 0xFFFFFFFFFFFFFFFF if li + 1 < len(longs) else 0
            v = (v >> off) | (nxt << (64 - off))
            out.append(v & mask)
        else:
            out.append((v >> off) & mask)
    return out


def _biomes_modern(root, cx, cz):
    sections = root.get("sections") or []
    heights = root.get("Heightmaps") or root.get("heightmaps") or {}
    surf = heights.get("WORLD_SURFACE") or heights.get("WORLD_SURFACE_WG") or []
    surface = _unpack_longs(surf, 9, 256) if surf else []
    # 每个 section 的 4x4x4 生物群系，按 Y 建表
    sec = {}
    for s in sections:
        try:
            sy = int(s.get("Y"))
        except Exception:
            continue
        b = s.get("biomes") or s.get("Biomes")
        if not isinstance(b, dict):
            continue
        pal = b.get("palette") or b.get("Palette") or []
        d = b.get("data") or b.get("Data")
        names = []
        for p in pal:
            if isinstance(p, str):
                names.append(p)
            elif isinstance(p, dict):
                names.append(p.get("value") or p.get("Name") or "")
            else:
                names.append(str(p))
        if not names:
            continue
        sec[sy] = (names, d)
    out = {}
    for i in range(256):
        lx, lz = i % 16, i // 16
        h = surface[i] if i < len(surface) else 63
        sy = max(-4, min(19, (h >> 4) if h > -64 else 0))
        entry = sec.get(sy)
        if not entry and sec:
            entry = sec[max(sec)]
        if not entry:
            continue
        names, d = entry
        if d:
            bits = max(1, (len(names) - 1).bit_length())
            data = _unpack_longs(d, bits, 64)
            x4, z4 = lx // 4, lz // 4
            y4 = max(0, min(3, (h % 16) // 4))
            idx = (y4 * 4 + z4) * 4 + x4
            bi = data[idx] if idx < len(data) else 0
        else:
            bi = 0
        out[(cx * 16 + lx, cz * 16 + lz)] = names[bi] if bi < len(names) else names[0]
    return out


def _biomes_legacy(lvl, cx, cz):
    arr = lvl.get("Biomes") or lvl.get("biomes") or []
    if not arr:
        return None
    out = {}
    for i in range(256):
        lx, lz = i % 16, i // 16
        try:
            bid = arr[i]
        except Exception:
            break
        out[(cx * 16 + lx, cz * 16 + lz)] = ("id:%d" % bid)
    return out


def read_region_file(path):
    """读一个 mca，返回 {(cx,cz): {(gx,gz): biome}}。"""
    chunks = {}
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return chunks
    if len(data) < 4096:
        return chunks
    for i in range(1024):
        off = struct.unpack(">I", data[i * 4:(i + 1) * 4])[0]
        if off == 0:
            continue
        sector = (off >> 8) * 4096
        if sector + 5 > len(data):
            continue
        length = struct.unpack(">I", data[sector:sector + 4])[0]
        comp = data[sector + 4]
        raw = data[sector + 5:sector + 4 + length]
        try:
            if comp == 2:
                raw = zlib.decompress(raw)
            elif comp == 1:
                import gzip
                raw = gzip.decompress(raw)
            elif comp != 3:
                continue
        except Exception:
            continue
        try:
            root = parse_nbt(raw)
        except Exception:
            continue
        got, cx, cz = read_chunk(root)
        if not got:
            continue
        if cx is None or cz is None:
            cx, cz = xz_from_index(i)
        chunks[(cx, cz)] = got
    return chunks


def xz_from_index(i):
    return (i % 32, i // 32)


def region_coords(path):
    """从 r.X.Z.mca 文件名里拿区域坐标。"""
    name = os.path.basename(path)
    try:
        parts = name.split(".")[1:]
        return int(parts[0]), int(parts[1])
    except Exception:
        return 0, 0


def scan_world(world_dir, max_regions=24):
    """扫存档 region 目录，返回 {(gx,gz): biome} 与统计。"""
    rdir = os.path.join(world_dir, "region")
    if not os.path.isdir(rdir):
        return {}, {"chunks": 0, "regions": 0, "biomes": []}
    files = [f for f in os.listdir(rdir)
             if f.startswith("r.") and f.endswith(".mca")]
    files.sort()
    files = files[:max_regions]
    result = {}
    biomes = set()
    for name in files:
        rx, rz = region_coords(name)
        chunks = read_region_file(os.path.join(rdir, name))
        for (cx, cz), cols in chunks.items():
            gx0, gz0 = (rx * 32 + cx) * 16, (rz * 32 + cz) * 16
            for (gx, gz), biome in cols.items():
                result[(gx, gz)] = biome
                biomes.add(biome)
    return result, {"chunks": len(result), "regions": len(files),
                    "biomes": sorted(biomes)}


def render_png(grid, out_png, scale=1):
    """把 {(gx,gz): biome} 画成 PNG，返回 (宽, 高, 命中像素数)。"""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QColor, QImage
    if not grid:
        return 0, 0, 0
    xs = [p[0] for p in grid]
    zs = [p[1] for p in grid]
    x0, x1 = min(xs), max(xs)
    z0, z1 = min(zs), max(zs)
    w, h = x1 - x0 + 1, z1 - z0 + 1
    img = QImage(w, h, QImage.Format_RGB32)
    img.fill(QColor(*UNKNOWN_COLOR))
    for (gx, gz), biome in grid.items():
        img.setPixel(gx - x0, gz - z0, QColor(*color_for(biome)).rgb())
    if scale != 1:
        img = img.scaled(w * scale, h * scale, Qt.IgnoreAspectRatio,
                         Qt.FastTransformation)
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    img.save(out_png, "PNG")
    return w, h, len(grid)
