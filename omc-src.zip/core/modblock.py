# -*- coding: utf-8 -*-
"""模组黑名单：~/.simple_mc_launcher/mod_blacklist.json

{"v": 1, "names": ["xxx.jar"], "patterns": ["*hack*"]}
names 精确匹配文件名（不分大小写），patterns 用 fnmatch 通配。
"""
import fnmatch
import json
import os


def store_path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "mod_blacklist.json")


def _read():
    p = store_path()
    if not os.path.isfile(p):
        return {"v": 1, "names": [], "patterns": []}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("names", [])
        data.setdefault("patterns", [])
        return data
    except Exception:
        return {"v": 1, "names": [], "patterns": []}


def _write(data):
    p = store_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def names():
    return list(_read().get("names") or [])


def patterns():
    return list(_read().get("patterns") or [])


def add_name(name):
    name = (name or "").strip()
    if not name:
        return False, "名字不能空"
    data = _read()
    low = [n.lower() for n in data["names"]]
    if name.lower() in low:
        return False, "已经在黑名单里了"
    data["names"].append(name)
    _write(data)
    return True, "已加入黑名单"


def add_pattern(pat):
    pat = (pat or "").strip()
    if not pat:
        return False, "规则不能空"
    data = _read()
    if pat.lower() in [p.lower() for p in data["patterns"]]:
        return False, "已经有这条规则了"
    data["patterns"].append(pat)
    _write(data)
    return True, "已加入黑名单"


def remove(name):
    data = _read()
    low = (name or "").strip().lower()
    data["names"] = [n for n in data["names"] if n.lower() != low]
    data["patterns"] = [p for p in data["patterns"] if p.lower() != low]
    _write(data)
    return True, "已移出黑名单"


def blocked(filename):
    """命中黑名单返回命中的那条规则，否则 None。"""
    fn = os.path.basename(filename or "")
    if not fn:
        return None
    low = fn.lower()
    for n in names():
        if n.lower() == low:
            return n
    for p in patterns():
        if fnmatch.fnmatch(low, p.lower()):
            return p
    return None


def filter_paths(paths):
    """把路径列表拆成 (允许的, [(路径, 命中规则)])。"""
    ok_list, bad = [], []
    for p in paths:
        hit = blocked(p)
        if hit:
            bad.append((p, hit))
        else:
            ok_list.append(p)
    return ok_list, bad
