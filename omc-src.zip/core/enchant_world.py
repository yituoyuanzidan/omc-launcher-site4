# -*- coding: utf-8 -*-
"""从存档里读出玩家的 XP 种子（RNG 附魔预测要用）。

种子存在 playerdata/<uuid>.dat 的 `XpSeed` 里（1.16 之后改名为 `XpSeed`；
老版本叫 `XpSeed` 也一样，都是同一个 32 位整数）。只需要读，不改存档。
"""
import gzip
import os
import struct
import time

TAG_END = 0
TAG_BYTE = 1
TAG_SHORT = 2
TAG_INT = 3
TAG_LONG = 4
TAG_FLOAT = 5
TAG_DOUBLE = 6
TAG_BYTE_ARRAY = 7
TAG_STRING = 8
TAG_LIST = 9
TAG_COMPOUND = 10
TAG_INT_ARRAY = 11
TAG_LONG_ARRAY = 12


class _Reader(object):
    def __init__(self, raw):
        self.b = raw
        self.i = 0

    def u1(self):
        v = self.b[self.i]
        self.i += 1
        return v

    def i2(self):
        v = struct.unpack(">h", self.b[self.i:self.i + 2])[0]
        self.i += 2
        return v

    def i4(self):
        v = struct.unpack(">i", self.b[self.i:self.i + 4])[0]
        self.i += 4
        return v

    def i8(self):
        v = struct.unpack(">q", self.b[self.i:self.i + 8])[0]
        self.i += 8
        return v

    def name(self):
        n = self.i2()
        end = self.i + n
        s = self.b[self.i:end].decode("utf-8", "replace")
        self.i = end
        return s

    def value(self, t, out, depth=0):
        if t == TAG_BYTE:
            return self.u1() if self.b[self.i] < 128 else self.u1() - 256
        if t == TAG_SHORT:
            return self.i2()
        if t == TAG_INT:
            return self.i4()
        if t == TAG_LONG:
            return self.i8()
        if t == TAG_FLOAT:
            v = struct.unpack(">f", self.b[self.i:self.i + 4])[0]
            self.i += 4
            return v
        if t == TAG_DOUBLE:
            v = struct.unpack(">d", self.b[self.i:self.i + 8])[0]
            self.i += 8
            return v
        if t == TAG_BYTE_ARRAY:
            n = self.i4()
            self.i += n
            return b""
        if t == TAG_STRING:
            return self.name()
        if t == TAG_LIST:
            et = self.u1()
            n = self.i4()
            items = []
            for _ in range(min(n, 4096)):
                items.append(self.value(et, out, depth + 1))
            return items
        if t == TAG_COMPOUND:
            if depth > 12:
                raise ValueError("NBT 太深")
            d = {}
            while True:
                et = self.u1()
                if et == TAG_END:
                    return d
                key = self.name()
                d[key] = self.value(et, out, depth + 1)
                if key in ("XpSeed", "XpLevel", "enchantment_seed", "Score",
                           "SelectedItemSlot") and not isinstance(d[key], (dict, list)):
                    out[key] = d[key]
        if t == TAG_INT_ARRAY:
            n = self.i4()
            self.i += 4 * n
            return []
        if t == TAG_LONG_ARRAY:
            n = self.i4()
            self.i += 8 * n
            return []
        raise ValueError("未知 NBT 类型 %r" % t)


def read_nbt_fields(path, limit_bytes=64 << 20):
    """读一个 .dat（gzip 压缩的 NBT），返回想找的几个顶层附近字段。"""
    size = os.path.getsize(path)
    if size > limit_bytes:
        raise ValueError("文件太大")
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    r = _Reader(raw)
    root_type = r.u1()
    root_name = r.name()
    out = {}
    r.value(root_type, out)
    return out


def saves_dirs(game_dir=None):
    """列出所有可能有 saves 的目录，按优先级排。"""
    dirs = []
    if game_dir:
        dirs.append(os.path.join(game_dir, "saves"))
    appdata = os.environ.get("APPDATA")
    if appdata:
        dirs.append(os.path.join(appdata, ".minecraft", "saves"))
    user = os.environ.get("USERPROFILE")
    if user:
        dirs.append(os.path.join(user, ".minecraft", "saves"))
        dirs.append(os.path.join(user, "Desktop", ".minecraft", "saves"))
    out = []
    seen = set()
    for d in dirs:
        d = os.path.abspath(d)
        if d.lower() in seen:
            continue
        seen.add(d.lower())
        if os.path.isdir(d):
            out.append(d)
    return out


def list_worlds(saves_dir):
    """存档目录下的所有带 level.dat 的文件夹。"""
    res = []
    if not os.path.isdir(saves_dir):
        return res
    for name in sorted(os.listdir(saves_dir)):
        path = os.path.join(saves_dir, name)
        if os.path.isdir(path) and os.path.exists(os.path.join(path, "level.dat")):
            res.append(path)
    return res


def read_world_seeds(world_dir):
    """读某存档里每个玩家文件（按最近修改排）的 XP 种子。"""
    pd = os.path.join(world_dir, "playerdata")
    out = []
    if not os.path.isdir(pd):
        return out
    for fn in os.listdir(pd):
        if not fn.endswith(".dat"):
            continue
        path = os.path.join(pd, fn)
        try:
            fields = read_nbt_fields(path)
            seed = fields.get("XpSeed", fields.get("enchantment_seed"))
            if seed is None:
                continue
            out.append({
                "file": path,
                "uuid": fn[:-4],
                "xseed": int(seed),
                "xp_level": int(fields.get("XpLevel", 0) or 0),
                "mtime": os.path.getmtime(path),
            })
        except Exception:
            continue
    out.sort(key=lambda d: -d["mtime"])
    return out


def latest_world_seed(world_dir):
    """这个存档里最近登录的那个玩家的种子（单人档通常只有一个）。"""
    seeded = read_world_seeds(world_dir)
    return seeded[0] if seeded else None


def scan_all(game_dir=None):
    """一次扫完所有常见存档目录，返回 [(world_dir, [seed info])]。"""
    res = []
    for sd in saves_dirs(game_dir):
        for w in list_worlds(sd):
            seeds = read_world_seeds(w)
            if seeds:
                res.append((w, seeds))
    return res


def seed_age_text(mtime):
    """存档多久以前被写，用来判断种子还有没有效。"""
    dt = time.time() - mtime
    if dt < 60:
        return "刚刚"
    if dt < 3600:
        return "%d 分钟前" % int(dt // 60)
    if dt < 86400:
        return "%d 小时前" % int(dt // 3600)
    return "%d 天前" % int(dt // 86400)
