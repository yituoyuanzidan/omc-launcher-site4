# -*- coding: utf-8 -*-
"""HTTP 工具：基于标准库 urllib，支持进度回调、重试、镜像地址替换、完整性校验。"""
import hashlib
import json
import os
import ssl
import time
import re
import urllib.request
import urllib.error

USER_AGENT = "SimpleMCLauncher/1.0"

import http.client
import threading
import urllib.parse
from urllib.parse import urlsplit

_LOCAL = threading.local()


def _conn_pool():
    pool = getattr(_LOCAL, "pool", None)
    if pool is None:
        pool = {}
        _LOCAL.pool = pool
    return pool


def _drop_conn(netloc):
    conn = _conn_pool().pop(netloc, None)
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass


def _get_conn(netloc, timeout):
    pool = _conn_pool()
    conn = pool.get(netloc)
    if conn is None:
        conn = http.client.HTTPSConnection(netloc, timeout=timeout,
                                           context=ssl_context())
        pool[netloc] = conn
    else:
        conn.timeout = timeout
    return conn


def _stream_get(url, timeout, headers=None):
    """用线程内复用的 keep-alive 连接发起 GET，减少握手开销。

    任何一步失败都要把这个连接从池里摘掉：连接复用最怕把「请求已发出、
    响应没收到」的半死连接留在池里，后面的请求会一直报 Request-sent。
    """
    parts = urlsplit(url)
    netloc = parts.netloc
    path = parts.path + ("?" + parts.query if parts.query else "")
    conn = _get_conn(netloc, timeout)
    h = {"User-Agent": USER_AGENT, "Connection": "keep-alive"}
    if headers:
        h.update(headers)
    try:
        conn.request("GET", path, headers=h)
        return netloc, conn.getresponse()
    except Exception:
        _drop_conn(netloc)
        raise


_SSL_CTX = None
_SSL_LOCK = threading.Lock()


def ssl_context():
    """优先使用 certifi 的 CA，缺失时回退系统默认证书。

    上下文只建一次：Windows 上 create_default_context 要读系统证书库，
    每次请求都新建会让登录 / 扫码这种小请求也白等几百毫秒。
    """
    global _SSL_CTX
    if _SSL_CTX is not None:
        return _SSL_CTX
    with _SSL_LOCK:
        if _SSL_CTX is None:
            try:
                import certifi
                _SSL_CTX = ssl.create_default_context(cafile=certifi.where())
            except Exception:
                _SSL_CTX = ssl.create_default_context()
    return _SSL_CTX


def ctx_for(url):
    """只有 https 才需要 SSL 上下文，http（自建站、本地服务）直接跳过。"""
    return ssl_context() if url.lower().startswith("https") else None


OFFICIAL_HOSTS = {
    "https://launchermeta.mojang.com": "https://bmclapi2.bangbang93.com",
    "https://piston-meta.mojang.com": "https://bmclapi2.bangbang93.com",
    "https://piston-data.mojang.com": "https://bmclapi2.bangbang93.com",
    "https://libraries.minecraft.net": "https://bmclapi2.bangbang93.com/maven",
    "https://maven.fabricmc.net": "https://bmclapi2.bangbang93.com/maven",
    "https://maven.neoforged.net/releases": "https://bmclapi2.bangbang93.com/maven",
    "https://resources.download.minecraft.net": "https://bmclapi2.bangbang93.com/assets",
    "https://meta.fastmirror.net": "https://bmclapi2.bangbang93.com",
}


def rewrite_url(url, mirror):
    if mirror != "bmcl":
        return url
    for old, new in OFFICIAL_HOSTS.items():
        if url.startswith(old):
            return new + url[len(old):]
    return url


def _candidates(url, mirror):
    """一次请求的候选地址：首选镜像/官方，失败再换另一边兜底。"""
    primary = rewrite_url(url, mirror)
    out = [primary]
    if mirror == "bmcl":
        if primary != url:
            out.append(url)          # 国内镜像连不上时回官方
    else:
        mirrored = rewrite_url(url, "bmcl")
        if mirrored != url:
            out.append(mirrored)     # 官方慢/被重置时走国内镜像
    return out


def _read_url(url, mirror="bmcl", timeout=15, retries=2, headers=None):
    """读一段文本/JSON：连接复用 + 短超时 + 候选地址 + 重试。

    「加载不出来」多数是连接被中途重置（WinError 10054 / SSL EOF），
    重一次并把 keep-alive 连接丢掉重建，成功率会明显提高。

    headers：额外的请求头（比如清单请求要带 Cache-Control: no-cache）。
    """
    last = None
    for cand in _candidates(url, mirror):
        for attempt in range(retries):
            netloc = None
            try:
                if not cand.startswith("https://"):
                    with open_url(cand, "official", timeout,
                                  headers=headers) as resp:
                        data = resp.read()
                    if data:
                        return data
                    raise RuntimeError("空响应")
                netloc, resp = _stream_get(cand, timeout, headers=headers)
                status = getattr(resp, "status", 200)
                if status >= 400:
                    _drop_conn(netloc)
                    raise RuntimeError("HTTP %s" % status)
                data = resp.read()
                if not data:
                    raise RuntimeError("空响应")
                return data
            except Exception as e:
                last = e
                if netloc:
                    _drop_conn(netloc)
                time.sleep(0.3 * (attempt + 1))
        # keep-alive 连接传大响应时偶尔会被中途掐断（版本清单 270KB 很常见），
        # 再给一次全新连接的机会
        try:
            with open_url(cand, "official", timeout + 3,
                          headers=headers) as resp:
                data = resp.read()
            if data:
                return data
            last = RuntimeError("空响应")
        except Exception as e:
            last = e
    raise last if last else RuntimeError("请求失败")


def open_url(url, mirror="bmcl", timeout=30, headers=None):
    real = rewrite_url(url, mirror)
    h = {"User-Agent": USER_AGENT}
    if headers:
        h.update(headers)
    req = urllib.request.Request(real, headers=h)
    return urllib.request.urlopen(req, timeout=timeout,
                                  context=ctx_for(real))


def fetch_json(url, mirror="bmcl", timeout=15, retries=2):
    return json.loads(_read_url(url, mirror, timeout, retries).decode("utf-8"))


def post_json(url, payload, timeout=20, mirror="bmcl", retries=2):
    """POST JSON 并解析响应。

    4xx 是业务错误（比如账号密码不对），不重试，直接把服务端给的
    errorMessage 原话抛出来 —— 用户看到「密码不对」比看到「HTTP 403」有用。
    """
    data = json.dumps(payload).encode("utf-8")
    last = None
    for attempt in range(retries):
        real = rewrite_url(url, mirror)
        try:
            req = urllib.request.Request(
                real, data=data,
                headers={"User-Agent": USER_AGENT,
                         "Content-Type": "application/json",
                         "Accept": "application/json"},
                method="POST")
            with urllib.request.urlopen(req, timeout=timeout,
                                        context=ctx_for(real)) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            msg = ""
            try:
                body = e.read().decode("utf-8", "replace")
                j = json.loads(body)
                msg = j.get("errorMessage") or j.get("message") or ""
            except Exception:
                msg = ""
            if 400 <= e.code < 500:
                raise RuntimeError(msg or ("服务器返回 HTTP %s" % e.code))
            last = e
            time.sleep(0.3 * (attempt + 1))
        except Exception as e:
            last = e
            time.sleep(0.3 * (attempt + 1))
    raise last


def fetch_text(url, mirror="bmcl", timeout=15, retries=2):
    return _read_url(url, mirror, timeout, retries).decode(
        "utf-8", errors="replace")


def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _file_ok(path, size=None, sha1=None):
    """判断已存在的文件是否真的完整。"""
    if not os.path.exists(path):
        return False
    if size is not None and os.path.getsize(path) != size:
        return False
    if sha1:
        try:
            return sha1_of(path).lower() == sha1.lower()
        except Exception:
            return False
    return os.path.getsize(path) > 0


def _resolve_redirect(url, timeout=10):
    """把短链/302 解析成真实地址。

    _stream_get 用 http.client 直连，不会自动跟随跳转，
    所以下载前先走一遍 urllib（它默认跟随 302）拿到最终 URL。
    """
    if not url or not url.startswith("https://"):
        return url
    try:
        req = urllib.request.Request(
            url, method="HEAD", headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            real = resp.geturl()
        if real and real.startswith("https://"):
            return real
    except Exception:
        pass
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        resp = urllib.request.urlopen(req, timeout=timeout)
        real = resp.geturl()
        resp.close()
        if real and real.startswith("https://"):
            return real
    except Exception:
        pass
    return url


def _download_once(url, tmp, progress, size, sha1, timeout):
    """下载一次到 tmp 并校验。

    返回空串表示已完成；返回非空字符串表示服务器给了跳转，调用方跟过去重下。
    """
    netloc, resp = _stream_get(url, timeout)
    try:
        status = getattr(resp, "status", 200)
        if status in (301, 302, 303, 307, 308):
            return resp.headers.get("Location") or ""
        if status not in (200, 206):
            raise RuntimeError("HTTP %s" % status)
        total = int(resp.headers.get("Content-Length") or 0)
        received = 0
        with open(tmp, "wb") as f:
            while True:
                chunk = resp.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
                received += len(chunk)
                if progress:
                    progress(received, total)
    finally:
        try:
            _drop_conn(netloc)
        except Exception:
            pass

    got = os.path.getsize(tmp)
    if size is not None and got != size:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RuntimeError("大小不符：期望 %d，实际 %d" % (size, got))
    if sha1 and sha1_of(tmp).lower() != sha1.lower():
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RuntimeError("SHA1 校验失败")
    return ""


def download_file(url, dest, mirror="bmcl", progress=None, retries=4,
                  size=None, sha1=None, timeout=120, multi=None):
    """下载到目标路径并校验完整性；失败自动重试。

    不再对每个直链先发 HEAD（那会多两个往返），只有真收到 3xx 才跟随跳转。
    multi 控制「是否先试多连接分块」：None=按大小自动（已知 ≥8MB 才试），
    True=强制试，False=只走单连接（调用方自己已经在并发下载时用 False，
    否则 24 路 × 6 分块会把连接数打爆，反而被服务器限速）。
    """
    if multi is None:
        multi = bool(size and size >= AUTO_MULTI_MIN)
    if multi:
        try:
            if download_file_multi(url, dest, mirror=mirror, progress=progress,
                                   size=size, sha1=sha1, retries=1,
                                   timeout=min(timeout, 60)):
                return True
        except Exception:
            # 服务器不支持 Range、探测失败、分块被限速：退回单连接，别报错给用户
            pass
    final_url = rewrite_url(url, mirror)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    last_err = None

    for attempt in range(retries):
        try:
            hops = 0
            while True:
                href = _download_once(final_url, tmp, progress, size, sha1,
                                      timeout)
                if not href:
                    os.replace(tmp, dest)
                    return True
                hops += 1
                if hops > 8:
                    raise RuntimeError("跳转次数过多")
                final_url = urllib.parse.urljoin(final_url, href)
        except Exception as e:
            last_err = e
            time.sleep(0.4 + attempt * 1.2)

    if os.path.exists(tmp) and size and os.path.getsize(tmp) == size:
        os.replace(tmp, dest)
        return True
    raise RuntimeError("下载失败：%s（%s）" % (final_url, last_err))


# ------------------- 多连接分块下载（大包提速） -------------------

AUTO_MULTI_MIN = 8 << 20     # 8MB 以上才值得开多连接
RE_CONTENT_RANGE = re.compile(r"bytes\s+\d+-\d+/(\d+)", re.I)


def _probe(url, timeout):
    """探长度和是否支持 Range，同时拿到 302 之后的真实地址。"""
    req = urllib.request.Request(
        url, headers={"User-Agent": USER_AGENT, "Range": "bytes=0-0"})
    with urllib.request.urlopen(req, timeout=timeout,
                                context=ctx_for(url)) as r:
        final = r.geturl()
        status = getattr(r, "status", 200)
        cr = r.headers.get("Content-Range") or ""
        cl = int(r.headers.get("Content-Length") or 0)
        total = 0
        m = RE_CONTENT_RANGE.match(cr) if cr else None
        if m:
            total = int(m.group(1))
        elif cl and status == 200:
            total = cl
        r.read(8192)
    return final, total, (status == 206 and total > 0)


def _chunk_worker(final, start, end, path, counter, lock, total, progress,
                  timeout, buf):
    req = urllib.request.Request(
        final, headers={"User-Agent": USER_AGENT,
                        "Range": "bytes=%d-%d" % (start, end)})
    with urllib.request.urlopen(req, timeout=timeout,
                                context=ctx_for(final)) as r:
        if getattr(r, "status", 200) != 206:
            raise RuntimeError("服务器不支持分块：HTTP %s" % getattr(r, "status", 0))
        with open(path, "wb") as f:
            while True:
                data = r.read(buf)
                if not data:
                    break
                f.write(data)
                with lock:
                    counter[0] += len(data)
                    done = counter[0]
                if progress:
                    progress(done, total)


def download_file_multi(url, dest, mirror="bmcl", progress=None, parts=6,
                        timeout=60, size=None, sha1=None, retries=2):
    """多连接并行分块下载同一个文件，走 Range。

    大文件（更新包 60MB+）单连接经常只有几十 KB/s，开 4-6 路能明显提速；
    服务器不支持 Range 或探测失败时抛异常，由调用方回退单连接下载。
    """
    final_url = rewrite_url(url, mirror)
    os.makedirs(os.path.dirname(dest), exist_ok=True)

    for attempt in range(retries):
        final, total, ranged = _probe(final_url, timeout)
        if not total:
            raise RuntimeError("探测不到文件大小")
        if not ranged:
            raise RuntimeError("服务器不支持 Range")
        if size is not None and total != size:
            raise RuntimeError("大小不符：期望 %d，服务器 %d" % (size, total))

        n = max(1, min(int(parts or 6), 8))
        # 太小的文件没必要并行
        if total < 4 << 20:
            n = 1
        step = (total + n - 1) // n
        spans = []
        for i in range(n):
            s = i * step
            e = min(total - 1, s + step - 1)
            if s > e:
                break
            spans.append((s, e, dest + ".p%d" % i))

        counter = [0]
        lock = threading.Lock()
        errors = []
        last_emit = [0]

        def cb(done, tot):
            # 6 个线程每 64KB 回一次会把主线程刷爆，节流到 512KB 或 1%
            with lock:
                if done - last_emit[0] < 524288 and done < tot:
                    return
                last_emit[0] = done
            if progress:
                progress(done, tot)

        threads = []
        for s, e, path in spans:
            t = threading.Thread(
                target=_guard, args=(errors, _chunk_worker, final, s, e, path,
                                     counter, lock, total, cb, timeout,
                                     1 << 16),
                daemon=True)
            t.start()
            threads.append(t)
        for t in threads:
            t.join()

        if errors:
            for _s, _e, path in spans:
                try:
                    os.remove(path)
                except OSError:
                    pass
            if attempt + 1 >= retries:
                raise RuntimeError("分块下载失败：%s" % errors[0])
            time.sleep(1.0 + attempt * 2)
            continue

        with open(dest + ".part", "wb") as out:
            for _s, _e, path in spans:
                with open(path, "rb") as f:
                    while True:
                        data = f.read(1 << 20)
                        if not data:
                            break
                        out.write(data)
                try:
                    os.remove(path)
                except OSError:
                    pass
        got = os.path.getsize(dest + ".part")
        if got != total:
            try:
                os.remove(dest + ".part")
            except OSError:
                pass
            raise RuntimeError("拼接后大小不符：%d / %d" % (got, total))
        if sha1 and sha1_of(dest + ".part").lower() != sha1.lower():
            try:
                os.remove(dest + ".part")
            except OSError:
                pass
            raise RuntimeError("SHA1 校验失败")
        os.replace(dest + ".part", dest)
        return True
    return False


def _guard(errors, fn, *args):
    try:
        fn(*args)
    except Exception as e:
        errors.append(e)
