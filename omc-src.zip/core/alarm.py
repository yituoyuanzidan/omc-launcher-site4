# -*- coding: utf-8 -*-
"""闹钟 / 计时器 / 秒表的数据与时间计算（纯逻辑，不碰界面）。

需求里「时间精确到小数点后两位」= 精确到 0.01 秒，所以这里一律用
从 1970 起的 float 秒来算，界面再用 "时:分:秒.百分" 显示。
"""
import json
import os
import time

FILE = "alarm.json"

BUILTIN_RINGS = [
    ("Ding", "叮（系统提示）"),
    ("Alarm01", "系统闹钟"),
    ("Alarm02", "系统铃声"),
    ("Windows Notify", "Windows 通知"),
    ("Ring01", "电话铃"),
]
_DAY_CN = ["一", "二", "三", "四", "五", "六", "日"]


def _path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, FILE)


def _blank():
    return {"ring": "Ding", "custom_ring": "", "volume": 80,
            "alarms": [], "timers": [], "last_id": 0}


def load():
    try:
        with open(_path(), encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            return _blank()
    except Exception:
        return _blank()
    base = _blank()
    base.update({k: v for k, v in d.items() if k in base})
    for k in ("alarms", "timers"):
        if not isinstance(base.get(k), list):
            base[k] = []
    return base


def save(data):
    p = _path()
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass


def new_id(data=None):
    d = data or load()
    n = int(d.get("last_id") or 0) + 1
    d["last_id"] = n
    return n


# ---------- 格式化 ----------
def fmt_clock(sec, show_hundred=True):
    """秒 → 时:分:秒.百分（不足一小时就不显示小时）。"""
    sec = max(0.0, float(sec or 0))
    h = int(sec // 3600)
    m = int((sec - h * 3600) // 60)
    s = sec - h * 3600 - m * 60
    if show_hundred:
        if h:
            return "%02d:%02d:%05.2f" % (h, m, s)
        return "%02d:%05.2f" % (m, s)
    if h:
        return "%02d:%02d:%02d" % (h, m, int(s))
    return "%02d:%02d" % (m, int(s))


def fmt_hms(h, m, s, frac=0):
    return "%02d:%02d:%02d.%02d" % (int(h), int(m), int(s), int(frac))


def parse_hms(text):
    """"7:30:00.50" / "07:30" / "30.5" → 秒（float）。解析不了返回 None。"""
    t = (text or "").strip().replace("：", ":")
    if not t:
        return None
    try:
        parts = t.split(":")
        if len(parts) == 1:
            return float(parts[0])
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        if len(parts) == 3:
            return (int(parts[0]) * 3600 + int(parts[1]) * 60
                    + float(parts[2]))
    except Exception:
        return None
    return None


def parse_clock(text):
    """"7:30:00.50" → (h, m, s, frac)；不能解析返回 None。"""
    t = (text or "").strip().replace("：", ":")
    if not t:
        return None
    try:
        parts = t.split(":")
        if len(parts) == 2:
            h, m, sec = 0, int(parts[0]), float(parts[1])
        elif len(parts) == 3:
            h, m, sec = int(parts[0]), int(parts[1]), float(parts[2])
        else:
            return None
    except Exception:
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59 and 0 <= sec < 60):
        return None
    frac = int(round((sec - int(sec)) * 100))
    if frac > 99:
        frac = 99
    return h, m, int(sec), frac


def next_fire(alarm, now=None, look_back=0.0):
    """这条闹钟下一次触发的 unix 时间（float，0.01 精度）。永不触发返回 0。

    look_back：允许返回「刚刚已经过去不到 look_back 秒」的那一次。
    判定循环靠它才不会错过到点瞬间（否则时间一过就只返回明天）。
    """
    now = time.time() if now is None else now
    if not alarm or not alarm.get("on", True):
        return 0
    h = int(alarm.get("hour", 0))
    m = int(alarm.get("minute", 0))
    s = int(alarm.get("second", 0))
    frac = int(alarm.get("frac", 0))
    days = alarm.get("days") or []
    lt = time.localtime(now)
    # 当天零点的近似；跨夏令时会有几十秒偏差，闹钟这个精度上够用
    base0 = now - (lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec
                   + (now - int(now)))
    for step in range(0, 9):
        ts = base0 + step * 86400 + h * 3600 + m * 60 + s + frac / 100.0
        if ts < now - look_back:
            continue
        if days:
            if time.localtime(ts).tm_wday not in days:
                continue
        return ts
    return 0


def day_text(days):
    if not days:
        return "只响一次"
    if len(days) == 7:
        return "每天"
    return "周" + "、".join(_DAY_CN[d] for d in sorted(days) if 0 <= d < 7)


def snooze_minutes(alarm):
    try:
        return max(1, min(60, int(alarm.get("snooze", 5))))
    except Exception:
        return 5
