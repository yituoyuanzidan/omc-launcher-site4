# -*- coding: utf-8 -*-
"""附魔计算内核：铁砧并书（Anvil）+ 附魔台摆法（Table）。

数值全部来自 Java 1.21 官方附魔数据包
（data/minecraft/enchantment/*.json：min_cost / max_cost / anvil_cost / weight /
 max_level / supported_items），规则取自 Wiki《Anvil mechanics》《Enchanting mechanics》。

铁砧：
  单次成本 = 牺牲件（右槽，按合并后等级）的附魔价值 + 左件惩罚 + 右件惩罚
  附魔价值 = 最终等级 × 倍率（书当牺牲用书倍率，物品之间直接用物品倍率）
  倍率 = anvil_cost（书 = ceil(anvil_cost / 2)，最低 1）
  惩罚 = 2^c − 1，c = 该件在铁砧左槽被用过的次数；合并后 c = max(c左, c右) + 1
  单次超过 39 级 → 「过于昂贵！」

附魔台：
  base = randomInt(1,8) + floor(b/2) + randomInt(0,b)，b = 有效书架数（≤15）
  顶槽 = floor(max(base/3, 1))、中槽 = floor(base*2/3 + 1)、底槽 = floor(max(base, 2b))
  某附魔某等级 lv 能出现 ⇔ min_cost(lv) ≤ 槽等级 ≤ max_cost(lv)
  min_cost(lv) = base + per_level×(lv−1)，max_cost 同理
  实测还会再叠一层随机浮动，所以附魔台只能保证「有机会」，铁砧并书才能保证结果。
"""
import math

MAX_ANVIL_COST = 39

# eid: 中文名, 最大等级, anvil_cost, weight, min(base, per), max(base, per),
#      物品 tag 集合, 是否宝藏
ENCHANTS = {
    "protection": ("保护", 4, 1, 10, (1, 11), (12, 11), {"armor"}, 0),
    "fire_protection": ("火焰保护", 4, 2, 5, (10, 8), (18, 8), {"armor"}, 0),
    "blast_protection": ("爆炸保护", 4, 4, 2, (5, 8), (13, 8), {"armor"}, 0),
    "projectile_protection": ("弹射物保护", 4, 2, 5, (3, 6), (9, 6), {"armor"}, 0),
    "thorns": ("荆棘", 3, 8, 1, (10, 20), (60, 20), {"armor"}, 0),
    "respiration": ("水下呼吸", 3, 4, 2, (10, 10), (40, 10), {"head_armor"}, 0),
    "aqua_affinity": ("水下速掘", 1, 4, 2, (1, 0), (41, 0), {"head_armor"}, 0),
    "feather_falling": ("摔落保护", 4, 2, 5, (5, 6), (11, 6), {"foot_armor"}, 0),
    "depth_strider": ("深海探索者", 3, 4, 2, (10, 10), (25, 10), {"foot_armor"}, 0),
    "frost_walker": ("冰霜行者", 2, 4, 2, (10, 10), (25, 10), {"foot_armor"}, 1),
    "soul_speed": ("灵魂疾行", 3, 8, 1, (10, 10), (25, 10), {"foot_armor"}, 1),
    "swift_sneak": ("迅捷潜行", 3, 8, 1, (25, 25), (75, 25), {"leg_armor"}, 1),
    "binding_curse": ("绑定诅咒", 1, 8, 1, (25, 0), (50, 0), {"armor", "elytra"}, 1),
    "sharpness": ("锋利", 5, 1, 10, (1, 11), (21, 11), {"weapon"}, 0),
    "smite": ("亡灵杀手", 5, 2, 5, (5, 8), (25, 8), {"weapon"}, 0),
    "bane_of_arthropods": ("节肢杀手", 5, 2, 5, (5, 8), (25, 8), {"weapon"}, 0),
    "knockback": ("击退", 2, 2, 5, (5, 20), (55, 20), {"sword"}, 0),
    "fire_aspect": ("火焰附加", 2, 4, 2, (10, 20), (60, 20), {"sword", "mace"}, 0),
    "looting": ("抢夺", 3, 4, 2, (15, 9), (65, 9), {"sword"}, 0),
    "sweeping_edge": ("横扫之刃", 3, 4, 2, (5, 9), (20, 9), {"sword"}, 0),
    "efficiency": ("效率", 5, 1, 10, (1, 10), (51, 10), {"mining"}, 0),
    "silk_touch": ("精准采集", 1, 8, 1, (15, 0), (65, 0), {"mining"}, 0),
    "fortune": ("时运", 3, 4, 2, (15, 9), (65, 9), {"mining"}, 0),
    "unbreaking": ("耐久", 3, 2, 5, (5, 8), (55, 8), {"durability"}, 0),
    "mending": ("经验修补", 1, 4, 2, (25, 25), (75, 25), {"durability"}, 1),
    "vanishing_curse": ("消失诅咒", 1, 8, 1, (25, 0), (50, 0), {"durability"}, 1),
    "power": ("力量", 5, 1, 10, (1, 10), (16, 10), {"bow"}, 0),
    "punch": ("冲击", 2, 4, 2, (12, 20), (37, 20), {"bow"}, 0),
    "flame": ("火矢", 1, 4, 2, (20, 0), (50, 0), {"bow"}, 0),
    "infinity": ("无限", 1, 8, 1, (20, 0), (50, 0), {"bow"}, 1),
    "multishot": ("多重射击", 1, 4, 2, (20, 0), (50, 0), {"crossbow"}, 0),
    "quick_charge": ("快速装填", 3, 2, 5, (12, 20), (50, 0), {"crossbow"}, 0),
    "piercing": ("穿透", 4, 1, 10, (1, 10), (50, 0), {"crossbow"}, 0),
    "loyalty": ("忠诚", 3, 2, 5, (12, 7), (50, 0), {"trident"}, 0),
    "impaling": ("穿刺", 5, 4, 2, (1, 8), (21, 8), {"trident"}, 0),
    "riptide": ("激流", 3, 4, 2, (17, 7), (50, 0), {"trident"}, 0),
    "channeling": ("引雷", 1, 8, 1, (25, 0), (50, 0), {"trident"}, 0),
    "density": ("密度", 5, 2, 5, (5, 8), (25, 8), {"mace"}, 0),
    "breach": ("破甲", 4, 4, 2, (15, 9), (65, 9), {"mace"}, 0),
    "wind_burst": ("风爆", 3, 4, 2, (15, 9), (65, 9), {"mace"}, 1),
    "luck_of_the_sea": ("海之眷顾", 3, 4, 2, (15, 9), (65, 9), {"fishing"}, 0),
    "lure": ("饵钓", 3, 4, 2, (15, 9), (65, 9), {"fishing"}, 0),
}

# 物品类型 → (显示名, 附魔台/附魔兼容 tag)
# 所有有耐久的物品都带 durability（耐久 / 经验修补 / 消失诅咒 就是这个 tag）
ITEM_TYPES = [
    ("sword", "剑", {"weapon", "sword", "durability"}),
    ("axe", "斧", {"weapon", "axe", "mining", "durability"}),
    ("pickaxe", "镐", {"pickaxe", "mining", "durability"}),
    ("shovel", "锹", {"shovel", "mining", "durability"}),
    ("hoe", "锄", {"hoe", "mining", "durability"}),
    ("mace", "重锤", {"mace", "weapon", "durability"}),
    ("bow", "弓", {"bow", "durability"}),
    ("crossbow", "弩", {"crossbow", "durability"}),
    ("trident", "三叉戟", {"trident", "durability"}),
    ("helmet", "头盔", {"head_armor", "armor", "durability"}),
    ("chestplate", "胸甲", {"chest_armor", "armor", "durability"}),
    ("leggings", "护腿", {"leg_armor", "armor", "durability"}),
    ("boots", "靴子", {"foot_armor", "armor", "durability"}),
    ("elytra", "鞘翅", {"elytra", "durability"}),
    ("shield", "盾牌", {"durability"}),
    ("fishing_rod", "钓鱼竿", {"fishing", "durability"}),
    ("shears", "剪刀", {"mining", "durability"}),
    ("flint_and_steel", "打火石", {"durability"}),
    ("carrot_on_a_stick", "胡萝卜钓竿", {"durability"}),
    ("book", "附魔书（能刷宝藏）", {"*"}),
]

EXCLUSIVE_GROUPS = [
    ("sharpness", "smite", "bane_of_arthropods"),
    ("density", "breach", "smite", "bane_of_arthropods"),
    ("fortune", "silk_touch"),
    ("protection", "fire_protection", "blast_protection",
     "projectile_protection"),
    ("depth_strider", "frost_walker"),
    ("infinity", "mending"),
    ("multishot", "piercing"),
    ("loyalty", "riptide"),
    ("channeling", "riptide"),
]

ROMAN = ("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X")


# ---------------- 基础查询 ----------------
def item_label(key):
    for k, label, _tags in ITEM_TYPES:
        if k == key:
            return label
    return key


def item_tags(key):
    for k, _label, tags in ITEM_TYPES:
        if k == key:
            return tags
    return set()


def enchant_label(eid, level=None):
    name = ENCHANTS[eid][0]
    if level is None:
        return name
    lv = ROMAN[level - 1] if 1 <= level <= 10 else str(level)
    return "%s %s" % (name, lv)


def info_order(eid):
    return (-ENCHANTS[eid][2], -ENCHANTS[eid][1], eid)


def max_level(eid):
    return ENCHANTS[eid][1]


def mult_item(eid):
    return ENCHANTS[eid][2]


def mult_book(eid):
    return max(1, ENCHANTS[eid][2] // 2)


def is_treasure(eid):
    return bool(ENCHANTS[eid][7])


def min_cost(eid, level):
    base, per = ENCHANTS[eid][4]
    return base + per * (level - 1)


def max_cost(eid, level):
    base, per = ENCHANTS[eid][5]
    return base + per * (level - 1)


def in_table(eid, item_key, level):
    """该物品放在附魔台时，这个附魔有没有资格出现在候选池。

    level 只用于说明；具体等级区间由 pool_at 按 min/max cost 判定。
    """
    tags = item_tags(item_key)
    if "*" not in tags and not (tags & ENCHANTS[eid][6]):
        return False
    if is_treasure(eid) and item_key != "book":
        return False        # 宝藏附魔只有附魔书能刷出来
    return True


def available(item_key):
    """该物品能附哪些附魔（铁砧/书本都按这套算）。"""
    tags = item_tags(item_key)
    out = []
    for eid in ENCHANTS:
        if "*" in tags or (tags & ENCHANTS[eid][6]):
            out.append(eid)
    return sorted(out, key=info_order)


def validate(item_key, targets):
    errs = []
    if not targets:
        errs.append("至少选一个附魔。")
        return errs
    tags = item_tags(item_key)
    for eid in targets:
        if "*" not in tags and item_key != "book" and not (tags & ENCHANTS[eid][6]):
            errs.append("%s 附不到%s上。" % (enchant_label(eid),
                                           item_label(item_key)))
    for eid, level in targets.items():
        if level < 1 or level > ENCHANTS[eid][1]:
            errs.append("%s 的等级只能是 1-%d。"
                        % (ENCHANTS[eid][0], ENCHANTS[eid][1]))
    picked = set(targets)
    for group in EXCLUSIVE_GROUPS:
        hit = [e for e in group if e in picked]
        if len(hit) > 1:
            errs.append("%s 不能同时附在一件物品上。"
                        % " / ".join(ENCHANTS[e][0] for e in hit))
    return errs


# ---------------- 铁砧：并书 ----------------
class _Node(object):
    __slots__ = ("ench", "uses", "label")

    def __init__(self, ench, uses=0, label=""):
        self.ench = dict(ench)
        self.uses = uses
        self.label = label

    @property
    def penalty(self):
        return (1 << self.uses) - 1

    def value(self):
        return sum(lv * mult_book(e) for e, lv in self.ench.items())

    def text(self):
        return "、".join(enchant_label(e, lv)
                        for e, lv in sorted(self.ench.items(),
                                            key=lambda kv: info_order(kv[0])))


def _merge_ench(a, b):
    out = dict(a)
    for eid, lv in b.items():
        cur = out.get(eid)
        top = ENCHANTS[eid][1]
        if cur is None:
            out[eid] = lv
        elif lv > cur:
            out[eid] = min(top, lv)
        elif lv == cur:
            out[eid] = min(top, cur + 1)
    return out


def _combine(left, right):
    merged = _merge_ench(left.ench, right.ench)
    sacrifice = 0
    for eid, lv in right.ench.items():
        sacrifice += merged.get(eid, lv) * mult_book(eid)
    cost = sacrifice + left.penalty + right.penalty
    node = _Node(merged, max(left.uses, right.uses) + 1,
                 "%s + %s" % (left.label, right.label))
    return node, cost


def plan(item_key, targets, base_ench=None):
    """先合书、最后一次性上物品；返回步骤与成本。"""
    errors = validate(item_key, targets)
    res = {"item": item_key, "targets": dict(targets), "errors": errors,
           "steps": [], "final": None, "total": 0, "warnings": []}
    if errors:
        return res

    nodes = [_Node({eid: lv}, 0, enchant_label(eid, lv))
             for eid, lv in sorted(targets.items(),
                                   key=lambda kv: -kv[1] * mult_book(kv[0]))]

    if len(nodes) == 1:
        big = nodes[0]
    else:
        big = None
        rounds = 0
        while len(nodes) > 1:
            rounds += 1
            nxt = []
            for i in range(0, len(nodes) - 1, 2):
                a, b = nodes[i], nodes[i + 1]
                if a.value() < b.value():
                    a, b = b, a
                node, cost = _combine(a, b)
                ok = cost <= MAX_ANVIL_COST
                res["steps"].append({
                    "round": rounds, "target": a.text(),
                    "sacrifice": b.text(), "result": node.text(),
                    "cost": cost, "penalty": (a.penalty, b.penalty), "ok": ok})
                res["total"] += cost
                if not ok:
                    res["warnings"].append(
                        "「%s」这一步要 %d 级，超过 %d 级算过于昂贵。"
                        % (node.text(), cost, MAX_ANVIL_COST))
                nxt.append(node)
            if len(nodes) % 2:
                nxt.append(nodes[-1])
            nodes = nxt
        big = nodes[0]

    equip = _Node(dict(base_ench or {}), 0, item_label(item_key))
    merged = _merge_ench(equip.ench, big.ench)
    cost = sum(merged.get(e, lv) * mult_book(e) for e, lv in big.ench.items())
    cost += equip.penalty + big.penalty
    uses = max(equip.uses, big.uses) + 1
    res["final"] = {
        "target": item_label(item_key), "sacrifice": big.text(),
        "result": "、".join(enchant_label(e, lv) for e, lv in
                            sorted(merged.items(), key=lambda kv: info_order(kv[0]))),
        "cost": cost, "penalty": (equip.penalty, big.penalty),
        "ok": cost <= MAX_ANVIL_COST, "result_uses": uses}
    res["total"] += cost
    res["final_penalty"] = (1 << uses) - 1
    if cost > MAX_ANVIL_COST:
        res["warnings"].append(
            "最后一步要 %d 级，超过 %d 级：这套目标得降几项等级，或者拆到不同装备上。"
            % (cost, MAX_ANVIL_COST))
    return res


def naive_plan(item_key, targets):
    """对照：把书一本一本直接往物品上加。"""
    steps = []
    equip = _Node({}, 0, item_label(item_key))
    total = 0
    for eid, lv in sorted(targets.items(),
                          key=lambda kv: -kv[1] * mult_book(kv[0])):
        book = _Node({eid: lv}, 0, enchant_label(eid, lv))
        merged = _merge_ench(equip.ench, book.ench)
        cost = sum(merged.get(e, lv) * mult_book(e) for e, lv in book.ench.items())
        cost += equip.penalty + book.penalty
        total += cost
        equip = _Node(merged, equip.uses + 1, item_label(item_key))
        steps.append({"book": enchant_label(eid, lv), "cost": cost,
                      "ok": cost <= MAX_ANVIL_COST, "item_uses": equip.uses})
    return {"steps": steps, "total": total, "final_penalty": equip.penalty}


# ---------------- 附魔台：书架与档位 ----------------
def _base_range(shelves):
    b = max(0, min(15, int(shelves)))
    return 1 + b // 2, 8 + b // 2 + b, b


def slot_ranges(shelves):
    """三个槽各自的等级区间（按公式枚举 base 的全部取值）。"""
    lo, hi, b = _base_range(shelves)
    top = [max(1, base // 3) for base in range(lo, hi + 1)]
    mid = [base * 2 // 3 + 1 for base in range(lo, hi + 1)]
    bottom = [max(base, b * 2) for base in range(lo, hi + 1)]
    return {"top": (min(top), max(top)),
            "middle": (min(mid), max(mid)),
            "bottom": (min(bottom), max(bottom))}


def power_range(slot_level):
    """槽等级再叠一层随机：power = rand(1,8) + 槽等级/2 + rand(0, 槽等级)。"""
    L = max(1, int(slot_level))
    return L // 2 + 1, 8 + L // 2 + L


def _fits(eid, level, power):
    return min_cost(eid, level) <= power <= max_cost(eid, level)


def needed_shelves(item_key, eid, level, slot="bottom"):
    """要让该档的 power 上限够到 min_cost(level)，最少要几个书架。"""
    need = min_cost(eid, level)
    for b in range(0, 16):
        hi = slot_ranges(b)[slot][1]
        if power_range(hi)[1] >= need:
            return b, slot_ranges(b)[slot]
    return 15, slot_ranges(15)[slot]


def pool_at(item_key, slot_level):
    """某个槽能刷出来的附魔（每项给出最高能出的等级）。"""
    lo, hi = power_range(slot_level)
    out = []
    for eid in ENCHANTS:
        if not in_table(eid, item_key, slot_level):
            continue
        best = 0
        for lv in range(1, ENCHANTS[eid][1] + 1):
            if _fits(eid, lv, hi) or (min_cost(eid, lv) <= hi and
                                      max_cost(eid, lv) >= lo):
                best = lv
        if best:
            out.append((eid, best, ENCHANTS[eid][3]))
    return sorted(out, key=lambda x: (-x[2], x[0]))


def table_advice(item_key, targets):
    """附魔台侧的建议：每项附魔要几个书架、走哪一档、这档还能出什么。"""
    res = {"errors": validate(item_key, targets) if targets else [],
           "rows": [], "shelves": 0, "notes": []}
    if res["errors"]:
        return res
    rows = []
    need_max = 0
    for eid, lv in sorted(targets.items(), key=lambda kv: info_order(kv[0])):
        row = {"eid": eid, "level": lv, "name": enchant_label(eid, lv),
               "treasure": is_treasure(eid)}
        if is_treasure(eid) and item_key != "book":
            row["ok"] = False
            row["why"] = "宝藏附魔，附魔台刷不出来，只能去换附魔书"
            rows.append(row)
            continue
        best = None
        for slot in ("bottom", "middle", "top"):
            b, rng = needed_shelves(item_key, eid, lv, slot)
            if best is None or b < best[1]:
                best = (slot, b, rng)
        row["slot"], row["shelves"], row["range"] = best
        row["ok"] = True
        row["min_cost"] = min_cost(eid, lv)
        row["max_cost"] = max_cost(eid, lv)
        top_power = power_range(best[2][1])[1]
        row["power_max"] = top_power
        can = 0
        for clv in range(1, ENCHANTS[eid][1] + 1):
            if min_cost(eid, clv) <= top_power:
                can = clv
        row["can"] = can
        need_max = max(need_max, best[1])
        rows.append(row)
    res["rows"] = rows
    res["shelves"] = need_max
    res["ranges"] = slot_ranges(need_max)
    return res


def shelf_note(shelves):
    b = max(0, min(15, int(shelves)))
    r = slot_ranges(b)
    return ("%d 个书架：顶槽 %d–%d 级，中槽 %d–%d 级，底槽 %d–%d 级"
            % (b, r["top"][0], r["top"][1], r["middle"][0], r["middle"][1],
               r["bottom"][0], r["bottom"][1]))
