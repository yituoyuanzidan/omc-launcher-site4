# -*- coding: utf-8 -*-
"""本地种子计算：调 bin/omcseeds.exe（cubiomes 编译出来的算法核心）。

全部在本机算，不联网、不跳网页：
- find_structures() 给种子算村庄 / 要塞 / 神殿 / 遗迹坐标
- biome_at()        查任意坐标的生物群系
- biome_grid()      取一片区域的生物群系网格，能画成小地图
"""
import json
import os
import subprocess
import sys

STRUCT_LABELS = {
    "village": "村庄",
    "outpost": "掠夺者前哨站",
    "monument": "海底神殿",
    "mansion": "林地府邸",
    "ancient_city": "远古城市",
    "desert_pyramid": "沙漠神殿",
    "jungle_temple": "丛林神庙",
    "swamp_hut": "沼泽女巫小屋",
    "igloo": "雪屋",
    "ruined_portal": "废弃传送门",
    "shipwreck": "沉船",
    "ocean_ruin": "海底废墟",
    "buried_treasure": "埋藏的宝藏",
    "trail_ruins": "古迹废墟",
    "trial_chambers": "试炼密室",
    "stronghold": "要塞（末地传送门）",
}

# 结构列表前面的小色块用色，跟地图上的红框区分开
STRUCT_COLORS = {
    "village": "#79c94b",
    "outpost": "#9a9a9a",
    "monument": "#3f9fd6",
    "mansion": "#5b4b8a",
    "ancient_city": "#2f5f8f",
    "desert_pyramid": "#e0c46b",
    "jungle_temple": "#2f8f4a",
    "swamp_hut": "#8a5bb0",
    "igloo": "#dfe9f2",
    "ruined_portal": "#a463d6",
    "shipwreck": "#8a6234",
    "ocean_ruin": "#4fb3b3",
    "buried_treasure": "#e8b53a",
    "trail_ruins": "#d98a3f",
    "trial_chambers": "#c96b3f",
    "stronghold": "#b04ad6",
}


def struct_color(kind):
    return STRUCT_COLORS.get(kind or "", "#a0a0a0")


def _app_root():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def exe_path():
    """找到 omcseeds.exe 的实际位置。"""
    roots = [_app_root()]
    if getattr(sys, "frozen", False):
        roots.append(os.path.dirname(sys.executable))
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    roots.append(here)
    cands = []
    for r in roots:
        cands.append(os.path.join(r, "bin", "omcseeds.exe"))
    cands.append(os.path.join(here, "_tools", "build", "omcseeds.exe"))
    for p in cands:
        if os.path.isfile(p):
            return p
    return ""


def available():
    return bool(exe_path())


def _no_window():
    if os.name == "nt":
        return 0x08000000  # CREATE_NO_WINDOW
    return 0


def _run(args, timeout=45):
    exe = exe_path()
    if not exe:
        raise RuntimeError("本地种子计算器缺失（bin/omcseeds.exe 没找到）")
    cmd = [exe] + [str(a) for a in args]
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout,
                           creationflags=_no_window())
    except subprocess.TimeoutExpired:
        raise RuntimeError("计算超时，把搜索范围调小一点再试")
    out = (p.stdout or b"").decode("utf-8", "replace").strip()
    err = (p.stderr or b"").decode("utf-8", "replace").strip()
    if p.returncode != 0 or not out:
        raise RuntimeError("计算失败：%s" % (err[:200] or "退出码 %d" % p.returncode))
    try:
        return json.loads(out)
    except ValueError:
        raise RuntimeError("计算结果读不出来：%s" % out[:120])


def norm_version(text):
    """把 1.21.4 / 1.20.1 这类版本号归一成计算器认识的主版本。"""
    t = (text or "").strip()
    if not t:
        return "1.21"
    parts = t.split(".")
    if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
        return "%s.%s" % (parts[0], parts[1])
    for v in ("1.21", "1.20", "1.19", "1.18", "1.17", "1.16"):
        if t.startswith(v):
            return v
    return "1.21"


def find_structures(version, seed, radius=3000):
    """返回 {spawn:{x,z}, structures:[{type,x,z}]}。"""
    return _run(["struct", norm_version(version), int(seed), int(radius)])


def biome_at(version, seed, x, z, y=64):
    return _run(["biome", norm_version(version), int(seed), int(x), int(z),
                 int(y), ], timeout=20)


def biome_grid(version, seed, x0, z0, w, h, scale=4):
    return _run(["map", norm_version(version), int(seed), int(x0), int(z0),
                 int(w), int(h), int(scale)], timeout=45)


def biome_cn(name):
    """minecraft:plains -> 平原。查不到就用原名去前缀。"""
    key = (name or "").strip()
    if key.startswith("minecraft:"):
        key = key[10:]
    return BIOME_CN.get(key, key)


def render_biome_png(data, out_png, block_x0, block_z0, marks=None, scale=1):
    """把 biome_grid() 的结果画成 PNG，可选在地图上打点。

    data: {"w","h","scale","biomes":[id,...],"legend":{id:name}}
    marks: [(x, z, (r,g,b), 标签)]，按方块坐标打点
    """
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QColor, QImage, QPainter, QPen

    from core import seedmap

    w = int(data.get("w") or 0)
    h = int(data.get("h") or 0)
    if w <= 0 or h <= 0:
        raise RuntimeError("区域为空")
    legend = data.get("legend") or {}
    colors = {}
    for k, name in legend.items():
        try:
            colors[int(k)] = seedmap.color_for(name)
        except Exception:
            colors[int(k)] = seedmap.UNKNOWN_COLOR
    ids = data.get("biomes") or []
    img = QImage(w, h, QImage.Format_RGB32)
    img.fill(QColor(*seedmap.UNKNOWN_COLOR))
    for i in range(min(w * h, len(ids))):
        c = colors.get(ids[i], seedmap.UNKNOWN_COLOR)
        img.setPixel(i % w, i // w, QColor(*c).rgb())
    if scale != 1:
        img = img.scaled(w * scale, h * scale, Qt.IgnoreAspectRatio,
                         Qt.FastTransformation)
    step = int(data.get("scale") or 4)
    if marks:
        p = QPainter(img)
        for x, z, col, _lab in marks:
            px = int((x - block_x0) / step) * scale
            py = int((z - block_z0) / step) * scale
            if 0 <= px < img.width() and 0 <= py < img.height():
                p.setPen(QPen(QColor(*col), 2))
                p.drawRect(px - 3, py - 3, 7, 7)
        p.end()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    img.save(out_png, "PNG")
    return img.width(), img.height()


BIOME_CN = {
    "badlands": "恶地",
    "bamboo_jungle": "竹林",
    "basalt_deltas": "玄武岩三角洲",
    "beach": "沙滩",
    "birch_forest": "桦木森林",
    "cherry_grove": "樱花树林",
    "cold_ocean": "冷水海洋",
    "crimson_forest": "绯红森林",
    "dark_forest": "黑森林",
    "deep_cold_ocean": "深冷水海洋",
    "deep_dark": "深暗之域",
    "deep_frozen_ocean": "深冻洋",
    "deep_lukewarm_ocean": "深温水海洋",
    "deep_ocean": "深海",
    "desert": "沙漠",
    "dripstone_caves": "溶洞",
    "eroded_badlands": "侵蚀恶地",
    "flower_forest": "繁花森林",
    "forest": "森林",
    "frozen_ocean": "冻洋",
    "frozen_peaks": "冰封山峰",
    "frozen_river": "冻河",
    "grove": "雪林",
    "ice_spikes": "冰刺之地",
    "jagged_peaks": "尖峭山峰",
    "jungle": "丛林",
    "lukewarm_ocean": "温水海洋",
    "lush_caves": "繁茂洞穴",
    "mangrove_swamp": "红树林沼泽",
    "meadow": "草甸",
    "mushroom_fields": "蘑菇岛",
    "nether_wastes": "下界荒地",
    "ocean": "海洋",
    "old_growth_birch_forest": "原始桦木森林",
    "old_growth_pine_taiga": "原始松木针叶林",
    "old_growth_spruce_taiga": "原始云杉针叶林",
    "pale_garden": "苍白之园",
    "plains": "平原",
    "river": "河流",
    "savanna": "热带草原",
    "savanna_plateau": "热带高原",
    "snowy_beach": "积雪的沙滩",
    "snowy_plains": "雪原",
    "snowy_slopes": "积雪山坡",
    "snowy_taiga": "积雪针叶林",
    "soul_sand_valley": "灵魂沙峡谷",
    "sparse_jungle": "稀疏丛林",
    "stony_peaks": "裸岩山峰",
    "stony_shore": "石岸",
    "sunflower_plains": "向日葵平原",
    "swamp": "沼泽",
    "taiga": "针叶林",
    "warm_ocean": "暖水海洋",
    "warped_forest": "诡异森林",
    "windswept_forest": "风袭森林",
    "windswept_gravelly_hills": "风袭沙砾丘陵",
    "windswept_hills": "风袭丘陵",
    "windswept_savanna": "风袭热带草原",
    "wooded_badlands": "疏林恶地",
    "the_end": "末地",
    "small_end_islands": "末地小岛",
    "end_midlands": "末地中部",
    "end_highlands": "末地高地",
    "end_barrens": "末地荒岛",
}
