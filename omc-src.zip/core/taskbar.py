# -*- coding: utf-8 -*-
"""任务栏身份：注册 AppUserModelID 的显示名与图标。

只调 SetCurrentProcessExplicitAppUserModelID 而不在注册表里登记这个 ID，
Windows 会拿这个 ID 去查图标，查不到就退回系统默认的「未知程序」占位图——
任务栏上看起来就是一个崩溃的程序。所以先写 HKCU 下的 AppUserModelId 键
（DisplayName + IconUri），再设进程 ID，任务栏才会用 exe / ico 自己的图标。

IconUri 指向一个**固定位置的 ico**（复制到用户数据目录），而不是正在运行的
exe：桌面上同时存在好几个不同版本的 OMC.exe，它们共用这一个 AUMID，谁最后
启动就把 IconUri 改成自己的路径——旧包里没塞好图标的那个一旦抢到，任务栏
就退回系统占位图。固定 ico 与具体 exe 解耦，换版本、换目录都不会再变。
"""
import os
import shutil
import sys

AUMID = "OMC.Launcher.App.1"


def _data_dir():
    d = os.path.abspath(os.path.expanduser("~/.simple_mc_launcher"))
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        return ""
    return d


def stable_icon(ico_path=""):
    """把 ico 复制到用户数据目录，返回一个不随版本更新消失的稳定路径。"""
    d = _data_dir()
    if not d or not ico_path or not os.path.isfile(ico_path):
        return ""
    dst = os.path.abspath(os.path.join(d, "taskbar.ico"))
    try:
        # 内容变了才重写：每次启动都拷一遍会白白改时间戳
        if (not os.path.isfile(dst)
                or os.path.getsize(dst) != os.path.getsize(ico_path)):
            shutil.copyfile(ico_path, dst)
        return dst if os.path.isfile(dst) else ""
    except Exception:
        return ""


def icon_uri(ico_path=""):
    """图标来源：优先稳定 ico，其次 exe 自己（图标已嵌进 exe），源码运行用 ico。"""
    uri = stable_icon(ico_path)
    if uri:
        return uri
    if getattr(sys, "frozen", False):
        exe = os.path.abspath(sys.executable)
        if exe.lower().endswith(".exe") and os.path.isfile(exe):
            return exe
    if ico_path and os.path.isfile(ico_path):
        return os.path.abspath(ico_path)
    return ""


def register(ico_path="", name="OMC 启动器"):
    """把 AUMID 写进注册表（HKCU，不需要管理员权限）。"""
    import winreg

    uri = icon_uri(ico_path)
    key_path = r"Software\Classes\AppUserModelId\%s" % AUMID
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as k:
        winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, name)
        if uri:
            winreg.SetValueEx(k, "IconUri", 0, winreg.REG_SZ, uri)
    return uri


def _notify_shell():
    """告诉资源管理器图标来源变了，别继续拿缓存里的旧图标。"""
    try:
        import ctypes

        SHCNE_ASSOCCHANGED = 0x08000000
        SHCNF_IDLIST = 0x0000
        ctypes.windll.shell32.SHChangeNotify(
            SHCNE_ASSOCCHANGED, SHCNF_IDLIST, None, None)
    except Exception:
        pass


def apply(ico_path="", name="OMC 启动器"):
    """注册 + 设置进程 AUMID；失败返回 False，不抛异常。"""
    if not sys.platform.startswith("win"):
        return False
    try:
        uri = register(ico_path, name)
    except Exception:
        return False
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(AUMID)
    except Exception:
        return False
    if uri and uri.lower().endswith(".ico"):
        # 只有换成固定 ico 之后才需要刷，指向 exe 的老路径不用惊动资源管理器
        _notify_shell()
    return True
