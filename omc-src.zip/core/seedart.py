# -*- coding: utf-8 -*-
"""种子地图的配图：顶部像素横幅、群系色卡图例、结构图标色块。

不依赖外部图片资源，全部用 QPainter 现画（纯像素风，跟 MC 一个路子），
这样不占体积、不会因为缺资源裂图，颜色也统一从 seedmap.BIOME_COLORS 来。
"""
import os

from PySide6.QtCore import Qt
from PySide6.QtGui import (QColor, QFont, QFontMetrics, QImage, QPainter, QPen,
                           QPixmap)

CELL = 8          # 横幅一个「像素方块」的逻辑边长
BANNER_W = 936
BANNER_H = 120

_CELL = CELL      # 实际绘制用的边长，按屏幕缩放比放大


def _r(p, x, y, w, h, color):
    p.fillRect(int(x * _CELL), int(y * _CELL), int(w * _CELL), int(h * _CELL),
               QColor(color))


def banner_png(path, dpr=1.0):
    """画一张 MC 风格的横版小景：天空、远山、草地、树、小屋、地下矿脉 + 地图标记。

    dpr 传屏幕缩放比（Windows 125% 就是 1.25），这样像素块落在整数物理像素上，
    放大后不会糊成半格。
    """
    global _CELL
    cell = max(5, int(round(CELL * float(dpr or 1.0))))
    _CELL = cell
    w = (BANNER_W // CELL) * cell
    h = (BANNER_H // CELL) * cell
    img = QImage(w, h, QImage.Format_ARGB32)
    img.fill(QColor("#0d1117"))
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing, False)

    cells = BANNER_W // CELL      # 117
    # 天空两档
    _r(p, 0, 0, cells, 4, "#4f93cf")
    _r(p, 0, 4, cells, 2, "#79b6e2")

    # 云
    for (cx, cy, cw) in ((2, 1, 7), (14, 2, 5), (78, 1, 9), (101, 2, 6),
                         (30, 0, 4)):
        _r(p, cx, cy, cw, 1, "#f6fafd")
        _r(p, cx + 1, cy + 1, max(1, cw - 3), 1, "#e6eff8")

    # 太阳
    _r(p, 108, 0, 4, 4, "#ffe9a3")
    _r(p, 109, 1, 2, 2, "#ffd75e")

    # 远山（用竖条模拟三角形）
    for i in range(13):
        h = 4 - abs(i - 6)
        _r(p, 3 + i, 7 - h, 1, h, "#5d7e96")
    for i in range(10):
        h = 3 - abs(i - 5)
        _r(p, 18 + i, 7 - h, 1, h, "#7296af")
    for i in range(8):
        h = 3 - abs(i - 4)
        _r(p, 86 + i, 7 - h, 1, h, "#7296af")

    # 草地、泥土、石层
    _r(p, 0, 7, cells, 1, "#6fb551")
    _r(p, 0, 8, cells, 1, "#4f8c39")
    _r(p, 0, 9, cells, 2, "#835a35")
    _r(p, 0, 11, cells, 4, "#6e6e6e")
    # 石层深浅交错，别是一整块灰
    for sx in range(0, cells, 7):
        _r(p, sx, 12, 3, 1, "#7a7a7a")
    for sx in range(3, cells, 9):
        _r(p, sx, 13, 4, 1, "#646464")

    # 树：两棵
    for tx in (24, 66):
        _r(p, tx + 1, 4, 2, 4, "#6b4a2b")          # 树干
        _r(p, tx, 2, 4, 2, "#3f7f2f")              # 树冠下
        _r(p, tx - 1, 1, 6, 1, "#4b9438")          # 树冠上
        _r(p, tx + 1, 0, 2, 1, "#58a743")          # 顶
        _r(p, tx, 3, 1, 1, "#356b28")
        _r(p, tx + 3, 3, 1, 1, "#356b28")

    # 小屋
    _r(p, 38, 4, 8, 1, "#5a3d24")                  # 屋顶
    _r(p, 37, 5, 10, 1, "#6b4a2b")
    _r(p, 38, 6, 8, 2, "#a3794a")                  # 墙
    _r(p, 41, 6, 2, 2, "#5c3f22")                  # 门
    _r(p, 39, 6, 1, 1, "#ffd75e")                  # 窗
    _r(p, 44, 6, 1, 1, "#ffd75e")

    # 矿脉
    for (oix, oiy, oc) in ((12, 11, "#c96b3f"), (30, 12, "#e0d24b"),
                           (52, 13, "#7ad7d7"), (88, 11, "#e0d24b"),
                           (104, 13, "#c96b3f"), (60, 12, "#5ec46a")):
        _r(p, oix, oiy, 1, 1, oc)

    # 地图网格（模拟地图纸）
    p.setPen(QPen(QColor(255, 255, 255, 26), 1))
    for gx in range(0, cells, 6):
        p.drawLine(gx * _CELL, 0, gx * _CELL, h)
    for gy in range(0, BANNER_H // CELL, 3):
        p.drawLine(0, gy * _CELL, w, gy * _CELL)

    # 三个「遗迹标记」红框
    p.setPen(QPen(QColor("#ff5050"), 2))
    for (mx, my) in ((44, 2), (70, 3), (96, 2)):
        p.drawRect(mx * _CELL, my * _CELL, 18, 18)

    # 中心准星（当前查询的坐标）
    p.setPen(QPen(QColor("#ffffff"), 2))
    cx = 78 * _CELL
    cy = 7 * _CELL + _CELL // 4
    p.drawLine(cx - _CELL, cy, cx + _CELL, cy)
    p.drawLine(cx, cy - _CELL // 2, cx, cy + _CELL // 2)
    p.setPen(QPen(QColor("#d8352a"), 2))
    p.drawRect(cx - 2, cy - 2, 4, 4)
    p.end()

    img.save(path, "PNG")
    return path


def legend_png(names, out_png, width=None, font_px=12, max_items=16):
    """把「群系名 + 颜色」排成一行行色卡图例，自动换行。"""
    from core import seedmap

    width = width or BANNER_W
    font = QFont()
    font.setPixelSize(font_px)
    fm = QFontMetrics(font)

    sw = 14            # 色块边长
    pad = 12
    gap_in = 6         # 色块与文字的间距
    gap_out = 20       # 条目间距
    line_gap = 10

    items = []
    for n in (names or [])[:max_items]:
        key = n if ":" in n else ("minecraft:" + n if n else "")
        items.append((seedmap.color_for(key), _cn(n)))
    if not items:
        return None

    # 先算布局
    rows = []
    cur = []
    cur_w = 0
    for color, label in items:
        w = sw + gap_in + fm.horizontalAdvance(label) + gap_out
        if cur and cur_w + w > width - pad * 2:
            rows.append(cur)
            cur = []
            cur_w = 0
        cur.append((color, label, w))
        cur_w += w
    if cur:
        rows.append(cur)

    line_h = max(sw, fm.height()) + line_gap
    height = pad * 2 + len(rows) * line_h - line_gap
    img = QImage(width, height, QImage.Format_ARGB32)
    img.fill(QColor(0, 0, 0, 0))
    p = QPainter(img)
    p.setFont(font)

    for ri, row in enumerate(rows):
        x = pad
        y = pad + ri * line_h
        for color, label, w in row:
            c = QColor(color) if isinstance(color, str) else QColor(*color)
            p.setPen(QPen(QColor(255, 255, 255, 70), 1))
            p.fillRect(x, y, sw, sw, c)
            p.drawRect(x, y, sw, sw)
            p.setPen(QColor("#c9d4e0"))
            p.drawText(x + sw + gap_in, y + sw - 2, label)
            x += w
    p.end()

    img.save(out_png, "PNG")
    return out_png


_CN = {}


def _cn(name):
    try:
        from core import seedcalc
        return seedcalc.biome_cn(name).replace("minecraft:", "")
    except Exception:
        return (name or "").replace("minecraft:", "")


def struct_icon(color, size=14):
    """结构列表前面那个小色块图标。"""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, False)
    p.fillRect(1, 1, size - 2, size - 2, QColor(color))
    p.setPen(QPen(QColor(255, 255, 255, 60), 1))
    p.drawRect(1, 1, size - 3, size - 3)
    p.end()
    return pm
