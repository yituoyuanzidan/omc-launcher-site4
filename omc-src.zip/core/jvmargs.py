# -*- coding: utf-8 -*-
"""JVM 启动参数模板：给不想自己查参数的人一个能直接用的优化组合。

只放 JVM 侧参数（-Xmx 由内存滑杆控制，这里不重复设置）。
"""
TEMPLATES = {
    "none": ("默认（不额外加参数）", ""),
    "aikar": ("Aikar 参数（大型整合包/服务器常用）",
              "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 "
              "-XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC "
              "-XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 "
              "-XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 "
              "-XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 "
              "-XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 "
              "-XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 "
              "-XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1"),
    "g1": ("G1 精简优化（一般整合包）",
           "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 "
           "-XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC"),
    "smooth": ("流畅优先（低配电脑，减少卡顿）",
               "-XX:+UseG1GC -XX:MaxGCPauseMillis=150 -XX:G1HeapRegionSize=4M "
               "-XX:+DisableExplicitGC"),
}

ORDER = ["none", "g1", "aikar", "smooth"]


def keys():
    return list(ORDER)


def label(key):
    return TEMPLATES.get(key, TEMPLATES["none"])[0]


def args_for(key):
    return TEMPLATES.get(key, TEMPLATES["none"])[1]
