# -*- coding: utf-8 -*-
"""局域网联机：专用服务器托管、RCON 管理（踢人/OP）、邀请码编解码。"""
import base64
import json
import os
import socket
import struct
import subprocess
import time

from . import http, platform_utils

# ---------- 邀请码：承载 ip:port，局域网内直接可连 ----------
def make_code(ip, port):
    raw = ("%s:%d" % (ip, int(port))).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_code(code):
    text = (code or "").strip()
    pad = "=" * (-len(text) % 4)
    raw = base64.urlsafe_b64decode(text + pad).decode("utf-8")
    ip, port = raw.rsplit(":", 1)
    return ip, int(port)


def lan_ip():
    """获取本机局域网 IP。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def room_dir(game_dir, vid):
    p = os.path.join(game_dir, "rooms", vid)
    os.makedirs(p, exist_ok=True)
    return p


def server_jar_path(game_dir, vid):
    return os.path.join(room_dir(game_dir, vid), "server.jar")


def ensure_server(game_dir, vid, version_data, mirror, log=lambda m: None):
    """下载专用服务器 jar 并写好配置，返回 jar 路径。"""
    dest = server_jar_path(game_dir, vid)
    if not os.path.exists(dest):
        url = None
        for ver in version_data or []:
            if ver.get("id") == vid:
                url = ver.get("url")
                break
        if not url:
            raise RuntimeError("找不到该版本的服务器信息")
        log("正在读取版本清单...")
        manifest = http.fetch_json(url, mirror, 30)
        srv = (manifest.get("downloads") or {}).get("server")
        if not srv:
            raise RuntimeError("该版本不提供专用服务器")
        log("正在下载服务器...")
        http.download_file(srv["url"], dest, mirror,
                           size=srv.get("size"), sha1=srv.get("sha1"))
    d = room_dir(game_dir, vid)
    with open(os.path.join(d, "eula.txt"), "w", encoding="utf-8") as f:
        f.write("eula=true\n")
    return dest


def write_properties(game_dir, vid, port, rcon_port, rcon_pwd, motd=None):
    props = {
        "server-port": port,
        "enable-rcon": "true",
        "rcon.port": rcon_port,
        "rcon.password": rcon_pwd,
        "online-mode": "true",
        "enforce-secure-profile": "false",
    }
    if motd:
        props["motd"] = motd
    path = os.path.join(room_dir(game_dir, vid), "server.properties")
    lines = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    keys = {ln.split("=", 1)[0]: i for i, ln in enumerate(lines) if "=" in ln}
    for k, v in props.items():
        entry = "%s=%s" % (k, v)
        if k in keys:
            lines[keys[k]] = entry
        else:
            lines.append(entry)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


class ServerProcess(object):
    def __init__(self, game_dir, vid, java_path, memory_mb):
        self.game_dir = game_dir
        self.vid = vid
        self.java_path = java_path
        self.memory_mb = memory_mb
        self.proc = None
        self.port = 25565
        self.rcon_port = 25575
        self.rcon_pwd = ""
        self.room_name = ""

    def start(self, rcon_pwd, log=lambda m: None, motd=None):
        self.rcon_pwd = rcon_pwd
        d = room_dir(self.game_dir, self.vid)
        write_properties(self.game_dir, self.vid,
                         self.port, self.rcon_port, rcon_pwd, motd)
        jar = server_jar_path(self.game_dir, self.vid)
        cmd = [self.java_path, "-Xmx%dM" % self.memory_mb,
               "-jar", jar, "nogui"]
        flags = platform_utils.no_window_flags()
        self.log_handle = open(os.path.join(d, "server.log"), "w",
                               encoding="utf-8", errors="replace")
        self.proc = subprocess.Popen(
            cmd, cwd=d, stdout=self.log_handle,
            stderr=subprocess.STDOUT, creationflags=flags)

    def running(self):
        return bool(self.proc) and self.proc.poll() is None

    def stop(self):
        if self.running():
            try:
                self.command("stop")
                for _ in range(20):
                    if not self.running():
                        break
                    time.sleep(0.5)
            except Exception:
                pass
        if self.running():
            self.proc.terminate()
        try:
            self.log_handle.close()
        except Exception:
            pass

    def command(self, command):
        return rcon_command("127.0.0.1", self.rcon_port,
                            self.rcon_pwd, command)


# ---------- 最小 RCON 客户端 ----------
def _packet(req_id, ptype, payload):
    body = struct.pack("<ii", req_id, ptype) + payload.encode("utf-8") + b"\x00\x00"
    return struct.pack("<i", len(body)) + body


def _read_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise RuntimeError("RCON 连接已断开")
        buf += chunk
    return buf


def _read_packet(sock):
    length = struct.unpack("<i", _read_exact(sock, 4))[0]
    data = _read_exact(sock, length)
    rid, ptype = struct.unpack("<ii", data[:8])
    payload = data[8:-2]
    return rid, ptype, payload


def rcon_command(host, port, password, command, timeout=8):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((host, int(port)))
        sock.sendall(_packet(1, 3, password))  # AUTH
        # 部分服务器会先回一个空 RESPONSE_VALUE，再回 AUTH_RESPONSE
        rid, ptype = 0, 0
        while ptype != 2:
            rid, ptype, _payload = _read_packet(sock)
        if rid == -1:
            raise RuntimeError("RCON 密码错误")
        sock.sendall(_packet(2, 2, command))  # EXECCOMMAND
        _rid, _t, payload = _read_packet(sock)
        return payload.decode("utf-8", errors="replace")
    finally:
        sock.close()


def player_list(server):
    """通过 RCON list 命令解析在线玩家名。"""
    out = server.command("list")
    # 形如 "There are 2 of a max of 20 players online: a, b"
    if ":" in out:
        names = out.split(":", 1)[1].strip()
        if names:
            return [n.strip() for n in names.split(",") if n.strip()]
    return []


# ---------- 检测游戏内「对局域网开放」的房间 ----------
def _varint(n):
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out += bytes([b | 0x80])
        else:
            return out + bytes([b])


def _read_varint(sock):
    num = 0
    for i in range(5):
        b = sock.recv(1)
        if not b:
            raise RuntimeError("closed")
        v = b[0]
        num |= (v & 0x7F) << (7 * i)
        if not v & 0x80:
            return num
    raise RuntimeError("bad varint")


def _varint_at(buf, pos):
    num = 0
    for i in range(5):
        v = buf[pos + i]
        num |= (v & 0x7F) << (7 * i)
        if not v & 0x80:
            return num, pos + i + 1
    raise RuntimeError("bad varint")


def status_ping(host, port, timeout=1.2):
    """用 Server List Ping 探测某个端口是不是 Minecraft，能拿到 MOTD 与人数。"""
    try:
        sock = socket.create_connection((host, int(port)), timeout)
    except OSError:
        return None
    sock.settimeout(timeout)
    try:
        addr = host.encode("utf-8")
        body = (b"\x00" + _varint(767) + _varint(len(addr)) + addr
                + struct.pack(">H", int(port)) + _varint(1))
        sock.sendall(_varint(len(body)) + body)
        sock.sendall(_varint(1) + b"\x00")
        total = _read_varint(sock)
        buf = b""
        while len(buf) < total:
            chunk = sock.recv(total - len(buf))
            if not chunk:
                return None
            buf += chunk
        length, pos = _varint_at(buf, 1)   # 跳过 packet id
        info = json.loads(buf[pos:pos + length].decode("utf-8", "replace"))
    except Exception:
        return None
    finally:
        sock.close()

    desc = info.get("description")
    if isinstance(desc, dict):
        motd = "".join(t.get("text", "") if isinstance(t, dict) else str(t)
                       for t in [desc] + list(desc.get("extra") or []))
    else:
        motd = str(desc or "")
    players = info.get("players") or {}
    sample = [p.get("name") for p in (players.get("sample") or [])
              if isinstance(p, dict) and p.get("name")]
    return {
        "port": int(port),
        "motd": motd.strip(),
        "online": players.get("online", 0),
        "max": players.get("max", 0),
        "names": sample,
        "version": (info.get("version") or {}).get("name", ""),
    }


def _run_text(args, timeout=12):
    """跨平台跑命令取文本：Windows 按本地代码页解码，其他系统走 UTF-8。"""
    return platform_utils.run_text(args, timeout)


def _java_pids():
    """当前存活的 java 进程 pid（Windows tasklist / Linux /proc / macOS ps）。"""
    return platform_utils.java_pids()


def _listen_ports():
    """处于 LISTEN 的 TCP 端口，按 pid 分组。"""
    result = {}
    for port, pid in platform_utils.listening_ports().items():
        result.setdefault(pid, set()).add(port)
    return result


def _netstat_ports_all():
    """全部处于 LISTEN 的端口 -> {port: pid}。"""
    result = {}
    for port, pid in platform_utils.listening_ports().items():
        if port >= 1024:
            result[port] = pid
    return result


def _lan_announcements(timeout=1.8):
    """监听 Minecraft 局域网公告组播，返回 [(来源IP, 端口)]。

    这是唯一能拿到「别人电脑上开的房间」的途径：公告包由开房的机器发出，
    源地址就是那台机器，端口写在 [AD]...[/AD] 里。
    """
    found = []
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                             socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", 4445))
        except OSError:
            return found
        mreq = struct.pack("4sl", socket.inet_aton("224.2.2.3"),
                           socket.INADDR_ANY)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        sock.settimeout(timeout)
        try:
            while True:
                data, addr = sock.recvfrom(2048)
                text = data.decode("utf-8", "replace")
                if "[AD]" in text and "[/AD]" in text:
                    seg = text.split("[AD]", 1)[1].split("[/AD]", 1)[0]
                    try:
                        found.append((addr[0], int(seg.strip())))
                    except ValueError:
                        pass
        except socket.timeout:
            pass
        finally:
            sock.close()
    except Exception:
        pass
    return found


def _lan_broadcast_ports(timeout=1.8):
    """监听 Minecraft 的局域网公告组播，直接拿到端口（最准的检测方式）。"""
    return set(p for _ip, p in _lan_announcements(timeout))


def detect_rooms(timeout=1.0, full=False):
    """检测局域网内的 Minecraft 房间（含同网段其他电脑开的房间）。

    三条路并用：组播公告（最准，带来源 IP）-> 本机 java 进程监听端口 -> 全端口兜底。
    full=True 时才做全端口扫描（手动重扫用，避免周期性刷新太重）。
    """
    from concurrent.futures import ThreadPoolExecutor
    listen = _netstat_ports_all()
    local_ip = lan_ip()
    cand = []  # [(host, port, pid)]

    # 1) 组播公告：本机或同网段其他电脑
    for ip, port in _lan_announcements(1.6):
        host = "127.0.0.1" if (ip in (local_ip, "0.0.0.0") or
                               ip.startswith("127.")) else ip
        pid = listen.get(port, 0) if host == "127.0.0.1" else 0
        if not any(c[0] == host and c[1] == port for c in cand):
            cand.append((host, port, pid))

    # 2) 本机 java/javaw 进程的监听端口（游戏端口一定挂在它们下面）
    java = _java_pids()
    local_ports = {}
    for port, pid in listen.items():
        if pid in java:
            local_ports.setdefault(port, pid)
    for port, pid in local_ports.items():
        if not any(c[1] == port and c[0] == "127.0.0.1" for c in cand):
            cand.append(("127.0.0.1", port, pid))

    # 3) 常见默认端口
    for port in (25565, 25566, 25567, 25564, 25568):
        if port in listen and not any(c[1] == port and c[0] == "127.0.0.1"
                                      for c in cand):
            cand.append(("127.0.0.1", port, listen[port]))

    # 4) 兜底：全端口逐个 ping（仅手动重扫时）
    if not cand and full:
        for port, pid in list(listen.items())[:64]:
            cand.append(("127.0.0.1", port, pid))

    rooms = []

    def probe(item):
        host, port, pid = item
        info = status_ping(host, port, timeout)
        if info:
            info["pid"] = pid
            info["ip"] = host
            info["remote"] = host != "127.0.0.1"
        return info

    if cand:
        with ThreadPoolExecutor(max_workers=16) as pool:
            for info in pool.map(probe, cand[:64]):
                if info:
                    rooms.append(info)
    rooms.sort(key=lambda r: (r.get("remote", False), r["port"]))
    return rooms

