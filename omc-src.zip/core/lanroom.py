"""开放联机房间的元数据交换。

房主打开房间后，启动器会在「房间端口 + 1」附近起一个极小的 HTTP 服务，
对外公布房间名称、封面、版本、人数等信息。其他玩家在房间列表里扫描到该
房间后，直接请求这个服务拿到名称和封面，列表就能像模组列表那样显示。

没有这个服务的房间（原生「对局域网开放」的房间）只会显示 MOTD，不影响使用。
"""
import json
import os
import socket
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

META_PORTS = 3          # 依次尝试 port+1 / port+2 / port+3
UA = "OMC-Launcher"
MAX_JSON = 64 * 1024
MAX_COVER = 8 * 1024 * 1024


def _port_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _http_get(url, timeout, limit):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read(limit)
    return data


def fetch_meta(ip, port, timeout=0.7):
    """向房间主机询问自定义名称/封面信息，拿不到就返回 None。"""
    for i in range(META_PORTS):
        try:
            raw = _http_get("http://%s:%d/room.json" % (ip, port + 1 + i),
                            timeout, MAX_JSON)
            meta = json.loads(raw.decode("utf-8", "replace"))
            if isinstance(meta, dict):
                meta["meta_port"] = port + 1 + i
                return meta
        except Exception:
            continue
    return None


def fetch_cover(ip, port, timeout=1.2, meta_port=None):
    """取房间封面字节，失败返回 None。"""
    ports = [meta_port] if meta_port else []
    ports += [port + 1 + i for i in range(META_PORTS)]
    for p in ports:
        try:
            return _http_get("http://%s:%d/cover" % (ip, p), timeout, MAX_COVER)
        except Exception:
            continue
    return None


class RoomMetaServer(object):
    """房主侧的元数据 HTTP 服务。provider() 返回 dict，cover() 返回 bytes。"""

    def __init__(self, base_port, provider, cover):
        self.base_port = base_port
        self.provider = provider
        self.cover = cover
        self.httpd = None
        self.thread = None
        self.port = None

    def _handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, body, ctype):
                try:
                    self.send_response(code)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-cache")
                    self.end_headers()
                    self.wfile.write(body)
                except Exception:
                    pass

            def do_GET(self):
                path = self.path.split("?")[0]
                if path == "/room.json":
                    try:
                        meta = server.provider() or {}
                    except Exception:
                        meta = {}
                    body = json.dumps(meta, ensure_ascii=False).encode("utf-8")
                    self._send(200, body, "application/json; charset=utf-8")
                    return
                if path == "/cover":
                    try:
                        data = server.cover() if server.cover else None
                    except Exception:
                        data = None
                    if not data:
                        self._send(404, b"", "text/plain")
                        return
                    self._send(200, data, "image/png")
                    return
                self._send(404, b"", "text/plain")

        return Handler

    def start(self):
        for i in range(META_PORTS):
            port = self.base_port + 1 + i
            if not _port_free(port):
                continue
            try:
                self.httpd = ThreadingHTTPServer(("0.0.0.0", port),
                                                 self._handler())
            except Exception:
                self.httpd = None
                continue
            self.port = port
            self.thread = threading.Thread(target=self.httpd.serve_forever,
                                           kwargs={"poll_interval": 0.3})
            self.thread.daemon = True
            self.thread.start()
            return port
        return None

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
            except Exception:
                pass
            try:
                self.httpd.server_close()
            except Exception:
                pass
        self.httpd = None
        self.thread = None
        self.port = None


def load_cover(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except Exception:
        return None


def save_cover(path, data):
    with open(path, "wb") as f:
        f.write(data)
        return True
