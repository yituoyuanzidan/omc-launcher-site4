# -*- coding: utf-8 -*-
"""启动前自检：这台电脑到底能不能跑这个包。

为什么要有这一步：打包出来的 exe 在老系统上双击后最常见的表现是
「点了没反应 / 一闪就没 / 只弹一个 0xc0000142 的系统框」——因为 Qt 6
的 DLL 在导入的那一刻就加载失败了，Python 代码根本没机会说话。
所以这里只用标准库 + ctypes，在 import PySide6 之前跑一遍，把
真实的失败原因用系统原生对话框说清楚。

同时顺便摸一遍机器的底（架构、内存、磁盘、运行库、显卡会话），
低配机器给程序一个 OMC_LOW_MEM 标记，让它少画点东西。
"""
import os
import shutil
import struct
import sys

WINDOWS = os.name == "nt"
# 老系统分支（Qt 5 / PySide2）的入口会把 OMC_QT5 设成 1：
# 这时最低要求降到 Windows 7 SP1（6.1.7601），Vista / XP 依然跑不了。
QT5_MODE = os.environ.get("OMC_QT5") == "1"
# Qt 6（也就是 PySide6 6.x）官方支持的最低 Windows 是 10 1809（10.0.17763）。
# Windows 7 / 8 / 8.1 从 Qt 6 起就被彻底放弃，装上也加载不了。
WIN_MIN_MAJOR = 6 if QT5_MODE else 10
WIN_MIN_BUILD = 7601 if QT5_MODE else 17763
# Linux 侧 glibc 2.28（Ubuntu 18.10 / Debian 10）以上才满足 Qt 6
GLIBC_MIN = "2.28"
# macOS 侧 Qt 6 要求 11.0 起
MAC_MIN = (11, 0)

_LOG_NAME = "syscheck.log"


# ---------------------------------------------------------------- 基础探测
def _win_version():
    """拿真实的 Windows 版本号。

    不用 platform.version()：它读的是 exe manifest 里的兼容层，
    在老系统上会被谎报成 6.2（Win8）之类。ntdll!RtlGetVersion 才是真值。
    """
    if not WINDOWS:
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class _OSVERSIONINFOEXW(ctypes.Structure):
            _fields_ = [
                ("dwOSVersionInfoSize", wintypes.DWORD),
                ("dwMajorVersion", wintypes.DWORD),
                ("dwMinorVersion", wintypes.DWORD),
                ("dwBuildNumber", wintypes.DWORD),
                ("dwPlatformId", wintypes.DWORD),
                ("szCSDVersion", ctypes.c_wchar * 128),
                ("wServicePackMajor", wintypes.WORD),
                ("wServicePackMinor", wintypes.WORD),
                ("wSuiteMask", wintypes.WORD),
                ("wProductType", ctypes.c_byte),
                ("wReserved", ctypes.c_byte),
            ]

        info = _OSVERSIONINFOEXW()
        info.dwOSVersionInfoSize = ctypes.sizeof(info)
        fn = ctypes.windll.ntdll.RtlGetVersion
        fn.argtypes = [ctypes.POINTER(_OSVERSIONINFOEXW)]
        fn.restype = ctypes.c_long
        if fn(ctypes.byref(info)) != 0:
            return None
        return {
            "major": int(info.dwMajorVersion),
            "minor": int(info.dwMinorVersion),
            "build": int(info.dwBuildNumber),
            "sp": "SP%d" % int(info.wServicePackMajor) if info.wServicePackMajor else "",
            "product": int(info.wProductType),
        }
    except Exception:
        return None


def os_label(ver=None):
    """把版本号翻成人看的名字。"""
    if not WINDOWS:
        import platform
        return platform.system() + " " + platform.release()
    v = ver or _win_version()
    if not v:
        return "Windows（版本读不出来）"
    major, minor, build = v["major"], v["minor"], v["build"]
    if major >= 10 and build >= 22000:
        return "Windows 11（%d.%d.%d）" % (major, minor, build)
    if major >= 10:
        return "Windows 10（%d.%d.%d）" % (major, minor, build)
    if major == 6 and minor == 3:
        return "Windows 8.1（%d.%d.%d）" % (major, minor, build)
    if major == 6 and minor == 2:
        return "Windows 8（%d.%d.%d）" % (major, minor, build)
    if major == 6 and minor == 1:
        return "Windows 7%s（%d.%d.%d）" % ((" " + v["sp"]) if v["sp"] else "",
                                          major, minor, build)
    if major == 6 and minor == 0:
        return "Windows Vista（%d.%d.%d）" % (major, minor, build)
    if major == 5:
        return "Windows XP / 2003（%d.%d.%d）" % (major, minor, build)
    return "Windows %d.%d.%d" % (major, minor, build)


def _is_arm64():
    return os.environ.get("PROCESSOR_ARCHITEW6432", "").upper() in ("ARM64",) or \
        os.environ.get("PROCESSOR_ARCHITECTURE", "").upper() in ("ARM64",)


def arch():
    """x64 / x86 / arm64 —— 顺便标出「32 位进程跑在 64 位系统上」。"""
    bits = struct.calcsize("P") * 8
    if _is_arm64():
        return "arm64" if bits == 64 else "arm32"
    if bits == 64:
        return "x64"
    if WINDOWS and os.environ.get("PROCESSOR_ARCHITEW6432", ""):
        return "x86（运行在 64 位系统上）"
    return "x86"


def memory_mb():
    """物理内存总量（MB）；读不到返回 0。"""
    if WINDOWS:
        try:
            import ctypes

            class _MEMSTAT(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            st = _MEMSTAT()
            st.dwLength = ctypes.sizeof(st)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
                return int(st.ullTotalPhys / (1024 * 1024))
        except Exception:
            return 0
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(int(line.split()[1]) / 1024)
    except Exception:
        return 0
    return 0


def disk_free_mb(path):
    try:
        return int(shutil.disk_usage(path).free / (1024 * 1024))
    except Exception:
        return 0


def _has_dll(name):
    """能不能把某个系统 DLL 真正加载起来（只查存在、不初始化）。"""
    if not WINDOWS:
        return True
    try:
        import ctypes
        ctypes.WinDLL(name)
        return True
    except Exception:
        return False


def _cpu_features():
    """CPU 指令集探测。Qt 6 的 x64 版本要求 SSE4.2，缺了会在启动时直接非法指令。"""
    out = {}
    if not WINDOWS:
        try:
            with open("/proc/cpuinfo", "r") as f:
                flags = ""
                for line in f:
                    if line.lower().startswith("flags"):
                        flags = line.split(":", 1)[1]
                        break
            out["sse4_2"] = "sse4_2" in flags
            out["avx"] = " avx " in (" " + flags + " ")
        except Exception:
            pass
        return out
    try:
        import ctypes
        # PF_SSE4_1_INSTRUCTIONS=37 / PF_SSE4_2_INSTRUCTIONS=38 / PF_AVX2_INSTRUCTIONS=40
        fn = ctypes.windll.kernel32.IsProcessorFeaturePresent
        out["sse4_1"] = bool(fn(37))
        out["sse4_2"] = bool(fn(38))
        out["avx2"] = bool(fn(40))
    except Exception:
        pass
    return out


def session_hints():
    """远程桌面 / 虚拟机这类场景，显卡和缩放都容易出问题。"""
    hints = []
    if WINDOWS and os.environ.get("SESSIONNAME", "").upper().startswith("RDP"):
        hints.append("远程桌面会话")
    return hints


# ---------------------------------------------------------------- 结论
def checks():
    """跑一遍自检，返回结构化结果。

    blockers —— 明确跑不起来的，必须拦；
    warns    —— 能跑但会难受的，只提示；
    info     —— 机器画像，写日志用。
    """
    blockers = []
    warns = []
    info = {}

    ver = _win_version() if WINDOWS else None
    # 排障用：OMC_FAKE_OS=6.1.7601 可以假装自己是 Win7，
    # 用来确认「跑不了」的提示会不会正常弹出来（不影响真实判断的其他项）。
    fake = os.environ.get("OMC_FAKE_OS", "")
    if fake and WINDOWS:
        try:
            parts = [int(x) for x in fake.split(".")]
            ver = {"major": parts[0], "minor": parts[1],
                   "build": parts[2] if len(parts) > 2 else 0,
                   "sp": "", "product": 1}
        except Exception:
            pass
    info["os"] = os_label(ver)
    info["arch"] = arch()

    if WINDOWS:
        if not ver:
            warns.append({
                "title": "读不出系统版本",
                "detail": "自检拿不到 Windows 版本号，可能是权限或系统裁剪过的精简版。",
                "fix": "如果启动正常可以忽略；启动失败请把 crash.log 发出来。",
            })
        else:
            major, build = ver["major"], ver["build"]
            if QT5_MODE:
                too_old = major < 6 or (major == 6 and build < WIN_MIN_BUILD)
            else:
                too_old = (major < WIN_MIN_MAJOR
                           or (major == 10 and build < WIN_MIN_BUILD))
            if too_old:
                if QT5_MODE:
                    blockers.append({
                        "title": "这台电脑的系统太老，老内核包也跑不了",
                        "detail": (
                            "当前系统是 %s。这个包用的是 Qt 5 / PySide2，"
                            "官方支持的最低版本是 Windows 7 SP1（6.1.7601）；"
                            "Vista / XP 连 Qt 5 的运行库都加载不了，"
                            "不是打补丁能解决的。" % os_label(ver)),
                        "fix": (
                            "两个选择：一、把系统升到 Windows 7 SP1 或更新"
                            "（Win8 / 8.1 / 10 / 11 都在支持范围内）；"
                            "二、换一台 Win7 SP1 以上的电脑，存档目录整个拷过去就行。"),
                    })
                else:
                    blockers.append({
                        "title": "这台电脑的系统版本跑不了这个包",
                        "detail": (
                            "当前系统是 %s。这个包用的是 Qt 6 / PySide6 6.x，"
                            "官方最低要求 Windows 10 1809（10.0.17763）或更新的版本；"
                            "Windows 7 / 8 / 8.1 从 Qt 6 起就不再被支持，"
                            "双击会直接因为加载不了 DLL 而闪退，跟内存、显卡没关系。"
                            % os_label(ver)),
                        "fix": (
                            "三个选择：一、把系统升到 Windows 10/11（最省事，游戏本身也要求 Win10 起）；"
                            "二、换一台 Win10 以上的电脑用这个启动器（存档目录可以整个拷过去）；"
                            "三、用同一站点上的「Win7 老系统版」exe（那套是 Qt 5 构建，"
                            "支持 Win7 / 8 / 8.1）。"),
                    })
    else:
        import platform
        info["os"] = "%s %s" % (platform.system(), platform.release())

    if info["arch"].startswith("x86（"):
        warns.append({
            "title": "正在用 32 位模式运行",
            "detail": "这个包是 64 位的，说明是被 32 位外壳程序拉起来的，"
                      "能给 MC 分配的内存最多 2G 左右。",
            "fix": "直接双击目录里的 OMC.exe 启动，别经过 32 位启动器转一手。",
        })
    elif info["arch"] == "arm32":
        blockers.append({
            "title": "ARM 32 位设备不支持",
            "detail": "这个包是给 x64 准备的，ARM 32 位（老平板 / 部分国产一体机）加载不了。",
            "fix": "换 64 位设备；或者用手机端网页遥控另一台电脑。",
        })
    elif info["arch"] == "x86":
        if QT5_MODE:
            blockers.append({
                "title": "这台电脑装的是 32 位 Windows",
                "detail": "Win7 老系统包目前只有 64 位构建（Qt 5 的 32 位预编译包官方没出），"
                          "32 位系统上装不上；即使 CPU 是 64 位的，只要系统装的是 32 位版也一样。",
                "fix": "把系统重装成 64 位 Win7 SP1 / Win8.1 / 10，或者换一台 64 位系统的电脑。",
            })
        else:
            blockers.append({
                "title": "这台电脑装的是 32 位 Windows",
                "detail": "PySide6 / Qt 6 只提供 64 位 Windows 构建，32 位系统上没有能用的版本；"
                          "即使硬件是 64 位的 CPU，只要系统装的是 32 位版本也一样跑不了。",
                "fix": "重装成 64 位 Windows（CPU 是 64 位的话不用换硬件），或者换一台 64 位系统的电脑。",
            })

    feat = _cpu_features()
    if feat.get("sse4_2") is False and QT5_MODE:
        warns.append({
            "title": "CPU 是较老的一代",
            "detail": "Qt 5 构建对指令集的要求比 Qt 6 低很多，这种机器通常能跑。",
            "fix": "先直接开一下；万一启动瞬间报「非法指令」退出，再换机器。",
        })
    elif feat.get("sse4_2") is False:
        blockers.append({
            "title": "CPU 缺少 SSE4.2 指令集",
            "detail": "Qt 6 的 64 位构建要求 SSE4.2，2008 年以前的老 CPU 基本没有，"
                    "会在启动瞬间报「非法指令」退出。",
            "fix": "这台机器只能用 Win7 老内核包（Qt 5 构建）或换机器。",
        })
    elif feat.get("sse4_2") is None:
        warns.append({
            "title": "CPU 指令集没探测到",
            "detail": "系统接口没返回结果，可能是很老的系统或受限环境。",
            "fix": "先试一下能不能开；打不开再考虑换机器。",
        })

    if WINDOWS:
        for dll, name, fix in (
                ("msvcp140.dll", "VC++ 2015-2022 运行库（msvcp140.dll）",
                 "装一遍微软的「Visual C++ Redistributable 2015-2022 x64」，装完重启再开。"),
                ("vcruntime140.dll", "VC++ 运行库（vcruntime140.dll）",
                 "同上，装 Visual C++ Redistributable 2015-2022 x64。"),
        ):
            if not _has_dll(dll):
                warns.append({
                    "title": "缺系统运行库：%s" % name,
                    "detail": "包里有自带的一份，通常能兜住；如果仍然闪退，就是系统这份也缺。",
                    "fix": fix,
                })

    mem = memory_mb()
    info["memory_mb"] = mem
    if mem and mem < 3000:
        warns.append({
            "title": "内存偏小（%d MB）" % mem,
            "detail": "启动器本身要 300MB 上下，MC 还要再分 1-2G。"
                      "内存不够时最容易表现成「点了启动，游戏没出来」。",
            "fix": "关掉浏览器和其它大程序再开；内存实在不够就把启动前内存设成 2G。",
        })

    free = disk_free_mb(os.path.expanduser("~"))
    info["disk_free_mb"] = free
    if free and free < 3000:
        warns.append({
            "title": "磁盘剩余空间不足（%d MB）" % free,
            "detail": "装一个带模组的版本要 1-2G，再加上备份和缓存。",
            "fix": "先清一下盘，或者把游戏目录挪到空间大的分区（设置里能改）。",
        })

    hints = session_hints()
    if hints:
        info["session"] = " / ".join(hints)
        warns.append({
            "title": "检测到 %s" % info["session"],
            "detail": "远程桌面下显卡加速基本用不上，界面会明显变卡、壁纸也可能不刷新。",
            "fix": "平时用本机屏幕开；远程时先在设置里关掉壁纸。",
        })

    return {"blockers": blockers, "warns": warns, "info": info,
            "ok": not blockers}


def mark_low_memory():
    """低内存机器打个标记，界面据此少画东西（壁纸、预告片）。"""
    mem = memory_mb()
    if mem and mem < 4096:
        os.environ["OMC_LOW_MEM"] = "1"
        return True
    return False


def low_memory():
    if os.environ.get("OMC_LOW_MEM"):
        return True
    return mark_low_memory()


def report_text(res=None):
    """自检报告（给日志 / 命令行 --doctor 用）。"""
    r = res or checks()
    lines = ["OMC 启动器自检", ""]
    for k, v in sorted(r["info"].items()):
        lines.append("  %-12s %s" % (k, v))
    lines.append("")
    if r["blockers"]:
        lines.append("跑不起来：")
        for b in r["blockers"]:
            lines.append("  · %s" % b["title"])
            lines.append("    %s" % b["detail"])
            lines.append("    怎么办：%s" % b["fix"])
    else:
        lines.append("可以让启动器跑起来。")
    if r["warns"]:
        lines.append("")
        lines.append("需要注意：")
        for w in r["warns"]:
            lines.append("  · %s" % w["title"])
            lines.append("    %s" % w["detail"])
            lines.append("    怎么办：%s" % w["fix"])
    return "\n".join(lines)


# ---------------------------------------------------------------- 跟系统说话
def native_alert(title, text):
    """在 Qt 还没起来的时候弹一个系统原生框（ctypes，不依赖任何 GUI 库）。"""
    if WINDOWS:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                None, text, title, 0x00000010 | 0x00040000)   # MB_ICONERROR | MB_TOPMOST
            return True
        except Exception:
            pass
    else:
        try:
            sys.stderr.write("%s\n%s\n" % (title, text))
        except Exception:
            pass
    return False


def _log_dir():
    d = os.path.expanduser("~/.simple_mc_launcher")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        return ""
    return d


def write_log(text):
    d = _log_dir()
    if not d:
        return ""
    p = os.path.join(d, _LOG_NAME)
    try:
        with open(p, "w", encoding="utf-8") as f:
            f.write(text)
        return p
    except Exception:
        return ""


def preflight(gui=True, quiet=False):
    """启动前跑一次。返回 True 表示可以继续开界面。

    老系统上会弹原生框说清楚原因后返回 False，调用方直接退出——这样
    用户看到的是「为什么跑不了」，而不是一闪而过的黑框。
    """
    res = checks()
    text = report_text(res)
    write_log(text)
    if not res["ok"]:
        if gui and not quiet:
            msg = []
            for b in res["blockers"]:
                msg.append(b["title"])
                msg.append("")
                msg.append(b["detail"])
                msg.append("")
                msg.append("怎么办：")
                msg.append(b["fix"])
                msg.append("")
            msg.append("自检报告已经写在：%s" % os.path.join(_log_dir(), _LOG_NAME))
            native_alert("OMC 启动器：这台电脑跑不了这个包", "\n".join(msg))
        return False
    mark_low_memory()
    return True


if __name__ == "__main__":
    print(report_text())
