# -*- coding: utf-8 -*-
"""本地小代理：给播放器用。

B 站的 mp4 直链要求带 Referer，QMediaPlayer 没法设自定义请求头，
所以在本机起一个只转发的小服务：播放器播 127.0.0.1 的地址，这里再带上
Referer / UA 去取远端，Range 原样透传，拖动进度条也能用。
"""
import http.server
import re
import socket
import socketserver
import threading
import urllib.parse
import urllib.request

# googlevideo 只认「有头有尾」的 Range（bytes=0-999）。开放式 bytes=0- 或者
# 干脆不带 Range 的请求一律 403 —— 播放器最爱发的偏偏就是 bytes=0-，
# 于是「地址明明拿到了，画面却一直在缓冲」。这里自己拆成一段段有线范围，
# 拼成一个完整响应喂给播放器。
#
# 每段都是一次新的 TLS 连接（open → 读 → 关），所以段不能太小：以前 512KB
# 一段，看一条 1080p 视频要重连几百次，国外线路一来一回 100ms+，表现出来
# 就是「海外 IP 看油管一直转圈」。改成 8MB 一段后重连次数降到十几分之一。
_CHUNK = 8 * 1024 * 1024
# 每次从上游往播放器搬多少：加大到 256KB，减少 write 调用次数。
_BUF = 256 * 1024

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# googlevideo 会校验「取 URL 的人和拉流的人是同一个客户端」：
# yt-dlp / ANDROID_VR 取到的地址，用浏览器 UA 去拉经常直接 403，
# 表现就是「油管视频播不出来、一直在缓冲」。所以按站点给对的 UA。
VR_UA = ("com.google.android.apps.youtube.vr.oculus/1.60.19 "
         "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip")


def _ref_for(url):
    host = urllib.parse.urlsplit(url).netloc.lower()
    if "bilivideo" in host or "bilibili" in host:
        return "https://www.bilibili.com/"
    if "hdslb" in host:
        return "https://www.bilibili.com/"
    if "googlevideo" in host or "youtube" in host:
        return "https://www.youtube.com/"
    return ""


def _ua_for(url):
    host = urllib.parse.urlsplit(url).netloc.lower()
    if "googlevideo" in host or "youtube" in host:
        return VR_UA
    return UA


class _Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        # 本机回环上 Nagle 会把小包攒在一起发，256KB 一块本来不该受影响，
        # 但拖动进度条、切流时的小响应会被拖 40ms 量级，表现为「点了没反应」。
        super().setup()
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass

    def log_message(self, *a):
        pass                      # 别把转发日志刷到控制台

    def _target(self):
        q = urllib.parse.urlsplit(self.path).query
        params = urllib.parse.parse_qs(q)
        u = (params.get("u") or [""])[0]
        if not u:
            return ""
        # 有些客户端会把 url 再编一次
        if not u.startswith("http"):
            u = urllib.parse.unquote(u)
        return u

    def _up(self, target, start, end):
        """向上游要一段有线范围 [start, end]。"""
        headers = {"User-Agent": _ua_for(target), "Accept": "*/*",
                   "Accept-Encoding": "identity",
                   "Range": "bytes=%d-%d" % (start, end)}
        ref = _ref_for(target)
        if ref:
            headers["Referer"] = ref
            headers["Origin"] = ref.rstrip("/")
        req = urllib.request.Request(target, headers=headers)
        op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        return op.open(req, timeout=20)

    def _relay_one(self, r, head_only=False):
        """把上游的一次响应原样转给客户端。"""
        status = getattr(r, "status", 200)
        self.send_response(status)
        for k in ("Content-Type", "Content-Length", "Content-Range",
                  "Accept-Ranges", "Last-Modified"):
            v = r.headers.get(k)
            if v:
                self.send_header(k, v)
        if not r.headers.get("Content-Type"):
            self.send_header("Content-Type", "video/mp4")
        self.send_header("Connection", "close")
        self.end_headers()
        if head_only:
            return
        while True:
            chunk = r.read(_BUF)
            if not chunk:
                break
            self.wfile.write(chunk)

    def _stream_chunked(self, target, start, total, head_only=False,
                        ranged=False):
        """开放式 Range：自己分块拉，拼成一个响应输出。"""
        ctype, lastmod = "video/mp4", None
        try:
            probe = self._up(target, start, min(start + 1023, total - 1))
            ctype = probe.headers.get("Content-Type") or ctype
            lastmod = probe.headers.get("Last-Modified")
            probe.close()
        except Exception:
            pass
        self.send_response(206 if ranged else 200)
        self.send_header("Content-Type", ctype)
        if lastmod:
            self.send_header("Last-Modified", lastmod)
        self.send_header("Accept-Ranges", "bytes")
        if ranged:
            self.send_header("Content-Range",
                             "bytes %d-%d/%d" % (start, total - 1, total))
        self.send_header("Content-Length", str(max(0, total - start)))
        self.send_header("Connection", "close")
        self.end_headers()
        if head_only:
            return
        # 顺序拉流：每 8MB 一段，段与段之间要重新建 TLS 连接并握手（100~400ms），
        # 这段时间一条字节都不往播放器下发，缓冲区一耗尽就是一次可见卡顿。
        # 改成「后台线程提前拉下一段、前台只管写 socket」，重连和数据下发重叠，
        # 段间空档基本消失（实测同样的视频，播放器缓冲水位从反复见底变成稳定）。
        import queue as _queue
        q = _queue.Queue(maxsize=96)
        _STOP = object()
        stop = threading.Event()

        def _produce():
            pos = start
            try:
                while pos < total and not stop.is_set():
                    stop_p = min(pos + _CHUNK - 1, total - 1)
                    r = self._up(target, pos, stop_p)
                    try:
                        while not stop.is_set():
                            chunk = r.read(_BUF)
                            if not chunk:
                                break
                            pos += len(chunk)
                            while not stop.is_set():
                                try:
                                    q.put(chunk, timeout=0.2)
                                    break
                                except _queue.Full:
                                    continue
                    finally:
                        try:
                            r.close()
                        except Exception:
                            pass
                    if pos <= start:      # 一点都没读到，别在这里死循环
                        break
            except Exception:
                pass
            finally:
                while not stop.is_set():
                    try:
                        q.put(_STOP, timeout=0.2)
                        break
                    except _queue.Full:
                        continue

        th = threading.Thread(target=_produce, name="videoproxy-stream",
                              daemon=True)
        th.start()
        try:
            while True:
                item = q.get()
                if item is _STOP:
                    break
                self.wfile.write(item)
        finally:
            stop.set()

    def _proxy(self, head_only=False):
        target = self._target()
        if not target:
            self.send_error(400, "missing u")
            return
        rng = (self.headers.get("Range") or "").strip()
        m = re.match(r"bytes=(\d+)-(\d*)$", rng)
        start = int(m.group(1)) if m else 0
        end_s = m.group(2) if m else ""
        host = urllib.parse.urlsplit(target).netloc.lower()
        chunked = ("googlevideo" in host or "youtube" in host)
        try:
            if end_s:
                # 有线范围：googlevideo 也照收，直接透传
                r = self._up(target, start, int(end_s))
                try:
                    self._relay_one(r, head_only)
                finally:
                    r.close()
                return
            if not chunked:
                # 别的站（B 站等）支持开放式 Range，原样透传最省事
                headers = {"User-Agent": _ua_for(target), "Accept": "*/*",
                           "Accept-Encoding": "identity"}
                if rng:
                    headers["Range"] = rng
                ref = _ref_for(target)
                if ref:
                    headers["Referer"] = ref
                    headers["Origin"] = ref.rstrip("/")
                op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                r = op.open(urllib.request.Request(target, headers=headers),
                            timeout=20)
                try:
                    self._relay_one(r, head_only)
                finally:
                    r.close()
                return
            # 开放式 / 不带 Range 的 googlevideo 请求：先探总长再分块拼流
            probe = self._up(target, start, start + 1023)
            crange = probe.headers.get("Content-Range") or ""
            probe.close()
            total = 0
            if "/" in crange:
                try:
                    total = int(crange.rsplit("/", 1)[1])
                except Exception:
                    total = 0
            if total <= 0:
                r = self._up(target, start, start + 1023)
                try:
                    self._relay_one(r, head_only)
                finally:
                    r.close()
                return
            self._stream_chunked(target, start, total, head_only,
                                 ranged=bool(rng))
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self.send_error(502, "upstream: %s" % e)
            except Exception:
                pass

    def do_GET(self):
        self._proxy(False)

    def do_HEAD(self):
        self._proxy(True)


class _Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class StreamProxy(object):
    """一个进程里只起一次。"""

    _inst = None
    _lock = threading.Lock()

    def __init__(self):
        self.port = 0
        self._srv = None
        self._thread = None

    @classmethod
    def get(cls):
        with cls._lock:
            if cls._inst is None or cls._inst.port == 0:
                inst = StreamProxy()
                inst.start()
                cls._inst = inst
            return cls._inst

    def start(self):
        try:
            self._srv = _Server(("127.0.0.1", 0), _Handler)
        except Exception:
            self.port = 0
            return
        self.port = self._srv.server_address[1]
        self._thread = threading.Thread(target=self._srv.serve_forever,
                                        daemon=True)
        self._thread.start()

    def stop(self):
        try:
            if self._srv is not None:
                self._srv.shutdown()
                self._srv.server_close()
        except Exception:
            pass
        self.port = 0

    def local_url(self, target):
        if not self.port:
            return target
        return "http://127.0.0.1:%d/v?u=%s" % (
            self.port, urllib.parse.quote(target, safe=""))


def local_url(target):
    return StreamProxy.get().local_url(target)


def _port_free_probe():
    """自检用：拿一个空闲端口。"""
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()
