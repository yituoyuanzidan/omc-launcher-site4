# -*- coding: utf-8 -*-
"""多 Java 管理：把机器上的所有 Java 列出来，并允许给某个版本钉死用哪个。

检测逻辑复用 java_utils（带磁盘缓存，第二次启动不再跑子进程），
这里只多做三件事：
1. 列出全部候选并标好主版本号
2. 按版本自动推荐（就沿用 java_utils.version_major）
3. 记住「这个实例用哪个 Java」，存进 config 的 java_map
"""
import os

from . import java_utils, platform_utils


def label_for(path, major):
    """把路径拆成人能看的一行：厂商 + 版本 + 路径尾巴。"""
    low = path.lower()
    vendor = ""
    if "adoptium" in low or "temurin" in low:
        vendor = "Temurin"
    elif "zulu" in low:
        vendor = "Zulu"
    elif "graal" in low:
        vendor = "GraalVM"
    elif "corretto" in low:
        vendor = "Corretto"
    elif "oracle" in low:
        vendor = "Oracle"
    elif "microsoft" in low:
        vendor = "Microsoft"
    elif "jbr" in low or "jetbrains" in low:
        vendor = "JetBrains"
    parts = [p for p in os.path.normpath(path).split(os.sep) if p]
    tail = " / ".join(parts[-3:-1])
    name = "Java %s" % (major or "?")
    if vendor:
        name = "%s %s" % (vendor, major or "?")
    return "%s　%s" % (name, tail)


def list_all():
    """[{path, major, label, version}]，按主版本倒序。"""
    rows = []
    for p in java_utils.candidate_javas():
        try:
            major = java_utils.java_major(p)
        except Exception:
            major = 0
        rows.append({"path": p, "major": major,
                     "version": java_utils.java_version(p),
                     "label": label_for(p, major)})
    rows.sort(key=lambda r: r["major"], reverse=True)
    return rows


def recommended(version_id, mc_version=""):
    """按 MC 版本号推一个 Java 主版本，并挑最合适的路径。"""
    need = java_utils.version_major(mc_version or version_id)
    path = java_utils.pick_for(need)
    return {"need": need, "path": path,
            "reason": "这个版本通常要 Java %d" % need,
            "have": [r["major"] for r in list_all()]}


def get_pref(cfg, version_id):
    """取某实例钉死的 Java；没钉过就返回空串。"""
    data = cfg.get("java_map") or {}
    if not isinstance(data, dict):
        return ""
    p = data.get(version_id) or ""
    return p if p and os.path.exists(p) else ""


def set_pref(cfg, version_id, java_path):
    data = cfg.get("java_map") or {}
    if not isinstance(data, dict):
        data = {}
    if java_path:
        data[version_id] = java_path
    else:
        data.pop(version_id, None)
    cfg.set("java_map", data)
    cfg.save()
    return data


def resolve(cfg, version_id, mc_version=""):
    """真正启动时用哪个：先看钉死的，再自动挑。"""
    pinned = get_pref(cfg, version_id)
    if pinned:
        return pinned
    return java_utils.pick_for(java_utils.version_major(mc_version or version_id))


# ---------- 内存 ----------

def total_ram_mb():
    """物理内存总量（MB），取不到返回 0。"""
    try:
        if platform_utils.WINDOWS:
            import ctypes

            class _M(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            m = _M()
            m.dwLength = ctypes.sizeof(_M)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullTotalPhys / 1048576)
        if platform_utils.MACOS:
            import re
            out = os.popen("sysctl -n hw.memsize").read()
            return int(re.sub(r"\D", "", out) or 0) // 1048576
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        return 0
    return 0


MEMORY_CHOICES = (2048, 4096, 8192, 16384, 32768)


def memory_tips(total_mb=0):
    """给出这机器上适用的档位，并标出推荐的那个（≈总量 45%，上限 16G）。"""
    total = total_mb or total_ram_mb()
    if not total:
        return [{"mb": mb, "label": "%dG" % (mb // 1024), "recommend": mb == 4096}
                for mb in MEMORY_CHOICES[:4]]
    cap = min(16384, max(2048, int(total * 0.45 // 1024) * 1024))
    rows = []
    for mb in MEMORY_CHOICES:
        if mb > total * 0.8:
            continue
        rows.append({"mb": mb, "label": "%dG" % (mb // 1024),
                     "recommend": mb == cap})
    if not rows:
        rows = [{"mb": 2048, "label": "2G", "recommend": True}]
    return rows
