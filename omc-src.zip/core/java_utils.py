# -*- coding: utf-8 -*-
"""Java 运行环境检测（Windows / macOS / Linux 通用）。"""
import json
import os
import re
import shutil
import subprocess

from . import platform_utils

_CACHE_FILE = os.path.join(platform_utils.data_dir(), "java_cache.json")


def _load_disk_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_disk_cache(data):
    try:
        os.makedirs(os.path.dirname(_CACHE_FILE), exist_ok=True)
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


def candidate_javas():
    found = []
    binname = platform_utils.java_binary_name()
    java_home = os.environ.get("JAVA_HOME")
    if java_home:
        found.append(os.path.join(java_home, "bin", binname))
    on_path = shutil.which("java")
    if on_path:
        found.append(on_path)

    # 各系统的常见 JDK 目录、PATH 之外的兜底位置，全部交给 platform_utils
    found.extend(platform_utils.java_extra_candidates())

    uniq = []
    for p in found:
        p = os.path.normpath(p)
        if p not in uniq and os.path.exists(p):
            uniq.append(p)
    return uniq


def java_version(java_path):
    try:
        flags = platform_utils.no_window_flags()
        out = subprocess.run(
            [java_path, "-version"], capture_output=True, text=True, timeout=15,
            creationflags=flags
        )
        text = (out.stderr or "") + (out.stdout or "")
        m = re.search(r'version "([^"]+)"', text)
        return m.group(1) if m else text.strip()
    except Exception:
        return "unknown"


_VERSION_CACHE = {}


def java_major(java_path):
    """返回 Java 主版本号，无法识别时返回 0（带磁盘缓存，避免每次启动都跑子进程）。"""
    if java_path in _VERSION_CACHE:
        return _VERSION_CACHE[java_path]

    path = os.path.normpath(java_path)
    sig = None
    try:
        st = os.stat(path)
        sig = [int(st.st_mtime), st.st_size]
    except Exception:
        pass

    disk = _load_disk_cache()
    rec = disk.get(path)
    if rec and rec.get("sig") == sig and isinstance(rec.get("major"), int):
        _VERSION_CACHE[java_path] = rec["major"]
        return rec["major"]

    v = java_version(java_path)
    mm = re.match(r"1\.(\d+)", v)
    if mm:
        major = int(mm.group(1))
    else:
        mm = re.match(r"(\d+)", v)
        major = int(mm.group(1)) if mm else 0
    _VERSION_CACHE[java_path] = major

    if sig:
        disk[path] = {"sig": sig, "major": major}
        _save_disk_cache(disk)
    return major


def pick_for(required_major):
    """按版本要求挑选 Java：优先恰好匹配，其次高于要求里最接近的那个。"""
    candidates = candidate_javas()
    if not candidates:
        return ""
    scored = [(java_major(p), p) for p in candidates]
    if required_major:
        exact = [p for m, p in scored if m == required_major]
        if exact:
            return exact[0]
        higher = [(m, p) for m, p in scored if m >= required_major]
        if higher:
            return min(higher, key=lambda x: x[0])[1]
    ranked = sorted(scored, key=lambda x: x[0], reverse=True)
    return ranked[0][1]


def pick_exact(required_major):
    """只要恰好是这个主版本的 Java；没有就返回空串（不拿高版本凑数）。"""
    if not required_major:
        return ""
    for p in candidate_javas():
        try:
            if java_major(p) == required_major:
                return p
        except Exception:
            continue
    return ""


def version_major(ver):
    """按 MC 版本号推断它要哪个 Java —— 版本 json 还没下下来时靠这个。

    1.16 及以下 → 8，1.17 → 16，1.18–1.20.4 → 17，1.20.5 以后 → 21。
    """
    s = (ver or "").strip().lower()
    s = s.split("-")[0].split("_")[0]
    try:
        parts = [int(x) for x in s.replace(" ", "").split(".")]
    except Exception:
        return 21
    if parts and parts[0] >= 2:
        return 25          # 26.x 之后的新版本线要 Java 25
    if parts and parts[0] == 1 and len(parts) >= 2:
        minor = parts[1]
        patch = parts[2] if len(parts) > 2 else 0
        if minor <= 16:
            return 8
        if minor == 17:
            return 16
        if minor <= 19:
            return 17
        if minor == 20:
            return 21 if patch >= 5 else 17
        return 21
    return 21


def auto_pick():
    return pick_for(17)
