# -*- coding: utf-8 -*-
"""把日志 zip 传到一个不用登录的临时空间，换一个链接出来。

用 tmpfiles.org 的公开接口：不需要账号、不需要 key，文件在那边只放一阵子，
所以只适合「把这份日志递给看的人」，不适合当存档。
失败就如实把原因交回去，不假装成功。
"""
import json
import os
import uuid
import urllib.request

UA = "OMC/1.0"
API = "https://tmpfiles.org/api/v1/upload"


def _multipart(path):
    boundary = "----OMC%s" % uuid.uuid4().hex
    name = os.path.basename(path)
    with open(path, "rb") as f:
        data = f.read()
    head = ("--%s\r\nContent-Disposition: form-data; name=\"file\"; "
            "filename=\"%s\"\r\nContent-Type: application/octet-stream\r\n\r\n"
            % (boundary, name)).encode("utf-8")
    tail = ("\r\n--%s--\r\n" % boundary).encode("utf-8")
    return head + data + tail, boundary


def upload(path, timeout=60):
    """传一个文件，返回 (ok, 链接或错误说明)。"""
    if not os.path.isfile(path):
        return False, "文件不存在：%s" % path
    try:
        body, boundary = _multipart(path)
    except OSError as e:
        return False, "读不了文件：%s" % e
    req = urllib.request.Request(
        API, data=body, method="POST",
        headers={"User-Agent": UA,
                 "Content-Type": "multipart/form-data; boundary=%s" % boundary})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
    except Exception as e:
        return False, "上传失败：%s" % e
    try:
        data = json.loads(raw)
    except Exception:
        return False, "上传接口返回看不懂：%s" % raw[:160]
    url = str((data.get("data") or {}).get("url") or "")
    if not url:
        return False, "上传接口没给链接：%s" % raw[:160]
    # 公开直链是把页面地址换成 /dl/
    url = url.replace("tmpfiles.org/", "tmpfiles.org/dl/")
    return True, url
