# -*- coding: utf-8 -*-
"""崩溃日志分析：读 logs/latest.log 与 crash-reports，定位常见崩溃原因并给可执行建议。

不是万能诊断，只是把日志里最容易复现的几类问题提出来，省得玩家翻几千行英文。
"""
import glob
import os
import re

# (正则, 结论, 建议)
RULES = [
    (r"OutOfMemoryError|Java heap space|GC overhead limit",
     "内存不够",
     "把设置里的内存调大（比如 +2048MB），或减少模组数量。"),
    (r"UnsupportedClassVersionError|class file version",
     "Java 版本不匹配",
     "这个版本要求的 Java 比当前高/低，换对应 Java（1.16 及以下用 Java 8，"
     "1.17-1.20.4 用 Java 17，1.20.5 之后用 Java 21）。"),
    (r"Missing or unsupported mandatory dependencies|requires .* of mod",
     "模组缺少前置依赖",
     "日志里点名的前置模组没装或版本不对，装上对应版本的前置（Fabric API / "
     "Architectury / Cloth Config 之类）。"),
    (r"DuplicateModsFoundException|Found duplicate mods",
     "装了重复模组",
     "mods 文件夹里有同一个模组的两个版本，删掉旧的那个。"),
    (r"Mixin apply failed|MixinTransformerError|mixin.*failed",
     "Mixin 注入冲突",
     "通常是模组之间或模组与当前游戏版本不兼容，按日志里提到的模组名逐个禁用排查。"),
    (r"java.lang.NoClassDefFoundError|ClassNotFoundException",
     "缺类/库不完整",
     "游戏文件或模组依赖缺失，用「完整性校验」补全文件后重试。"),
    (r"GLFW error|Failed to create window|OpenGL|Pixel format not accelerated|"
     r"org.lwjgl.LWJGLException",
     "显卡/OpenGL 问题",
     "更新显卡驱动；远程桌面或虚拟机里常出这个，换本机屏幕直接运行。"),
    (r"Ticking entity|Ticking block entity|Exception ticking",
     "某个模组在游戏内崩了",
     "这类崩溃通常由特定实体/方块触发，按日志里的 modid 找出模组并禁用。"),
    (r"AccessDeniedException|拒绝访问|Permission denied",
     "文件被占用或没权限",
     "关掉正在占用游戏目录的程序（另一个启动器/游戏本身），"
     "或把游戏目录换成非系统盘路径。"),
    (r"java.lang.VerifyError|Invalid or corrupt jarfile",
     "jar 文件损坏",
     "重新下载该版本或重新拖入模组文件。"),
    (r"Your game crashed|An unexpected issue occurred",
     "游戏异常退出",
     "先看下方日志末尾的实际异常行，再对照上面几条。"),
]

MOD_HINT = re.compile(r"(?:mod|模组)\s*[:\s]\s*([a-z0-9_\-]{3,32})", re.I)


def latest_files(game_dir):
    """返回 (crash_report_path, latest_log_path)，没有的为 None。"""
    crash = None
    reports = sorted(glob.glob(os.path.join(game_dir, "crash-reports",
                                            "crash-*.txt")),
                     key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)
    if reports:
        crash = reports[-1]
    log = os.path.join(game_dir, "logs", "latest.log")
    if not os.path.exists(log):
        log = None
    return crash, log


def read_text(path, limit=60000):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()[-limit:]
    except Exception:
        return ""


def analyze(text):
    """返回 dict：hits=[(结论, 建议, 命中片段)]、suspects=[模组名]、tail=末几行。"""
    hits = []
    for pattern, verdict, advice in RULES:
        m = re.search(pattern, text, re.I)
        if m:
            snippet = text[max(0, m.start() - 60):m.end() + 60].strip()
            hits.append((verdict, advice, snippet))
    suspects = sorted(set(m.group(1).lower() for m in MOD_HINT.finditer(text)))
    tail = [ln for ln in text.strip().splitlines()[-12:] if ln.strip()]
    return {"hits": hits, "suspects": suspects[:12], "tail": tail}


def analyze_game_dir(game_dir):
    crash, log = latest_files(game_dir)
    source = crash or log
    if not source:
        return {"source": None, "hits": [], "suspects": [], "tail": []}
    text = read_text(source)
    result = analyze(text)
    result["source"] = source
    return result
