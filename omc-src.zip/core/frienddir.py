# -*- coding: utf-8 -*-
"""好友目录：让大家能按账号名互相搜到。

没有自己的服务器，就用 ntfy.sh 的公共消息通道做一个很轻的「谁最近在线」目录：
账号登录时往固定主题发一条自己（只发用户名 + 随机 uid，不发邮箱），
搜索时把最近 12 小时的公告拉下来，按名字过滤。

限制说白了：只覆盖最近 12 小时内登录过的人；要长期可搜、跨设备唯一，
得有一台自己的后端（Supabase 那套），配好后这里会自动改从后端查。
"""
import json
import time
import urllib.request

TOPIC = "omc-dir-9m3t7xw2q8rk"
BASE = "https://ntfy.sh"
UA = "OMC/1.0"
SINCE = "12h"
TIMEOUT = 10


def _post(payload, timeout=TIMEOUT):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(BASE + "/" + TOPIC, data=body,
                                 headers={"Title": "OMC", "User-Agent": UA},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return 200 <= r.getcode() < 300


def announce(name, uid, allow=True, status="launcher"):
    """把自己挂到目录上；关掉「允许被搜到」就不发。

    status 说明现在在干什么：launcher = 开着启动器，game = 正在游戏里。
    """
    if not allow or not name:
        return False
    payload = {"t": "acc", "n": str(name)[:32], "u": str(uid)[:24],
               "ts": int(time.time()), "st": str(status or "launcher")[:12]}
    try:
        from core import avatar
        av = avatar.mini_b64(name)
        if av:
            payload["av"] = av
    except Exception:
        pass
    try:
        return _post(payload)
    except Exception:
        return False


def fetch(since=SINCE, timeout=TIMEOUT):
    """拉目录，按 uid 取最新一条，返回 [{name, uid, ts}]。"""
    url = "%s/%s/json?poll=1&since=%s" % (BASE, TOPIC, since)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode("utf-8", "replace")
    seen = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception:
            continue
        if item.get("event") and item.get("event") != "message":
            continue
        try:
            payload = json.loads(item.get("message") or "{}")
        except Exception:
            continue
        if payload.get("t") != "acc":
            continue
        uid = str(payload.get("u") or "").strip()
        name = str(payload.get("n") or "").strip()
        if not uid or not name:
            continue
        ts = int(payload.get("ts") or item.get("time") or 0)
        st = str(payload.get("st") or "launcher")[:12]
        av = str(payload.get("av") or "")
        if av:
            try:
                from core import avatar
                avatar.save_remote(name, av)
            except Exception:
                pass
        if uid not in seen or ts >= seen[uid]["ts"]:
            seen[uid] = {"name": name, "uid": uid, "ts": ts, "av": av, "st": st}
    return sorted(seen.values(), key=lambda x: -x["ts"])


def search(query, local_names=(), since=SINCE):
    """按账号名搜：先列本机自己的账号，再列目录里最近在线的。

    返回 [{name, uid, src}]，src 是 "本机" / "在线目录" / "本机/在线"。

    按「名字」去重，不按 uid：本机账号那条没有 uid，目录那条有，
    两路各塞一遍就会同一个人出现两次（1.7.63 的老 bug）。
    合并后保留目录里的 uid / 在线状态，src 标成 "本机/在线"。
    """
    q = (query or "").strip().lower()
    out = {}
    order = []

    def key_of(name):
        return (name or "").strip().lower()

    for name in local_names or ():
        name = (name or "").strip()
        if not name:
            continue
        if q and q not in name.lower():
            continue
        k = key_of(name)
        if not k or k in out:
            continue
        out[k] = {"name": name, "uid": "", "src": "本机", "ts": 0,
                  "st": "launcher"}
        order.append(k)
    try:
        for row in fetch(since=since):
            nm = (row.get("name") or "").strip()
            if not nm:
                continue
            if q and q not in nm.lower():
                continue
            k = key_of(nm)
            if not k:
                continue
            if k in out:
                prev = out[k]
                if not prev.get("uid"):
                    prev["uid"] = row.get("uid") or ""
                prev["src"] = ("本机/在线" if prev["src"] == "本机"
                               else "在线目录")
                # 名字以目录里最新的写法为准（对方可能改过大小写）
                prev["name"] = nm
                if int(row.get("ts") or 0) > int(prev.get("ts") or 0):
                    prev["ts"] = int(row.get("ts") or 0)
                    prev["st"] = row.get("st") or "launcher"
                continue
            out[k] = {"name": nm, "uid": row.get("uid") or "", "src": "在线目录",
                      "ts": int(row.get("ts") or 0),
                      "st": row.get("st") or "launcher"}
            order.append(k)
    except Exception:
        pass
    rows = [out[k] for k in order]
    rows.sort(key=lambda x: -int(x.get("ts") or 0))
    return rows
