# -*- coding: utf-8 -*-
"""Modrinth 资源浏览与下载：模组、资源包、光影（接口开放，无需 API key）。

几个原则：
- 资源包/光影基本跨版本通用，不拿 MC 版本去筛，否则很容易筛成 0 条；
- 下载时先按版本+加载器精确找，找不到就退回该项目的通用最新文件，避免"点下载没反应"；
- 搜索结果留一小段内存缓存，翻页/来回切页签不重复请求。
"""
import hashlib
import json
import os
import time
import urllib.parse

from . import http, platform_utils

API = "https://api.modrinth.com/v2"
LIMIT = 20

_CACHE = {}
_CACHE_TTL = 180
_DISK_TTL = 6 * 3600


def _disk_path(key):
    h = hashlib.sha1(repr(key).encode("utf-8")).hexdigest()[:20]
    d = os.path.join(platform_utils.data_dir(), "cache", "modrinth")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        return ""
    return os.path.join(d, h + ".json")


def _disk_get(key):
    path = _disk_path(key)
    if not path:
        return None
    try:
        if time.time() - os.path.getmtime(path) > _DISK_TTL:
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) and len(data) == 2 else None
    except Exception:
        return None


def _disk_put(key, hits, total):
    path = _disk_path(key)
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump([hits, total], f, ensure_ascii=False)
    except Exception:
        pass


def search(project_type, mc_version=None, query="", loader=None,
           offset=0, limit=LIMIT, category=None):
    """按类型搜索，返回 (结果列表, 总数)。

    category 是 Modrinth 的分类（adventure / technology / magic / optimization
    ……），和 loader 都落在 facets 的 categories 上，但必须是**两个独立的
    facet 数组**：同一个数组内是「或」，数组之间是「与」。
    """
    key = (project_type, mc_version or "", query or "", loader or "",
           category or "", offset, limit)
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < _CACHE_TTL:
        return hit[1], hit[2]
    disk = _disk_get(key)
    if disk:
        _CACHE[key] = (time.time(), disk[0], disk[1])
        return disk[0], disk[1]

    facets = [["project_type:%s" % project_type]]
    if mc_version:
        facets.append(["versions:%s" % mc_version])
    if loader:
        facets.append(["categories:%s" % loader])
    if category:
        facets.append(["categories:%s" % category])
    params = urllib.parse.urlencode({
        "facets": json.dumps(facets),
        "query": query or "",
        "offset": offset,
        "limit": limit,
        "index": "relevance",
    })
    url = API + "/search?" + params
    data = None
    for attempt in range(3):
        try:
            data = http.fetch_json(url, "official", timeout=15, retries=2)
            break
        except Exception:
            if attempt >= 2:
                raise
            time.sleep(0.5 * (attempt + 1))
    hits, total = data.get("hits") or [], data.get("total_hits", 0)
    _CACHE[key] = (time.time(), hits, total)
    _disk_put(key, hits, total)
    return hits, total


def project_versions(project_id, mc_version=None, loader=None):
    """取项目的版本（文件）列表，按发布时间倒序。"""
    params = []
    if mc_version:
        params.append("game_versions=" + urllib.parse.quote(
            json.dumps([mc_version])))
    if loader:
        params.append("loaders=" + urllib.parse.quote(json.dumps([loader])))
    url = API + "/project/%s/version" % project_id
    if params:
        url += "?" + "&".join(params)
    versions = http.fetch_json(url, "official", timeout=15, retries=2)
    return versions or []


def pick_file(version, prefer_zip=False):
    """从版本里挑一个合适的文件；资源包/光影优先挑 zip。"""
    files = version.get("files") or []
    if not files:
        return None
    if prefer_zip:
        zips = [f for f in files
                if (f.get("filename") or "").lower().endswith(".zip")]
        if zips:
            return zips[0]
    primary = [f for f in files if f.get("primary")]
    if primary:
        return primary[0]
    return files[0]


def download_project(project_id, mc_version, loader, dest_dir, log,
                     filename=None, progress_cb=None, project_type=None):
    """下载项目最新可用版本到目标目录，返回落地路径。

    精确条件找不到文件时回退到项目完整版本列表，保证「能下载」优先。
    """
    prefer_zip = project_type in ("resourcepack", "shader")
    versions = project_versions(project_id, mc_version, loader)
    if not versions:
        versions = project_versions(project_id, None, None)
    if not versions:
        raise RuntimeError("这个项目暂时没有可下载的文件")

    file = pick_file(versions[0], prefer_zip)
    if not file:
        raise RuntimeError("版本里没有文件")
    name = filename or file["filename"]
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    http.download_file(file["url"], dest, "official",
                       progress=progress_cb,
                       size=file.get("size") or None,
                       sha1=file.get("hashes", {}).get("sha1"))
    log("已下载：%s" % name)
    return dest
