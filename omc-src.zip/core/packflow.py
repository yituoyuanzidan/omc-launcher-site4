# -*- coding: utf-8 -*-
"""批量导入导出：一次把一整个文件夹的模组/光影/资源包/数据包装进来，或者反着打包带走。

导入只做「复制到对应目录」，绝不覆盖同名文件：重名的会自动加 -2、-3。
导出打成一个 zip，里面按目录分好，收到的人解到 .minecraft 里就能用。
"""
import os
import shutil
import time
import zipfile

KIND_DIRS = {
    "mod": "mods",
    "shader": "shaderpacks",
    "resourcepack": "resourcepacks",
    "datapack": "datapacks",
}
KIND_NAMES = {
    "mod": "模组",
    "shader": "光影",
    "resourcepack": "资源包",
    "datapack": "数据包",
}
KIND_EXTS = {
    "mod": (".jar", ".jar.disabled"),
    "shader": (".zip",),
    "resourcepack": (".zip",),
    "datapack": (".zip",),
}


def target_dir(game_dir, kind):
    name = KIND_DIRS.get(kind)
    if not name:
        raise ValueError("不认识的类型：%s" % kind)
    d = os.path.join(game_dir, name)
    os.makedirs(d, exist_ok=True)
    return d


def classify(name, kind=""):
    """按扩展名猜类型；kind 明确给了就直接用。"""
    if kind in KIND_DIRS:
        return kind
    low = (name or "").lower()
    if low.endswith(".jar") or low.endswith(".jar.disabled"):
        return "mod"
    if low.endswith(".zip"):
        return ""      # zip 可能是光影/资源包/数据包，需要人来定
    return ""


def _unique(dst_dir, name):
    """同名不覆盖：a.jar -> a-2.jar。"""
    base, ext = os.path.splitext(name)
    if name.lower().endswith(".jar.disabled"):
        base, ext = name[:-len(".jar.disabled")], ".jar.disabled"
    cand = name
    i = 2
    while os.path.exists(os.path.join(dst_dir, cand)):
        cand = "%s-%d%s" % (base, i, ext)
        i += 1
    return cand


def import_many(game_dir, paths, kind="", log=None):
    """把 files/目录 里的文件导进对应目录。

    返回 {"ok":[...], "dup":[...], "skip":[...], "error":[...]}
    """
    log = log or (lambda _m: None)
    out = {"ok": [], "dup": [], "skip": [], "error": []}
    files = []
    for p in paths or []:
        if os.path.isdir(p):
            for root, _dirs, names in os.walk(p):
                for n in names:
                    files.append(os.path.join(root, n))
        elif os.path.isfile(p):
            files.append(p)
    for src in files:
        name = os.path.basename(src)
        k = classify(name, kind)
        if not k:
            out["skip"].append("%s（认不出类型，请先选目标）" % name)
            continue
        exts = KIND_EXTS.get(k, ())
        if exts and not name.lower().endswith(exts):
            out["skip"].append("%s（不是 %s 的格式）" % (name, KIND_NAMES[k]))
            continue
        dst_dir = target_dir(game_dir, k)
        dst_name = _unique(dst_dir, name)
        if dst_name != name:
            out["dup"].append("%s → %s" % (name, dst_name))
        try:
            shutil.copy2(src, os.path.join(dst_dir, dst_name))
            out["ok"].append(dst_name)
        except OSError as e:
            out["error"].append("%s：%s" % (name, e))
    log("批量导入完成：%d 个成功，%d 个重名改名，%d 个跳过，%d 个失败"
        % (len(out["ok"]), len(out["dup"]), len(out["skip"]), len(out["error"])))
    return out


def scan_installed(game_dir, kind):
    """列出已装的条目：名字、大小、时间。"""
    d = os.path.join(game_dir, KIND_DIRS.get(kind, ""))
    rows = []
    if not os.path.isdir(d):
        return rows
    exts = KIND_EXTS.get(kind, ())
    for name in sorted(os.listdir(d)):
        p = os.path.join(d, name)
        low = name.lower()
        if not os.path.isfile(p):
            continue
        if exts and not low.endswith(exts):
            continue
        try:
            st = os.stat(p)
        except OSError:
            continue
        rows.append({"name": name, "path": p,
                     "size_mb": round(st.st_size / 1048576.0, 2),
                     "mtime": st.st_mtime,
                     "disabled": low.endswith(".disabled")})
    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows


def _paidir(kind):
    return KIND_DIRS.get(kind, "")


def export_zip(game_dir, kind, names, out_path, log=None):
    """把选中条目打成一个 zip，内部保留「mods/」这种目录结构。"""
    log = log or (lambda _m: None)
    src_dir = os.path.join(game_dir, _paidir(kind))
    picked = []
    for n in names or []:
        p = os.path.join(src_dir, n)
        if os.path.isfile(p):
            picked.append((p, n))
    if not picked:
        raise RuntimeError("没有可导出的文件")
    folder = _paidir(kind)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.writestr("omc-export.json",
                   '{"kind":"%s","time":"%s","count":%d}'
                   % (kind, time.strftime("%Y-%m-%d %H:%M:%S"), len(picked)))
        for p, n in picked:
            z.write(p, "%s/%s" % (folder, n))
    size = os.path.getsize(out_path)
    log("已导出 %d 个%s：%s（%.1f MB）"
        % (len(picked), KIND_NAMES.get(kind, ""), os.path.basename(out_path),
           size / 1048576.0))
    return {"path": out_path, "files": len(picked),
            "size_mb": round(size / 1048576.0, 1)}


def find_duplicates(game_dir, kind):
    """同名但内容不同的重复（xxx.jar / xxx (1).jar），返回成对的组。"""
    import re
    d = os.path.join(game_dir, KIND_DIRS.get(kind, ""))
    if not os.path.isdir(d):
        return []
    groups = {}
    for name in os.listdir(d):
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            continue
        base = re.sub(r"(?: - 副本)?(?: \(\d+\))?(\.[a-z]+)$", r"\1", name, flags=re.I)
        groups.setdefault(base.lower(), []).append(name)
    return [g for g in groups.values() if len(g) > 1]
