# -*- coding: utf-8 -*-
"""桌面入口：Windows 建 .lnk，Linux 建 .desktop，macOS 由 .app 本身承担（跳过）。

打包成 exe/app 后首次运行自动创建，避免用户手动建。
"""
import os
import shutil
import subprocess
import sys
import tempfile

from . import platform_utils

SHORTCUT_NAME = "OMC启动器"


def desktop_dir():
    """当前用户桌面路径，三平台各走各的。"""
    if platform_utils.WINDOWS:
        import ctypes
        buf = ctypes.create_unicode_buffer(260)
        # CSIDL_DESKTOPDIRECTORY = 0x0010
        try:
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0:
                return buf.value
        except Exception:
            pass
        return os.path.join(os.path.expanduser("~"), "Desktop")
    # macOS / Linux
    xdg = os.environ.get("XDG_DESKTOP_DIR")
    if xdg and os.path.isdir(os.path.expanduser(xdg)):
        return os.path.expanduser(xdg)
    for name in ("Desktop", "桌面"):
        p = os.path.join(os.path.expanduser("~"), name)
        if os.path.isdir(p):
            return p
    return os.path.join(os.path.expanduser("~"), "Desktop")


def shortcut_path(name=SHORTCUT_NAME):
    if platform_utils.LINUX:
        return os.path.join(desktop_dir(), name + ".desktop")
    return os.path.join(desktop_dir(), name + ".lnk")


def _ps_quote(text):
    return text.replace("`", "``").replace('"', '`"')


def _shell_exe():
    """找一个可用的 PowerShell：系统自带路径优先，避免 PATH 被精简。"""
    candidates = [
        r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        r"C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe",
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    for name in ("powershell", "pwsh"):
        p = shutil.which(name)
        if p:
            return p
    return None


def create_shortcut(target, working_dir, lnk, icon=None, description="OMC 启动器"):
    """Windows：用 WScript.Shell 生成 .lnk（中文路径通过临时 ps1 传递）。

    Linux：生成 .desktop 并加可执行位。macOS：.app 自带图标与入口，直接跳过。
    """
    if not platform_utils.WINDOWS:
        if platform_utils.LINUX:
            return _create_desktop_entry(target, working_dir, lnk, icon, description)
        return False

    icon = icon or target
    shell = _shell_exe()
    if not shell:
        return False
    script = (
        '$sh = New-Object -ComObject WScript.Shell\n'
        '$s = $sh.CreateShortcut("%s")\n'
        '$s.TargetPath = "%s"\n'
        '$s.WorkingDirectory = "%s"\n'
        '$s.IconLocation = "%s,0"\n'
        '$s.Description = "%s"\n'
        '$s.Save()\n'
    ) % tuple(_ps_quote(v) for v in (lnk, target, working_dir, icon, description))

    fd, path = tempfile.mkstemp(suffix=".ps1")
    os.close(fd)
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write(script)
    try:
        subprocess.run(
            [shell, "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", path],
            capture_output=True, timeout=40,
            creationflags=platform_utils.no_window_flags(),
        )
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    return os.path.exists(lnk)


def _desktop_entry_text(target, working_dir, icon, description):
    return (
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Version=1.0\n"
        "Name=%s\n"
        "Exec=\"%s\"\n"
        "Path=%s\n"
        "Icon=%s\n"
        "Terminal=false\n"
        "Categories=Game;\n"
        "Comment=%s\n"
    ) % (description, target, working_dir, icon or target, description)


def _create_desktop_entry(target, working_dir, path, icon, description):
    text = _desktop_entry_text(target, working_dir, icon, description)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        os.chmod(path, 0o755)
        # 同时装进应用菜单，从启动器里也能找到
        apps = os.path.join(os.path.expanduser("~"), ".local", "share", "applications")
        os.makedirs(apps, exist_ok=True)
        with open(os.path.join(apps, os.path.basename(path)), "w",
                  encoding="utf-8") as f:
            f.write(text)
        return os.path.exists(path)
    except Exception:
        return False


def ensure_desktop_shortcut(name=SHORTCUT_NAME, force=False):
    """仅在以打包产物运行时执行，源码运行不创建，避免指向 python。"""
    if not getattr(sys, "frozen", False):
        return None
    target = sys.executable
    lnk = shortcut_path(name)
    if os.path.exists(lnk) and not force:
        return lnk
    try:
        icon = target
        if platform_utils.LINUX:
            base = getattr(sys, "_MEIPASS", os.path.dirname(target))
            cand = os.path.join(base, "assets", "diamond_sword.png")
            if os.path.exists(cand):
                icon = cand
        ok = create_shortcut(target, os.path.dirname(target), lnk, icon=icon)
        return lnk if ok else None
    except Exception:
        return None
