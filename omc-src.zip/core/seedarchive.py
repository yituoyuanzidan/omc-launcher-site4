# -*- coding: utf-8 -*-
"""读存档里的种子：扫 saves 目录，解析 level.dat（gzip 压缩的 NBT）。

只为了拿几项显示用的字段，所以写了一小段够用的 NBT 读取，
不引第三方库，也不改存档里的任何东西。
"""
import gzip
import os
import struct
import time


class _NBTReader(object):
    def __init__(self, data):
        self.d = data
        self.i = 0

    def _need(self, n):
        if self.i + n > len(self.d):
            raise ValueError("NBT 数据不完整")

    def u1(self):
        self._need(1)
        v = self.d[self.i]
        self.i += 1
        return v

    def i2(self):
        self._need(2)
        v = struct.unpack_from(">h", self.d, self.i)[0]
        self.i += 2
        return v

    def u2(self):
        self._need(2)
        v = struct.unpack_from(">H", self.d, self.i)[0]
        self.i += 2
        return v

    def i4(self):
        self._need(4)
        v = struct.unpack_from(">i", self.d, self.i)[0]
        self.i += 4
        return v

    def i8(self):
        self._need(8)
        v = struct.unpack_from(">q", self.d, self.i)[0]
        self.i += 8
        return v

    def f4(self):
        self._need(4)
        v = struct.unpack_from(">f", self.d, self.i)[0]
        self.i += 4
        return v

    def f8(self):
        self._need(8)
        v = struct.unpack_from(">d", self.d, self.i)[0]
        self.i += 8
        return v

    def string(self):
        n = self.u2()
        self._need(n)
        s = self.d[self.i:self.i + n].decode("utf-8", "replace")
        self.i += n
        return s

    def payload(self, tag):
        if tag == 1:
            return self.u1()
        if tag == 2:
            return self.i2()
        if tag == 3:
            return self.i4()
        if tag == 4:
            return self.i8()
        if tag == 5:
            return self.f4()
        if tag == 6:
            return self.f8()
        if tag == 7:
            n = self.i4()
            self._need(n)
            b = self.d[self.i:self.i + n]
            self.i += n
            return b
        if tag == 8:
            return self.string()
        if tag == 9:
            sub = self.u1()
            n = self.i4()
            if sub == 0 or n <= 0:
                return []
            items = []
            for _ in range(min(n, 100000)):
                items.append(self.payload(sub))
                if sub == 10:
                    items[-1] = items[-1]        # 复合体已整体读完
            return items
        if tag == 10:
            return self.compound()
        if tag == 11:
            n = self.i4()
            self._need(4 * n)
            v = list(struct.unpack_from(">%di" % n, self.d, self.i))
            self.i += 4 * n
            return v
        if tag == 12:
            n = self.i4()
            self._need(8 * n)
            v = list(struct.unpack_from(">%dq" % n, self.d, self.i))
            self.i += 8 * n
            return v
        raise ValueError("不认识的 NBT 类型 %s" % tag)

    def compound(self):
        out = {}
        while True:
            tag = self.u1()
            if tag == 0:
                return out
            name = self.string()
            if tag == 9:
                # 列表要单独处理（元素名不存在），先读子类型和长度
                sub = self.u1()
                n = self.i4()
                vals = []
                for _ in range(min(max(0, n), 200000)):
                    if sub == 0:
                        break
                    if sub == 10:
                        vals.append(self.compound())
                    else:
                        vals.append(self.payload(sub))
                out[name] = vals
            else:
                out[name] = self.payload(tag)


def read_level_dat(path):
    """返回 {'seed','name','mtime','version','gametype'}，读不出来抛异常。"""
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    r = _NBTReader(raw)
    tag = r.u1()
    if tag != 10:
        raise ValueError("level.dat 根不是一个结构")
    r.string()                       # 根名字一般是空串
    root = r.compound()
    data = root.get("Data") if isinstance(root.get("Data"), dict) else root
    seed = data.get("RandomSeed")
    if not isinstance(seed, int):
        # 1.16 之后种子挪到了 WorldGenSettings.seed
        wgs = data.get("WorldGenSettings")
        if isinstance(wgs, dict):
            seed = wgs.get("seed")
    if not isinstance(seed, int):
        # 极少数存档用字符串形式，或者在世界级 compound 里
        for key in ("WorldGenSettings", "Data"):
            cur = root.get(key)
            if isinstance(cur, dict) and isinstance(cur.get("seed"), int):
                seed = cur.get("seed")
                break
    ver = data.get("Version")
    ver_name = ""
    if isinstance(ver, dict):
        ver_name = ver.get("Name") or ""
    return {
        "seed": seed,
        "name": data.get("LevelName") or "",
        "last": data.get("LastPlayed") or 0,
        "version": ver_name,
        "gametype": data.get("GameType"),
    }


def _dir_mtime(p):
    try:
        return max(int(os.path.getmtime(os.path.join(p, n)))
                   for n in os.listdir(p)
                   if n.lower().endswith(".dat") or n.lower().endswith(".mca"))
    except Exception:
        try:
            return int(os.path.getmtime(p))
        except OSError:
            return 0


def list_saves(game_dir):
    """列出 game_dir/saves 下所有存档，按最近玩过排序。"""
    out = []
    if not game_dir:
        return out
    sd = os.path.join(game_dir, "saves")
    if not os.path.isdir(sd):
        return out
    for name in os.listdir(sd):
        d = os.path.join(sd, name)
        if not os.path.isdir(d):
            continue
        lv = os.path.join(d, "level.dat")
        if not os.path.isfile(lv):
            continue
        item = {"dir": d, "folder": name, "seed": None, "label": name,
                "version": "", "mtime": _dir_mtime(d), "ok": False}
        try:
            info = read_level_dat(lv)
            item["seed"] = info.get("seed")
            item["label"] = info.get("name") or name
            item["version"] = info.get("version") or ""
            if info.get("last"):
                item["mtime"] = int(info["last"]) // 1000
            item["ok"] = isinstance(item["seed"], int)
        except Exception:
            pass
        if not item["mtime"]:
            item["mtime"] = int(time.time())
        out.append(item)
    out.sort(key=lambda x: x.get("mtime") or 0, reverse=True)
    return out
