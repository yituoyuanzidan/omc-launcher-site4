# -*- coding: utf-8 -*-
"""版本克隆：把一个已装版本复制成一个新实例（可选择性复制存档等）。"""
import json
import os
import shutil


def _safe(name):
    bad = '<>:"/\\|?*'
    out = "".join("_" if c in bad else c for c in (name or "").strip())
    return out.strip(". ") or "新版本"


def default_new_name(old, versions_dir):
    base = "%s-副本" % (old or "版本")
    cand, i = base, 2
    while os.path.isdir(os.path.join(versions_dir, cand)):
        cand = "%s%d" % (base, i)
        i += 1
    return cand


def clone(versions_dir, old_name, new_name=None, with_saves=False,
          with_mods=True, with_config=True, progress=None):
    """复制版本目录。返回 (ok, 说明, 新版本名)。

    with_saves 需要老版本目录里的 saves/，一般版本目录不含存档（存档在全局
    saves 里），所以这里只处理目录自带的情况。
    """
    def say(msg):
        if progress:
            try:
                progress(msg)
            except Exception:
                pass

    src = os.path.join(versions_dir, old_name)
    if not os.path.isdir(src):
        return False, "找不到这个版本的目录", ""
    new_name = new_name or default_new_name(old_name, versions_dir)
    dst = os.path.join(versions_dir, new_name)
    if os.path.exists(dst):
        return False, "已经有叫「%s」的版本了" % new_name, ""
    if not os.path.basename(dst).strip():
        return False, "名字不合法", ""
    skip_dirs = set()
    if not with_mods:
        skip_dirs.add("mods")
    if not with_config:
        skip_dirs.update({"config", "defaultconfigs", "kubejs", "scripts"})
    if not with_saves:
        skip_dirs.add("saves")
    try:
        os.makedirs(dst, exist_ok=True)
        for name in os.listdir(src):
            s = os.path.join(src, name)
            d = os.path.join(dst, name)
            if os.path.isdir(s):
                if name in skip_dirs or name.lower() in ("logs", "cache", "crash-reports"):
                    continue
                say("复制 %s…" % name)
                shutil.copytree(s, d, symlinks=False, ignore=shutil.ignore_patterns(
                    "*.log", "crash-*.txt", "logs", "cache"))
            else:
                if name.endswith(".log"):
                    continue
                shutil.copy2(s, d)
        # 改 json 里的 id / name
        jp = os.path.join(dst, os.path.basename(dst) + ".json")
        alt = os.path.join(dst, old_name + ".json")
        target = jp if os.path.isfile(jp) else (alt if os.path.isfile(alt) else "")
        if target:
            if target != jp:
                os.replace(target, jp)
            try:
                with open(jp, encoding="utf-8") as f:
                    data = json.load(f)
                data["id"] = os.path.basename(dst)
                with open(jp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
    except Exception as e:
        shutil.rmtree(dst, ignore_errors=True)
        return False, "复制失败：%s" % e, ""
    return True, "已复制成「%s」" % new_name, new_name
