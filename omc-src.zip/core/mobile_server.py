# -*- coding: utf-8 -*-
"""手机控制台：同一个 Wi-Fi 下用手机浏览器操作电脑上的启动器。

不开公网、不加账号，仅在局域网提供：查看状态、启动游戏、重扫联机房间。
"""
import json
import os
import socket
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


PAGE = """<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#14161c">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="OMC">
<title>OMC 手机控制台</title>
<style>
:root{--ac:#4C8DFF}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;padding:18px 14px 34px;background:radial-gradient(120% 80% at 50% 0,#232838,#12141a 72%);color:#e8ecf6;font:15px/1.55 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
h1{font-size:19px;margin:0 0 4px;font-weight:650}
.sub{color:#8b93a7;font-size:12px;margin-bottom:16px}
.card{background:rgba(39,43,51,.88);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:14px 15px;margin-bottom:12px}
.k{color:#8b93a7;font-size:12px}
.v{font-size:15px;margin-top:2px;word-break:break-all}
.btn{width:100%;padding:16px;border:0;border-radius:14px;font-size:16px;font-weight:600;color:#fff;background:var(--ac);margin-top:8px;display:block}
.btn:active{opacity:.82}
.btn.ghost{background:rgba(255,255,255,.09);color:#cfd6e6;font-weight:500;padding:13px}
.log{font:12px/1.5 ui-monospace,Consolas,monospace;color:#a9b2c6;white-space:pre-wrap;max-height:240px;overflow:auto}
.room{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.room:last-child{border-bottom:0}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#3ddc84;margin-right:7px}
.tip{color:#6f7789;font-size:11px;margin-top:10px;text-align:center}
</style>
</head>
<body>
<h1>OMC 手机控制台</h1>
<div class="sub">同一 Wi-Fi 下控制电脑上的启动器</div>

<div class="card">
  <div class="k">当前版本</div><div class="v" id="ver">-</div>
  <div class="k" style="margin-top:10px">账号</div><div class="v" id="acc">-</div>
</div>

<div class="card">
  <div class="k">局域网房间</div>
  <div id="rooms" class="v">检测中...</div>
</div>

<button class="btn" onclick="act('launch')">启动游戏</button>
<button class="btn ghost" id="installBtn" onclick="addToHome()">添加到手机桌面</button>
<button class="btn ghost" onclick="act('rescan')">重新检测联机房间</button>

<div class="card" style="margin-top:12px">
  <div class="k">运行日志</div>
  <div class="log" id="log">-</div>
</div>

<div class="tip">手机与电脑需连同一个 Wi-Fi，电脑上的启动器要保持打开</div>

<script>
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', function(e){
  e.preventDefault();
  deferredPrompt = e;
});
async function addToHome(){
  if (deferredPrompt){
    deferredPrompt.prompt();
    deferredPrompt = null;
    return;
  }
  const ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
  alert(ios
    ? '点右上角「分享」，选「添加到主屏幕」即可'
    : '点浏览器右上角菜单，选「添加到主屏幕 / 安装应用」即可');
}
async function act(a){
  try{
    await fetch('/api/'+a,{method:'POST'});
    refresh();
  }catch(e){}
}
async function refresh(){
  try{
    const s = await (await fetch('/api/state')).json();
    document.getElementById('ver').textContent = s.version || '-';
    document.getElementById('acc').textContent = s.account || '-';
    const rs = document.getElementById('rooms');
    if (s.rooms && s.rooms.length){
      rs.innerHTML = s.rooms.map(function(r){
        return '<div class="room"><span class="dot"></span>' + r + '</div>';
      }).join('');
    } else {
      rs.textContent = '没检测到房间，先在游戏里对局域网开放';
    }
    document.getElementById('log').textContent = (s.log || []).join('\\n') || '-';
  }catch(e){}
}
refresh();
setInterval(refresh, 3000);
</script>
</body>
</html>
"""


MANIFEST = json.dumps({
    "name": "OMC 手机控制台",
    "short_name": "OMC",
    "start_url": "/",
    "scope": "/",
    "display": "standalone",
    "background_color": "#12141a",
    "theme_color": "#14161c",
    "icons": [
        {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png",
         "purpose": "any maskable"},
        {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png",
         "purpose": "any maskable"},
    ],
}, ensure_ascii=False)

_ICON_CACHE = {}


def _asset_png():
    """启动器自带图标：源码运行取工程 assets，打包后取 PyInstaller 解包目录。"""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for name in ("sword_preview.png", "diamond_sword.png"):
        path = os.path.join(base, "assets", name)
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return path
    return ""


def _icon_png(size):
    """生成指定尺寸的正方形 PNG；Pillow 不可用时退回原图。"""
    if size in _ICON_CACHE:
        return _ICON_CACHE[size]
    src = _asset_png()
    if not src:
        return None
    data = None
    try:
        import io
        from PIL import Image
        img = Image.open(src).convert("RGBA")
        side = max(img.size)
        canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        canvas.paste(img, ((side - img.size[0]) // 2, (side - img.size[1]) // 2))
        img = canvas.resize((size, size), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data = buf.getvalue()
    except Exception:
        try:
            with open(src, "rb") as f:
                data = f.read()
        except Exception:
            return None
    if data:
        _ICON_CACHE[size] = data
    return data


def lan_ip():
    """取本机在局域网里的地址，取不到就回 127.0.0.1。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        return ip
    except OSError:
        return "127.0.0.1"


class _Handler(BaseHTTPRequestHandler):
    server_version = "OMC"

    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif self.path == "/manifest.json":
            self._send(200, MANIFEST, "application/manifest+json; charset=utf-8")
        elif self.path in ("/icon-192.png", "/icon-512.png"):
            size = 192 if "192" in self.path else 512
            icon = _icon_png(size)
            if icon:
                data = icon
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "max-age=86400")
                self.end_headers()
                try:
                    self.wfile.write(data)
                except OSError:
                    pass
            else:
                self._send(404, json.dumps({"error": "no icon"}))
        elif self.path.startswith("/api/state"):
            state = dict(self.server.bridge.state or {})
            self._send(200, json.dumps(state, ensure_ascii=False))
        else:
            self._send(404, json.dumps({"error": "not found"}))

    def do_POST(self):
        if self.path.startswith("/api/launch"):
            self.server.bridge.launchRequested.emit()
            self._send(200, json.dumps({"ok": True}))
        elif self.path.startswith("/api/rescan"):
            self.server.bridge.rescanRequested.emit()
            self._send(200, json.dumps({"ok": True}))
        else:
            self._send(404, json.dumps({"error": "not found"}))


class MobileServer(object):
    """把启动器包成一个局域网网页，手机浏览器直接打开。"""

    def __init__(self, bridge, port=8899):
        self.bridge = bridge
        self.port = port
        self.httpd = None
        self.thread = None
        self.url = ""

    def start(self):
        for p in range(self.port, self.port + 8):
            try:
                httpd = ThreadingHTTPServer(("0.0.0.0", p), _Handler)
            except OSError:
                continue
            httpd.bridge = self.bridge
            httpd.daemon_threads = True
            self.httpd = httpd
            self.thread = threading.Thread(
                target=httpd.serve_forever, daemon=True)
            self.thread.start()
            self.url = "http://%s:%d/" % (lan_ip(), p)
            return self.url
        return ""

    def stop(self):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None
