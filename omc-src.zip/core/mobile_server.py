# -*- coding: utf-8 -*-
"""手机控制台：同一个 Wi-Fi 下用手机浏览器操作电脑上的启动器。

不开公网、不加账号，仅在局域网提供：
- 看状态（版本 / 账号 / 内存 / Java / 房间 / 是否在运行）
- 操作（启动、切版本、重扫房间、打开截图、改内存）
- 看截图相册、看日志诊断

电脑端会给一个地址 + 二维码，手机扫一下直接进来，不用手打 IP。
"""
import json
import os
import queue
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

PAGE = r"""<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#14161c">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="OMC">
<title>OMC 手机控制台</title>
<style>
:root{--ac:#4C8DFF;--card:rgba(39,43,51,.9);--line:rgba(255,255,255,.09)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;padding:16px 13px 30px;background:radial-gradient(120% 70% at 50% 0,#232838,#12141a 70%);color:#e8ecf6;font:15px/1.55 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
h1{font-size:19px;margin:0;font-weight:650;display:flex;align-items:center;gap:8px}
.pill{font-size:11px;padding:2px 9px;border-radius:20px;background:rgba(78,141,255,.16);color:#9dc0ff;font-weight:500}
.pill.on{background:rgba(61,220,132,.16);color:#7ee2a8}
.sub{color:#8b93a7;font-size:12px;margin:4px 0 14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:15px;padding:13px 14px;margin-bottom:11px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 12px}
.k{color:#8b93a7;font-size:12px}
.v{font-size:15px;margin-top:2px;word-break:break-all}
.btn{width:100%;padding:15px;border:0;border-radius:14px;font-size:16px;font-weight:600;color:#fff;background:var(--ac);display:block}
.btn:active{opacity:.84}
.btn.ghost{background:rgba(255,255,255,.09);color:#cfd6e6;font-weight:500;padding:13px;font-size:14px}
.btn:disabled{opacity:.45}
.row{display:flex;gap:9px}
.row>*{flex:1}
h2{font-size:13px;color:#8b93a7;font-weight:600;margin:0 0 9px}
.ver{display:flex;align-items:center;justify-content:space-between;padding:9px 2px;border-bottom:1px solid var(--line);font-size:14px}
.ver:last-child{border-bottom:0}
.ver .tag{font-size:11px;color:#8b93a7}
.ver.now .nm{color:#9dc0ff;font-weight:600}
.acts{display:flex;gap:8px;margin-left:auto}
.mini{border:1px solid var(--line);background:rgba(255,255,255,.06);color:#cfd6e6;border-radius:9px;padding:6px 11px;font-size:12px}
.shots{display:flex;gap:9px;overflow-x:auto;padding-bottom:4px}
.shots img{height:96px;border-radius:10px;border:1px solid var(--line);flex:0 0 auto}
.empty{color:#6f7789;font-size:12px}
.log{font:12px/1.55 ui-monospace,Consolas,monospace;color:#a9b2c6;white-space:pre-wrap;max-height:230px;overflow:auto;word-break:break-all}
.diag{margin-top:9px;padding-top:9px;border-top:1px solid var(--line)}
.diag .t{font-size:13px;font-weight:600}
.diag .a{font-size:12px;color:#9aa3b8;margin-top:3px}
.err{color:#ff8a8a}
.ok{color:#7ede9a}
.warn{color:#ffcf7a}
.tip{color:#6f7789;font-size:11px;margin-top:14px;text-align:center;line-height:1.6}
#toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(20px);background:rgba(20,22,28,.96);border:1px solid var(--line);color:#e8ecf6;font-size:13px;padding:10px 18px;border-radius:11px;opacity:0;transition:.22s;pointer-events:none}
#toast.on{opacity:1;transform:translateX(-50%) translateY(0)}
#big{position:fixed;inset:0;background:rgba(8,9,12,.95);display:none;align-items:center;justify-content:center;z-index:9}
#big img{max-width:100%;max-height:100%}
</style>
</head>
<body>
<h1>OMC 控制台 <span class="pill" id="live">连接中</span></h1>
<div class="sub" id="pcname">正在读取电脑状态…</div>
<div class="sub" id="alt" style="font-size:11px;opacity:.6;margin-top:2px"></div>

<div class="card">
  <div class="grid">
    <div><div class="k">当前版本</div><div class="v" id="ver">-</div></div>
    <div><div class="k">账号</div><div class="v" id="acc">-</div></div>
    <div><div class="k">内存</div><div class="v" id="mem">-</div></div>
    <div><div class="k">Java</div><div class="v" id="java">-</div></div>
  </div>
</div>

<button class="btn" id="btnLaunch" onclick="launchNow()">启动游戏</button>
<div class="row" style="margin-top:9px">
  <button class="btn ghost" onclick="act('rescan')">重扫房间</button>
  <button class="btn ghost" onclick="act('album')">截图相册</button>
</div>

<div class="card" style="margin-top:12px">
  <h2>切换版本</h2>
  <div id="versions"><div class="empty">读取中…</div></div>
</div>

<div class="card">
  <h2>局域网房间</h2>
  <div id="rooms"><div class="empty">检测中…</div></div>
</div>

<div class="card" id="playCard">
  <h2>手机上真的玩起来</h2>
  <div id="streamBox"><div class="empty">检测中…</div></div>
  <div id="streamBtns" style="margin-top:9px"></div>
</div>

<div class="card" id="screenCard">
  <h2>电脑画面</h2>
  <div id="screenWrap"><div class="empty">点下面按钮，看电脑现在的屏幕</div></div>
  <button class="btn ghost" style="margin-top:8px" id="screenBtn" onclick="toggleScreen()">看电脑画面</button>
</div>

<div class="card" id="shotCard">
  <h2>最近截图</h2>
  <div class="shots" id="shots"><div class="empty">还没有截图</div></div>
</div>

<div class="card">
  <h2>运行日志</h2>
  <div class="log" id="log">-</div>
  <div id="diag"></div>
</div>

<button class="btn ghost" style="margin-top:4px" id="installBtn" onclick="addToHome()">添加到手机桌面</button>
<div class="tip">手机跑不动 Java 版，所以这里的「启动游戏」启动的是电脑上的游戏，画面在电脑屏幕上。<br>
想在手机里真的玩，走上方的串流（电脑 Sunshine + 手机 Moonlight），连上后手机就是电脑的屏幕和手柄。<br>
「电脑画面」卡片是不装串流时的应急看屏，每 3 秒一张。<br>
手机与电脑需连同一个 Wi-Fi，电脑上的启动器保持打开；关掉网页会自动暂停刷新，省电</div>

<div id="big" onclick="this.style.display='none'"><img id="bigimg" alt=""></div>
<div id="toast"></div>

<script>
let deferredPrompt = null, lastState = null, timer = null, lastNotice = '';
window.addEventListener('beforeinstallprompt', function(e){ e.preventDefault(); deferredPrompt = e; });
function toast(t){
  const el = document.getElementById('toast');
  el.textContent = t; el.classList.add('on');
  clearTimeout(el._t); el._t = setTimeout(function(){ el.classList.remove('on'); }, 1600);
}
async function addToHome(){
  if (deferredPrompt){ deferredPrompt.prompt(); deferredPrompt = null; return; }
  const ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
  alert(ios ? '点右上角「分享」，选「添加到主屏幕」即可'
            : '点浏览器右上角菜单，选「添加到主屏幕 / 安装应用」即可');
}
async function act(name, arg){
  try{
    const r = await fetch('/api/act', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name:name, arg:arg||''})});
    const d = await r.json();
    toast(d.msg || (d.ok ? '已执行' : (d.error || '没成功')));
    if (d.reload !== false) setTimeout(refresh, 300);
    if (name === 'album' && d.msg) location.hash = 'shots';
  }catch(e){ toast('连不上电脑'); }
}
function shortVer(id){ return (id||'').length > 26 ? id.slice(0,24) + '…' : (id||''); }
async function launchNow(){
  toast('已通知电脑启动，几秒后看「运行日志」');
  await act('launch');
}
async function refresh(){
  if (document.hidden) return;
  try{
    const s = await (await fetch('/api/state', {cache:'no-store'})).json();
    lastState = s;
    document.getElementById('live').textContent = '已连接';
    document.getElementById('live').classList.add('on');
    document.getElementById('pcname').textContent = s.pc || '同一 Wi-Fi 下控制电脑上的启动器';
    const alt = document.getElementById('alt');
    if (alt){
      alt.textContent = (s.urls && s.urls.length) ?
        ('打不开就试这些地址：' + s.urls.join('  ')) : '';
    }
    document.getElementById('ver').textContent = s.version || '-';
    document.getElementById('acc').textContent = s.account || '-';
    document.getElementById('mem').textContent = s.memory || '-';
    document.getElementById('java').textContent = s.java || '-';
    const b = document.getElementById('btnLaunch');
    b.textContent = s.running ? '游戏运行中' : '启动游戏';
    b.disabled = !!s.running;
    if (s.notice && s.notice !== lastNotice){ lastNotice = s.notice; toast(s.notice); }

    const vs = document.getElementById('versions');
    const list = s.versions || [];
    vs.innerHTML = list.length ? list.map(function(v){
      const now = (v === s.version);
      return '<div class="ver ' + (now?'now':'') + '"><span class="nm">' + shortVer(v) + '</span>' +
        (now ? '<span class="tag">正在用</span>' :
          '<button class="mini" onclick="act(\'switch\', \'' + v.replace(/'/g, '') + '\')">切到这个</button>') +
        '</div>';
    }).join('') : '<div class="empty">还没有已装版本</div>';

    const rs = document.getElementById('rooms');
    const rooms = s.rooms || [];
    rs.innerHTML = rooms.length ? rooms.map(function(r){
      return '<div class="ver"><span class="nm">' + r + '</span></div>';
    }).join('') : '<div class="empty">没检测到房间，先在游戏里对局域网开放</div>';

    const shots = document.getElementById('shots');
    const sh = s.shots || [];
    if (sh.length){
      shots.innerHTML = sh.map(function(x){
        return '<img loading="lazy" src="/shot/' + encodeURIComponent(x.name) + '" alt="' + x.name +
          '" onclick="bigshot(\'' + encodeURIComponent(x.name) + '\')">';
      }).join('');
    } else { shots.innerHTML = '<div class="empty">还没有截图，游戏里按 F2 就能拍</div>'; }

    document.getElementById('log').textContent = (s.log || []).join('\n') || '-';
    renderStream(s.stream || {});
    const d = document.getElementById('diag');
    const diag = s.diag || [];
    d.innerHTML = diag.length ? '<div class="diag"><div class="t err">发现 ' + diag.length +
      ' 个问题</div>' + diag.map(function(it){
        return '<div class="t" style="margin-top:7px">' + it.title + '</div><div class="a">' + it.advice + '</div>';
      }).join('') + '</div>' : '';
  }catch(e){
    document.getElementById('live').textContent = '已断开';
    document.getElementById('live').classList.remove('on');
  }
}
function renderStream(st){
  const box = document.getElementById('streamBox');
  const bar = document.getElementById('streamBtns');
  if (!box) return;
  let head, cls, acts;
  if (st.running){
    head = '串流服务正在运行'; cls = 'ok';
    acts = (st.web ? '<a class="btn" href="' + st.web + '" target="_blank" rel="noopener">打开串流设置页</a>' : '') +
           '<div class="tip" style="margin:8px 0 0">手机上装 Moonlight，打开后搜这台电脑就能连上，连上就是电脑上的游戏画面，手机当手柄用。</div>';
  } else if (st.installed){
    head = '电脑上装了串流服务，但没启动'; cls = 'warn';
    acts = '<button class="btn ghost" onclick="act(\'streamstart\')">让电脑启动它</button>' +
           '<div class="tip" style="margin:8px 0 0">启动后手机用 Moonlight 连；第一次连要在电脑串流设置页确认配对码。</div>';
  } else {
    head = '电脑上还没装串流服务'; cls = 'warn';
    acts = '<button class="btn ghost" onclick="openGuide()">看怎么弄</button>';
  }
  box.innerHTML = '<div class="diag"><div class="t ' + cls + '">' + head + '</div>' +
    '<div class="a">' + (st.msg || '') + '</div></div>';
  bar.innerHTML = acts;
}
function openGuide(){
  alert('手机玩 Java 版《我的世界》只能靠串流：\n\n' +
        '1. 电脑装 Sunshine（免费开源，在 GitHub 上搜 LizardByte/Sunshine 下载 Windows 版）\n' +
        '2. 手机装 Moonlight（应用商店里就有）\n' +
        '3. 两个设备连同一个 Wi-Fi，Moonlight 里会自动搜到这台电脑\n' +
        '4. 第一次连接要输入电脑上显示的配对码\n\n' +
        '启动器这边能做的：帮你启动 Sunshine、让你确认它在跑、随时看电脑画面。');
}
function bigshot(name){  document.getElementById('bigimg').src = '/shot/' + name;
  document.getElementById('big').style.display = 'flex';
}
let screenTimer = null;
function toggleScreen(){
  const wrap = document.getElementById('screenWrap');
  const btn = document.getElementById('screenBtn');
  if (screenTimer){
    clearInterval(screenTimer); screenTimer = null;
    btn.textContent = '看电脑画面';
    return;
  }
  btn.textContent = '停止看画面';
  const tick = function(){
    const src = '/api/screen?t=' + Date.now();
    let img = document.getElementById('screenImg');
    if (!img){
      wrap.innerHTML = '<img id="screenImg" style="width:100%;border-radius:10px;display:block">';
      img = document.getElementById('screenImg');
      img.onerror = function(){ wrap.innerHTML = '<div class="empty">还取不到画面：确认启动器没关、手机和电脑是同一个 Wi-Fi</div>'; };
    }
    img.src = src;
  };
  tick();
  screenTimer = setInterval(tick, 3000);
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) refresh(); });
refresh();
timer = setInterval(refresh, 2500);
</script>
</body>
</html>
"""


MANIFEST = json.dumps({
    "name": "OMC 手机控制台",
    "short_name": "OMC",
    "start_url": "/",
    "scope": "/",
    "display": "standalone",
    "background_color": "#12141a",
    "theme_color": "#14161c",
    "icons": [
        {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png",
         "purpose": "any maskable"},
        {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png",
         "purpose": "any maskable"},
    ],
}, ensure_ascii=False)

_ICON_CACHE = {}
_IMG_TYPES = {".png": "image/png", ".jpg": "image/jpeg",
              ".jpeg": "image/jpeg", ".webp": "image/webp",
              ".bmp": "image/bmp"}

# 手机端点下来的指令先塞进这个线程安全队列，主线程定时取走执行。
# 不再跨线程 emit 信号：实测那种写法在真机上收不到，手机点启动电脑毫无反应。
_ACTIONS = queue.Queue(maxsize=64)


def take_actions(limit=8):
    """主线程调用：取出待执行的手机指令列表 [(name, arg), ...]。"""
    out = []
    while len(out) < limit:
        try:
            out.append(_ACTIONS.get_nowait())
        except queue.Empty:
            break
    return out


def push_action(name, arg=""):
    """HTTP 线程调用：只入队。"""
    try:
        _ACTIONS.put_nowait((str(name), str(arg or "")))
    except queue.Full:
        pass


def _asset_png():
    """启动器自带图标：源码运行取工程 assets，打包后取 PyInstaller 解包目录。"""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for name in ("sword_preview.png", "diamond_sword.png"):
        path = os.path.join(base, "assets", name)
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return path
    return ""


def _icon_png(size):
    """生成指定尺寸的正方形 PNG；Pillow 不可用时退回原图。"""
    if size in _ICON_CACHE:
        return _ICON_CACHE[size]
    src = _asset_png()
    if not src:
        return None
    data = None
    try:
        import io
        from PIL import Image
        img = Image.open(src).convert("RGBA")
        side = max(img.size)
        canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        canvas.paste(img, ((side - img.size[0]) // 2, (side - img.size[1]) // 2))
        img = canvas.resize((size, size), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data = buf.getvalue()
    except Exception:
        try:
            with open(src, "rb") as f:
                data = f.read()
        except Exception:
            return None
    if data:
        _ICON_CACHE[size] = data
    return data


def _ip_score(ip):
    """给本机地址打分：越像「家里路由器分的地址」分越高。

    Docker / WSL / 虚拟网卡（172.17-31.*、169.254.*）常常排在前面，
    但它们手机根本连不进来，所以按网段排优先级而不是按枚举顺序。
    """
    if ip.startswith("127."):
        return 0
    if ip.startswith("169.254."):
        return 1
    parts = ip.split(".")
    if len(parts) != 4:
        return 10
    try:
        a, b = int(parts[0]), int(parts[1])
    except ValueError:
        return 10
    if a == 192 and b == 168:
        return 120          # 家用 Wi-Fi 最常见的网段
    if a == 10:
        return 110
    if a == 172 and 16 <= b <= 31:
        return 25           # Docker / WSL 默认段，优先级压到很低
    if a == 100 and 64 <= b <= 127:
        return 40           # 运营商 CGNAT / 校园网
    return 60


def lan_ips():
    """本机所有可用 IPv4，按「手机能不能连」的可能性排序。"""
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None,
                                       socket.AF_INET):
            ip = info[4][0]
            if ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    # 多网卡 / 虚拟网卡时 getaddrinfo 可能漏，用一次 UDP 探测补一个
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip not in ips:
                ips.append(ip)
        finally:
            s.close()
    except OSError:
        pass
    ips.sort(key=_ip_score, reverse=True)
    return ips


def lan_ip():
    """取本机在局域网里的地址，取不到就回 127.0.0.1。"""
    ips = lan_ips()
    return ips[0] if ips else "127.0.0.1"


def _bridge_state(bridge):
    """拿到桥接的最新状态：优先 snapshot()，退回静态 state。"""
    snap = getattr(bridge, "snapshot", None)
    if callable(snap):
        try:
            return snap() or {}
        except Exception:
            return {}
    return dict(getattr(bridge, "state", None) or {})


class _Handler(BaseHTTPRequestHandler):
    server_version = "OMC"

    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8")
        self._raw(code, data, ctype)

    def _raw(self, code, data, ctype, cache="no-store"):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", cache)
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    # ---------- GET ----------
    def do_GET(self):
        path = urlsplit(self.path).path
        bridge = self.server.bridge
        if path in ("/", "/index.html"):
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif path == "/manifest.json":
            self._send(200, MANIFEST, "application/manifest+json; charset=utf-8")
        elif path.startswith("/icon-"):
            size = 192 if "192" in path else 512
            icon = _icon_png(size)
            if icon:
                self._raw(200, icon, "image/png", cache="max-age=86400")
            else:
                self._json({"error": "no icon"}, 404)
        elif path == "/favicon.ico":
            icon = _icon_png(64)
            if icon:
                self._raw(200, icon, "image/png", cache="max-age=86400")
            else:
                self._json({"error": "no icon"}, 404)
        elif path == "/api/state":
            st = _bridge_state(bridge)
            # 顺手告诉手机端「当前地址」和「备选地址」，主网卡选错时能自己换
            try:
                port = self.server.server_address[1]
            except Exception:
                port = 8899
            try:
                ips = lan_ips()
                st["url"] = "http://%s:%d/" % (ips[0] if ips else "127.0.0.1",
                                               port)
                st["urls"] = ["http://%s:%d/" % (ip, port)
                              for ip in ips[1:4]]
            except Exception:
                st["url"] = ""
                st["urls"] = []
            self._json(st)
        elif path == "/api/screen":
            # 手机端想看一眼电脑现在什么样：让主线程下一拍去截屏
            try:
                bridge.screen_want = time.time()
            except Exception:
                pass
            png = getattr(bridge, "screen_png", b"") or b""
            if png:
                self._raw(200, png, "image/png", cache="no-store")
            else:
                self._json({"error": "screen not ready"}, 404)
        elif path.startswith("/shot/"):
            self._serve_shot(bridge, path[len("/shot/"):])
        else:
            self._json({"error": "not found"}, 404)

    def _serve_shot(self, bridge, name):
        """只允许 screenshots 目录里的文件名，防目录穿越。"""
        from urllib.parse import unquote
        name = unquote(name)
        safe = os.path.basename(name)
        if not safe or safe != name:
            self._json({"error": "bad name"}, 400)
            return
        game_dir = getattr(bridge, "game_dir", "") or ""
        if not game_dir:
            self._json({"error": "no game dir"}, 404)
            return
        p = os.path.join(game_dir, "screenshots", safe)
        if not os.path.isfile(p):
            self._json({"error": "not found"}, 404)
            return
        ext = os.path.splitext(safe)[1].lower()
        ctype = _IMG_TYPES.get(ext, "application/octet-stream")
        try:
            with open(p, "rb") as f:
                data = f.read()
        except OSError:
            self._json({"error": "read error"}, 500)
            return
        self._raw(200, data, ctype, cache="max-age=60")

    # ---------- POST ----------
    def do_POST(self):
        path = urlsplit(self.path).path
        if path == "/api/launch":
            push_action("launch")
            self._json({"ok": True, "msg": "已发送到电脑"})
            return
        if path == "/api/rescan":
            push_action("rescan")
            self._json({"ok": True, "msg": "已发送到电脑"})
            return
        if path == "/api/act":
            try:
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(min(n, 4096)).decode("utf-8", "replace")
                payload = json.loads(raw or "{}")
            except Exception:
                self._json({"ok": False, "error": "格式不对"}, 400)
                return
            name = str(payload.get("name") or "")
            arg = payload.get("arg") or ""
            push_action(name, arg)
            self._json({"ok": True, "msg": "已发送到电脑"})
            return
        self._json({"error": "not found"}, 404)


class MobileServer(object):
    """把启动器包成一个局域网网页，手机浏览器直接打开。"""

    def __init__(self, bridge, port=8899):
        self.bridge = bridge
        self.port = port
        self.httpd = None
        self.thread = None
        self.url = ""
        self.started_at = 0.0

    def start(self):
        for p in range(self.port, self.port + 8):
            try:
                httpd = ThreadingHTTPServer(("0.0.0.0", p), _Handler)
            except OSError:
                continue
            httpd.bridge = self.bridge
            httpd.daemon_threads = True
            self.httpd = httpd
            self.thread = threading.Thread(
                target=httpd.serve_forever, daemon=True)
            self.thread.start()
            self.started_at = time.time()
            self.url = "http://%s:%d/" % (lan_ip(), p)
            return self.url
        return ""

    def stop(self):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None

    def alive(self):
        return self.httpd is not None
