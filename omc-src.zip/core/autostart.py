# -*- coding: utf-8 -*-
"""开机自动启动：Windows 写 HKCU 的 Run 项（不需要管理员），
Linux 写 ~/.config/autostart 下的 desktop 文件，macOS 暂不支持（会如实说明）。"""
import os
import sys

from core import platform_utils

REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
REG_NAME = "OMC Launcher"
APP_NAME = "OMC启动器"


def launch_command():
    """返回 (可执行文件, 附加参数)：打包后就是自己，源码运行走 pythonw + main.py。"""
    if getattr(sys, "frozen", False):
        return os.path.abspath(sys.executable), ""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    exe = sys.executable
    pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.path.exists(pyw):
        exe = pyw
    return exe, os.path.join(root, "main.py")


def _win_cmd():
    exe, arg = launch_command()
    if arg:
        return '"%s" "%s"' % (exe, arg)
    return '"%s"' % exe


def _desktop_file():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(
        os.path.expanduser("~"), ".config")
    return os.path.join(base, "autostart", "omc-launcher.desktop")


def supported():
    return platform_utils.WINDOWS or platform_utils.LINUX


def state():
    """{'supported', 'enabled', 'target'}"""
    info = {"supported": supported(), "enabled": False, "target": _win_cmd()}
    if platform_utils.WINDOWS:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0,
                                winreg.KEY_READ) as key:
                val, _t = winreg.QueryValueEx(key, REG_NAME)
            info["enabled"] = bool(val)
            if val:
                info["target"] = val
        except OSError:
            pass
    elif platform_utils.LINUX:
        info["enabled"] = os.path.exists(_desktop_file())
    return info


def enable():
    """返回 (成功, 说明)。"""
    if not supported():
        return False, "macOS 不支持从启动器里设开机自启，请到「系统设置 · 登录项」手动添加。"
    exe, arg = launch_command()
    if platform_utils.WINDOWS:
        try:
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH) as key:
                winreg.SetValueEx(key, REG_NAME, 0, winreg.REG_SZ, _win_cmd())
            return True, "已加入开机启动：" + _win_cmd()
        except OSError as e:
            return False, "写注册表失败：%s" % e
    path = _desktop_file()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if arg:
            cmd = '"%s" "%s"' % (exe, arg)
        else:
            cmd = '"%s"' % exe
        body = ("[Desktop Entry]\n"
                "Type=Application\n"
                "Name=%s\n"
                "Exec=%s\n"
                "Terminal=false\n"
                "X-GNOME-Autostart-enabled=true\n" % (APP_NAME, cmd))
        with open(path, "w", encoding="utf-8") as f:
            f.write(body)
        return True, "已写入启动项：" + path
    except OSError as e:
        return False, "写启动项失败：%s" % e


def disable():
    if not supported():
        return False, "macOS 不支持从启动器里改开机自启。"
    if platform_utils.WINDOWS:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0,
                                winreg.KEY_ALL_ACCESS) as key:
                winreg.DeleteValue(key, REG_NAME)
            return True, "已取消开机启动"
        except OSError:
            return True, "本来就没设开机启动"
    path = _desktop_file()
    try:
        if os.path.exists(path):
            os.remove(path)
        return True, "已取消开机启动"
    except OSError as e:
        return False, "删除启动项失败：%s" % e
