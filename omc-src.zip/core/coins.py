# -*- coding: utf-8 -*-
"""娱乐币：纯虚拟积分，按账号分开存。

口径（照用户说的来）：
  * **每个账号一份**，同一个启动器里切了账号，金币不串；
  * 只和娱乐页里的棋牌有关，**不能充值、不能兑换、不能提现**，
    所以属性就写死成"虚拟积分"，别的地方也别拿它当钱用；
  * 真人对局输了，输家扣多少，赢家就加多少（一进一出，总额不变）。

存 ~/.simple_mc_launcher/coins.json，流水另存 coins_log.jsonl（最近 200 条）。
"""
import json
import os
import time

START_COINS = 500          # 新账号的初始积分，也是「重置」回到的数
LOSS_RATE = 0.10           # 真人对局输了，按自己当前积分的 10% 扣给对方
MIN_LOSS = 1               # 再少也扣 1 分，别出现 0
_LOG_MAX = 200


def _dir():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def _path():
    return os.path.join(_dir(), "coins.json")


def _log_path():
    return os.path.join(_dir(), "coins_log.jsonl")


def _blank_user():
    return {"coins": START_COINS, "wins": 0, "losses": 0, "draws": 0,
            "played": 0}


def load():
    try:
        with open(_path(), encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            return {"accounts": {}}
    except Exception:
        return {"accounts": {}}
    if not isinstance(d.get("accounts"), dict):
        d["accounts"] = {}
    return d


def save(d):
    p = _path()
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass


def _acct(d, user):
    name = (user or "").strip()
    if not name:
        return None
    row = d["accounts"].get(name)
    if not isinstance(row, dict):
        row = _blank_user()
        d["accounts"][name] = row
    for k, v in _blank_user().items():
        row.setdefault(k, v)
    return row


def account(user):
    """某个账号的积分明细（没有就按初始值建一份）。"""
    d = load()
    row = _acct(d, user)
    if row is None:
        return dict(_blank_user())
    save(d)
    return dict(row)


def balance(user):
    return int(account(user).get("coins", 0))


def loss_amount(user):
    """这个账号这一局输了要扣多少：自己当前积分的 10%（至少 1 分）。"""
    b = balance(user)
    if b <= 0:
        return 0
    return max(MIN_LOSS, int(round(b * LOSS_RATE)))


def can_play(user):
    """还有积分就能玩（0 分就不能再开局了，得点重置）。"""
    if not (user or "").strip():
        return False, "先登录账号"
    if balance(user) <= 0:
        return False, "积分用完了，点右上角「重置积分」回到 %d" % START_COINS
    return True, ""


def add(user, n, reason="", opponent="", game=""):
    """加/减积分（n 可以为负）。返回变动后的余额。"""
    d = load()
    row = _acct(d, user)
    if row is None:
        return 0
    row["coins"] = max(0, int(row.get("coins", 0)) + int(n))
    save(d)
    _log(user, int(n), reason, opponent, game, row["coins"])
    return row["coins"]


def settle(winner, loser, amt, game=""):
    """真人对局结算：输家扣 amt，赢家加 amt（一进一出，总额不变）。

    amt 一般是输家自己余额的 10%（见 loss_amount）。
    两边都记战绩；平局走 settle_draw。
    """
    amt = max(0, int(amt or 0))
    d = load()
    w = _acct(d, winner)
    l = _acct(d, loser)
    out = {}
    if w is not None:
        w["coins"] = int(w.get("coins", 0)) + amt
        w["wins"] = int(w.get("wins", 0)) + 1
        w["played"] = int(w.get("played", 0)) + 1
        out["winner_coins"] = w["coins"]
    if l is not None and l is not w:
        # 扣到 0 为止，不出现负积分
        l["coins"] = max(0, int(l.get("coins", 0)) - amt)
        l["losses"] = int(l.get("losses", 0)) + 1
        l["played"] = int(l.get("played", 0)) + 1
        out["loser_coins"] = l["coins"]
    save(d)
    if w is not None:
        _log(winner, amt, "赢了", loser, game, w["coins"])
    if l is not None and l is not w:
        _log(loser, -min(amt, int(l.get("coins", 0)) + amt), "输了",
             winner, game, l["coins"])
    return out


def settle_rate(winner, loser, game=""):
    """按「输家余额 10%」结算，返回实际扣的数额。"""
    amt = loss_amount(loser)
    settle(winner, loser, amt, game=game)
    return amt


def reset(user):
    """把这个账号的积分重置回 500（战绩也一起清）。"""
    if not (user or "").strip():
        return 0
    d = load()
    row = _acct(d, user)
    if row is None:
        return 0
    row["coins"] = START_COINS
    row["wins"] = 0
    row["losses"] = 0
    row["draws"] = 0
    row["played"] = 0
    save(d)
    _log(user, 0, "重置为 %d" % START_COINS, "", "", START_COINS)
    return START_COINS


def settle_draw(a, b, game=""):
    d = load()
    for u in (a, b):
        row = _acct(d, u)
        if row is not None:
            row["draws"] = int(row.get("draws", 0)) + 1
            row["played"] = int(row.get("played", 0)) + 1
    save(d)
    _log(a, 0, "平局", b, game, balance(a))


def _log(user, delta, reason, opponent, game, after):
    rec = {"ts": int(time.time()), "user": user, "delta": int(delta),
           "reason": reason, "opponent": opponent or "", "game": game or "",
           "after": int(after)}
    old = []
    try:
        with open(_log_path(), encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        old.append(json.loads(line))
                    except Exception:
                        pass
    except Exception:
        old = []          # 第一次还没有流水文件，这不是错误
    try:
        old = old[-_LOG_MAX:]
        old.append(rec)
        with open(_log_path(), "w", encoding="utf-8") as f:
            for r in old:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    except Exception:
        pass


def recent(user, limit=20):
    """这个账号最近的流水（结算界面拿来展示）。"""
    out = []
    try:
        with open(_log_path(), encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if (r.get("user") or "") == (user or ""):
                    out.append(r)
    except Exception:
        return []
    return out[-limit:][::-1]


def all_accounts():
    d = load()
    return d.get("accounts") or {}
