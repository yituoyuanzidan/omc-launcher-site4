# -*- coding: utf-8 -*-
"""版本检查：读远端清单，比对本地版本。

清单（update.json）内容：
{
  "latest": "1.6.0",
  "pc_url": "电脑版下载直链",
  "mobile_url": "手机版下载直链",
  "notes": "这一次改了什么"
}

清单地址可以在设置里改（update_url），方便把更新源换成自己的固定地址。
"""
import json
import os
import re
import sys
import urllib.request

VERSION = "1.7.37"
DEFAULT_SOURCE = "https://yituoyuanzidan.github.io/omc-launcher-site4/"
TIMEOUT = 8

# 固定页面里塞一份清单，页面链接不变、内容可以随时重发，
# 这样老版本也能一直读到最新版本号，不会卡在旧清单上。
# content 的引号可能是单引号也可能是双引号，里面的 JSON 又带一堆双引号，
# 所以用反向引用锁同一种引号收尾，不能写死。
META_RE = re.compile(
    r"<meta\s+name=[\"']omc-update[\"']\s+content=([\"'])(.*?)\1",
    re.S | re.I)


def _cfg_path():
    return os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")


def _exe_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_source():
    """更新源优先级：设置里填的 > 程序目录 update_source.txt > 内置默认源。

    打包好的目录里可以直接放一个 update_source.txt，改它就能换更新源，
    不用重新打包 exe。
    """
    try:
        with open(os.path.join(_cfg_path(), "config.json"), "r",
                  encoding="utf-8") as f:
            cfg = json.load(f)
        url = (cfg.get("update_url") or "").strip()
        if url:
            return url
    except Exception:
        pass
    try:
        with open(os.path.join(_exe_dir(), "update_source.txt"), "r",
                  encoding="utf-8") as f:
            url = f.read().strip()
        if url:
            return url
    except Exception:
        pass
    return DEFAULT_SOURCE


def _parse_version(text):
    nums = []
    for part in str(text or "").replace("v", "").split("."):
        digits = ""
        for ch in part:
            if ch.isdigit():
                digits += ch
            else:
                break
        nums.append(int(digits) if digits else 0)
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums[:4])


def is_newer(remote, local=None):
    return _parse_version(remote) > _parse_version(local or VERSION)


def _parse_manifest(text):
    """支持两种清单来源：纯 JSON，或下载站页面里的 <meta name="omc-update">。"""
    s = (text or "").strip()
    if s.startswith("{"):
        return json.loads(s)
    m = META_RE.search(text or "")
    if not m:
        raise ValueError("清单页面里没找到 omc-update")
    import html as _html
    return json.loads(_html.unescape(m.group(2)))


def check(url=None, timeout=TIMEOUT):
    """返回清单 dict（含 latest/pc_url/mobile_url/notes），失败抛异常。"""
    from . import http
    base = (url or _load_source()).strip()
    if not base.lower().startswith(("http://", "https://")):
        raise ValueError("更新地址不是 http(s) 链接：%s" % base)
    # GitHub Pages 这类站点，去掉结尾斜杠会被 301 掉头，拿回来的是跳转页，
    # 所以原样先试一次，再拿去掉斜杠的地址兜底。
    last = None
    for cand in (base, base.rstrip("/")):
        try:
            raw = http._read_url(cand, "official", timeout=max(6, timeout),
                                 retries=2)
            data = _parse_manifest(raw[: 512 * 1024].decode("utf-8", "replace"))
            if not isinstance(data, dict):
                raise ValueError("清单格式不正确")
            return data
        except Exception as e:
            last = e
    raise last if last else ValueError("清单格式不正确")
