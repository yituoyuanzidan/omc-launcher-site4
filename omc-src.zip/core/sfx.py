# -*- coding: utf-8 -*-
"""游戏音效：程序内合成 wav，首次用到时写进用户目录，之后直接读文件。

包里不带任何音频素材，所以不会因为漏打包某个 wav 就变哑；音色全用正弦/
方波/三角波加指数衰减凑出来，几 KB 一个文件，加载几乎没成本。

播放优先 QSoundEffect（低延迟、能叠加）；拿不到就退回 QMediaPlayer，
再退回 Windows 自带的 winsound。全部失败就静默，绝不影响对局。
"""
import math
import os
import random
import struct
import wave

from core import platform_utils

_RATE = 22050

#: 每种音效：(总时长秒, [(起始秒, 时长秒, 频率Hz, 音量, 波形, 衰减率)], 噪声强度)
_SPECS = {
    "click": (0.055, [(0.0, 0.050, 900, 0.35, "sine", 55)], 0.0),
    "select": (0.065, [(0.0, 0.055, 1150, 0.30, "tri", 60)], 0.0),
    "deal": (0.32, [(0.00, 0.08, 520, 0.26, "sine", 30),
                    (0.09, 0.08, 600, 0.26, "sine", 30),
                    (0.18, 0.10, 700, 0.30, "sine", 30)], 0.05),
    "play": (0.20, [(0.0, 0.17, 700, 0.34, "sine", 16),
                    (0.04, 0.15, 520, 0.26, "sine", 16)], 0.0),
    "pass": (0.16, [(0.0, 0.14, 300, 0.28, "sine", 22)], 0.0),
    "stone": (0.13, [(0.0, 0.11, 220, 0.36, "square", 42),
                     (0.0, 0.07, 860, 0.16, "sine", 65)], 0.20),
    "flip": (0.15, [(0.0, 0.10, 420, 0.26, "tri", 20),
                    (0.06, 0.09, 900, 0.20, "tri", 24)], 0.0),
    "win": (0.64, [(0.00, 0.16, 523, 0.26, "sine", 12),
                   (0.13, 0.16, 659, 0.28, "sine", 12),
                   (0.26, 0.18, 784, 0.30, "sine", 12),
                   (0.42, 0.22, 1047, 0.32, "sine", 10)], 0.0),
    "lose": (0.56, [(0.00, 0.16, 392, 0.30, "sine", 14),
                    (0.14, 0.16, 330, 0.28, "sine", 14),
                    (0.28, 0.28, 262, 0.24, "sine", 12)], 0.0),
    "bust": (0.32, [(0.0, 0.10, 980, 0.32, "square", 26),
                    (0.10, 0.20, 700, 0.28, "square", 20)], 0.0),
    "draw": (0.24, [(0.0, 0.22, 440, 0.22, "sine", 12)], 0.0),
    "coin": (0.26, [(0.0, 0.08, 880, 0.30, "tri", 25),
                    (0.08, 0.14, 1320, 0.26, "tri", 20)], 0.0),
}

_cache_dir = None
_effects = {}          # name -> [QSoundEffect, ...]，两个实例轮换，允许叠加
_rot = {}              # name -> 下次用第几个实例
_players = {}          # QMediaPlayer 回退用
_mode = None
state = {"enabled": True, "volume": 0.55}


def _osc(freq, t, kind):
    ph = 2.0 * math.pi * freq * t
    s = math.sin(ph)
    if kind == "square":
        return 1.0 if s >= 0 else -1.0
    if kind == "tri":
        return 2.0 / math.pi * math.asin(max(-1.0, min(1.0, s)))
    return s


def _render(duration, notes, noise):
    n = int(_RATE * duration)
    buf = [0.0] * n
    for (st, du, fq, am, kind, dec) in notes:
        i0 = int(st * _RATE)
        i1 = min(n, int((st + du) * _RATE))
        for i in range(i0, i1):
            t = (i - i0) / float(_RATE)
            env = math.exp(-dec * t)
            if t < 0.003:                 # 起头 3ms 淡入，别爆音
                env *= t / 0.003
            buf[i] += am * env * _osc(fq, t, kind)
    if noise:
        rnd = random.Random(7)
        for i in range(n):
            buf[i] += noise * (rnd.random() - 0.5) * math.exp(-70.0 * (i / _RATE))
    peak = 0.0
    for v in buf:
        if abs(v) > peak:
            peak = abs(v)
    if peak > 0.96:
        k = 0.96 / peak
        buf = [v * k for v in buf]
    return buf


def _write(path, buf):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(_RATE)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32767))
                               for v in buf))


def _dir():
    global _cache_dir
    if _cache_dir:
        return _cache_dir
    try:
        d = os.path.join(platform_utils.data_dir(), "sfx")
    except Exception:
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher_sfx")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    _cache_dir = d
    return d


def _path(name):
    p = os.path.join(_dir(), "%s.wav" % name)
    if os.path.isfile(p) and os.path.getsize(p) >= 200:
        return p
    spec = _SPECS.get(name)
    if not spec:
        return None
    try:
        _write(p, _render(spec[0], spec[1], spec[2] if len(spec) > 2 else 0.0))
        return p
    except Exception:
        return None


def _soundeffect_cls():
    for mod in ("PySide6.QtMultimedia", "PySide2.QtMultimedia"):
        try:
            m = __import__(mod, fromlist=["QSoundEffect"])
        except Exception:
            continue
        cls = getattr(m, "QSoundEffect", None)
        if cls is not None:
            return cls
    return None


def _init():
    """第一次播放时才知道该用哪套后端（必须等 QApplication 建好）。"""
    global _mode
    if _mode is not None:
        return _mode
    if _soundeffect_cls() is not None:
        _mode = "soundeffect"
        return _mode
    try:
        from ui.media_compat import HAS_MEDIA
        if HAS_MEDIA:
            _mode = "player"
            return _mode
    except Exception:
        pass
    try:
        import winsound              # noqa: F401
        _mode = "winsound"
    except Exception:
        _mode = "none"
    return _mode


def _effect_for(name):
    """取这个音效的实例组（两个轮流，连点两下不会互相掐断）。"""
    if name in _effects:
        return _effects[name]
    cls = _soundeffect_cls()
    p = _path(name)
    arr = []
    if cls is not None and p:
        for _ in range(2):
            try:
                eff = cls()
                eff.setSource(_qurl(p))
                eff.setLoopCount(1)
                try:
                    eff.setVolume(float(state["volume"]))
                except Exception:
                    pass
                arr.append(eff)
            except Exception:
                break
    _effects[name] = arr
    return arr


def _qurl(path):
    for mod in ("PySide6.QtCore", "PySide2.QtCore"):
        try:
            m = __import__(mod, fromlist=["QUrl"])
        except Exception:
            continue
        return m.QUrl.fromLocalFile(path)
    return None


def play(name):
    """播一个音效。任何异常都吞掉——音效绝不能拖垮对局。"""
    if not state.get("enabled", True):
        return
    try:
        mode = _init()
    except Exception:
        return
    try:
        if mode == "soundeffect":
            arr = _effect_for(name)
            if not arr:
                return
            i = _rot.get(name, 0) % len(arr)
            _rot[name] = i + 1
            try:
                arr[i].setVolume(float(state["volume"]))
            except Exception:
                pass
            arr[i].play()
            return
        if mode == "player":
            from ui.media_compat import make_player, make_audio, set_source
            pl = _players.get(name)
            if pl is None:
                pl = make_player()
                if pl is None:
                    return
                _players[name] = (pl, make_audio(pl, None, state["volume"]))
                pl = _players[name]
            player, audio = pl
            u = _qurl(_path(name))
            if u is None:
                return
            set_source(player, u)
            try:
                from ui.media_compat import set_volume
                set_volume(player, audio, state["volume"])
            except Exception:
                pass
            player.play()
            return
        if mode == "winsound":
            import winsound
            p = _path(name)
            if p:
                winsound.PlaySound(p, winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        return


def set_enabled(on):
    state["enabled"] = bool(on)


def set_volume(v):
    state["volume"] = max(0.0, min(1.0, float(v)))


def warmup():
    """启动时先把 wav 生成好，避免第一次点按钮时才现算（约 20~60ms）。"""
    for name in _SPECS:
        try:
            _path(name)
        except Exception:
            pass


def names():
    return sorted(_SPECS)
