# -*- coding: utf-8 -*-
"""好友关系：申请、通过策略、黑名单、双向同步。

还是走 ntfy 公共中转（跟聊天、对局一套路），一人一个收件箱：
    omc-frq3-<账号名哈希>

消息类型：
    {"t":"freq","f":我,"to":他,"txt":"指定的口令","note":"打招呼的话"}
    {"t":"facc","f":我,"to":他,"yes":1/0}        答复对方的申请
    {"t":"fadd","f":我,"to":他}                   我已经加了你，你也把我加上（双向同步）
    {"t":"fdel","f":我,"to":他,"k":"un"/"black"}   删好友 / 拉黑

本机存三个文件（都在 ~/.simple_mc_launcher 下）：
    friendreq.json    收到的申请（等他点同意）
    blacklist.json    黑名单
    friendpolicy.json 别人加我的方式：直接通过 / 需要申请 / 需要指定文本 / 禁止
"""
import hashlib
import json
import os
import time

from core import gamesync as gs

MODES = ("open", "ask", "phrase", "closed")
MODE_LABELS = {
    "open": "直接通过（对方一加就互相成为好友）",
    "ask": "需要申请（我看到后点同意才加）",
    "phrase": "需要输入指定文本（口令对才加）",
    "closed": "禁止别人加我（只能我自己加别人）",
}
MODE_SHORT = {"open": "直接通过", "ask": "需要申请",
              "phrase": "需要口令", "closed": "禁止加我"}


def _h(s):
    return hashlib.md5(s.encode("utf-8")).hexdigest()[:12]


def topic(name):
    """每人一个好友申请收件箱。"""
    return "omc-frq3-" + _h("omc-frq3-v1|" + (name or "").strip().lower())


def _base():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def _load(fn, default):
    p = os.path.join(_base(), fn)
    if not os.path.isfile(p):
        return default
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save(fn, data):
    p = os.path.join(_base(), fn)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


# ---------- 策略 ----------
def policy():
    d = _load("friendpolicy.json", {})
    mode = d.get("mode") or "open"
    if mode not in MODES:
        mode = "open"
    return {"mode": mode, "phrase": d.get("phrase") or ""}


def set_policy(mode, phrase=""):
    if mode not in MODES:
        mode = "open"
    _save("friendpolicy.json", {"mode": mode,
                                "phrase": (phrase or "").strip(),
                                "ts": int(time.time())})
    return MODE_SHORT[mode]


def decide(mode, phrase, incoming_text):
    """接收端判定：accept / ask / deny。"""
    if mode == "open":
        return "accept"
    if mode == "ask":
        return "ask"
    if mode == "phrase":
        want = (phrase or "").strip()
        got = (incoming_text or "").strip()
        return "accept" if (want and got and want == got) else "deny"
    if mode == "closed":
        return "deny"
    return "ask"


# ---------- 收到的申请 ----------
def requests():
    return _load("friendreq.json", {"items": []}).get("items") or []


def add_request(name, uid="", text="", note=""):
    name = (name or "").strip()
    if not name:
        return False
    data = _load("friendreq.json", {"items": []})
    items = data.get("items") or []
    key = name.lower()
    for it in items:
        if (it.get("name") or "").lower() == key:
            it["ts"] = int(time.time())
            it["text"] = text or it.get("text") or ""
            data["items"] = items
            _save("friendreq.json", data)
            return False
    items.append({"name": name, "uid": (uid or "").strip(),
                  "text": text or "", "note": note or "",
                  "ts": int(time.time())})
    data["items"] = items
    _save("friendreq.json", data)
    return True


def drop_request(name):
    name = (name or "").strip().lower()
    data = _load("friendreq.json", {"items": []})
    data["items"] = [it for it in (data.get("items") or [])
                     if (it.get("name") or "").lower() != name]
    _save("friendreq.json", data)


def request_of(name):
    name = (name or "").strip().lower()
    for it in requests():
        if (it.get("name") or "").lower() == name:
            return it
    return None


# ---------- 黑名单 ----------
def blacklist():
    return _load("blacklist.json", {"items": []}).get("items") or []


def is_black(name):
    key = (name or "").strip().lower()
    if not key:
        return False
    for it in blacklist():
        if (it.get("name") or "").lower() == key:
            return True
    return False


def black_add(name, uid="", why=""):
    name = (name or "").strip()
    if not name:
        return False, "名字不能空"
    if is_black(name):
        return False, "已经在黑名单里"
    data = _load("blacklist.json", {"items": []})
    data.setdefault("items", []).append(
        {"name": name, "uid": (uid or "").strip(), "why": why or "",
         "ts": int(time.time()), "since": time.strftime("%Y-%m-%d %H:%M")})
    _save("blacklist.json", data)
    return True, "已拉黑 %s" % name


def black_remove(name):
    key = (name or "").strip().lower()
    data = _load("blacklist.json", {"items": []})
    data["items"] = [it for it in (data.get("items") or [])
                     if (it.get("name") or "").lower() != key]
    _save("blacklist.json", data)


# ---------- 发消息 ----------
def _send(peer, payload, timeout=gs.TIMEOUT):
    if not peer:
        return False
    try:
        gs._post(topic(peer), payload, timeout=timeout)
        return True
    except Exception:
        return False


def send_request(me, peer, text="", note=""):
    if not me or not peer:
        return False, "还没登录或没选人"
    ok = _send(peer, {"t": "freq", "f": me, "to": peer,
                      "txt": (text or "")[:120], "note": (note or "")[:120],
                      "ts": int(time.time())})
    if not ok:
        return False, "申请没发出去，检查一下网络"
    return True, "好友申请已发给 %s，等对方处理" % peer


def send_reply(me, peer, yes):
    return _send(peer, {"t": "facc", "f": me, "to": peer,
                        "yes": 1 if yes else 0, "ts": int(time.time())})


def notify_added(me, peer):
    """双向同步：我加了你，同时通知你把我加上，避免「甲有乙、乙没有甲」。"""
    return _send(peer, {"t": "fadd", "f": me, "to": peer,
                        "ts": int(time.time())})


def notify_removed(me, peer, kind="un"):
    return _send(peer, {"t": "fdel", "f": me, "to": peer, "k": kind,
                        "ts": int(time.time())})


def poll(me, since="180s", timeout=gs.TIMEOUT):
    """拉自己的收件箱，只留发给我的、不是我自己发的、也不在我黑名单里的。"""
    me_l = (me or "").strip().lower()
    if not me_l:
        return []
    rows = gs._pull(topic(me), since=since, timeout=timeout,
                    kinds=("freq", "facc", "fadd", "fdel"))
    out = []
    for r in rows:
        to_l = (r.get("to") or "").strip().lower()
        if to_l and to_l != me_l:
            continue
        f = (r.get("f") or "").strip()
        if not f or f.lower() == me_l:
            continue
        if is_black(f):
            continue
        out.append(r)
    return out


def pretty(msg):
    """把一条消息变成一句能直接显示的话。"""
    t = msg.get("t")
    f = msg.get("f") or "某人"
    if t == "freq":
        return "%s 想加你为好友" % f
    if t == "facc":
        return "%s %s你的好友申请" % (f, "同意" if int(msg.get("yes") or 0) else "拒绝")
    if t == "fadd":
        return "%s 加了你，已自动互加" % f
    if t == "fdel":
        return "%s 把你%s了" % (f, "拉黑" if (msg.get("k") or "") == "black" else "删掉")
    return f
