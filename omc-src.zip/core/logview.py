# -*- coding: utf-8 -*-
"""日志与崩溃报告的中文诊断：把一堆 Java 报错翻成人话 + 给具体做法。

只做「识别常见故障」，不做完整栈分析。找到第一条命中就给结论，
没命中也要把最后几行原文留给用户/开发者看。
"""
import os
import re
import time

TAIL_LINES = 40

# (正则, 级别, 结论标题, 处理建议)
RULES = [
    (r"UnsupportedClassVersionError|compiled by a more recent version of the Java Runtime",
     "error", "Java 版本太低",
     "这个模组/游戏要求更高的 Java。到「工具」页里选一个 Java 21 再启动；"
     "1.17 以下用 Java 8，1.18–1.20.4 用 Java 17。"),
    (r"OutOfMemoryError: Java heap space",
     "error", "内存不够（堆溢出）",
     "把内存调大：启动页有一键 4G/8G/16G；同时别给 32 位 Java 分超过 1G。"),
    (r"OutOfMemoryError: Metaspace",
     "error", "元空间不够（模组太多）",
     "模组数量过多，把 JVM 参数模板换成「大模组包」，或删掉不用的模组。"),
    (r"ModResolutionException|Incompatible mod set|incompatible mod set",
     "error", "模组依赖冲突",
     "去「工具」页点「扫描模组冲突」，它会列出缺哪个前置、哪个模组装了重复版本。"),
    (r"which is missing|Missing or unsupported mandatory dependencies|"
     r"requires .* which is missing",
     "error", "缺前置模组",
     "报错里点名的那个模组没装。按名字去模组页搜出来装上，再启动。"),
    (r"Duplicate mods found|already registered",
     "error", "模组重复注册",
     "同一个模组装了两份（常见于手动复制 jar）。工具页扫描后按提示删掉旧的那份。"),
    (r"Mixin apply failed|MixinTransformerError|MixinExtras",
     "error", "Mixin 注入失败",
     "多半是模组版本和 MC/加载器不匹配。把报错里的模组升到对应游戏版本，"
     "或暂时禁用最近新装的那个。"),
    (r"Failed to create window|GLFW error|GLXBadFBConfig|Cannot open display|"
     r"Unable to create GLFW window",
     "error", "显卡/OpenGL 初始化失败",
     "更新显卡驱动；笔记本切到独显；Linux 上确认装了 Mesa 与 libGL；"
     "远程桌面/虚拟机里跑需要在物理机上试。"),
    (r"Pixel format not accelerated|OpenGL .*not supported",
     "error", "显卡不支持所需 OpenGL",
     "驱动太旧或被系统用的是软渲染。更新驱动，或装 OpenGL 4.6 支持的显卡驱动。"),
    (r"NoClassDefFoundError|ClassNotFoundException",
     "warn", "缺类/库文件",
     "通常是模组包不完整或 Java 版本不对。重新下载那个模组，"
     "再确认 Java 主版本是否匹配。"),
    (r"A fatal error has been detected by the Java Runtime Environment|hs_err_pid",
     "error", "JVM 崩溃（生成了 hs_err 日志）",
     "看 crash-reports 里最新那份，头部有 「Problematic frame」；"
     "多数是显卡驱动或 32 位 Java 内存越界，换 Java 21 或更新驱动能解决大部分。"),
    (r"java.lang.IllegalStateException: GLFW",
     "error", "窗口创建失败",
     "同上：显卡驱动、远程桌面、虚拟机。"),
    (r"AccessDeniedException|java.io.FileNotFoundException|拒绝访问",
     "warn", "文件权限/路径问题",
     "游戏目录可能被杀毒软件锁住，或路径里有中文/空格。把 .minecraft 移到"
     "纯英文路径下试试，并把启动器加入杀毒白名单。"),
    (r"Address already in use|BindException",
     "warn", "端口被占用",
     "上一次的游戏进程可能没退干净，任务管理器结束 java.exe 再启动；"
     "联机端口冲突就在联机页换个端口。"),
    (r"Could not find or load main class|Error: Could not find or load",
     "error", "启动参数/主类找不到",
     "版本 json 可能损坏。工具页备份该版本后删掉重新下载一次。"),
    (r"java.lang.VerifyError|java.lang.LinkageError",
     "error", "字节码校验失败",
     "Java 版本与模组编译目标不一致，换对应 Java 主版本。"),
    (r"Failed to download|Couldn't download|download failed|SSLHandshake",
     "warn", "下载失败/网络问题",
     "启动器设置里把下载源切到「国内镜像」，或检查代理。"),
]

# (级别, 图标颜色, 标题) —— 供 UI 直接用
LEVEL_COLOR = {"error": "#FF6B6B", "warn": "#FFC53D", "info": "#4C8DFF"}


def log_path(game_dir):
    return os.path.join(game_dir, "logs", "latest.log")


def crash_dir(game_dir):
    return os.path.join(game_dir, "crash-reports")


def latest_crash(game_dir):
    """crash-reports 里最新的 .txt。"""
    d = crash_dir(game_dir)
    if not os.path.isdir(d):
        return None
    files = [os.path.join(d, n) for n in os.listdir(d)
             if n.lower().endswith(".txt")]
    if not files:
        return None
    files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return files[0]


def read_text(path, limit=400000):
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except OSError:
        return ""


def diagnose(text, max_hits=6):
    """在一段日志里找已知故障，返回 [{level,title,advice,evidence}]。"""
    hits = []
    text = text or ""
    for pattern, level, title, advice in RULES:
        m = re.search(pattern, text, re.I)
        if not m:
            continue
        # 抓命中处往后一段原文，方便对照上下文
        seg = text[max(0, m.start()):m.end() + 240]
        seg = re.sub(r"\s+", " ", seg).strip()
        hits.append({"level": level, "title": title, "advice": advice,
                     "evidence": seg[:260]})
        if len(hits) >= max_hits:
            break
    return hits


def tail(text, n=TAIL_LINES):
    lines = [ln for ln in (text or "").splitlines() if ln.strip()]
    return "\n".join(lines[-n:])


def report(game_dir):
    """汇总一次诊断结果：最近日志 + 最近崩溃报告 + 命中项。"""
    lp = log_path(game_dir)
    cp = latest_crash(game_dir)
    log_text = read_text(lp)
    crash_text = read_text(cp, 200000)
    items = diagnose(log_text + "\n" + crash_text)
    out = {
        "log_path": lp if os.path.isfile(lp) else "",
        "log_time": time.strftime("%Y-%m-%d %H:%M",
                                  time.localtime(os.path.getmtime(lp)))
        if os.path.isfile(lp) else "",
        "crash_path": cp or "",
        "crash_time": time.strftime("%Y-%m-%d %H:%M",
                                    time.localtime(os.path.getmtime(cp)))
        if cp and os.path.isfile(cp) else "",
        "items": items,
        "tail": tail(log_text or crash_text),
        "ok": bool(items),
    }
    if not items:
        out["summary"] = "没在最近的日志里发现已知故障。"
    else:
        out["summary"] = "；".join(i["title"] for i in items[:3])
    return out
