# -*- coding: utf-8 -*-
"""存档导入：支持文件夹或 .zip 压缩包，写入游戏目录 saves。"""
import os
import shutil
import zipfile


def saves_dir(game_dir):
    d = os.path.join(game_dir, "saves")
    os.makedirs(d, exist_ok=True)
    return d


def list_saves(game_dir):
    d = saves_dir(game_dir)
    result = []
    for name in os.listdir(d):
        path = os.path.join(d, name)
        if os.path.isdir(path) and os.path.exists(os.path.join(path, "level.dat")):
            result.append(name)
    return sorted(result)


def world_icon(game_dir, name):
    """存档封面为目录内 icon.png，没有则返回 None 由界面画占位图。"""
    p = os.path.join(saves_dir(game_dir), name, "icon.png")
    try:
        if os.path.exists(p):
            with open(p, "rb") as f:
                return f.read()
    except Exception:
        pass
    return None


def _import_folder(path, game_dir, log):
    if not os.path.exists(os.path.join(path, "level.dat")):
        raise RuntimeError("该文件夹里没有 level.dat，不是存档")
    name = os.path.basename(path.rstrip(os.sep))
    dest = os.path.join(saves_dir(game_dir), name)
    if os.path.exists(dest):
        base = name
        i = 1
        while os.path.exists(os.path.join(saves_dir(game_dir),
                                          "%s_%d" % (base, i))):
            i += 1
        dest = os.path.join(saves_dir(game_dir), "%s_%d" % (base, i))
        name = os.path.basename(dest)
    shutil.copytree(path, dest)
    log("已导入存档：" + name)
    return name


def _import_zip(path, game_dir, log):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        roots = {n.split("/")[0] for n in names if "/" in n}
        has_level = any(n.endswith("level.dat") for n in names)
        if not has_level:
            raise RuntimeError("压缩包里没有 level.dat，不是存档")

        # 压缩包内统一根目录：直接解；否则套一层文件夹
        single_root = len(roots) == 1 and any(
            n == list(roots)[0] + "/level.dat" for n in names)
        if single_root:
            root = list(roots)[0]
            target = os.path.join(saves_dir(game_dir), root)
            if os.path.exists(target):
                raise RuntimeError("同名存档已存在：" + root)
            z.extractall(saves_dir(game_dir))
            log("已导入存档：" + root)
            return root
        else:
            name = os.path.splitext(os.path.basename(path))[0]
            target = os.path.join(saves_dir(game_dir), name)
            if os.path.exists(target):
                raise RuntimeError("同名存档已存在：" + name)
            os.makedirs(target, exist_ok=True)
            z.extractall(target)
            log("已导入存档：" + name)
            return name


def import_save(path, game_dir, log):
    if os.path.isdir(path):
        return _import_folder(path, game_dir, log)
    if path.lower().endswith(".zip"):
        return _import_zip(path, game_dir, log)
    raise RuntimeError("存档只支持文件夹或 .zip 压缩包")


def install_from_url(url, game_dir, log=None, progress=None):
    """从 http/https 直链下载存档 zip 并装进 saves 目录，返回存档名。"""
    import re
    import tempfile

    from . import http

    log = log or (lambda _m: None)
    url = (url or "").strip()
    if not re.match(r"^https?://", url, re.I):
        raise RuntimeError("请填 http:// 或 https:// 开头的存档下载链接")

    # 用链接里的文件名做存档名，避免全叫 world
    raw = url.split("?")[0].split("#")[0]
    base = os.path.basename(raw) or "world.zip"
    if not base.lower().endswith(".zip"):
        base = (os.path.splitext(base)[0] or "world") + ".zip"
    if not base or len(base) > 120:
        base = "world.zip"

    tmpdir = tempfile.mkdtemp(prefix="omc_world_")
    dest = os.path.join(tmpdir, base)
    log("开始下载存档：" + raw)
    http.download_file(url, dest, mirror="official", progress=progress,
                       retries=3, timeout=180)
    if not zipfile.is_zipfile(dest):
        raise RuntimeError(
            "这个链接下载到的不是 zip 文件（可能是网页地址），"
            "请复制存档真正的 .zip 下载链接再试")
    log("下载完成（%.1f MB），正在解包校验......"
        % (os.path.getsize(dest) / 1048576.0))
    return import_save(dest, game_dir, log)
