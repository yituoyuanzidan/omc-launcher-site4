# -*- coding: utf-8 -*-
"""模组与整合包安装：支持拖入 .jar 模组，以及 .mrpack / .zip 整合包。"""
import json
import os
import shutil
import zipfile

from . import http


def mods_dir(game_dir):
    d = os.path.join(game_dir, "mods")
    os.makedirs(d, exist_ok=True)
    return d


def list_mods(game_dir):
    d = mods_dir(game_dir)
    return sorted(f for f in os.listdir(d) if f.lower().endswith((".jar", ".zip")))


def _read_member(z, path):
    if not path:
        return None
    try:
        return z.read(path)
    except KeyError:
        return None


def _fabric_info(z):
    if "fabric.mod.json" not in z.namelist():
        return None
    data = json.loads(z.read("fabric.mod.json").decode("utf-8", "replace"))
    icon = _read_member(z, data.get("icon"))
    return {
        "id": data.get("id", ""),
        "name": data.get("name") or data.get("id", ""),
        "description": (data.get("description") or "").strip(),
        "icon": icon,
        "loaders": {"fabric", "quilt"},
    }


def _toml_info(z, candidate, loader=""):
    import tomllib
    if candidate not in z.namelist():
        return None
    meta = tomllib.loads(z.read(candidate).decode("utf-8", "replace"))
    entries = meta.get("mods") or []
    if not entries:
        return None
    m = entries[0]
    logo = (m.get("logoFile") or "").strip()
    return {
        "id": m.get("modId", ""),
        "name": m.get("displayName") or m.get("modId", ""),
        "description": (m.get("description") or "").strip(),
        "icon": _read_member(z, logo) if logo else None,
        "loaders": {loader} if loader else set(),
    }


def _legacy_info(z):
    if "mcmod.info" not in z.namelist():
        return None
    raw = json.loads(z.read("mcmod.info").decode("utf-8", "replace"))
    entries = raw.get("modList") if isinstance(raw, dict) else raw
    if not entries:
        return None
    m = entries[0]
    return {
        "id": m.get("modid", ""),
        "name": m.get("name") or m.get("modid", ""),
        "description": (m.get("description") or "").strip(),
        "icon": _read_member(z, m.get("logoImage")),
    }


def mod_info(path):
    """从 jar 内读模组元数据（名称、简介、封面图、适用加载器），失败则回退文件名。"""
    fallback = {"id": "", "name": os.path.basename(path),
                "description": "", "icon": None, "loaders": set()}
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            info = _fabric_info(z)
            toml_info = None
            if "META-INF/neoforge.mods.toml" in names:
                toml_info = _toml_info(z, "META-INF/neoforge.mods.toml",
                                       "neoforge")
            elif "META-INF/mods.toml" in names:
                toml_info = _toml_info(z, "META-INF/mods.toml", "forge")
            if info and toml_info:
                info["loaders"] = info["loaders"] | toml_info["loaders"]
                return info
            if info:
                return info
            if toml_info:
                return toml_info
            legacy = _legacy_info(z)
            if legacy:
                legacy.setdefault("loaders", set())
                return legacy
            return fallback
    except Exception:
        return fallback


def list_resourcepacks(game_dir):
    d = os.path.join(game_dir, "resourcepacks")
    if not os.path.isdir(d):
        return []
    out = []
    for name in os.listdir(d):
        p = os.path.join(d, name)
        if os.path.isdir(p) or name.lower().endswith(".zip"):
            out.append(name)
    return sorted(out)


def resourcepack_info(game_dir, name):
    """资源包封面取 pack.png（zip 内或文件夹根目录）。"""
    path = os.path.join(game_dir, "resourcepacks", name)
    icon = None
    try:
        if os.path.isdir(path):
            pp = os.path.join(path, "pack.png")
            if os.path.exists(pp):
                with open(pp, "rb") as f:
                    icon = f.read()
        else:
            with zipfile.ZipFile(path) as z:
                if "pack.png" in z.namelist():
                    icon = z.read("pack.png")
    except Exception:
        icon = None
    return {"name": name, "description": "", "icon": icon}


def add_mod_files(paths, game_dir, log=None):
    """把 .jar 模组复制进 mods 目录。"""
    say = log or (lambda m: None)
    dest_dir = mods_dir(game_dir)
    added = []
    for p in paths:
        if not os.path.isfile(p):
            continue
        name = os.path.basename(p)
        if not name.lower().endswith((".jar", ".zip")):
            say("跳过不是模组的文件：" + name)
            continue
        target = os.path.join(dest_dir, name)
        try:
            if os.path.abspath(p) != os.path.abspath(target):
                shutil.copy2(p, target)
            added.append(name)
            say("已添加模组：" + name)
        except Exception as e:
            say("添加失败 %s：%s" % (name, e))
    return added


def _extract_overrides(z, prefixes, game_dir, log):
    """把整合包里的 overrides/config 等内容解到游戏目录。"""
    count = 0
    for member in z.namelist():
        if member.endswith("/"):
            continue
        for prefix in prefixes:
            if member.startswith(prefix):
                rel = member[len(prefix):]
                if not rel:
                    continue
                target = os.path.join(game_dir, rel.replace("/", os.sep))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(member) as src, open(target, "wb") as out:
                    out.write(src.read())
                count += 1
                break
    if count:
        log("已写入整合包附加文件 %d 个" % count)


def install_mrpack(path, game_dir, log, progress, mirror="official"):
    """Modrinth 整合包（.mrpack）。"""
    with zipfile.ZipFile(path) as z:
        index = json.loads(z.read("modrinth.index.json").decode("utf-8"))
        name = index.get("name") or os.path.basename(path)
        deps = index.get("dependencies") or {}
        files = index.get("files") or []
        client_files = [f for f in files
                        if (f.get("env") or {}).get("client") != "unsupported"]

        log("整合包：%s，待安装 %d 个文件" % (name, len(client_files)))
        for i, f in enumerate(client_files, 1):
            rel = f.get("path") or ""
            if not rel:
                continue
            dest = os.path.join(game_dir, rel.replace("/", os.sep))
            downloads = f.get("downloads") or []
            if not downloads:
                log("跳过无下载地址：" + rel)
                continue
            try:
                http.download_file(downloads[0], dest, mirror,
                                   size=f.get("fileSize"),
                                   sha1=((f.get("hashes") or {}).get("sha1")))
            except Exception as e:
                log("下载失败 %s：%s" % (rel, e))
            progress(i, len(client_files))

        _extract_overrides(z, ("overrides/", "client-overrides/"), game_dir, log)

    return {
        "kind": "mrpack",
        "name": name,
        "minecraft": deps.get("minecraft"),
        "loader": deps.get("fabric-loader") or deps.get("forge") or deps.get("quilt-loader"),
        "mods": len(list_mods(game_dir)),
    }


def install_zip_pack(path, game_dir, log, progress, mirror="official"):
    """通用 .zip 整合包：能识别 CurseForge 清单，也能直接抽出里面的 jar。"""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        has_cf = "manifest.json" in names

        if has_cf:
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            mc = (manifest.get("minecraft") or {})
            log("整合包（CurseForge）：%s" %
                (manifest.get("name") or os.path.basename(path)))

        # 先把包里自带 / mods 目录下的 jar 落盘
        jars = [n for n in names if n.lower().endswith(".jar") and not n.endswith("/")]
        dest_dir = mods_dir(game_dir)
        total = len(jars)
        copied = 0
        for i, member in enumerate(jars, 1):
            base = os.path.basename(member)
            if base:
                target = os.path.join(dest_dir, base)
                if not os.path.exists(target):
                    with z.open(member) as src, open(target, "wb") as out:
                        out.write(src.read())
                    copied += 1
            progress(i, total)

        _extract_overrides(z, ("overrides/", "config/", "defaultconfigs/",
                               "resourcepacks/", "shaderpacks/"), game_dir, log)

        minecraft = None
        loader = None
        if has_cf:
            minecraft = (manifest.get("minecraft") or {}).get("version")
            loaders = (manifest.get("minecraft") or {}).get("modLoaders") or []
            if loaders:
                loader = loaders[0].get("id")

    if copied == 0 and has_cf:
        log("该 CurseForge 整合包没有内嵌模组文件，需要联网按清单下载；"
            "建议改用 Modrinth 的 .mrpack 整合包，或先把模组解压到 mods 目录")

    return {
        "kind": "curseforge" if has_cf else "zip",
        "name": os.path.basename(path),
        "minecraft": minecraft,
        "loader": loader,
        "mods": len(list_mods(game_dir)),
        "copied": copied,
    }


def install_paths(paths, game_dir, log=None, progress=None, mirror="official"):
    """统一入口：.mrpack / .zip 当整合包，.jar 当单个模组。"""
    say = log or (lambda m: None)
    step = progress or (lambda c, t: None)
    results = []
    for p in paths:
        name = os.path.basename(p)
        if not os.path.isfile(p):
            continue
        low = name.lower()
        if low.endswith(".mrpack"):
            results.append(install_mrpack(p, game_dir, say, step, mirror))
        elif low.endswith(".zip"):
            results.append(install_zip_pack(p, game_dir, say, step, mirror))
        elif low.endswith(".jar"):
            added = add_mod_files([p], game_dir, say)
            results.append({"kind": "mod", "name": name, "added": added})
        else:
            say("不认识的格式：" + name)
    return results
