# -*- coding: utf-8 -*-
"""在线搜歌：用 iTunes 的公开搜索接口。

为什么用它：不用注册、不用 key、返回里直接带可播放的试听地址，中文歌在
香港 / 美国商店都有收录。国内几家音乐平台的搜索接口都要签名或登录态，
放不了歌还容易失效。

注意：返回的播放地址是**试听片段**（一般 30 秒左右），不是整首。
"""
import json
import re
import ssl
import urllib.parse
import urllib.request

TIMEOUT = 10
# 一个商店搜不到就换下一个：香港收录中文歌最全，美国兜底英文歌
COUNTRIES = ("HK", "US")
PAGE_SIZE = 25
# 一次抓这么多个（iTunes 上限 200），翻页在本地切片。
# 它的 offset 参数实测不生效（传 offset=25 回来还是第一页），只能自己切。
FETCH_SIZE = 120
_CACHE_LIMIT = 8

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# 音乐接口一律直连，不走系统代理。
# 用户开着加速器 / 科学上网工具时，系统代理会把 music.163.com、itunes.apple.com
# 这些本来能直连的域名也一起转发出去，结果就是搜索超时、试听地址拿到 HTML，
# 表现成「搜不到歌 / 播不了 / 加不进列表」。显式给个空 ProxyHandler 绕开。
_OPENER = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=_CTX))

# 缓存：(国家, 关键词) -> 该店能搜到的全部条目
_CACHE = {}
_LAST_COUNTRY = [None]


def _open(req, timeout):
    """统一的发请求入口：走直连 opener，不用系统代理。"""
    return _OPENER.open(req, timeout=timeout)


def _fetch(keyword, country, offset, limit):
    url = ("https://itunes.apple.com/search?term=%s&media=music&entity=song"
           "&limit=%d&offset=%d" % (urllib.parse.quote(keyword), limit, offset))
    if country:
        url += "&country=" + country
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with _open(req, TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _parse(raw):
    out = []
    for x in raw.get("results") or []:
        name = (x.get("trackName") or "").strip()
        if not name:
            continue
        preview = (x.get("previewUrl") or "").strip()
        row = {
            "id": x.get("trackId"),
            "name": name,
            "artist": (x.get("artistName") or "").strip(),
            "album": (x.get("collectionName") or "").strip(),
            "ms": int(x.get("trackTimeMillis") or 0),
            "preview": preview,
            "cover": (x.get("artworkUrl100") or "").strip(),
            "page_url": (x.get("trackViewUrl") or "").strip(),
        }
        out.append(row)
    return out


def _dedupe(rows):
    """按 trackId 去重就行：同一首歌的专辑版 / 单曲版确实是两条，不该被吞掉。"""
    seen = set()
    out = []
    for r in rows:
        key = r.get("id") or (r["name"].lower(), r["artist"].lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def _all_rows(keyword, country):
    """把某个商店里这个词能搜到的都拿回来（最多 FETCH_SIZE 条）。"""
    key = (country, keyword)
    if key in _CACHE:
        return _CACHE[key]
    raw = _fetch(keyword, country, 0, FETCH_SIZE)
    rows = _dedupe(_parse(raw))
    if len(_CACHE) >= _CACHE_LIMIT:
        _CACHE.clear()
    _CACHE[key] = rows
    return rows


# 旧接口 /api/search/get 只给 picId、不给封面地址，列表里就全是音符占位；
# /api/cloudsearch/pc 的 al.picUrl 是现成的专辑封面，两边的字段名（al/ar/dt）
# 下面的解析都兼容，所以直接用 cloudsearch。
NETEASE_SEARCH = ("https://music.163.com/api/cloudsearch/pc"
                  "?s=%s&type=1&limit=%d&offset=0")
NETEASE_STREAM = "https://music.163.com/song/media/outer/url?id=%s.mp3"


def _norm(text):
    """归一化歌名 / 歌手，用来做跨平台匹配（去掉空格、标点、括号里的注释）。"""
    s = (text or "").lower()
    s = re.sub(r"[（(\[【].*?[）)\]】]", "", s)
    s = re.sub(r"[\s\-_·,.'\"!?~:;+&/]", "", s)
    return s.strip()


def _https(url):
    """封面地址统一走 https：http 的图在部分网络里会被直接掐掉。"""
    url = (url or "").strip()
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def _netease_rows(keyword, limit=30):
    """网易云搜索：拿到的是歌曲 id，配合外链接口能取整首 mp3。"""
    url = NETEASE_SEARCH % (urllib.parse.quote(keyword), limit)
    req = urllib.request.Request(url, headers={
        "User-Agent": _UA, "Referer": "https://music.163.com/"})
    try:
        with _open(req, 8) as r:
            raw = json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return []
    songs = (raw.get("result") or {}).get("songs") or []
    out = []
    for s in songs:
        sid = s.get("id")
        if not sid:
            continue
        artists = s.get("artists") or s.get("ar") or []
        album = s.get("album") or s.get("al") or {}
        out.append({
            "id": sid,
            "name": (s.get("name") or "").strip(),
            "artist": ", ".join((a.get("name") or "") for a in artists
                                if isinstance(a, dict)).strip(),
            "album": (album.get("name") or "").strip(),
            "cover": _https(album.get("picUrl") or ""),
            "ms": int(s.get("duration") or s.get("dt") or 0),
            "url": NETEASE_STREAM % sid,
        })
    return out


def _netease_row(x):
    """转成和 iTunes 结果一样的结构，界面不用区分来源。"""
    return {
        "id": "ne-%s" % x["id"],
        "name": x["name"],
        "artist": x["artist"],
        "album": x.get("album") or "",
        "ms": x.get("ms") or 0,
        "preview": "",                 # 这个源本来就是整首
        "full_id": x["id"],
        "full_url": x["url"],
        "cover": x.get("cover") or "",
        "page_url": "https://music.163.com/song?id=%s" % x["id"],
    }


def attach_full(rows, keyword):
    """给 iTunes 的搜索结果挂上「整首」地址。

    能挂上的就把 preview 当备用；挂不上的照旧只有 30 秒试听，
    界面会照实标出来，不假装是整首。
    """
    if not rows:
        return rows
    try:
        cands = _netease_rows(keyword)
    except Exception:
        cands = []
    if not cands:
        return rows
    for r in rows:
        nm, ar = _norm(r.get("name")), _norm(r.get("artist"))
        best = None
        for c in cands:
            cn, ca = _norm(c["name"]), _norm(c["artist"])
            if not cn or not nm:
                continue
            if cn != nm and cn not in nm and nm not in cn:
                continue
            # 时长差超过 12 秒基本是另一首（比如同名翻唱 / 剪辑版）
            if r.get("ms") and c["ms"] and abs(r["ms"] - c["ms"]) > 12000:
                continue
            score = 2 if (ca and ar and (ca in ar or ar in ca)) else 0
            if best is None or score > best[0]:
                best = (score, c)
        if best is not None and best[0] > 0:
            r["full_id"] = best[1]["id"]
            r["full_url"] = best[1]["url"]
            r["fullms"] = best[1]["ms"]
    return rows


def search(keyword, page=1, limit=PAGE_SIZE):
    """搜第 page 页（从 1 开始，每页 limit 条）。

    返回 dict：rows / page / has_more / country / error
    """
    keyword = (keyword or "").strip()
    if not keyword:
        return {"rows": [], "page": 1, "has_more": False,
                "country": "", "error": "搜索词是空的"}
    page = max(1, int(page or 1))
    start = (page - 1) * limit

    # 优先走能拿到整首的源；它没结果再退回 iTunes（只有 30 秒试听）
    try:
        nr = _netease_rows(keyword, 60)
    except Exception:
        nr = []
    if nr:
        rows = [_netease_row(x) for x in nr]
        part = rows[start:start + limit]
        if part:
            return {"rows": part, "page": page,
                    "has_more": (start + limit) < len(rows),
                    "country": "网易云", "error": ""}
    # 翻页沿用第一页命中的那个商店，免得第 3 页跑去另一个店翻出重复内容
    order = COUNTRIES
    if page > 1 and _LAST_COUNTRY[0]:
        order = (_LAST_COUNTRY[0],) + tuple(c for c in COUNTRIES
                                           if c != _LAST_COUNTRY[0])

    last_err = ""
    for country in order:
        try:
            rows = _all_rows(keyword, country)
        except Exception as e:
            last_err = "%s：%s" % (country, e)
            continue
        if not rows:
            continue
        part = rows[start:start + limit]
        if not part:
            if page > 1:
                # 这个店就这么多，别再换店重复了
                return {"rows": [], "page": page, "has_more": False,
                        "country": country, "error": "没有下一页了"}
            continue
        if page == 1:
            _LAST_COUNTRY[0] = country
        return {"rows": part, "page": page,
                "has_more": (start + limit) < len(rows),
                "country": country, "error": ""}
    return {"rows": [], "page": page, "has_more": False, "country": "",
            "error": last_err or "这个关键词没搜到（换个写法试试，比如只写歌名）"}
