# -*- coding: utf-8 -*-
"""在线搜歌：用 iTunes 的公开搜索接口。

为什么用它：不用注册、不用 key、返回里直接带可播放的试听地址，中文歌在
香港 / 美国商店都有收录。国内几家音乐平台的搜索接口都要签名或登录态，
放不了歌还容易失效。

注意：返回的播放地址是**试听片段**（一般 30 秒左右），不是整首。
"""
import json
import ssl
import urllib.parse
import urllib.request

TIMEOUT = 10
# 一个商店搜不到就换下一个：香港收录中文歌最全，美国兜底英文歌
COUNTRIES = ("HK", "US")
PAGE_SIZE = 25
# 一次抓这么多个（iTunes 上限 200），翻页在本地切片。
# 它的 offset 参数实测不生效（传 offset=25 回来还是第一页），只能自己切。
FETCH_SIZE = 120
_CACHE_LIMIT = 8

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# 缓存：(国家, 关键词) -> 该店能搜到的全部条目
_CACHE = {}
_LAST_COUNTRY = [None]


def _fetch(keyword, country, offset, limit):
    url = ("https://itunes.apple.com/search?term=%s&media=music&entity=song"
           "&limit=%d&offset=%d" % (urllib.parse.quote(keyword), limit, offset))
    if country:
        url += "&country=" + country
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=TIMEOUT, context=_CTX) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _parse(raw):
    out = []
    for x in raw.get("results") or []:
        name = (x.get("trackName") or "").strip()
        if not name:
            continue
        preview = (x.get("previewUrl") or "").strip()
        row = {
            "id": x.get("trackId"),
            "name": name,
            "artist": (x.get("artistName") or "").strip(),
            "album": (x.get("collectionName") or "").strip(),
            "ms": int(x.get("trackTimeMillis") or 0),
            "preview": preview,
            "cover": (x.get("artworkUrl100") or "").strip(),
            "page_url": (x.get("trackViewUrl") or "").strip(),
        }
        out.append(row)
    return out


def _dedupe(rows):
    """按 trackId 去重就行：同一首歌的专辑版 / 单曲版确实是两条，不该被吞掉。"""
    seen = set()
    out = []
    for r in rows:
        key = r.get("id") or (r["name"].lower(), r["artist"].lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def _all_rows(keyword, country):
    """把某个商店里这个词能搜到的都拿回来（最多 FETCH_SIZE 条）。"""
    key = (country, keyword)
    if key in _CACHE:
        return _CACHE[key]
    raw = _fetch(keyword, country, 0, FETCH_SIZE)
    rows = _dedupe(_parse(raw))
    if len(_CACHE) >= _CACHE_LIMIT:
        _CACHE.clear()
    _CACHE[key] = rows
    return rows


def search(keyword, page=1, limit=PAGE_SIZE):
    """搜第 page 页（从 1 开始，每页 limit 条）。

    返回 dict：rows / page / has_more / country / error
    """
    keyword = (keyword or "").strip()
    if not keyword:
        return {"rows": [], "page": 1, "has_more": False,
                "country": "", "error": "搜索词是空的"}
    page = max(1, int(page or 1))
    start = (page - 1) * limit

    # 翻页沿用第一页命中的那个商店，免得第 3 页跑去另一个店翻出重复内容
    order = COUNTRIES
    if page > 1 and _LAST_COUNTRY[0]:
        order = (_LAST_COUNTRY[0],) + tuple(c for c in COUNTRIES
                                           if c != _LAST_COUNTRY[0])

    last_err = ""
    for country in order:
        try:
            rows = _all_rows(keyword, country)
        except Exception as e:
            last_err = "%s：%s" % (country, e)
            continue
        if not rows:
            continue
        part = rows[start:start + limit]
        if not part:
            if page > 1:
                # 这个店就这么多，别再换店重复了
                return {"rows": [], "page": page, "has_more": False,
                        "country": country, "error": "没有下一页了"}
            continue
        if page == 1:
            _LAST_COUNTRY[0] = country
        return {"rows": part, "page": page,
                "has_more": (start + limit) < len(rows),
                "country": country, "error": ""}
    return {"rows": [], "page": page, "has_more": False, "country": "",
            "error": last_err or "这个关键词没搜到（换个写法试试，比如只写歌名）"}
