# -*- coding: utf-8 -*-
"""启动器内聊天内核：私聊 + 群聊，不靠自建后端，用公共中转（ntfy）传消息。

私聊：把「我 + 对方」两个账号名排序后取哈希当频道名，双方算出同一个频道。
群聊：群号（一串短 ID）哈希当频道名，知道群号的人就在同一个群里。
别人算不出频道名，也就看不到你们聊的内容；但内容确实经过第三方中转，
明文传输，不要拿它发密码一类的东西。

每条消息会捎带一个 32×32 的头像（base64），这样两边都不用额外下载就能看到头像。
本地另存一份 jsonl，断网也能翻历史；启动器一开就后台轮询，
所以两个人都没进游戏、只要开着启动器就能互相说话。
"""
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request

from core import avatar

BASE = "https://ntfy.sh"
UA = "OMC/1.0"
SALT = "omc-chat-v1"
GROUP_SALT = "omc-group-v1"
TIMEOUT = 10
MAX_TEXT = 2400        # ntfy 单条上限 4KB，留给头像和字段余量
POLL_SINCE = "12h"
INBOX_SINCE = "2h"


# ---------- 频道 ----------
def _key(me, peer):
    pair = sorted([(me or "").strip().lower(), (peer or "").strip().lower()])
    raw = (SALT + "|" + "|".join(pair)).encode("utf-8")
    return hashlib.md5(raw).hexdigest()[:12]


def topic(me, peer):
    return "omc-chat-" + _key(me, peer)


def group_key(gid):
    raw = (GROUP_SALT + "|" + (gid or "").strip().lower()).encode("utf-8")
    return hashlib.md5(raw).hexdigest()[:12]


def group_topic(gid):
    return "omc-grp-" + group_key(gid)


def _dir():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def _chat_dir():
    d = os.path.join(_dir(), "chat")
    os.makedirs(d, exist_ok=True)
    return d


def log_path(me, peer):
    return os.path.join(_chat_dir(), _key(me, peer) + ".jsonl")


def group_log_path(gid):
    return os.path.join(_chat_dir(), "g-" + group_key(gid) + ".jsonl")


# ---------- 群 ----------
def groups_all():
    p = os.path.join(_dir(), "groups.json")
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("groups", [])
            return data
    except Exception:
        pass
    return {"groups": []}


def _save_groups(data):
    p = os.path.join(_dir(), "groups.json")
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def group_list():
    return groups_all().get("groups") or []


def group_add(gid, title="", members=()):
    """加一个群（知道自己群号就能进）。"""
    gid = (gid or "").strip()[:40]
    if not gid:
        return False, "群号是空的"
    data = groups_all()
    for g in data["groups"]:
        if (g.get("id") or "") == gid:
            g["title"] = (title or g.get("title") or gid)[:40]
            _save_groups(data)
            return True, "已更新这个群"
    data["groups"].append({"id": gid, "title": (title or gid)[:40],
                           "members": [str(m)[:32] for m in list(members)][:60],
                           "added": int(time.time())})
    _save_groups(data)
    return True, ""


def group_remove(gid):
    data = groups_all()
    data["groups"] = [g for g in data["groups"] if (g.get("id") or "") != gid]
    _save_groups(data)


def new_group_id():
    return hashlib.md5(
        (str(time.time()) + os.urandom(8).hex()).encode("utf-8")).hexdigest()[:10]


# ---------- 收发 ----------
def _msg_id(from_, ts, text):
    h = hashlib.md5((text or "").encode("utf-8")).hexdigest()[:8]
    return "%s|%s|%s" % (ts, from_, h)


def _append(path, from_, text, ts=None, av=""):
    ts = int(ts or time.time())
    rec = {"f": str(from_)[:32], "m": str(text)[:MAX_TEXT], "ts": ts}
    if av:
        rec["av"] = av
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return rec


def append_local(me, peer, from_, text, ts=None, av=""):
    return _append(log_path(me, peer), from_, text, ts, av)


def _read(path):
    out = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                if not rec.get("m"):
                    continue
                frm = rec.get("f") or ""
                ts = int(rec.get("ts") or 0)
                out.append({"from": frm, "text": rec.get("m") or "", "ts": ts,
                            "av": rec.get("av") or "",
                            "id": _msg_id(frm, ts, rec.get("m") or "")})
    except Exception:
        pass
    return out


def read_local(me, peer):
    return _read(log_path(me, peer))


def group_read_local(gid):
    return _read(group_log_path(gid))


def _post(tp, payload, timeout=TIMEOUT):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BASE + "/" + tp, data=body, method="POST",
        # HTTP 头只能 ASCII，账号名可能是中文，标题固定英文，名字放正文
        headers={"Title": "OMC", "User-Agent": UA,
                 "Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return 200 <= r.getcode() < 300


def send(me, peer, text, timeout=TIMEOUT, with_avatar=True):
    """私聊发一条，同时写进本地历史。返回 (ok, 说明)。"""
    me = (me or "").strip()
    peer = (peer or "").strip()
    text = (text or "").strip()
    if not me or not peer:
        return False, "还没选好友"
    if not text:
        return False, "没写内容"
    text = text[:MAX_TEXT]
    av = avatar.mini_b64(me) if with_avatar else ""
    payload = {"t": "chat", "f": me, "s": peer, "m": text}
    if av:
        payload["av"] = av
    try:
        _post(topic(me, peer), payload, timeout=timeout)
    except Exception as e:
        return False, "没发出去：%s" % e
    append_local(me, peer, me, text, av=av)
    return True, ""


def send_group(me, gid, text, timeout=TIMEOUT, with_avatar=True):
    me = (me or "").strip()
    gid = (gid or "").strip()
    text = (text or "").strip()
    if not me:
        return False, "还没登录"
    if not gid:
        return False, "还没选群"
    if not text:
        return False, "没写内容"
    text = text[:MAX_TEXT]
    av = avatar.mini_b64(me) if with_avatar else ""
    payload = {"t": "grp", "g": gid, "f": me, "m": text}
    if av:
        payload["av"] = av
    try:
        _post(group_topic(gid), payload, timeout=timeout)
    except Exception as e:
        return False, "没发出去：%s" % e
    _append(group_log_path(gid), me, text, av=av)
    return True, ""


def _pull(tp, kind, since, timeout, allow=None):
    """从频道拉消息。allow 是允许的发言者名字集合（小写），None 表示不限。"""
    q = urllib.parse.urlencode({"poll": "1", "since": since})
    url = "%s/%s/json?%s" % (BASE, tp, q)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
    except Exception:
        return []
    out = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception:
            continue
        if item.get("event") and item.get("event") != "message":
            continue
        try:
            p = json.loads(item.get("message") or "{}")
        except Exception:
            continue
        if p.get("t") != kind:
            continue
        text = p.get("m") or ""
        frm = str(p.get("f") or "").strip()
        if not text or not frm:
            continue
        if allow is not None and frm.lower() not in allow:
            continue
        av = str(p.get("av") or "")
        if av:
            avatar.save_remote(frm, av)
        ts = int(p.get("ts") or item.get("time") or 0)
        out.append({"from": frm, "text": text[:MAX_TEXT], "ts": ts, "av": av,
                    "id": _msg_id(frm, ts, text)})
    return out


def fetch_remote(me, peer, since=POLL_SINCE, timeout=TIMEOUT):
    names = {(me or "").strip().lower(), (peer or "").strip().lower()}
    return _pull(topic(me, peer), "chat", since, timeout, allow=names)


def fetch_group(gid, since=POLL_SINCE, timeout=TIMEOUT, members=None):
    allow = None
    if members:
        allow = {str(m).strip().lower() for m in members}
    return _pull(group_topic(gid), "grp", since, timeout, allow=allow)


def _merge(path, me, remote):
    local = _read(path)
    seen = {m["id"] for m in local}
    added = 0
    for m in remote:
        if m["id"] in seen:
            continue
        seen.add(m["id"])
        local.append(m)
        _append(path, m["from"], m["text"], m["ts"], m.get("av") or "")
        added += 1
    local.sort(key=lambda m: m["ts"])
    return local, added


def history(me, peer, since=POLL_SINCE, timeout=TIMEOUT, use_net=True):
    remote = fetch_remote(me, peer, since=since, timeout=timeout) if use_net else []
    local, _add = _merge(log_path(me, peer), me, remote)
    return local


def group_history(gid, since=POLL_SINCE, timeout=TIMEOUT, use_net=True, members=None):
    remote = (fetch_group(gid, since=since, timeout=timeout, members=members)
              if use_net else [])
    local, _add = _merge(group_log_path(gid), "", remote)
    return local


def unread_hint(me, peer, since=INBOX_SINCE):
    """好友页用：对方发来还没读过的条数。"""
    before = sum(1 for m in read_local(me, peer)
                 if m["from"].lower() != (me or "").lower())
    msgs = fetch_remote(me, peer, since=since)
    now = sum(1 for m in msgs if m["from"].lower() != (me or "").lower())
    return max(0, now - before)


# ---------- 后台常驻收信 ----------
def sync_inbox(me, peers=(), gids=(), since=INBOX_SINCE):
    """把好友私聊 + 群消息都拉一遍存本地，返回 {名字或群号: 新条数}。

    启动器后台定时调它，这样双方都不进游戏、只开启动器也能收到消息。
    """
    me = (me or "").strip()
    added = {}
    if not me:
        return added
    for peer in list(peers or ())[:80]:
        peer = (peer or "").strip()
        if not peer or peer.lower() == me.lower():
            continue
        try:
            remote = fetch_remote(me, peer, since=since)
        except Exception:
            continue
        if not remote:
            continue
        _local, n = _merge(log_path(me, peer), me, remote)
        if n:
            added[peer] = added.get(peer, 0) + n
    for gid in list(gids or ())[:40]:
        try:
            remote = fetch_group(gid, since=since)
        except Exception:
            continue
        if not remote:
            continue
        _local, n = _merge(group_log_path(gid), "", remote)
        if n:
            added[gid] = added.get(gid, 0) + n
    return added
