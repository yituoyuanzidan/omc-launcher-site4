# -*- coding: utf-8 -*-
"""启动器内聊天内核：私聊 + 群聊，不靠自建后端，用公共中转（ntfy）传消息。

私聊：把「我 + 对方」两个账号名排序后取哈希当频道名，双方算出同一个频道。
群聊：群号（一串短 ID）哈希当频道名，知道群号的人就在同一个群里。
别人算不出频道名，也就看不到你们聊的内容；但内容确实经过第三方中转，
明文传输，不要拿它发密码一类的东西。

每条消息会捎带一个 32×32 的头像（base64），这样两边都不用额外下载就能看到头像。
本地另存一份 jsonl，断网也能翻历史；启动器一开就后台轮询，
所以两个人都没进游戏、只要开着启动器就能互相说话。
"""
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request

from core import avatar
from core import wordfilter as _wf

BASE = "https://ntfy.sh"
UA = "OMC/1.0"
SALT = "omc-chat-v1"
GROUP_SALT = "omc-group-v1"
TIMEOUT = 10
MAX_TEXT = 2400        # ntfy 单条上限 4KB，留给头像和字段余量
POLL_SINCE = "12h"
INBOX_SINCE = "2h"


# ---------- 频道 ----------
def _key(me, peer):
    pair = sorted([(me or "").strip().lower(), (peer or "").strip().lower()])
    raw = (SALT + "|" + "|".join(pair)).encode("utf-8")
    return hashlib.md5(raw).hexdigest()[:12]


def topic(me, peer):
    return "omc-chat-" + _key(me, peer)


def group_key(gid):
    raw = (GROUP_SALT + "|" + (gid or "").strip().lower()).encode("utf-8")
    return hashlib.md5(raw).hexdigest()[:12]


def group_topic(gid):
    return "omc-grp-" + group_key(gid)


def _dir():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def _chat_dir():
    d = os.path.join(_dir(), "chat")
    os.makedirs(d, exist_ok=True)
    return d


def log_path(me, peer):
    return os.path.join(_chat_dir(), _key(me, peer) + ".jsonl")


def group_log_path(gid):
    return os.path.join(_chat_dir(), "g-" + group_key(gid) + ".jsonl")


# ---------- 违禁词开关（设置页控制，默认开） ----------
_FILTER = [True]


def set_filter(on):
    _FILTER[0] = bool(on)


def _filter_on():
    return _FILTER[0]


# ---------- 群 ----------
def groups_all():
    p = os.path.join(_dir(), "groups.json")
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("groups", [])
            return data
    except Exception:
        pass
    return {"groups": []}


def _save_groups(data):
    p = os.path.join(_dir(), "groups.json")
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def group_list():
    return groups_all().get("groups") or []


def group_add(gid, title="", members=(), owner=""):
    """加一个群（知道自己群号就能进）。owner 是建群的人（群主）。"""
    gid = (gid or "").strip()[:40]
    if not gid:
        return False, "群号是空的"
    data = groups_all()
    now = int(time.time())
    for g in data["groups"]:
        if (g.get("id") or "") == gid:
            g["title"] = (title or g.get("title") or gid)[:40]
            if owner and not g.get("owner"):
                g["owner"] = str(owner)[:32]
            cur = list(g.get("members") or [])
            for m in list(members or ()):
                m = str(m)[:32]
                if m and m not in cur:
                    cur.append(m)
            g["members"] = cur[:80]
            _save_groups(data)
            return True, "已更新这个群"
    data["groups"].append({"id": gid, "title": (title or gid)[:40],
                           "members": [str(m)[:32] for m in list(members)][:80],
                           "owner": str(owner or "")[:32],
                           "muted": [], "added": now})
    _save_groups(data)
    return True, ""


def group_get(gid):
    for g in group_list():
        if (g.get("id") or "") == gid:
            return g
    return {}


def _group_patch(gid, **kw):
    data = groups_all()
    for g in data["groups"]:
        if (g.get("id") or "") == gid:
            g.update(kw)
            _save_groups(data)
            return g
    return {}


def group_role(gid, name):
    """群里的身份：群主 / 管理员 / 成员。"""
    g = group_get(gid)
    name = (name or "").strip().lower()
    if not g or not name:
        return "member"
    if (g.get("owner") or "").strip().lower() == name:
        return "owner"
    if name in {(a or "").strip().lower() for a in (g.get("admins") or [])}:
        return "admin"
    return "member"


def group_member_add(gid, name):
    g = group_get(gid)
    if not g:
        return
    cur = list(g.get("members") or [])
    name = (name or "").strip()[:32]
    if name and name not in cur:
        cur.append(name)
        _group_patch(gid, members=cur[:80])


def group_member_del(gid, name):
    g = group_get(gid)
    if not g:
        return
    cur = [(m or "") for m in (g.get("members") or [])
           if (m or "").strip().lower() != (name or "").strip().lower()]
    _group_patch(gid, members=cur)


def group_kick(gid, name):
    """踢人：先从成员里删掉，再把事件广播给群里其他端。"""
    group_member_del(gid, name)
    _post(group_topic(gid), {"t": "gmgr", "g": gid, "act": "kick",
                             "who": (name or "").strip(),
                             "by": _me_hint(gid), "m": ""})
    return True, ""


def group_mute(gid, name, minutes=10):
    """禁言某人 minutes 分钟（0 表示解除）。"""
    g = group_get(gid) or {}
    muted = [m for m in (g.get("muted") or [])
             if (m.get("name") or "").strip().lower()
             != (name or "").strip().lower()]
    if minutes and int(minutes) > 0:
        muted.append({"name": (name or "").strip(),
                      "until": int(time.time()) + int(minutes) * 60,
                      "min": int(minutes)})
    _group_patch(gid, muted=muted)
    _post(group_topic(gid), {"t": "gmgr", "g": gid,
                             "act": "mute" if minutes else "unmute",
                             "who": (name or "").strip(),
                             "min": int(minutes or 0), "by": _me_hint(gid),
                             "m": ""})
    return True, ""


def _me_hint(gid):
    """广播管理事件时捎上操作者名字（后台线程没有上下文，取群主名兜底）。"""
    g = group_get(gid) or {}
    return (g.get("owner") or "") or "群主"


def mute_left(gid, name):
    """还剩多少秒被禁言（0 表示能说话）。"""
    g = group_get(gid) or {}
    name = (name or "").strip().lower()
    for m in (g.get("muted") or []):
        if (m.get("name") or "").strip().lower() == name:
            left = int(m.get("until") or 0) - int(time.time())
            return max(0, left)
    return 0


def apply_mgr(gid, ev):
    """收到别人的管理事件，更新本地群信息。"""
    act = (ev.get("act") or "").lower()
    who = (ev.get("who") or "").strip()
    if not who:
        return
    if act == "kick":
        group_member_del(gid, who)
    elif act == "mute":
        g = group_get(gid) or {}
        muted = [m for m in (g.get("muted") or [])
                 if (m.get("name") or "").lower() != who.lower()]
        muted.append({"name": who,
                      "until": int(time.time()) + int(ev.get("min") or 10) * 60,
                      "min": int(ev.get("min") or 10)})
        _group_patch(gid, muted=muted)
    elif act == "unmute":
        g = group_get(gid) or {}
        muted = [m for m in (g.get("muted") or [])
                 if (m.get("name") or "").lower() != who.lower()]
        _group_patch(gid, muted=muted)


def group_remove(gid):
    data = groups_all()
    data["groups"] = [g for g in data["groups"] if (g.get("id") or "") != gid]
    _save_groups(data)


def new_group_id():
    return hashlib.md5(
        (str(time.time()) + os.urandom(8).hex()).encode("utf-8")).hexdigest()[:10]


# ---------- 收发 ----------
def _msg_id(from_, ts, text):
    h = hashlib.md5((text or "").encode("utf-8")).hexdigest()[:8]
    return "%s|%s|%s" % (ts, from_, h)


def _append(path, from_, text, ts=None, av="", at=None):
    ts = int(ts or time.time())
    rec = {"f": str(from_)[:32], "m": str(text)[:MAX_TEXT], "ts": ts}
    if av:
        rec["av"] = av
    if at:
        rec["at"] = [str(x)[:32] for x in at][:20]
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return rec


def append_local(me, peer, from_, text, ts=None, av=""):
    return _append(log_path(me, peer), from_, text, ts, av)


def _read(path):
    out = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                if not rec.get("m"):
                    continue
                frm = rec.get("f") or ""
                ts = int(rec.get("ts") or 0)
                out.append({"from": frm, "text": rec.get("m") or "", "ts": ts,
                            "av": rec.get("av") or "",
                            "at": list(rec.get("at") or []),
                            "id": _msg_id(frm, ts, rec.get("m") or "")})
    except Exception:
        pass
    return out


# ---------- @ ----------
def parse_mentions(text, members=(), extra=()):
    """从一段话里认出被 @ 的人。

    群成员名单可能不全（各端只记自己见过的），所以除了按名单匹配，
    也认 `@名字` 这种写法本身：@ 后面紧跟一串非空白字符，去掉 @ 就是名字。
    名字按长度从长到短匹配，免得「@小矿二号」被当成「@小矿」。
    """
    body = str(text or "")
    names = [str(m).strip() for m in list(members or ()) + list(extra or ())]
    names = [n for n in names if n and n not in ("所有人", "全体成员", "all")]
    # 名单里有的，按长度倒序精确匹配
    for n in sorted(set(names), key=len, reverse=True):
        if "@" + n in body:
            return [n], "all"
    # 名单里没有：按 @ 后面的连续字符猜一个
    import re
    m = re.search(r"@([^\s@,，。:：!！?？]{1,16})", body)
    if m:
        return [m.group(1)], "guess"
    if "@所有人" in body or "@全体成员" in body:
        return [], "all"
    return [], ""


def at_me(msg, me):
    """这条消息是不是 @ 了我。"""
    me = (me or "").strip().lower()
    if not me or not msg:
        return False
    ats = [str(x).strip().lower() for x in (msg.get("at") or [])]
    return me in ats


def at_all(msg):
    return bool(msg.get("at_all"))


def read_local(me, peer):
    return _read(log_path(me, peer))


def group_read_local(gid):
    return _read(group_log_path(gid))


def _post(tp, payload, timeout=TIMEOUT):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BASE + "/" + tp, data=body, method="POST",
        # HTTP 头只能 ASCII，账号名可能是中文，标题固定英文，名字放正文
        headers={"Title": "OMC", "User-Agent": UA,
                 "Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return 200 <= r.getcode() < 300


def send(me, peer, text, timeout=TIMEOUT, with_avatar=True):
    """私聊发一条，同时写进本地历史。返回 (ok, 说明)。"""
    me = (me or "").strip()
    peer = (peer or "").strip()
    text = (text or "").strip()
    if not me or not peer:
        return False, "还没选好友"
    if not text:
        return False, "没写内容"
    text = text[:MAX_TEXT]
    filt = False
    if _filter_on():
        filt, text = _wf.check(text)
    av = avatar.mini_b64(me) if with_avatar else ""
    payload = {"t": "chat", "f": me, "s": peer, "m": text}
    if av:
        payload["av"] = av
    try:
        _post(topic(me, peer), payload, timeout=timeout)
    except Exception as e:
        return False, "没发出去：%s" % e
    append_local(me, peer, me, text, av=av)
    return True, ("已发送（%d 处违禁词被替换）" % 1) if filt else ""


def send_group(me, gid, text, timeout=TIMEOUT, with_avatar=True, ats=None):
    me = (me or "").strip()
    gid = (gid or "").strip()
    text = (text or "").strip()
    if not me:
        return False, "还没登录"
    if not gid:
        return False, "还没选群"
    if not text:
        return False, "没写内容"
    left = mute_left(gid, me)
    if left > 0:
        return False, "你被群主禁言了，还有 %d 秒" % left
    text = text[:MAX_TEXT]
    # @ 名单：调用方给了就用，没给就从正文里认
    at = [str(x).strip()[:32] for x in list(ats or ()) if str(x).strip()]
    at_all_it = ("@所有人" in text) or ("@全体成员" in text)
    if not at:
        members = (group_get(gid) or {}).get("members") or []
        found, _mode = parse_mentions(text, members)
        at = [x for x in found if x.lower() != me.lower()]
    filt = False
    if _filter_on():
        filt, text = _wf.check(text)
    av = avatar.mini_b64(me) if with_avatar else ""
    payload = {"t": "grp", "g": gid, "f": me, "m": text}
    if av:
        payload["av"] = av
    if at:
        payload["at"] = at[:20]
    if at_all_it:
        payload["atall"] = 1
    try:
        _post(group_topic(gid), payload, timeout=timeout)
    except Exception as e:
        return False, "没发出去：%s" % e
    _append(group_log_path(gid), me, text, av=av, at=at if not at_all_it else [])
    group_member_add(gid, me)
    return True, "已发送（有违禁词被替换了）" if filt else ""


def _pull(tp, kind, since, timeout, allow=None):
    """从频道拉消息。allow 是允许的发言者名字集合（小写），None 表示不限。"""
    q = urllib.parse.urlencode({"poll": "1", "since": since})
    url = "%s/%s/json?%s" % (BASE, tp, q)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
    except Exception:
        return []
    out = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except Exception:
            continue
        if item.get("event") and item.get("event") != "message":
            continue
        try:
            p = json.loads(item.get("message") or "{}")
        except Exception:
            continue
        # 群管理事件（踢人 / 禁言）不是聊天内容，单独处理掉
        if p.get("t") == "gmgr":
            try:
                apply_mgr(str(p.get("g") or ""), p)
            except Exception:
                pass
            continue
        if p.get("t") != kind:
            continue
        text = p.get("m") or ""
        frm = str(p.get("f") or "").strip()
        if not text or not frm:
            continue
        if allow is not None and frm.lower() not in allow:
            continue
        if _filter_on():
            _hit, text = _wf.check(text)
        av = str(p.get("av") or "")
        if av:
            avatar.save_remote(frm, av)
        ts = int(p.get("ts") or item.get("time") or 0)
        at = [str(x)[:32] for x in (p.get("at") or [])][:20]
        out.append({"from": frm, "text": text[:MAX_TEXT], "ts": ts, "av": av,
                    "at": at, "at_all": bool(p.get("atall")),
                    "id": _msg_id(frm, ts, text)})
    return out


def fetch_remote(me, peer, since=POLL_SINCE, timeout=TIMEOUT):
    names = {(me or "").strip().lower(), (peer or "").strip().lower()}
    return _pull(topic(me, peer), "chat", since, timeout, allow=names)


def fetch_group(gid, since=POLL_SINCE, timeout=TIMEOUT, members=None,
                strict=False):
    """拉群消息。

    默认不做成员过滤：群成员名单是各端本地记的，把别人的名字记全之前按名单过滤，
    会把自己以外的人说的话全丢掉 —— 表现就是「进了群却一句都看不到」。
    strict=True 时才只看名单里的人。
    """
    allow = None
    if strict and members:
        allow = {str(m).strip().lower() for m in members}
    return _pull(group_topic(gid), "grp", since, timeout, allow=allow)


def _merge(path, me, remote):
    local = _read(path)
    seen = {m["id"] for m in local}

    def near(m):
        """同一个人、同一段话、时间差 90 秒内，就算同一条。

        本地写入用的是本机时间，中转回来的是服务器时间，两边能差一两秒；
        只按 id 去重会让「我自己刚发的那句话」在界面上出现两遍。
        """
        key = ((m.get("from") or "").lower(), m.get("text") or "")
        for x in local:
            if ((x.get("from") or "").lower(), x.get("text") or "") != key:
                continue
            if abs(int(x.get("ts") or 0) - int(m.get("ts") or 0)) <= 90:
                return True
        return False

    added = 0
    for m in remote:
        if m["id"] in seen:
            continue
        if near(m):
            seen.add(m["id"])
            continue
        seen.add(m["id"])
        local.append(m)
        _append(path, m["from"], m["text"], m["ts"], m.get("av") or "",
                m.get("at") or [])
        added += 1
    local.sort(key=lambda m: m["ts"])
    return local, added


def history(me, peer, since=POLL_SINCE, timeout=TIMEOUT, use_net=True):
    remote = fetch_remote(me, peer, since=since, timeout=timeout) if use_net else []
    local, _add = _merge(log_path(me, peer), me, remote)
    return local


def group_history(gid, since=POLL_SINCE, timeout=TIMEOUT, use_net=True, members=None):
    remote = (fetch_group(gid, since=since, timeout=timeout, members=members)
              if use_net else [])
    local, _add = _merge(group_log_path(gid), "", remote)
    return local


def unread_hint(me, peer, since=INBOX_SINCE):
    """好友页用：对方发来还没读过的条数。"""
    before = sum(1 for m in read_local(me, peer)
                 if m["from"].lower() != (me or "").lower())
    msgs = fetch_remote(me, peer, since=since)
    now = sum(1 for m in msgs if m["from"].lower() != (me or "").lower())
    return max(0, now - before)


# ---------- 后台常驻收信 ----------
def sync_inbox(me, peers=(), gids=(), since=INBOX_SINCE):
    """把好友私聊 + 群消息都拉一遍存本地，返回 {名字或群号: 新条数}。

    启动器后台定时调它，这样双方都不进游戏、只开启动器也能收到消息。
    """
    me = (me or "").strip()
    added = {}
    if not me:
        return added
    for peer in list(peers or ())[:80]:
        peer = (peer or "").strip()
        if not peer or peer.lower() == me.lower():
            continue
        try:
            remote = fetch_remote(me, peer, since=since)
        except Exception:
            continue
        if not remote:
            continue
        _local, n = _merge(log_path(me, peer), me, remote)
        if n:
            added[peer] = added.get(peer, 0) + n
    for gid in list(gids or ())[:40]:
        try:
            remote = fetch_group(gid, since=since)
        except Exception:
            continue
        if not remote:
            continue
        _local, n = _merge(group_log_path(gid), "", remote)
        if n:
            added[gid] = added.get(gid, 0) + n
    return added
