# -*- coding: utf-8 -*-
"""配置持久化：保存在用户目录下，与游戏目录分离。

几条保命规则（升级/替换程序目录都不该丢设置）：
1. 配置放在用户目录，不放程序目录 —— 换新包解压到别的地方也读得到。
2. 保存用「先写临时文件、再原子替换」，断电/被强杀不会写出半截 JSON。
3. 每次保存前把上一份完整的 config.json 复制成 config.json.bak；
   主文件读坏了自动从 .bak 或历史快照恢复，不让用户白丢一遍设置。
4. 版本号变了（升级后第一次启动）自动把旧配置存一份快照到 config_backups/，
   保留最近 8 份，界面上随时能一键恢复。
"""
import glob
import json
import os
import shutil
import time

DEFAULT_CONFIG = {
    "username": "Player",
    "java_path": "",
    "java_auto": True,        # 全自动：按所选版本要的 Java 自动切换，缺了就自己下
    "game_dir": "",
    "memory_mb": 4096,
    "mirror": "official",     # official = 官方源, bmcl = 国内镜像
    "account_mode": "offline",  # offline = 离线, msa = 正版
    "last_version": "",
    "extra_jvm_args": "",
    "language": "zh_CN",      # 界面与游戏默认语言
    "background_image": "",   # 自定义背景图，空=默认深色
    "auto_backup": True,      # 启动游戏前自动备份存档
    "backup_keep": 5,         # 每个存档保留最近几份备份
    "jvm_template": "none",   # JVM 参数模板
    "multi_instance": False,  # 允许同一个版本同时开多个游戏进程
    "minimize_to_tray": False,  # 关闭窗口时缩到托盘而不是退出
}

VERSION_KEY = "_app_version"
KEEP_BACKUPS = 8


def app_dir():
    """配置目录：按系统规范走（Windows/Linux 用 ~/.simple_mc_launcher，macOS 用 Library）。"""
    from . import platform_utils
    return platform_utils.data_dir()


CONFIG_PATH = os.path.join(app_dir(), "config.json")
BAK_PATH = CONFIG_PATH + ".bak"
BACKUP_DIR = os.path.join(app_dir(), "config_backups")


def _load_json(path):
    """读一份 json；读不出来就返回 None，绝不抛异常打断启动。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return None
    return d if isinstance(d, dict) else None


def current_version():
    try:
        from . import update
        return str(update.VERSION or "")
    except Exception:
        return ""


def list_backups():
    """已有快照，新的在前。"""
    try:
        items = glob.glob(os.path.join(BACKUP_DIR, "config-*.json"))
    except Exception:
        return []
    paths = [p for p in items if os.path.isfile(p)]
    paths.sort(key=lambda p: -os.path.getmtime(p))
    return paths


def _trim_backups():
    for p in list_backups()[KEEP_BACKUPS:]:
        try:
            os.remove(p)
        except Exception:
            pass


class Config(object):
    def __init__(self, version=""):
        self.data = dict(DEFAULT_CONFIG)
        self.recovered = ""   # 本次是从哪儿捞回来的（.bak / 快照），供界面或日志说明
        self.snapshot = ""    # 升级时自动留的快照路径
        self._dirty = False   # set 过之后还没写盘（外面有个定时器盯着它兜底）
        raw = None
        if os.path.exists(CONFIG_PATH):
            raw = _load_json(CONFIG_PATH)
            if raw is None:
                # 主文件坏了：先找 .bak，再找最近的快照
                bak = _load_json(BAK_PATH)
                if bak is not None:
                    raw, self.recovered = bak, BAK_PATH
                else:
                    for p in list_backups():
                        d = _load_json(p)
                        if d is not None:
                            raw, self.recovered = d, p
                            break
        if raw:
            self.data.update(raw)
        if not self.data.get("game_dir"):
            self.data["game_dir"] = os.path.join(os.path.expanduser("~"),
                                                 ".minecraft")

        # 升级后第一次启动：把旧配置留一份快照，再把新版本号写进去
        ver = version or current_version()
        if os.path.exists(CONFIG_PATH) and raw is not None:
            old = str(self.data.get(VERSION_KEY) or "")
            if ver and old != ver:
                self.snapshot = self._snapshot(old or "旧版")
                self.data[VERSION_KEY] = ver
                try:
                    self.save()
                except Exception:
                    pass

    # ---------- 读改存 ----------
    def get(self, key):
        return self.data.get(key)

    def set(self, key, value):
        self.data[key] = value
        # 记成「还没写盘」：以前很多地方 set 完忘了 save()，用户改的东西
        # 重启/更新之后又变回默认，看着就像「设置被重置」。主窗里有个定时器
        # 会调用 flush()，把漏掉的这些统一补上。
        self._dirty = True

    def dirty(self):
        return bool(self._dirty)

    def flush(self):
        """有没写盘的改动就写一次。返回是否真的写了。"""
        if not self._dirty:
            return False
        try:
            self.save()
            return True
        except Exception:
            return False

    def save(self):
        folder = os.path.dirname(CONFIG_PATH)
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass
        tmp = CONFIG_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        # 只有主文件此刻还是好的，才把它存成 .bak，坏文件别去污染备份
        try:
            if _load_json(CONFIG_PATH) is not None:
                shutil.copy2(CONFIG_PATH, BAK_PATH)
        except Exception:
            pass
        os.replace(tmp, CONFIG_PATH)
        self._dirty = False

    # ---------- 快照 / 备份 / 恢复 ----------
    def _snapshot(self, tag=""):
        if not os.path.exists(CONFIG_PATH):
            return ""
        try:
            os.makedirs(BACKUP_DIR, exist_ok=True)
            name = "config-%s-%s.json" % (
                (tag or "backup").replace(" ", ""),
                time.strftime("%Y%m%d-%H%M%S"))
            dst = os.path.join(BACKUP_DIR, name)
            shutil.copy2(CONFIG_PATH, dst)
            _trim_backups()
            return dst
        except Exception:
            return ""

    def backup(self, tag="manual"):
        """立刻备份当前配置，返回路径（失败返回空串）。"""
        return self._snapshot(tag)

    def restore(self, path):
        """用某份 json 覆盖当前设置；成功返回 True。"""
        d = _load_json(path)
        if d is None:
            return False
        keep = self.data.get(VERSION_KEY)
        self.data = dict(DEFAULT_CONFIG)
        self.data.update(d)
        if keep:
            self.data[VERSION_KEY] = keep
        if not self.data.get("game_dir"):
            self.data["game_dir"] = os.path.join(os.path.expanduser("~"),
                                                 ".minecraft")
        self.save()
        return True
