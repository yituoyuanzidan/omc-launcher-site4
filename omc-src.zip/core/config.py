# -*- coding: utf-8 -*-
"""配置持久化：保存在用户目录下，与游戏目录分离。"""
import json
import os

DEFAULT_CONFIG = {
    "username": "Player",
    "java_path": "",
    "java_auto": True,        # 全自动：按所选版本要的 Java 自动切换，缺了就自己下
    "game_dir": "",
    "memory_mb": 4096,
    "mirror": "official",     # official = 官方源, bmcl = 国内镜像
    "account_mode": "offline",  # offline = 离线, msa = 正版
    "last_version": "",
    "extra_jvm_args": "",
    "language": "zh_CN",      # 界面与游戏默认语言
    "background_image": "",   # 自定义背景图，空=默认深色
    "auto_backup": True,      # 启动游戏前自动备份存档
    "backup_keep": 5,         # 每个存档保留最近几份备份
    "jvm_template": "none",   # JVM 参数模板
    "multi_instance": False,  # 允许同一个版本同时开多个游戏进程
    "minimize_to_tray": False,  # 关闭窗口时缩到托盘而不是退出
}


def app_dir():
    """配置目录：按系统规范走（Windows/Linux 用 ~/.simple_mc_launcher，macOS 用 Library）。"""
    from . import platform_utils
    return platform_utils.data_dir()


CONFIG_PATH = os.path.join(app_dir(), "config.json")


class Config(object):
    def __init__(self):
        self.data = dict(DEFAULT_CONFIG)
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    self.data.update(json.load(f))
            except Exception:
                pass
        if not self.data.get("game_dir"):
            self.data["game_dir"] = os.path.join(os.path.expanduser("~"), ".minecraft")

    def get(self, key):
        return self.data.get(key)

    def set(self, key, value):
        self.data[key] = value

    def save(self):
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
