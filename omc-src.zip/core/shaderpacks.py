"""光影包（Shaders）管理：目录、列表、导入。

Iris / OptiFine 都支持把 .zip 直接放进 shaderpacks，
也支持「文件夹 + shaders 子目录」的形式，两种都认。
"""
import os
import shutil

from . import platform_utils


def shaderpacks_dir(game_dir):
    return os.path.join(game_dir or "", "shaderpacks")


def _fmt_size(n):
    if n >= 1024 * 1024:
        return "%.1f MB" % (n / 1024.0 / 1024.0)
    if n >= 1024:
        return "%d KB" % (n // 1024)
    return "%d B" % n


def list_shaderpacks(game_dir):
    """返回 [{name, path, is_dir, size_text}]，按名称排序。"""
    d = shaderpacks_dir(game_dir)
    out = []
    if not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        p = os.path.join(d, name)
        if os.path.isdir(p):
            if os.path.isdir(os.path.join(p, "shaders")):
                out.append({"name": name, "path": p, "is_dir": True,
                            "size_text": "文件夹", "icon": b""})
        elif name.lower().endswith(".zip"):
            try:
                size = os.path.getsize(p)
            except OSError:
                size = 0
            out.append({"name": name[:-4], "path": p, "is_dir": False,
                        "size_text": _fmt_size(size), "icon": b""})
    return out


def install_file(path, game_dir, log=None):
    """把 zip 或文件夹装进 shaderpacks，返回目标路径。"""
    d = shaderpacks_dir(game_dir)
    os.makedirs(d, exist_ok=True)
    name = os.path.basename(path.rstrip("\\/"))
    dest = os.path.join(d, name)
    if os.path.abspath(path) == os.path.abspath(dest):
        return dest
    if os.path.isdir(path):
        shutil.copytree(path, dest, dirs_exist_ok=True)
    else:
        shutil.copy2(path, dest)
    if log:
        log("光影已安装：" + os.path.basename(dest))
    return dest


def remove_shaderpack(path, log=None):
    """删除单个光影包（仅供 UI 里的删除按钮调用）。"""
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
        elif os.path.exists(path):
            os.remove(path)
        if log:
            log("已移除光影：" + os.path.basename(path))
        return True
    except OSError as e:
        if log:
            log("移除失败：" + str(e))
        return False


def open_dir(game_dir):
    d = shaderpacks_dir(game_dir)
    os.makedirs(d, exist_ok=True)
    platform_utils.open_path(d)
