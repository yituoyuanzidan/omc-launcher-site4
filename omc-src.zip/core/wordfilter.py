# -*- coding: utf-8 -*-
"""聊天违禁词过滤（默认打开，可在设置里关）。

只做本地遮盖，不上报、不联网。
- 脏话 / 人身攻击
- 色情露骨词
- 诈骗与引流（免费送、加微信、扫码领、私聊返利之类）
- 违法交易（代练代充、卖号、外挂、赌博）
命中的字用 * 替换，保留长度，聊天记录里也能一眼看出被过滤了。
"""
import re

WORDS = [
    # 脏话 / 攻击
    "傻逼", "傻b", "沙比", "煞笔", "蠢货", "废物", "滚你妈的", "草泥马",
    "操你妈", "你妈的", "去死吧", "死全家", "贱人", "婊子", "杂种", "狗东西",
    "脑残", "智障", "弱智", "nmsl", "cnm", "tmd", "sb",
    # 色情
    "色情", "黄色网站", "裸聊", "约炮", "一夜情", "做爱", "口交", "自慰",
    "成人视频", "黄片", "av片", "嫖娼", "情趣用品",
    # 诈骗 / 引流
    "加我微信", "扫码领", "免费领取皮肤", "免费送皮肤", "代充", "代练",
    "刷钻", "刷qb", "返利", "投资稳赚", "日赚", "兼职刷单", "内部渠道",
    "先交钱", "押金", "解冻费", "账号被骗", "官方客服让你",
    # 违法 / 危险
    "卖号", "租号", "外挂", "透视", "自瞄", "赌博", "博彩", "洗钱",
    "毒品", "冰毒", "枪支", "炸药", "自制炸弹",
]

# 用正则做一次编译，长词优先，避免「傻逼」被「傻」先吃掉
_PATTERN = None


def _pattern():
    global _PATTERN
    if _PATTERN is None:
        parts = sorted({w.lower() for w in WORDS}, key=len, reverse=True)
        _PATTERN = re.compile("|".join(re.escape(p) for p in parts),
                              re.IGNORECASE)
    return _PATTERN


def hit(text):
    """返回命中的词（没有就空串）。"""
    t = str(text or "")
    if not t:
        return ""
    m = _pattern().search(t)
    return m.group(0) if m else ""


def mask(text, star="＊"):
    """把命中的词换成星号，长度不变。"""
    t = str(text or "")
    if not t:
        return t

    def rep(m):
        return star * len(m.group(0))

    return _pattern().sub(rep, t)


def check(text):
    """(是否命中, 遮盖后的文本)。"""
    w = hit(text)
    if not w:
        return False, str(text or "")
    return True, mask(text)


def enabled(config):
    """设置项关闭时才不过滤；没这个键就是默认开。"""
    try:
        v = config.get("filter_chat_words")
    except Exception:
        return True
    if v is None:
        return True
    return bool(v)
