# -*- coding: utf-8 -*-
"""让 AI 好友说话：系统自带语音合成 + 变调声线。

试过的东西记在这里，免得以后又走回头路：
- SAPI 的 SSML `<prosody pitch="+35%">` **实测无效**：三段 wav 长度一模一样、过零率只差
  3% 以内（_tts_probe.txt）。所以音调只能靠自己重采样变调，pitch 这条路不走了。
- SSML 的 rate 有效，`<break time="…"/>` 也有效。**停顿才是「像人」的关键**：以前一句
  话一口气念完，听感像机器报站；现在按标点断句、句号后停 240ms、逗号后停 120ms，
  曼波那种一顿一顿的腔调就是这么来的。
- 变调用 Catmull-Rom 三次插值（线性插值会抽点抽出一堆锯齿，听起来沙哑），升调后再过
  一道二阶低通压掉混叠，最后把峰值归一到 0.9 满量程——以前 gain 没补，声音又闷又小。
- 变调幅度收着点：超过 1.25 倍就没法听了，宁可让 rate 帮忙。
不联网、不常驻，念完就把临时文件删掉。
"""
import base64
import json
import os
import random
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import wave

_LOCK = threading.Lock()

# WinRT（OneCore 音色）只有 Windows PowerShell 5.1 能加载：pwsh 7 跑在 .NET Core 上，
# `[Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media, ContentType=WindowsRuntime]`
# 直接报 "Unable to find type"，于是音色探查永远返回 0 个、合成退回 SAPI5 的老音库，
# 一句短话就要 1.5 秒。所以 WinRT 这条路固定用系统自带的 powershell.exe。
_PS51 = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


def _ps_winrt():
    """跑 WinRT / System.Speech 用哪个解释器：Windows 上固定 5.1，其它平台退回 _ps()。"""
    if os.name == "nt" and os.path.isfile(_PS51):
        return _PS51
    return _ps()


# 常驻合成进程：加载一次 WinRT 与音色，之后每条只做「读一行 → 合成 → 回 OK」。
# 每句都新起一个 powershell.exe 的话，光进程冷启动和 Add-Type 就要 600~900 毫秒，
# 这就是「小矿半天不开口」的主要来处。协议（每行一个，UTF-8，制表符分隔）：
#   VOICE\t音色名 → OK / ERR voice
#   SAY\t输出wav路径\tSSML 的 base64 → OK / ERR 说明
#   QUIT → 退出
_DAEMON_PS = r'''$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) {
  $m = $asTask.MakeGenericMethod($type)
  $t = $m.Invoke($null, @($op))
  [void]$t.Wait(-1)
  $t.Result
}
$syn = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
[Console]::Out.WriteLine("READY")
[Console]::Out.Flush()
while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line -or $line -eq "QUIT") { break }
  $f = $line.Split("`t")
  if ($f.Count -lt 2) { [Console]::Out.WriteLine("ERR"); [Console]::Out.Flush(); continue }
  if ($f[0] -eq "VOICE") {
    $pick = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices | Where-Object { $_.DisplayName -eq $f[1] } | Select-Object -First 1
    if ($pick) { $syn.Voice = $pick; [Console]::Out.WriteLine("OK") }
    else { [Console]::Out.WriteLine("ERR voice") }
    [Console]::Out.Flush()
    continue
  }
  if ($f[0] -eq "SAY" -and $f.Count -ge 3) {
    $out = $f[1]
    try {
      $ssml = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($f[2]))
      $st = Await $syn.SynthesizeSsmlToStreamAsync($ssml) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
      $reader = New-Object Windows.Storage.Streams.DataReader($st.GetInputStreamAt(0))
      [void](Await $reader.LoadAsync([uint32]$st.Size) ([uint32]))
      $bytes = New-Object byte[] ([int]$st.Size)
      $reader.ReadBytes($bytes)
      [System.IO.File]::WriteAllBytes($out, $bytes)
      [Console]::Out.WriteLine("OK")
    } catch {
      $msg = ($_.Exception.Message -replace "`r", " " -replace "`n", " ")
      [Console]::Out.WriteLine("ERR " + $msg)
    }
    [Console]::Out.Flush()
    continue
  }
  [Console]::Out.WriteLine("ERR")
  [Console]::Out.Flush()
}
'''


class _Daemon:
    """常驻的 PowerShell 合成进程（一条，全局共享，空闲 3 分钟自己退出）。"""

    def __init__(self):
        self.p = None
        self.voice = ""
        self.lock = threading.Lock()
        self.sp = ""
        self.idle = None
        self.off = False       # 这台机器试过起不来（比如没有 WinRT），别再重试

    # ---- 生命周期 ----
    def alive(self):
        return self.p is not None and self.p.poll() is None

    def start(self):
        if self.off:
            return False
        if self.alive():
            return True
        try:
            fd, sp = tempfile.mkstemp(suffix=".ps1", prefix="omc_tts_d_")
            os.close(fd)
            with open(sp, "w", encoding="utf-8-sig") as f:
                f.write(_DAEMON_PS)
            self.sp = sp
            self.p = subprocess.Popen(
                [_ps_winrt(), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", sp],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, text=True, encoding="utf-8",
                bufsize=1, creationflags=_flags())
            self.voice = ""
            # 12 秒还没 READY 就判死：WinRT 加载本来 1 秒内就该好，
            # 拖这么久基本是这台机器没有这套语音（Win7 之类），别再等 45 秒。
            if self._read(12) == "READY":
                return True
            self.off = True
            self.stop()
            return False
        except Exception:
            self.off = True
            self.stop()
            return False

    def stop(self):
        try:
            if self.p is not None:
                self.p.stdin.write("QUIT\n")
                self.p.stdin.flush()
        except Exception:
            pass
        try:
            if self.p is not None:
                self.p.terminate()
        except Exception:
            pass
        try:
            if self.sp and os.path.isfile(self.sp):
                os.remove(self.sp)
        except Exception:
            pass
        self.p, self.sp, self.voice = None, "", ""
        return True

    def _read(self, timeout=25):
        """读一行回应。管道读没有超时，套一个短命线程等，卡住也不拖死调用方。"""
        if self.p is None:
            return ""
        box = {}

        def rd():
            try:
                box["v"] = self.p.stdout.readline()
            except Exception:
                box["v"] = ""

        t = threading.Thread(target=rd, daemon=True)
        t.start()
        t.join(timeout)
        if t.is_alive():
            return ""                    # 超时：当失败处理，由调用方重启
        return (box.get("v") or "").strip()

    def _idle_timer(self, seconds=180):
        """空闲太久就关掉，别让一个 40 MB 的解释器陪着界面空转。"""
        try:
            if self.idle is not None:
                self.idle.cancel()
        except Exception:
            pass
        self.idle = threading.Timer(seconds, self.stop)
        self.idle.daemon = True
        self.idle.start()

    # ---- 合成 ----
    def say(self, ssml, voice, path, timeout=30):
        with self.lock:
            if not self.start():
                return False
            try:
                if voice and voice != self.voice:
                    self.p.stdin.write("VOICE\t%s\n" % voice)
                    self.p.stdin.flush()
                    if not self._read(timeout).startswith("OK"):
                        return False
                    self.voice = voice
                payload = base64.b64encode(ssml.encode("utf-8")).decode("ascii")
                self.p.stdin.write("SAY\t%s\t%s\n" % (path.replace("\\", "/"), payload))
                self.p.stdin.flush()
                r = self._read(timeout)
                ok = (r == "OK" and os.path.isfile(path)
                      and os.path.getsize(path) > 2000)
                self._idle_timer()
                return ok
            except Exception:
                self.stop()
                return False


_DAEMON = _Daemon()

# 新版优先走 Windows 自带的 OneCore 音色（WinRT 合成），它们的录音比 SAPI5 那套
# 「Huihui Desktop」新，而且沙盒实测：Kangkang（男）、Yaoyao（女）、Huihui 三个
# 都能真出声（SAPI5 里只有 Huihui Desktop 一个能 SelectVoice，另外两个一选就报
# 「未安装匹配的语音」，所以以前那套多声线其实是假的多声线）。
# 系统以后若装了神经网络语音包（Xiaoxiao / Yunxi / Yunjian 等），这里会自动优先用它。
_OC = {"ok": None, "voices": [], "tried": False, "n": 0}

_OC_PROBE = r'''$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media, ContentType = WindowsRuntime]
$all = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices
foreach ($v in $all) { Write-Output ($v.Language + "|" + $v.DisplayName + "|" + $v.Gender) }
'''

_OC_SYNTH = r'''$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) {
  $m = $asTask.MakeGenericMethod($type)
  $t = $m.Invoke($null, @($op))
  [void]$t.Wait(-1)
  $t.Result
}
$syn = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
$pick = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices | Where-Object { $_.DisplayName -eq '__VOICE__' } | Select-Object -First 1
if ($pick) { $syn.Voice = $pick }
$ssml = @'
__SSML__
'@
$st = Await $syn.SynthesizeSsmlToStreamAsync($ssml) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
$reader = New-Object Windows.Storage.Streams.DataReader($st.GetInputStreamAt(0))
[void](Await $reader.LoadAsync([uint32]$st.Size) ([uint32]))
$bytes = New-Object byte[] ([int]$st.Size)
$reader.ReadBytes($bytes)
[System.IO.File]::WriteAllBytes('__OUT__', $bytes)
'''

# 神经网络音色优先（真人感最强）；其次是女声 Yaoyao（偏年轻，最像「年轻女生」），
# 再退 Huihui。Kangkang 是成年男声、音色偏粗（就是以前那个「五大三粗」），
# 只留作最后的兜底，别的都选不到时才会用上。
_NN_NAMES = ("xiaoxiao", "xiaoyi", "yunxi", "yunjian", "yunyang", "yunye",
             "neural", "natural")
_PREF_NAMES = ("yaoyao", "huihui", "kangkang")


# key → (显示名, 音库, 语速档(-10..10), 变调系数, 说明)
# 只留一个真声线：多套音色听起来是几个不同的机器人在说话，反而更假。
# 「关闭声音」不是声线，是开关，留着给界面用。
VOICE_STYLES = [
    ("xiaokuang", "小矿", "zh", -1, 1.00, "平常说话，句读清楚"),
    ("guan", "关闭声音", "-", 0, 1.00, "只看文字，不出声"),
]

# 标点后面的停顿毫秒数：句子断得开，听感才不像一口气念到底。
# 真人说话的句号停顿接近 300ms，逗号 150ms 上下；以前 240/120 太赶，像报站。
_BREAK_MS = {
    "。": 300, "！": 320, "？": 320, ".": 280, "!": 300, "?": 300,
    "；": 200, ";": 190, "，": 145, ",": 135, "、": 95, "：": 130, ":": 120,
    "\n": 340,
}


# ---------------- 语气自动检测 ----------------
# 每句话先按字面判一个语气，再用「音高小改 + 语速整档 + 音量一点」念出来。
# 幅度必须收着：音高改动超过 ±8% 就不像同一个人换语气，而像换了个人。
# 这里保持「同一个人、说话的情绪不一样」才是最像真人的听感。
# 结构：(标签, 关键词, 语速档(-10/0/+10), 音高系数, 音量系数)
_TONES = (
    ("joy", ("太棒", "好棒", "厉害", "牛啊", "真牛", "爽", "哈哈", "嘻嘻", "耶",
             "赢了", "成了", "成功", "搞定", "太帅", "绝了", "喜欢", "开心",
             "高兴", "走起", "起飞", "好玩", "稳了", "舒服"),
     0, 1.05, 1.02),
    ("sad", ("唉", "算了", "可惜", "没成", "失败", "崩了", "没了", "遗憾",
             "对不起", "抱歉", "难过", "难受", "心疼", "不怪你", "下次吧",
             "白干了", "凉了", "烦人"),
     0, 0.95, 0.94),
    ("angry", ("怎么又", "气死", "凭什么", "废话", "快点", "别磨", "又坏",
               "又来", "受够", "什么鬼", "搞什么", "服了"),
     10, 1.02, 1.06),
    ("soft", ("别急", "没事", "慢慢", "放心", "我在", "加油", "不着急",
              "陪你", "歇会", "别慌", "有我在", "不要紧", "慢慢来"),
     -10, 1.00, 0.93),
    ("surprise", ("哇", "居然", "竟然", "没想到", "真的吗", "天啊", "神了",
                  "不可思议", "我去"),
     0, 1.07, 1.03),
    ("ask", ("吗", "呢", "怎么", "为什么", "是不是", "要不要", "哪个", "啥"),
     0, 1.03, 1.00),
)


def detect_tone(text):
    """按要念的这句话自己判语气。

    返回 dict：tag 语气名、rate 语速档（-10 / 0 / +10）、k 音高系数、vol 音量系数。
    只做字面判断，不加延迟、不联网，念之前就算完了。
    """
    t = (text or "").strip()
    plain = {"tag": "plain", "rate": 0, "k": 1.0, "vol": 1.0}
    if not t:
        return plain
    best, score = plain, 0
    for tag, words, rate, k, vol in _TONES:
        n = sum(1 for w in words if w in t)
        if n > score:
            score = n
            best = {"tag": tag, "rate": rate, "k": k, "vol": vol}
    if score == 0:
        return plain
    # 多个感叹号是「情绪更冲」的强信号，音高再抬一小格（仍在安全范围内）
    bangs = t.count("！") + t.count("!")
    if bangs >= 2 and best["k"] > 1.0:
        best["k"] = min(1.09, best["k"] + 0.02)
    # 问句收尾会把音调抬起来，这是中文很自然的习惯
    if t.endswith(("？", "?")) and best["k"] < 1.02:
        best["k"] = 1.03
    return best


def style_of(key):
    for row in VOICE_STYLES:
        if row[0] == key:
            return row
    return VOICE_STYLES[0]


def available():
    if os.name != "nt":
        return False
    return bool(shutil.which("powershell") or shutil.which("pwsh"))


def _ps():
    return shutil.which("powershell") or shutil.which("pwsh")


def _flags():
    return (subprocess.CREATE_NO_WINDOW
            if hasattr(subprocess, "CREATE_NO_WINDOW") else 0)


def voices():
    """系统里有哪些语音。"""
    if not available():
        return []
    try:
        script = ("Add-Type -AssemblyName System.Speech;"
                  "(New-Object System.Speech.Synthesis.SpeechSynthesizer)"
                  ".GetInstalledVoices() | ForEach-Object "
                  "{ $_.VoiceInfo.Culture.Name + ' ' + $_.VoiceInfo.Name }")
        out = subprocess.run([_ps_winrt(), "-NoProfile", "-Command", script],
                             capture_output=True, timeout=20,
                             creationflags=_flags()).stdout
        txt = out.decode("utf-8", "replace")
        return [ln.strip() for ln in txt.splitlines() if ln.strip()]
    except Exception:
        return []


def _voice_for(lang):
    want = "zh-CN" if lang != "en" else "en-US"
    for n in voices():
        if want in n:
            return n.split(" ", 1)[-1].strip()
    return ""


def _xml_escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# 中文（及其标点）之间夹的空格念出来是突兀的停顿；英文路径里的空格必须留着
_CN_SPACE = re.compile(r"([\u4e00-\u9fff，。！？；：、）])\s+([\u4e00-\u9fff])")


def _clean(text):
    """念之前把书面符号清掉：markdown、括号注释、破折号、bookmarks。

    不清理的话，SAPI 会把 `*`、括号、`——` 当字符念出来或者卡一下，
    这是「机器人感」里很显眼的一条。
    """
    t = (text or "")
    t = re.sub(r"[*#`>_\[\]|]", "", t)
    t = re.sub(r"（[^）]*）|\([^)]*\)", "", t)
    t = t.replace("——", "，").replace("—", "，").replace("–", "，")
    t = t.replace("「", "").replace("」", "").replace("“", "").replace("”", "")
    t = _CN_SPACE.sub(r"\1\2", t)
    t = re.sub(r"\n+", "\n", t)
    return t.strip()


def _ssml(text, rate_pct):
    """把一句话拼成 SSML：语速 + 标点处停顿。pitch 不用（SAPI 不认）。"""
    parts = []
    buf = ""
    for ch in text:
        buf += ch
        if ch in _BREAK_MS:
            parts.append((buf, _BREAK_MS[ch]))
            buf = ""
    if buf:
        parts.append((buf, 0))
    body = ""
    for seg, br in parts:
        seg = seg.strip()
        if not seg:
            continue
        body += _xml_escape(seg)
        if br:
            body += '<break time="%dms"/>' % int(br)
    rate = max(-60, min(60, int(float(rate_pct) * 8)))
    return ('<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" '
            'xml:lang="zh-CN"><prosody rate="%+d%%">%s</prosody></speak>'
            % (rate, body))


def _synth(text, rate_pct, voice, volume, path):
    """让 SAPI 把一句话合成到 wav（优先走 SSML，失败退回纯文本）。"""
    safe = text.replace("'", "”").replace("\n", "，")[:600]
    ssml = _ssml(safe, rate_pct).replace("'", "''")
    head = (
        "Add-Type -AssemblyName System.Speech;"
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$s.Volume=%d;"
        "%s"
        "$s.SetOutputToWaveFile('%s');"
        % (int(volume),
           ("$s.SelectVoice('%s');" % voice) if voice else "",
           path.replace("\\", "\\\\"))
    )
    body = "try{ $s.SpeakSsml('%s') }catch{ $s.Rate=%d; $s.Speak('%s') };" % (
        ssml, int(rate_pct), safe.replace("'", "''"))
    subprocess.run([_ps_winrt(), "-NoProfile", "-NonInteractive", "-Command",
                    head + body + "; $s.Dispose()"],
                   capture_output=True, timeout=90,
                   creationflags=_flags())


def _sentences(text, limit=9):
    """按句末标点切句：一句一次合成，句间留气口，听着才像人在说话。

    一次性把整段塞给它，语调是一条直线，AI 味就出来了。
    """
    parts = []
    buf = ""
    for ch in text:
        buf += ch
        if ch in "。！？；\n":
            if buf.strip():
                parts.append(buf.strip())
            buf = ""
    if buf.strip():
        parts.append(buf.strip())
    # 一句太长、又没句号可断，就在中间的逗号切一刀。一口气念 40 字以上，
    # 换气点全靠引擎自己猜，听上去就是「念稿」。
    split = []
    for p in parts:
        if len(p) > 40 and ("，" in p or "," in p):
            half = len(p) // 2
            at = -1
            for i, ch in enumerate(p):
                if ch in "，," and 8 <= i <= len(p) - 8:
                    if at < 0 or abs(i - half) < abs(at - half):
                        at = i + 1
            if at > 0:
                split.append(p[:at].strip())
                split.append(p[at:].strip())
                continue
        split.append(p)
    parts = [p for p in split if p]
    if len(parts) > limit:
        merged, cur = [], ""
        for p in parts:
            if cur and len(cur) + len(p) > 70:
                merged.append(cur)
                cur = p
            else:
                cur += p
        if cur:
            merged.append(cur)
        parts = merged[:limit]
    return parts or [text[:600]]


def _wav_info(path):
    with wave.open(path, "rb") as w:
        return (w.getnchannels(), w.getsampwidth(), w.getframerate(),
                w.readframes(w.getnframes()))


def _join_wavs(paths, gaps, out):
    """把几句 wav 拼成一句：中间插静音当换气口，长一点的气口里带一丝吸气声。

    gaps 可以是单个毫秒数，也可以是每段各自的毫秒数（按前一句的标点定）。
    """
    try:
        nch, sw, fr, head = _wav_info(paths[0])
        if not isinstance(gaps, (list, tuple)):
            gaps = [gaps] * (len(paths) - 1)
        frames = [head]
        for i, p in enumerate(paths):
            info = _wav_info(p)
            if info[:3] != (nch, sw, fr):
                return False
            frames.append(info[3])
            if i + 1 < len(paths):
                g = int(gaps[i]) if i < len(gaps) else 170
                silent = _gap_frames(nch, sw, fr, g)
                frames.append(silent)
        with wave.open(out, "wb") as nw:
            nw.setnchannels(nch)
            nw.setsampwidth(sw)
            nw.setframerate(fr)
            nw.writeframes(b"".join(frames))
        return os.path.getsize(out) > 2000
    except Exception:
        return False


# 句间气口的呼吸声：极轻的嘶声（约满量程 1%），带缓起缓落。
# 纯粹的静音听起来像被剪断；一点吸气声，句与句之间才有「人在换气」的感觉。
def _gap_frames(nch, sw, fr, gms):
    n = max(1, int(fr * gms / 1000.0))
    if gms < 180 or sw != 2:
        return b"\x00" * (sw * nch * n)
    breath = max(1, int(n * 0.42))
    vals = []
    prev = [0] * nch
    seed = (gms * 131 + n) & 0x7fffffff
    for i in range(n):
        if i < breath:
            env = (i / (breath * 0.35)) if i < breath * 0.35 else \
                  ((breath - i) / (breath * 0.65))
            env = max(0.0, min(1.0, env))
            seed = (seed * 1103515245 + 12345) & 0x7fffffff
            raw = ((seed >> 16) % 2001 - 1000) * 0.5 * env
            for c in range(nch):
                prev[c] = prev[c] + 0.35 * (raw - prev[c])   # 低通成嘶声
                vals.append(int(prev[c]))
        else:
            vals.extend([0] * nch)
    return b"".join(struct.pack("<h", max(-32768, min(32767, v))) for v in vals)


def _normalize(path, peak=0.90, fade_ms=30):
    """整段收到一起后再统一音量、加两头渐入渐出（逐句各自归一会让音量忽大忽小）。"""
    try:
        nch, fr, samples = _read_wav(path)
    except Exception:
        return
    if not samples:
        return
    mx = max((abs(v) for v in samples), default=0)
    if mx > 0:
        gain = min(4.0, (peak * 32767) / float(mx))
        samples = [int(v * gain) for v in samples]
    fade = min(len(samples) // 2, int(fr * fade_ms / 1000.0) * nch)
    for i in range(fade):
        g = i / float(fade)
        samples[i] = int(samples[i] * g)
        samples[-1 - i] = int(samples[-1 - i] * g)
    try:
        with wave.open(path, "wb") as nw:
            nw.setnchannels(nch)
            nw.setsampwidth(2)
            nw.setframerate(fr)
            nw.writeframes(struct.pack("<%dh" % len(samples), *samples))
    except Exception:
        pass


def _gap_of(sentence):
    """每句之后的换气长度按它自己的标点来：句号后面停久一点，逗号短一点。"""
    s = (sentence or "").rstrip()
    if not s:
        return 170
    c = s[-1]
    if c in "。":
        return 300
    if c in "！？!?":
        return 330
    if c in "；;":
        return 210
    if c in "，,":
        return 160
    if c in "…":
        return 340
    return 190


# 每句的音高相对基音差值：真人讲话一句高一句低，全程同一个调门就是机器味。
_SENT_K = (1.000, 0.972, 1.024, 0.985, 1.014)


def _sentence_k(sentence, base_k, idx):
    s = (sentence or "").rstrip()
    c = s[-1] if s else ""
    if c in "？?":
        factor = 1.032                 # 问句句尾抬高一点
    elif c in "！!":
        factor = 1.018
    elif c in "…":
        factor = 0.990
    else:
        factor = _SENT_K[idx % len(_SENT_K)]
    k = base_k * factor
    # 整段往下走：真人一段话越说到后面调门越低（declination），
    # 全程一条直线听着像播报。幅度收在 4% 以内，不仔细听不出来。
    k *= (1.008 - 0.008 * min(idx, 5))
    return max(0.86, min(1.24, k))


def _trim_silence(src, dst, th=40, keep_ms=15):
    """掐掉句子首尾自带的长静音。

    SAPI 每段 wav 的头尾常带 0.3~0.5 秒空白，直接拼起来句间停顿就变成
    「300ms 再加两段空白」，实测有 1.3 秒的空等——听着像卡住了，不像换气。
    裁掉之后停顿完全由我们按标点给的时长决定。
    """
    try:
        nch, fr, samples = _read_wav(src)
        if not samples or nch < 1:
            raise ValueError
    except Exception:
        try:
            shutil.copyfile(src, dst)
        except Exception:
            pass
        return dst
    n = len(samples) // nch
    keep = int(fr * keep_ms / 1000.0)
    i0 = 0
    while i0 < n:
        if abs(samples[i0 * nch]) >= th:
            break
        i0 += 1
    i0 = max(0, i0 - keep)
    i1 = n
    while i1 > i0 + 1:
        if abs(samples[(i1 - 1) * nch]) >= th:
            break
        i1 -= 1
    i1 = min(n, i1 + keep)
    try:
        with wave.open(dst, "wb") as nw:
            nw.setnchannels(nch)
            nw.setsampwidth(2)
            nw.setframerate(fr)
            nw.writeframes(struct.pack("<%dh" % ((i1 - i0) * nch),
                                       *samples[i0 * nch:i1 * nch]))
    except Exception:
        try:
            shutil.copyfile(src, dst)
        except Exception:
            pass
    return dst


def _synth_joined(segs, rate, voice, volume, out, tmpdir, base_k=1.0):
    """逐句合成、逐句微变调再拼接：每句音高不同，句子语速也轻抖（±1 档）。"""
    files = []
    gaps = []
    try:
        for i, s in enumerate(segs):
            p = os.path.join(tmpdir, "omc_seg_%d_%d.wav" % (os.getpid(), i))
            t = os.path.join(tmpdir, "omc_segt_%d_%d.wav" % (os.getpid(), i))
            q = os.path.join(tmpdir, "omc_segp_%d_%d.wav" % (os.getpid(), i))
            # 语速随机轻抖 ±5%（不是固定 ±1 档，那四句一个循环听多了有规律）
            r = max(-10.0, min(10.0, float(rate) + random.uniform(-0.6, 0.6)))
            _synth(s, r, voice, volume, p)
            if os.path.isfile(p) and os.path.getsize(p) > 2000:
                _trim_silence(p, t)
                src = t if os.path.isfile(t) else p
                # 逐句变调时不做归一/淡入，等整段拼完再统一处理
                _pitch_shift(src, q, _sentence_k(s, base_k, i), norm=False)
                files.append(q if os.path.isfile(q) else src)
                gaps.append(_gap_of(s))
            for x in (p, t):
                try:
                    os.remove(x)
                except Exception:
                    pass
            else:
                try:
                    os.remove(p)
                except Exception:
                    pass
        if len(files) < 2:
            return False
        if not _join_wavs(files, gaps, out):
            return False
        _normalize(out, 0.90, 30)
        return os.path.getsize(out) > 2000
    finally:
        for p in files:
            try:
                os.remove(p)
            except Exception:
                pass


def _read_wav(path):
    with wave.open(path, "rb") as w:
        nch = w.getnchannels()
        sw = w.getsampwidth()
        fr = w.getframerate()
        n = w.getnframes()
        raw = w.readframes(n)
    if sw != 2:
        return None
    samples = list(struct.unpack("<%dh" % (len(raw) // 2), raw))
    return nch, fr, samples


def _lowpass(samples, nch, k=0.32, passes=1):
    """一阶低通，压掉变调抽点带出来的高频毛刺。

    以前固定跑两遍、系数还小，声音被削得发闷——听起来就像机器在念。
    现在默认一遍、系数大一些，只处理毛刺不损清晰度。
    """
    out = list(samples)
    n = len(samples) // max(1, nch)
    for _ in range(max(1, int(passes))):
        prev = [0] * nch
        for i in range(n):
            base = i * nch
            for c in range(nch):
                v = out[base + c]
                prev[c] = int(prev[c] + k * (v - prev[c]))
                out[base + c] = prev[c]
    return out


def _pitch_shift(src, dst, k, norm=True):
    """Catmull-Rom 三次插值重采样做变调：k>1 音调升高、语速变快。

    norm=False 时不归一、不加渐入渐出——逐句处理连成整段后统一做，
    不然每句都被拉到满音量，句与句之间听着忽大忽小。
    """
    if abs(k - 1.0) < 0.02:
        try:
            shutil.copyfile(src, dst)
        except Exception:
            pass
        return dst
    try:
        got = _read_wav(src)
        if got is None:
            shutil.copyfile(src, dst)
            return dst
        nch, fr, samples = got
        total = len(samples) // max(1, nch)
        new_total = max(1, int(total / k))
        out = [0] * (new_total * nch)
        last = total - 1
        for i in range(new_total):
            pos = i * k
            i0 = int(pos)
            t = pos - i0
            base0 = (i0 - 1 if i0 > 0 else 0) * nch
            base1 = i0 * nch
            base2 = (i0 + 1 if i0 < last else last) * nch
            base3 = (i0 + 2 if i0 + 2 <= last else last) * nch
            t2 = t * t
            t3 = t2 * t
            for c in range(nch):
                s0 = samples[base0 + c]
                s1 = samples[base1 + c]
                s2 = samples[base2 + c]
                s3 = samples[base3 + c]
                v = 0.5 * ((2 * s1) + (-s0 + s2) * t
                           + (2 * s0 - 5 * s1 + 4 * s2 - s3) * t2
                           + (-s0 + 3 * s1 - 3 * s2 + s3) * t3)
                if v > 32767:
                    v = 32767
                elif v < -32768:
                    v = -32768
                out[i * nch + c] = int(v)
        # 低通是为了压掉升调后的齿音；语气只升 2~9%，这个幅度不需要，
        # 加了反而把声音糊住，所以阈值抬到 1.10（超过才是真的在变调）。
        if k > 1.10:
            out = _lowpass(out, nch, 0.56 if k > 1.20 else 0.70, 1)
        if norm:
            # 音量归一：以前变调后峰值掉到 0.6，听着又小又虚
            peak = max((abs(v) for v in out), default=0)
            if peak > 0:
                gain = min(4.0, (0.90 * 32767) / float(peak))
                out = [int(v * gain) for v in out]
            # 两头各加 30ms 渐入渐出，句子不会一上来就“啪”地出声
            fade = min(len(out) // 2, int(fr * 0.03) * nch)
            for i in range(fade):
                g = i / float(fade)
                out[i] = int(out[i] * g)
                out[-1 - i] = int(out[-1 - i] * g)
        with wave.open(dst, "wb") as nw:
            nw.setnchannels(nch)
            nw.setsampwidth(2)
            nw.setframerate(fr)
            nw.writeframes(struct.pack("<%dh" % len(out), *out))
    except Exception:
        try:
            shutil.copyfile(src, dst)
        except Exception:
            pass
    return dst


def say_block(text, style="xiaokuang", volume=100, mood=0):
    """念一句并**等它念完**（语音通话用：念的时候不能开着麦克风，会自己听见自己）。

    返回 True 表示确实念出来了。
    """
    text = (text or "").strip()
    if not text or not available() or style == "guan":
        return False
    if not _LOCK.acquire(blocking=False):
        return False
    try:
        return _say(text, style, volume, mood)
    finally:
        _LOCK.release()


def stop():
    """立刻掐掉正在念的这一句（挂电话时用）。"""
    try:
        import winsound
        winsound.PlaySound(None, winsound.SND_PURGE)
    except Exception:
        pass


def _render_to(text, style="xiaokuang", volume=100, path="", mood=0):
    """把一段话合成到 wav：多句走「逐句合成 + 逐句微变调 + 呼吸气口」，单句走整段。

    返回 True 表示 wav 可用。say / render 共用这一条路径，
    这样试听听到的和通话里念出来的是同一个东西。

    mood > 0 说高兴的事（略高略快），mood < 0 是安抚（略低略慢），幅度都很小。
    """
    text = _clean(text)
    if not text:
        return False
    sid, _label, lang, rate_pct, k, _note = style_of(style)
    tone = detect_tone(text)
    # 文本本身没判出情绪时，才用调用方给的 mood 兜一下（AI 那边的情绪判断）
    if tone["tag"] == "plain":
        if mood > 0:
            tone = {"tag": "mood+", "rate": 0, "k": 1.03, "vol": 1.01}
        elif mood < 0:
            tone = {"tag": "mood-", "rate": 0, "k": 0.98, "vol": 0.96}
    pct = int(tone["rate"])
    vol = max(0, min(100, int(volume * tone["vol"])))
    k *= tone["k"]
    try:
        # 首选 OneCore 音色整段合成：一条进程、停顿交给 SSML。
        # 换音色后不再大改音高（重采样会把共振峰一起搬走，那才是「机器味」），
        # 但语气需要的那点起伏（≤9%）可以接受：变的是同一个人的音高，不是换人。
        if _winrt_ok():
            v = _oc_voice(lang)
            if v:
                raw = path + ".tone.wav"
                if _synth_winrt(text, v, pct, vol, raw):
                    if abs(k - 1.0) >= 0.02:
                        _pitch_shift(raw, path, k)
                    else:
                        shutil.copyfile(raw, path)
                    try:
                        os.remove(raw)
                    except Exception:
                        pass
                    _normalize(path, 0.90, 30)
                    return True
        d = tempfile.gettempdir()
        voice = _voice_for(lang)
        # 变调会同时改语速：升一点就慢一点念，降一点就快一点，抵消掉
        comp = 0
        if k > 1.05:
            comp = int(round((k - 1.0) * 5))
        elif k < 0.95:
            comp = -int(round((1.0 - k) * 5))
        rate = max(-10, min(10, int(rate_pct) + comp + int(tone["rate"]) // 10))
        # SAPI 的 rate 百分比实测按档量化（-8% 与 -12% 输出长度一模一样），
        # 所以别指望 0.4 档这种小步长，要动就动一整档；语气已在上面折进 rate。
        segs = _sentences(text)
        if len(segs) > 1:
            # 多句：逐句合成 + 逐句微变调（每句音高不同），句间插呼吸
            if _synth_joined(segs, rate, voice, volume, path, d, base_k=k):
                return True
        p = path + ".raw.wav"
        _synth(text, rate, voice, volume, p)
        if os.path.isfile(p) and os.path.getsize(p) < 2000 and voice:
            # 比如用 Zira 念中文会一个字都不出，换默认中文音库再试
            _synth(text, rate, _voice_for("zh"), volume, p)
        if not os.path.isfile(p) or os.path.getsize(p) < 2000:
            return False
        _pitch_shift(p, path, k)
        try:
            os.remove(p)
        except Exception:
            pass
        return os.path.getsize(path) > 2000
    except Exception:
        return False


def _voice_cache_path():
    return os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                        "tts_voices.json")


def _voice_cache_read():
    """上一次探查成功的音色表。启动后第一句话不必再花 700 毫秒去探。"""
    try:
        with open(_voice_cache_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        rows = [(str(r[0]), str(r[1]), str(r[2])) for r in d.get("voices") or []]
        if rows:
            _OC["voices"], _OC["ok"], _OC["tried"] = rows, True, True
            return rows
    except Exception:
        pass
    return []


def _voice_cache_write():
    try:
        p = _voice_cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"voices": [list(r) for r in _OC["voices"]]}, f,
                      ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        pass


def _oc_list():
    """探一次系统音色（OneCore / WinRT）。成功才封存，失败下次还能再试。

    以前失败一次就永久回退 SAPI：PowerShell 冷启动在内存紧的机器上偶尔会
    超过 25 秒，一次超时就把音色锁死在「Huihui Desktop」那种老音库上，
    表现为「换音色没生效」。现在放宽到 60 秒，失败只记次数（最多试 3 次）。

    探查固定用 Windows PowerShell 5.1：pwsh 7 加载不了 WinRT 类型，用它探
    永远是 0 个音色，然后一直退回慢一倍的 SAPI5 路径。
    """
    if _OC["tried"]:
        return _OC["voices"]
    if _OC["n"] >= 3:
        return []
    if _OC["n"] == 0 and _voice_cache_read():
        return _OC["voices"]
    _OC["n"] += 1
    path = ""
    try:
        fd, path = tempfile.mkstemp(suffix=".ps1", prefix="omc_oc_")
        os.close(fd)
        with open(path, "w", encoding="utf-8-sig") as f:
            f.write(_OC_PROBE)
        out = subprocess.run([_ps_winrt(), "-NoProfile", "-ExecutionPolicy",
                              "Bypass", "-File", path], capture_output=True,
                             timeout=60, creationflags=_flags()
                             ).stdout.decode("utf-8", "replace")
        rows = []
        for ln in out.splitlines():
            bits = ln.strip().split("|")
            if len(bits) >= 3 and bits[0]:
                rows.append((bits[0].strip(), bits[1].strip(), bits[2].strip()))
        _OC["voices"] = rows
        _OC["ok"] = bool(rows)
        _OC["tried"] = bool(rows)          # 探到了才封存，没探到留机会重试
        if rows:
            _voice_cache_write()
    except Exception:
        _OC["voices"], _OC["ok"], _OC["tried"] = [], False, False
    finally:
        try:
            if path:
                os.remove(path)
        except Exception:
            pass
    return _OC["voices"]


def _winrt_ok():
    _oc_list()
    return bool(_OC["ok"])


def _oc_voice(lang="zh"):
    """挑一个最适合的 OneCore 音色。"""
    want = "en" if lang == "en" else "zh"
    pool = [r for r in _oc_list() if r[0].lower().startswith(want)]
    if not pool:
        return ""
    for r in pool:
        if any(n in r[1].lower() for n in _NN_NAMES):
            return r[1]
    for p in _PREF_NAMES:
        for r in pool:
            if p in r[1].lower():
                return r[1]
    return pool[0][1]


def voice_name(lang="zh"):
    """当前实际会用哪个音色（给界面/自检显示用）。"""
    if _winrt_ok():
        return _oc_voice(lang) or _voice_for(lang)
    return _voice_for(lang)


def _ssml_winrt(text, rate_pct, volume):
    """整段 SSML：标点处插 break，rate 用百分比（WinRT 认这个，比 SAPI 的档位细）。

    pitch 依旧不用：系统这几套音库里 prosody 的音高改动不生效，硬改只能自己重采样，
    而重采样会连共振峰一起搬走——那正是「机器味」的来源，所以新版不做变调。
    """
    marks = _BREAK_MS
    body, buf = "", ""
    for ch in text:
        if ch in "\r":
            continue
        buf += ch
        if ch in marks:
            body += _xml_escape(buf)
            body += '<break time="%dms"/>' % int(marks[ch])
            buf = ""
        elif ch == "\n":
            body += _xml_escape(buf[:-1])
            body += '<break time="%dms"/>' % int(marks["\n"])
            buf = ""
    body += _xml_escape(buf)
    return ('<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" '
            'xml:lang="zh-CN"><prosody rate="%+d%%" volume="%d">%s</prosody></speak>'
            % (max(-40, min(40, int(rate_pct))), max(0, min(100, int(volume))), body))


def _synth_winrt(text, voice, rate_pct, volume, path):
    """把整段话合成到一个 wav（含标点停顿）。成功返回 True。

    先走常驻进程（加载一次 WinRT，之后每条只是一次内存里的合成调用）；
    常驻进程不可用再退回「起一个 powershell.exe 跑一段脚本」的老路子。
    """
    try:
        ssml = _ssml_winrt((text or "")[:600], rate_pct, volume)
        if _DAEMON.say(ssml, voice, os.path.abspath(path)):
            return True
        code = (_OC_SYNTH.replace("__VOICE__", voice.replace("'", "''"))
                .replace("__SSML__", ssml)
                .replace("__OUT__", os.path.abspath(path).replace("\\", "\\\\")))
        fd, sp = tempfile.mkstemp(suffix=".ps1", prefix="omc_oc_s_")
        os.close(fd)
        try:
            with open(sp, "w", encoding="utf-8-sig") as f:
                f.write(code)
            subprocess.run([_ps_winrt(), "-NoProfile", "-ExecutionPolicy", "Bypass",
                            "-File", sp], capture_output=True, timeout=90,
                           creationflags=_flags())
        finally:
            try:
                os.remove(sp)
            except Exception:
                pass
        return os.path.isfile(path) and os.path.getsize(path) > 2000
    except Exception:
        return False


def _say(text, style="xiaokuang", volume=100, mood=0):
    tmp = ""
    try:
        tmp = os.path.join(tempfile.gettempdir(), "omc_tts_%d.wav" % int(os.getpid()))
        if not _render_to(text, style, volume, tmp, mood):
            return False
        import winsound
        winsound.PlaySound(tmp, winsound.SND_FILENAME)
        return True
    except Exception:
        return False
    finally:
        if tmp:
            try:
                os.remove(tmp)
            except Exception:
                pass


def _speak_stream(text, style, volume, mood):
    """边合成边播：第一句合成好就开口，剩下的在上一句播放期间准备好。

    以前是整段合成完才出声，一段三句话要干等四五秒才算「开始说话」；
    现在等待时间只剩第一句的合成（常驻进程下通常 100~300 毫秒）。
    """
    import winsound
    segs = _sentences(_clean(text), limit=6) or [text]
    tmp = tempfile.gettempdir()
    pid = int(os.getpid())

    def prep(i):
        if i >= len(segs):
            return ""
        p = os.path.join(tmp, "omc_say_%d_%d.wav" % (pid, i))
        try:
            if _render_to(segs[i], style, volume, p, mood):
                return p
        except Exception:
            pass
        return ""

    cur = prep(0)
    i = 0
    while cur:
        box = {}
        th = None
        if i + 1 < len(segs):
            th = threading.Thread(target=lambda j=i + 1: box.update(p=prep(j)),
                                  daemon=True)
            th.start()
        try:
            winsound.PlaySound(cur, winsound.SND_FILENAME)
        except Exception:
            pass
        try:
            os.remove(cur)
        except Exception:
            pass
        cur = ""
        if th is not None:
            th.join(timeout=12)
            cur = box.get("p") or ""
        i += 1


def speak(text, style="xiaokuang", volume=100, mood=0):
    """念一句话（后台线程，立刻返回）。返回 True 表示已派发。"""
    text = (text or "").strip()
    if not text or not available() or style == "guan":
        return False

    def work():
        if not _LOCK.acquire(blocking=False):
            return                      # 上一句还在念，不叠着开进程
        try:
            _speak_stream(text, style, volume, mood)
        finally:
            _LOCK.release()

    threading.Thread(target=work, daemon=True).start()
    return True


def render(text, style="xiaokuang", volume=100, path="", mood=0):
    """不开音响，只把这一句合成到指定 wav（给试听/取证用）。"""
    if not text or not available() or not path:
        return ""
    return path if _render_to(text, style, volume, path, mood) else ""


def preview(style, text="我是小矿，这个声音听得清吗？"):
    """试听按钮用：同一个声线念一句固定的话。"""
    return speak(text, style, 95)
