# -*- coding: utf-8 -*-
"""检测并启动 Windows 商店版《我的世界》基岩版。"""
import json
import os
import subprocess
import sys

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# 包名 -> 显示名
KNOWN = {
    "Microsoft.MinecraftUWP": "基岩版（正式版）",
    "Microsoft.MinecraftWindowsBeta": "基岩版（预览版）",
}

STORE_URL = "ms-windows-store://pdp/?productid=9NBLGGH2JHXJ"
STORE_PDP = "https://apps.microsoft.com/detail/9nblggh2jhxj"


def _ps(cmd, timeout=25):
    """跑一条 PowerShell 命令，返回 stdout 文本（失败返回空串）。"""
    if sys.platform != "win32":
        return ""
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace",
            creationflags=CREATE_NO_WINDOW)
        return (r.stdout or "").strip()
    except Exception:
        return ""


def list_installed():
    """返回已安装的基岩版列表：[{"name","label","family","version"}]。"""
    ps = ("Get-AppxPackage Microsoft.MinecraftUWP,"
          "Microsoft.MinecraftWindowsBeta | "
          "Select-Object Name,PackageFamilyName,Version | "
          "ConvertTo-Json -Compress")
    raw = _ps(ps)
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    out = []
    for d in data:
        nm = d.get("Name") or ""
        fam = d.get("PackageFamilyName") or ""
        if not fam:
            continue
        out.append({
            "name": nm,
            "label": KNOWN.get(nm, nm),
            "family": fam,
            "version": d.get("Version") or "",
        })
    # 正式版排前面
    out.sort(key=lambda r: 0 if r["name"] == "Microsoft.MinecraftUWP" else 1)
    return out


def launch(entry):
    """启动指定基岩版，返回 (ok, message)。"""
    if not entry or not entry.get("family"):
        return False, "没有可用的基岩版"
    uri = "shell:AppsFolder\\%s!App" % entry["family"]
    try:
        subprocess.Popen(["explorer.exe", uri],
                         creationflags=CREATE_NO_WINDOW)
        return True, "已启动 " + (entry.get("label") or "基岩版")
    except Exception as e:
        return False, str(e)


def open_store():
    """打开微软商店的基岩版页面。"""
    try:
        os.startfile(STORE_URL)   # noqa: S606
        return True
    except Exception:
        try:
            os.startfile(STORE_PDP)   # noqa: S606
            return True
        except Exception:
            return False
