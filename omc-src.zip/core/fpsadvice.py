# -*- coding: utf-8 -*-
"""帧率建议：按本机 CPU 核数、物理内存、屏幕刷新率给一套 options.txt 推荐值。

只写「用户没设过」的键（game_options.apply_options(only_missing=True)），
玩家自己调过的渲染距离、画质不会被悄悄改回去。
"""
import ctypes


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class _SYSTEMINFO(ctypes.Structure):
    _fields_ = [
        ("wProcessorArchitecture", ctypes.c_ushort),
        ("wReserved", ctypes.c_ushort),
        ("dwPageSize", ctypes.c_ulong),
        ("lpMinimumApplicationAddress", ctypes.c_void_p),
        ("lpMaximumApplicationAddress", ctypes.c_void_p),
        ("dwActiveProcessorMask", ctypes.c_void_p),
        ("dwNumberOfProcessors", ctypes.c_ulong),
        ("dwProcessorType", ctypes.c_ulong),
        ("dwAllocationGranularity", ctypes.c_ulong),
        ("wProcessorLevel", ctypes.c_ushort),
        ("wProcessorRevision", ctypes.c_ushort),
    ]


def hw():
    """返回 {'cores', 'mem_gb', 'mem_free_gb'}；取不到的项给 0。"""
    res = {"cores": 0, "mem_gb": 0.0, "mem_free_gb": 0.0}
    try:
        si = _SYSTEMINFO()
        ctypes.windll.kernel32.GetSystemInfo(ctypes.byref(si))
        res["cores"] = int(si.dwNumberOfProcessors or 0)
    except Exception:
        pass
    try:
        ms = _MEMORYSTATUSEX()
        ms.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        fn = ctypes.windll.kernel32.GlobalMemoryStatusEx
        fn.argtypes = [ctypes.POINTER(_MEMORYSTATUSEX)]
        fn.restype = ctypes.c_int
        if fn(ctypes.byref(ms)):
            res["mem_gb"] = round(ms.ullTotalPhys / 1073741824.0, 1)
            res["mem_free_gb"] = round(ms.ullAvailPhys / 1073741824.0, 1)
    except Exception:
        pass
    return res


def recommend(h, refresh=60):
    """按硬件给推荐。refresh 由 QScreen.refreshRate() 传进来。

    三档：弱机（≤4 核或 ≤8G）、中档、强机（≥8 核且 ≥16G）。
    maxFps 取刷新率本身：再高也看不出来，只是白烧 GPU。
    返回 ({key: value}, [给人看的理由])。
    """
    cores = h.get("cores") or 0
    mem = h.get("mem_gb") or 0
    try:
        refresh = int(round(float(refresh))) if refresh else 60
    except Exception:
        refresh = 60
    if refresh <= 0 or refresh > 500:
        refresh = 60

    if cores and cores <= 4 or (mem and mem <= 8.5):
        tier, rd, gfx, par, clouds, shadow = "偏弱", 6, "fast", "minimal", "fast", False
    elif cores >= 8 and mem >= 15.5:
        tier, rd, gfx, par, clouds, shadow = "偏强", 12, "fancy", "decreased", "true", True
    else:
        tier, rd, gfx, par, clouds, shadow = "中等", 10, "fast", "decreased", "fast", True

    # 硬件够但可用内存已经见底（浏览器、剪辑软件常驻）时，按弱机给：
    # Java 拿不到连续内存，进游戏后是一路掉帧 + 频繁 GC，不是显卡的锅。
    tight_mem = bool(h.get("mem_free_gb")) and h["mem_free_gb"] < 3.0
    if tight_mem:
        tier, rd, gfx, par, clouds, shadow = "内存吃紧", 6, "fast", "minimal", "fast", False

    values = {
        "maxFps": refresh,
        "graphics": gfx,
        "renderDistance": rd,
        "simulationDistance": rd,
        "particles": par,
        "clouds": clouds,
        "entityShadows": shadow,
        "vsync": False,
        "ao": gfx != "fast",
        "biomeBlendRadius": 2 if gfx == "fancy" else 0,
    }
    reasons = [
        "档位：%s（%s 核 / %s GB 内存 / %s Hz 屏）"
        % (tier, cores or "?", mem or "?", refresh),
        "最大帧率设成 %d：和屏幕刷新率对齐，超过刷新率的帧数是白烧显卡。" % refresh,
        "渲染距离 %d 区块、模拟距离 %d：这两个是最吃帧率的滑块。" % (rd, rd),
        "粒子 %s、云 %s：中低档机器上这两项常年占掉 10-20%% 的帧率。" % (par, clouds),
        "垂直同步关：开着会把帧率锁在刷新率并增加输入延迟，用 maxFps 限帧更稳。",
    ]
    if tight_mem:
        reasons.insert(1, "可用内存只剩 %s GB：进游戏前先关掉浏览器 / 剪辑软件，"
                          "否则 Java 一路 GC，帧率会一段一段地掉。" % h["mem_free_gb"])
    return values, reasons


def text(h, values, reasons):
    lines = ["本机：%s 核 CPU，%s GB 内存（可用 %s GB）"
             % (h.get("cores") or "?", h.get("mem_gb") or "?", h.get("mem_free_gb") or "?"),
             ""]
    for r in reasons:
        lines.append("· " + r)
    lines.append("")
    lines.append("将写入 options.txt（已有同名项不动）：")
    from core import game_options
    for k in sorted(values):
        label = game_options.LABELS.get(k, k)
        v = values[k]
        if isinstance(v, bool):
            v = "开" if v else "关"
        lines.append("  %s = %s（%s）" % (label, v, k))
    return "\n".join(lines)
