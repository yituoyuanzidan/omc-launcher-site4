# -*- coding: utf-8 -*-
"""版本安装：下载 version json、client、libraries、natives、assets，并做完整性自检。"""
import json
import os
import zipfile

from . import http, platform_utils

VERSION_MANIFEST = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"

# 当前平台的 Mojang 名称与架构（windows/osx/linux、x86_64/arm64/x86）
OS_NAME = platform_utils.OS_NAME
OS_ARCH = platform_utils.OS_ARCH

_VERIFY_CACHE_FILE = os.path.join(platform_utils.data_dir(), "verify_cache.json")


def _load_verify_cache():
    try:
        with open(_VERIFY_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_verify_cache(data):
    try:
        os.makedirs(os.path.dirname(_VERIFY_CACHE_FILE), exist_ok=True)
        with open(_VERIFY_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


def list_versions(mirror="official"):
    data = http.fetch_json(VERSION_MANIFEST, mirror)
    return data["versions"]


def _rules_allowed(rules, arch=None):
    """按官方规则判断该库/参数是否适用于当前平台与架构。"""
    if not rules:
        return True
    arch = arch or OS_ARCH
    allowed = False
    for rule in rules:
        action = rule.get("action")
        os_rule = rule.get("os") or {}
        matches = True
        if os_rule:
            name = os_rule.get("name")
            if name and name != OS_NAME:
                matches = False
            rule_arch = os_rule.get("arch")
            if rule_arch and rule_arch != arch:
                matches = False
        if rule.get("features"):
            # 依赖特性开关的参数默认关闭
            matches = False
        if matches:
            allowed = (action == "allow")
    return allowed


def _is_native(name):
    """判断这是不是当前平台/架构要用的 natives 库，排除其它系统与其它架构。"""
    tag = ":natives-"
    if tag not in name:
        return False
    seg = name.split(tag, 1)[1].split(":")[0]  # 例如 windows / windows-64 / osx / linux
    if OS_NAME not in seg:
        return False
    if OS_ARCH == "arm64":
        if "arm64" not in seg:
            return False
    else:
        if "arm64" in seg:
            return False
        if OS_ARCH == "x86_64" and (seg.endswith("-x86") or seg.endswith("-32")):
            return False
        if OS_ARCH == "x86" and "-64" in seg:
            return False
    return True


def _pick_artifacts(lib):
    """返回 [(artifact, is_native)]，兼顾现代独立 natives 库与旧式 classifiers。"""
    downloads = lib.get("downloads") or {}
    name = lib.get("name", "")
    result = []

    artifact = downloads.get("artifact")
    if artifact:
        result.append((artifact, _is_native(name)))

    natives = lib.get("natives") or {}
    classifier = natives.get(OS_NAME)
    if classifier:
        if "${arch}" in classifier:
            # 只有 Windows 的旧式 classifier 带架构位（32/64）
            bits = "64"
            if platform_utils.WINDOWS and OS_ARCH == "x86":
                bits = "32"
            classifier = classifier.replace("${arch}", bits)
        native_art = (downloads.get("classifiers") or {}).get(classifier)
        if native_art:
            result.append((native_art, True))
    return result


def expected_parts(vj):
    """列出这个版本运行所需的全部磁盘文件（用于启动前自检）。"""
    parts = []
    client = (vj.get("downloads") or {}).get("client")
    if client:
        parts.append(("client", client["path"] if "path" in client else "", client))
    for lib in vj.get("libraries", []):
        if not _rules_allowed(lib.get("rules")):
            continue
        for art, is_native in _pick_artifacts(lib):
            parts.append(("library" if not is_native else "native",
                          art.get("path", ""), art))
    return parts


class Installer(object):
    def __init__(self, game_dir, mirror="official", log=None, progress=None):
        self.game_dir = game_dir
        self.mirror = mirror
        self.log = log or (lambda msg: None)
        self.progress = progress or (lambda cur, total: None)
        self.cancelled = False

    def cancel(self):
        self.cancelled = True

    def _check_cancel(self):
        if self.cancelled:
            raise RuntimeError("已取消安装")

    # ---------- 主流程 ----------
    def install(self, version_id, manifest_url):
        self._check_cancel()
        ver_dir = os.path.join(self.game_dir, "versions", version_id)
        os.makedirs(ver_dir, exist_ok=True)
        json_path = os.path.join(ver_dir, version_id + ".json")

        self.log("下载版本信息 " + version_id)
        if not (os.path.exists(json_path) and os.path.getsize(json_path) > 0):
            vj = http.fetch_json(manifest_url, self.mirror)
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(vj, f, ensure_ascii=False, indent=2)
        else:
            with open(json_path, "r", encoding="utf-8") as f:
                vj = json.load(f)

        # 1. 收集全部下载任务：client、依赖库、资源文件，统一编号统一进度
        self._check_cancel()
        jobs = []
        client = (vj.get("downloads") or {}).get("client")
        if client:
            dest = os.path.join(ver_dir, version_id + ".jar")
            if not http._file_ok(dest, client.get("size"), client.get("sha1")):
                jobs.append(("client", client["url"], dest,
                             client.get("size"), client.get("sha1")))

        natives_dir = os.path.join(ver_dir, "natives")
        libs = [l for l in vj.get("libraries", [])
                if _rules_allowed(l.get("rules"))]
        need_native = False
        for lib in libs:
            for art, is_native in _pick_artifacts(lib):
                if is_native:
                    need_native = True
                dest = os.path.join(self.game_dir, "libraries", art["path"])
                if not http._file_ok(dest, art.get("size"), art.get("sha1")):
                    jobs.append(("native" if is_native else "library",
                                 art["url"], dest,
                                 art.get("size"), art.get("sha1")))

        jobs.extend(self._asset_jobs(vj))

        # 2. 统一线程池并发下载，进度只增不减
        import time
        import threading
        from concurrent.futures import ThreadPoolExecutor, as_completed

        total = len(jobs)
        self.log("待下载文件 %d 个" % total)
        self.progress(0, total)

        finished = [0]
        bytes_done = [0]
        fails = []
        lock = threading.Lock()
        stop = threading.Event()

        def monitor():
            last_b, last_t = 0, time.time()
            while not stop.wait(1.5):
                with lock:
                    b, f = bytes_done[0], finished[0]
                now = time.time()
                spd = (b - last_b) / max(now - last_t, 1e-6)
                last_b, last_t = b, now
                self.log("进度 %d/%d，已下载 %.1f MB，速度 %.2f MB/s"
                         % (f, total, b / 1048576, spd / 1048576))

        def fetch(job):
            self._check_cancel()
            _kind, url, dest, size, sha1 = job
            try:
                http.download_file(url, dest, self.mirror,
                                   size=size, sha1=sha1, retries=3)
            except Exception as e:
                self.log("下载失败 %s: %s" % (os.path.basename(dest), e))
                with lock:
                    fails.append(dest)
                return
            with lock:
                finished[0] += 1
                bytes_done[0] += size or 0
                f = finished[0]
            if f == total or f % 2 == 0:
                self.progress(f, total)

        tmon = threading.Thread(target=monitor, daemon=True)
        tmon.start()
        with ThreadPoolExecutor(max_workers=24) as pool:
            futures = [pool.submit(fetch, j) for j in jobs]
            for _ in as_completed(futures):
                self._check_cancel()
        stop.set()
        self.progress(total, total)
        if fails:
            raise RuntimeError("%d 个文件下载失败，可重试安装补齐" % len(fails))

        # 3. natives 统一解压（含历史已存在的包），避免并发写同一目录
        os.makedirs(natives_dir, exist_ok=True)
        for lib in libs:
            for art, is_native in _pick_artifacts(lib):
                if not is_native:
                    continue
                src = os.path.join(self.game_dir, "libraries", art["path"])
                if os.path.exists(src):
                    self._extract_natives(src, natives_dir)

        # 4. 自检
        problems = check_version(self.game_dir, version_id, vj, need_native=need_native)
        if problems:
            raise RuntimeError("安装不完整：" + "；".join(problems[:3]) +
                               ("（共 %d 项）" % len(problems) if len(problems) > 3 else ""))
        self.log("安装完成：" + version_id)
        return json_path

    def _asset_jobs(self, vj):
        """收集资源索引里缺失的 objects，返回统一格式的任务列表。"""
        asset_index = vj.get("assetIndex")
        if not asset_index:
            return []
        index_id = asset_index["id"]
        index_dir = os.path.join(self.game_dir, "assets", "indexes")
        os.makedirs(index_dir, exist_ok=True)
        index_path = os.path.join(index_dir, index_id + ".json")
        if os.path.exists(index_path) and os.path.getsize(index_path) > 0:
            with open(index_path, "r", encoding="utf-8") as f:
                index_data = json.load(f)
        else:
            index_data = http.fetch_json(asset_index["url"], self.mirror)
            with open(index_path, "w", encoding="utf-8") as f:
                json.dump(index_data, f)

        jobs = []
        for obj in (index_data.get("objects") or {}).values():
            h = obj["hash"]
            dest = os.path.join(self.game_dir, "assets", "objects", h[:2], h)
            if http._file_ok(dest, obj.get("size")):
                continue
            url = "https://resources.download.minecraft.net/%s/%s" % (h[:2], h)
            jobs.append(("asset", url, dest, obj.get("size"), None))
        return jobs

    def _extract_natives(self, jar_path, natives_dir):
        try:
            with zipfile.ZipFile(jar_path) as z:
                for member in z.namelist():
                    if member.startswith("META-INF") or member.endswith("/"):
                        continue
                    base = os.path.basename(member)
                    if not base:
                        continue
                    # 只解压当前平台能用的文件，避免 arm64/x86 覆盖 64 位库
                    if base.endswith((".dll", ".so", ".dylib")):
                        target = os.path.join(natives_dir, base)
                        with z.open(member) as src, open(target, "wb") as out:
                            out.write(src.read())
        except Exception as e:
            self.log("natives 解压失败: %s" % e)

def json_path_join(game_dir, version_id):
    return os.path.join(game_dir, "versions", version_id, version_id + ".json")


def check_version(game_dir, version_id, vj=None, need_native=True):
    """返回缺失项描述列表；空列表表示可以启动。"""
    # 上次校验通过且版本文件没变，直接放行，省掉 4000+ 次文件检查
    cache_key = os.path.normpath(os.path.join(game_dir, version_id))
    sig = None
    if vj is None:
        try:
            json_path = os.path.join(game_dir, "versions", version_id,
                                     version_id + ".json")
            st = os.stat(json_path)
            jar = os.path.join(game_dir, "versions", version_id, version_id + ".jar")
            jar_size = os.path.getsize(jar) if os.path.exists(jar) else 0
            sig = [int(st.st_mtime), st.st_size, jar_size]
            rec = _load_verify_cache().get(cache_key)
            if rec and rec.get("sig") == sig:
                return []
        except Exception:
            sig = None

    problems = []
    ver_dir = os.path.join(game_dir, "versions", version_id)
    if vj is None:
        json_path = os.path.join(ver_dir, version_id + ".json")
        if not os.path.exists(json_path):
            return ["版本信息缺失"]
        with open(json_path, "r", encoding="utf-8") as f:
            vj = json.load(f)

    # 加载器版本：先校验父版本，再校验自己独有的库
    parent = vj.get("inheritsFrom")
    if parent and os.path.exists(json_path_join(game_dir, parent)):
        problems = check_version(game_dir, parent, need_native=need_native)
        for lib in vj.get("libraries", []):
            if not _rules_allowed(lib.get("rules")):
                continue
            for art, _is_native in _pick_artifacts(lib):
                dest = os.path.join(game_dir, "libraries", art["path"])
                if not http._file_ok(dest, art.get("size")):
                    problems.append("缺少依赖 " + art["path"])
        return problems

    client = (vj.get("downloads") or {}).get("client")
    if client:
        jar = os.path.join(ver_dir, version_id + ".jar")
        if not http._file_ok(jar, client.get("size")):
            problems.append("主程序不完整")

    for lib in vj.get("libraries", []):
        if not _rules_allowed(lib.get("rules")):
            continue
        for art, is_native in _pick_artifacts(lib):
            dest = os.path.join(game_dir, "libraries", art["path"])
            if not http._file_ok(dest, art.get("size")):
                problems.append("缺少依赖 " + art["path"])

    natives_dir = os.path.join(ver_dir, "natives")
    has_native_lib = any(is_native for lib in vj.get("libraries", [])
                         if _rules_allowed(lib.get("rules"))
                         for _a, is_native in _pick_artifacts(lib))
    if has_native_lib and need_native:
        dlls = []
        if os.path.isdir(natives_dir):
            dlls = [f for f in os.listdir(natives_dir)
                    if f.lower().endswith(platform_utils.NATIVE_EXTS)]
        if not dlls:
            problems.append("natives 未解压（缺少 %s）"
                            % platform_utils.NATIVE_EXT.lstrip("."))

    # 资源索引与资源对象
    asset_index = vj.get("assetIndex")
    if asset_index:
        index_path = os.path.join(game_dir, "assets", "indexes",
                                  asset_index["id"] + ".json")
        if not (os.path.exists(index_path) and os.path.getsize(index_path) > 0):
            problems.append("缺少资源索引 " + asset_index["id"])
        else:
            try:
                with open(index_path, "r", encoding="utf-8") as f:
                    objects = (json.load(f).get("objects") or {})
                missing = 0
                for obj in objects.values():
                    h = obj["hash"]
                    p = os.path.join(game_dir, "assets", "objects", h[:2], h)
                    if not http._file_ok(p, obj.get("size")):
                        missing += 1
                if missing:
                    problems.append("资源文件缺失 %d 个" % missing)
            except Exception as e:
                problems.append("资源索引损坏: %s" % e)

    if not problems and sig:
        cache = _load_verify_cache()
        cache[cache_key] = {"sig": sig}
        _save_verify_cache(cache)
    return problems
