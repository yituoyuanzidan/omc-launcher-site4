# -*- coding: utf-8 -*-
"""娱乐页的棋牌内核：只管规则和 AI，界面在 ui/play_page.py。

这里的每个类都不碰网络、不碰界面，方便单独测：
    b = Gomoku(); b.place(7, 7, 1); b.winner()
约定棋盘/手牌里 1 是我、2 是 AI / 对手（斗地主是 1、2、3 三家）。
"""
import random

# =====================  общего：游戏清单 =====================
GAMES = [
    {"id": "gomoku", "name": "五子棋", "players": 2, "net": True,
     "desc": "15×15，先连五子者胜。可以邀请好友、匹配真人，也可以跟 AI 下。"},
    {"id": "go", "name": "围棋", "players": 2, "net": False,
     "desc": "9×9 小盘，数子定胜负。目前先做跟 AI 下。"},
    {"id": "landlord", "name": "斗地主", "players": 3, "net": False,
     "desc": "三个人斗一副牌，你当地主，两个 AI 当农民。"},
    {"id": "duel", "name": "一对一·21 点", "players": 2, "net": False,
     "desc": "你和对家各摸牌比点数，21 点最大、爆点直接输。"},
    {"id": "tic", "name": "三连棋", "players": 2, "net": True,
     "desc": "3×3 连成一线赢，规则最简单，适合热身。"},
    {"id": "rps", "name": "猜拳", "players": 2, "net": False,
     "desc": "石头剪刀布，五局三胜。先跟 AI 玩。"},
]

GAME_NAMES = {g["id"]: g["name"] for g in GAMES}
NET_GAMES = [g["id"] for g in GAMES if g.get("net")]


def game_name(gid):
    return GAME_NAMES.get(gid, gid or "对局")


# ===================== 五子棋 =====================
DIRS = ((1, 0), (0, 1), (1, 1), (1, -1))


class Gomoku(object):
    SIZE = 15

    def __init__(self):
        self.size = self.SIZE
        self.reset()

    def reset(self):
        self.board = [[0] * self.size for _ in range(self.size)]
        self.last = None
        self.moves = 0

    def inside(self, r, c):
        return 0 <= r < self.size and 0 <= c < self.size

    def place(self, r, c, who):
        if not self.inside(r, c) or self.board[r][c]:
            return False
        self.board[r][c] = who
        self.last = (r, c)
        self.moves += 1
        return True

    def winner(self):
        """返回 1/2/0。只看最后一步周围，省得每次全盘扫。"""
        if not self.last:
            return 0
        r, c = self.last
        who = self.board[r][c]
        for dr, dc in DIRS:
            n = 1
            for sign in (1, -1):
                k = 1
                while True:
                    rr, cc = r + dr * k * sign, c + dc * k * sign
                    if not self.inside(rr, cc) or self.board[rr][cc] != who:
                        break
                    n += 1
                    k += 1
            if n >= 5:
                return who
        return 0

    def full(self):
        return self.moves >= self.size * self.size

    def winner_line(self):
        """返回获胜那一整条线的坐标（从一端到另一端）。没有就返回空。

        结算前界面要用它画一条线，让人一眼看出是哪五颗子连起来的。
        """
        if not self.last:
            return []
        r, c = self.last
        who = self.board[r][c]
        if not who:
            return []
        for dr, dc in DIRS:
            left, right = [], []
            for sign, box in ((1, right), (-1, left)):
                k = 1
                while True:
                    rr, cc = r + dr * k * sign, c + dc * k * sign
                    if not self.inside(rr, cc) or self.board[rr][cc] != who:
                        break
                    box.append((rr, cc))
                    k += 1
            pts = list(reversed(left)) + [(r, c)] + right
            if len(pts) >= 5:
                return pts
        return []

    # ---- AI ----
    #: (模式, 等级)：5=成五 4=四 3=三 2=二 1=一
    _PAT = (
        ("XXXXX", 5),
        (".XXXX.", 4),
        ("XXXX.", 4), (".XXXX", 4),
        ("XXX.X", 4), ("X.XXX", 4), ("XX.XX", 4),
        (".XXX.", 3), (".XX.X.", 3), (".X.XX.", 3),
        ("XXX", 2), ("XX.X", 2), ("X.XX", 2),
        (".XX.", 1), (".X.X.", 1), ("XX", 1),
    )

    def _line_text(self, r, c, dr, dc, who):
        """以 (r,c) 为 who 的子，沿一个方向取 9 格字符串（X 同色、O 对手或界外）。"""
        out = []
        for k in range(-4, 5):
            if k == 0:
                out.append("X")
                continue
            rr, cc = r + dr * k, c + dc * k
            if not self.inside(rr, cc):
                out.append("O")
            else:
                v = self.board[rr][cc]
                out.append("X" if v == who else ("." if v == 0 else "O"))
        return "".join(out)

    def _levels(self, r, c, who):
        """四个方向上各自的威胁等级（0 = 没形状）。"""
        res = []
        for dr, dc in DIRS:
            t = self._line_text(r, c, dr, dc, who)
            lv = 0
            for pat, level in self._PAT:
                if pat in t:
                    lv = level
                    break
            res.append(lv)
        return res

    def _eval_point(self, r, c, who):
        """who 落这里值多少分：一眼成五最大，双四/四三/双活三各自加成。"""
        lv = self._levels(r, c, who)
        n5 = lv.count(5)
        n4 = lv.count(4)
        n3 = lv.count(3)
        n2 = lv.count(2)
        if n5:
            return 10000000
        v = n4 * 120000 + n3 * 9000 + n2 * 260 + lv.count(1) * 18
        if n4 >= 2:
            v += 700000
        elif n4 and n3:
            v += 260000
        if n3 >= 2:
            v += 80000
        return v

    def ai_move(self, me=2, level=2):
        """先占天元；之后按「自己的形 + 掐对方的形」挑点。

        以前只看连了几颗，分不出活三和冲四，更看不出双威胁；
        现在四个方向各自判形状，双活三、双四、四三都当一步定胜负来走。
        """
        if self.moves == 0:
            mid = self.size // 2
            return mid, mid
        opp = 3 - me
        cand = set()
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c]:
                    for dr in range(-2, 3):
                        for dc in range(-2, 3):
                            rr, cc = r + dr, c + dc
                            if self.inside(rr, cc) and not self.board[rr][cc]:
                                cand.add((rr, cc))
        if not cand:
            for r in range(self.size):
                for c in range(self.size):
                    if not self.board[r][c]:
                        cand.add((r, c))
        for (r, c) in cand:               # 自己一手成五，直接落
            if self._eval_point(r, c, me) >= 10000000:
                return r, c
        for (r, c) in cand:               # 对方下一手成五，必须堵
            if self._eval_point(r, c, opp) >= 10000000:
                return r, c
        best, best_v = None, -1.0
        mid = self.size // 2
        for (r, c) in cand:
            mine = self._eval_point(r, c, me)
            theirs = self._eval_point(r, c, opp)
            v = mine + theirs * 0.92
            v += random.random() * 6
            v -= (abs(r - mid) + abs(c - mid)) * 0.3
            if v > best_v:
                best_v, best = v, (r, c)
        return best or (mid, mid)


# ===================== 围棋（9×9 简化） =====================
class Go(object):
    SIZE = 9

    def __init__(self):
        self.size = self.SIZE
        self.reset()

    def reset(self):
        self.board = [[0] * self.size for _ in range(self.size)]
        self.passes = 0
        self.captured = {1: 0, 2: 0}
        self.ko = None      # 简化：不许立刻下回上一个位置
        self.last = None
        self.moves = []     # 双方落子顺序（AI 靠它判断「是不是又扎在同一片」）

    def inside(self, r, c):
        return 0 <= r < self.size and 0 <= c < self.size

    def _group(self, r, c):
        """返回 (同色连通块, 气数)。"""
        who = self.board[r][c]
        stack = [(r, c)]
        seen = {(r, c)}
        lib = set()
        while stack:
            rr, cc = stack.pop()
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                r2, c2 = rr + dr, cc + dc
                if not self.inside(r2, c2):
                    continue
                v = self.board[r2][c2]
                if v == 0:
                    lib.add((r2, c2))
                elif v == who and (r2, c2) not in seen:
                    seen.add((r2, c2))
                    stack.append((r2, c2))
        return seen, len(lib)

    def play(self, r, c, who):
        """落子。返回 (是否合法, 提掉的子数)。"""
        if not self.inside(r, c) or self.board[r][c]:
            return False, 0
        if self.ko == (r, c):
            return False, 0
        self.board[r][c] = who
        opp = 3 - who
        taken = 0
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            r2, c2 = r + dr, c + dc
            if self.inside(r2, c2) and self.board[r2][c2] == opp:
                grp, lib = self._group(r2, c2)
                if lib == 0:
                    for (rr, cc) in grp:
                        self.board[rr][cc] = 0
                    taken += len(grp)
        # 自己这块不能一点气都没有
        grp, lib = self._group(r, c)
        if lib == 0 and taken == 0:
            self.board[r][c] = 0
            return False, 0
        self.captured[who] += taken
        self.ko = (r, c) if taken == 1 and len(grp) == 1 else None
        self.last = (r, c)
        self.moves.append((r, c))
        self.passes = 0
        return True, taken

    def pass_turn(self):
        self.passes += 1
        return self.passes >= 2      # 两边都停一手就终局

    def score(self):
        """中国规则简化：数子和空（不管贴目），返回 (黑, 白)。"""
        blacks = 0
        whites = 0
        seen = set()
        for r in range(self.size):
            for c in range(self.size):
                v = self.board[r][c]
                if v == 1:
                    blacks += 1
                elif v == 2:
                    whites += 1
                elif (r, c) not in seen:
                    # 这块空被谁围住就归谁
                    area = set()
                    stack = [(r, c)]
                    seen.add((r, c))
                    around = set()
                    while stack:
                        rr, cc = stack.pop()
                        area.add((rr, cc))
                        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                            r2, c2 = rr + dr, cc + dc
                            if not self.inside(r2, c2):
                                continue
                            v2 = self.board[r2][c2]
                            if v2 == 0 and (r2, c2) not in seen:
                                seen.add((r2, c2))
                                stack.append((r2, c2))
                            elif v2:
                                around.add(v2)
                    if len(around) == 1:
                        if 1 in around:
                            blacks += len(area)
                        else:
                            whites += len(area)
        return blacks, whites

    # ---------- 围棋 AI：战术层 ----------
    _NB = ((1, 0), (-1, 0), (0, 1), (0, -1))
    _STARS = ((2, 2), (2, 6), (6, 2), (6, 6), (4, 4))

    def _scan(self):
        """全盘块：[颜色, 点集合, 气数]。"""
        seen, out = set(), []
        for r in range(self.size):
            for c in range(self.size):
                if not self.board[r][c] or (r, c) in seen:
                    continue
                grp, lib = self._group(r, c)
                seen |= grp
                out.append((self.board[r][c], grp, lib))
        return out

    def _position_map(self, me):
        """位置价值：大空区、势力、区心。落子前算一次，所有候选共用。"""
        opp = 3 - me
        b = self.board
        val = {}
        seen = set()
        for r in range(self.size):
            for c in range(self.size):
                if b[r][c] or (r, c) in seen:
                    continue
                area, stack, near = set(), [(r, c)], {1: 0, 2: 0}
                seen.add((r, c))
                while stack:
                    rr, cc = stack.pop()
                    area.add((rr, cc))
                    for dr, dc in self._NB:
                        r2, c2 = rr + dr, cc + dc
                        if not self.inside(r2, c2):
                            continue
                        v = b[r2][c2]
                        if v:
                            near[v] += 1
                        elif (r2, c2) not in seen:
                            seen.add((r2, c2))
                            stack.append((r2, c2))
                n = len(area)
                if not n:
                    continue
                cx = sum(p[0] for p in area) / float(n)
                cy = sum(p[1] for p in area) / float(n)
                weight = 1.0 if n >= 12 else 0.6       # 大空才值得抢
                # 这附近自己子已经堆了不少，再往里塞就是重复，越堆越不值钱
                rep = max(0, near[me] - 4) * 0.9
                base = (near[me] - near[opp]) * 0.35 + n * 0.25 - rep
                for (rr, cc) in area:
                    val[(rr, cc)] = (6.0 * weight - (abs(rr - cx) + abs(cc - cy)) * 0.5
                                     + base)
        for r in range(self.size):
            for c in range(self.size):
                if b[r][c]:
                    continue
                s = 0.0
                for dr in range(-2, 3):
                    for dc in range(-2, 3):
                        if dr == 0 and dc == 0:
                            continue
                        r2, c2 = r + dr, c + dc
                        if not self.inside(r2, c2) or not b[r2][c2]:
                            continue
                        w = 1.0 / (1 + abs(dr) + abs(dc))
                        s += w if b[r2][c2] == me else -w
                val[(r, c)] = val.get((r, c), 0.0) + s
        return val

    def _own_risk(self, me):
        """我方「下一手就会被提」的块：气只剩一口气的。返回 (总子数, 最大块)。

        AI 落子前先问一句：我这么走，他下一手是不是直接把我这块端了。
        只看自己这手拿了多少分，就会出现「吃了两子、送掉一大块」的棋。
        """
        total, biggest = 0, 0
        for color, grp, lib in self._scan():
            if color == me and lib <= 1:
                total += len(grp)
                if len(grp) > biggest:
                    biggest = len(grp)
        return total, biggest

    def _move_score(self, r, c, me, posv, weak, recent):
        """模拟这一手，按战术项打分；None 表示不能下（自杀）。"""
        opp = 3 - me
        b = self.board
        own_nb, opp_pts = {}, {}
        for dr, dc in self._NB:
            r2, c2 = r + dr, c + dc
            if not self.inside(r2, c2) or not b[r2][c2]:
                continue
            g, l = self._group(r2, c2)
            key = frozenset(g)
            if b[r2][c2] == me:
                own_nb[key] = l
            else:
                opp_pts.setdefault(key, set()).add((r2, c2))

        b[r][c] = me
        cleared, taken, grp, lib, opp_after = [], 0, set(), 0, []
        try:
            for dr, dc in self._NB:
                r2, c2 = r + dr, c + dc
                if not self.inside(r2, c2) or b[r2][c2] != opp:
                    continue
                g, l = self._group(r2, c2)
                if l == 0:
                    taken += len(g)
                    for (rr, cc) in g:
                        if b[rr][cc] == opp:
                            b[rr][cc] = 0
                            cleared.append((rr, cc))
            grp, lib = self._group(r, c)
            if lib == 0:
                return None
            for dr, dc in self._NB:
                r2, c2 = r + dr, c + dc
                if self.inside(r2, c2) and b[r2][c2] == opp:
                    g, l = self._group(r2, c2)
                    opp_after.append((frozenset(g), l))
        finally:
            for (rr, cc) in cleared:
                b[rr][cc] = opp
            b[r][c] = 0

        v = float(taken) * 16.0                  # 提子
        v += lib * 3.0                           # 自己的气
        v += len(grp) * 1.2                      # 连成一片

        saved = [k for k, l in own_nb.items() if l == 1]
        if saved and lib >= 2:
            # 救回来的块越大越该救：二十子的大块和两子的小块不是一回事
            v += sum(45.0 + len(k) * 8.0 for k in saved)
        if len(own_nb) >= 2:
            v += 16.0 * (len(own_nb) - 1)        # 连接自己的两块
        elif own_nb and lib >= 3:
            v += 1.5                             # 纯贴着自己往外长，不算好棋

        n_atari = sum(1 for _g, l in opp_after if l == 1)
        if n_atari >= 2:
            v += 52.0                            # 双打吃：一手打两块，对方救不全
        elif n_atari == 1:
            v += 14.0
        v += sum(len(_g) for _g, l in opp_after if l <= 2) * 1.5

        cut_same = sum(1 for _k, pts in opp_pts.items() if len(pts) >= 2)
        if cut_same:
            v += 24.0 * cut_same                 # 一刀切开对方同一块
            if sum(1 for _g, l in opp_after if l <= 2) >= 2:
                v += 12.0
        if len(opp_pts) >= 2:
            v += 14.0                            # 同时顶住两块，卡死它们连片

        cnt = {1: 0, 2: 0}
        for dr, dc in self._NB:
            r2, c2 = r + dr, c + dc
            if self.inside(r2, c2) and self.board[r2][c2]:
                cnt[self.board[r2][c2]] += 1
        if cnt[opp] >= 3:
            v += 26.0                            # 点在对方眼位：破眼
        if cnt[me] >= 3:
            v -= 22.0                            # 填自己的眼：亏

        v += posv.get((r, c), 0.0)               # 大场 / 势力 / 空区价值

        if not weak and (r, c) in self._STARS:
            v += 9.0                             # 开局先占角
        if weak:
            d = min(abs(r - wr) + abs(c - wc) for (wr, wc) in weak)
            if d > 3:
                v -= 5.0                         # 打起来了别跑去下闲棋
        if recent:
            dmin = min(abs(r - rr) + abs(c - cc) for (rr, cc) in recent)
            if dmin <= 1:
                v -= 9.0                         # 紧贴着刚下的子，容易越走越死
            elif dmin <= 2:
                v -= 5.0
        return v + random.random() * 0.8

    def ai_move(self, me=2):
        """会打战术的一手：先研判全盘，再决定打哪儿。

        以前只算「贴着这块能不能提、气多不多」，所以会一直在一个角里反复落子。
        现在每个点都按八项战术打分——提子、救子、叫吃、双打吃、分断、连接、
        做眼/破眼、围空与大场——再叠一条全盘分布项：贴着刚才那几手死磕同一片
        会自动降权，盘上还有大空就先抢大场，不会只盯着一块地方下。
        """
        if not any(any(row) for row in self.board):
            return (2, 2)                        # 空盘第一手直接占角
        opp = 3 - me
        posv = self._position_map(me)
        weak = []
        for _color, grp, lib in self._scan():
            if lib <= 2:
                weak.extend(grp)
        recent = self.moves[-3:]
        cands = []
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c] or self.ko == (r, c):
                    continue
                v = self._move_score(r, c, me, posv, weak, recent)
                if v is not None:
                    cands.append((v, (r, c)))
        if not cands:
            return None
        cands.sort(reverse=True)
        # 前几名各看一手：我下这里，对手最好的应手能拿多少分，
        # 以及**我下完之后自己还剩多少子下一手就要被提**。
        # 只看对手得分不够：对手随手一挡也可能有十几分，真正要命的是一手吃我一大块。
        best, best_net, best_v = None, -1e9, -1e9
        for v0, mv in cands[:8]:
            rec = self._place(mv[0], mv[1], me)
            if rec is None:
                continue
            reply, risk, big = 0.0, 0, 0
            try:
                risk, big = self._own_risk(me)
                for r in range(self.size):
                    for c in range(self.size):
                        if self.board[r][c] or self.ko == (r, c):
                            continue
                        v = self._move_score(r, c, opp, posv, weak, recent)
                        if v is not None and v > reply:
                            reply = v
            finally:
                self._unplace(rec)
            # 「我这样走，他下一步就把我这块提了」——这种棋先扣掉。
            # 扣得比提子分（16/子）轻一点：能提不等于一定被提，但大块被端是硬亏。
            net = v0 - reply * 0.85 - risk * 10.0
            if big >= 5:
                net -= 26.0 + big * 4.0
            if net > best_net:
                best_net, best_v, best = net, v0, mv
        if best is None:
            return None
        return best if best_v >= 2.0 else None

    def _place(self, r, c, who):
        """临时落一手（含提子），返回撤销记录；不合法返回 None。"""
        b = self.board
        if not self.inside(r, c) or b[r][c]:
            return None
        b[r][c] = who
        opp = 3 - who
        cleared = []
        for dr, dc in self._NB:
            r2, c2 = r + dr, c + dc
            if self.inside(r2, c2) and b[r2][c2] == opp:
                g, l = self._group(r2, c2)
                if l == 0:
                    for (rr, cc) in g:
                        if b[rr][cc] == opp:
                            b[rr][cc] = 0
                            cleared.append((rr, cc))
        g, l = self._group(r, c)
        if l == 0 and not cleared:
            b[r][c] = 0
            for (rr, cc) in cleared:
                b[rr][cc] = opp
            return None
        return (r, c, cleared, opp)

    def _unplace(self, rec):
        r, c, cleared, opp = rec
        self.board[r][c] = 0
        for (rr, cc) in cleared:
            self.board[rr][cc] = opp


# ===================== 斗地主 =====================
def _rank(card):
    return card % 13 + 3          # 3..15（15 = 2）


def _rank_name(v):
    return {11: "J", 12: "Q", 13: "K", 14: "A", 15: "2", 16: "小王",
            17: "大王"}.get(v, str(v))


def card_label(card):
    if card == 52:
        return "小王"
    if card == 53:
        return "大王"
    suit = "♠♥♣♦"[card // 13]
    return suit + _rank_name(_rank(card))


def new_deck():
    return list(range(54))


TYPE_NAMES = {"single": "单张", "pair": "对子", "triple": "三张",
              "triple1": "三带一", "triple2": "三带二", "straight": "顺子",
              "pairs": "连对", "plane": "飞机", "bomb": "炸弹",
              "rocket": "王炸", "four2": "四带二"}


def _card_val(card):
    """比大小时用点数：3..15（15 是 2）、16 小王、17 大王。"""
    if card == 52:
        return 16
    if card == 53:
        return 17
    return card % 13 + 3


def _seg_runs(vs):
    """把一组点数拆成连续段（顺子 / 连对 / 飞机都靠它）。"""
    out, cur = [], []
    for v in sorted(vs):
        if cur and v == cur[-1] + 1:
            cur.append(v)
        else:
            if cur:
                out.append(cur)
            cur = [v]
    if cur:
        out.append(cur)
    return out


def play_type(cards):
    """认出牌型。返回 (type, 主牌点数, 长度)；认不出返回 (None, 0, 0)。

    以前这里放得太松：一堆不相干的牌也会被认成能出的牌型，界面上就是
    「牌型不合法照样出得掉」。现在每种牌型的张数、点数跟班都卡死了。
    """
    cards = list(cards or [])
    if not cards:
        return None, 0, 0
    if len(set(cards)) != len(cards):
        # 同一张牌不能出两次（旧 AI 拼三带一时就会拼出重复牌）
        return None, 0, 0
    vals = sorted(_card_val(c) for c in cards)
    n = len(vals)
    cnt = {}
    for v in vals:
        cnt[v] = cnt.get(v, 0) + 1
    kinds = sorted(cnt.values(), reverse=True)
    has_joker = (52 in cards) or (53 in cards)

    if 52 in cards and 53 in cards:
        return ("rocket", 99, 2) if n == 2 else (None, 0, 0)
    if n == 1:
        return "single", vals[0], 1
    if has_joker:
        # 王只能单出或者两个一起王炸，不能塞进对子/顺子/三带里
        return None, 0, 0
    if n == 2:
        return ("pair", vals[0], 2) if vals[0] == vals[1] else (None, 0, 0)
    if n == 3:
        return ("triple", vals[0], 3) if kinds == [3] else (None, 0, 0)
    if n == 4:
        if kinds == [4]:
            return "bomb", vals[0], 4
        if kinds == [3, 1]:
            return "triple1", cnt_key(cnt, 3), 4
        return None, 0, 0
    if n == 5 and kinds == [3, 2]:
        return "triple2", cnt_key(cnt, 3), 5
    if n == 6 and kinds in ([4, 1, 1], [4, 2]):
        return "four2", cnt_key(cnt, 4), 6
    # 顺子：>=5 张、张张不同、连续、不能带 2 和王
    if n >= 5 and len(cnt) == n and vals[-1] <= 14:
        if all(vals[i] + 1 == vals[i + 1] for i in range(n - 1)):
            return "straight", vals[0], n
    # 连对：>=3 对、连续、不能带 2 和王
    if n >= 6 and n % 2 == 0 and kinds[0] == 2 and len(cnt) == n // 2:
        vs = sorted(cnt)
        if vs[-1] <= 14 and all(vs[i] + 1 == vs[i + 1] for i in range(len(vs) - 1)):
            return "pairs", vs[0], n
    # 飞机：连续的三张，可以不带、带同数量的单张、或带同数量的对子
    tri = [v for v, k in cnt.items() if k == 3 and v <= 14]
    if len(tri) >= 2:
        for run in _seg_runs(tri):
            m = len(run)
            if m < 2:
                continue
            others = {v: k for v, k in cnt.items() if v not in run}
            osum = sum(others.values())
            singles_ok = all(k <= 2 for k in others.values())
            if osum == 0:
                return "plane", run[0], 3 * m
            if osum == m and singles_ok:
                return "plane", run[0], 4 * m
            if (osum == 2 * m and singles_ok
                    and all(k == 2 for k in others.values())):
                return "plane", run[0], 5 * m
    return None, 0, 0


def cnt_key(cnt, k):
    for v, n in cnt.items():
        if n == k:
            return v
    return 0


def beats(new, old):
    """new 能不能压 old。两个都是 play_type 的返回。"""
    t1, v1, n1 = new
    t2, v2, n2 = old
    if not t1:
        return False
    if t1 == "rocket":
        return True
    if t2 == "rocket":
        return False
    if t1 == "bomb" and t2 != "bomb":
        return True
    if t2 == "bomb" and t1 != "bomb":
        return False
    if t1 != t2:
        return False
    if n1 != n2:
        return False
    return v1 > v2


class Landlord(object):
    """斗地主：我(1) 当地主，2、3 是农民 AI。"""

    def __init__(self):
        self.reset()

    def reset(self):
        deck = new_deck()
        random.shuffle(deck)
        self.hands = {1: deck[0:20], 2: deck[20:37], 3: deck[37:54]}
        for u in (1, 2, 3):
            self.hands[u].sort(key=_card_val)
        self.owner = 1
        self.turn = 1
        self.last = None        # (who, cards)
        self.last_type = (None, 0, 0)
        self.passes = 0
        self.over = False
        self.win = 0

    def hand(self, who):
        return list(self.hands[who])

    def label(self, who):
        if who == 1:
            return "你"
        return "农民%s" % ("A" if who == 2 else "B")

    def _remove(self, who, cards):
        for c in cards:
            if c in self.hands[who]:
                self.hands[who].remove(c)
        if not self.hands[who]:
            self.over = True
            self.win = who

    def play(self, who, cards):
        """出牌。返回 (ok, 说明)。"""
        if self.over or who != self.turn:
            return False, "还没轮到你"
        if not cards:
            return False, "先选牌再出"
        hand = self.hands[who]
        if not set(cards) <= set(hand) or len(set(cards)) != len(cards):
            return False, "手里没有这几张"
        pt = play_type(cards)
        if not pt[0]:
            return False, "这个牌型不合法"
        if self.last and self.last[0] != who and not beats(pt, self.last_type):
            return False, "压不过上家"
        self._remove(who, cards)
        self.last = (who, list(cards))
        self.last_type = pt
        self.passes = 0
        if not self.over:
            self._next()
        return True, ""

    def pass_turn(self, who):
        if self.over or who != self.turn:
            return False, "还没轮到你"
        if not self.last or self.last[0] == who:
            return False, "你是这一轮的头一家，必须出牌"
        self.passes += 1
        if self.passes >= 2:
            self.last = None
            self.last_type = (None, 0, 0)
            self.passes = 0
        self._next()
        return True, ""

    def _next(self):
        self.turn = self.turn % 3 + 1

    # ---- 找牌 ----
    def _groups(self, hand):
        g = {}
        for c in sorted(hand, key=_card_val):
            g.setdefault(_card_val(c), []).append(c)
        return g

    def _runs(self, g, need_count):
        """连续点数段（每点至少有 need_count 张，2 和王不算）。"""
        vs = [v for v in sorted(g) if v <= 14 and len(g[v]) >= need_count]
        return _seg_runs(vs)

    def _find_beats(self, hand, need, allow_bomb=False):
        """找一手能压过 need 的牌，同型优先取最小的。"""
        t, v, n = need
        if not t:
            return []
        g = self._groups(hand)
        out = []

        def add(cs):
            if not cs or out:
                return
            pt = play_type(cs)
            if pt[0] and beats(pt, need):
                out.append(list(cs))

        if t == "single":
            # 优先用本来就是单张的牌，别把对子/三张/炸弹拆成单张打出去
            tiers = []
            for vv in sorted(g):
                if vv <= v:
                    continue
                n = len(g[vv])
                tiers.append((0 if n == 1 else (1 if n == 2 else (2 if n == 3 else 9)), vv))
            if tiers:
                tiers.sort()
                add([g[tiers[0][1]][0]])
        elif t == "pair":
            tiers = []
            for vv in sorted(g):
                if vv <= v or len(g[vv]) < 2:
                    continue
                tiers.append((0 if len(g[vv]) == 2 else (1 if len(g[vv]) == 3 else 9), vv))
            if tiers:
                tiers.sort()
                add(g[tiers[0][1]][:2])
        elif t == "triple":
            for vv in sorted(g):
                if vv > v and len(g[vv]) >= 3:
                    add(g[vv][:3])
                    break
        elif t in ("triple1", "triple2"):
            want = 1 if t == "triple1" else 2
            for vv in sorted(g):
                if vv <= v or len(g[vv]) < 3:
                    continue
                extra = []
                for v2 in sorted(g):
                    if v2 == vv or len(g[v2]) < want:
                        continue
                    extra = g[v2][:want]
                    break
                if extra:
                    add(g[vv][:3] + extra)
                    break
        elif t == "straight":
            for run in self._runs(g, 1):
                if len(run) < n:
                    continue
                for i in range(len(run) - n + 1):
                    seg = run[i:i + n]
                    if seg[0] > v:
                        add([g[s][0] for s in seg])
                        break
                if out:
                    break
        elif t == "pairs":
            m = n // 2
            for run in self._runs(g, 2):
                if len(run) < m:
                    continue
                for i in range(len(run) - m + 1):
                    seg = run[i:i + m]
                    if seg[0] > v:
                        add([c for s in seg for c in g[s][:2]])
                        break
                if out:
                    break
        elif t == "plane":
            # 按张数反推：3m 纯飞机、4m 带单、5m 带对
            if n % 5 == 0 and n % 3 != 0:
                m, wings = n // 5, 2
            elif n % 4 == 0:
                m, wings = n // 4, 1
            else:
                m, wings = n // 3, 0
            for run in self._runs(g, 3):
                if len(run) < m:
                    continue
                for i in range(len(run) - m + 1):
                    seg = run[i:i + m]
                    if seg[0] <= v:
                        continue
                    cs = [c for s in seg for c in g[s][:3]]
                    if wings:
                        extra = []
                        for v2 in sorted(g):
                            if v2 in seg or len(g[v2]) < wings:
                                continue
                            extra = g[v2][:wings]
                            break
                        if not extra:
                            continue
                        cs = cs + extra
                    add(cs)
                    break
                if out:
                    break
        elif t == "four2":
            for vv in sorted(g):
                if vv <= v or len(g[vv]) != 4:
                    continue
                cs = list(g[vv][:4])
                extra = []
                for v2 in sorted(g):
                    if v2 == vv:
                        continue
                    if len(g[v2]) >= 2:
                        extra = g[v2][:2]
                        break
                if not extra:
                    for v2 in sorted(g):
                        if v2 == vv:
                            continue
                        extra.append(g[v2][0])
                        if len(extra) == 2:
                            break
                add(cs + extra)
                break

        if out:
            return out[0]
        if not allow_bomb:
            return []
        # 同型压不住：炸弹 / 王炸（王炸压一切）
        if 52 in hand and 53 in hand:
            return [52, 53]
        if t == "rocket":
            return []
        bombs = [vv for vv in sorted(g) if len(g[vv]) == 4]
        if t == "bomb":
            for vv in bombs:
                if vv > v:
                    return list(g[vv][:4])
            return []
        if bombs:
            return list(g[bombs[0]][:4])
        return []

    def _pick_lead(self, hand):
        """自己头家出牌：能一次走完就走完，否则先甩最便宜的。"""
        if not hand:
            return []
        if play_type(hand)[0]:
            return list(hand)
        g = self._groups(hand)
        # 先出长的顺子 / 连对，减牌最快
        for run in sorted(self._runs(g, 1), key=len, reverse=True):
            if len(run) >= 5:
                return [g[s][0] for s in run]
        for run in sorted(self._runs(g, 2), key=len, reverse=True):
            if len(run) >= 3:
                return [c for s in run for c in g[s][:2]]
        for vv in sorted(g):
            if vv <= 14 and len(g[vv]) == 1:
                return [g[vv][0]]
        for vv in sorted(g):
            if vv <= 14 and len(g[vv]) == 2:
                return list(g[vv][:2])
        for vv in sorted(g):
            if len(g[vv]) == 3:
                # 三张单独出也合法（三张牌型）
                return list(g[vv][:3])
        return [min(hand, key=_card_val)]

    def hint(self, who):
        """给玩家一个建议（界面上的「提示」按钮用）。"""
        hand = self.hands.get(who) or []
        if not hand:
            return []
        need = self.last_type if (self.last and self.last[0] != who) else None
        if need and need[0]:
            return self._find_beats(hand, need, allow_bomb=True)
        return self._pick_lead(hand)

    # ---- AI ----
    def ai_play(self, who):
        """AI 决定这一手出什么。返回要出的牌（list），空表示 pass。"""
        hand = self.hands.get(who) or []
        if not hand:
            return []
        need = self.last_type if (self.last and self.last[0] != who) else None
        last_who = self.last[0] if self.last else 0
        pt_all = play_type(hand)
        # 一手能把整手牌走完，直接走（头家也一样）
        if pt_all[0] and (not need or not need[0] or beats(pt_all, need)):
            return list(hand)
        if not need or not need[0]:
            return self._ai_lead(hand)
        lord_left = len(self.hands.get(1, []))
        me_left = len(hand)
        # 队友（另一个农民）出的牌：地主手上还宽裕就别抢，牌留着自己压地主
        if who in (2, 3) and last_who in (2, 3) and last_who != who:
            if lord_left > 4 and me_left > 2:
                return []
        if me_left <= 2:
            return self._find_beats(hand, need, allow_bomb=True)
        enemy_min = (lord_left if who in (2, 3)
                     else min(len(self.hands.get(2, [])),
                              len(self.hands.get(3, []))))
        best = self._find_beats(hand, need, allow_bomb=enemy_min <= 3)
        if not best:
            return []
        # 手牌还多的时候，别拿 2 / 王去压人家一张小牌
        if len(best) == 1 and me_left > 6 and need[1] <= 12:
            if _card_val(best[0]) >= 15:
                return []
        return best

    def _ai_lead(self, hand):
        """头家出牌：挑「带走最多张、点数又最小」的一手，别把大牌先扔出去。"""
        if not hand:
            return []
        if play_type(hand)[0]:
            return list(hand)
        g = self._groups(hand)
        options = []
        for run in self._runs(g, 1):
            if len(run) >= 5:
                options.append([g[s][0] for s in run])
        for run in self._runs(g, 2):
            if len(run) >= 3:
                options.append([c for s in run for c in g[s][:2]])
        for vv in sorted(g):
            if len(g[vv]) == 3:                 # 三带一（不拆炸弹）
                cs = list(g[vv][:3])
                single = next((g[v2][0] for v2 in sorted(g)
                               if v2 != vv and len(g[v2]) == 1), None)
                if single is not None:
                    cs = cs + [single]
                options.append(cs)
        for vv in sorted(g):
            if len(g[vv]) == 2 and vv <= 14 and len(g[vv]) != 4:
                options.append(list(g[vv][:2]))
        for vv in sorted(g):
            if len(g[vv]) == 1 and vv <= 15:
                options.append([g[vv][0]])
        best, best_key = None, None
        for cs in options:
            pt = play_type(cs)
            if not pt[0]:
                continue
            key = (-len(cs), max(_card_val(c) for c in cs))
            if best_key is None or key < best_key:
                best_key, best = key, cs
        return best or [min(hand, key=_card_val)]

    def _ai_follow(self, hand, need):
        return self._find_beats(hand, need, allow_bomb=True)


# ===================== 一对一 21 点 =====================
# 21 点的点数要按 A=1/11、JQK=10 算，所以不能直接用斗地主的 _rank（那个是从 3 起）
def bj_value(cards):
    total = 0
    aces = 0
    for c in cards:
        if c >= 52:
            total += 10
            continue
        v = c % 13 + 1          # 1..13 => A,2..K
        if v == 1:
            aces += 1
            total += 11
        elif v >= 11:
            total += 10
        else:
            total += v
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


class Blackjack(object):
    """1 对 1：你先摸，对家（真人或 AI）后摸，21 点最大、爆点输。"""

    def __init__(self):
        self.reset()

    def reset(self):
        deck = [c for c in new_deck() if c < 52]
        random.shuffle(deck)
        self.deck = deck
        self.me = [self._draw(), self._draw()]
        self.opp = [self._draw(), self._draw()]
        self.done = False
        self.win = 0

    def _draw(self):
        if not self.deck:
            self.deck = [c for c in new_deck() if c < 52]
            random.shuffle(self.deck)
        return self.deck.pop()

    def my_value(self):
        return bj_value(self.me)

    def opp_value(self):
        return bj_value(self.opp)

    def hit(self):
        if self.done:
            return False
        self.me.append(self._draw())
        if bj_value(self.me) > 21:
            self.finish()
        return True

    def _ai_should_hit(self):
        """对家的策略：11 点以下一定摸；12~16 只有软牌（A 能当 1）才摸；17 以上停。

        以前是「不到 17 就一律摸」，等于硬 12 也去赌，爆点率高得离谱。
        """
        v = bj_value(self.opp)
        if v <= 11:
            return True
        if v >= 17:
            return False
        hard = 0
        has_ace = False
        for c in self.opp:
            if c >= 52:
                hard += 10
            else:
                r = c % 13 + 1
                if r == 1:
                    has_ace = True
                    hard += 1
                elif r >= 11:
                    hard += 10
                else:
                    hard += r
        if has_ace and hard <= 16:
            return v <= 17
        return False

    def stand(self):
        """停牌：对家按上面的策略摸到该停的点数。"""
        if self.done:
            return False
        guard = 0
        while self._ai_should_hit() and len(self.opp) < 21 and guard < 20:
            self.opp.append(self._draw())
            guard += 1
        self.finish()
        return True

    def finish(self):
        self.done = True
        a = bj_value(self.me)
        b = bj_value(self.opp)
        if a > 21:
            self.win = 2
        elif b > 21:
            self.win = 1
        elif a > b:
            self.win = 1
        elif a < b:
            self.win = 2
        else:
            self.win = 0
        return self.win


# ===================== 三连棋 =====================
class Tic(object):
    SIZE = 3
    LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8),
             (0, 3, 6), (1, 4, 7), (2, 5, 8),
             (0, 4, 8), (2, 4, 6))

    def __init__(self):
        self.reset()

    def reset(self):
        self.cells = [0] * 9
        self.moves = 0

    def place(self, idx, who):
        if not (0 <= idx < 9) or self.cells[idx]:
            return False
        self.cells[idx] = who
        self.moves += 1
        return True

    def winner(self):
        for a, b, c in self.LINES:
            if self.cells[a] and self.cells[a] == self.cells[b] == self.cells[c]:
                return self.cells[a]
        return 0

    def full(self):
        return self.moves >= 9

    def winner_line(self):
        """三连棋的获胜三格（界面用来把这三个格子标出来）。"""
        for a, b, c in self.LINES:
            if self.cells[a] and self.cells[a] == self.cells[b] == self.cells[c]:
                return [a, b, c]
        return []

    def ai_move(self, me=2):
        """能赢就赢、能拦就拦，剩下按 minimax 走。"""
        opp = 3 - me
        for who in (me, opp):
            for i in range(9):
                if not self.cells[i]:
                    self.cells[i] = who
                    if self.winner() == who:
                        self.cells[i] = 0
                        return i
                    self.cells[i] = 0
        empties = [i for i in range(9) if not self.cells[i]]
        best = None
        best_v = -99
        for i in empties:
            self.cells[i] = me
            v = self._minimax(opp, me, 0)
            self.cells[i] = 0
            if v > best_v:
                best_v = v
                best = i
        return best if best is not None else (empties[0] if empties else 4)

    def _minimax(self, turn, me, depth):
        w = self.winner()
        if w == me:
            return 10 - depth
        if w and w != me:
            return depth - 10
        scores = []
        for i in range(9):
            if not self.cells[i]:
                self.cells[i] = turn
                scores.append(self._minimax(3 - turn, me, depth + 1))
                self.cells[i] = 0
        if not scores:          # 棋盘满了还没分出胜负：平局
            return 0
        return max(scores) if turn == me else min(scores)


# ===================== 猜拳 =====================
RPS_NAMES = ("石头", "剪刀", "布")


def rps_result(mine, opp):
    """0/1/2 → 1 我赢, 2 我输, 0 平。规则：石头胜剪刀、剪刀胜布、布胜石头。

    注意顺序是 石头0 / 剪刀1 / 布2，所以「我赢」是 (mine-opp)%3 == 2；
    以前写成 == 1，结果石头打剪刀被判成输，这是老 bug。
    """
    if mine == opp:
        return 0
    return 1 if (mine - opp) % 3 == 2 else 2


def rps_ai(history=None):
    """对手最近出得最多的那手，我就出能克它的那一手；没历史就随机。"""
    if history:
        cnt = [0, 0, 0]
        for h in list(history)[-10:]:
            if h in (0, 1, 2):
                cnt[h] += 1
        if sum(cnt) >= 2:
            pick = cnt.index(max(cnt))      # 对手最常出的
            if (pick + 1) % 3 == pick:      # 理论上不会发生，保险
                return random.randint(0, 2)
            return (pick + 1) % 3
    return random.randint(0, 2)
