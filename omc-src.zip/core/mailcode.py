# -*- coding: utf-8 -*-
"""邮箱验证码：用发信邮箱（QQ 邮箱）把 6 位码发到用户填的邮箱。

发信配置放在配置里的 smtp 一段：
    {"host": "smtp.qq.com", "port": 465, "ssl": true,
     "user": "你的QQ邮箱@qq.com", "password": "授权码", "to": ""}
QQ 邮箱要用「授权码」不是登录密码，在 QQ 邮箱设置里开启 SMTP 后拿到。
"""
import random
import time

from core import mailbox

CODES = {}          # email -> {"code": "123456", "expire": 秒, "sent": 秒}
GAP = 10            # 两次发码至少隔 10 秒
LIFE = 600          # 6 位码 10 分钟有效


def send_code(email, smtp_conf, dev_ok=False):
    """发一封验证码邮件，返回 (ok, 说明, 验证码或空)。"""
    email = (email or "").strip().lower()
    if not email or "@" not in email:
        return False, "邮箱格式不对", ""
    now = time.time()
    old = CODES.get(email) or {}
    if old.get("sent") and now - old["sent"] < GAP:
        left = int(GAP - (now - old["sent"]))
        return False, "刚发过一封，%d 秒后再试" % left, ""

    code = "%06d" % random.randint(0, 999999)
    conf = dict(smtp_conf or {})
    subject = "OMC 启动器验证码：%s" % code
    body = ("这是 OMC 启动器的邮箱验证码，10 分钟内有效。\n\n"
            "验证码：%s\n\n"
            "不是你要的就忽略这封邮件。") % code
    ok, why = mailbox.smtp_send(conf, subject, body, to=email)
    if not ok:
        if not dev_ok:
            return False, "发信失败：%s\n（账号页右上角「发信邮箱」里检查 QQ 邮箱和授权码）" % why, ""
        CODES[email] = {"code": code, "expire": now + LIFE, "sent": now}
        return True, "没配发信邮箱，验证码显示在下面", code

    CODES[email] = {"code": code, "expire": now + LIFE, "sent": now}
    return True, "验证码已发到 %s，10 分钟内有效" % email, ""


def verify(email, code):
    """校验验证码，成功后作废。"""
    email = (email or "").strip().lower()
    code = (code or "").strip()
    item = CODES.get(email)
    if not item:
        return False, "先点「发送验证码」"
    if time.time() > item.get("expire", 0):
        CODES.pop(email, None)
        return False, "验证码已过期，重新发一封"
    if code != item.get("code"):
        return False, "验证码不对"
    CODES.pop(email, None)
    return True, "邮箱已验证"


def peek(email):
    """本地没配发信时的兜底：把码显示出来（dev 用）。"""
    item = CODES.get((email or "").strip().lower()) or {}
    return item.get("code") or ""
