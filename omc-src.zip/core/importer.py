# -*- coding: utf-8 -*-
"""拖进 OMC 的任意文件 / 文件夹：判断它是什么，并装到该去的位置。

判定只看内部结构，不看文件名，改过名的也认得出。
"""
import json
import os
import shutil
import tempfile
import zipfile

KIND_LABELS = {
    "mod": "模组",
    "resourcepack": "材质包",
    "shader": "光影",
    "world": "存档",
    "version": "版本",
    "modpack": "整合包",
    "skin": "皮肤",
    "unknown": "未知",
}

SKIN_SIZES = {(64, 64), (64, 32), (128, 128), (256, 256), (32, 32)}


def _zip_names(path):
    try:
        with zipfile.ZipFile(path) as z:
            return [n.replace("\\", "/").lower() for n in z.namelist()]
    except Exception:
        return []


def _png_size(path):
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.size
    except Exception:
        return (0, 0)


def _json_of(path, depth=1):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _by_names(names):
    """按压缩包里的条目瘦判断。"""
    if not names:
        return "unknown"
    lower = set(names)
    if "fabric.mod.json" in lower or "mcmod.info" in lower:
        return "mod"
    if "meta-inf/mods.toml" in lower or "meta-inf/neoforge.mods.toml" in lower:
        return "mod"
    if "modrinth.index.json" in lower or "manifest.json" in lower:
        return "modpack"
    if any(n.startswith("shaders/") for n in lower):
        return "shader"
    if "pack.mcmeta" in lower:
        return "resourcepack"
    if any(n.endswith(".vsh") or n.endswith(".fsh") for n in lower) \
            and any(n.startswith("shaders/") or "shader" in n for n in lower):
        return "shader"
    if any(n.startswith("mods/") and n.endswith(".jar") for n in lower):
        return "modpack"
    # 存档包：<名字>/level.dat（可能在根，也可能套一层文件夹）
    if any(n == "level.dat" or n.endswith("/level.dat") for n in lower):
        return "world"
    # 版本包：versions/<名字>/<名字>.json
    if any(n.startswith("versions/") and n.endswith(".json")
           for n in lower):
        return "version"
    return "unknown"


def _detect_dir(path):
    name = os.path.basename(path.rstrip("\\/"))

    if os.path.isfile(os.path.join(path, "level.dat")):
        return "world"

    if os.path.isfile(os.path.join(path, name + ".json")):
        j = _json_of(os.path.join(path, name + ".json"))
        if isinstance(j, dict) and ("id" in j or "inheritsFrom" in j
                                    or "libraries" in j):
            return "version"

    if os.path.isfile(os.path.join(path, "modrinth.index.json")) or \
            os.path.isfile(os.path.join(path, "manifest.json")):
        return "modpack"

    if os.path.isdir(os.path.join(path, "mods")) and \
            any(f.endswith(".jar") for f in os.listdir(os.path.join(path, "mods"))):
        return "modpack"

    if os.path.isdir(os.path.join(path, "shaders")) or \
            os.path.isfile(os.path.join(path, "shaders", "composite.vsh")):
        return "shader"

    if os.path.isfile(os.path.join(path, "pack.mcmeta")):
        return "resourcepack"

    if os.path.isfile(os.path.join(path, "META-INF", "mods.toml")) or \
            os.path.isfile(os.path.join(path, "META-INF", "neoforge.mods.toml")) \
            or os.path.isfile(os.path.join(path, "fabric.mod.json")):
        return "mod"

    # 只有一堆 jar 的文件夹，按整合包处理
    jars = [f for f in os.listdir(path) if f.lower().endswith(".jar")]
    if jars:
        return "modpack"
    return "unknown"


def detect(path):
    """-> (kind, 说明文本)"""
    if not os.path.exists(path):
        return "unknown", "路径读不到"
    if os.path.isdir(path):
        return _detect_dir(path), ""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".jar":
        return _by_names(_zip_names(path)), ""
    if ext == ".zip":
        return _by_names(_zip_names(path)), ""
    if ext in (".png", ".jpg", ".jpeg"):
        w, h = _png_size(path)
        if (w, h) in SKIN_SIZES and (w == h or w == h * 2):
            return "skin", ""
        return "unknown", "图片尺寸 %dx%d 不像 MC 皮肤" % (w, h)
    return "unknown", "不认识这个类型"


def _copy_tree(src, dst):
    if os.path.exists(dst):
        raise RuntimeError("目标已存在：%s" % os.path.basename(dst))
    shutil.copytree(src, dst)


def _zip_dir(src, dst):
    """把解压后的文件夹压成 zip。

    光影 / 材质包在游戏里只认 zip，所以拖文件夹进来时自动压一层；
    zip 内的路径相对源文件夹本身，shaders/ 或 pack.mcmeta 就在根上。
    """
    root_depth = src.rstrip("\\/")
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for cur, _dirs, files in os.walk(root_depth):
            for f in files:
                full = os.path.join(cur, f)
                rel = os.path.relpath(full, root_depth).replace("\\", "/")
                try:
                    z.write(full, rel)
                except Exception:
                    continue
    return dst


def _find_payload_dir(root, kind):
    """zip 解开后找真正的那一层：可能直接是内容，也可能外面套了一层文件夹。"""
    if _detect_dir(root) == kind:
        return root
    for cur, dirs, _files in os.walk(root):
        if cur == root:
            continue
        if _detect_dir(cur) == kind:
            return cur
    return root


def import_all(paths, game_dir, log=lambda *_: None):
    """返回 [(路径, kind, 是否成功, 说明)]，unknown 的也会带一条。"""
    from core import skins

    results = []
    mods_dir = os.path.join(game_dir, "mods")
    packs_dir = os.path.join(game_dir, "resourcepacks")
    shaders_dir = os.path.join(game_dir, "shaderpacks")
    saves_dir = os.path.join(game_dir, "saves")
    versions_dir = os.path.join(game_dir, "versions")

    for p in paths:
        kind, note = detect(p)
        try:
            if kind == "unknown":
                results.append((p, kind, False, note or "认不出这是什么"))
                continue

            if kind == "skin":
                dest = skins.import_skin(p)
                results.append((p, kind, True,
                                "已导入皮肤库：" + os.path.basename(str(dest))))
                continue

            if kind == "mod":
                if os.path.isdir(p):
                    raise RuntimeError("这是个文件夹，不是单个模组文件")
                os.makedirs(mods_dir, exist_ok=True)
                dst = os.path.join(mods_dir, os.path.basename(p))
                shutil.copy2(p, dst)
                results.append((p, kind, True, "已装进 mods"))
                continue

            if kind in ("resourcepack", "shader"):
                dst_dir = shaders_dir if kind == "shader" else packs_dir
                os.makedirs(dst_dir, exist_ok=True)
                if os.path.isdir(p):
                    # 解压后的光影 / 材质包文件夹：自动压成 zip 再放进去
                    name = os.path.basename(p.rstrip("\\/")) or "pack"
                    dst = os.path.join(dst_dir, name + ".zip")
                    if os.path.exists(dst):
                        dst = os.path.join(dst_dir, name + "-导入.zip")
                    _zip_dir(p, dst)
                    results.append((p, kind, True,
                                    "文件夹已压成 %s，放进 %s"
                                    % (os.path.basename(dst),
                                       os.path.basename(dst_dir))))
                    continue
                dst = os.path.join(dst_dir, os.path.basename(p))
                shutil.copy2(p, dst)
                results.append((p, kind, True,
                                "已装进 " + os.path.basename(dst_dir)))
                continue

            if kind in ("world", "version"):
                base = saves_dir if kind == "world" else versions_dir
                os.makedirs(base, exist_ok=True)
                if os.path.isdir(p):
                    name = os.path.basename(p.rstrip("\\/"))
                else:
                    name = os.path.splitext(os.path.basename(p))[0]
                dst = os.path.join(base, name)
                if os.path.exists(dst):
                    dst = dst + "-导入"
                if os.path.isdir(p):
                    _copy_tree(p, dst)
                else:
                    # 存档 / 版本打成 zip 拖进来：先解开，再找里面那一层
                    tmp = tempfile.mkdtemp(prefix="omc_unzip_")
                    try:
                        with zipfile.ZipFile(p) as z:
                            z.extractall(tmp)
                        _copy_tree(_find_payload_dir(tmp, kind), dst)
                    finally:
                        shutil.rmtree(tmp, ignore_errors=True)
                results.append((p, kind, True,
                                "已复制到 " + os.path.basename(base)))
                continue

            if kind == "modpack":
                jars = _collect_modpack_jars(p)
                if not jars:
                    results.append((p, kind, False, "整合包里没找到 mods/*.jar"))
                    continue
                os.makedirs(mods_dir, exist_ok=True)
                n = 0
                for j in jars:
                    dst = os.path.join(mods_dir, os.path.basename(j))
                    if not os.path.exists(dst):
                        shutil.copy2(j, dst)
                        n += 1
                results.append((p, kind, True,
                                "整合包：装了 %d 个模组（config 等配置没搬）" % n))
                continue

            results.append((p, kind, False, "没有对应的处理方式"))
        except Exception as e:
            results.append((p, kind, False, str(e)))
    return results


def _collect_modpack_jars(path):
    jars = []
    if os.path.isdir(path):
        m = os.path.join(path, "mods")
        base = m if os.path.isdir(m) else path
        for root, _dirs, files in os.walk(base):
            for f in files:
                if f.lower().endswith(".jar"):
                    jars.append(os.path.join(root, f))
        return jars
    tmp = tempfile.mkdtemp(prefix="omc_pack_")
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if n.lower().endswith(".jar"):
                z.extract(n, tmp)
                jars.append(os.path.join(tmp, *n.split("/")))
    return jars
