# -*- coding: utf-8 -*-
"""RNG 附魔操控核心：复刻 Minecraft 1.21 附魔台的随机数算法。

算法来源：Earthcomputer/EnchantmentCracker 的 Enchantments.java / Items.java
（视频「附魔操控！一键满强！2025 最新的 RNG 附魔教程」用的就是这套）。

能做三件事：
1. 给一个 XP 种子（存档里的 XpSeed，或破解出来的 xpSeed），预测当前附魔台
   三个槽位分别会出什么附魔。
2. 只看附魔台上显示的三个等级数字，反推 XP 种子（后台多进程扫描）。
3. 给目标附魔，算「先扔几件物品、摆几个书架、点第几个槽位」。

**注意**：Paper / Purpur / Leaves 等服务端改过随机数，预测会失效，只在原版
（含 Fabric / Forge 单人开服）可用。
"""
import math

MASK48 = (1 << 48) - 1
MULT = 0x5DEECE66D
ADD = 0xB

# ---------------------------------------------------------------- Java Random


class JavaRandom(object):
    """java.util.Random 的逐位复刻（seed 是 48 位）。"""

    __slots__ = ("seed",)

    def __init__(self, seed=0):
        self.set_seed(seed)

    def set_seed(self, s):
        self.seed = (int(s) ^ MULT) & MASK48

    def next(self, bits):
        self.seed = (self.seed * MULT + ADD) & MASK48
        return self.seed >> (48 - bits)

    def next_int(self, bound):
        if bound <= 0:
            raise ValueError("bound must be positive")
        if bound & (bound - 1) == 0:
            # 2 的幂走快路径：(bound * next(31)) >> 31
            return (bound * self.next(31)) >> 31
        while True:
            r = self.next(31)
            v = r % bound
            if r - v + (bound - 1) < 0x80000000:
                return v

    def next_float(self):
        return self.next(24) / float(1 << 24)


def _f32(x):
    """按 Java float（单精度）取整，附魔等级修正要它才不会差 1。"""
    import struct
    return struct.unpack("<f", struct.pack("<f", float(x)))[0]


def _java_round(v):
    """Math.round(float)：floor(v + 0.5f)，按单精度算。"""
    return int(math.floor(_f32(_f32(v) + 0.5)))


# ---------------------------------------------------------------- 附魔数据

# 附魔台池的顺序（weightedRandom 依赖这个顺序，必须一致）
TABLE_ENCHANTS = [
    "protection", "fire_protection", "feather_falling", "blast_protection",
    "projectile_protection", "respiration", "aqua_affinity", "thorns",
    "depth_strider", "sharpness", "smite", "bane_of_arthropods", "knockback",
    "fire_aspect", "looting", "sweeping", "efficiency", "silk_touch",
    "unbreaking", "fortune", "power", "punch", "flame", "infinity",
    "luck_of_the_sea", "lure", "loyalty", "impaling", "riptide", "channeling",
    "multishot", "quick_charge", "piercing", "density", "breach", "lunge",
]

MAX_LEVEL = {
    "sharpness": 5, "smite": 5, "bane_of_arthropods": 5, "efficiency": 5,
    "power": 5, "impaling": 5, "density": 5,
    "protection": 4, "fire_protection": 4, "blast_protection": 4,
    "projectile_protection": 4, "feather_falling": 4, "piercing": 4, "breach": 4,
    "thorns": 3, "depth_strider": 3, "respiration": 3, "looting": 3, "sweeping": 3,
    "fortune": 3, "luck_of_the_sea": 3, "lure": 3, "unbreaking": 3, "loyalty": 3,
    "riptide": 3, "quick_charge": 3, "soul_speed": 3, "wind_burst": 3, "lunge": 3,
    "frost_walker": 2, "knockback": 2, "fire_aspect": 2, "punch": 2,
    "aqua_affinity": 1, "binding_curse": 1, "silk_touch": 1, "flame": 1,
    "infinity": 1, "mending": 1, "vanishing_curse": 1, "channeling": 1,
    "multishot": 1,
}

MIN_COST = {
    "protection": lambda l: 1 + (l - 1) * 11,
    "fire_protection": lambda l: 10 + (l - 1) * 8,
    "feather_falling": lambda l: 5 + (l - 1) * 6,
    "blast_protection": lambda l: 5 + (l - 1) * 8,
    "projectile_protection": lambda l: 3 + (l - 1) * 6,
    "respiration": lambda l: l * 10,
    "aqua_affinity": lambda l: 1,
    "thorns": lambda l: 10 + (l - 1) * 20,
    "depth_strider": lambda l: l * 10,
    "frost_walker": lambda l: l * 10,
    "binding_curse": lambda l: 25,
    "sharpness": lambda l: 1 + (l - 1) * 11,
    "smite": lambda l: 5 + (l - 1) * 8,
    "bane_of_arthropods": lambda l: 5 + (l - 1) * 8,
    "knockback": lambda l: 5 + (l - 1) * 20,
    "fire_aspect": lambda l: 10 + (l - 1) * 20,
    "looting": lambda l: 15 + (l - 1) * 9,
    "sweeping": lambda l: 5 + (l - 1) * 9,
    "efficiency": lambda l: 1 + (l - 1) * 10,
    "silk_touch": lambda l: 15,
    "unbreaking": lambda l: 5 + (l - 1) * 8,
    "fortune": lambda l: 15 + (l - 1) * 9,
    "power": lambda l: 1 + (l - 1) * 10,
    "punch": lambda l: 12 + (l - 1) * 20,
    "flame": lambda l: 20,
    "infinity": lambda l: 20,
    "luck_of_the_sea": lambda l: 15 + (l - 1) * 9,
    "lure": lambda l: 15 + (l - 1) * 9,
    "mending": lambda l: 25,
    "vanishing_curse": lambda l: 25,
    "loyalty": lambda l: 5 + l * 7,
    "impaling": lambda l: 1 + (l - 1) * 8,
    "riptide": lambda l: 10 + l * 7,
    "channeling": lambda l: 25,
    "multishot": lambda l: 20,
    "quick_charge": lambda l: 12 + (l - 1) * 20,
    "piercing": lambda l: 1 + (l - 1) * 10,
    "soul_speed": lambda l: l * 10,
    "density": lambda l: 5 + (l - 1) * 8,
    "breach": lambda l: 15 + (l - 1) * 9,
    "wind_burst": lambda l: 15 + (l - 1) * 9,
    "lunge": lambda l: 5 + (l - 1) * 8,
}

MAX_COST = {
    "protection": lambda l: 1 + l * 11,
    "fire_protection": lambda l: 10 + l * 8,
    "feather_falling": lambda l: 5 + l * 6,
    "blast_protection": lambda l: 5 + l * 8,
    "projectile_protection": lambda l: 3 + l * 6,
    "respiration": lambda l: 30 + l * 10,
    "aqua_affinity": lambda l: 41,
    "thorns": lambda l: 40 + l * 20,
    "depth_strider": lambda l: 15 + l * 10,
    "frost_walker": lambda l: 15 + l * 10,
    "binding_curse": lambda l: 50,
    "sharpness": lambda l: 21 + (l - 1) * 11,
    "smite": lambda l: 25 + (l - 1) * 8,
    "bane_of_arthropods": lambda l: 25 + (l - 1) * 8,
    "knockback": lambda l: 55 + (l - 1) * 20,
    "fire_aspect": lambda l: 40 + l * 20,
    "looting": lambda l: 65 + (l - 1) * 9,
    "sweeping": lambda l: 20 + (l - 1) * 9,
    "efficiency": lambda l: 50 + l * 10,
    "silk_touch": lambda l: 65,
    "unbreaking": lambda l: 55 + (l - 1) * 8,
    "fortune": lambda l: 65 + (l - 1) * 9,
    "power": lambda l: 16 + (l - 1) * 10,
    "punch": lambda l: 37 + (l - 1) * 20,
    "flame": lambda l: 50,
    "infinity": lambda l: 50,
    "luck_of_the_sea": lambda l: 65 + (l - 1) * 9,
    "lure": lambda l: 65 + (l - 1) * 9,
    "mending": lambda l: 75,
    "vanishing_curse": lambda l: 50,
    "loyalty": lambda l: 50,
    "impaling": lambda l: 21 + (l - 1) * 8,
    "riptide": lambda l: 50,
    "channeling": lambda l: 50,
    "multishot": lambda l: 50,
    "quick_charge": lambda l: 50,
    "piercing": lambda l: 50,
    "soul_speed": lambda l: 15 + l * 10,
    "density": lambda l: 25 + (l - 1) * 8,
    "breach": lambda l: 65 + (l - 1) * 9,
    "wind_burst": lambda l: 65 + (l - 1) * 9,
    "lunge": lambda l: 25 + (l - 1) * 8,
}

WEIGHT = {}
for _e in ("protection", "sharpness", "efficiency", "power", "piercing"):
    WEIGHT[_e] = 10
for _e in ("fire_protection", "feather_falling", "projectile_protection", "smite",
           "bane_of_arthropods", "knockback", "unbreaking", "loyalty",
           "quick_charge", "density", "lunge"):
    WEIGHT[_e] = 5
for _e in ("blast_protection", "respiration", "aqua_affinity", "depth_strider",
           "frost_walker", "fire_aspect", "looting", "sweeping", "fortune",
           "punch", "flame", "luck_of_the_sea", "lure", "mending", "impaling",
           "riptide", "multishot", "breach", "wind_burst"):
    WEIGHT[_e] = 2
for _e in ("thorns", "binding_curse", "silk_touch", "infinity",
           "vanishing_curse", "channeling", "soul_speed"):
    WEIGHT[_e] = 1

ENCH_CN = {
    "protection": "保护", "fire_protection": "火焰保护",
    "feather_falling": "摔落保护", "blast_protection": "爆炸保护",
    "projectile_protection": "弹射物保护", "respiration": "水下呼吸",
    "aqua_affinity": "水下速掘", "thorns": "荆棘", "depth_strider": "深海探索者",
    "frost_walker": "冰霜行者", "binding_curse": "绑定诅咒",
    "sharpness": "锋利", "smite": "亡灵杀手", "bane_of_arthropods": "节肢杀手",
    "knockback": "击退", "fire_aspect": "火焰附加", "looting": "抢夺",
    "sweeping": "横扫之刃", "efficiency": "效率", "silk_touch": "精准采集",
    "unbreaking": "耐久", "fortune": "时运", "power": "力量", "punch": "冲击",
    "flame": "火矢", "infinity": "无限", "luck_of_the_sea": "海之眷顾",
    "lure": "饵钓", "mending": "经验修补", "vanishing_curse": "消失诅咒",
    "loyalty": "忠诚", "impaling": "穿刺", "riptide": "激流",
    "channeling": "引雷", "multishot": "多重射击", "quick_charge": "快速装填",
    "piercing": "穿透", "soul_speed": "灵魂疾行", "density": "密度",
    "breach": "破甲", "wind_burst": "风爆", "lunge": "突刺",
}

ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V"}


def ench_label(eid, level):
    name = ENCH_CN.get(eid, eid)
    if level == 1 and MAX_LEVEL.get(eid, 1) == 1:
        return name
    return "%s %s" % (name, ROMAN.get(level, str(level)))


# ---------------------------------------------------------------- 物品

_MATERIAL_CN = {
    "netherite": "下界合金", "diamond": "钻石", "golden": "金", "iron": "铁",
    "chainmail": "锁链", "copper": "铜", "stone": "石", "wooden": "木",
    "leather": "皮革", "turtle": "海龟",
}
_TYPE_CN = {
    "sword": "剑", "pickaxe": "镐", "axe": "斧", "shovel": "锹", "hoe": "锄",
    "helmet": "头盔", "chestplate": "胸甲", "leggings": "护腿", "boots": "靴子",
    "bow": "弓", "crossbow": "弩", "trident": "三叉戟", "mace": "重锤",
    "fishing_rod": "钓鱼竿", "book": "书", "shears": "剪刀",
}

_TOOL_MATS = ["netherite", "diamond", "golden", "iron", "copper", "stone", "wooden"]
_ARMOR_MATS = ["netherite", "diamond", "golden", "iron", "chainmail", "copper",
               "turtle", "leather"]

# (key, 显示名) 按这个顺序展示
RNG_ITEMS = []
for _mat in _TOOL_MATS:
    for _t in ("sword", "pickaxe", "axe", "shovel", "hoe"):
        RNG_ITEMS.append(("%s_%s" % (_mat, _t),
                          "%s%s" % (_MATERIAL_CN[_mat], _TYPE_CN[_t])))
for _mat in _ARMOR_MATS:
    for _t in ("helmet", "chestplate", "leggings", "boots"):
        if _mat == "turtle" and _t != "helmet":
            continue
        RNG_ITEMS.append(("%s_%s" % (_mat, _t),
                          "%s%s" % (_MATERIAL_CN[_mat], _TYPE_CN[_t])))
for _t in ("bow", "crossbow", "trident", "mace", "fishing_rod", "book", "shears"):
    RNG_ITEMS.append((_t, _TYPE_CN[_t]))

ITEM_CN = dict(RNG_ITEMS)


def item_label(key):
    return ITEM_CN.get(key, key)


def _family(key):
    return key.rsplit("_", 1)[-1] if "_" in key else key


def _mat(key):
    return key.rsplit("_", 1)[0] if "_" in key else ""


def is_armor(key):
    return _family(key) in ("helmet", "chestplate", "leggings", "boots")


def is_helmet(key):
    return _family(key) == "helmet"


def is_chestplate(key):
    return _family(key) == "chestplate"


def is_boots(key):
    return _family(key) == "boots"


def _is_tool_mat(key):
    return _family(key) in ("pickaxe", "axe", "shovel", "hoe")


def is_tool(key):
    return _is_tool_mat(key)


def is_sword(key):
    return _family(key) == "sword"


def is_axe(key):
    return _family(key) == "axe"


def has_durability(key):
    return (is_armor(key) or is_tool(key) or is_sword(key)
            or _family(key) in ("bow", "crossbow", "trident", "mace",
                                "fishing_rod", "shears"))


def enchantability(key):
    fam, mat = _family(key), _mat(key)
    if is_armor(key):
        return {"leather": 15, "iron": 9, "chainmail": 12, "golden": 25,
                "diamond": 10, "turtle": 9, "netherite": 15, "copper": 8}.get(mat, 0)
    if fam in ("sword", "pickaxe", "axe", "shovel", "hoe"):
        return {"wooden": 15, "stone": 5, "iron": 14, "golden": 22,
                "diamond": 10, "netherite": 15, "copper": 13}.get(mat, 0)
    if fam in ("bow", "fishing_rod", "trident", "crossbow", "book"):
        return 1
    if fam == "mace":
        return 15
    return 0


_ARMOR_ONLY = ("protection", "fire_protection", "blast_protection",
               "projectile_protection")
_BOOTS_ONLY = ("feather_falling", "depth_strider", "frost_walker", "soul_speed")
_HELMET_ONLY = ("respiration", "aqua_affinity")
_SWORD_ENCH = ("sharpness", "smite", "bane_of_arthropods")
_BOW_ENCH = ("power", "punch", "flame", "infinity")
_FISH_ENCH = ("luck_of_the_sea", "lure")
_TRIDENT_ENCH = ("loyalty", "impaling", "riptide", "channeling")
_CROSSBOW_ENCH = ("multishot", "quick_charge", "piercing")
_MACE_ENCH = ("density", "breach", "wind_burst")


def can_apply(eid, key, primary=True):
    """某附魔能不能上到某件物品上（对应 Enchantments.canApply）。"""
    if key == "book":
        return True
    fam = _family(key)
    if eid in _ARMOR_ONLY:
        return is_armor(key)
    if eid == "thorns":
        return is_chestplate(key) if primary else is_armor(key)
    if eid in _BOOTS_ONLY:
        return is_boots(key)
    if eid in _HELMET_ONLY:
        return is_helmet(key)
    if eid == "binding_curse":
        return is_armor(key)
    if eid in _SWORD_ENCH:
        if is_sword(key):
            return True
        if not primary:
            return is_axe(key) or fam == "mace"
        return False
    if eid == "fire_aspect":
        if is_sword(key):
            return True
        return (not primary) and fam == "mace"
    if eid in ("knockback", "looting"):
        return is_sword(key)
    if eid == "sweeping":
        return is_sword(key)
    if eid == "efficiency":
        return is_tool(key) or (not primary and fam == "shears")
    if eid in ("silk_touch", "fortune"):
        return is_tool(key)
    if eid in _BOW_ENCH:
        return fam == "bow"
    if eid in _FISH_ENCH:
        return fam == "fishing_rod"
    if eid in ("unbreaking", "mending"):
        return has_durability(key)
    if eid == "vanishing_curse":
        return has_durability(key)
    if eid in _TRIDENT_ENCH:
        return fam == "trident"
    if eid in _CROSSBOW_ENCH:
        return fam == "crossbow"
    if eid in _MACE_ENCH:
        return fam == "mace"
    if eid == "lunge":
        return fam == "trident"
    return False


# ---------------------------------------------------------------- 互斥


def _is_pow2(b):
    return b & (b - 1) == 0


_DAMAGE_GROUP = ("sharpness", "smite", "bane_of_arthropods", "density", "breach")
_PROT_GROUP = ("protection", "blast_protection", "fire_protection",
               "projectile_protection")


def are_compatible(a, b):
    if a == b:
        return False
    if (a == "infinity" and b == "mending") or (b == "infinity" and a == "mending"):
        return False
    if a in _DAMAGE_GROUP and b in _DAMAGE_GROUP:
        return False
    if (a == "depth_strider" and b == "frost_walker") or \
       (b == "depth_strider" and a == "frost_walker"):
        return False
    if a == "silk_touch" and b in ("looting", "fortune", "luck_of_the_sea"):
        return False
    if b == "silk_touch" and a in ("looting", "fortune", "luck_of_the_sea"):
        return False
    if (a == "riptide" and b in ("loyalty", "channeling")) or \
       (b == "riptide" and a in ("loyalty", "channeling")):
        return False
    if (a == "multishot" and b == "piercing") or (b == "multishot" and a == "piercing"):
        return False
    if a in _PROT_GROUP and b in _PROT_GROUP:
        return False
    return True


# ---------------------------------------------------------------- 附魔台


def slot_levels(xp_seed, shelves, item):
    """三个槽位显示的等级（和游戏里附魔台上一模一样的三个数字）。"""
    if enchantability(item) == 0:
        return [0, 0, 0]
    rand = JavaRandom(int(xp_seed))
    out = []
    half = shelves >> 1
    for slot in range(3):
        base = rand.next_int(8) + 1 + half + rand.next_int(shelves + 1)
        if slot == 0:
            lv = max(base // 3, 1)
        elif slot == 1:
            lv = base * 2 // 3 + 1
        else:
            lv = max(base, shelves * 2)
        out.append(lv)
    return out


def highest_allowed(level, item):
    """给定强度值，这件物品允许出现的附魔（每个取能出的最高等级）。"""
    res = []
    for eid in TABLE_ENCHANTS:
        if not can_apply(eid, item, True):
            continue
        top = MAX_LEVEL[eid]
        for lv in range(top, 0, -1):
            if MIN_COST[eid](lv) <= level <= MAX_COST[eid](lv):
                res.append((eid, lv))
                break
    return res


def _weighted_random(rand, allowed):
    total = sum(WEIGHT[e] for e, _l in allowed)
    if total <= 0:
        return None
    w = rand.next_int(total)
    for e, lv in allowed:
        w -= WEIGHT[e]
        if w < 0:
            return (e, lv)
    return None


def add_random_enchantments(rand, item, level):
    """复刻 Enchantments.addRandomEnchantments（1.21 口径）。"""
    ench = enchantability(item)
    out = []
    if ench <= 0:
        return out
    level = level + 1 + rand.next_int(ench // 4 + 1) + rand.next_int(ench // 4 + 1)
    pct = _f32(_f32(_f32(rand.next_float() + rand.next_float()) - 1.0) * 0.15)
    level += _java_round(_f32(level * pct))
    if level < 1:
        level = 1
    allowed = highest_allowed(level, item)
    if not allowed:
        return out
    pick = _weighted_random(rand, allowed)
    out.append(pick)
    while rand.next_int(50) <= level:
        allowed = [x for x in allowed if are_compatible(x[0], pick[0])]
        allowed = [x for x in allowed
                   if all(are_compatible(x[0], y[0]) for y in out)]
        if not allowed:
            break
        pick = _weighted_random(rand, allowed)
        out.append(pick)
        level //= 2
    return out


def slot_enchantments(xp_seed, item, slot, level):
    """某个槽位实际开出来的附魔（书会随机丢掉一条，只剩一条）。"""
    rand = JavaRandom(0)
    s = (int(xp_seed) + slot) & 0xFFFFFFFF
    if s >= 0x80000000:
        s -= 0x100000000
    rand.set_seed(s)
    out = add_random_enchantments(rand, item, level)
    if item == "book" and len(out) > 1:
        out.pop(rand.next_int(len(out)))
    return out


def predict(xp_seed, shelves, item):
    """完整预测：三个槽位的等级 + 各自产出。"""
    levels = slot_levels(xp_seed, shelves, item)
    slots = []
    for i in range(3):
        lv = levels[i]
        if lv < i + 1:          # 等级不够，这一格在游戏里是灰的
            slots.append({"slot": i, "level": lv, "usable": False, "enchants": []})
            continue
        slots.append({"slot": i, "level": lv, "usable": True,
                      "enchants": slot_enchantments(xp_seed, item, i, lv)})
    return {"levels": levels, "slots": slots}


# ---------------------------------------------------------------- 破解


def _group_cfg(shelves, want):
    """把一组观测（书架数 + 三个等级）压成快速判定要用的元组。"""
    plus = shelves + 1
    pow2 = (plus & (plus - 1)) == 0
    return (shelves >> 1, plus, shelves * 2, pow2,
            48 - (plus.bit_length() - 1) if pow2 else 0,
            int(want[0]), int(want[1]), int(want[2]))


def _levels_for(xp, cfg):
    """按一组观测算三槽等级，判断是否匹配（与 _scan 同一套算法）。"""
    half, plus, two, pow2, shift, w0, w1, w2 = cfg
    s = (int(xp) ^ MULT) & MASK48
    for slot in range(3):
        s = (s * MULT + ADD) & MASK48
        first = s >> 45
        s = (s * MULT + ADD) & MASK48
        if pow2:
            base = first + 1 + half + (s >> shift)
        else:
            while True:
                r = s >> 17
                v = r % plus
                if r - v + plus - 1 < 0x80000000:
                    base = first + 1 + half + v
                    break
                s = (s * MULT + ADD) & MASK48
        if slot == 0:
            lv = base // 3
            if lv < 1:
                lv = 1
        elif slot == 1:
            lv = base * 2 // 3 + 1
        else:
            lv = max(base, two)
        if lv != (w0, w1, w2)[slot]:
            return False
    return True


def _scan(groups, start, end, cap, prog_path=None, ticks=8):
    """扫 [start, end) 区间的 xpSeed，返回 array('i')。

    第一组内联（走绝大多数命中路径），后面的组只在第一组通过时才验。
    nextInt(8) 等价于取 s 的最高 3 位；书架数+1 是 2 的幂时同理，省一次乘法。
    """
    from array import array
    mult, add, mask = MULT, ADD, MASK48
    cfgs = [_group_cfg(s, w) for s, w in groups]
    half, plus, two, pow2, shift, w0, w1, w2 = cfgs[0]
    rest = cfgs[1:]
    out = array("i")
    ap = out.append
    span = end - start
    blk = max(1, span // max(1, ticks))
    for blk_start in range(start, end, blk):
        blk_end = min(blk_start + blk, end)
        for xp in range(blk_start, blk_end):
            s = (xp ^ mult) & mask
            # ---- 第 1 组：setSeed 后连续 6 次 nextInt
            s = (s * mult + add) & mask
            first = s >> 45
            s = (s * mult + add) & mask
            if pow2:
                base = first + 1 + half + (s >> shift)
            else:
                while True:
                    r = s >> 17
                    v = r % plus
                    if r - v + plus - 1 < 0x80000000:
                        base = first + 1 + half + v
                        break
                    s = (s * mult + add) & mask
            lv0 = base // 3
            if lv0 < 1:
                lv0 = 1
            if lv0 != w0:
                continue

            s = (s * mult + add) & mask
            first = s >> 45
            s = (s * mult + add) & mask
            if pow2:
                base = first + 1 + half + (s >> shift)
            else:
                while True:
                    r = s >> 17
                    v = r % plus
                    if r - v + plus - 1 < 0x80000000:
                        base = first + 1 + half + v
                        break
                    s = (s * mult + add) & mask
            if base * 2 // 3 + 1 != w1:
                continue

            s = (s * mult + add) & mask
            first = s >> 45
            s = (s * mult + add) & mask
            if pow2:
                base = first + 1 + half + (s >> shift)
            else:
                while True:
                    r = s >> 17
                    v = r % plus
                    if r - v + plus - 1 < 0x80000000:
                        base = first + 1 + half + v
                        break
                    s = (s * mult + add) & mask
            if max(base, two) != w2:
                continue

            for cfg in rest:
                if not _levels_for(xp, cfg):
                    break
            else:
                ap(xp if xp < 0x80000000 else xp - 0x100000000)
                if len(out) >= cap:
                    if prog_path:
                        _write_prog(prog_path, (blk_end - start) / float(span))
                    return out
        if prog_path:
            _write_prog(prog_path, (blk_end - start) / float(span))
    return out


def _write_prog(path, frac):
    try:
        with open(path, "w", encoding="ascii") as f:
            f.write("%.4f" % min(1.0, max(0.0, frac)))
    except Exception:
        pass


def matches_levels(xp_seed, shelves, want):
    """某 xpSeed 的三槽等级是否等于这一组观测。"""
    return _levels_for(xp_seed, _group_cfg(shelves, want))


def filter_seeds(seeds, shelves, want):
    """已有候选种子时再喂一组观测，秒级过滤。"""
    cfg = _group_cfg(shelves, want)
    return [s for s in seeds if _levels_for(s, cfg)]


# ------------------------------------------------- 子进程并行（打包后也能用）

SEG = 1 << 24          # 兼容旧接口
RESULT_CAP = 3000000


def _entry_argv():
    import os
    import sys
    if getattr(sys, "frozen", False):
        return [sys.executable]
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return [sys.executable, os.path.join(root, "main.py")]


def encode_groups(groups):
    return "#".join("%d:%d,%d,%d" % (s, w[0], w[1], w[2]) for s, w in groups)


def decode_groups(text):
    groups = []
    for part in text.split("#"):
        if not part.strip():
            continue
        s, nums = part.split(":")
        groups.append((int(s), [int(x) for x in nums.split(",")]))
    return groups


def _arg(argv, name, default=None):
    for i, a in enumerate(argv):
        if a == name and i + 1 < len(argv):
            return argv[i + 1]
    return default


def cli_main(argv):
    """main.py 顶部拦下的破解子进程入口（不加载 Qt）。"""
    import sys
    groups_text = _arg(argv, "--groups")
    out_path = _arg(argv, "--out")
    if not groups_text or not out_path:
        sys.stderr.write("bad args\n")
        return 2
    start = int(_arg(argv, "--start", "-2147483648"))
    end = int(_arg(argv, "--end", "2147483648"))
    cap = int(_arg(argv, "--cap", str(RESULT_CAP)))
    prog = _arg(argv, "--prog")
    res = _scan(decode_groups(groups_text), start, end, cap, prog)
    with open(out_path, "wb") as f:
        if res:
            res.tofile(f)
    if prog:
        _write_prog(prog, 1.0)
    return 0


def default_workers():
    """留出余量的进程数：别把机器占满，否则界面会卡。"""
    import os
    cpus = os.cpu_count() or 4
    return max(2, min(10, cpus - 2))


def crack_all(groups, workers=None, progress=None, should_stop=None,
              cap=RESULT_CAP):
    """开 workers 个子进程各扫一段连续区间。返回 (seeds array, truncated)。

    子进程按「低于正常」优先级跑，前台界面/游戏不会被抢得太狠。
    """
    from array import array
    import os
    import subprocess
    import sys
    import tempfile
    import time

    n = max(1, int(workers or default_workers()))
    total = 1 << 32
    step = total // n
    parts = []
    cur = -0x80000000
    for i in range(n):
        end = 0x80000000 if i == n - 1 else cur + step
        parts.append((cur, end))
        cur = end

    cmd_base = _entry_argv() + ["--rng-crack", "--groups", encode_groups(groups),
                                "--cap", str(cap)]
    seeds = array("i")
    truncated = False
    tmpdir = tempfile.mkdtemp(prefix="omc_rng_")
    procs = []
    for i, (start, end) in enumerate(parts):
        out = os.path.join(tmpdir, "o%d.bin" % i)
        prog = os.path.join(tmpdir, "p%d.txt" % i)
        cmd = cmd_base + ["--start", str(start), "--end", str(end),
                          "--out", out, "--prog", prog]
        kwargs = {}
        if sys.platform == "win32":
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            kwargs["startupinfo"] = si
            # CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS
            kwargs["creationflags"] = 0x08000000 | 0x00004000
        procs.append([subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, **kwargs),
                      out, prog])

    def _kill_all():
        for item in procs:
            try:
                if item[0].poll() is None:
                    item[0].kill()
            except Exception:
                pass

    try:
        while True:
            frac = 0.0
            alive = 0
            for item in procs:
                p, out, prog = item
                if p.poll() is None:
                    alive += 1
                try:
                    if os.path.exists(prog):
                        with open(prog, "r", encoding="ascii") as f:
                            frac += float((f.read() or "0").strip() or 0)
                    elif p.poll() is not None:
                        frac += 1.0
                except Exception:
                    pass
            if progress:
                progress(int(100 * frac / len(procs)), len(seeds))
            if should_stop and should_stop():
                _kill_all()
                break
            if alive == 0:
                break
            time.sleep(0.4)
        for p, out, prog in procs:
            try:
                if os.path.exists(out) and os.path.getsize(out) >= 4:
                    with open(out, "rb") as f:
                        part = array("i")
                        part.frombytes(f.read())
                        seeds.extend(part)
            except Exception:
                pass
        if len(seeds) >= cap:
            truncated = True
    finally:
        _kill_all()
        try:
            for name in os.listdir(tmpdir):
                try:
                    os.remove(os.path.join(tmpdir, name))
                except Exception:
                    pass
            os.rmdir(tmpdir)
        except Exception:
            pass
    if progress:
        progress(100, len(seeds))
    return seeds, truncated


def combine_seeds(xp1, xp2):
    """两组相邻观测的 xpSeed → 完整的 48 位 playerSeed（找不到返回 None）。"""
    high1 = (xp1 << 16) & 0x0000FFFFFFFF0000
    high2 = (xp2 << 16) & 0x0000FFFFFFFF0000
    for low in range(65536):
        cand = ((high1 | low) * MULT + ADD) & MASK48
        if (cand & 0x0000FFFFFFFF0000) == high2:
            return cand
    return None


# ---------------------------------------------------------------- 目标规划


def _check(enchants, wanted, unwanted):
    for eid, lv in wanted:
        ok = False
        for e, l in enchants:
            if e == eid and l >= lv:
                ok = True
                break
        if not ok:
            return False
    for eid, _lv in unwanted:
        for e, _l in enchants:
            if e == eid:
                return False
    return True


def plan(player_seed, item, max_shelves, player_level, wanted, unwanted):
    """找「先扔几件物品 + 摆几个书架 + 点第几个槽」，复刻破解器的搜索。

    返回 dict：times（-1 表示不需要假附魔，None 表示做不到）、
    shelves、slot（0 起）、xp_seed。
    """
    best = {"times": None, "shelves": 0, "slot": -1, "xp_seed": 0,
            "enchants": []}
    seed = int(player_seed) & MASK48
    if enchantability(item) == 0:
        return best
    for i in range(-1, 64 * 32):
        if i == -1:
            xp = (seed >> 16) & 0xFFFFFFFF
        else:
            xp = (((seed * MULT + ADD) & MASK48) >> 16) & 0xFFFFFFFF
        for shelves in range(0, max_shelves + 1):
            levels = slot_levels(xp, shelves, item)
            for slot in range(3):
                lv = levels[slot]
                if lv < slot + 1:
                    continue
                if i == -1:
                    if player_level < lv:
                        continue
                elif player_level < lv + 1:
                    continue
                enchants = slot_enchantments(xp, item, slot, lv)
                if not _check(enchants, wanted, unwanted):
                    continue
                best.update({"times": i, "shelves": shelves, "slot": slot,
                             "xp_seed": xp, "levels": levels,
                             "enchants": enchants})
                return best
        if i != -1:
            for _ in range(4):        # 扔一件物品吃掉 4 步随机数
                seed = (seed * MULT + ADD) & MASK48
    return best


def describe_plan(res):
    """把 plan() 的结果写成给人看的中文步骤。"""
    t = res["times"]
    if t is None:
        return ("没找到能出这套目标的路线。可能原因：目标互斥、等级不够，"
                "或者这组种子的随机序列里真的刷不出来；换个目标再试。")
    L = []
    if t == -1:
        L.append("1. 不用先扔东西，直接摆 %d 个书架。" % res["shelves"])
    elif t == 0:
        L.append("1. 先随便附一张纸（花 1 级），把种子推一下。")
        L.append("   然后摆 %d 个书架。" % res["shelves"])
    else:
        stacks, rest = divmod(t, 64)
        how = "%d 件" % t
        if stacks:
            how += "（约 %d 组 + %d 件）" % (stacks, rest)
        L.append("1. 先往地上扔 %s 物品，捡起来再扔，别对着同一格堆。"
                 % how)
        L.append("2. 再附一张纸（花 1 级，这一下也推种子）。")
        L.append("3. 摆 %d 个书架。" % res["shelves"])
    L.append("4. 目标物品放进附魔台，点第 %d 格（%s）。"
             % (res["slot"] + 1, "顶/中/底"[res["slot"]]))
    L.append("   这一格是 %d 级，出来的是：%s"
             % (res.get("levels", [0, 0, 0])[res["slot"]],
                "、".join(ench_label(e, l) for e, l in res["enchants"])))
    L.append("")
    L.append("做完再算下一次，就再点一遍「算下一步」。")
    return "\n".join(L)
