# -*- coding: utf-8 -*-
"""把 Qt 自带对话框的标准按钮换成中文。

打包环境里的 PySide6 没带 translations/（编译时就会警告 could not find
translations with base name 'qt'），所以 QMessageBox / QInputDialog 的按钮一直
显示 Yes / No / OK / Cancel。这里直接接管几个静态方法，自己建对话框、自己给按钮
改名，不依赖任何 .qm 文件，打包后必然生效。
"""
from PySide6.QtWidgets import (QDialogButtonBox, QInputDialog, QLineEdit,
                               QMessageBox, QWidget)

_BTN_TEXT = {
    "&Yes": "是",
    "&No": "否",
    "&OK": "确定",
    "&Cancel": "取消",
    "&Close": "关闭",
    "&Save": "保存",
    "&Discard": "不保存",
    "&Apply": "应用",
    "&Reset": "重置",
    "&Retry": "重试",
    "&Ignore": "忽略",
    "&Abort": "中止",
    "&Help": "帮助",
    "&Open": "打开",
    "&Save All": "全部保存",
    "&Don't Save": "不保存",
}

_CN = {
    "Yes": "是", "No": "否", "OK": "确定", "Cancel": "取消",
    "Close": "关闭", "Save": "保存", "Discard": "不保存", "Apply": "应用",
    "Reset": "重置", "Retry": "重试", "Ignore": "忽略", "Abort": "中止",
    "Help": "帮助", "Open": "打开", "SaveAll": "全部保存",
}

_STD = {
    "Yes": QMessageBox.Yes, "No": QMessageBox.No, "Ok": QMessageBox.Ok,
    "Cancel": QMessageBox.Cancel, "Close": QMessageBox.Close,
    "Save": QMessageBox.Save, "Discard": QMessageBox.Discard,
    "Apply": QMessageBox.Apply, "Reset": QMessageBox.Reset,
    "Retry": QMessageBox.Retry, "Ignore": QMessageBox.Ignore,
    "Abort": QMessageBox.Abort, "Help": QMessageBox.Help,
    "Open": QMessageBox.Open,
}


def localize_buttons(dialog, mapping=None):
    """把对话框里所有标准按钮改成中文。"""
    mapping = mapping or _CN
    bb = dialog.findChild(QDialogButtonBox)
    if bb is not None:
        for btn in bb.buttons():
            key = btn.text().replace("&", "").replace(" ", "")
            if key in mapping:
                btn.setText(mapping[key])
    for name, std in _STD.items():
        btn = dialog.button(std) if hasattr(dialog, "button") else None
        if btn is not None and name in mapping:
            btn.setText(mapping[name])


def _box(kind, parent, title, text, buttons, default):
    box = QMessageBox(parent if parent is not None else None)
    box.setIcon(getattr(QMessageBox, kind))
    if title:
        box.setWindowTitle(title)
    box.setText(text)
    box.setStandardButtons(buttons)
    if default != QMessageBox.NoButton:
        box.setDefaultButton(default)
    localize_buttons(box)
    return box.exec_()


def install():
    """接管 QMessageBox / QInputDialog 的静态调用。"""
    QMessageBox.information = staticmethod(
        lambda parent=None, title="", text="", buttons=QMessageBox.Ok,
               defaultButton=QMessageBox.NoButton, *a, **k:
        _box("Information", parent, title, text, buttons, defaultButton))
    QMessageBox.warning = staticmethod(
        lambda parent=None, title="", text="", buttons=QMessageBox.Ok,
               defaultButton=QMessageBox.NoButton, *a, **k:
        _box("Warning", parent, title, text, buttons, defaultButton))
    QMessageBox.critical = staticmethod(
        lambda parent=None, title="", text="", buttons=QMessageBox.Ok,
               defaultButton=QMessageBox.NoButton, *a, **k:
        _box("Critical", parent, title, text, buttons, defaultButton))
    QMessageBox.question = staticmethod(
        lambda parent=None, title="", text="",
               buttons=QMessageBox.Yes | QMessageBox.No,
               defaultButton=QMessageBox.NoButton, *a, **k:
        _box("Question", parent, title, text, buttons, defaultButton))

    def _input(parent, title, label, mode, text="", ok_text="确定",
               cancel_text="取消"):
        dlg = QInputDialog(parent)
        dlg.setWindowTitle(title)
        dlg.setLabelText(label)
        dlg.setTextValue(text)
        if mode == "int":
            dlg.setInputMode(QInputDialog.IntInput)
        elif mode == "double":
            dlg.setInputMode(QInputDialog.DoubleInput)
        else:
            dlg.setInputMode(QInputDialog.TextInput)
        dlg.setOkButtonText(ok_text)
        dlg.setCancelButtonText(cancel_text)
        return (dlg.exec_() == QInputDialog.Accepted), dlg

    def get_text(parent=None, title="", label="", mode=QLineEdit.Normal,
                 text="", flags=None, inputMethodHints=None, *a, **k):
        from PySide6.QtCore import Qt
        ok, dlg = _input(parent, title, label, "text", text)
        return (dlg.textValue() if ok else ""), bool(ok)

    def get_item(parent=None, title="", label="", items=None,
                 current=0, editable=True, *a, **k):
        dlg = QInputDialog(parent)
        dlg.setWindowTitle(title)
        dlg.setLabelText(label)
        dlg.setComboBoxItems(list(items or []))
        dlg.setComboBoxEditable(bool(editable))
        dlg.setOkButtonText("确定")
        dlg.setCancelButtonText("取消")
        r = dlg.exec_()
        ok = r == QInputDialog.Accepted
        return (dlg.textValue() if ok else ""), bool(ok)

    def get_int(parent=None, title="", label="", value=0, minv=-2147483647,
                maxv=2147483647, step=1, *a, **k):
        ok, dlg = _input(parent, title, label, "int", str(value))
        return (dlg.intValue() if ok else value), bool(ok)

    def get_double(parent=None, title="", label="", value=0.0, minv=-1e9,
                   maxv=1e9, decimals=2, step=0.1, *a, **k):
        ok, dlg = _input(parent, title, label, "double", str(value))
        return (dlg.doubleValue() if ok else value), bool(ok)

    QInputDialog.getText = staticmethod(get_text)
    QInputDialog.getItem = staticmethod(get_item)
    QInputDialog.getInt = staticmethod(get_int)
    QInputDialog.getDouble = staticmethod(get_double)
