# -*- coding: utf-8 -*-
"""官方最新版本探测：版本号取 Mojang 的 version_manifest，封面取官方补丁说明的配图。

为了「打开就显示」而不是每次都等网络：
- 版本清单落盘缓存 15 分钟，网络失败时直接用旧缓存；
- 补丁说明（封面来源）缓存 6 小时，失败 20 分钟内不再重试；
- 封面图按版本缓存，下过就不再下。
"""
import json
import os
import time

from . import http, platform_utils

MANIFESTS = (
    ("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json", "official"),
    ("https://bmclapi2.bangbang93.com/mc/game/version_manifest_v2.json", "bmcl"),
)
NOTES = "https://launchercontent.mojang.com/v2/javaPatchNotes.json"
COVER_HOST = "https://launchercontent.mojang.com"

_MANIFEST_TTL = 4 * 3600      # 官方版本号不会几分钟一变，缓存久一点，打开就先显示
_NOTES_TTL = 12 * 3600
_NOTES_FAIL_TTL = 20 * 60
_COVER_FAIL_TTL = 20 * 60


def _data_dir():
    d = os.path.join(platform_utils.data_dir(), "cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _cache_file(name):
    return os.path.join(_data_dir(), name)


def _read_cache(name, ttl):
    path = _cache_file(name)
    try:
        if ttl is not None and time.time() - os.path.getmtime(path) > ttl:
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _write_cache(name, obj):
    path = _cache_file(name)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except Exception:
        pass


def _touch(name):
    path = _cache_file(name)
    try:
        with open(path, "a", encoding="utf-8"):
            os.utime(path, None)
    except Exception:
        pass


def _stale(name):
    """失败标记是否还在有效期。"""
    path = _cache_file(name)
    try:
        return time.time() - os.path.getmtime(path) < _COVER_FAIL_TTL
    except Exception:
        return False


def latest_versions():
    """返回 {'release': '1.21.x', 'snapshot': '...', 'source': url}。"""
    cached = _read_cache("manifest_latest.json", _MANIFEST_TTL)
    if cached and cached.get("release"):
        return dict(cached, cached=True)

    last_err = None
    for url, mirror in MANIFESTS:
        try:
            data = http.fetch_json(url, mirror, timeout=12, retries=2)
            latest = data.get("latest") or {}
            if latest.get("release"):
                info = {"release": str(latest["release"]),
                        "snapshot": str(latest.get("snapshot") or ""),
                        "source": url}
                _write_cache("manifest_latest.json", info)
                return info
        except Exception as e:
            last_err = e

    # 网络彻底不行时，宁可显示上一次的结果，也不要空着
    old = _read_cache("manifest_latest.json", None)
    if old and old.get("release"):
        return dict(old, offline=True)
    raise RuntimeError("拿不到官方版本列表（%s）" % last_err)


def _notes_entries():
    cached = _read_cache("patch_notes.json", _NOTES_TTL)
    if cached is not None:
        return cached
    if _stale("patch_notes.json.fail"):
        old = _read_cache("patch_notes.json", None)
        return old or []
    try:
        data = http.fetch_json(NOTES, "official", timeout=8, retries=2)
        entries = data.get("entries") or []
        if entries:
            _write_cache("patch_notes.json", entries)
        return entries
    except Exception:
        _touch("patch_notes.json.fail")
        return _read_cache("patch_notes.json", None) or []


def cover_url(version):
    """优先找这个版本自己的说明图，找不到就退到最近一个正式版的图。"""
    entries = _notes_entries()
    if not entries:
        return ""
    pick = None
    for e in entries:
        if str(e.get("version") or "") == str(version):
            pick = e
            break
    if pick is None:
        for e in entries:
            if e.get("type") == "release":
                pick = e
                break
    if pick is None:
        pick = entries[0]
    image = pick.get("image") or {}
    url = image.get("url") or ""
    if not url:
        return ""
    if url.startswith("/"):
        url = COVER_HOST + url
    return url


def _cover_name(version):
    return "cover_%s.jpg" % "".join(
        ch for ch in str(version) if ch.isalnum() or ch in "-._")


def get_cover(version):
    """把封面图下到本地缓存（同一版本只下一次），返回本地路径或空串。"""
    if not version:
        return ""
    path = _cache_file(_cover_name(version))
    try:
        if os.path.exists(path) and os.path.getsize(path) > 4096:
            return path
    except Exception:
        pass
    if _stale(_cover_name(version) + ".fail"):
        return ""
    url = cover_url(version)
    if not url:
        return ""
    try:
        data = http._read_url(url, "official", timeout=10, retries=2)
        if len(data) < 4096:
            return ""
        with open(path, "wb") as f:
            f.write(data)
        return path
    except Exception:
        _touch(_cover_name(version) + ".fail")
        return ""


def notes_for(version):
    """版本的更新摘要（有就拿，没有返回空串）。"""
    for e in _notes_entries():
        if str(e.get("version") or "") == str(version):
            return str(e.get("title") or "")
    return ""


def cached_cover(version=""):
    """本地已经下过的封面，用来在联网之前先铺一张图，避免「封面加载中」干等。"""
    d = _data_dir()
    try:
        covers = [(os.path.getmtime(os.path.join(d, f)), f)
                  for f in os.listdir(d)
                  if f.startswith("cover_") and f.endswith(".jpg")]
    except Exception:
        return ""
    if not covers:
        return ""
    if version:
        want = _cover_name(version)
        hit = os.path.join(d, want)
        try:
            if os.path.getsize(hit) > 4096:
                return hit
        except Exception:
            pass
    covers.sort(reverse=True)
    latest_file = os.path.join(d, covers[0][1])
    try:
        if os.path.getsize(latest_file) > 4096:
            return latest_file
    except Exception:
        return ""
