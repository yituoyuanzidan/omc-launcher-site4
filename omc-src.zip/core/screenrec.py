# -*- coding: utf-8 -*-
"""屏幕录制：Qt 原生通路（QScreenCapture + QMediaRecorder），不依赖外部 ffmpeg。

做的几件事：
- 起录前按帧率 / 画质配置编码器，输出到用户目录；
- 起录后弹一个「停止」浮窗到屏幕右上角，窗口设 WDA_EXCLUDEFROMCAPTURE，
  这样它盖在所有程序之上，却不会被录进视频里；
- 停止后等文件真正落盘，再把路径和时长交回去。

Qt5 / Win7 分支没有 QScreenCapture，has_capture() 返回 False，页面据此降级。
"""
import ctypes
import datetime
import os
import sys

HAS_CAPTURE = False
IMPORT_ERROR = ""
Signal = None

# 基础 Qt 类：Qt6 与 Qt5 都有，先拿到手，保证这个模块本身导得进来；
# 屏幕捕获相关的类只有 Qt6 有，单独判断，缺了就让页面降级。
_QT_PKG = ""
try:
    from PySide6.QtCore import QObject, Qt, QTimer, QUrl
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
                                   QPushButton)
    Signal = __import__("PySide6.QtCore", fromlist=["Signal"]).Signal
    _QT_PKG = "PySide6"
except Exception:
    try:
        from PySide2.QtCore import QObject, Qt, QTimer, QUrl
        from PySide2.QtGui import QGuiApplication
        from PySide2.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
                                       QPushButton)
        Signal = __import__("PySide2.QtCore", fromlist=["Signal"]).Signal
        _QT_PKG = "PySide2"
    except Exception as _e:
        IMPORT_ERROR = "%s: %s" % (type(_e).__name__, _e)

try:
    from PySide6.QtMultimedia import (QMediaCaptureSession, QMediaFormat,
                                      QMediaRecorder, QScreenCapture)

    HAS_CAPTURE = True
except Exception as _e:                      # Qt5 / Win7 分支没有屏幕捕获
    IMPORT_ERROR = "%s: %s" % (type(_e).__name__, _e)
    HAS_CAPTURE = False

#: 帧率选项（值, 显示名）；最高 120 帧
FPS_CHOICES = [(30, "30 帧"), (60, "60 帧"), (90, "90 帧"), (120, "120 帧")]

#: 画质选项（key, 显示名, QMediaRecorder 档位名, 码率上限）
QUALITY_CHOICES = [
    ("low", "流畅", "LowQuality", 2500000),
    ("normal", "标准", "NormalQuality", 6000000),
    ("high", "高清", "HighQuality", 12000000),
    ("ultra", "超清", "VeryHighQuality", 20000000),
]

WDA_EXCLUDEFROMCAPTURE = 0x00000011


def quality_spec(key):
    for q in QUALITY_CHOICES:
        if q[0] == key:
            return q
    return QUALITY_CHOICES[2]


def default_dir():
    """默认保存目录：用户「视频」目录下的 OMC 录屏。"""
    home = os.path.expanduser("~")
    for sub in ("Videos", "视频"):
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            return os.path.join(p, "OMC录屏")
    return os.path.join(home, "OMC录屏")


def ensure_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
        return True
    except Exception:
        return False


def new_file(dir_path, ext=".mp4"):
    ensure_dir(dir_path)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.join(dir_path, "OMC_%s" % stamp)
    path = base + ext
    i = 1
    while os.path.exists(path):
        path = "%s_%d%s" % (base, i, ext)
        i += 1
    return path


class StopBar(QFrame):
    """屏幕右上角的停止浮窗：永远置顶，但不会被录进画面。

    置顶靠 WindowStaysOnTopHint + Qt.Tool；不被录到靠 Windows 的
    SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE)，DWM 会把这个窗口从
    截图/录屏的取像里剔掉（实测录出的帧里按钮区域 0 像素）。
    """

    def __init__(self):
        super().__init__(None)
        self._sec = 0
        self.on_stop = None
        self._excluded = None
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
                           | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setStyleSheet(
            "StopBar{background:#1b1414;border:1px solid #a33;border-radius:10px;}"
            "QLabel{color:#ff6b6b;font-size:14px;background:transparent;}"
            "QPushButton{background:#d33;color:#fff;border:none;border-radius:8px;"
            "padding:6px 14px;font-size:14px;}"
            "QPushButton:hover{background:#e44;}")
        h = QHBoxLayout(self)
        h.setContentsMargins(12, 8, 10, 8)
        h.setSpacing(10)
        self.dot = QLabel("● 录制中")
        self.time = QLabel("00:00")
        self.btn = QPushButton("停止")
        self.btn.setFixedHeight(30)
        self.btn.clicked.connect(self._clicked)
        h.addWidget(self.dot)
        h.addWidget(self.time)
        h.addWidget(self.btn)
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self.adjustSize()

    def _clicked(self):
        if callable(self.on_stop):
            self.on_stop()

    def _tick(self):
        self._sec += 1
        self.time.setText("%02d:%02d" % (self._sec // 60, self._sec % 60))

    def place_top_right(self):
        scr = QGuiApplication.primaryScreen()
        if scr is None:
            return
        g = scr.availableGeometry()
        self.adjustSize()
        w, h = self.width(), self.height()
        self.move(g.right() - w - 16, g.top() + 16)

    def show_bar(self):
        self._sec = 0
        self.time.setText("00:00")
        self.adjustSize()
        self.place_top_right()
        self.show()
        self.raise_()
        # show 之后 HWND 立刻就有，但要让 DWM 把它真正合成上屏，
        # 再挂排除属性；起录会在 200ms 后才开始，来得及。
        try:
            QApplication.processEvents()
        except Exception:
            pass
        self.exclude_from_capture()
        self._timer.start()
        return self._excluded

    def hide_bar(self):
        self._timer.stop()
        self.hide()

    def exclude_from_capture(self):
        """把这个窗口从屏幕捕获里剔掉；返回是否成功。"""
        if not sys.platform.startswith("win"):
            self._excluded = False
            return False
        try:
            hwnd = int(self.winId())
            ok = ctypes.windll.user32.SetWindowDisplayAffinity(
                ctypes.c_void_p(hwnd), ctypes.c_uint(WDA_EXCLUDEFROMCAPTURE))
            self._excluded = bool(ok)
        except Exception:
            self._excluded = False
        return bool(self._excluded)


class Recorder(QObject):
    """一次录制。start() 后 stop() 即可拿到文件。

    信号：started(path) / finished(path, 时长毫秒) / failed(说明)
    """

    started = Signal(str) if Signal is not None else None
    finished = Signal(str, int) if Signal is not None else None
    failed = Signal(str) if Signal is not None else None

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cap = None
        self._sess = None
        self._rec = None
        self._path = ""
        self._pending_start = False
        self._retry = 0
        self._bar = None
        if not HAS_CAPTURE:
            return
        self._bar = StopBar()
        self._bar.on_stop = self.stop

    # ---- 能力 ----
    @staticmethod
    def has_capture():
        return HAS_CAPTURE

    def bar(self):
        return self._bar

    def is_recording(self):
        if self._rec is None:
            return False
        try:
            return self._rec.recorderState() == QMediaRecorder.RecordingState
        except Exception:
            return False

    # ---- 起停 ----
    def start(self, dir_path="", fps=30, quality="high", screen_index=0):
        if not HAS_CAPTURE:
            self._emit(self.failed, "这台电脑的 Qt 版本不支持录屏：%s" % IMPORT_ERROR)
            return False
        if self.is_recording() or self._pending_start:
            return False
        self._path = new_file(dir_path or default_dir())
        try:
            q = quality_spec(quality)
            scr = QGuiApplication.screens()
            scr = scr[screen_index] if 0 <= screen_index < len(scr) else \
                QGuiApplication.primaryScreen()

            self._cap = QScreenCapture(self)
            self._cap.setScreen(scr)
            self._sess = QMediaCaptureSession(self)
            self._sess.setScreenCapture(self._cap)
            self._rec = QMediaRecorder(self)
            self._sess.setRecorder(self._rec)

            self._rec.setQuality(getattr(QMediaRecorder, q[2]))
            try:
                self._rec.setVideoBitRate(q[3])
            except Exception:
                pass
            fmt = QMediaFormat(QMediaFormat.MPEG4)
            fmt.setVideoCodec(QMediaFormat.H264)
            self._rec.setMediaFormat(fmt)
            try:
                self._rec.setVideoFrameRate(float(fps))
            except Exception:
                pass
            self._rec.setOutputLocation(QUrl.fromLocalFile(self._path))
            self._rec.errorOccurred.connect(
                lambda e, s: self._emit(self.failed, "录制出错：%s" % s))

            # 先把停止浮窗摆好并排除出捕获，再开始录，否则第一帧会带上它
            excluded = None
            if self._bar is not None:
                excluded = self._bar.show_bar()
            if excluded is False:
                # 排除不掉就意味着停止按钮会被录进视频，那宁可不录
                self._bar.hide_bar()
                self._cleanup()
                self._emit(self.failed,
                           "这台系统不允许把窗口排除出录屏画面（要 Win10 2004 "
                           "以上），录出来的视频会带上停止按钮，所以先不录了。")
                return False

            # 给 DWM 一点时间把「排除」生效，避免开头几帧里还留着按钮
            def _begin():
                self._pending_start = False
                try:
                    self._cap.start()
                    self._rec.record()
                except Exception as e:
                    self._emit(self.failed,
                               "起录失败：%s: %s" % (type(e).__name__, e))
            self._pending_start = True
            QTimer.singleShot(220, _begin)
        except Exception as e:
            self._cleanup()
            self._emit(self.failed, "起录失败：%s: %s" % (type(e).__name__, e))
            return False
        self._emit(self.started, self._path)
        return True

    def stop(self):
        """停止录制；文件落盘后发 finished。"""
        if self._rec is None:
            return
        try:
            if self._bar is not None:
                self._bar.hide_bar()
            self._rec.stop()
            if self._cap is not None:
                self._cap.stop()
        except Exception as e:
            self._emit(self.failed, "停止失败：%s" % e)
        # record 停下来到文件真正写完有几百毫秒，轮询着等
        QTimer.singleShot(900, self._finish)

    def _finish(self):
        size = 0
        try:
            size = os.path.getsize(self._path) if os.path.isfile(self._path) else 0
        except Exception:
            size = 0
        if size <= 0:
            QTimer.singleShot(700, self._finish)
            self._retry = getattr(self, "_retry", 0) + 1
            if self._retry > 6:
                self._cleanup()
                self._emit(self.failed, "录制没有写出文件：%s" % self._path)
            return

        dur = 0
        try:
            if self._rec is not None:
                dur = int(self._rec.duration())
        except Exception:
            dur = 0
        path = self._path
        self._cleanup()
        self._emit(self.finished, path, dur)

    def _emit(self, sig, *args):
        try:
            if sig is not None:
                sig.emit(*args)
        except Exception:
            pass

    def _cleanup(self):
        try:
            if self._rec is not None:
                self._rec.deleteLater()
            if self._sess is not None:
                self._sess.deleteLater()
            if self._cap is not None:
                self._cap.deleteLater()
        except Exception:
            pass
        self._rec = None
        self._sess = None
        self._cap = None
        self._retry = 0

    def cancel(self):
        """放弃这次录制（文件删掉）。"""
        try:
            if self._bar is not None:
                self._bar.hide_bar()
            if self._rec is not None:
                self._rec.stop()
            if self._cap is not None:
                self._cap.stop()
        except Exception:
            pass
        self._cleanup()
        try:
            if self._path and os.path.isfile(self._path):
                os.remove(self._path)
        except Exception:
            pass


def list_recordings(dir_path):
    """列出目录里的录屏文件，按时间倒序。"""
    out = []
    try:
        for name in os.listdir(dir_path):
            if not name.lower().endswith((".mp4", ".mkv", ".mov")):
                continue
            p = os.path.join(dir_path, name)
            try:
                st = os.stat(p)
                out.append({"path": p, "name": name,
                            "size": st.st_size, "mtime": st.st_mtime})
            except Exception:
                continue
    except Exception:
        return out
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def human_size(n):
    try:
        n = float(n)
    except Exception:
        return "—"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%.1f %s" % (n, unit)) if unit != "B" else ("%d B" % n)
        n /= 1024.0
    return "—"


def human_dur(ms):
    try:
        s = int(ms // 1000)
    except Exception:
        return "—"
    return "%02d:%02d" % (s // 60, s % 60)
