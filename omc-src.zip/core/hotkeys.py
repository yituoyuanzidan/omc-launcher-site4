# -*- coding: utf-8 -*-
"""全局快捷键：游戏在跑、启动器缩在后台时也能一键唤出。

Windows 用 user32 的 RegisterHotKey，热键由系统直接投递，不需要管理员权限；
macOS / Linux 没有等价的免权限方案（要辅助功能授权或 X11 grab），
这里直接返回不可用，界面会显示「仅 Windows」，不会假装成功。
"""
import queue
import threading

from . import platform_utils

# 常用的键码
VK = {
    "F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74, "F6": 0x75,
    "F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79, "F11": 0x7A, "F12": 0x7B,
    "O": 0x4F, "L": 0x4C, "M": 0x4D, "P": 0x50, "S": 0x53, "R": 0x52,
    "ESC": 0x1B, "SPACE": 0x20,
}
MOD_ALT = 0x0001
MOD_CTRL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008

DEFAULTS = {
    "toggle": {"mods": ["ctrl", "alt"], "key": "O",
               "label": "Ctrl+Alt+O 唤出启动器"},
    "launch": {"mods": ["ctrl", "alt"], "key": "L",
               "label": "Ctrl+Alt+L 启动游戏"},
    "screenshot": {"mods": ["ctrl", "alt"], "key": "S",
                   "label": "Ctrl+Alt+S 打开截图相册"},
}

_events = queue.Queue()
_thread = None
_registered = {}
_state = {"ok": False, "msg": ""}


def available():
    return platform_utils.WINDOWS


def state():
    return dict(_state)


def _mods_value(mods):
    v = 0
    for m in mods or []:
        low = str(m).lower()
        if low in ("ctrl", "control"):
            v |= MOD_CTRL
        elif low == "alt":
            v |= MOD_ALT
        elif low == "shift":
            v |= MOD_SHIFT
        elif low in ("win", "super", "cmd"):
            v |= MOD_WIN
    return v


def _parse(binding):
    """{"mods":[...],"key":"O"} -> (mods_value, vk)。"""
    key = str(binding.get("key") or "").upper()
    vk = VK.get(key)
    if not vk:
        m = None
        try:
            import re
            m = re.match(r"^([A-Z0-9])$", key)
        except Exception:
            m = None
        if m:
            ch = m.group(1)
            vk = ord(ch) if ch.isalpha() else ord(ch)
        else:
            raise ValueError("不支持的按键：%s" % key)
    return _mods_value(binding.get("mods")), vk


def _loop(bindings, result):
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    ids = {}
    nid = 0x4F4D  # 随便挑一个不会和别人撞的起始 id
    for name, binding in bindings.items():
        try:
            mods, vk = _parse(binding)
        except Exception as e:
            result["skipped"].append("%s：%s" % (name, e))
            continue
        nid += 1
        if user32.RegisterHotKey(None, nid, mods, vk):
            ids[nid] = name
            _registered[name] = nid
        else:
            result["skipped"].append("%s：被别的程序占用了" % name)

    if not ids:
        result["ok"] = False
        result["msg"] = "没有可用的热键（可能都被占用了）"
        return

    result["ok"] = True
    result["msg"] = "已注册 %d 个热键" % len(ids)

    while not result["stop"].is_set():
        msg = wintypes.MSG()
        ret = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
        if ret == 0 or ret == -1:
            break
        if msg.message == 0x0312:  # WM_HOTKEY
            name = ids.get(int(msg.wParam))
            if name:
                _events.put(name)
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))

    for nid in ids:
        try:
            user32.UnregisterHotKey(None, nid)
        except Exception:
            pass
    _registered.clear()


def start(bindings=None):
    """注册热键；返回 {"ok","msg","skipped"}。非 Windows 返回 ok=False。"""
    global _thread
    if not available():
        _state.update({"ok": False, "msg": "全局快捷键只在 Windows 上生效"})
        return {"ok": False, "msg": _state["msg"], "skipped": []}
    if _thread is not None and _thread.is_alive():
        return {"ok": True, "msg": "热键已在运行", "skipped": []}
    bindings = bindings or DEFAULTS
    result = {"ok": False, "msg": "", "skipped": [],
              "stop": threading.Event()}
    _thread = threading.Thread(target=_loop, args=(bindings, result),
                               daemon=True, name="omc-hotkeys")
    _thread.start()
    # 等它把注册做完，握手最多 1 秒
    for _ in range(20):
        if result["msg"]:
            break
        threading.Event().wait(0.05)
    _state.update({"ok": bool(result["ok"]), "msg": result["msg"] or ""})
    return {"ok": bool(result["ok"]), "msg": result["msg"] or "",
            "skipped": result["skipped"], "handle": result}


def poll():
    """UI 侧用 QTimer 拉：返回待处理的动作名列表。"""
    out = []
    while True:
        try:
            out.append(_events.get_nowait())
        except queue.Empty:
            break
    return out


def stop():
    global _thread
    try:
        if _thread is not None and _thread.is_alive():
            _state.update({"ok": False, "msg": "已停止"})
            _thread = None
    except Exception:
        pass
