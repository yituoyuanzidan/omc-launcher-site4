# -*- coding: utf-8 -*-
"""免打扰 / 置顶 / 特别关心：好友和群聊各自的提醒偏好。

存一份小 json（~/.simple_mc_launcher/notify.json），不改好友本体的数据，
好友删了偏好留着也无所谓。

提醒规则（被判定的顺序很重要）：
1. **特别关心**的好友发消息 → 一定要提示 + 一定要响，不管全局免打扰、不管最小化；
2. 全局免打扰开着 → 除了特别关心，谁都不提示（消息照样收进列表）；
3. 这个好友 / 这个群自己开了免打扰 → 不提示；
4. 其余情况 → 右下角提示 + 叮一声。
"""
import json
import os

_FILE_NAME = "notify.json"
_CACHE = {}


def _path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, _FILE_NAME)


def _blank():
    return {"global_dnd": False, "no_sound": False,
            "friends": {}, "groups": {}}


def load():
    p = _path()
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            return _blank()
    except Exception:
        return _blank()
    base = _blank()
    base.update({k: v for k, v in d.items() if k in base})
    for key in ("friends", "groups"):
        if not isinstance(base.get(key), dict):
            base[key] = {}
    return base


def save(data):
    p = _path()
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass


def friend(name):
    return (load().get("friends") or {}).get(name or "", {}) or {}


def group(gid):
    return (load().get("groups") or {}).get(gid or "", {}) or {}


def set_friend(name, **flags):
    if not name:
        return
    d = load()
    row = d["friends"].get(name) or {}
    row.update({k: bool(v) for k, v in flags.items()})
    d["friends"][name] = row
    save(d)


def set_group(gid, **flags):
    if not gid:
        return
    d = load()
    row = d["groups"].get(gid) or {}
    row.update({k: bool(v) for k, v in flags.items()})
    d["groups"][gid] = row
    save(d)


def set_global(key, on):
    d = load()
    d[key] = bool(on)
    save(d)


def global_dnd():
    return bool(load().get("global_dnd"))


def no_sound():
    return bool(load().get("no_sound"))


def is_star(name):
    return bool(friend(name).get("star"))


def is_pinned_friend(name):
    return bool(friend(name).get("pin"))


def is_pinned_group(gid):
    return bool(group(gid).get("pin"))


def should_alert(name=None, gid=None, mention=False):
    """返回 (要不要弹提示, 要不要响)。

    name 是好友名（私聊时给），gid 是群号（群消息时给）。
    mention=True 表示群里这条消息 @ 了我：这时候只要群没开免打扰、
    全局免打扰也没开，就一定弹一条「有人@你」（哪怕平时只关提示音）。
    """
    d = load()
    if name and (d["friends"].get(name) or {}).get("star"):
        # 特别关心：不管全局免打扰、不管是不是只关了提示音，都要弹 + 都要响
        return True, True
    if name and (d["friends"].get(name) or {}).get("dnd"):
        return False, False
    if gid and (d["groups"].get(gid) or {}).get("dnd"):
        return False, False
    if d.get("global_dnd"):
        return False, False
    if mention:
        # 被 @ 比普通群消息要紧：就算只关了提示音，也要弹一下 + 响一声
        return True, True
    return True, not bool(d.get("no_sound"))
