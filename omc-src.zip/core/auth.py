# -*- coding: utf-8 -*-
"""微软正版登录：OAuth2 授权码 + 本地回调，Xbox/XSTS，MC 令牌与档案。"""
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

from .config import app_dir
from .http import ssl_context

# 可替换为你在 Azure 门户自行注册的应用 ID（移动/桌面应用，允许 localhost 回调）
CLIENT_ID = "00000000402b5328"
SCOPE = "XboxLive.signin offline_access"

ACCOUNT_PATH = os.path.join(app_dir(), "account.json")

AUTHORIZE = "https://login.live.com/oauth20_authorize.srf"
TOKEN = "https://login.live.com/oauth20_token.srf"
# 官方客户端 ID 只登记了这个回调地址，用 localhost 随机端口会被微软拒绝
DESKTOP_REDIRECT = "https://login.live.com/oauth20_desktop.srf"
XBL = "https://user.auth.xboxlive.com/user/authenticate"
XSTS = "https://xsts.auth.xboxlive.com/xsts/authorize"
MC_LOGIN = "https://api.minecraftservices.com/authentication/login_with_xbox"
MC_ENTITLEMENT = "https://api.minecraftservices.com/entitlements/mcstore"
MC_PROFILE = "https://api.minecraftservices.com/minecraft/profile"

# MSA 设备码登录：用户只需在网页输入 8 位码，不用再复制地址栏
DEVICE_CODE_URL = "https://login.live.com/oauth20_connect.srf"
DEVICE_GRANT = "urn:ietf:params:oauth:grant-type:device_code"
DEVICE_VERIFY_URL = "https://www.microsoft.com/link"


def _retry(fn, *args, **kwargs):
    """网络瞬时抖动时重试一次，避免一次超时就整体登录失败。"""
    try:
        return fn(*args, **kwargs)
    except urllib.error.HTTPError as e:
        if 500 <= e.code < 600:
            time.sleep(1.5)
            return fn(*args, **kwargs)
        raise
    except (urllib.error.URLError, TimeoutError):
        time.sleep(1.5)
        return fn(*args, **kwargs)


# XSTS 常见拒绝码 -> 人话
XSTS_HINTS = {
    2148916233: "该微软账号还没有 Xbox 账号，请先到 xbox.com 创建一次",
    2148916235: "该账号所在地区不支持 Xbox Live",
    2148916236: "需要成人验证，请在 xbox.com 完成年龄验证",
    2148916237: "需要成人验证，请在 xbox.com 完成年龄验证",
    2148916238: "未成年账号，需要家长把该账号加入 Microsoft 家庭组",
    2148916227: "该账号已被 Xbox Live 封禁",
}


def _http_body(e):
    try:
        return e.read().decode("utf-8", "replace")
    except Exception:
        return ""


def _friendly(body):
    """把微软返回的错误体翻成能看懂的一句话。"""
    m = re.search(r'"XErr"\s*:\s*(\d+)', body)
    if m:
        code = int(m.group(1))
        hint = XSTS_HINTS.get(code)
        if hint:
            return "%s（XErr %d）" % (hint, code)
        return "Xbox 验证被拒绝（XErr %d）" % code
    m = re.search(r'"error"\s*:\s*"([^"]+)"', body)
    if m:
        err = m.group(1)
        desc = ""
        m2 = re.search(r'"error_description"\s*:\s*"([^"]*)"', body)
        if m2:
            desc = m2.group(1).replace("\\u0026", "&")
        return ("%s：%s" % (err, desc)) if desc else err
    text = body.strip().replace("\n", " ")
    return text[:220] if text else "没有任何返回内容"


def _request_json(req, timeout=40):
    """统一请求入口：非 2xx 时把微软的错误体翻成人话再抛出。"""
    try:
        with urllib.request.urlopen(req, timeout=timeout,
                                    context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code >= 500:
            raise
        raise RuntimeError("HTTP %d：%s" % (e.code, _friendly(_http_body(e))))


def _post_json(url, payload, extra_headers=None):
    data = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json", "Accept": "application/json",
               "User-Agent": "SimpleMCLauncher/1.0"}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    return _request_json(req)


def _post_form(url, fields):
    data = urllib.parse.urlencode(fields).encode("utf-8")
    headers = {"Content-Type": "application/x-www-form-urlencoded",
               "User-Agent": "SimpleMCLauncher/1.0"}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    return _request_json(req)


def _get_json(url, bearer=None):
    headers = {"Accept": "application/json",
               "User-Agent": "SimpleMCLauncher/1.0"}
    if bearer:
        headers["Authorization"] = "Bearer " + bearer
    req = urllib.request.Request(url, headers=headers)
    return _request_json(req)


def _wait_for_code(port):
    result = {}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            q = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(q)
            if "code" in params:
                result["code"] = params["code"][0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(
                "<h2 style='font-family:sans-serif'>登录成功，可以回到启动器了。</h2>".encode("utf-8")
            )

    httpd = HTTPServer(("127.0.0.1", port), Handler)
    httpd.timeout = 180
    httpd.handle_request()
    return result.get("code")


def _microsoft_token(grant, fields):
    base = {"client_id": CLIENT_ID, "scope": SCOPE}
    base.update(fields)
    return _post_form(TOKEN, base)


def _xbox_chain(ms_access_token):
    xbl = _retry(_post_json, XBL, {
        "Properties": {
            "AuthMethod": "RPS",
            "SiteName": "user.auth.xboxlive.com",
            "RpsTicket": "d=" + ms_access_token,
        },
        "RelyingParty": "http://auth.xboxlive.com",
        "TokenType": "JWT",
    })
    xbl_token = xbl["Token"]
    uhs = xbl["DisplayClaims"]["xui"][0]["uhs"]

    xsts = _retry(_post_json, XSTS, {
        "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl_token]},
        "RelyingParty": "rp://api.minecraftservices.com/",
        "TokenType": "JWT",
    })
    return uhs, xsts["Token"]


def _mc_token(uhs, xsts_token):
    # 官方接口要求 identityToken 带 "XBL3.0 x=" 前缀，漏了会被 400 拒绝
    mc = _retry(_post_json, MC_LOGIN,
                {"identityToken": "XBL3.0 x=" + uhs + ";" + xsts_token})
    return mc["access_token"], int(mc.get("expires_in", 86400))


def _build_account(ms_token_resp):
    ms_access = ms_token_resp["access_token"]
    refresh = ms_token_resp.get("refresh_token", "")
    uhs, xsts_token = _xbox_chain(ms_access)
    mc_access, expires_in = _mc_token(uhs, xsts_token)
    profile = _retry(_get_json, MC_PROFILE, bearer=mc_access)
    return {
        "type": "msa",
        "name": profile["name"],
        "uuid": profile["id"],
        "mc_token": mc_access,
        "mc_expires_at": time.time() + expires_in - 60,
        "refresh_token": refresh,
    }


def _authorize_url(redirect, custom_id=None):
    query = urllib.parse.urlencode({
        "client_id": custom_id or CLIENT_ID,
        "response_type": "code",
        "redirect_uri": redirect,
        "scope": SCOPE,
        "prompt": "select_account",
    })
    return AUTHORIZE + "?" + query


def extract_code(text):
    """从用户粘贴的整段回调地址里取出 code，也允许直接粘贴 code。

    兼容：整段 https://login.live.com/oauth20_desktop.srf?code=xxx&lc=...
    以及 "code=xxx"、"code: xxx"、纯 code。
    """
    if not text:
        return None
    text = text.strip().strip('"').strip("'").strip()
    if "code=" in text:
        part = text.split("code=", 1)[1]
        for sep in ("&", "#", " ", "\n"):
            part = part.split(sep, 1)[0]
        return urllib.parse.unquote(part.strip()) or None
    for key in ("code:", "code："):
        if key in text:
            part = text.split(key, 1)[1]
            for sep in ("&", "#", "\n"):
                part = part.split(sep, 1)[0]
            return part.strip().strip('"').strip("'") or None
    return text or None


def device_code_start():
    """申请一个设备码：返回 8 位验证码、验证网址与轮询参数。"""
    resp = _post_form(DEVICE_CODE_URL, {
        "client_id": CLIENT_ID,
        "scope": SCOPE,
        "response_type": "device_code",
    })
    return {
        "user_code": resp["user_code"],
        "device_code": resp["device_code"],
        "uri": resp.get("verification_uri") or DEVICE_VERIFY_URL,
        "interval": max(3, int(resp.get("interval", 5))),
        "expires_in": int(resp.get("expires_in", 900)),
    }


def device_login(log=None, on_code=None, is_cancelled=None):
    """设备码登录全流程：拿码 -> 等用户在网页确认 -> 自动换令牌。

    比「复制回调地址里的一长串 code」稳得多，也不会因为 code 过期或被
    用掉而失败。
    """
    say = log or (lambda m: None)
    info = device_code_start()
    say("请在网页输入代码：%s" % info["user_code"])
    if on_code:
        on_code(info["user_code"], info["uri"])
    webbrowser.open(info["uri"])

    interval = info["interval"]
    deadline = time.time() + info["expires_in"]
    while time.time() < deadline:
        if is_cancelled and is_cancelled():
            raise RuntimeError("已取消登录")
        time.sleep(interval)
        try:
            token = _post_form(TOKEN, {
                "client_id": CLIENT_ID,
                "grant_type": DEVICE_GRANT,
                "device_code": info["device_code"],
            })
        except RuntimeError as e:
            msg = str(e)
            if "authorization_pending" in msg or "bad_verification_code" in msg:
                continue          # 用户还没点确认，继续等
            if "slow_down" in msg:
                interval += 5
                continue
            if "expired" in msg:
                raise RuntimeError("验证码已过期，请重新点一次「登录」")
            if "declined" in msg or "cancel" in msg:
                raise RuntimeError("你在网页上取消了授权")
            raise
        account = _build_account(token)
        save_account(account)
        return account
    raise RuntimeError("验证码已过期，请重新点一次「登录」")


def login_interactive(log=None, ask_code=None, custom_id=None):
    """交互式登录。

    ask_code 为回调函数时走「粘贴授权码」流程（无需注册 Azure 应用，最稳）；
    否则走本地端口监听流程（需要自己注册的应用 ID 允许 localhost 回调）。
    """
    say = log or (lambda m: None)

    if ask_code:
        url = _authorize_url(DESKTOP_REDIRECT, custom_id)
        say("正在打开浏览器登录...")
        webbrowser.open(url)
        say("登录完成后会停在一个空白页，把地址栏里的整段内容粘贴到启动器")
        raw = ask_code()
        code = extract_code(raw)
        if not code:
            raise RuntimeError("没有拿到授权码")
        say("正在换取令牌...")
        token_resp = _retry(_microsoft_token, "authorization_code", {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": DESKTOP_REDIRECT,
        })
        account = _build_account(token_resp)
        save_account(account)
        return account

    httpd = HTTPServer(("127.0.0.1", 0), BaseHTTPRequestHandler)
    port = httpd.server_address[1]
    httpd.server_close()

    redirect = "http://localhost:%d/" % port
    say("正在打开浏览器登录...")
    webbrowser.open(_authorize_url(redirect, custom_id))

    code = _wait_for_code(port)
    if not code:
        raise RuntimeError("未收到登录授权")
    say("正在换取令牌...")
    token_resp = _retry(_microsoft_token, "authorization_code", {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect,
    })
    account = _build_account(token_resp)
    save_account(account)
    return account


def refresh_account(account):
    """用 refresh_token 刷新，返回新的 account。"""
    if not account.get("refresh_token"):
        raise RuntimeError("缺少刷新令牌，需要重新登录")
    token_resp = _microsoft_token("refresh_token", {
        "grant_type": "refresh_token",
        "refresh_token": account["refresh_token"],
    })
    new_account = _build_account(token_resp)
    # 部分响应不返回新 refresh_token，保留旧的
    if not new_account.get("refresh_token"):
        new_account["refresh_token"] = account["refresh_token"]
    save_account(new_account)
    return new_account


def ensure_valid(account):
    """MC 令牌过期则自动刷新。"""
    if time.time() < float(account.get("mc_expires_at", 0)):
        return account
    return refresh_account(account)


def save_account(account):
    with open(ACCOUNT_PATH, "w", encoding="utf-8") as f:
        json.dump(account, f, ensure_ascii=False, indent=2)


def load_account():
    if not os.path.exists(ACCOUNT_PATH):
        return None
    try:
        with open(ACCOUNT_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def logout():
    if os.path.exists(ACCOUNT_PATH):
        os.remove(ACCOUNT_PATH)
