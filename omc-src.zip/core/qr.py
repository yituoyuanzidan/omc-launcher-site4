# -*- coding: utf-8 -*-
"""二维码生成：给手机控制台用，手机扫一下直接打开网页。

只依赖 qrcode + Pillow（都已打进发布包）；任一个缺失时返回 None，
调用方自己退回「只显示地址」的样子，不会让界面崩。
"""
import io

_CACHE = {}


def png_bytes(text, box=8, border=2):
    """生成 PNG 字节；失败返回 None。"""
    key = (text, box, border)
    if key in _CACHE:
        return _CACHE[key]
    try:
        import qrcode

        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=box,
            border=border,
        )
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#111319", back_color="#FFFFFF")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data = buf.getvalue()
    except Exception:
        return None
    _CACHE[key] = data
    return data


def png_bytes_sized(text, side=300, border=2):
    """输出近似 side×side 的方图（按估算的模块数调 box_size）。"""
    try:
        import qrcode

        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,
                           border=border)
        qr.add_data(text)
        qr.make(fit=True)
        modules = qr.modules_count + border * 2
        box = max(2, int(side // max(modules, 1)))
        return png_bytes(text, box=box, border=border)
    except Exception:
        return None
