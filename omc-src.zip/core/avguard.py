# -*- coding: utf-8 -*-
"""把启动器目录加进 Windows Defender 排除项。

Defender 的排除项只有管理员能写，所以这里必须借一次 UAC 提权：
弹一个系统确认框，用户点「是」之后才真正写入。程序自己不做任何静默提权。
"""
import os
import subprocess
import sys
import tempfile

_PS_TEMPLATE = """$ErrorActionPreference='Stop'
try {{
  Add-MpPreference -ExclusionPath '{dir}'
  Add-MpPreference -ExclusionProcess '{exe}'
  'ok' | Out-File -FilePath '{out}' -Encoding utf8
}} catch {{
  ('fail: ' + $_.Exception.Message) | Out-File -FilePath '{out}' -Encoding utf8
}}
"""


def supported():
    """只有 Windows + 打包后的程序才走这条逻辑。"""
    return sys.platform.startswith("win")


def install_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _ps_no_window():
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)


def excluded_paths():
    """读 Defender 现有的排除目录列表；读不到（没装 Defender 等）返回 []。"""
    if not supported():
        return []
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-MpPreference).ExclusionPath"],
            capture_output=True, text=True, timeout=30,
            creationflags=_ps_no_window())
    except Exception:
        return []
    out = []
    for line in (r.stdout or "").splitlines():
        s = line.strip().strip('"').strip("'")
        if not s:
            continue
        low = s.lower()
        # 非管理员读这个属性只会拿到一句提示，不是真的排除路径
        if low.startswith("n/a") or "exclusions" in low or "administrator" in low:
            continue
        out.append(s)
    return out


def already_excluded(extra_dirs=()):
    """安装目录是否已经在 Defender 排除项里（不管是谁加的）。"""
    here = os.path.abspath(install_dir()).lower().replace("/", "\\")
    targets = [here] + [os.path.abspath(d).lower().replace("/", "\\")
                        for d in extra_dirs if d]
    for p in excluded_paths():
        p = p.lower().replace("/", "\\").rstrip("\\")
        if not p:
            continue
        for t in targets:
            if t == p or t.startswith(p + "\\"):
                return True
    return False


def add_exclusion(timeout=180):
    """请求把安装目录和主程序加入 Defender 排除项。

    返回 (ok, message)。用户取消 UAC 会得到 (False, "已取消")。
    """
    if not supported():
        return False, "只有 Windows 需要这一步"
    d = install_dir().replace("'", "''")
    exe = os.path.basename(sys.executable) if getattr(sys, "frozen", False) \
        else "OMC.exe"
    out = os.path.join(tempfile.gettempdir(), "omc_av_result.txt")
    try:
        if os.path.exists(out):
            os.remove(out)
    except OSError:
        pass
    script = _PS_TEMPLATE.format(dir=d, exe=exe, out=out.replace("'", "''"))
    ps1 = os.path.join(tempfile.gettempdir(), "omc_av_whitelist.ps1")
    # PowerShell 5.1 读无 BOM 的 UTF-8 会按 ANSI 解析，中文路径会坏
    with open(ps1, "w", encoding="utf-8-sig") as f:
        f.write(script)

    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
           "-Command",
           "Start-Process powershell -Verb RunAs -WindowStyle Hidden "
           "-ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%s' "
           "-Wait" % ps1]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        return False, "超时：UAC 窗口可能还开着，点「是」后可以再试一次"
    except Exception as e:
        return False, "启动提权失败：%s" % e

    if os.path.exists(out):
        try:
            txt = open(out, encoding="utf-8", errors="replace").read().strip()
        except OSError:
            txt = ""
        if txt.startswith("ok"):
            return True, "已加入白名单：%s" % install_dir()
        if txt:
            return False, txt
    err = (r.stderr or "").strip()
    if "canceled" in err.lower() or "取消" in err:
        return False, "已取消"
    return False, err or "没有拿到结果，可能没点 UAC 的「是」"
