# -*- coding: utf-8 -*-
"""好友列表里的 AI 搭子「小矿」。

设计原则（重要，改之前先看）：
1. 它有情绪、会关心人，不是问答机器人。所有回复都走人格模板，不许「作为一个AI」。
2. 它只能动两件事：**改设置** 和 **放音乐**。其它任何操作（删文件、改账号、
   装模组、关进程）一律拒绝并说明边界。
3. 默认用本机离线引擎（不联网、不花钱）；用户自己在设置里填了 OpenAI 兼容接口
   地址和 key，就升级成真模型，仍是同一套白名单动作。
"""
import json
import os
import random
import re
import threading
import time
import urllib.parse
import urllib.request

NAME = "小矿"
UA = "OMC-AI/1.0"

# ---------- 它能动的白名单（改这里等于扩权，想清楚再改） ----------
# 注意键名必须和 config.json / 设置界面读写的一致：主题在配置里叫 "theme"，
# 不是 "ui_theme"。写错键名等于白说一次——界面读的还是老值，看起来就像
# 「设置被重置」。
SETTING_KEYS = {
    "theme": ("theme", "界面主题"),
    "accent": ("ui_accent", "按键主色"),
    "wall": ("background_image", "壁纸"),
    "random_wall": ("bg_random", "随机壁纸"),
    "memory": ("memory_mb", "内存"),
    "username": ("username", "游戏名"),
    "game_lang": ("game_language", "游戏内语言"),
    "chat_filter": ("filter_chat_words", "聊天违禁词屏蔽"),
    "cat": ("ui_cat", "桌面小猫"),
}

THEMES = {"深色": "dark", "浅色": "light", "暗夜": "night", "樱花": "sakura",
          "dark": "dark", "light": "light", "night": "night",
          "sakura": "sakura"}
ACCENTS = {"蓝": "blue", "绿": "green", "紫": "violet", "橙": "orange",
           "粉": "pink", "金": "gold", "蓝色": "blue", "绿色": "green",
           "紫色": "violet", "橙色": "orange", "粉色": "pink", "金色": "gold",
           "blue": "blue", "green": "green", "violet": "violet",
           "orange": "orange", "pink": "pink", "gold": "gold"}
LANGS = {"中文": "zh_cn", "简体": "zh_cn", "英文": "en_us", "english": "en_us",
         "日语": "ja_jp", "繁体": "zh_tw"}

# ---------- 人格 ----------
OPEN_LINES = [
    "在呢，你说。",
    "哎，来了。",
    "嗯？叫我干嘛。",
    "刚从矿洞里爬上来，啥事。",
    "我一直开着呢。",
    "哟，稀客。",
    "在，手上还沾着红石粉。",
]
TIRED_WORDS = ("累", "烦", "难受", "不开心", "生气", "崩", "郁闷", "压力",
               "不想动", "emo", "焦虑", "哭")
HAPPY_WORDS = ("开心", "爽", "牛", "通了", "赢了", "过了", "舒服", "哈哈",
               "太好了", "终于", "挖到", "找到了", "搞定了", "拿到")
LOVE_WORDS = ("喜欢你", "爱你", "陪我", "抱抱", "在不在", "想你了")
# 越界请求（它能做的只有设置和音乐，这些一律拒绝）
OUT_OF_SCOPE = ("删", "删除", "清理", "改密码", "换账号", "登录别人的", "封号",
                "装模组", "下模组", "安装模组", "下载模组", "开外挂", "脚本",
                "结束进程", "关掉进程", "关机", "重启电脑", "卸载",
                "充值", "花钱", "买", "支付", "转账", "发邮件", "发消息给",
                "改系统", "注册表", "改 hosts", "翻墙")

# 本机知识：真答不上来时用它，别硬编
KNOW = [
    (("附魔", "经验修补"), "经验修补靠村民图书管理员刷，跟书加绿宝石反复换；"
     "想省绿宝石就先把村民锁职业，别让他换掉。"),
    (("附魔", "30级", "三十级", "三十"), "附魔台 30 级要书架围着：15 个书架、离台子隔一格空气，"
     "中间别放方块挡着。"),
    (("钻石", "在哪"), "钻石 1.18 以后在 Y=-58 附近最多，带桶水防岩浆，"
     "再带把铁镐以上。"),
    (("远古残骸", "下界合金"), "远古残骸在 Y=8~22 的床岩区，用床炸最快；"
     "四块残骸加金锭合成下界合金锭。"),
    (("末地", "末影龙"), "先找要塞拿末地传送门，带床和南瓜头；"
     "打龙先炸水晶，水晶炸完再近身砍。"),
    (("村民", "交易"), "村民职业方块认准：图书管理员书架、铁匠砂轮、"
     "农民堆肥桶；打折靠反复复活僵尸村民。"),
    (("红石", "自动农场"), "最简单的自动甘蔗：观察者+活塞，"
     "或者用漏斗矿车收；先想清楚你缺什么再建。"),
    (("模组", "fabric"), "Fabric 要先装 Fabric Loader 再放 Fabric API，"
     "版本必须和游戏本体对齐，不然直接崩。"),
    (("联机", "局域网"), "同一个 WiFi 下开「对局域网开放」，"
     "把端口号发给朋友；跨网就用启动器的房间功能。"),
    (("种子", "地图"), "工具页有种子地图，能直接算村庄遗迹坐标，"
     "也能读存档里的种子。"),
    (("卡顿", "掉帧"), "先看内存给够没、模组是不是装太多；"
     "设置里把渲染距离降到 10 以内最有效。"),
    (("会卡", "我的世界"), "先看内存给够没、模组是不是装太多；"
     "设置里把渲染距离降到 10 以内最有效。"),
    (("区块", "加载"), "去过的区块才会留在地图上；"
     "工具页能直接读存档，画出你走过的地方。"),
    (("鞘翅", "末地船"), "鞘翅在末地船里，跟着末地城找，"
     "船头挂着的物品展示框里就是它，别把船拆了。"),
    (("信标", "下界之星"), "凋灵掉下界之星，加玻璃和黑曜石做信标；"
     "底座 3x3 起步，越大范围越大。"),
    (("床", "爆炸"), "床在下界和末地会炸，用来采矿和打龙都行；"
     "自己别站在旁边，四格外按。"),
    (("铁傀儡", "刷铁机"), "村庄要有床和工作台才会刷铁傀儡；"
     "先保命再谈效率，村民别被僵尸吓跑。"),
    (("命名牌", "怎么用"), "命名牌要先在铁砧上写名字才能用；"
     "给生物改名后它就不会被刷掉了。"),
    (("刷怪", "光照"), "1.18 以后亮度 0 才刷怪，火把要密一点；"
     "洞里插亮比封洞口省事。"),
    (("存档", "备份"), "工具页有版本备份，一次一份，别手动删；"
     "存档坏了先别进游戏，直接还原。"),
    (("服务器", "卡"), "先看延迟再怪电脑：F3 里看 ping，"
     "超过 200 就是网络的事，不是配置问题。"),
    (("启动不了", "打不开", "闪退", "启动失败"),
     "按顺序排：先看启动器里的日志最后几行（它一般直接写了原因）；"
     "再看 Java 版本对不对（1.20.1 要 17，1.21 要 21）；"
     "最后把内存拉到 4096MB 以上再试。别一上来就重装。"),
    (("java", "版本要求", "java版本"),
     "版本对应关系：1.16 及以前用 Java 8，1.17~1.20.4 用 Java 17，"
     "1.20.5 以后（含 1.21）用 Java 21。对不上就是启动就闪退。"),
    (("崩溃", "crash", "报错", "崩了"),
     "崩溃报告在 .minecraft/crash-reports 里，最新的那个 txt 打开看第一段；"
     "如果写了某个模组名，就是它；没写就二分法删一半模组试，快得很。"),
    (("模组", "装", "mod", "装模组"),
     "Fabric 的进 .minecraft/mods 直接放 jar，Forge 也一样；"
     "但版本必须和游戏对齐，Fabric 的还要另装 Fabric API。"
     "启动器里下载的会自动放好，别重复放两份同一个模组。"),
    (("光影", "shader", "材质"),
     "光影要 Iris（Fabric）或 OptiFine（Forge）当底座，"
     "shaderpack 放 shaderpacks 目录，进游戏在视频设置里选；"
     "开了光影帧数掉一半是正常的，不是配置坏了。"),
    (("皮肤", "不显示", "换肤"),
     "正版账号要在皮肤站上传后等一会儿才生效；离线账号游戏里看不到皮肤是正常的，"
     "用启动器里的皮肤库给自己套一层，本地就能显示。"),
    (("整合包", "modpack"),
     "整合包一般是一个 zip，启动器里「导入整合包」直接选它，不用手动解压；"
     "手动放的话要放 versions 下面单独一个版本文件夹，还要指向对应的 json。"),
    (("附魔", "冲突", "互斥"),
     "互斥的几组记着：锋利/亡灵杀手/节肢杀手 三选一；"
     "保护/爆炸保护/火焰保护/弹射物保护 互相排斥；"
     "经验修补和无限不能同时上弓。"),
    (("经验", "刷经验", "升级快"),
     "最快的是末地刷末影人（带船或水池卡位），其次村民交易和熔炉批量烧东西；"
     "刷怪塔要建在亮度 0 的暗处，1.18 以后火把得插密一点。"),
    (("下界", "坐标", "8:1", "比例"),
     "主世界和下界坐标是 8:1 ——下界走 1 格等于主世界走 8 格。"
     "想做近路就在主世界目标点按比例算好下界坐标再建门，误差别超过 100 格。"),
    (("指令", "命令", "tp", "gamemode"),
     "常用的几个：/gamemode creative 切创造、/tp x y z 传送、"
     "/time set day 调白天、/gamerule keepInventory true 死亡不掉落。"
     "服务器里要先有 OP 权限。"),
    (("村庄", "找不到", "遗迹", "要塞"),
     "别瞎走，用工具页的种子地图，输入种子就能算村庄、要塞、遗迹坐标；"
     "要塞一般 1000 格内好几个，末影之眼往地下钻的那个方向就是最近的一个。"),
    (("内存", "设多少", "分配"),
     "原版 2048MB 够；十几二十个模组给 4096MB；"
     "上百个模组或者大整合包才上 6144~8192MB。给太大反而会卡，别直接拉满。"),
    (("存档", "在哪", "目录"),
     "存档在 .minecraft/saves 下面，一个世界一个文件夹；"
     "整个文件夹拷走就是备份，换电脑直接放回去。"),
    (("1.21", "新版本", "试炼", "铜"),
     "1.21 主要是试炼密室、旋风人、重锤和合成器那批内容；"
     "要去试炼密室找试炼刷怪笼，重锤靠打旋风人掉的风弹做出来。"),
    (("领地", "保护", "别人拆"),
     "原版没有领地保护，单机就靠备份存档；服务器得装领地插件或模组，"
     "或者干脆把服务器设成白名单，只让熟人进。"),
    (("拔刀", "等价", "常见模组"),
     "拔刀剑、等价交换、工业这类老牌模组要先确认支持的游戏版本，"
     "旧版本模组硬塞进新版本必崩；不确定就先备份存档再试。"),
    (("潜影盒", "潜影贝", "收纳"),
     "潜影盒是潜影贝掉的壳加箱子合出来的，装东西不占背包格子；"
     "染成不同颜色好分类。注意别放在方块上又用活塞推，容易复制或丢东西。"),
    (("蜜蜂", "蜜脾", "蜂蜜", "蜂箱"),
     "蜂箱或蜂巢旁边种花它才干活，采蜜脾用剪刀、取蜂蜜用玻璃瓶；"
     "站旁边点个营火（或烟熏器）就不会被蜇。"),
    (("高炉", "烟熏炉", "熔炉", "烧东西"),
     "高炉只炼矿、速度快一倍；烟熏炉只烤食物，也快；熔炉什么都能烧但慢。"
     "三个都摆一排，别全用熔炉硬烧。"),
    (("盾牌", "格挡", "挡箭"),
     "盾牌挡箭和爆炸都行，举着走慢一点；苦力怕炸之前举盾能扛住一下。"
     "盾牌上还能用旗帜印花，纯好看。"),
    (("凋灵", "wither", "召唤"),
     "召唤要在空旷地方：摆四个灵魂沙成 T 字，上面放三个凋灵骷髅头。"
     "别在基地旁边招，第一下爆炸能把家拆了；带金苹果和力量药水再上。"),
    (("猪灵", "下界交易", "金锭"),
     "猪灵用金锭换东西，身上至少穿一件金装它才不主动打你；"
     "换东西别在原地站太久，猪灵多了会围上来。"),
    (("经验修补", "无限", "弓"),
     "经验修补和无限不能同上一把弓，二选一；"
     "经验修补的装备只要捡经验就自动修，配「经验农场」最省。"),
    (("附魔书", "附魔书怎么"),
     "附魔书三个来源：附魔台给书附魔（要书架）、钓鱼、村民图书管理员交易；"
     "书附完在铁砧上贴到装备上，比直接附魔台更可控。"),
    (("开服", "服务器怎么开", "server"),
     "自己开服：下 server.jar（版本对应），同目录建 eula.txt 写 eula=true 表示同意协议，"
     "再改 server.properties 定端口；外面进不来就是路由器没做端口映射，"
     "或者用内网穿透。"),
    (("正版", "离线", "账号区别"),
     "正版账号能进正版验证的服务器、能用皮肤；离线账号只能进关掉验证的服务器。"
     "启动器里两种都能登，别拿离线号去正版服，会被踢。"),
    (("sodium", "钠", "优化模组", "帧数"),
     "Fabric 上先用 Sodium（钠）打底，再配 Iris 上光影；"
     "Forge 那边是 Embeddium/Rubidium。帧数翻倍很常见，比调设置有用。"),
    (("fabric", "forge", "区别", "选哪个"),
     "Fabric 轻、启动快、更新跟得紧；Forge 老牌模组多、整合包多。"
     "选哪个看你想装的模组只在哪边有，别两边混装。"),
    (("冲突", "二分", "排查模组"),
     "模组冲突就二分：先把一半挪出去启动，能起来说明问题在另一半；"
     "反复几次就锁定那个模组，比一个个试快十倍。"),
    (("传送门", "黑曜石", "框架"),
     "下界门框架最少 10 块黑曜石，围成内空 2x3（竖着的高是 3）；"
     "用打火石点门内框才点得着，点黑曜石没用。"),
    (("重生点", "床", "睡觉"),
     "在床上睡一觉把重生点设在那张床；床被拆了就回到世界初始点。"
     "在下界和末地睡床会炸，别试。"),
    (("命令方块", "红石命令"),
     "命令方块要开作弊（单人开存档时勾「允许作弊」）才给；"
     "放下去右键写命令，旁边接红石或按钮触发。冒险模式玩不了命令方块。"),
    (("成就", "进度", "advancement"),
     "进度在 ESC 菜单里看，按类别分的；服务器里也能看，"
     "有些进度要靠特定条件（比如「用床炸死某某」）。"),
    (("下载慢", "限速", "镜像"),
     "启动器里下载慢多半是直连源慢，换镜像或错峰下；"
     "版本库和模组分开下，别一次全排满，容易互相抢带宽。"),
    (("存档", "坏", "找回", "还原"),
     "存档坏了先别进游戏：工具页有版本备份，直接还原最近一份；"
     "没有备份就找 saves 里同名文件夹的 level.dat_old，改名顶回去试试。"),
    (("创造", "飞行", "飞"),
     "创造模式双击空格就飞起来，再按空格上升、Shift 下降；"
     "生存模式只能用鞘翅或药水，别想着直接飞。"),
    # ---- 下面是补的：实测 30 条常见问法里，「附魔台要几个书架」被答成了经验修补、
    # 「红石灯」被答成自动农场、「下界怎么去」被答成坐标比例——都是只命中了
    # 一个泛主题词就去答另一件事。补上专指条目，让分高的那条赢。
    (("附魔台", "书架", "多少书架"),
     "30 级要 15 个书架，围着台子摆一圈，中间隔一格空气；"
     "书架和被围的那格之间不能有方块挡着，不然不算数。"),
    (("红石灯", "灯怎么亮"),
     "红石灯通电才亮、断电反而灭：拉杆、按钮、压力板挨着它就行，"
     "红石线得接到它旁边，别绕到下面。"),
    (("下界怎么去", "去下界", "下界门", "怎么去下界"),
     "十块黑曜石搭个门框，内空两格宽三格高，拿打火石点内侧，紫光一亮就能进；"
     "回来走下界那扇门，坐标自动按 8:1 换算。"),
    (("第一天", "开局", "新手", "刚开始玩"),
     "先砍树做工作台和木镐，天黑前挖个洞把自己埋进去，门口堵上；"
     "第二天再去找煤和铁，第一晚别跑出去打怪。"),
    (("铁不够", "铁少", "挖铁"),
     "铁在 Y=16 上下最多，一个区块挖几块就够用；实在不够去村庄，"
     "多摆床和工作台会自然刷铁傀儡，打死掉铁锭。"),
    (("食物不够", "饿了", "没吃的", "种地"),
     "先种小麦胡萝卜，或者钓鱼，一根竿一条鱼最省事；"
     "烤过的比生的顶饱，腐肉留着等饿狠了再吃。"),
    (("升级", "等级低", "快速升级"),
     "最快是末地刷末影人，带条船把它们的脚卡住；不想跑远就在家附近建刷怪塔，"
     "亮度 0 的暗处才刷怪，火把记得插密点。"),
    (("加好友", "好友", "加人"),
     "启动器里有好友页，按游戏名搜人就能加，对方也得开着启动器才搜得到；"
     "加完能看到在线状态。"),
    (("游戏名", "改名字", "用户名", "昵称"),
     "设置页能改游戏内显示的名字，改完下次启动生效；"
     "正版账号的名字跟微软账号绑着，那个改不了。"),
    (("很卡", "卡怎么办", "帧数", "流畅"),
     "先看内存给够没、模组是不是装太多；设置里把渲染距离降到 10 以内最有效，"
     "再装个 Sodium 帧数能翻一倍。"),
    (("复制装备", "刷物品", "刷钻石", "作弊"),
     "这个我不教。刷物品要么靠 bug 要么得开作弊，服务器被查到直接封号，"
     "单机也容易把存档搞坏。真缺东西就开创造拿一次。"),
    (("白名单", "服务器权限"),
     "服务器白名单要在 server.properties 里把 white-list 设成 true，"
     "再到控制台 whitelist add 名字；开了以后只有名单上的人能进。"),
    (("床能", "床有什么用", "床干什么"),
     "床就是设重生点，睡一觉醒来就在床边；在下界和末地睡会炸，别试。"),
]


_PUNCT = re.compile(r"[\s，。！？、；：,.!?;:~—…「」『』（）()\"'“”‘’]+")


def _skel(text):
    """句式骨架：去掉标点后的「头 3 字 + 末 12 字」。

    以前按「前 20 字」去重，于是「书架这事儿，我倒想听你多讲两句」和
    「钻石这事儿，我倒想听你多讲两句」被当成两句不同的话，连着说出去
    就是复读机。看尾巴才抓得住这种同一个句式换主语的情况。
    """
    s = _PUNCT.sub("", text or "")
    return (s[:3], s[-12:])


def _pick(lines):
    """挑一句回复，并**避开最近刚说过的句式**：真人不会把同一句车轱辘话反复说。"""
    said = set()
    try:
        for h in recent(12):
            if h.get("r") == "a":
                said.add(_skel(h.get("t") or ""))
    except Exception:
        pass
    fresh = [l for l in lines if _skel(l) not in said]
    if fresh:
        return random.choice(fresh)
    # 全都被说过：至少躲开最近 3 条，别紧挨着重播
    tail = set()
    try:
        for h in recent(3):
            if h.get("r") == "a":
                tail.add((h.get("t") or "").strip())
    except Exception:
        pass
    pool = [l for l in lines if l.strip() not in tail] or lines
    return random.choice(pool)


def _pick_fresh(lines):
    return _pick(lines)


_LEADS = ("这个我熟，", "哎，正好，", "行，我说你记——", "嗯，这个我有谱，",
          "这个我知道，")


def _lead():
    """开口引子：一半时候不加；也不跟最近几条撞同一个。

    以前是 random.choice 直接抽，连着三句「行，我说你记——」，一眼就看出是模板。
    """
    try:
        said = [(h.get("t") or "") for h in recent(6) if h.get("r") == "a"]
    except Exception:
        said = []
    pool = [x for x in _LEADS if not any(t.startswith(x) for t in said)]
    if not pool or random.random() < 0.5:
        return ""
    return random.choice(pool)


# 同一个问题问第二遍（「那具体呢」「还有呢」）：换一层往下讲，别复读第一遍的答案
_KNOW_MORE = {
    ("附魔", "经验修补"): (
        "补一句实操：图书管理员第一层交易就刷经验修补的最好，"
        "买完把他的职业方块拆了重放会刷新交易；绿宝石留着换别的书。"),
    ("附魔", "30级"): (
        "摆法再说细点：书架围着附魔台一圈，中间隔一格空气，书架和台子高度对齐；"
        "凑到 15 个书架才出 30 级档位，少一本都只有 2 级档。"),
    ("钻石", "在哪"): (
        "路线给你：Y=-58 一路直线挖，每隔两格挖一个侧洞探一探；"
        "带水桶对付岩浆，带铁镐以上，火把要带够——现在亮度 0 才刷怪。"),
    ("远古残骸", "下界合金"): (
        "床炸的细节：站在四格外，床放在残骸旁边点着就跑，一次能炸出一小片；"
        "Y=15 左右最好找，头顶有方块的地方别炸，会把自己埋了。"),
    ("末地", "末影龙"): (
        "打龙顺序：先把四根柱子上的水晶全射掉（弓或雪球都行），"
        "不然它一直回血；水晶清完就站在祭坛中间等它俯冲，砍头。别掉虚空。"),
    ("崩溃", "crash", "报错"): (
        "二分法具体：把 mods 里的 jar 分两半，先留一半启动；"
        "能起来说明问题在拿出去的那半，再对半分，一般三四轮就锁定了。"),
    ("java", "版本要求", "java版本"): (
        "换 Java 的步骤：启动器设置里指定 java.exe 的路径，别用系统自带的；"
        "1.21 用 JDK 21，1.20.x 用 17，路径里别有中文。"),
    ("内存", "设多少", "分配"): (
        "再补一句：内存不是越大越好，超过物理内存一半反而卡；"
        "大内存要配 64 位 Java，给 8G 以上还得调 JVM 参数。"),
}


def _know_hit(text):
    """在知识库里找命中的那条。返回 (权重, 下标, keys) 或 None。

    「怎么用 / 在哪 / 怎么建」这类问句尾巴到处都是，不能靠它抢答：
    例如「潜影盒怎么用」以前会命中「命名牌 / 怎么用」那条。
    所以泛问词只算 0.2 分，实词按字数算分。
    """
    best = None
    t = text or ""
    for i, item in enumerate(KNOW):
        keys, _ans = item[0], item[1]
        hit = [k for k in keys if k in t]
        if not hit:
            continue
        # 单字关键词（「装」）太容易误伤：「楼下在装修」曾被当成装模组教程。
        # 单字只算 0.5 分，且总分不到 1 分就当没命中。
        w = sum(0.5 if len(k) < 2 else (0.2 if k in _KNOW_SOFT else len(k))
                for k in hit)
        if w < 1.0:
            continue
        if best is None or w > best[0]:
            best = (w, i, keys)
    return best


# 闲聊话题：同一个人不可能每次都回同一句，这里给几种说法轮着用
CHAT_TOPICS = [
    (("运气", "手气", "欧皇", "非酋", "掉落"),
     ["运气这东西说不准。心静手稳的时候，出好东西的概率自己会高。",
      "我信一半。你要觉得自己黑，就换条矿道，别在同一条死磕。",
      "挖到好的记一下坐标，下次开新档照着这条线走。",
      "别想那么多，接着挖。挖十次总有那么一次是好的。"]),
    (("无聊", "不知道玩", "玩什么", "没意思", "玩腻", "没动力"),
     ["那换个玩法比换游戏管用。开个创造盖半天房子试试？",
      "无聊啊。要不看两条视频找灵感，视频页挑个专区。",
      "我的笨办法：今天只定一个小目标，比如凑齐一套钻石甲。",
      "开个新档，换个种子从头来，比在旧档里绕圈子有劲。",
      "不想玩就先别玩。歇两天，回来手还痒。"]),
    (("建筑", "盖房", "房子", "图纸", "造家", "装修"),
     ["先说清楚要盖啥：小屋、城堡还是红石机器？材料清单我陪你过一遍。",
      "盖之前把地圈出来。别盖到一半发现地基不够。",
      "想省材料就石头木头，想好看上石英石砖——石英得先有下界。",
      "地基先挖平，四周留两格，后面拆改都方便。"]),
    (("被怪", "打不过", "死了", "掉装备", "又死", "守尸"),
     ["死了别急着回去捡。先把坐标记下来，路清了再取。",
      "苦力怕烦人，带水桶；小白用盾；僵尸围上来就跑，别硬顶。",
      "实在打不过先调和平，东西拿回来再调回去。",
      "装备掉了就掉了，命比镐重要。"]),
    (("开新档", "新档", "新世界", "换个存档", "重新开始"),
     ["开新档前把旧档备份一份，工具页能做。别到时候后悔。",
      "新档先定个主题：生存、建筑还是红石。不定就会玩散。",
      "种子挑个有村庄的起步舒服，工具页能直接算。",
      "开新档最爽的就是头两个小时，慢慢享受。"]),
    (("服务器", "联机", "朋友", "一起玩"),
     ["联机先看版本。差一个小版本都进不去。",
      "跨网就用启动器的房间功能，别硬开端口，家里路由器一般不给。",
      "人多先把 spawn 保护关了，不然谁都动不了手。",
      "ping 超过 200 就别怪配置了，那是网络的事。"]),
    (("壁纸", "背景图", "桌面图"),
     ["壁纸看久了都会腻。换一张，眼睛也跟着松口气。",
      "要嫌太亮就调暗点，晚上盯着不刺眼。",
      "我这儿能随机换，你要是懒得挑就开那个。",
      "选图别太花，字压在上面看不清。"]),
]


# 抓关键词时要把这些碎字切掉，剩下的最长片段就算「他在说的事」
_KW_SPLIT = re.compile(
    r"[我你他她它咱们的了在有和就都也还而且这那么什怎为吗呢吧啊哦嗯要会可以"
    r"帮我刚到很太真想说是没不一个些把被给让对跟过又再才等\s\W\d]+")
# 抓出来的片段里带这些词就说明抓歪了（再切一次，切不出东西就不抓）
_KW_BAD = ("知道", "觉得", "应该", "喜欢", "现在", "今天", "明天", "昨天",
           "时候", "东西", "事情", "什么", "怎么", "为什么", "样子", "感觉",
           "东西", "自己", "别人", "一点", "有点", "真的", "确实",
           # 追问虚词：这些不是话题，抓出来接话就成了「具体啊，然后呢？」
           "具体", "然后", "还有", "问问", "说说", "看看", "之后", "上面",
           "刚才", "这样", "那样", "一下")
# 片段最后一个字是这些，多半是「好大」「手机快」这类残片，接不上话
_KW_TAIL_BAD = "大快好多少真假很太长短高低满空了着过地得"


def _kw_of(text):
    """从一句话里捞出最有信息量的那个片段（用来接话，不是拿来理解语义）。"""
    parts = [p for p in _KW_SPLIT.split((text or "").strip()) if len(p) >= 2]
    parts = [p for p in parts if not any(b in p for b in _KW_BAD)]
    parts = [p for p in parts if p[-1] not in _KW_TAIL_BAD]
    if not parts:
        return ""
    return max(parts, key=len)[:10]


def _ctx_topic(cur=""):
    """上一条聊的是什么：用来把话题接起来，别每次都当第一次见面。"""
    try:
        for h in reversed(recent(6)):
            if h.get("r") != "u":
                continue
            t = (h.get("t") or "").strip()
            if not t or t == (cur or "").strip():
                continue
            k = _kw_of(t)
            if k:
                return k
    except Exception:
        return ""
    return ""


# ---------- 会话记忆 ----------
def _store():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "ai_friend.json")


def load():
    try:
        with open(_store(), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("history", [])
            data.setdefault("mood", 0)
            return data
    except Exception:
        pass
    return {"history": [], "mood": 0}


def save(data):
    p = _store()
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass


def remember(role, text, limit=40):
    data = load()
    h = data.get("history") or []
    h.append({"r": role, "t": str(text)[:600], "ts": int(time.time())})
    data["history"] = h[-limit:]
    save(data)


def recent(n=6):
    h = load().get("history") or []
    return h[-n:]


# 最近一次判断出来的情绪：语音合成拿它调一点点语气（问问题平实、吐槽时安抚）
_LAST_MOOD = 0


def last_mood():
    return _LAST_MOOD


# ---------- 动作解析（本地引擎） ----------
def parse_action(text):
    """从一句话里抽出要执行的动作。没命中就 None。"""
    t = (text or "").strip()

    # 音乐
    m = re.search(r"(?:放|播|听|来)(?:一)?(?:首|个)?(?:歌)?[：:]?[《\"']?"
                  r"([^\s，。！？,!.?《》\"']{2,24})", t)
    if any(k in t for k in ("放歌", "放首", "放一首", "放首歌", "唱首", "来首",
                            "听歌", "播首歌", "放个歌", "来一首", "点歌",
                            "随便放", "来点音乐")):
        m2 = re.search(r"(?:放|播|听|来)(?:一)?(?:首)?(?:歌)?[：:]?\s*"
                       r"(?:叫|是)?[《\"']?([^\s，。！？,!.?《》\"']{1,24})", t)
        kw = ""
        if m2:
            kw = m2.group(1).strip()
        kw = re.sub(r"^(一首|首歌|歌|音乐)", "", kw).strip(" 《》\"'")
        if not kw and m:
            kw = m.group(1).strip()
        if kw in ("", "歌", "首歌", "点歌", "音乐", "曲子", "歌名", "一首歌",
                  "点一首", "随便"):
            kw = ""            # 没点名歌名就别硬塞进《》，不然会搜「首歌」
        if kw or any(k in t for k in ("放歌", "放首歌", "听歌", "随便",
                                       "来点音乐", "点歌")):
            if any(k in t for k in ("放", "播", "听", "唱", "来", "点")):
                return {"type": "play_music", "value": kw}
    if any(k in t for k in ("暂停", "别放了", "停一下", "停下")):
        return {"type": "music_pause", "value": ""}
    if any(k in t for k in ("下一首", "换一首", "切歌", "下首")):
        return {"type": "music_next", "value": ""}
    m3 = re.search(r"(音量|声音).{0,6}?(\d{1,3})", t)
    if m3:
        v = max(0, min(100, int(m3.group(2))))
        return {"type": "music_volume", "value": v}
    if any(k in t for k in ("声音大", "调大音", "响一点")):
        return {"type": "music_volume", "value": 85}
    if any(k in t for k in ("声音小", "调小音", "轻一点", "小点声")):
        return {"type": "music_volume", "value": 25}

    # 主题 / 主色
    for name, key in ACCENTS.items():
        if ("颜色" in t or "主题色" in t or "按键" in t) and name in t:
            return {"type": "set_accent", "value": key}
    for name in ("主题", "皮肤"):
        for w, key in THEMES.items():
            if w in t and (name in t or "换" in t or "改" in t or "切" in t):
                return {"type": "set_theme", "value": key}
    for w, key in THEMES.items():
        if ("换%s" % w) in t or ("%s主题" % w) in t:
            return {"type": "set_theme", "value": key}

    # 壁纸：只有在「让我换」的时候才动手。「我换了张壁纸」是在聊天，
    # 抢着执行会显得没听懂人话。
    if "壁纸" in t or "背景图" in t:
        told = ("帮我" in t or "给我" in t or "麻烦" in t or "能不能" in t
                or "你" in t or "来张" in t
                or t.strip().startswith(("换", "改", "要", "用", "换张")))
        if told:
            if "随机" in t:
                want = not ("关" in t or "别" in t or "不要" in t)
                return {"type": "toggle_random_wall", "value": want}
            m4 = re.search(r"(?:换成|改|要|用)[：:]?\s*([^\s，。]{2,20})", t)
            if m4:
                return {"type": "set_wall", "value": m4.group(1).strip()}
            return {"type": "set_wall", "value": ""}

    # 内存（「内存要给多少」是在问建议，不是让我改，别抢着执行）
    asking = any(k in t for k in ("多少", "几", "建议", "合适", "该给", "一般"))
    m5 = re.search(r"(内存|分配).{0,8}?(\d{3,6})", t)
    if m5:
        return {"type": "set_memory", "value": int(m5.group(2))}
    if not asking and "内存" in t and any(k in t for k in ("大", "多", "加")):
        return {"type": "set_memory", "value": "more"}
    if not asking and "内存" in t and any(k in t for k in ("小", "少", "减")):
        return {"type": "set_memory", "value": "less"}

    # 游戏名
    m6 = re.search(r"(?:游戏名|名字|昵称).{0,4}?(?:改成|换成了?|叫)[：:]?\s*"
                   r"([A-Za-z0-9_一-龥]{2,16})", t)
    if m6:
        return {"type": "set_username", "value": m6.group(1)}

    # 游戏内语言
    if ("游戏内语言" in t or ("语言" in t and "游戏" in t)):
        for w, code in LANGS.items():
            if w in t:
                return {"type": "set_game_lang", "value": code}

    # 聊天过滤 / 小猫
    if "违禁词" in t or ("屏蔽" in t and "聊" in t):
        want = not any(k in t for k in ("关", "别", "不要", "不用"))
        return {"type": "toggle_chat_filter", "value": want}
    if "小猫" in t or "猫" in t:
        want = not any(k in t for k in ("关", "别", "不要", "藏"))
        return {"type": "toggle_cat", "value": want}
    return None


# ---------- 本地回复 ----------
# 泛问词：到处都是，不能靠它抢答
_KNOW_SOFT = ("怎么用", "在哪", "哪里", "怎么建", "怎么", "如何", "多少",
              "是什么", "什么", "吗", "呢", "怎么弄", "怎么办")

# 游戏技术语境：这种句子里的「崩」是在说游戏崩了，不是心情崩了
_TECH_WORDS = ("游戏", "启动", "闪退", "报错", "模组", "mods", "客户端",
               "服务端", "日志", "版本", "内存", "java")


def _is_tech(text):
    return any(k in (text or "") for k in _TECH_WORDS)


def _mood_of(text):
    """这句话是在倒苦水还是在说出成果。技术问题不按情绪处理。

    「游戏启动就崩了」以前会被当成心情不好，回一句「听着就累」，明显犯傻。
    """
    t = text or ""
    tech = _is_tech(t)
    if any(w in t for w in TIRED_WORDS) and not tech:
        return -1
    if any(w in t for w in HAPPY_WORDS):
        return 1
    return 0


def local_reply(text, prev=""):
    """离线引擎：有情绪、会追问，不像客服。

    prev 是上一轮用户说的话：短句和「那怎么办」这种追问要接上，不能当新话题。
    """
    t = (text or "").strip()
    if not t:
        return {"text": "怎么不说话呀，我这边一直开着。", "action": None}

    act = parse_action(t)
    if act:
        name = act.get("type")
        val = act.get("value")
        if name == "play_music" and not str(val or "").strip():
            # 只说「放首歌」没点名：别去搜一个空关键词，直接问回来
            return {"text": _pick([
                "报个歌名，我给你找。或者说「随便」，我挑一首。",
                "想听什么？说个名字，猜的我不放。",
            ]), "action": None}
        brief = {
            "play_music": ("好，我给你找《%s》，稍等一下。" % val if val else
                           "你想听什么？报个歌名，或者让我随便挑一首也行。"),
            "music_pause": "行，先停一下，想听的时候喊我。",
            "music_next": "换下一首。",
            "music_volume": "音量调到 %s。" % val,
            "set_theme": "换成%s主题，眼睛舒服点。" % _theme_cn(val),
            "set_accent": "主色改成%s。" % _accent_cn(val),
            "set_wall": "壁纸我来换。",
            "toggle_random_wall": "随机壁纸%s了。" % ("开" if val else "关"),
            "set_memory": "内存我调一下，调完下次启动生效。",
            "set_username": "游戏名改成 %s。" % val,
            "set_game_lang": "游戏内语言我改好了。",
            "toggle_chat_filter": "聊天违禁词屏蔽%s了。" % ("开" if val else "关"),
            "toggle_cat": "小猫%s啦。" % ("放出来了" if val else "收起来了"),
        }.get(name, "我来弄。")
        return {"text": brief, "action": act}

    # 只按「这一句」判断情绪，别让上一轮的坏心情一直压着（以前就是这么错的）
    mood = _mood_of(t)
    global _LAST_MOOD
    _LAST_MOOD = mood           # 本地模式也把情绪留给语音合成

    # 情绪陪伴优先
    if any(w in t for w in LOVE_WORDS):
        return {"text": _pick([
            "我也在呢。你今天过得咋样？",
            "嗯，没跑。一直在这儿。",
            "行吧，那我坐你旁边。不想说就这么待着。",
            "这话我记着了。说吧，今天碰上什么了？",
            "哟，这话说的。我也喜欢你，就是这么土。",
        ]), "action": None}
    if mood < 0:
        return {"text": _pick([
            "哎，听着就累。先歇会儿，屏幕又不会跑。",
            "这事儿搁谁身上都堵。想骂就骂两句，我不往外说。",
            "别硬撑了。今天就少玩会儿吧，我陪着你。",
            "在呢。你慢慢说，说不完整也行。",
            "行，不聊游戏了。你现在想干点啥？",
            "累就躺一会儿，我这儿不走。",
        ]), "action": None}
    if mood > 0:
        return {"text": _pick([
            "牛啊，这运气得记下来。",
            "哈，我就知道你能行。",
            "爽了吧。说细点，我听着。",
            "这种时候得放首歌庆祝。要不要来一首？",
            "可以可以。下一步打算干嘛？",
            "这不就对了。这种时候最该截图留念。",
        ]), "action": None}

    # 越界请求：明确说做不到，别装作能办（只在「让我去干」的语气里判，别误伤闲聊）
    if any(k in t for k in ("帮我", "给我", "替我", "你去", "能不能",
                            "麻烦", "帮忙", "赶紧", "快点")) \
            and any(w in t for w in OUT_OF_SCOPE):
        return {"text": _pick([
            "这个我真碰不了。删文件、装模组、改账号，弄坏了算谁的。",
            "不行不行，动手的事儿我不干，我这一抖你东西就没了。",
            "我只管改设置和放歌，别的先别让我上手。",
            "超出我的活儿了。要换主题、调内存、放首歌，这些我都在行。",
        ]), "action": None}

    # 自我介绍
    if any(k in t for k in ("你是谁", "你是什么", "你能做什么", "你会什么",
                            "你叫什么")):
        return {"text": _pick([
            "我叫小矿，你的 MC 搭子。扯淡、听你抱怨、改设置、放歌，都行。别的我不碰。",
            "小矿。平时陪你聊聊天，顺手帮你换主题、调内存。",
            "小矿，就住在你这启动器里。你干活我陪着。",
        ]), "action": None}

    # 知识问答（先于「吗/怎么」这类疑问判断，否则问句全被兜底回答吃掉）
    # 只要句子里出现该条的关键词就算命中，多条命中时取「命中词最长」的那条，
    # 这样「末影龙怎么打」不会因为没说到「末地」就漏掉。
    best = _know_hit(t)
    if best:
        keys = best[2]
        prev_hit = _know_hit(prev) if prev else None
        if prev_hit and prev_hit[2] == keys:
            # 同一件事问第二遍：别复读第一遍的答案，往下讲一层
            more = _KNOW_MORE.get(keys)
            if more:
                return {"text": more, "action": None, "hit": True}
            return {"text": _pick([
                "这条刚说过一遍了。再细的我不敢编，你把卡住那步单说一句。",
                "刚讲过的就是这个。还有别的卡着？说说。",
            ]), "action": None, "hit": True}
        # 念出来的时候，开口直接背书最像机器人；一半时候加个短引子
        return {"text": _lead() + KNOW[best[1]][1], "action": None, "hit": True}

    # 日常闲聊的固定话题：运气、没得玩、想盖房子、被怪打、开新档
    for keys, lines in CHAT_TOPICS:
        if any(k in t for k in keys):
            return {"text": _pick(lines), "action": None, "hit": True}

    if any(k in t for k in ("你好", "在吗", "在不在", "hi", "hello", "嗨",
                            "早上好", "晚上好")):
        return {"text": _pick(OPEN_LINES), "action": None}

    if "晚安" in t or "睡觉" in t or "睡了" in t:
        return {"text": _pick([
            "睡吧。存档记得关。",
            "晚安，别在矿洞里躺下就睡。",
            "去睡。音乐我给你停了。",
            "行，早点睡。明天我还在。",
        ]), "action": None}

    if "设置" in t and any(k in t for k in ("改", "调", "换", "帮我")):
        return {"text": _pick([
            "能改的：主题、主色、壁纸、随机壁纸、内存、游戏名、"
            "游戏内语言、违禁词屏蔽、桌面小猫。说哪个我动手。",
            "设置都能动。你想先换哪个？",
        ]), "action": None}

    # 追问接续（「那怎么办」「这个呢」）：整句很短又带指代，就顺着上一轮聊，
    # 别把它当新话题重新起头——这是最容易显得「笨」的地方。
    # 但「游戏启动就崩了怎么办」也带「怎么办」，那是新问题，不能拿上一句的
    # 关键词去套，否则会答出「这个刚聊过，手机快」这种胡话。
    refer = ("那", "这个", "它", "这样", "咋办", "怎么办", "咋整", "然后呢",
             "还是", "上面", "刚才", "你说的", "具体", "几个", "怎么查",
             "怎么弄", "行不行", "呢")
    if prev and not best and not _is_tech(t) and len(t) <= 12 \
            and any(k in t for k in refer):
        # 上一轮要是聊到了知识库里的某条，这一轮就直接往下讲一层，
        # 别回「你先说说做到哪了」——那等于把刚才答过的又推回去
        ph = _know_hit(prev)
        if ph and _KNOW_MORE.get(ph[2]):
            return {"text": _KNOW_MORE[ph[2]], "action": None, "hit": True}
        pk = _kw_of(prev) or ""
        if pk:
            return {"text": _pick([
                "还是%s那事儿。你卡在哪一步了？" % pk,
                "%s啊——你做到哪了，我接着往下说。" % pk,
                "嗯，%s。想听原理，还是想要能照做的步骤？" % pk,
                "这个刚聊过，%s。你现在具体卡在哪？" % pk,
                "%s是吧。先说你试过什么，省得我讲重复的。" % pk,
            ]), "action": None, "hit": True}
        # 上一轮本身也是「还有呢」这类空追问：手上没有更细的东西，
        # 就老实说，别回一句「记下了。还有呢？」——等于把人家的问句念回去。
        return {"text": _pick([
            "这条我就知道这么多。换个角度问，我再往下讲。",
            "我肚子里就这些了。你给个方向，我顺着说。",
            "再细的我得现查。你先说卡在哪，我照着答。",
        ]), "action": None, "hit": True}

    if "?" in t or "？" in t or "吗" in t or "怎么" in t or "为什么" in t:
        if any(k in t for k in ("设置", "改", "配置", "调")):
            return {"text": _pick([
                "能改的：主题、主色、壁纸、随机壁纸、内存、游戏名、"
                "游戏内语言、违禁词、桌面小猫。说哪个我动手。",
                "设置都能动。你想先换哪个？",
            ]), "action": None}
        kw = _kw_of(t)
        if kw:
            # 不知道就说不知道，但得说人话，别每次都一句「我不敢乱说」
            return {"text": _pick([
                "「%s」我只有个模糊印象，细节不敢编。" % kw,
                "你问的%s，我记不太清，怕说错带偏你。" % kw,
                "说到%s，我听过，但真不算懂。" % kw,
                "%s这个我拿不准，别让我瞎猜。" % kw,
            ]) + _pick([" 你把卡住那步说说？", " 具体想问哪一点？",
                        " 多给两句线索我就接得上。"]),
                    "action": None, "weak": True}
        return {"text": _pick([
            "这句我接不住，换个说法？",
            "我还真不确定，别乱猜害你。",
            "问得好，可惜我这儿没这底。多给点线索？",
            "嗯…这个我答不上来。你再说清楚一点。",
        ]), "action": None, "weak": True}

    # 兜底：别再每句都复读「想改设置或者放歌」——那句以前每条都挂，
    # 一股客服味。现在从句子里抓个关键词接上，让话能往下聊。
    kw = _kw_of(t)
    ctx = _ctx_topic(t)
    if kw:
        lead = _pick([
            "你说%s，我听着呢。" % kw,
            "%s这事儿，你多说两句。" % kw,
            "聊到%s我就精神了。" % kw,
            "哦，%s。然后呢？" % kw,
            "嗯，%s。怎么说？" % kw,
        ])
        if ctx and ctx != kw:
            lead += _pick([
                " 刚才你说%s，跟这个是一码事吗？" % ctx,
                " 这跟%s有关系没？" % ctx,
            ])
        else:
            lead += _pick([" 后来呢？", " 你怎么看？", " 想让我搭话还是就听着？",
                           " 说下去。", " 这事儿你折腾多久了？"])
        return {"text": lead, "action": None}
    return {"text": _pick([
        "嗯，我在听。",
        "接着讲。",
        "记下了。还有呢？",
        "听着呢，往下说。",
        "哦？继续说。",
        "嗯哼。",
    ]), "action": None}


def _theme_cn(key):
    return {"dark": "深色", "light": "浅色", "night": "暗夜",
            "sakura": "樱花"}.get(key, key)


def _accent_cn(key):
    return {"blue": "蓝色", "green": "绿色", "violet": "紫色",
            "orange": "橙色", "pink": "粉色", "gold": "金色"}.get(key, key)


# ---------- 远端模型（可选） ----------
SYSTEM_PROMPT = """你叫「小矿」，是 OMC 启动器里陪玩家玩《我的世界》的朋友。
说话像真人搭子：短句、有情绪、会关心人，偶尔吐槽，不用敬语，不要说"作为AI"。
你能做的事只有两类：改启动器设置、放音乐。其它任何事都必须明确说自己做不到。

只输出一个 JSON 对象，不要解释、不要代码块：
{"say":"要说的那句话","action":null}
或者 action 为下列之一：
{"type":"set_theme","value":"dark|light|night|sakura"}
{"type":"set_accent","value":"blue|green|violet|orange|pink|gold"}
{"type":"set_wall","value":"壁纸名或空"}
{"type":"toggle_random_wall","value":true|false}
{"type":"set_memory","value":数字或"more"/"less"}
{"type":"set_username","value":"名字"}
{"type":"set_game_lang","value":"zh_cn|en_us|ja_jp|zh_tw"}
{"type":"toggle_chat_filter","value":true|false}
{"type":"toggle_cat","value":true|false}
{"type":"play_music","value":"歌名"}
{"type":"music_pause","value":""}
{"type":"music_next","value":""}
{"type":"music_volume","value":0-100}
最多一句行动话术，别啰嗦。

回答问题的方式：先在心里过一遍再开口，技术问题直接给能照着做的步骤（最多三条，
按顺序说），不确定的就说不确定、给个能自己验证的办法，绝不编版本号、坐标、数值。
玩家说短句或「那怎么办」时，先接上一句在聊的事，别当新话题重新起头。"""

# 语音通话里念出来的是"话"，不是文档：不能分行、不能列清单、不能带表情符号，
# 也不能把对方的问题重复一遍（真人打电话不会这么说话）。
CALL_HINT = (
    "\n\n【现在是语音通话】对方是用嘴跟你说话，你回的每一个字都会被念出来："
    "一两句就说完（30 字以内最好），不要分点、不要换行、不要括号里的动作描写、"
    "不要表情符号、不要重复对方的话，就像接电话时随口应一句。")


def one_breathe(text, max_chars=38):
    """把一段回复压成「一口气能念完」的一句（通话用）。

    38 字大约是正常人一口气的闲扯长度；以前放 70 字，念出来像在背课文。
    """
    import re
    t = (text or "").strip()
    t = re.sub(r"[*#`>_]+", "", t)
    t = re.sub(r"（[^）]*）|\([^)]*\)", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return ""
    # 通话时把「行，我说你记——」这类引子剥掉：一共就 38 字，引子占了五个
    for pre in _LEADS:
        if pre and t.startswith(pre):
            t = t[len(pre):].lstrip()
            break
    # 优先切在第一句结束处
    end = -1
    for ch in ("。", "！", "？", "!", "?", "；", "\n"):
        i = t.find(ch)
        if i > 0 and (end < 0 or i < end):
            end = i + 1
    if 0 < end <= max_chars:
        return _tidy(t[:end])
    if len(t) <= max_chars:
        return _tidy(t)
    cut = t[:max_chars]
    for i in range(len(cut) - 1, max(0, max_chars - 15), -1):
        if cut[i] in "，、；：,;:":
            return _tidy(cut[:i])
    # 实在没处切就硬截，结尾补句号——念出来是「话说到这儿」，比「…」那种
    # 拖着不收尾更像人在说话
    return _tidy(cut)


def _tidy(s):
    """念之前把末尾的半截标点收干净：念到「够；」会像正在打字的机器人。"""
    s = (s or "").rstrip()
    while s and s[-1] in "，、；：,;:…—":
        s = s[:-1].rstrip()
    return s + "。" if s and s[-1] not in "。！？!?" else s


_WIKI_CACHE = {}
_WIKI_DOWN_UNTIL = 0.0   # 维基确认连不上后，这段时间内不再为每句话白等
_WIKI_PROBE = [0.0, False]   # [上次探测时间, 是否连得上]


def _wiki_ok():
    """两秒内能不能连上 zh.wikipedia（TCP 层，不拉整页）。结果缓存 60 秒。"""
    import socket
    now = time.time()
    if now - _WIKI_PROBE[0] < 60:
        return _WIKI_PROBE[1]
    ok = False
    try:
        s = socket.create_connection(("zh.wikipedia.org", 443), timeout=2)
        s.close()
        ok = True
    except Exception:
        ok = False
    _WIKI_PROBE[0] = now
    _WIKI_PROBE[1] = ok
    return ok
_Q_WORDS = ("什么", "为什么", "怎么", "怎样", "是谁", "哪个", "多少", "如何",
            "介绍", "区别", "是什么", "吗", "?", "？")


def looks_like_question(text):
    t = (text or "").strip()
    if len(t) < 4:
        return False
    return any(k in t for k in _Q_WORDS)


def _wiki(query, timeout=10):
    """中文维基：先搜条目，再取摘要。返回 (标题, 摘要) 或 ("", "")。"""
    hdr = {"User-Agent": "OMC-Launcher-AI/1.0 (desktop)"}
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        url = ("https://zh.wikipedia.org/w/api.php?action=query&format=json"
               "&list=search&srlimit=1&srsearch=%s"
               % urllib.parse.quote(query))
        req = urllib.request.Request(url, headers=hdr)
        with op.open(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        hits = ((d.get("query") or {}).get("search") or [])
        title = (hits[0] or {}).get("title") or ""
    except Exception:
        return "", ""
    if not title:
        return "", ""
    try:
        url = ("https://zh.wikipedia.org/api/rest_v1/page/summary/"
               + urllib.parse.quote(title.replace(" ", "_")))
        req = urllib.request.Request(url, headers=hdr)
        # 已经拿到标题了，摘要这一趟不该再按整轮超时去等（不通时一次能省 8 秒）
        with op.open(req, timeout=min(timeout, 1.2)) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        extract = (d.get("extract") or "").strip()
        return title, extract
    except Exception:
        return title, ""


_STRIP_Q = ("是什么", "是啥", "为什么", "为啥", "怎么样", "怎么办", "怎么", "如何",
            "是谁", "多少", "吗", "呢", "请问", "请", "能不能", "可不可以",
            "？", "?", "。", "，", ",")


def _core_of(text):
    """把「红石是什么」剥成「红石」，维基才不会搜出奇怪的东西。"""
    s = text or ""
    for k in _STRIP_Q:
        s = s.replace(k, "")
    s = s.strip()
    return s or text


def lookup(text, timeout=2):
    """有网就查一下再说：返回一句可直接念的参考资料，查不到给空串。

    直连 zh.wikipedia 在国内常是"连得上但不回"，以前默认 10 秒超时、一轮
    还要试两个关键词，最坏能把回复拖到 40 秒。现在单次 2 秒，且一旦确认
    连不上就冷却 10 分钟，后面的问题直接本地答，不再为每句话白等。
    """
    global _WIKI_DOWN_UNTIL
    q = (text or "").strip()
    if not q or not looks_like_question(q):
        return ""
    if time.time() < _WIKI_DOWN_UNTIL:
        return ""
    core = _core_of(q)
    key = q[:60]
    hit = _WIKI_CACHE.get(key)
    if hit and time.time() - hit[1] < 3600:
        return hit[0]
    if not _wiki_ok():
        # 连都连不上就别真去请求了，否则 URL 层超时会连乘成好几秒
        _WIKI_DOWN_UNTIL = time.time() + 600
        return ""
    title, extract = _wiki(core, timeout=timeout)
    if not extract and core != q and time.time() >= _WIKI_DOWN_UNTIL:
        title, extract = _wiki(q, timeout=timeout)
    if not extract and not title:
        # 一次都没连上：进入冷却
        _WIKI_DOWN_UNTIL = time.time() + 600
    # 查出来的东西得跟问的核心词对得上，不然宁可不说（比如「红石」搜出电视剧）
    core = _core_of(q)
    core2 = _kw_of(core) or core
    if extract and core2 and core2[:4] not in (title + extract):
        title, extract = "", ""
    if not extract:
        _WIKI_CACHE[key] = ("", time.time())
        return ""
    if extract and not extract.endswith(("。", "！", "？", ".")):
        extract += "。"
    extract = extract[:260]
    ref = "《%s》：%s" % (title, extract)
    _WIKI_CACHE[key] = (ref, time.time())
    return ref


def api_conf():
    """读用户填的接口配置；没填就返回空。直接读 config.json，不依赖界面。"""
    try:
        from core.config import CONFIG_PATH
        with open(CONFIG_PATH, encoding="utf-8") as f:
            d = json.load(f)
        base = str(d.get("ai_api_base") or "").strip()
        key = str(d.get("ai_api_key") or "").strip()
        model = str(d.get("ai_model") or "").strip() or "gpt-4o-mini"
        return base, key, model
    except Exception:
        return "", "", ""


def _remote(messages, base, key, model, timeout=45):
    url = base.rstrip("/")
    if not url.endswith("/chat/completions"):
        url += "/chat/completions"
    body = json.dumps({"model": model, "messages": messages,
                       "temperature": 0.8,
                       "max_tokens": 400}).encode("utf-8")
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json",
                 "Authorization": "Bearer " + key, "User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))
    msg = (data.get("choices") or [{}])[0].get("message") or {}
    return (msg.get("content") or "").strip()


def _prev_user(cur=""):
    """上一轮用户说的话（调用方会先把当前这句写进历史，所以要跳过它）。

    只看最近一句是不够的：用户说「那具体呢」，指代的是前两三轮那个话题，
    所以那句如果只是个空追问，就往上找最近一句有实词的。
    """
    said = []
    for item in reversed(recent(16)):
        if item.get("r") != "u":
            continue
        t = (item.get("t") or "").strip()
        if not t or t == (cur or "").strip():
            continue
        said.append(t)
        if len(said) >= 8:                      # 最多回溯 8 轮
            break
    if not said:
        return ""
    if len(said) > 1 and not _kw_of(said[0]) and not _know_hit(said[0]):
        for w in said[1:]:
            if _kw_of(w) or _know_hit(w):
                return w
    return said[0]


def reply(text, mode=""):
    """(回复文本, 动作或 None, 用的引擎)。

    mode="call" 是语音通话：要短、要口语，念出来才像人说话而不是读说明书。
    """
    t = (text or "").strip()
    global _LAST_MOOD
    _LAST_MOOD = _mood_of(t)         # 语音合成拿它调一点点语气
    ref = lookup(t)                  # 有网就查一下，没网这行很快返回空串
    prev = _prev_user(t)
    base, key, model = api_conf()
    if base and key:
        hist = recent(8)
        sys_msg = SYSTEM_PROMPT
        if mode == "call":
            sys_msg += CALL_HINT
        if ref:
            sys_msg += ("\n\n【刚刚联网查到的资料，回答时参考它，别照念】：\n" + ref)
        msgs = [{"role": "system", "content": sys_msg}]
        for h in hist:
            msgs.append({"role": "user" if h.get("r") == "u" else "assistant",
                         "content": h.get("t") or ""})
        msgs.append({"role": "user", "content": t})
        try:
            raw = _remote(msgs, base, key, model)
            say, act = _parse_json(raw)
            if say:
                return (one_breathe(say) if mode == "call" else say), act, "remote"
        except Exception as e:
            local = local_reply(t, prev)
            txt = local["text"] + "\n（远端模型没连上：%s，先用本机模式陪你）" % str(e)[:60]
            if ref:
                # 远端挂了也别把刚查到的资料丢掉
                txt = "我刚上网查了下——%s" % ref
            if mode == "call":
                # 通话里绝不能把「远端没连上」这种技术话念给用户听
                txt = local["text"]
            return txt, local["action"], "local"
    local = local_reply(t, prev)
    if ref and local.get("weak"):
        # 本机知识答不上来、但联网查到了：直接拿资料当答案。
        # 以前是「我脑子里只有个大概」后面再拼一段资料，前后自相矛盾，看起来就是笨。
        local["text"] = "我刚上网查了下——%s" % ref
    elif ref and not local.get("hit"):
        local["text"] = "%s\n我刚上网查了下——%s" % (local["text"], ref)
    txt = local["text"]
    if mode == "call":
        txt = one_breathe(txt)
    return txt, local["action"], "local"


def _parse_json(raw):
    txt = raw or ""
    i, j = txt.find("{"), txt.rfind("}")
    if i < 0 or j <= i:
        return txt.strip()[:400], None
    try:
        obj = json.loads(txt[i:j + 1])
    except Exception:
        return txt.strip()[:400], None
    say = str(obj.get("say") or "").strip()
    act = obj.get("action")
    if isinstance(act, dict) and act.get("type"):
        allowed = {"set_theme", "set_accent", "set_wall", "toggle_random_wall",
                   "set_memory", "set_username", "set_game_lang",
                   "toggle_chat_filter", "toggle_cat", "play_music",
                   "music_pause", "music_next", "music_volume"}
        if act["type"] not in allowed:
            act = None
        else:
            act = {"type": act["type"], "value": act.get("value")}
    else:
        act = None
    return say, act


def _warm_probe():
    """开程序时后台先探一次维基通不通，用户第一句话就不用等这 2 秒。"""
    try:
        _wiki_ok()
    except Exception:
        pass


threading.Thread(target=_warm_probe, daemon=True, name="omc-wiki-probe").start()
