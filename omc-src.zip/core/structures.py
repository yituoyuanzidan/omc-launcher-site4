# -*- coding: utf-8 -*-
"""存档的结构（structure）文件管理。

结构就是游戏里 /structure save 存出来、或者在别的存档里 .nbt 文件，
放进 <存档>/generated/structures/ 后，进游戏 /place structure <名字> 就能用。
"""
import os
import shutil


def structures_dir(save_path):
    d = os.path.join(save_path, "generated", "structures")
    os.makedirs(d, exist_ok=True)
    return d


def list_structures(save_path):
    """返回 [(文件名, 字节数)]。"""
    d = structures_dir(save_path)
    out = []
    for name in sorted(os.listdir(d), key=str.lower):
        p = os.path.join(d, name)
        if os.path.isfile(p) and name.lower().endswith(".nbt"):
            try:
                out.append((name, os.path.getsize(p)))
            except OSError:
                out.append((name, 0))
    return out


def install_structures(save_path, paths, log=None):
    """把一个或多个 .nbt 结构复制进存档，返回落地的文件名列表。"""
    log = log or (lambda _m: None)
    d = structures_dir(save_path)
    done = []
    for src in paths:
        if not os.path.isfile(src):
            continue
        if not str(src).lower().endswith(".nbt"):
            raise RuntimeError("结构文件必须是 .nbt：%s" % os.path.basename(src))
        base = os.path.basename(src)
        stem, ext = os.path.splitext(base)
        name = base
        i = 1
        while os.path.exists(os.path.join(d, name)):
            name = "%s_%d%s" % (stem, i, ext)
            i += 1
        shutil.copy2(src, os.path.join(d, name))
        done.append(name)
        log("已导入结构：" + name)
    if not done:
        raise RuntimeError("没有可导入的 .nbt 结构文件")
    return done


def open_dir(save_path):
    d = structures_dir(save_path)
    try:
        if os.name == "nt":
            os.startfile(d)
        else:
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.Popen([opener, d])
    except Exception:
        pass
    return d
