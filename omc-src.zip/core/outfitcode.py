# -*- coding: utf-8 -*-
"""穿搭码：把一套穿搭压成一段可复制的短码，别人粘进去就能还原。"""
import base64
import json
import zlib

PREFIX = "OMC-"


def encode(rec):
    """rec: {"name","label","cape_name","group"} -> 短码字符串"""
    payload = {
        "n": (rec.get("name") or "").strip(),
        "l": (rec.get("label") or rec.get("name") or "").strip(),
        "c": (rec.get("cape_name") or "").strip(),
        "g": (rec.get("group") or "").strip(),
    }
    if not payload["n"]:
        raise ValueError("这套穿搭没有皮肤名，不能生成")
    raw = json.dumps(payload, ensure_ascii=False,
                     separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii")
    return PREFIX + body.rstrip("=")


def decode(code):
    """短码 -> dict(name,label,cape_name,group)；解析失败抛异常。"""
    s = (code or "").strip().replace("\n", "").replace("\r", "")
    s = s.replace(" ", "")
    if not s:
        raise ValueError("穿搭码是空的")
    if s.upper().startswith(PREFIX):
        s = s[len(PREFIX):]
    pad = (-len(s)) % 4
    try:
        raw = zlib.decompress(base64.urlsafe_b64decode(s + "=" * pad))
    except Exception as e:
        raise ValueError("这段码不完整或者不是穿搭码（%s）" % e)
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise ValueError("这段码的内容读不出来（%s）" % e)
    if not isinstance(data, dict) or not data.get("n"):
        raise ValueError("这段码里没有皮肤名")
    return {
        "name": data.get("n") or "",
        "label": data.get("l") or data.get("n") or "",
        "cape_name": data.get("c") or "",
        "group": data.get("g") or "",
    }


# ------------------------------------------------------------------ 带图穿搭码
#
# 老码只带一个名字，对方本地没这张皮肤就得联网再按名字拉一遍，还容易拉错。
# 新码把皮肤（和披风）的 PNG 一起塞进去，离线也能还原，颜色不会跑。
FULL_PREFIX = "OMC2-"
MAX_PACK = 1024 * 1024      # 解出来超过 1MB 就当不是正经穿搭码
SKIN_LIMIT = 512 * 1024


def _b64(data):
    return base64.urlsafe_b64encode(zlib.compress(data, 9)).decode("ascii")


def _unb64(text):
    pad = (-len(text)) % 4
    return zlib.decompress(base64.urlsafe_b64decode(text + "=" * pad))


def encode_full(label, skin_bytes, cape_bytes=b"", note=""):
    """把皮肤和披风的图片一起编成码，别人粘进去就能直接还原。"""
    if not skin_bytes:
        raise ValueError("没有皮肤图片，生成不了带图穿搭码")
    if len(skin_bytes) > SKIN_LIMIT:
        raise ValueError("皮肤图片太大了（超过 512KB），换张普通的 64x64")
    payload = {
        "n": (label or "穿搭").strip() or "穿搭",
        "s": _b64(skin_bytes),
        "c": _b64(cape_bytes) if cape_bytes else "",
        "m": (note or "").strip(),
    }
    raw = json.dumps(payload, ensure_ascii=False,
                     separators=(",", ":")).encode("utf-8")
    return FULL_PREFIX + _b64(raw).rstrip("=")


def is_full(code):
    return (code or "").strip().replace(" ", "").upper().startswith(FULL_PREFIX)


def decode_full(code):
    """带图穿搭码 -> dict(label, note, skin_bytes, cape_bytes, legacy_code)。

    不是带图码时把原串放回 legacy_code，让调用方回落到老的按名字拉取。
    """
    s = (code or "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
    if not s:
        raise ValueError("穿搭码是空的")
    if not is_full(s):
        return {"label": "", "note": "", "skin_bytes": b"", "cape_bytes": b"",
                "legacy_code": s}
    body = s[len(FULL_PREFIX):]
    try:
        raw = _unb64(body)
    except Exception as e:
        raise ValueError("这段带图穿搭码不完整（%s）" % e)
    if len(raw) > MAX_PACK:
        raise ValueError("这段码解出来太大，不像是穿搭码")
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise ValueError("这段码的内容读不出来（%s）" % e)
    if not isinstance(data, dict) or not data.get("s"):
        raise ValueError("这段码里没有皮肤图片")
    try:
        skin = _unb64(data.get("s") or "")
        cape = _unb64(data.get("c")) if data.get("c") else b""
    except Exception as e:
        raise ValueError("皮肤图片解不出来（%s）" % e)
    if not skin:
        raise ValueError("这段码里没有皮肤图片")
    return {"label": (data.get("n") or "穿搭").strip() or "穿搭",
            "note": data.get("m") or "",
            "skin_bytes": skin, "cape_bytes": cape, "legacy_code": ""}
