# -*- coding: utf-8 -*-
"""穿搭码：把一套穿搭压成一段可复制的短码，别人粘进去就能还原。"""
import base64
import json
import zlib

PREFIX = "OMC-"


def encode(rec):
    """rec: {"name","label","cape_name","group"} -> 短码字符串"""
    payload = {
        "n": (rec.get("name") or "").strip(),
        "l": (rec.get("label") or rec.get("name") or "").strip(),
        "c": (rec.get("cape_name") or "").strip(),
        "g": (rec.get("group") or "").strip(),
    }
    if not payload["n"]:
        raise ValueError("这套穿搭没有皮肤名，不能生成")
    raw = json.dumps(payload, ensure_ascii=False,
                     separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii")
    return PREFIX + body.rstrip("=")


def decode(code):
    """短码 -> dict(name,label,cape_name,group)；解析失败抛异常。"""
    s = (code or "").strip().replace("\n", "").replace("\r", "")
    s = s.replace(" ", "")
    if not s:
        raise ValueError("穿搭码是空的")
    if s.upper().startswith(PREFIX):
        s = s[len(PREFIX):]
    pad = (-len(s)) % 4
    try:
        raw = zlib.decompress(base64.urlsafe_b64decode(s + "=" * pad))
    except Exception as e:
        raise ValueError("这段码不完整或者不是穿搭码（%s）" % e)
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise ValueError("这段码的内容读不出来（%s）" % e)
    if not isinstance(data, dict) or not data.get("n"):
        raise ValueError("这段码里没有皮肤名")
    return {
        "name": data.get("n") or "",
        "label": data.get("l") or data.get("n") or "",
        "cape_name": data.get("c") or "",
        "group": data.get("g") or "",
    }
