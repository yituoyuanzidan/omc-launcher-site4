# -*- coding: utf-8 -*-
"""服务器收藏：本地保存常去的服务器地址，双击可进服，顺手显示在线人数和延迟。"""
import json
import os
import time

from . import config, lan

FILE_NAME = "servers.json"


def _path():
    return os.path.join(config.app_dir(), FILE_NAME)


def _load():
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
    except Exception:
        pass
    return []


def _save(items):
    os.makedirs(config.app_dir(), exist_ok=True)
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


def list_servers():
    return _load()


def split_address(address):
    """支持 example.com / example.com:25565 / ip:port。"""
    address = (address or "").strip()
    if not address:
        return "", 25565
    if address.count(":") == 1:
        host, port = address.split(":")
        try:
            return host.strip(), int(port)
        except ValueError:
            return address, 25565
    return address, 25565


def add(name, address):
    host, port = split_address(address)
    if not host:
        raise RuntimeError("请填服务器地址，例如 mc.hypixel.net 或 1.2.3.4:25565")
    items = _load()
    for it in items:
        if it.get("host") == host and int(it.get("port") or 25565) == port:
            it["name"] = name or it.get("name") or host
            _save(items)
            return it
    item = {"name": (name or host).strip(), "host": host, "port": port}
    items.append(item)
    _save(items)
    return item


def remove(index):
    items = _load()
    if 0 <= index < len(items):
        items.pop(index)
        _save(items)
        return True
    return False


def ping(item, timeout=1.5):
    """返回 {'online':bool,'players':str,'motd':str,'latency':int, 'version':str}"""
    host = item.get("host") or ""
    port = int(item.get("port") or 25565)
    t0 = time.time()
    try:
        res = lan.status_ping(host, port, timeout=timeout)
    except Exception as e:
        return {"online": False, "players": "", "motd": str(e)[:60],
                "latency": -1, "version": ""}
    latency = int((time.time() - t0) * 1000)
    if not res:
        return {"online": False, "players": "", "motd": "无响应",
                "latency": -1, "version": ""}
    online = res.get("online")
    maxp = res.get("max")
    players_txt = ("%s/%s" % (online, maxp)) if online is not None else ""
    return {
        "online": True,
        "players": players_txt,
        "motd": (res.get("motd") or "").strip()[:80],
        "latency": latency,
        "version": res.get("version") or "",
    }
