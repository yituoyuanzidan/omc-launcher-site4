# -*- coding: utf-8 -*-
"""整合包（Modrinth .mrpack）：浏览、下载、装成一个独立版本。

为什么装成「独立版本」：整合包自带一整套 mods/config/资源包，直接倒进全局
游戏目录会把用户原来的模组全搅在一起。这里把每个整合包装成
versions/<名字>/ 下的一个版本，并在版本 json 里打 _omcIsolated，启动时
游戏目录就指到这个版本自己的文件夹，和原来的存档/模组互不影响。

安装步骤（Modrinth 规范）：
1. 下载 .mrpack（其实就是个 zip）；
2. 读 modrinth.index.json：dependencies 里的 minecraft + 加载器版本；
3. 先按依赖装加载器（fabric / quilt / forge / neoforge）；
4. 把 index 里列的文件（mods/config/资源包…）按相对路径下进版本目录；
5. 把 overrides / client-overrides 解进版本目录；
6. 写版本 json（inheritsFrom 加载器版本），版本列表里就能选到它。
"""
import json
import os
import re
import shutil
import tempfile
import time
import zipfile

from . import downloader, http, loaders

API = "https://api.modrinth.com/v2"

# 精选清单：slug 都是 Modrinth 上真实可下载的项目。
# hot 是公告下载量（仅用于排序展示，安装时会实时取最新版本）。
CATALOG = [
    {"slug": "fabulously-optimized", "name": "极致优化原版",
     "tag": "原版 / 优化", "why": "什么都不改，只把帧数拉满；老电脑首选",
     "hot": 19223946, "pick": "原版整合 极致优化"},
    {"slug": "create_plus", "name": "机械动力 Plus",
     "tag": "机械 / 科技", "why": "机械动力全家桶 + 优化，齿轮传送带一次上齐",
     "hot": 1482532, "pick": "机械动力"},
    {"slug": "zombie-invade-100-days", "name": "丧尸入侵 100 天",
     "tag": "丧尸 / 生存", "why": "尸潮一波接一波，守一百天",
     "hot": 15267693, "pick": "丧尸"},
    {"slug": "battlearmorytacz", "name": "军械库 TACZ",
     "tag": "枪械 / 战斗", "why": "TACZ 枪械加护甲，自带优化不卡",
     "hot": 3744698, "pick": "枪械"},
    {"slug": "wither-storm-enhanced", "name": "凋零风暴 强化版",
     "tag": "Boss / 冒险", "why": "那只吞噬世界的凋零风暴，强化重制",
     "hot": 149859, "pick": "凋零风暴"},
    {"slug": "mineinabyss-modpack", "name": "来自深渊",
     "tag": "冒险 / 探索", "why": "深渊一层层往下探，越深越吓人",
     "hot": 60569, "pick": "来自深渊"},
    {"slug": "escape-from-tarkraft", "name": "塔科夫式搜打撤",
     "tag": "搜打撤 / 硬核", "why": "带装备进场、搜刮、活着撤离，死了全丢",
     "hot": 58263, "pick": "搜打撤"},
    {"slug": "farming-experience", "name": "种田生活",
     "tag": "模拟经营 / 养老", "why": "种地养殖开店，慢节奏不打架",
     "hot": 58050, "pick": "模拟经营 / 养老"},
    {"slug": "better-mc-forge-bmc4", "name": "Better MC 冒险（Forge）",
     "tag": "冒险 / 综合", "why": "任务线 + 地牢 + 战斗，内容量极大",
     "hot": 2304323, "pick": "冒险"},
    {"slug": "atmos_roguelike", "name": "肉鸽：Atmos",
     "tag": "肉鸽 / 冒险", "why": "每局地图和掉落都不一样，死了重开",
     "hot": 44692, "pick": "肉鸽"},
    {"slug": "cobblemon-fabric", "name": "宝可梦 Cobblemon",
     "tag": "养成 / 冒险", "why": "官方宝可梦整合包，抓宠对战",
     "hot": 11425667, "pick": "热门"},
    {"slug": "prominence-2-fabric", "name": "Prominence II 冒险",
     "tag": "冒险 / 科技", "why": "任务驱动的大型冒险整合，口碑极好",
     "hot": 2192852, "pick": "热门"},
    {"slug": "vanilla-perfected", "name": "原版增强",
     "tag": "原版 / 优化", "why": "原版手感 + 少量改善，联机不挑人",
     "hot": 2680386, "pick": "热门"},
    {"slug": "slimes-adventure", "name": "史莱姆冒险",
     "tag": "冒险 / 战斗", "why": "史莱姆主题的冒险整合，轻量好上手",
     "hot": 2086393, "pick": "热门"},
]


def _int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default


def catalog():
    """精选清单，按热度倒序。"""
    return sorted([dict(c) for c in CATALOG], key=lambda c: -_int(c["hot"]))


def project_info(slug):
    return http.fetch_json(API + "/project/" + slug, "official",
                           timeout=20, retries=2)


def versions(slug):
    return http.fetch_json(API + "/project/%s/version" % slug, "official",
                           timeout=20, retries=2) or []


def _is_pack_file(f):
    return (f.get("filename") or "").lower().endswith(".mrpack")


def best_pack(slug, version_id=None):
    """挑一个可安装的 .mrpack：优先正式版、最新的那个。"""
    vs = versions(slug)
    if version_id:
        vs = [v for v in vs if v.get("id") == version_id] or vs
    picks = [v for v in vs
             if any(_is_pack_file(f) for f in (v.get("files") or []))]
    if not picks:
        raise RuntimeError("这个整合包还没有 .mrpack 下载")
    # 正式版优先，其次按发布时间
    picks.sort(key=lambda v: (v.get("version_type") != "release",
                              -(time.mktime(time.strptime(
                                  (v.get("date_published") or "1970-01-01")[:19],
                                  "%Y-%m-%dT%H:%M:%S")) if (v.get("date_published")) else 0)))
    v = picks[0]
    f = [x for x in (v.get("files") or []) if _is_pack_file(x)]
    return v, (f[0] if f else None)


def _safe_name(text):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", text or "").strip(" .")
    s = re.sub(r"\s+", " ", s)
    return s[:64] or "整合包"


def _loader_from_deps(deps):
    """dependencies -> (kind, version)。"""
    if deps.get("fabric-loader"):
        return "fabric", str(deps["fabric-loader"])
    if deps.get("quilt-loader"):
        return "quilt", str(deps["quilt-loader"])
    if deps.get("forge"):
        return "forge", str(deps["forge"])
    if deps.get("neoforge"):
        return "neoforge", str(deps["neoforge"])
    return "", ""


def ensure_vanilla(game_dir, mc, log=None, progress=None, mirror="official"):
    """整合包的父版本必须是原版；没装就先装原版。"""
    log = log or (lambda _m: None)
    progress = progress or (lambda _c, _t: None)
    jp = os.path.join(game_dir, "versions", mc, mc + ".json")
    if os.path.isfile(jp):
        return True
    log("先装原版 Minecraft %s（整合包的加载器要挂它）" % mc)
    try:
        vers = downloader.list_versions(mirror)
    except Exception:
        vers = downloader.list_versions("official")
    item = None
    for v in vers:
        if v.get("id") == mc:
            item = v
            break
    if not item:
        raise RuntimeError("版本清单里找不到 Minecraft %s" % mc)
    downloader.Installer(game_dir, mirror, log=log, progress=progress).install(
        mc, item["url"])
    return True


def install(slug, game_dir, java_path="", log=None, progress=None, stage=None,
            version_id=None):
    """把整合包装成一个独立版本，返回版本 id（版本列表里就是它）。"""
    log = log or (lambda _m: None)
    stage = stage or (lambda _n, _p: None)
    progress = progress or (lambda _c, _t: None)

    info = project_info(slug)
    cn = next((c for c in CATALOG if c["slug"] == slug), None)
    # 版本名优先用清单里的中文名（版本列表里好认），没有才退回项目原名
    title = (cn or {}).get("name") or info.get("title") or slug
    ver, pack = best_pack(slug, version_id)
    if not pack:
        raise RuntimeError("这个整合包没有可下载的 .mrpack")

    work = os.path.join(tempfile.gettempdir(),
                        "omc_pack_%d" % int(time.time()))
    os.makedirs(work, exist_ok=True)
    mrpath = os.path.join(work, pack.get("filename") or "pack.mrpack")
    stage("下载整合包", 0)
    log("正在下载整合包：%s %s" % (title, ver.get("version_number") or ""))

    def _prog(cur, tot):
        progress(cur, tot)
        if tot:
            stage("下载整合包", int(cur * 100 / tot) * 0.2)

    http.download_file_multi(pack["url"], mrpath, "official",
                             progress=_prog, parts=4, timeout=60, retries=2)

    stage("解析清单", 25)
    with zipfile.ZipFile(mrpath) as zf:
        try:
            index = json.loads(zf.read("modrinth.index.json").decode("utf-8"))
        except KeyError:
            raise RuntimeError("这不是标准的 .mrpack（缺少 modrinth.index.json）")

        deps = index.get("dependencies") or {}
        mc = deps.get("minecraft") or ""
        if not mc:
            raise RuntimeError("整合包没写游戏版本，装不了")
        kind, lver = _loader_from_deps(deps)
        if not kind:
            raise RuntimeError("这个整合包没写加载器（fabric/forge 等），暂不支持")

        vid = "%s %s" % (title, ver.get("version_number") or "")
        vid = _safe_name(vid)
        dest_root = os.path.join(game_dir, "versions", vid)
        os.makedirs(dest_root, exist_ok=True)

        # 0) 原版：加载器 inheritsFrom 的就是它，缺了会启动失败
        stage("准备原版", 28)
        ensure_vanilla(game_dir, mc, log=log,
                       progress=lambda c, t: (
                           stage("准备原版", 28 + (int(c * 100 / t) * 0.07 if t else 0)),
                           progress(c, t)))

        # 1) 先装加载器：整合包里的每个模组都依赖它
        stage("安装加载器", 35)
        log("正在安装加载器：%s %s（MC %s）" % (kind, lver, mc))
        loader_vid = loaders.install(
            kind, mc, lver, game_dir, java_path, log,
            lambda _name, _pct: stage("安装加载器", 35 + (_pct or 0) * 0.12),
            "bmcl")

        # 2) 版本 json：inheritsFrom 加载器版本 + 隔离标记
        stage("写入版本", 48)
        vj = {
            "id": vid,
            "inheritsFrom": loader_vid,
            "type": "release",
            "_omcIsolated": True,
            "omcPack": {"slug": slug, "title": title,
                        "version": ver.get("version_number") or "",
                        "minecraft": mc, "loader": kind,
                        "loaderVersion": lver},
        }
        with open(os.path.join(dest_root, vid + ".json"), "w",
                  encoding="utf-8") as f:
            json.dump(vj, f, ensure_ascii=False, indent=2)

        # 3) 下 index 里列的文件
        files = [f for f in (index.get("files") or [])
                 if (f.get("path") or "") and
                 ((f.get("env") or {}).get("client") != "unsupported")]
        total = max(1, len(files))
        log("整合包里共 %d 个文件要下载" % len(files))
        for i, f in enumerate(files, 1):
            rel = (f.get("path") or "").replace("/", os.sep)
            dst = os.path.join(dest_root, rel)
            want = _int(f.get("fileSize"), -1)
            if os.path.isfile(dst) and want >= 0 and os.path.getsize(dst) == want:
                stage("下载文件", 50 + i * 42 / total)
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            url = (f.get("downloads") or [""])[0]
            if not url:
                continue
            try:
                http.download_file_multi(url, dst, "official", parts=2,
                                         timeout=60, retries=1)
            except Exception as e:
                log("跳过文件 %s：%s" % (os.path.basename(rel), e))
                continue
            stage("下载文件", 50 + i * 42 / total)
            if i % 20 == 0:
                log("已下好 %d / %d 个文件" % (i, len(files)))

        # 4) overrides：整合包自带的配置/资源包，同名不覆盖已下内容
        stage("解压配置", 92)
        for prefix in ("overrides/", "client-overrides/"):
            for n in zf.namelist():
                if not n.startswith(prefix) or n.endswith("/"):
                    continue
                rel = n[len(prefix):]
                if not rel:
                    continue
                dst = os.path.join(dest_root, rel.replace("/", os.sep))
                if os.path.exists(dst):
                    continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, "wb") as out:
                    out.write(zf.read(n))

    stage("完成", 100)
    log("整合包装好了：%s（版本列表里叫「%s」）" % (title, vid))
    try:
        shutil.rmtree(work, ignore_errors=True)
    except Exception:
        pass
    return vid
