# -*- coding: utf-8 -*-
"""昵称审核：举报违规名字，违规者被改成「未命名（编号）」。

没有后端账号服务，所以这里只能做到两件事：
  1. 本机判定：名字命中违禁词库（和聊天过滤同一套词）就算违规；
  2. 下发改名：往对方的改名收件箱塞一条指令，对方客户端下次同步时
     把自己改成「未命名（四位编号）」，并把改名结果广播回去。

也就是说：对方开着新版启动器、同步跑起来才会真改名；对方用旧版
或者一直离线，就只能在本机把名字显示成「未命名（xxxx）」。
"""
import hashlib
import json
import os
import time

from core import friendbook, gamesync as gs, wordfilter

PREFIX = "未命名"


def _h(s):
    return hashlib.md5(s.encode("utf-8")).hexdigest()[:12]


def _base():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def _load(fn, default):
    p = os.path.join(_base(), fn)
    if not os.path.isfile(p):
        return default
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save(fn, data):
    p = os.path.join(_base(), fn)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def bad_name(name):
    """违规名字返回命中的词，否则空串。"""
    try:
        return wordfilter.hit(name)
    except Exception:
        return ""


def safe_name(old):
    """违规名字换成「未命名（1234）」；编号由原名决定，同一个人每次都一样。"""
    h = hashlib.md5(("omc-unnamed|" + (old or "").strip().lower()).encode("utf-8")).hexdigest()
    num = int(h[:6], 16) % 10000
    return "%s（%04d）" % (PREFIX, num)


def topic(name):
    return "omc-rename3-" + _h("omc-rename3-v1|" + (name or "").strip().lower())


def reports():
    return _load("nickreports.json", {"items": []}).get("items") or []


def report(me, target, reason="", timeout=gs.TIMEOUT):
    """举报一个名字：记本机、给违规者下发改名指令。"""
    target = (target or "").strip()
    if not target or not me:
        return False, "先选一个人"
    word = bad_name(target)
    data = _load("nickreports.json", {"items": []})
    data.setdefault("items", []).append({
        "by": me, "target": target, "word": word, "why": (reason or "")[:120],
        "ts": int(time.time()),
        "when": time.strftime("%Y-%m-%d %H:%M")})
    _save("nickreports.json", data)
    if not word:
        # 没命中词库：只记账，不下发（避免误伤正常人）
        _save("nickreports.json", data)
        return True, "已记录举报（名字暂时没命中违禁词，不会强制改名）"
    new = safe_name(target)
    try:
        gs._post(topic(target), {"t": "rn", "to": target, "by": me,
                                 "new": new, "why": (reason or "")[:120],
                                 "ts": int(time.time())}, timeout=timeout)
    except Exception as e:
        return False, "改名指令没发出去：%s" % e
    rename_local(target, new)
    return True, "已举报并下发改名：%s → %s" % (target, new)


def rename_local(old, new):
    """把本机好友列表里那个名字换掉（含备注、分组、来源）。"""
    try:
        old_l = (old or "").strip().lower()
        for it in friendbook.items():
            if (it.get("name") or "").strip().lower() != old_l:
                continue
            friendbook.remove(uid=it.get("uid"), name=it.get("name"))
            friendbook.add(uid=it.get("uid") or new, name=new,
                           src=it.get("src") or "改名")
            try:
                friendbook.update_note(uid=it.get("uid"), name=new,
                                       note=it.get("note") or "",
                                       group=it.get("group") or None,
                                       alias=it.get("alias") or "")
            except Exception:
                pass
    except Exception:
        pass


def orders(me, since="3d", timeout=gs.TIMEOUT):
    """拉发给我的改名指令。"""
    me_l = (me or "").strip().lower()
    if not me_l:
        return []
    rows = gs._pull(topic(me), since=since, timeout=timeout, kinds=("rn",))
    out = []
    for r in rows:
        if (r.get("to") or "").strip().lower() != me_l:
            continue
        if (r.get("by") or "").strip().lower() == me_l:
            continue
        out.append(r)
    return out


def apply_rename(new_name):
    """自己改名（改本机账号记录 + 当前登录名）。返回 (ok, 名字或原因)。"""
    new_name = (new_name or "").strip()
    if not new_name:
        return False, "名字不能空"
    from core import accounts as acc
    cur = acc.current_user()
    if not cur:
        return False, "还没登录账号"
    old = cur.get("name") or ""
    if new_name == old:
        return True, old
    data = acc._read()
    for u in data.get("users", []):
        if (u.get("name") or "") == old:
            if acc.name_taken(new_name):
                return False, "这个名字已经有人用了"
            u["name"] = new_name
            u["renamed_from"] = old
            u["renamed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            if data.get("current") == old:
                data["current"] = new_name
            acc._write(data)
            return True, new_name
    return False, "找不到当前账号记录"
