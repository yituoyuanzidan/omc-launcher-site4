# -*- coding: utf-8 -*-
"""存档的数据包（datapacks）管理：列目录、导入 zip/文件夹、删除、打开目录。

数据包就是扔进 <存档>/datapacks/ 的 .zip 或文件夹，
游戏里用 /datapack list 能看到装了什么。
"""
import json
import os
import shutil
import zipfile


def datapacks_dir(save_path):
    d = os.path.join(save_path, "datapacks")
    os.makedirs(d, exist_ok=True)
    return d


def _dir_size(path):
    total = 0
    for cur, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(cur, f))
            except OSError:
                pass
    return total


def _desc_from_meta(raw):
    """从 pack.mcmeta 里取描述文字（description 可能是字符串或 translate 对象）。"""
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
        pack = data.get("pack") or {}
        desc = pack.get("description")
        if isinstance(desc, dict):
            desc = desc.get("text") or desc.get("translate") or ""
        return str(desc or "").strip(), pack.get("pack_format")
    except Exception:
        return "", None


def _read_meta_zip(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            cands = [n for n in names if n.endswith("pack.mcmeta")]
            if not cands:
                return "", None
            cands.sort(key=lambda n: n.count("/"))
            raw = z.read(cands[0])
        return _desc_from_meta(raw)
    except Exception:
        return "", None


def _read_meta_folder(path):
    p = os.path.join(path, "pack.mcmeta")
    if not os.path.exists(p):
        return "", None
    try:
        with open(p, "rb") as f:
            return _desc_from_meta(f.read())
    except Exception:
        return "", None


def _looks_like_pack(path_or_zip):
    """判断是不是数据包：有 pack.mcmeta，或者有 data 目录。"""
    if os.path.isdir(path_or_zip):
        return (os.path.exists(os.path.join(path_or_zip, "pack.mcmeta"))
                or os.path.isdir(os.path.join(path_or_zip, "data")))
    try:
        with zipfile.ZipFile(path_or_zip) as z:
            names = z.namelist()
        if any(n.endswith("pack.mcmeta") for n in names):
            return True
        return any(n.startswith("data/") or "/data/" in n for n in names)
    except Exception:
        return False


def list_datapacks(save_path):
    """返回 [{name, path, kind, size, desc, pack_format}]。"""
    d = datapacks_dir(save_path)
    out = []
    for name in sorted(os.listdir(d), key=str.lower):
        p = os.path.join(d, name)
        if os.path.isdir(p):
            if not _looks_like_pack(p):
                continue
            desc, fmt = _read_meta_folder(p)
            out.append({"name": name, "path": p, "kind": "folder",
                        "size": _dir_size(p), "desc": desc,
                        "pack_format": fmt})
        elif name.lower().endswith(".zip"):
            desc, fmt = _read_meta_zip(p)
            out.append({"name": name, "path": p, "kind": "zip",
                        "size": os.path.getsize(p), "desc": desc,
                        "pack_format": fmt})
    return out


def install_pack(save_path, src, log=None):
    """把 zip 或文件夹装进存档的 datapacks，返回落地文件名。"""
    log = log or (lambda _m: None)
    d = datapacks_dir(save_path)
    if not _looks_like_pack(src):
        raise RuntimeError("这不是数据包（里面没有 pack.mcmeta 或 data 目录）")
    base = os.path.basename(str(src).rstrip("\\/"))
    name = base
    if os.path.isdir(src):
        while os.path.exists(os.path.join(d, name)):
            name = base + "_%d" % len(os.listdir(d))
    else:
        stem, ext = os.path.splitext(base)
        while os.path.exists(os.path.join(d, name)):
            name = "%s_%d%s" % (stem, len(os.listdir(d)), ext)
    dest = os.path.join(d, name)
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
    log("已加入数据包：" + name)
    return name


def remove_pack(save_path, name):
    p = os.path.join(datapacks_dir(save_path), name)
    if not os.path.exists(p):
        raise RuntimeError("找不到这个数据包：" + name)
    if os.path.isdir(p):
        shutil.rmtree(p)
    else:
        os.remove(p)
    return True


def open_dir(save_path):
    d = datapacks_dir(save_path)
    try:
        if os.name == "nt":
            os.startfile(d)
        else:
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.Popen([opener, d])
    except Exception:
        pass
    return d
