# -*- coding: utf-8 -*-
"""自定义下载：自己填网址、自己选存哪儿、自己定文件名。

跟启动器里那些「点一下就下」的功能不同，这里是给用户兜底的：
  * 任何 http/https 直链都能拉（不加代理，跟别处一样走直连）
  * 保存目录自己挑，文件名自己写；留空就按网址自动猜
  * 边下边报进度、能中途取消；断了重来时支持 Range 续传
  * 下完算一遍 SHA256 并核对大小，能看到到底拉了多少
"""
import hashlib
import os
import re
import threading
import time
import urllib.parse
import urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
CHUNK = 64 * 1024
BAD_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def default_dir():
    """默认存到「下载/OMC下载」，没有就用用户目录下的 OMC下载。"""
    home = os.path.expanduser("~")
    for cand in (os.path.join(home, "Downloads", "OMC下载"),
                 os.path.join(home, "OMC下载"),
                 os.path.join(home, "Desktop")):
        try:
            if os.path.isdir(os.path.dirname(cand)) or cand == os.path.join(home, "Desktop"):
                os.makedirs(cand, exist_ok=True)
                return cand
        except Exception:
            continue
    return home


def sanitize_name(name, fallback="download.bin"):
    name = (name or "").strip()
    name = name.replace("\u3000", " ")
    name = BAD_CHARS.sub("_", name)
    name = name.strip(" .")
    if not name:
        name = fallback
    if len(name) > 180:
        base, ext = os.path.splitext(name)
        name = base[:170] + ext
    return name


def guess_name(url):
    """从网址猜文件名；猜不出来就用资源哈希命名。"""
    try:
        path = urllib.parse.urlparse(url).path
        base = urllib.parse.unquote(os.path.basename(path))
    except Exception:
        base = ""
    base = sanitize_name(base, "")
    if base:
        return base
    h = hashlib.md5((url or "").encode("utf-8")).hexdigest()[:8]
    return "download_%s.bin" % h


def unique_path(path):
    if not os.path.exists(path):
        return path
    root, ext = os.path.splitext(path)
    i = 1
    while os.path.exists("%s(%d)%s" % (root, i, ext)):
        i += 1
    return "%s(%d)%s" % (root, i, ext)


def _open(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    return op.open(req, timeout=timeout)


def probe(url, timeout=12):
    """只看头：拿到大小和文件名，不下载正文。"""
    info = {"ok": False, "size": 0, "name": "", "msg": ""}
    try:
        r = _open(url, timeout=timeout)
        info["size"] = int(r.headers.get("Content-Length") or 0)
        cd = r.headers.get("Content-Disposition") or ""
        m = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";]+)"?', cd)
        info["name"] = urllib.parse.unquote(m.group(1)) if m else guess_name(url)
        info["ctype"] = r.headers.get("Content-Type") or ""
        r.close()
        info["ok"] = True
    except Exception as e:
        info["msg"] = str(e)
    return info


def download(url, save_dir, filename="", on_progress=None, cancel=None,
             timeout=20, resume=True):
    """下载到 save_dir/filename。

    返回 (ok, 路径或错误说明, 信息 dict)
    信息 dict: bytes / sha256 / elapsed / resumed
    """
    url = (url or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        return False, "网址要以 http:// 或 https:// 开头", {}
    save_dir = os.path.expanduser((save_dir or "").strip() or default_dir())
    try:
        os.makedirs(save_dir, exist_ok=True)
    except Exception as e:
        return False, "保存目录建不了：%s" % e, {}
    if not os.path.isdir(save_dir):
        return False, "保存目录不存在：%s" % save_dir, {}

    name = sanitize_name(filename or guess_name(url))
    target = unique_path(os.path.join(save_dir, name))
    part = target + ".omcpart"
    t0 = time.time()
    total = 0
    resumed = False

    def _emit(done, total_bytes, speed):
        if not on_progress:
            return
        try:
            on_progress(done, total_bytes, speed)
        except Exception:
            pass

    try:
        headers = {"User-Agent": UA}
        offset = 0
        if resume and os.path.exists(part):
            offset = os.path.getsize(part)
            if offset > 0:
                headers["Range"] = "bytes=%d-" % offset
        req = urllib.request.Request(url, headers=headers)
        op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        r = op.open(req, timeout=timeout)
        code = getattr(r, "status", 200)
        if offset and code != 206:
            offset = 0            # 服务器不认续传，从头来
        else:
            resumed = offset > 0
        cl = int(r.headers.get("Content-Length") or 0)
        total = cl + offset
        done = offset
        mode = "ab" if offset else "wb"
        with open(part, mode) as f:
            while True:
                if cancel is not None and cancel.is_set():
                    r.close()
                    return False, "已取消（未完成的部分留着，可以续传）", {
                        "bytes": done, "path": part}
                chunk = r.read(CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                sp = done / max(0.001, time.time() - t0)
                _emit(done, total, sp)
        r.close()
        if total and done < total:
            return False, "只下到 %d / %d 字节，网络断了吧" % (done, total), {
                "bytes": done, "path": part}
        os.replace(part, target)
        sha = hashlib.sha256()
        with open(target, "rb") as f:
            for b in iter(lambda: f.read(1024 * 1024), b""):
                sha.update(b)
        info = {"bytes": done, "sha256": sha.hexdigest().upper(),
                "elapsed": round(time.time() - t0, 1), "resumed": resumed,
                "total": total}
        return True, target, info
    except Exception as e:
        return False, "下载失败：%s" % e, {"bytes": os.path.getsize(part)
                                         if os.path.exists(part) else 0,
                                         "path": part}


def human_size(n):
    try:
        n = float(n or 0)
    except Exception:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.0f %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024
    return "%.1f TB" % n


class DownloadThread(threading.Thread):
    """给 UI 用的薄包装：跑在后台线程里，主线程只读 self.state。"""

    def __init__(self, url, save_dir, filename="", worker=None):
        super().__init__(daemon=True)
        self.url = url
        self.save_dir = save_dir
        self.filename = filename
        self.cancel_ev = threading.Event()
        self.worker = worker          # 可选：一个带 .emit 的对象
        self.state = {"done": 0, "total": 0, "speed": 0, "ok": None,
                      "path": "", "msg": "", "info": {}}

    def stop(self):
        self.cancel_ev.set()

    def run(self):
        def prog(done, total, speed):
            self.state.update(done=done, total=total, speed=speed)

        ok, path_or_msg, info = download(
            self.url, self.save_dir, self.filename, on_progress=prog,
            cancel=self.cancel_ev)
        self.state.update(ok=ok, info=info)
        if ok:
            self.state["path"] = path_or_msg
        else:
            self.state["msg"] = path_or_msg
