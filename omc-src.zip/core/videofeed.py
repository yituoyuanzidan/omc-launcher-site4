# -*- coding: utf-8 -*-
"""刷视频的内容源：只取《我的世界》相关。

能站内直接播的只有 B 站（它的 playurl 匿名就能拿到 mp4 直链）；
YouTube 能拿到条目（封面/标题/作者），播放要跳到浏览器；
抖音、小红书都是纯前端 + 登录才能看列表，这里只给搜索入口，不硬凑。
"""
import http.cookiejar
import base64
import hashlib
import json
import os
import random
import re
import ssl
import sys
import threading
import time
import urllib.parse
import urllib.request

TIMEOUT = 10
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
BILI_H = {"User-Agent": UA, "Referer": "https://www.bilibili.com/",
          "Origin": "https://www.bilibili.com"}
YT_H = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Cookie": "CONSENT=YES+cb; SOCS=CAI"}

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

_CID_CACHE = {}
_INFO_CACHE = {}
_PLAY_CACHE = {}
_TTL = 600          # 直链有效期短，缓存 10 分钟就够

KEYWORDS = ("我的世界", "Minecraft 我的世界", "我的世界 生存", "我的世界 建筑",
            "奥特曼")


def _get(url, headers=None, timeout=TIMEOUT):
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    req = urllib.request.Request(url, headers=headers or {"User-Agent": UA})
    with op.open(req, timeout=timeout) as r:
        return r.read()


# B 站匿名调接口会被 412 风控，先访问一次首页把 buvid3 之类的 cookie 拿到
_JAR = http.cookiejar.CookieJar()
_OP = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                 urllib.request.HTTPCookieProcessor(_JAR))
_WARMED = [False]


def _warm_bili():
    if _WARMED[0]:
        return
    _WARMED[0] = True
    try:
        req = urllib.request.Request("https://www.bilibili.com/",
                                     headers={"User-Agent": UA})
        _OP.open(req, timeout=8).read()
    except Exception:
        pass


def _get_bili(url, timeout=TIMEOUT):
    _warm_bili()
    req = urllib.request.Request(url, headers=BILI_H)
    with _OP.open(req, timeout=timeout) as r:
        return r.read()


# 空间类接口（UP 投稿列表）要的是「没 cookie 也要带签名」这套，
# 带 cookie 反而容易跟签名里的 buvid 对不上被 412，所以单独一条通道
_PLAIN_OP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _get_plain(url, headers=None, timeout=TIMEOUT):
    req = urllib.request.Request(url, headers=headers or BILI_H)
    with _PLAIN_OP.open(req, timeout=timeout) as r:
        return r.read()


def _clean(text):
    t = re.sub(r"<[^>]+>", "", str(text or ""))
    return (t.replace("&quot;", '"').replace("&amp;", "&")
             .replace("&lt;", "<").replace("&gt;", ">").replace("&#39;", "'"))


# ---------------- B 站 ----------------
def bili_search(keyword, page=1):
    url = ("https://api.bilibili.com/x/web-interface/search/type"
           "?search_type=video&keyword=%s&page=%d"
           % (urllib.parse.quote(keyword), page))
    body = _get_bili(url)
    d = json.loads(body.decode("utf-8", "replace"))
    items = ((d.get("data") or {}).get("result") or [])
    out = []
    for it in items:
        pic = it.get("pic") or ""
        if pic.startswith("//"):
            pic = "https:" + pic
        out.append({
            "platform": "bilibili",
            "id": it.get("bvid") or "",
            "aid": it.get("aid"),
            "title": _clean(it.get("title")),
            "author": _clean(it.get("author")),
            "cover": pic,
            "duration": str(it.get("duration") or ""),
            "views": it.get("play") or 0,
            "pubdate": it.get("pubdate") or 0,
            # 这两个字段以前没取，导致「过滤」只能看标题：接口明明返回了 tag
            # （逗号分隔的一串）和简介，标题里没写「恐怖」但 tag 里写着
            # 「MC 恐怖模组」的片子就一路漏进列表。取回来过滤才有得判断。
            "tags": _clean(it.get("tag") or ""),
            "desc": _clean(it.get("description") or it.get("desc") or ""),
            "page_url": "https://www.bilibili.com/video/%s" % (it.get("bvid") or ""),
            "playable": True,
        })
    return out


_INFO_LOCK = threading.Lock()


def bili_info(bvid):
    """视频详情（缓存）：cid / 标题 / 简介 / 作者，用来从简介里挖背景音乐。

    背景音乐线程和取直链线程常常同时要这条，加锁保证只发一次请求。
    """
    if not bvid:
        return {}
    if bvid in _INFO_CACHE:
        return _INFO_CACHE[bvid]
    with _INFO_LOCK:
        if bvid in _INFO_CACHE:
            return _INFO_CACHE[bvid]
        try:
            body = _get_bili(
                "https://api.bilibili.com/x/web-interface/view?bvid=%s" % bvid)
            d = json.loads(body.decode("utf-8", "replace"))
        except Exception:
            return {}
        data = d.get("data") or {}
        if not data:
            return {}
        info = {
            "cid": data.get("cid"),
            "title": _clean(data.get("title")),
            "desc": data.get("desc") or "",
            "author": _clean((data.get("owner") or {}).get("name")),
        }
        _INFO_CACHE[bvid] = info
        _trim(_INFO_CACHE, 200)
        if info.get("cid"):
            _CID_CACHE[bvid] = info["cid"]
            _trim(_CID_CACHE, 300)
        return info


def bili_cid(bvid):
    if bvid in _CID_CACHE:
        return _CID_CACHE[bvid]
    info = bili_info(bvid)
    return info.get("cid")


def _bili_playurl(bvid, cid, qn):
    """按指定清晰度要一次 html5 直链，返回 (url, quality, 错误)。"""
    url = ("https://api.bilibili.com/x/player/playurl?bvid=%s&cid=%s"
           "&platform=html5&high_quality=1&qn=%d" % (bvid, cid, qn))
    try:
        body = _get_bili(url)
        d = json.loads(body.decode("utf-8", "replace"))
    except Exception as e:
        return "", 0, "取播放地址失败：%s" % e
    if d.get("code") != 0:
        return "", 0, "B 站返回 %s %s" % (d.get("code"), d.get("message"))
    data = d.get("data") or {}
    durl = (data.get("durl") or [])
    if not durl:
        return "", 0, "这条没有可直连的播放地址（可能要大会员或已下架）"
    return (durl[0].get("url") or ""), int(data.get("quality") or qn), ""


def bili_play(bvid, cid=None):
    """拿 mp4 直链（html5 档，匿名可拿）。返回 (url, 说明)。

    以前写死 qn=64（720p 档位），好片子直接糊一档。现在先要 qn=80（1080p），
    拿不到（大会员限定 / 片源没有这档）再退 qn=64，最后才报错——退路和以前一样。
    """
    key = bvid
    hit = _PLAY_CACHE.get(key)
    if hit and time.time() - hit[1] < _TTL:
        return hit[0], ""
    cid = cid or bili_cid(bvid)
    if not cid:
        return "", "拿不到 cid"
    purl = ""
    last_err = ""
    for qn in (80, 64):
        purl, _q, last_err = _bili_playurl(bvid, cid, qn)
        if purl:
            break
    if not purl:
        return "", last_err or "取播放地址失败"
    _PLAY_CACHE[key] = (purl, time.time())
    if len(_PLAY_CACHE) > 120:
        # 只清过期的那批，别整表清空（清空后下一条又得干等一次接口）
        for k in [k for k, v in list(_PLAY_CACHE.items())
                  if time.time() - v[1] > _TTL]:
            _PLAY_CACHE.pop(k, None)
    return purl, ""


# ---------------- YouTube ----------------
# 直链走 youtubei，用 ANDROID_VR 客户端：它给的 formats 里 itag 18（mp4，自带音轨）
# 没被签名保护，url 直接能取 206。WEB / TV 那两个客户端现在要么 UNPLAYABLE，
# 要么被 YouTube 明确挡掉，靠不住。
_YT_VR_CTX = {
    "clientName": "ANDROID_VR",
    "clientVersion": "1.60.19",
    "androidSdkVersion": 32,
    "deviceMake": "Oculus",
    "deviceModel": "Quest 3",
    "osName": "Android",
    "osVersion": "12L",
    "userAgent": ("com.google.android.apps.youtube.vr.oculus/1.60.19 "
                  "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"),
}
_YT_PLAY_CACHE = {}
_YT_DETAIL = {}

# YouTube 直链缓存 15 分钟：googlevideo 的地址带 expire，放太久就是「拿到的
# 地址已经过期」——表现正是“点开就在缓冲、什么都不出”。
_YT_TTL = 900

# ---- yt-dlp 内核（唯一能稳定过「Sign in to confirm you're not a bot」的路）----
# 裸调 youtubei 时 YouTube 现在对多数视频直接 LOGIN_REQUIRED；yt-dlp 里带了
# 正确的 client 参数（android_vr）、visitorData 与请求头组合，同样的地址能拿到。
_DLP_STATE = {"mod": None, "fail": False}
_DLP_UA = ("com.google.android.apps.youtube.vr.oculus/1.60.19 "
           "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip")


def _dlp_zip():
    """找随包带的 yt-dlp 单体包。源码跑在 _tools 下，打包后在 exe 同级/资源目录。"""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cands = [os.path.join(root, "_tools", "yt-dlp.pyz")]
    me = getattr(sys, "_MEIPASS", "") or ""
    if me:
        cands.append(os.path.join(me, "_tools", "yt-dlp.pyz"))
        cands.append(os.path.join(me, "yt-dlp.pyz"))
    try:
        cands.append(os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])),
                                  "_tools", "yt-dlp.pyz"))
    except Exception:
        pass
    for p in cands:
        if os.path.isfile(p):
            return p
    return ""


def _ytdlp():
    if _DLP_STATE["mod"] is not None:
        return _DLP_STATE["mod"]
    if _DLP_STATE["fail"]:
        return None
    z = _dlp_zip()
    if not z:
        _DLP_STATE["fail"] = True
        return None
    try:
        if z not in sys.path:
            sys.path.insert(0, z)          # zipapp 也能直接 import
        import yt_dlp
        _DLP_STATE["mod"] = yt_dlp
        return yt_dlp
    except Exception:
        _DLP_STATE["fail"] = True
        return None


def _yt_stream_ok(url, tries=1):
    """自检一下地址真能拉：拿到 403 的地址交给播放器只会一直转圈。"""
    if not url or not url.startswith("http"):
        return False
    for _ in range(max(1, tries)):
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": _DLP_UA, "Range": "bytes=0-1023",
                              "Referer": "https://www.youtube.com/",
                              "Accept": "*/*"})
            op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with op.open(req, timeout=12) as r:
                r.read(512)
            return True
        except Exception:
            continue
    return False


def _yield_detail(vid, info):
    """把 yt-dlp 的 info 塞进 _YT_DETAIL，格式跟 youtubei 那份对齐。"""
    try:
        _YT_DETAIL[vid] = {
            "title": info.get("title") or "",
            "shortDescription": (info.get("description") or "")[:2000],
            "author": info.get("uploader") or info.get("channel") or "",
            "lengthSeconds": str(info.get("duration") or ""),
            "viewCount": str(info.get("view_count") or ""),
        }
        _trim(_YT_DETAIL, 120)
    except Exception:
        pass


def _dlp_play(vid, attempts=2):
    """用 yt-dlp 取一条**自带音轨**的直链（itag 18 那种），拿不到就再解析一次。"""
    mod = _ytdlp()
    if mod is None:
        return "", "缺少 yt-dlp 内核"
    err = ""
    for _ in range(max(1, attempts)):
        opts = {"quiet": True, "no_warnings": True, "skip_download": True,
                "cachedir": False, "noprogress": True, "socket_timeout": 12,
                # 22=720p muxed，18=360p muxed，两个都自带音轨；以前只写 18，
                # 于是窗口能看、全屏就糊。先要 22，拿不到再退 18。
                "format": ("22/18/best[ext=mp4][acodec!=none]"
                           "/best[acodec!=none]"),
                "extractor_args": {"youtube": {"player_client": ["android_vr"]}}}
        try:
            with mod.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(
                    "https://www.youtube.com/watch?v=%s" % vid, download=False)
        except Exception as e:
            err = str(e)[:90]
            # 反爬拦下来的，再解析一次也一样，别让用户干等那 6 秒
            low = err.lower()
            if "sign in" in low or "confirm you" in low or "bot" in low:
                return "", ("这条 YouTube 在验证这台机器的网络，暂时播不了"
                            "（点「在平台上打开」能看）")
            continue
        u = (info or {}).get("url") or ""
        if u and _yt_stream_ok(u):
            _yield_detail(vid, info)
            return u, ""
        err = "地址被拒（403）"
    return "", err


def _trim(d, limit=200):
    """缓存别无限长：超了就丢最早的那批，内存不跟着刷视频一路涨。"""
    if len(d) <= limit:
        return
    for k in list(d.keys())[:len(d) - limit]:
        d.pop(k, None)


def cached_play(platform, vid):
    """切条时先看一眼缓存：有现成直链就直接开播，省掉一次网络往返。"""
    if not vid:
        return ""
    if platform == "youtube":
        hit = _YT_PLAY_CACHE.get(vid)
    else:
        hit = _PLAY_CACHE.get(vid)
    if hit and time.time() - hit[1] < (_YT_TTL if platform == "youtube" else _TTL):
        return hit[0]
    return ""


def yt_play(vid):
    """取油管可播直链。返回 (url, err)。

    itag 18 自带音轨，质量 360p，够在窗口里看；拿不到就退到 adaptive 里
    码率最高的 mp4 视频（可能没声音，总比黑屏好）。
    """
    vid = (vid or "").strip()
    if not vid:
        return "", "没有视频 id"
    hit = _YT_PLAY_CACHE.get(vid)
    if hit and time.time() - hit[1] < _YT_TTL:
        return hit[0], ""
    body = {
        "context": {"client": dict(_YT_VR_CTX)},
        "videoId": vid,
        "contentCheckOk": True,
        "racyCheckOk": True,
    }
    req = urllib.request.Request(
        "https://www.youtube.com/youtubei/v1/player?prettyPrint=false",
        data=json.dumps(body).encode(),
        headers={"User-Agent": _YT_VR_CTX["userAgent"],
                 "Content-Type": "application/json",
                 "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                 "X-YouTube-Client-Name": "28",
                 "X-YouTube-Client-Version": _YT_VR_CTX["clientVersion"],
                 "Origin": "https://www.youtube.com"})
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with op.open(req, timeout=15) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return "", "取油管地址失败：%s" % e
    st = data.get("streamingData") or {}
    try:
        _YT_DETAIL[vid] = data.get("videoDetails") or {}
    except Exception:
        pass
    # 1) 带音轨的 mp4（formats 里是 muxed 的，音画都在里面）。
    #    以前「第一个 video/mp4 就用」，可油管的 muxed 档通常同时给 itag 18（360p）
    #    和 itag 22（720p），返回顺序并不保证 —— 挑到 18 就是「全屏一片糊」。
    #    现在按 (height, bitrate) 取最大的一条。
    muxed = []
    for f in st.get("formats") or []:
        u = f.get("url") or ""
        mime = (f.get("mimeType") or "").lower()
        if not u or "video/mp4" not in mime:
            continue
        try:
            hh = int(f.get("height") or 0)
        except Exception:
            hh = 0
        try:
            br = int(f.get("bitrate") or 0)
        except Exception:
            br = 0
        muxed.append((hh, br, u))
    if muxed:
        muxed.sort(key=lambda x: (x[0], x[1]), reverse=True)
        u = muxed[0][2]
        _YT_PLAY_CACHE[vid] = (u, time.time())
        _trim(_YT_PLAY_CACHE, 120)
        return u, ""    # 2) 裸 youtubei 被反爬挡掉了（现在绝大多数视频都是这个结果）：
    #    换 yt-dlp 内核再取一次，它带齐了 client 参数，能拿到自带音轨的 itag 18。
    u2, _e2 = _dlp_play(vid)
    if u2:
        _YT_PLAY_CACHE[vid] = (u2, time.time())
        _trim(_YT_PLAY_CACHE, 120)
        return u2, ""
    # 3) 退到 adaptive 里的**视频**流（没有音轨，只比黑屏强一点）。
    #    这里以前是「第一个有 url 的就行」，可 adaptive 是音视频分开的，
    #    运气不好就挑到 audio/mp4 —— 表现正是「进度条在走、画面一片黑/没画面」。
    #    所以 audio/* 一律不要，只要 video/*。
    vids = []
    for f in (st.get("adaptiveFormats") or []):
        u = f.get("url") or ""
        mime = (f.get("mimeType") or "").lower()
        if not u or not mime.startswith("video/"):
            continue
        try:
            br = int(f.get("bitrate") or 0)
        except Exception:
            br = 0
        vids.append((br, u))
    if vids:
        vids.sort(key=lambda x: x[0], reverse=True)
        u = vids[0][1]
        _YT_PLAY_CACHE[vid] = (u, time.time())
        _trim(_YT_PLAY_CACHE, 120)
        return u, ""
    ps = data.get("playabilityStatus") or {}
    reason = str(ps.get("reason") or ps.get("status") or "")
    if "age" in reason.lower() or "sign in" in reason.lower() or "bot" in reason.lower():
        return "", "这条 YouTube 在验证这台机器的网络，暂时播不了（点「在平台上打开」能看）"
    return "", "YouTube 没给可播地址（%s）" % (reason or "未知原因")


def yt_search(keyword):
    """偶尔会被限流返回空页，所以失败时再试一次。"""
    # 兜底再判一次地区：列表/搜索两条主路径都拦过了，这里防止以后新加的
    # 入口（专区、作者页之类）直接调 yt_search 又绕过去。
    if youtube_region_blocked()[0]:
        return []
    for i in range(2):
        items = _yt_search_once(keyword)
        if items:
            return items
        if i == 0:
            time.sleep(1.2)
    return []


def _yt_search_once(keyword):
    url = ("https://www.youtube.com/results?search_query=%s&hl=zh-CN"
           % urllib.parse.quote(keyword))
    try:
        body = _get(url, YT_H)
    except Exception:
        return []
    txt = body.decode("utf-8", "replace")
    out = []
    # 从 ytInitialData 里一段段捞 videoRenderer
    for m in re.finditer(r'"videoId":"([\w-]{11})"', txt):
        vid = m.group(1)
        if any(x["id"] == vid for x in out):
            continue
        chunk = txt[m.start():m.start() + 3000]
        tm = re.search(r'"title":\{"runs":\[\{"text":"(.*?)"\}\]', chunk)
        title = _clean(_unesc(tm.group(1))) if tm else ""
        if not title:
            tm = re.search(r'"title":\{"simpleText":"(.*?)"\}', chunk)
            title = _clean(_unesc(tm.group(1))) if tm else ""
        if not title:
            continue
        om = re.search(r'"ownerText":\{"runs":\[\{"text":"(.*?)"', chunk)
        owner = _clean(_unesc(om.group(1))) if om else ""
        lm = re.search(r'"lengthText":\{[^}]*"simpleText":"([\d:]+)"', chunk)
        length = lm.group(1) if lm else ""
        cm = re.search(r'"thumbnail":\{"thumbnails":\[\{"url":"(.*?)"', chunk)
        cover = _unesc(cm.group(1)) if cm else ""
        pt = re.search(r'"publishedTimeText":\{"simpleText":"(.*?)"', chunk)
        published = _unesc(pt.group(1)) if pt else ""
        vc = re.search(r'"viewCountText":\{"simpleText":"([\d,\.]+)', chunk)
        views = 0
        if vc:
            try:
                views = int(str(vc.group(1)).replace(",", "").replace(".", ""))
            except Exception:
                views = 0
        out.append({
            "platform": "youtube",
            "id": vid,
            "title": title,
            "author": owner,
            "cover": cover,
            "duration": length,
            "views": views,
            "published": published,
            "page_url": "https://www.youtube.com/watch?v=%s" % vid,
            "playable": True,
        })
        if len(out) >= 12:
            break
    return out


def _unesc(s):
    try:
        return s.encode("utf-8").decode("unicode_escape")
    except Exception:
        return s.replace("\\u0026", "&").replace("\\/", "/")


# ---------------- 作者主页 ----------------
# B 站「UP 主投稿列表」接口要 wbi 签名，不签就是 412 / -352 风控
_MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]
_WBI = {}            # {'key': mixin_key, 'ts': 时间}
_MID_CACHE = {}
_YT_CH = {}


def _wbi_key():
    """取 wbi 的 mixin key（两小时有效，缓存着用）。"""
    hit = _WBI.get("key")
    if hit and time.time() - _WBI.get("ts", 0) < 7200:
        return hit
    try:
        body = _get_bili("https://api.bilibili.com/x/web-interface/nav")
        d = json.loads(body.decode("utf-8", "replace"))
        wi = (d.get("data") or {}).get("wbi_img") or {}
        img = (wi.get("img_url") or "").rsplit("/", 1)[-1].split(".")[0]
        sub = (wi.get("sub_url") or "").rsplit("/", 1)[-1].split(".")[0]
        if not img or not sub:
            return ""
        orig = img + sub
        key = "".join(orig[i] for i in _MIXIN_KEY_ENC_TAB)[:32]
        _WBI["key"] = key
        _WBI["ts"] = time.time()
        return key
    except Exception:
        return ""


def _wbi_query(params):
    """把参数排好序加 wts、算 w_rid，返回可直接拼的查询串。"""
    key = _wbi_key()
    if not key:
        return urllib.parse.urlencode(params)
    p = dict(params)
    p["wts"] = int(time.time())
    clean = {}
    for k, v in p.items():
        clean[k] = re.sub(r"[!'()*]", "", str(v))
    items = sorted(clean.items())
    query = urllib.parse.urlencode(items)
    rid = hashlib.md5((query + key).encode()).hexdigest()
    return query + "&w_rid=" + rid


def bili_mid_of(bvid):
    """从一条视频查作者 mid（投稿列表、作者主页都要）。"""
    if bvid in _MID_CACHE:
        return _MID_CACHE[bvid]
    try:
        body = _get_bili("https://api.bilibili.com/x/web-interface/view?bvid=%s"
                         % bvid)
        d = json.loads(body.decode("utf-8", "replace"))
        owner = (d.get("data") or {}).get("owner") or {}
        mid = owner.get("mid")
        if mid:
            _MID_CACHE[bvid] = mid
        return mid
    except Exception:
        return None


def bili_author(mid):
    """UP 主名片：名字、头像、粉丝数、签名、投稿总数。"""
    info = {"platform": "bilibili", "mid": mid, "name": "", "face": "",
            "sign": "", "fans": 0, "count": 0,
            "page_url": "https://space.bilibili.com/%s" % mid}
    try:
        body = _get_bili("https://api.bilibili.com/x/web-interface/card?mid=%s"
                         % mid)
        d = json.loads(body.decode("utf-8", "replace"))
        data = d.get("data") or {}
        card = data.get("card") or {}
        face = card.get("face") or ""
        if face.startswith("//"):
            face = "https:" + face
        info.update({
            "name": _clean(card.get("name")),
            "face": face,
            "sign": _clean(card.get("sign")),
            "fans": card.get("fans") or 0,
            "count": data.get("archive_count") or 0,
        })
    except Exception:
        pass
    return info


# 空间接口要这几个「设备指纹」参数，缺了直接 412；值本身可以给固定的
_DM_PARAMS = {
    "dm_img_list": "[]",
    "dm_img_str": base64.b64encode(b"RIFF\x00\x00\x00\x00WEBPVP8 ").decode(),
    "dm_cover_img_str": base64.b64encode(b"RIFF\x00\x00\x00\x00WEBPVP8X").decode(),
    "dm_img_inter": '{"ds":[],"wh":[0,0,0,1],"of":[0,0,0,1]}',
}


def bili_author_videos(mid, page=1, ps=30):
    """UP 主投稿列表（按发布时间倒序）。

    实测组合：带 cookie + 补 dm 设备参数 + Referer 用 www（用 space 域名会 412）。
    仍然偶尔限流，所以失败时重取一次签名再试。
    """
    last = ""
    for i in range(3):
        params = {"mid": mid, "ps": ps, "pn": page, "order": "pubdate",
                  "platform": "web", "web_location": 1550101}
        params.update(_DM_PARAMS)
        url = ("https://api.bilibili.com/x/space/wbi/arc/search?"
               + _wbi_query(params))
        try:
            body = _get_bili(url)
            d = json.loads(body.decode("utf-8", "replace"))
        except Exception as e:
            last = str(e)
            _WBI.clear()
            time.sleep(1.2 + i)
            continue
        if d.get("code") == 0:
            lst = (((d.get("data") or {}).get("list") or {}).get("vlist") or [])
            break
        last = "B 站返回 %s %s" % (d.get("code"), d.get("message"))
        _WBI.clear()
        time.sleep(1.2 + i)
    else:
        return [], last or "取投稿列表失败"
    lst = lst or []
    out = []
    for x in lst:
        pic = x.get("pic") or ""
        if pic.startswith("//"):
            pic = "https:" + pic
        out.append({
            "platform": "bilibili",
            "id": x.get("bvid") or "",
            "aid": x.get("aid"),
            "title": _clean(x.get("title")),
            "author": _clean(x.get("author")),
            "cover": pic,
            "duration": str(x.get("length") or ""),
            "views": x.get("play") or 0,
            "mid": mid,
            "page_url": "https://www.bilibili.com/video/%s" % (x.get("bvid") or ""),
            "playable": True,
        })
    return out, ""


def yt_channel_of(vid):
    """从视频页找频道 id。"""
    if vid in _YT_CH:
        return _YT_CH[vid]
    try:
        body = _get("https://www.youtube.com/watch?v=%s&hl=zh-CN" % vid, YT_H)
        txt = body.decode("utf-8", "replace")
        m = re.search(r'"channelId":"(UC[\w-]{22})"', txt)
        cid = m.group(1) if m else ""
        if cid:
            _YT_CH[vid] = cid
        return cid
    except Exception:
        return ""


def _yt_json_block(txt):
    """从页面里抠出 ytInitialData 那段 JSON（括号配平，不用正则硬套）。"""
    pos = txt.find("ytInitialData = ")
    if pos < 0:
        pos = txt.find("ytInitialData=")
        if pos < 0:
            return None
    i = txt.find("{", pos)
    if i < 0:
        return None
    depth = 0
    in_str = False
    esc = False
    for j in range(i, min(len(txt), i + 4_000_000)):
        ch = txt[j]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(txt[i:j + 1])
                except Exception:
                    return None
    return None


def _yt_walk_videos(node, out):
    """递归找视频条目：新版是 lockupViewModel，老版是 videoRenderer。"""
    if isinstance(node, dict):
        lv = node.get("lockupViewModel")
        if isinstance(lv, dict):
            vid = lv.get("contentId") or ""
            if vid:
                title = ""
                meta = (lv.get("metadata") or {}).get("lockupMetadataViewModel") or {}
                t = meta.get("title") or {}
                title = t.get("content") or ""
                cover = ""
                length = ""
                views = ""
                img = ((lv.get("contentImage") or {}).get("thumbnailViewModel")
                       or {})
                srcs = ((img.get("image") or {}).get("sources") or [])
                if srcs:
                    cover = srcs[0].get("url") or ""
                for ov in (img.get("overlays") or []):
                    b = ((ov.get("thumbnailBottomOverlayViewModel") or {})
                         .get("badges") or [])
                    for one in b:
                        txt = (one.get("thumbnailBadgeViewModel") or {}).get("text")
                        if txt:
                            length = txt
                rows = (((meta.get("metadata") or {})
                         .get("contentMetadataViewModel") or {})
                        .get("metadataRows") or [])
                for row in rows:
                    for part in (row.get("metadataParts") or []):
                        txt = (part.get("text") or {}).get("content")
                        if txt and not views:
                            views = txt
                out.append({
                    "platform": "youtube",
                    "id": vid,
                    "title": _clean(title),
                    "author": "",
                    "cover": cover,
                    "duration": str(length),
                    "views_text": views,
                    "page_url": "https://www.youtube.com/watch?v=%s" % vid,
                    "playable": False,
                })
        vr = node.get("videoRenderer")
        if isinstance(vr, dict):
            vid = vr.get("videoId") or ""
            if vid:
                title = ""
                t = vr.get("title") or {}
                runs = t.get("runs") or []
                if runs:
                    title = runs[0].get("text") or ""
                elif t.get("simpleText"):
                    title = t["simpleText"]
                length = ((vr.get("lengthText") or {}).get("simpleText") or "")
                views = ((vr.get("viewCountText") or {}).get("simpleText")
                         or "")
                cover = ""
                th = (vr.get("thumbnail") or {}).get("thumbnails") or []
                if th:
                    cover = th[-1].get("url") or ""
                owner = ""
                ot = vr.get("ownerText") or {}
                oruns = ot.get("runs") or []
                if oruns:
                    owner = oruns[0].get("text") or ""
                out.append({
                    "platform": "youtube",
                    "id": vid,
                    "title": _clean(title),
                    "author": _clean(owner),
                    "cover": cover,
                    "duration": str(length),
                    "views_text": views,
                    "page_url": "https://www.youtube.com/watch?v=%s" % vid,
                    "playable": False,
                })
        for v in node.values():
            _yt_walk_videos(v, out)
    elif isinstance(node, list):
        for v in node:
            _yt_walk_videos(v, out)


def yt_channel_videos(cid, need=30):
    """频道投稿（/videos 页的第一屏，约 30 条）。"""
    url = ("https://www.youtube.com/channel/%s/videos?hl=zh-CN" % cid)
    try:
        body = _get(url, YT_H)
    except Exception as e:
        return [], "取频道页失败：%s" % e
    txt = body.decode("utf-8", "replace")
    data = _yt_json_block(txt)
    if not data:
        return [], "频道页解析失败"
    out = []
    _yt_walk_videos(data, out)
    seen = set()
    uniq = []
    for it in out:
        if it["id"] in seen:
            continue
        seen.add(it["id"])
        uniq.append(it)
    return uniq[:need], ""


def yt_channel_info(cid):
    """频道名 / 头像（顺手从频道页拿）。"""
    info = {"platform": "youtube", "cid": cid, "name": "", "face": "",
            "fans": 0, "sign": "", "count": 0,
            "page_url": "https://www.youtube.com/channel/%s" % cid}
    try:
        body = _get("https://www.youtube.com/channel/%s?hl=zh-CN" % cid, YT_H)
        txt = body.decode("utf-8", "replace")
        m = re.search(r'"channelMetadataRenderer":\{"title":"(.*?)"', txt)
        if m:
            info["name"] = _clean(_unesc(m.group(1)))
        m2 = re.search(r'"avatar":\{"thumbnails":\[\{"url":"(.*?)"', txt)
        if m2:
            info["face"] = _unesc(m2.group(1))
        m3 = re.search(r'("subscriberCountText".{0,160}?),"', txt, re.S)
        if m3:
            seg = m3.group(1)
            mm = re.search(r'"simpleText":"(.*?)"', seg)
            if not mm:
                mm = re.search(r'"content":"(.*?)"', seg)
            if mm:
                info["fans_text"] = _clean(_unesc(mm.group(1)))
    except Exception:
        pass
    return info


def author_page(item, need=30):
    """给「UP 主主页」用：返回 (作者信息, 视频列表, 说明)。

    B 站走 card + wbi 投稿列表；油管走频道页。抖音/小红书只有入口。
    """
    plat = item.get("platform")
    if plat == "bilibili":
        bvid = item.get("id") or ""
        mid = item.get("mid") or bili_mid_of(bvid)
        if not mid:
            return {}, [], "拿不到这个 UP 的 id"
        info = bili_author(mid)
        vids, err = bili_author_videos(mid, 1, 30)
        if err:
            return info, [], err
        return info, vids, ""
    if plat == "youtube":
        cid = item.get("channel") or yt_channel_of(item.get("id") or "")
        if not cid:
            return {}, [], "拿不到这个频道的 id"
        info = yt_channel_info(cid)
        vids, err = yt_channel_videos(cid, need)
        if err:
            return info, [], err
        return info, vids, ""
    return {}, [], "这个平台要登录，作者主页只能在网页上看"


def yt_subtitles(vid):
    """尝试拿 YouTube 字幕。返回 (语言, [(起, 文)], 说明)。"""
    try:
        body = _get("https://www.youtube.com/watch?v=%s&hl=en" % vid, YT_H)
        txt = body.decode("utf-8", "replace")
    except Exception as e:
        return "", [], "取视频页失败：%s" % e
    m = re.search(r'"captionTracks":(\[.*?\])', txt)
    if not m:
        return "", [], "这条视频没有开放字幕轨道"
    try:
        tracks = json.loads(m.group(1))
    except Exception:
        return "", [], "字幕轨道解析失败"
    pick = None
    for t in tracks:
        code = (t.get("languageCode") or "").lower()
        if code.startswith("zh"):
            pick = t
            break
    if pick is None:
        for t in tracks:
            if (t.get("languageCode") or "").lower().startswith("en"):
                pick = t
                break
    if pick is None:
        pick = tracks[0] if tracks else None
    if not pick:
        return "", [], "没有可用字幕"
    base = (pick.get("baseUrl") or "").replace("\\u0026", "&")
    if not base:
        return "", [], "字幕地址为空"
    code = (pick.get("languageCode") or "en").lower()
    # 先要 json3，拿不到就当 XML 解析（YouTube 两种都可能给）
    for suffix in ("&fmt=json3", ""):
        try:
            sb = _get(base + suffix,
                      {"User-Agent": UA, "Referer": "https://www.youtube.com/"})
        except Exception as e:
            last = "字幕请求失败：%s" % e
            continue
        txt = sb.decode("utf-8", "replace")
        if not txt.strip():
            last = "字幕内容为空"
            continue
        if txt.lstrip().startswith("{"):
            try:
                d = json.loads(txt)
                segs = []
                for e in (d.get("events") or []):
                    t = "".join([c.get("utf8", "") for c in (e.get("segs") or [])])
                    t = t.replace("\n", " ").strip()
                    if t:
                        segs.append(((e.get("tStartMs") or 0) / 1000.0, t))
                if segs:
                    return code, segs, ""
                last = "字幕里没有正文"
            except Exception as e:
                last = "字幕 JSON 解析失败：%s" % e
            continue
        segs = []
        for m2 in re.finditer(r'<text[^>]*start="([\d.]+)"[^>]*>(.*?)</text>',
                              txt, re.S):
            raw = m2.group(2)
            raw = (raw.replace("&amp;", "&").replace("&lt;", "<")
                   .replace("&gt;", ">").replace("&#39;", "'")
                   .replace("&quot;", '"').replace("\n", " "))
            raw = _clean(raw).strip()
            if raw:
                segs.append((float(m2.group(1)), raw))
        if segs:
            return code, segs, ""
        last = "字幕 XML 里没找到句子"
    return "", [], last


# ---------------- 其他平台（只给入口） ----------------
def douyin_hint():
    return {"platform": "douyin", "ok": False,
            "msg": "抖音网页端的视频列表要登录 + 走加密接口，启动器里拿不到，"
                   "点右边按钮去抖音网页版搜「我的世界」。",
            "url": "https://www.douyin.com/search/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C"}


def xhs_hint():
    return {"platform": "xiaohongshu", "ok": False,
            "msg": "小红书同样要登录才有搜索结果，这里只能给你搜索入口。",
            "url": "https://www.xiaohongshu.com/search_result?keyword=%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C"}


PLATFORM_NAMES = {"bilibili": "B 站", "youtube": "油管",
                  "douyin": "抖音", "xiaohongshu": "小红书"}


# ---------------- 质量过滤 / 相关性 / 排序 ----------------
# 中文视频的标题里出现这些词基本就是 MC：强信号
MC_STRONG = (
    "我的世界", "minecraft", "mc生存", "mc实况", "mc建筑", "mc整合",
    "mc模组", "mc红石", "mcbe", "mc基岩", "mcjava",
    "mc极限生存", "mc空岛", "mc服务器", "mc地图", "mc皮肤", "mc材质",
)
# 弱信号：这些词单独出现也算相关，但要是配上别的游戏名就得判无关
MC_WEAK = (
    "生存", "红石", "建筑", "模组", "整合包", "附魔", "末地", "下界", "地狱",
    "村民", "种子", "皮肤", "材质", "材质包", "指令", "命令方块", "刷怪塔",
    "农场", "挖矿", "苦力怕", "僵尸", "凋灵", "末影", "钻石", "铁傀儡",
    "空岛", "幸运方块", "基岩版", "java版", "起床战争", "hypixel", "服务器",
    "光影", "光影包", "地图", "存档", "建筑教程",
)
# 明确是别的游戏/内容，且标题里没有 MC 强信号时判无关
# 奥特曼以前在这张表里，结果一条都刷不出来；用户要看的是奥特曼本身，
# 所以把它挪到下面的「额外放行题材」里。
NOT_MC = (
    "原神", "王者荣耀", "和平精英", "迷你世界", "蛋仔派对", "第五人格",
    "英雄联盟", "绝地求生", "无畏契约", "泰拉瑞亚", "饥荒", "方舟生存",
    "roblox", "罗布乐思", "gta", "赛博朋克", "光遇", "火影",
    "赛马娘", "崩坏", "星穹铁道", "永劫无间", "暗区突围", "穿越火线",
    "逆战", "大话西游", "梦幻西游", "征途", "我的起源", "迷你攻防",
)
# 额外放行的题材：跟《我的世界》无关，但用户就是要看，别拿相关性规则拦它
ALLOW_EXTRA = ("奥特曼", "ultraman", "ultra man", "奥特英雄")
# 「长得像我的世界」的一堆沙盒/像素游戏：标题里只要点了名，就算同时写着
# 「我的世界」也剔掉（这种多半是对比、撕逼、剪辑搬运，不是我们要看的正片）
BLOCK_ALIKE = (
    "迷你世界", "奶块", "方块堡垒", "方块世界", "我的世界2", "我的世界二",
    "泰拉瑞亚", "terraria", "生存战争", "survivalcraft", "像素沙盒",
    "沙盒世界", "沙盒游戏", "开放世界沙盒", "blockcraft", "block craft",
    "block craft 3d", "cubecraft", "cube craft", "crafting and building",
    "craft world", "minecraft clone", "minecraft style", "minecraft like",
    "mc克隆", "mc仿制", "仿mc", "仿我的世界", "mc风格", "类mc", "类似mc",
    "类似我的世界", "我的世界风格", "像我的世界", "神似我的世界",
    "我的世界平替", "mc平替", "roblox", "罗布乐思", "奶块世界",
)
# 标题里的低质信号（搬运、音画不同步的盗转、纯图集）
LOW_Q = ("转载", "搬运自", "无授权", "侵权", "合集搬运", "转载视频", "已获得授权删除")
# 不推的题材：网页版/魔改客户端/启动器教程这类不是「玩游戏」本身
NOPE_TOPIC = (
    "网页版mc", "网页版我的世界", "我的世界网页版", "mc网页版",
    "网页版minecraft", "重制了网页版", "网页版我的世界重制",
    "启动器", "launcher", "客户端下载", "怎么下载我的世界", "我的世界安装教程",
    "我的世界免费下载", "我的世界破解", "我的世界手机版下载", "手机版我的世界怎么",
    "掌上我的世界", "我的世界手游", "mc手游", "我的世界中国版下载",
)


def is_hype_topic(item):
    """网页版 / 启动器 / 下载安装这类视频：不推。"""
    text = ((item.get("title") or "") + " " + (item.get("tags") or "")).lower()
    return any(k in text for k in NOPE_TOPIC)


# 用户可以自己勾的「不想看」类型（视频页那个过滤按钮就是它）
FILTER_KINDS = (
    ("horror", "恐怖、惊悚、灵异"),
    ("unwell", "血腥、恶心、猎奇"),
    ("story", "剧情演绎、小剧场"),
    ("kiddie", "幼儿向、外国卡通小剧场"),
    ("lowq", "搬运、合集、没解说"),
    ("long", "超长视频（30 分钟以上）"),
)

FILTER_WORDS = {
    # 恐怖这一类要判得狠一点：B 站很多片子的标题故意不写「恐怖」，写「这模组会
    # 让你…」「我第一次玩就后悔了」，但 tag 里老老实实写着「MC 恐怖模组」。
    # 所以这里既收题材词，也收那些只有恐怖片才会用的说法。
    "horror": ("恐怖", "惊悚", "灵异", "闹鬼", "鬼屋", "鬼故事", "鬼片",
               "鬼影", "鬼脸", "女鬼", "怨灵", "恶灵", "阴森", "诡异",
               "毛骨悚然", "不寒而栗", "后背发凉", "吓得", "吓人", "吓尿",
               "吓哭", "胆小勿入", "不敢关灯", "都市传说", "后室",
               "backroom", "back room", "creepypasta", "scp", "规则怪谈",
               "恐怖游戏", "恐怖地图",
               "恐怖模组", "恐怖生存", "寂静岭", "生化危机", "死亡空间",
               "恶灵附身", "黎明杀机", "恐鬼症", "phasmophobia",
               "horror", "scary", "creepy", "spooky", "eerie", "haunted",
               "nightmare", "terror", "terrifying", "jumpscare", "jump scare",
               "ghost", "ghoul", "demon", "devil", "occult", "cursed",
               "scream", "尖叫", "胆小鬼", "undertale", "五夜", "fnaf"),
    "unwell": ("血腥", "恶心", "猎奇", "尸体", "断肢", "呕吐", "gore",
               "重口", "变态", "毁三观", "san值", "不适"),
    "story": ("剧情", "演绎", "小剧场", "角色扮演", "roleplay", "短剧",
              "演出来", "第一人称剧情", "如果我", "假如我"),
    "kiddie": ("儿童", "宝宝", "幼儿", "亲子", "益智", "kids", "for kids",
               "cartoon", "动画片", "baby", "nursery", "colors for kids"),
}

# ---------- 专区：主播 / 系列 ----------
# 视频页「专区」下拉用。关键词写成各平台都能搜到的样子。
# 已逝的创作者（比如 Technoblade）照样留着他的专区，看的是他留下的作品。
SCENES = [
    ("USMP（Unstable SMP）", "Unstable SMP"),
    ("Technoblade（已逝）", "Technoblade"),
    ("Dream", "Dream Minecraft"),
    ("ParrotX2", "ParrotX2"),
    ("Wemmbu", "Wemmbu"),
    ("FlameFrags", "FlameFrags"),
    ("SpokeIsHere", "SpokeIsHere"),
    ("Skeppy", "Skeppy Minecraft"),
    ("GeorgeNotFound", "GeorgeNotFound"),
    ("Sapnap", "Sapnap Minecraft"),
    ("Philza", "Philza Minecraft"),
    ("CaptainSparklez", "CaptainSparklez"),
    ("籽岷", "籽岷 我的世界"),
    ("老番茄", "老番茄 我的世界"),
    ("大橙子", "大橙子 我的世界"),
    ("芒果块", "芒果块 我的世界"),
    ("Acon", "Acon 我的世界"),
    ("迪哥闯世界", "迪哥闯世界 我的世界"),
    ("小本解说", "小本解说 我的世界"),
    ("舞秋风", "舞秋风 我的世界"),
    ("天骐", "天骐 我的世界"),
    ("悠然小天", "悠然小天 我的世界"),
    ("KingSight", "KingSight 我的世界"),
    ("卡哥", "卡哥 我的世界"),
]

# 原视频 / 二创：同一个专区能切两种看法
SCENE_KINDS = (
    ("orig", "只看原视频"),
    ("fan", "只看二创"),
    ("both", "全部都看"),
)

# ---------- 内容安全：涉政、违法违规一律不推 ----------
# 这里只按「类别词」拦，不列任何具体人物或事件名。
POLITIC_WORDS = ("政治", "选举", "大选", "总统", "首相", "政权", "政党",
                 "政府", "抗议", "游行", "示威", "暴乱", "革命", "独立",
                 "分裂国家", "战争", "军事", "导弹", "军队", "恐怖",
                 "恐袭", "枪击", "领导人", "政变", "制裁", "外交",
                 "politic", "election", "protest", "riot", "war",
                 "military", "terror", "coup")
VIOLATION_WORDS = ("赌博", "博彩", "押注", "彩票", "色情", "成人内容",
                   "裸露", "毒品", "大麻", "冰毒", "走私", "洗钱", "诈骗",
                   "传销", "外挂", "私服", "破解", "盗版", "作弊器",
                   "代练", "售卖账号", "黑客", "木马", "porn", "gamble",
                   "casino", "drug", "cheat", "crack", "hack")


def is_unsafe(item):
    """涉政 / 违法违规内容：命中就不进列表（所有平台都拦，不限油管）。"""
    text = " ".join(((item.get("title") or ""), (item.get("desc") or ""),
                     (item.get("tags") or ""), (item.get("author") or ""))
                    ).lower()
    for w in POLITIC_WORDS:
        if w in text:
            return True
    for w in VIOLATION_WORDS:
        if w in text:
            return True
    return False


def drop_unsafe(items):
    """返回 (安全的, 被拦掉的条数)。顺带把「杰杰/麦琪」那类剧情垃圾片拦掉，
    这样不管是推荐、搜索还是专区，走的都是同一道闸。"""
    keep = [it for it in items
            if not is_unsafe(it) and not is_bad_creator(it)]
    return keep, len(items) - len(keep)



def _item_text(it):
    """一条片子能被用来判断的全部文字：标题 + 标签 + 简介 + 作者。

    以前只看标题和标签（而 B 站那边标签压根没取回来），等于只按标题猜，
    标题不写「恐怖」的一律漏过去。现在简介也进来：作者常在里面写
    「这款恐怖模组」「胆小勿入」。
    """
    parts = []
    for k in ("title", "tags", "desc", "author"):
        v = it.get(k)
        if isinstance(v, (list, tuple)):
            v = " ".join(str(x) for x in v)
        if v:
            parts.append(str(v))
    return " ".join(parts)


def apply_filters(items, kinds=None):
    """按用户勾的类型再过一遍。kinds 为空就原样返回。"""
    if not kinds:
        return items
    out = []
    for it in items:
        text = _item_text(it).lower()
        drop = False
        for k in kinds:
            if k == "long":
                sec = _duration_sec(it.get("duration"))
                if sec and sec > 1800:
                    drop = True
            elif k == "lowq":
                if any(w in text for w in LOW_Q):
                    drop = True
            else:
                if any(w in text for w in FILTER_WORDS.get(k, ())):
                    drop = True
            if drop:
                break
        if not drop:
            out.append(it)
    return out

CATEGORIES = (
    ("全部", ""),
    ("生存实况", "生存"),
    ("建筑", "建筑"),
    ("红石机械", "红石"),
    ("模组整合包", "模组 整合包"),
    ("教程攻略", "教程 攻略"),
    ("种子地图", "种子 地图"),
    ("皮肤材质", "皮肤 材质包"),
    ("多人服务器", "服务器 联机"),
    ("小游戏", "小游戏 起床战争"),
    ("搞笑整活", "搞笑 整活"),
    ("奥特曼", "奥特曼"),
)


def _duration_sec(text):
    if not text:
        return 0
    parts = str(text).split(":")
    try:
        nums = [int(p) for p in parts]
    except Exception:
        return 0
    sec = 0
    for n in nums:
        sec = sec * 60 + n
    return sec


# 「XX 进化文明」这类剧情流水线视频：标题套模板、剧情千篇一律，不推。
# 只认「进化 + 文明/矿石/矿物/人类/部落」这种组合，正常的文明模拟、进化史讲
# 解类不会同时撞上两词，所以不会被误杀。
_STORY_PAIRS = (
    ("进化", "文明"), ("进化", "矿石"), ("进化", "矿物"), ("进化", "人类"),
    ("进化", "部落"), ("进化", "村庄"), ("进化", "帝国"), ("进化", "时代"),
    ("进化", "王国"), ("进化", "城市"), ("文明", "矿石"), ("文明", "矿物"),
    ("演变", "文明"), ("发展史", "文明"),
)


# YouTube 上那对「Mikey 和 JJ」（频道叫 Maizen）、以及「杰杰和麦琪」这类剧情
# 短片：剧情烂、演技尬，看着还引人不适，一律不推。这几个词都不是通用词，
# 单独命中就够判定了 —— 以前要求「杰杰 + 迈克」同时出现，结果只带了杰杰、
# 或者只带「麦琪」的那些照样漏进列表，用户刷到过好几次。
_CREATOR_EN = ("mikey", "maizen", "maggie", "maggi",
               "jj and mikey", "mikey and jj")
_CREATOR_CN = ("杰杰", "杰杰杰", "麦琪", "玛琪", "麥琪", "迈克和杰杰",
               # 这两家剧情片在国内的搬运号常用这几个名字，光看标题认不出来
               "小马厨房", "咕咕嘎嘎")
# 这几个是那对角色自己的名字，单独出现可能是别的意思，
# 只有同时是《我的世界》内容才判成垃圾片
_CREATOR_ROLE = ("咕嘎", "比比拉布")
# 这些词经常跟在那两个人的标题后面（「杰杰被…」「麦琪又…」），一起认了
_CREATOR_CTX = ("杰杰", "麦琪", "玛琪", "mikey", "maizen", "maggie", "maggi")


def is_bad_creator(item):
    body = " ".join(((item.get("title") or ""), (item.get("tags") or ""),
                     (item.get("author") or ""), (item.get("desc") or "")
                     )).lower()
    for k in _CREATOR_EN:
        if k in body:
            return True
    for k in _CREATOR_CN:
        if k in body:
            return True
    if any(k in body for k in _CREATOR_ROLE) and \
            ("我的世界" in body or "minecraft" in body):
        return True
    if "jj" in body and ("家族" in body or "小剧场" in body or "剧情" in body):
        return True
    if "jj" in body and any(k in body for k in ("mikey", "maizen")):
        return True
    return False


def is_story_spam(item):
    """矿石进化文明 / 文明进化史这类套模板剧情片，一律不推。"""
    text = ((item.get("title") or "") + " " + (item.get("tags") or "")).lower()
    for a, b in _STORY_PAIRS:
        if a in text and b in text:
            return True
    return False


def relevance(item):
    """这条到底跟《我的世界》有没有关系。返回 (是否相关, 分数)。"""
    title = (item.get("title") or "").lower()
    author = (item.get("author") or "").lower()
    tags = (item.get("tags") or "").lower()
    text = " ".join((title, tags, author))
    # 先剔「长得像 MC 的其他游戏」：只看标题和标签，别拿作者名误伤
    body = " ".join((title, tags))
    for k in BLOCK_ALIKE:
        if k in body:
            return False, 0
    if is_story_spam(item):
        return False, 0
    if is_bad_creator(item):
        return False, 0
    strong = any(k in text for k in MC_STRONG)
    weak = any(k in text for k in MC_WEAK)
    other = any(k in text for k in NOT_MC)
    if strong:
        return True, 42
    if other:
        return False, 0
    if any(k in text for k in ALLOW_EXTRA):
        return True, 30                    # 奥特曼这类：不做 MC 相关性要求
    if weak:
        return True, 22
    return False, 0


_AGE_RE = re.compile(
    r"(\d+)\s*(second|minute|hour|day|week|month|year|秒|分钟|小时|天|周|星期|个月|月|年)",
    re.I)
_AGE_H = {"second": 1.0 / 3600, "秒": 1.0 / 3600, "minute": 1.0 / 60,
          "分钟": 1.0 / 60, "hour": 1.0, "小时": 1.0, "day": 24.0, "天": 24.0,
          "week": 168.0, "周": 168.0, "星期": 168.0, "month": 720.0,
          "个月": 720.0, "月": 720.0, "year": 8760.0, "年": 8760.0}


def age_hours(item):
    """这条发了多久（小时）。取不到就返回 None，不参与排序。"""
    ts = item.get("pubdate")
    if ts:
        try:
            return max(0.0, (time.time() - float(ts)) / 3600.0)
        except Exception:
            pass
    txt = str(item.get("published") or "")
    if not txt:
        return None
    low = txt.lower()
    if "刚刚" in low or "just now" in low or "streamed" in low:
        return 0.0
    m = _AGE_RE.search(low)
    if not m:
        return None
    unit = m.group(2).lower()
    return ((float(m.group(1)) + 0.5) * _AGE_H.get(unit, 24.0))


_BGM_RE = re.compile(
    r"(?:BGM|bgm|Bgm|背景音乐|配乐|插曲|片尾曲|主题曲)"
    r"[\s:：\-—【】\[\]()（）]*([^\n\r,，;；|/]{2,50})")


def find_bgm(text):
    """从简介里把背景音乐抠出来。抠不到给空串。"""
    t = str(text or "")
    m = _BGM_RE.search(t)
    if not m:
        return ""
    s = m.group(1).strip().strip("【】[]()（）<>《》\"'")
    s = re.sub(r"\s{2,}", " ", s).strip()
    for tail in ("感谢", "视频", "本视频", "转载", "作者"):
        if tail in s:
            s = s.split(tail)[0]
    s = s.strip().strip("【】[]()（）<>《》\"':：-—,，。 ")
    return s[:60]


def info(item):
    """一条视频的详情（标题 / 简介 / 作者），给「背景音乐」和别的展示用。"""
    if not item:
        return {}
    p = item.get("platform")
    if p == "bilibili":
        return bili_info(item.get("id"))
    if p == "youtube":
        vid = item.get("id")
        hit = _YT_DETAIL.get(vid)
        if not hit:
            try:
                yt_play(vid)            # 顺带把 details 填进来
            except Exception:
                pass
            hit = _YT_DETAIL.get(vid) or {}
        return {"title": _clean(hit.get("title")),
                "desc": hit.get("shortDescription") or "",
                "author": hit.get("author") or ""}
    return {}


# 营销号 / 带货号：明显导流的直接不推，标题党的一律扣分往后排
_AD_HARD = ("加群", "进群", "群号", "私信", "私聊我", "下方链接", "简介链接",
            "评论区链接", "领取", "免费送", "免费领", "扫码", "二维码",
            "公众号", "微信号", "vx", "威信", "某宝", "淘宝", "店铺", "下单",
            "优惠券", "代练", "接单", "充值", "点我", "戳我", "戳下面",
            "链接在", "复制打开", "giveaway")
_AD_SOFT = ("震惊", "必看", "赶紧", "速看", "绝了", "全网最", "史上最",
            "最牛", "爆款", "百万播放", "千万播放", "天花板", "别错过",
            "秒变", "神器", "赶紧收藏", "收藏起来", "记得关注", "点个赞",
            "一键三连", "关注不迷路", "福利", "干货", "揭秘", "亲测有效")


def is_marketing(item):
    """营销号判定：返回 "hard"（不推）/ "soft"（扣分）/ ""。

    判的是「这条视频像不像在导流卖东西」，不是创作者本身——同一个号也可能
    有正经内容，所以标题党只扣分，只有明确拉群/引流/卖货才直接不推。
    """
    title = item.get("title") or ""
    desc = item.get("desc") or ""
    tags = item.get("tags") or ""
    author = item.get("author") or ""
    body = " ".join((title, desc, tags, author)).lower()
    for k in _AD_HARD:
        if k in body:
            return "hard"
    if title.count("！") + title.count("!") >= 4:
        return "soft"
    if any(k in body for k in _AD_SOFT):
        return "soft"
    if any(k in author for k in ("好物", "带货", "精选", "推荐官", "福利", "优惠")):
        return "soft"
    return ""


def quality_score(item, category=""):
    """综合分：相关性 + 播放量 + 时长 + 类型贴合度 - 低质信号。

    没有点赞数据可用，就用播放量和时长当质量代理；标题里的黑话词再加一点。
    """
    rel, base = relevance(item)
    if not rel:
        return -1
    if is_hype_topic(item):
        return -1                # 网页版 / 启动器 / 下载教程，不推
    mk = is_marketing(item)
    if mk == "hard":
        return -1                # 拉群 / 引流 / 卖货的营销号，不推
    score = float(base)
    if mk == "soft":
        score -= 12.0            # 标题党：能推，但排到后面

    views = item.get("views") or 0
    try:
        views = float(views)
    except Exception:
        views = 0.0
    if views > 0:
        # 播放量取对数，避免百万播放把一切压死
        import math
        score += min(34.0, math.log10(views + 1) * 9.0)
    ah = age_hours(item)
    if ah is not None:
        # 最新发布优先：刚发的加满 16 分，两天前的就归零，再老的不倒扣
        score += max(0.0, 16.0 - ah / 3.0)
    sec = _duration_sec(item.get("duration"))
    if sec:
        if sec < 45:
            return -1            # 几十秒的切片/广告，直接不推
        elif sec < 90:
            score -= 4
        elif sec < 3600:
            score += 6           # 几分钟到一小时：正经内容
        elif sec < 7200:
            score += 3
        else:
            score -= 2           # 两小时以上的长直播，先排后面
    title = (item.get("title") or "").lower()
    for kw, w in (("教程", 7), ("攻略", 6), ("实况", 5), ("生存", 6),
                  ("建筑", 6), ("红石", 7), ("整合包", 6), ("模组", 5),
                  ("极限", 6), ("100天", 8), ("新手", 5), ("原版", 4),
                  ("测试", 3), ("自动化", 5), ("图文", -8), ("录播", -6),
                  ("回放", -5), ("cut", -4), ("合集", 2)):
        if kw in title:
            score += w
    for kw in LOW_Q:
        if kw in title:
            score -= 12
    if category:
        for part in category.split():
            if part and part in title:
                score += 9
    if item.get("platform") == "bilibili" and item.get("playable"):
        score += 3               # 能直接播的优先
    return score


def filter_and_rank(items, category="", need=14, min_score=26.0, kinds=None,
                    skip=None, author_boost="", prefer_fan=False,
                    only_author=False):
    """过滤掉无关/低质，按分数排序。返回 (保留列表, 丢掉的条数)。

    kinds：用户勾的「不想看」类型；skip：这次已经刷过的 key 集合，不再重复出现。
    author_boost：专区名，作者对得上算「原视频」加权；prefer_fan 时反过来压它
    （二创基本都出在别人号上，原作者自己的号反而少）。
    only_author：专区「只看原视频」时只留真的属于这个主播的条目
    （搜出来一堆别人的切片不能算他的专区），少于 3 条才回退到加权排序。
    涉政 / 违法违规内容在这里无条件拦掉，不看用户勾没勾。
    """
    kept = []
    dropped = 0
    seen = set(skip or ())
    for it in items:
        key = (it.get("platform"), it.get("id"))
        if key in seen:
            continue
        seen.add(key)
        s = quality_score(it, category)
        if s < min_score:
            dropped += 1
            continue
        it["_score"] = round(s, 1)
        kept.append(it)
    kept, unsafe = drop_unsafe(kept)
    dropped += unsafe
    if author_boost:
        low = author_boost.lower()
        for it in kept:
            mine = low in (it.get("author") or "").lower()
            if mine and not prefer_fan:
                it["_score"] = it.get("_score", 0) + 14.0
            elif mine and prefer_fan:
                it["_score"] = it.get("_score", 0) - 8.0
        if only_author:
            own = [it for it in kept
                   if low in (it.get("author") or "").lower()]
            if len(own) >= 3:
                kept = own
    kept = apply_filters(kept, kinds)
    # 排序不再是「热度最高的永远第一」：
    # 分数高的整体仍然靠前（0.86~1.28 的系数翻不了大档次），但每次刷出来的顺序会变，
    # 首屏不会永远是同一支。
    for it in kept:
        it["_rank"] = float(it.get("_score", 0)) * (0.86 + random.random() * 0.42)
    kept.sort(key=lambda x: x.get("_rank", 0), reverse=True)
    # 再留点「探新」：有一定概率把第一条和靠前的某条换个位置
    if len(kept) > 3 and random.random() < 0.35:
        j = random.randint(1, min(5, len(kept) - 1))
        kept[0], kept[j] = kept[j], kept[0]
    return kept[:need], dropped


def _merge(items, more):
    """按 id 去重合并。"""
    have = set((i.get("platform"), i.get("id")) for i in items)
    for it in more or []:
        k = (it.get("platform"), it.get("id"))
        if k in have:
            continue
        have.add(k)
        items.append(it)
    return items


def _par(jobs, timeout=14):
    """把几个搜索同时发出去，只等最慢的那个：刷新一下少等一半时间。

    超时别给太长：网络差的时候等 25 秒，用户早就以为卡死了。
    慢的那个到点就放弃，剩下已回来的先用着（多数情况下够一屏）。
    """
    out = [None] * len(jobs)

    def run(i, fn):
        try:
            out[i] = fn()
        except Exception:
            out[i] = []

    ths = []
    for i, fn in enumerate(jobs):
        t = threading.Thread(target=run, args=(i, fn), daemon=True)
        t.start()
        ths.append(t)
    for t in ths:
        t.join(timeout)
    return [r for r in out if r]


# 取回来的原始列表先放这儿：翻回上一页、刷新几次、来回切专区，
# 3 分钟内同一个关键词不再重复打网络，直接拿这批重新过滤排序（本地毫秒级）。
_FEED_CACHE = {}
_FEED_CACHE_TTL = 180.0
_FEED_CACHE_MAX = 14


def _cache_key(platform, category, page, scene, kind):
    return (platform or "", category or "", int(page or 1),
            scene or "", kind or "")


def _cache_get(key):
    hit = _FEED_CACHE.get(key)
    if not hit:
        return None
    ts, items = hit
    if time.time() - ts > _FEED_CACHE_TTL:
        _FEED_CACHE.pop(key, None)
        return None
    return list(items)


def _cache_put(key, items):
    if not items:
        return
    if len(_FEED_CACHE) >= _FEED_CACHE_MAX:
        oldest = min(_FEED_CACHE.items(), key=lambda kv: kv[1][0])[0]
        _FEED_CACHE.pop(oldest, None)
    _FEED_CACHE[key] = (time.time(), list(items))


_YT_REGION = {}
_IP_CACHE = {}
# 多个源一起看：任何一个源说是中国就算中国（一票否决，宁拦勿放）；
# 只有「至少 2 个源都给出答案、而且答案一致、且都不是中国」才放行。
# 全都查不出来、或者几个源互相矛盾 —— 一律当说不清，按不可用处理。
_IP_SOURCES = (
    ("https://ipapi.co/json/", "country_code"),
    ("https://api.ip.sb/geoip", "country_code"),
    ("http://ip-api.com/json/?fields=countryCode", "countryCode"),
    ("https://ipinfo.io/country", ""),
    # 再加几个独立源：国内网络下前面几个经常被拦或超时，
    # 只剩一两个源答话时按「说不清」处理会把境外用户也一起拦掉。
    ("https://api.country.is/", "country"),
    ("https://ipwho.is/", "country_code"),
    ("https://ifconfig.co/country-iso", ""),
)
_IP_MIN_SOURCES = 2


def _exit_country_detail():
    """并发查出口 IP 的国家码。

    返回 (code, 给出答案的源数量, 各源给的码)。一个源说是 CN 就直接返回 CN。
    这几个请求走的是直连（_get 用空 ProxyHandler），查到的是本机真实出口。
    """
    hit = _IP_CACHE.get("v")
    if hit and time.time() - hit[0] < 20.0:
        return hit[1], hit[2], hit[3]

    def one(item):
        url, key = item
        try:
            raw = _get(url, {"User-Agent": UA}, timeout=3.5)
            txt = raw.decode("utf-8", "ignore").strip()
            if not txt:
                return ""
            if not key:
                code = txt.split()[-1].upper() if txt else ""
            else:
                code = (json.loads(txt).get(key) or "").upper()
            if len(code) == 2 and code.isalpha():
                return code
        except Exception:
            return ""
        return ""

    seen = []
    try:
        import concurrent.futures as _cf
        with _cf.ThreadPoolExecutor(max_workers=len(_IP_SOURCES)) as ex:
            outs = list(ex.map(one, _IP_SOURCES))
        seen = [c for c in outs if c]
    except Exception:
        seen = []
    if "CN" in seen:
        code = "CN"
    else:
        code = seen[0] if seen else ""
    _IP_CACHE["v"] = (time.time(), code, len(seen), list(seen))
    return code, len(seen), list(seen)


def _exit_country():
    """查出口 IP 的国家码：返回 "CN" / 其它两位码 / 空串（查不到）。"""
    return _exit_country_detail()[0]


def youtube_region_quick():
    """只读缓存里的判定，不联网。

    返回 (blocked, why)；缓存里还没有结果时返回 None。
    界面点击时用这个：查一次 7 个源要几秒，不能卡在按钮回调里。
    """
    hit = _YT_REGION.get("v")
    if hit and time.time() - hit[0] < 60.0:
        return hit[1], hit[2]
    return None


def youtube_region_blocked():
    """油管在国内 IP 下不许用：返回 (是否禁, 说明)。

    判定只认「使用者自己的出口 IP」，而且刻意做成「默认不放」：
      * 任意一个源看到 CN → 直接禁；
      * 少于 2 个源给出答案（网络被拦、接口不通）→ 禁；
      * 几个源答案不一致（比如同时连着不同出口）→ 禁；
      * 只有 2 个以上源一致地说境外，才放行。
    每 60 秒重查一次，换网络 / 挂代理后很快能跟上。
    """
    hit = _YT_REGION.get("v")
    if hit and time.time() - hit[0] < 60.0:
        return hit[1], hit[2]
    code, n, seen = _exit_country_detail()
    if code == "CN":
        blocked, why = True, "此功能暂时不对中国大陆开放"
    elif n < _IP_MIN_SOURCES or len(set(seen)) != 1 or not code:
        blocked, why = True, "暂时判断不出你所在的网络地区，油管先不开放"
    else:
        blocked, why = False, ""
    _YT_REGION["v"] = (time.time(), blocked, why)
    return blocked, why


def youtube_region_force_recheck():
    """把地区缓存清掉，下一次判定重新查一遍（网络刚变的时候用）。"""
    _YT_REGION.pop("v", None)
    _IP_CACHE.pop("v", None)


# 上一次成功查到的地区码 + 判定结果，给界面显示「地区：日本 / 未知地域」，
# 也用来判断「看视频的过程中 IP 变了没有」。
_LAST_GEO = {"code": "", "ts": 0.0}


def visitor_region():
    """当前出口地区的可读信息（给界面用）。

    返回 dict：
      code   两位国家码，查不到是空串
      text   "日本" 这种中文名；查不到就是「未知地域」
      n      给出答案的源数量
      seen   各源给的码
      blocked 油管是否按地区规则被拦
      why    被拦的原因
    缓存 30 秒，播放中反复调用也不至于把接口打爆。
    """
    blocked, why = youtube_region_blocked()
    code, n, seen = _exit_country_detail()
    if code:
        _LAST_GEO["code"] = code
        _LAST_GEO["ts"] = time.time()
    return {"code": code, "text": _region_name(code), "n": n,
            "seen": list(seen), "blocked": bool(blocked), "why": why or ""}


_REGION_NAMES = {
    "CN": "中国大陆", "HK": "中国香港", "MO": "中国澳门", "TW": "中国台湾",
    "JP": "日本", "KR": "韩国", "US": "美国", "CA": "加拿大", "GB": "英国",
    "DE": "德国", "FR": "法国", "NL": "荷兰", "RU": "俄罗斯",
    "SG": "新加坡", "MY": "马来西亚", "TH": "泰国", "VN": "越南",
    "PH": "菲律宾", "ID": "印度尼西亚", "IN": "印度", "AU": "澳大利亚",
    "NZ": "新西兰", "BR": "巴西", "TR": "土耳其", "AE": "阿联酋",
}


def _region_name(code):
    """国家码 -> 中文名；查不到统一叫「未知地域」。"""
    if not code:
        return "未知地域"
    return _REGION_NAMES.get(code.upper(), code.upper())



def feed(platform, category="", page=1, need=14, kinds=None, skip=None,
         scene="", kind="both"):
    """给刷视频页取一屏内容：多取一些再过滤排序。

    category 传 CATEGORIES 里的第二项（关键词），page 用来换一批。
    kinds 是用户勾的过滤类型，skip 是这次已经刷过的 (platform, id)。
    scene 是「专区」的关键词（主播名 / USMP 这种系列名）；kind 决定看
    原视频（orig）、二创（fan）还是都看（both）。
    几次搜索并发跑，别一条一条慢慢等（这就是「刷新卡顿」的大头）。
    """
    raw = []
    if platform == "youtube" and youtube_region_blocked()[0]:
        return [], 0                   # 国内网络：油管一律不给内容
    ck = _cache_key(platform, category, page, scene, kind)
    hit = _cache_get(ck)
    if hit is None and scene:
        # 专区：按主播/系列名去搜，再按「原视频 / 二创」调关键词
        sname = scene
        if kind == "fan":
            queries = [sname + " 二创", sname + " 剪辑 解说",
                       sname + " 搬运 熟肉"]
        elif kind == "orig":
            queries = [sname + " 原视频", sname]
        else:
            queries = [sname, sname + " 剪辑 解说"]
        if platform == "bilibili":
            res = _par([lambda q=q: bili_search(q, page) for q in queries])
        else:
            res = _par([lambda q=("%s minecraft" % q if "minecraft" not in
                                  q.lower() else q): yt_search(q)
                        for q in queries])
        for r in res:
            raw = _merge(raw, r)
        _cache_put(ck, raw)
        keep, dropped = filter_and_rank(
            raw, "", need=need, kinds=kinds, skip=skip,
            author_boost=sname, prefer_fan=(kind == "fan"),
            only_author=(kind == "orig"))
        return keep, dropped
    if hit is not None:
        raw = hit                      # 3 分钟内的同一页：不打网络，直接排序返回
        return filter_and_rank(raw, category, need=need, kinds=kinds, skip=skip)
    if platform == "bilibili":
        jobs = []
        if category:
            jobs = [(category, page), (category + " 我的世界", page)]
        else:
            for i in range(2):
                jobs.append((KEYWORDS[(page - 1 + i) % len(KEYWORDS)], page + i))
        res = _par([lambda kw=kw, pg=pg: bili_search(kw, pg) for kw, pg in jobs])
        for r in res:
            raw = _merge(raw, r)
    elif platform == "youtube":
        if category and any(k in category.lower() for k in ALLOW_EXTRA):
            q = category                      # 奥特曼不需要拼 minecraft
        elif category:
            q = category + " minecraft"
        else:
            q = "minecraft %s" % ("survival" if page % 2 else "build")
        res = _par([lambda: yt_search(q), lambda: yt_search(q + " tutorial")])
        for r in res:
            raw = _merge(raw, r)
    _cache_put(ck, raw)
    return filter_and_rank(raw, category, need=need, kinds=kinds, skip=skip)


def search(keyword, platform="bilibili", need=14, kinds=None):
    """站内搜：搜完一样走相关性过滤，别把无关的塞进来。"""
    kw = (keyword or "").strip()
    if not kw:
        return [], 0
    # 搜索也不能绕过地区限制：以前只拦了 feed()，从搜索框搜油管照样能刷出
    # 封面和标题，等于把「大陆不许看油管」这条留了个后门。
    if platform == "youtube" and youtube_region_blocked()[0]:
        return [], 0
    # 关键词里没提 MC 的话补上，这样搜「红石」也能落到我的世界里
    looks_mc = any(k in kw.lower() for k in MC_STRONG)
    extra = any(k in kw.lower() for k in ALLOW_EXTRA)
    mine = kw if (looks_mc or extra) else ("我的世界 " + kw)
    raw = []
    if platform == "bilibili":
        jobs = [lambda: bili_search(mine, 1), lambda: bili_search(mine, 2)]
        if not looks_mc and not extra:
            jobs.append(lambda: bili_search(kw, 1))
        for r in _par(jobs):
            raw = _merge(raw, r)
    else:
        raw = yt_search(mine)
        if not looks_mc and not extra:
            raw = _merge(raw, yt_search(kw))
    return filter_and_rank(raw, kw, need=need, kinds=kinds)

