# -*- coding: utf-8 -*-
"""把当前游戏目录里的模组 / 配置 / 资源包 / 光影打成一个整合包 zip。

产物面向"发给朋友"：解压后把 mods、config 等放进 game_dir 就能玩。
"""
import os
import time
import zipfile

README = """%s
导出时间：%s
由 OMC 启动器导出

怎么用：
1. 用 OMC（或别的启动器）装一个对应的 Minecraft 版本 + 同样的加载器（Forge / Fabric / NeoForge）。
2. 把这个包里的 mods 文件夹整个放进游戏目录的 mods 里。
3. config 文件夹放进游戏目录的 config 里（里面是模组的配置文件）。
4. resourcepacks / shaderpacks 同理放进游戏目录。
5. options.txt 是游戏设置，想沿用就放进游戏目录（不想改就删掉）。

注意：光影需要装 Iris / OptiFine 才能用；版本要跟模组要求的游戏版本一致。
"""


def _walk_files(root, prefix):
    out = []
    if not os.path.isdir(root):
        return out
    for cur, _dirs, files in os.walk(root):
        for f in files:
            p = os.path.join(cur, f)
            rel = os.path.relpath(p, root).replace("\\", "/")
            out.append((p, "%s/%s" % (prefix, rel)))
    return out


def collect(game_dir, include_resourcepacks=True, include_shaders=True,
            include_saves=False):
    """收集要打包的文件，返回 [(源路径, zip 内路径)]。"""
    items = []
    items += _walk_files(os.path.join(game_dir, "mods"), "mods")
    items += _walk_files(os.path.join(game_dir, "config"), "config")
    opt = os.path.join(game_dir, "options.txt")
    if os.path.exists(opt):
        items.append((opt, "options.txt"))
    if include_resourcepacks:
        items += _walk_files(os.path.join(game_dir, "resourcepacks"),
                             "resourcepacks")
    if include_shaders:
        items += _walk_files(os.path.join(game_dir, "shaderpacks"),
                             "shaderpacks")
    if include_saves:
        items += _walk_files(os.path.join(game_dir, "saves"), "saves")
    return items


def export_pack(game_dir, out_zip, name="我的整合包",
                progress=None, include_resourcepacks=True,
                include_shaders=True, include_saves=False):
    """写出整合包，返回 (out_zip, 文件数, 字节数)。"""
    log = progress or (lambda _done, _total, _msg: None)
    items = collect(game_dir, include_resourcepacks, include_shaders,
                    include_saves)
    if not items:
        raise RuntimeError("这个游戏目录里没有可导出的东西（mods / config 都是空的）")
    total = len(items)
    out_dir = os.path.dirname(out_zip)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    tmp = out_zip + ".part"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for i, (src, arc) in enumerate(items):
            z.write(src, arc)
            log(i + 1, total, "打包 " + arc)
        z.writestr("OMC-整合包说明.txt",
                   README % (name, time.strftime("%Y-%m-%d %H:%M")))
    os.replace(tmp, out_zip)
    return out_zip, total, os.path.getsize(out_zip)
