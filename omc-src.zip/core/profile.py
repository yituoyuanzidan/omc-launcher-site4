# -*- coding: utf-8 -*-
"""个人主页资料：简介、头像、游戏时长、好友数、启动器在线时长。

没有自己的服务器，还是用 ntfy 公共中转，一人一个主页频道：
    omc-prof3-<账号名哈希>

每台启动器启动时发一条、之后每 3 分钟发一条，看完就留在公共频道里，
别人打开你的主页时拉最近 7 天的最新一条。隐藏的字段在发布前就剥掉，
不是靠前端遮——省得别人扒原始消息。
"""
import hashlib
import json
import time

from core import gamesync as gs

FIELDS = ("play", "friends", "online", "bio", "avatar")
FIELD_LABELS = {"play": "游戏时长", "friends": "好友数量",
                "online": "启动器在线时长", "bio": "主页简介",
                "avatar": "头像"}


def _h(s):
    return hashlib.md5(s.encode("utf-8")).hexdigest()[:12]


def topic(name):
    return "omc-prof3-" + _h("omc-prof3-v1|" + (name or "").strip().lower())


def fmt_minutes(m):
    """分钟数 -> 「123 小时 40 分」/「40 分钟」。"""
    try:
        m = int(m or 0)
    except Exception:
        m = 0
    if m < 60:
        return "%d 分钟" % m
    h, mm = m // 60, m % 60
    if h < 100:
        return "%d 小时 %d 分" % (h, mm) if mm else "%d 小时" % h
    return "%d 小时" % h


def publish(me, uid="", bio="", play=0, friends=0, online=0,
            hide=None, avatar_b64="", timeout=gs.TIMEOUT):
    """把自己的主页挂上去；hide 里的字段会被剥掉。"""
    hide = hide or {}
    payload = {"t": "prof", "n": (me or "")[:32], "u": (uid or "")[:24],
               "ts": int(time.time())}
    if not hide.get("bio"):
        payload["bio"] = (bio or "")[:200]
    if not hide.get("play"):
        payload["play"] = int(play or 0)
    if not hide.get("friends"):
        payload["fr"] = int(friends or 0)
    if not hide.get("online"):
        payload["on"] = int(online or 0)
    if not hide.get("avatar") and avatar_b64:
        payload["av"] = avatar_b64
    payload["hide"] = {k: 1 for k, v in hide.items() if v}
    if not me:
        return False, "还没登录"
    try:
        gs._post(topic(me), payload, timeout=timeout)
    except Exception as e:
        return False, "主页没发出去：%s" % e
    return True, "已更新主页"


def fetch(name, since="7d", timeout=gs.TIMEOUT):
    """拉某个人的主页，返回最新一条 dict（没有就 None）。"""
    name = (name or "").strip()
    if not name:
        return None
    rows = gs._pull(topic(name), since=since, timeout=timeout, kinds=("prof",))
    best = None
    for r in rows:
        if (r.get("n") or "").strip().lower() != name.lower():
            continue
        if best is None or int(r.get("_ts") or 0) >= int(best.get("_ts") or 0):
            best = r
    return best


def from_local(name, config, friendbook, avatar_mod=None):
    """自己没登录/没发布时，至少把本机能算的算出来。"""
    play = int(config.get("play_minutes") or 0) if config else 0
    online = int(config.get("online_minutes") or 0) if config else 0
    fr = friendbook.count() if friendbook else 0
    bio = (config.get("profile_bio") or "") if config else ""
    out = {"n": name, "bio": bio, "play": play, "fr": fr, "on": online, "ts": int(time.time())}
    return out


def add_minutes(config, key, minutes):
    """往 config 里累加分钟数（play_minutes / online_minutes）。"""
    if not config or minutes <= 0:
        return 0
    try:
        cur = int(config.get(key) or 0)
    except Exception:
        cur = 0
    cur += int(minutes)
    try:
        config.set(key, cur)
        config.save()
    except Exception:
        pass
    return cur
