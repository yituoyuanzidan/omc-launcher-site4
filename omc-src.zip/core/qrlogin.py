# -*- coding: utf-8 -*-
"""扫码登录：电脑上出二维码，手机扫一下在浏览器里点「确认登录」。

给微信 / QQ 两个渠道用同一套机制——不接开放平台（那要企业资质），
所以扫码这一步走的是「电脑上的启动器 + 同一 Wi-Fi 的手机」：
手机连同一个 Wi-Fi 就能打开确认页，点确认之后电脑才会登录。
这样有个额外好处：账号不会被别人随便扫码顶掉，必须你本人手机点一下。

注：手机和电脑必须在同一个局域网；跨网络扫码需要把启动器端口映射出去，
那一层不在本机做。
"""
import html
import json
import os
import socket
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

_STATE = {}
_LOCK = threading.Lock()
TTL = 180          # 二维码 3 分钟有效

#: 画好的二维码 PNG 缓存（同一票据不重复渲染）。以前这里漏了定义，
#: 一进 qr_png 就抛 NameError，界面就「二维码生成不出来」。
_QR_PNG_CACHE = {}
_QR_CACHE_MAX = 24


def _purge():
    now = time.time()
    for k, v in list(_STATE.items()):
        if now - v["created"] > TTL and v["status"] == "pending":
            v["status"] = "expired"


def _adapter_ips():
    """枚举本机各网卡的 IPv4（走 GetAdaptersAddresses），带网卡名和状态。

    返回 [(friendly, description, iftype, ip)]。取不到就返回空列表。
    """
    import ctypes
    import ctypes.wintypes as wt
    import socket as _s

    class _Head(ctypes.Union):
        class _Inner(ctypes.Structure):
            _fields_ = [("Length", wt.ULONG), ("IfIndex", wt.DWORD)]
        _fields_ = [("Alignment", ctypes.c_ulonglong), ("_s", _Inner)]

    class _SocketAddress(ctypes.Structure):
        _fields_ = [("lpSockaddr", ctypes.c_void_p),
                    ("iSockaddrLength", ctypes.c_int)]

    class _Unicast(ctypes.Structure):
        pass

    _Unicast._fields_ = [
        ("Head", _Head),
        ("Next", ctypes.POINTER(_Unicast)),
        ("Address", _SocketAddress),
    ]

    class _Addr(ctypes.Structure):
        pass

    _Addr._fields_ = [
        ("Head", _Head),
        ("Next", ctypes.POINTER(_Addr)),
        ("AdapterName", ctypes.c_char_p),
        ("FirstUnicastAddress", ctypes.POINTER(_Unicast)),
        ("FirstAnycastAddress", ctypes.c_void_p),
        ("FirstMulticastAddress", ctypes.c_void_p),
        ("FirstDnsServerAddress", ctypes.c_void_p),
        ("DnsSuffix", ctypes.c_wchar_p),
        ("Description", ctypes.c_wchar_p),
        ("FriendlyName", ctypes.c_wchar_p),
        ("PhysicalAddress", ctypes.c_ubyte * 8),
        ("PhysicalAddressLength", wt.ULONG),
        ("Flags", wt.ULONG),
        ("Mtu", wt.ULONG),
        ("IfType", wt.ULONG),
        ("OperStatus", ctypes.c_int),
    ]

    AF_UNSPEC = 0
    FLAGS = 0x0002 | 0x0004 | 0x0008      # 跳过 anycast / multicast / dns
    size = wt.ULONG(15 * 1024)
    buf = ctypes.create_string_buffer(size.value)
    fn = ctypes.windll.iphlpapi.GetAdaptersAddresses
    fn.argtypes = [wt.ULONG, wt.ULONG, ctypes.c_void_p, ctypes.c_void_p,
                   ctypes.POINTER(wt.ULONG)]
    fn.restype = wt.ULONG
    rc = fn(AF_UNSPEC, FLAGS, None, buf, ctypes.byref(size))
    if rc == 111:                       # ERROR_BUFFER_OVERFLOW，按需要的长度重来
        buf = ctypes.create_string_buffer(size.value)
        rc = fn(AF_UNSPEC, FLAGS, None, buf, ctypes.byref(size))
    if rc != 0:
        return []

    out = []
    p = ctypes.cast(buf, ctypes.POINTER(_Addr))
    while p:
        a = p.contents
        for u in _iter_unicast(a.FirstUnicastAddress):
            if not u.lpSockaddr:
                continue
            raw = ctypes.string_at(u.lpSockaddr, u.iSockaddrLength)
            if len(raw) >= 8 and raw[0] == 2:           # AF_INET
                out.append((a.FriendlyName or "", a.Description or "",
                            int(a.IfType), socket.inet_ntoa(raw[4:8]),
                            int(a.OperStatus)))
        p = a.Next
    return out


def _iter_unicast(first):
    """遍历 IP_ADAPTER_UNICAST_ADDRESS 链，产出 SOCKET_ADDRESS。"""
    p = first
    while p:
        a = p.contents
        yield a.Address
        p = a.Next


#: 名字里带这些的网卡基本都是虚拟的，手机连不上
_VIRTUAL_HINTS = ("vethernet", "hyper-v", "wsl", "docker", "virtualbox",
                  "vmware", "loopback", "tap", "tunnel", "npcap", "zerotier",
                  "tailscale", "radmin", "hamachi", "蓝牙", "bluetooth",
                  "wireguard", "openvpn", "tun0", "tun1", "vpn")

_IP_CACHE = {"ip": "", "at": 0.0}
IP_CACHE_SEC = 30


def _score(iftype, ip, name):
    """给候选地址打分，小的更优先。"""
    s = 0
    if ip.startswith("192.168."):
        s += 0
    elif ip.startswith("10."):
        s += 1
    elif ip.startswith("172."):
        s += 3                       # 172.16-31 里虚拟网卡居多
    else:
        s += 6
    if iftype == 71:                 # IF_TYPE_IEEE80211，Wi-Fi
        s -= 1
    elif iftype == 6:                # IF_TYPE_ETHERNET_CSMACD
        s -= 0
    else:
        s += 2
    return s


def lan_ip(force=False):
    """返回手机应该访问的本机局域网地址。

    以前直接用「连 114.114.114.114 得到的本机地址」，机器上装了 WSL / Docker
    这类虚拟网卡时，默认路由会落到虚拟网卡上（拿到 172.19.0.1 这种），
    手机扫进去根本连不上，只能一直等到超时——表现就是「扫码登录延迟特别高」。
    这里改成枚举真实网卡，排除虚拟网卡后按网段打分选一个，并缓存 30 秒。
    """
    now = time.time()
    if not force and _IP_CACHE["ip"] and now - _IP_CACHE["at"] < IP_CACHE_SEC:
        return _IP_CACHE["ip"]

    best = None
    try:
        for friendly, desc, iftype, ip, status in _adapter_ips():
            if status != 1:                       # 只要 IfOperStatusUp
                continue
            if ip.startswith(("127.", "169.254.", "0.")):
                continue
            if iftype in (24, 53, 131):           # loopback / tunnel / tunnel
                continue
            name = (friendly + " " + desc).lower()
            if any(h in name for h in _VIRTUAL_HINTS):
                continue
            score = _score(iftype, ip, name)
            if best is None or score < best[0]:
                best = (score, ip)
    except Exception:
        best = None

    ip = best[1] if best else ""
    if not ip:                                # 兜底：还按老办法问一次路由
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("114.114.114.114", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "127.0.0.1"
        finally:
            try:
                s.close()
            except Exception:
                pass

    _IP_CACHE["ip"] = ip
    _IP_CACHE["at"] = now
    return ip


def new_ticket(kind="wechat", name="", port=8901):
    """开一张票据。kind 是渠道名（微信 / QQ），name 是当前待登录账号名。"""
    _purge()
    ticket = uuid.uuid4().hex[:10].upper()
    with _LOCK:
        _STATE[ticket] = {"status": "pending", "created": time.time(),
                          "kind": kind, "name": name, "port": port,
                          "confirmed_by": ""}
    return ticket


def state(ticket):
    with _LOCK:
        v = _STATE.get(ticket)
        if not v:
            return "missing"
        return v["status"]


def confirm(ticket, who=""):
    with _LOCK:
        v = _STATE.get(ticket)
        if not v:
            return False
        if v["status"] != "pending":
            return False
        v["status"] = "confirmed"
        v["confirmed_by"] = who
        return True


def cancel(ticket):
    with _LOCK:
        v = _STATE.get(ticket)
        if v:
            v["status"] = "cancelled"


def drop(ticket):
    with _LOCK:
        _STATE.pop(ticket, None)


def url_for(ticket, port):
    return "http://%s:%d/q/%s" % (lan_ip(), port, ticket)


def qr_png(ticket, port, scale=6):
    """把确认网址画成二维码 PNG 字节；没装 qrcode 时返回空。

    同一个票据只画一次（qrcode 首次导入 + 渲染要 100ms 上下，
    重复生成时直接拿缓存，点按钮不会卡顿）。
    """
    key = (ticket, port, scale)
    hit = _QR_PNG_CACHE.get(key)
    if hit:
        return hit
    try:
        import qrcode
    except Exception:
        return b""
    try:
        # 自己指定模块像素和留白：默认 box_size=1 拉到 180px 会被缩放糊掉，
        # 手机扫的时候容易识别不出。
        q = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M,
                          box_size=max(2, int(scale)), border=2)
        q.add_data(url_for(ticket, port))
        q.make(fit=True)
        img = q.make_image(fill_color="black", back_color="white")
        from io import BytesIO
        buf = BytesIO()
        img.save(buf, "PNG")
        data = buf.getvalue()
        if len(_QR_PNG_CACHE) >= _QR_CACHE_MAX:
            _QR_PNG_CACHE.clear()
        _QR_PNG_CACHE[key] = data
        return data
    except Exception:
        return b""


def qr_png_bytes(ticket, port, scale=6):
    """python 侧要「为什么没画出来」时用：返回 (png, 错误说明)。"""
    png = qr_png(ticket, port, scale)
    if png:
        return png, ""
    try:
        import qrcode  # noqa: F401
    except Exception as e:
        return b"", "缺少 qrcode 库（%s）" % e
    return b"", "二维码渲染失败"


# ---------- 手机端看到的确认页 ----------
_PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OMC 登录确认</title>
<style>
body{margin:0;background:#12151B;color:#E8EDF5;
font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
display:flex;align-items:center;justify-content:center;min-height:100vh}
.box{width:min(92vw,420px);background:#1C2029;border-radius:16px;padding:24px}
.h{font-size:20px;font-weight:700;margin:0 0 8px}
.s{color:#9AA3B2;font-size:13px;line-height:1.6;margin:0 0 18px}
.k{color:#9AA3B2;font-size:12px;margin:0 0 4px}
.v{font-size:15px;margin:0 0 14px;word-break:break-all}
.btn{display:block;width:100%;border:0;border-radius:10px;padding:14px;
font-size:16px;font-weight:600;margin-top:10px;color:#fff;background:#3FB950}
.btn2{background:#2A3040;color:#C7CEFB}
.tip{color:#6F7787;font-size:12px;margin-top:14px;line-height:1.5}
</style></head><body><div class="box">
<p class="h">确认在电脑上登录 OMC</p>
<p class="s">请核对下面的信息，确认是你自己的操作。点「确认登录」之后，
电脑上的启动器才会登录，别把这个页面转发给别人。</p>
<p class="k">渠道</p><div class="v">__KIND__</div>
<p class="k">登录到账号</p><div class="v">__NAME__</div>
<p class="k">请求时间</p><div class="v">__WHEN__</div>
<form method="post" action="/q/__TICKET__/ok">
<button class="btn" type="submit">确认登录</button></form>
<form method="post" action="/q/__TICKET__/no">
<button class="btn btn2" type="submit">不是我，取消</button></form>
<p class="tip">确认后可以关掉这个页面。如果不是你本人在登录，直接点取消。</p>
</div></body></html>"""

_DONE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OMC</title><style>body{margin:0;background:#12151B;color:#E8EDF5;
font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
display:flex;align-items:center;justify-content:center;min-height:100vh}
.d{background:#1C2029;border-radius:16px;padding:28px;font-size:16px;
text-align:center;line-height:1.7}</style></head>
<body><div class="d">__MSG__</div></body></html>"""


class _Handler(BaseHTTPRequestHandler):
    server_version = "OMC-QR"

    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path.startswith("/q/"):
            ticket = path[3:].strip("/")
            with _LOCK:
                v = _STATE.get(ticket)
            if not v:
                self._send(404, _DONE.replace("__MSG__", "这个二维码已经失效了。"))
                return
            if v["status"] != "pending":
                msg = ("已经在电脑上登录了。" if v["status"] == "confirmed"
                       else "这次登录已取消，请重新生成二维码。")
                self._send(200, _DONE.replace("__MSG__", msg))
                return
            when = time.strftime("%H:%M:%S", time.localtime(v["created"]))
            body = (_PAGE.replace("__KIND__", html.escape(v.get("kind") or ""))
                    .replace("__NAME__", html.escape(v.get("name") or "（未指定）"))
                    .replace("__WHEN__", when)
                    .replace("__TICKET__", ticket))
            self._send(200, body)
        else:
            self._send(404, _DONE.replace("__MSG__", "没有这个页面。"))

    def do_POST(self):
        path = self.path.split("?")[0]
        if path.startswith("/q/") and (path.endswith("/ok") or path.endswith("/no")):
            parts = path.strip("/").split("/")
            ticket = parts[1] if len(parts) > 1 else ""
            ok = path.endswith("/ok")
            if ok:
                done = confirm(ticket, "手机端")
            else:
                cancel(ticket)
                done = True
            msg = ("已确认，请回到电脑上的启动器。" if ok
                   else "已取消这次登录。")
            if not done:
                msg = "这个二维码已经失效了。"
            self._send(200, _DONE.replace("__MSG__", msg))
        else:
            self._send(404, _DONE.replace("__MSG__", "没有这个页面。"))


class QrServer(object):
    """电脑上开的小服务，只给手机扫进来点「确认」用。"""

    def __init__(self, port=8901):
        self.port = port
        self.httpd = None
        self.thread = None

    def start(self):
        if self.httpd:
            return self.port
        for p in range(self.port, self.port + 8):
            try:
                self.httpd = ThreadingHTTPServer(("0.0.0.0", p), _Handler)
                self.port = p
                break
            except Exception:
                self.httpd = None
        if not self.httpd:
            return 0
        self.thread = threading.Thread(target=self.httpd.serve_forever,
                                       daemon=True)
        self.thread.start()
        return self.port

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None
