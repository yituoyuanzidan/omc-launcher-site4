# -*- coding: utf-8 -*-
"""OMC 公共服：地址存取、服务器状态探测、分享文案。

公共服由作者维护一台常开的《我的世界》服务器（托管在简幻欢等平台），
启动器里只暴露「地址 + 在线人数 + 一键加入」。玩家进服不需要注册任何平台，
只需要在自己的 Minecraft 里填这个地址，或者直接在启动器里点「加入」。

设计取舍：
1. 地址不写死在代码里 —— 换服/换端口不用发新版本。优先读远端配置
   （GitHub Pages 上的 public_server.json），其次读本地配置，最后读缓存。
2. 探测用标准 Server List Ping 协议，纯标准库，不依赖服务器类型。
3. 所有网络操作都有超时，失败一律返回「离线」，绝不抛异常打断界面。
"""
import json
import os
import socket
import struct
import time

from . import config

# 远端配置：作者把地址放站点上，玩家启动器自己拉，改地址不用重发安装包
REMOTE_URL = "https://yituoyuanzidan.github.io/omc-launcher-site4/public_server.json"
CACHE_NAME = "public_server.json"
DEFAULT_PORT = 25565

CONFIG_KEY = "public_server"


# ---------- 地址解析 ----------
def split_addr(text):
    """把 'host:port' / 'host' 拆成 (host, port)。解析失败返回 (None, 0)。"""
    raw = (text or "").strip()
    if not raw:
        return None, 0
    raw = raw.replace("minecraft://", "").replace("http://", "").strip()
    if raw.endswith("/"):
        raw = raw[:-1]
    if ":" in raw:
        host, _, port_text = raw.rpartition(":")
        try:
            port = int(port_text)
        except Exception:
            return None, 0
        host = host.strip()
    else:
        host, port = raw, DEFAULT_PORT
    if not host:
        return None, 0
    if not (1 <= port <= 65535):
        return None, 0
    return host, port


def join_addr(host, port):
    if not host:
        return ""
    if int(port or DEFAULT_PORT) == DEFAULT_PORT:
        return host
    return "%s:%d" % (host, int(port))


# ---------- 配置读写 ----------
def save(cfg, addr, name="", note=""):
    """写入本地配置。addr 可以带端口。返回规范化后的 dict。

    cfg 是 core.config.Config 的实例（主窗口里传 self.config）。
    """
    host, port = split_addr(addr)
    if not host:
        raise ValueError("地址格式不对，应该像 1.2.3.4:25565")
    data = {"addr": join_addr(host, port), "host": host, "port": port,
            "name": (name or "OMC 公共服").strip(), "note": (note or "").strip()}
    if cfg is not None:
        cfg.set(CONFIG_KEY, data)
        try:
            cfg.save()
        except Exception:
            pass
    _write_cache(data)
    return data


def _write_cache(data):
    path = _cache_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _cache_path():
    return os.path.join(config.app_dir(), CACHE_NAME)


def _read_cache():
    try:
        with open(_cache_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) and d.get("addr") else None
    except Exception:
        return None


def _normalize(raw):
    """把任意来源的字段整理成同一套结构。"""
    if not isinstance(raw, dict):
        return None
    addr = raw.get("addr") or raw.get("address") or ""
    host, port = split_addr(addr)
    if not host:
        return None
    return {
        "addr": join_addr(host, port),
        "host": host,
        "port": port,
        "name": (raw.get("name") or "OMC 公共服").strip(),
        "note": (raw.get("note") or "").strip(),
    }


def load(cfg=None):
    """当前生效的公共服地址。顺序：本地配置 → 远端缓存 → None。"""
    d = _normalize(cfg.get(CONFIG_KEY) if cfg is not None else None)
    if d:
        return d
    d = _normalize(_read_cache())
    if d:
        return d
    return None


def fetch_remote(timeout=8):
    """从站点拉公共服配置；成功则写缓存并返回，失败返回 None。"""
    try:
        from . import http
        raw = http.fetch_json(REMOTE_URL, timeout=timeout)
    except Exception:
        return None
    d = _normalize(raw)
    if d:
        _write_cache(d)
    return d


# ---------- 状态探测（Server List Ping） ----------
def _varint(n):
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out += bytes([b | 0x80])
        else:
            return out + bytes([b])


def _read_varint(sock, limit=5):
    num = 0
    for i in range(limit):
        b = sock.recv(1)
        if not b:
            raise RuntimeError("连接已断开")
        v = b[0]
        num |= (v & 0x7F) << (7 * i)
        if not v & 0x80:
            return num
    raise RuntimeError("数据格式不对")


def _mc_string(s):
    raw = s.encode("utf-8")
    return _varint(len(raw)) + raw


def _read_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise RuntimeError("连接已断开")
        buf += chunk
    return buf


def _motd_plain(motd):
    """MOTD 可能是纯文本，也可能是聊天组件（dict / list），取纯文本。"""
    if motd is None:
        return ""
    if isinstance(motd, str):
        return motd
    if isinstance(motd, dict):
        parts = [motd.get("text") or ""]
        for extra in motd.get("extra") or []:
            parts.append(_motd_plain(extra))
        return "".join(parts)
    if isinstance(motd, list):
        return "".join(_motd_plain(x) for x in motd)
    return str(motd)


def _strip_mc_codes(text):
    """去掉 §x 颜色/格式代码，界面里只留文字。"""
    out = []
    i = 0
    n = len(text or "")
    while i < n:
        ch = text[i]
        if ch == "§":
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def ping(host, port, timeout=3.0):
    """探测服务器状态。返回 dict：
    online / players / max_players / version / motd / latency_ms / error
    """
    result = {"online": False, "players": 0, "max_players": 0,
              "version": "", "motd": "", "latency_ms": 0, "error": ""}
    if not host:
        result["error"] = "没有地址"
        return result
    started = time.time()
    sock = None
    try:
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.settimeout(timeout)
        # handshake：next state = 1（status）
        body = (_varint(0) + _varint(47) + _mc_string(host)
                + struct.pack(">H", int(port)) + _varint(1))
        sock.sendall(_varint(len(body)) + body)
        sock.sendall(_varint(1) + _varint(0))  # status request
        length = _read_varint(sock)
        packet = _read_exact(sock, length)
        # 跳过包 id（0），后面是一个 JSON 字符串
        idx = 0
        for i in range(5):
            v = packet[idx]
            idx += 1
            if not v & 0x80:
                break
        slen = 0
        for i in range(5):
            v = packet[idx]
            idx += 1
            slen |= (v & 0x7F) << (7 * i)
            if not v & 0x80:
                break
        data = json.loads(packet[idx:idx + slen].decode("utf-8", "replace"))
        players = data.get("players") or {}
        version = data.get("version") or {}
        result.update({
            "online": True,
            "players": int(players.get("online") or 0),
            "max_players": int(players.get("max") or 0),
            "version": str(version.get("name") or ""),
            "motd": _strip_mc_codes(_motd_plain(data.get("description"))).strip(),
            "latency_ms": int((time.time() - started) * 1000),
        })
    except Exception as e:
        result["error"] = str(e) or "连接失败"
    finally:
        try:
            if sock:
                sock.close()
        except Exception:
            pass
    return result


def status(cfg=None):
    """按当前配置探测一次，返回 (info, ping_result)。info 为 None 表示没配地址。"""
    info = load(cfg)
    if not info:
        return None, None
    return info, ping(info["host"], info["port"])


def share_text(info=None, cfg=None):
    """给玩家复制用的整段文字。"""
    info = info or load(cfg)
    if not info:
        return "公共服地址还没配置。"
    return ("OMC 公共服（不用注册任何平台）\n"
            "服务器地址：%s\n"
            "进入方式：启动器 → 联机 → 加入联机 → 加入公共服，"
            "或在 Minecraft 里「添加服务器」填上面这个地址。" % info["addr"])


def recommend_players():
    """按免费档 4核16G 给一个人数参考，写进界面提示。"""
    return {"vanilla": (15, 25), "light_mod": (6, 12), "heavy_mod": (3, 6)}
