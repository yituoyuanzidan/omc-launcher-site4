# -*- coding: utf-8 -*-
"""没有 Java 时自动下载并安装 JRE（Adoptium Temurin 官方源）。

GitHub release 直链在国内经常连不上，这里按 直连 -> gh-proxy -> ghfast 依次尝试。
装好后放到 数据目录/java/ 下，java_utils 能扫得到。
"""
import os
import shutil
import time
import zipfile

from . import http, platform_utils

_API = ("https://api.adoptium.net/v3/assets/latest/%d/hotspot"
        "?architecture=%s&image_type=jre&os=%s&vendor=eclipse")
_PROXIES = ("", "https://gh-proxy.com/", "https://ghfast.top/")


def _adoptium_os():
    if platform_utils.WINDOWS:
        return "windows"
    if platform_utils.MACOS:
        return "mac"
    return "linux"


def _adoptium_arch():
    return "x64" if platform_utils.OS_ARCH in ("x86_64", "x86") else "aarch64"


def java_root():
    return os.path.join(platform_utils.data_dir(), "java")


def _binary_in(root):
    """在解包目录里找 java 可执行文件。"""
    name = platform_utils.java_binary_name()
    direct = os.path.join(root, "bin", name)
    if os.path.isfile(direct):
        return direct
    for cur, _dirs, files in os.walk(root):
        if name in files and os.path.basename(cur) == "bin":
            return os.path.join(cur, name)
    return ""


def installed_java(major):
    """已经下载装好的 JRE（存在就直接复用，不重复下载）。"""
    root = java_root()
    if not os.path.isdir(root):
        return ""
    for name in sorted(os.listdir(root)):
        if not name.lower().startswith(("jdk%d" % major, "jre%d" % major)):
            continue
        p = _binary_in(os.path.join(root, name))
        if p:
            return p
    return ""


def latest_package(major, retries=3):
    """查 Adoptium 最新 JRE：返回 (link, filename, size)。"""
    url = _API % (major, _adoptium_arch(), _adoptium_os())
    last_err = None
    for i in range(retries):
        try:
            data = http.fetch_json(url, mirror="official", timeout=20,
                                   retries=2)
            if not data:
                raise RuntimeError("Adoptium 没返回 Java %d 的 JRE" % major)
            pkg = (data[0].get("binary") or {}).get("package") or {}
            link = pkg.get("link") or ""
            if not link:
                raise RuntimeError("Adoptium 返回里没有下载地址")
            return link, (pkg.get("name") or "java.zip"), (pkg.get("size") or None)
        except Exception as e:
            last_err = e
            if i + 1 < retries:
                time.sleep(2 + i * 2)
    raise RuntimeError("查询 Adoptium 失败：%s" % last_err)


def install_java(major=17, log=None, progress=None):
    """下载并解压 JRE，返回 java 可执行文件路径。"""
    log = log or (lambda _m: None)
    cached = installed_java(major)
    if cached:
        log("本地已有 Java %d：%s" % (major, cached))
        return cached

    link, filename, size = latest_package(major)
    root = java_root()
    os.makedirs(root, exist_ok=True)
    zip_path = os.path.join(root, filename)

    ok = False
    last_err = None
    for idx, proxy in enumerate(_PROXIES):
        url = (proxy + link) if proxy else link
        # 直连先快试一次（连不上就立刻换代理，别让用户干等）
        retries = 1 if idx == 0 else 3
        timeout = 25 if idx == 0 else 180
        try:
            log("下载 Java %d（%.1f MB）%s"
                % (major, (size or 0) / 1048576.0,
                   "（加速节点）" if proxy else "（官方直连）"))
            http.download_file(url, zip_path, mirror="official",
                               progress=progress, size=size,
                               retries=retries, timeout=timeout)
            ok = True
            break
        except Exception as e:
            last_err = e
            log("这个通道下不动，换下一个：%s" % e)
    if not ok:
        raise RuntimeError("Java 下载失败：%s" % last_err)

    log("下载完成，正在解压......")
    import time
    tmp = os.path.join(root, "_unpack_%d_%d" % (major, int(time.time())))
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(tmp)
    java = _binary_in(tmp)
    if not java:
        raise RuntimeError("解压后没找到 java 可执行文件")

    # zip 里通常带一层根目录，把那一层搬到 jdk<major> 下面
    java_home = os.path.dirname(os.path.dirname(java))
    dest = os.path.join(root, "jdk%d" % major)
    if os.path.isdir(dest):
        shutil.rmtree(dest, ignore_errors=True)
    os.replace(java_home, dest)
    java = _binary_in(dest)
    if not java:
        raise RuntimeError("搬迁后没找到 java 可执行文件")
    if not platform_utils.WINDOWS:
        try:
            os.chmod(java, 0o755)
        except OSError:
            pass
    log("Java %d 已装好：%s" % (major, java))
    return java
