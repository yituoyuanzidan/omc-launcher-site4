# -*- coding: utf-8 -*-
"""本机好友表：~/.simple_mc_launcher/friends.json"""
import json
import os
import time

FIELDS = ("uid", "name", "src", "since")


def store_path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "friends.json")


def _read():
    p = store_path()
    if not os.path.isfile(p):
        return {"v": 1, "items": []}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("items", [])
        return data
    except Exception:
        return {"v": 1, "items": []}


def _write(data):
    p = store_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def items():
    return _read().get("items") or []


def has(uid=None, name=None):
    for it in items():
        if uid and it.get("uid") == uid:
            return it
        if name and (it.get("name") or "").lower() == (name or "").lower():
            return it
    return None


def add(uid, name, src="", note="", group=""):
    uid = (uid or "").strip()
    name = (name or "").strip()
    if not name:
        return False, "名字不能空"
    if has(uid=uid, name=name):
        return False, "已经在好友列表里了"
    data = _read()
    data["items"].append({"uid": uid, "name": name, "src": src, "note": note,
                          "group": group or "",
                          "since": time.strftime("%Y-%m-%d %H:%M")})
    _write(data)
    return True, "已添加"


def update_note(uid=None, name=None, note="", group=None, alias=""):
    """改备注 / 分组 / 显示名。返回 (ok, 说明)。"""
    data = _read()
    hit = None
    for it in data.get("items") or []:
        if uid and it.get("uid") == uid:
            hit = it
            break
        if name and (it.get("name") or "").lower() == (name or "").lower():
            hit = it
            break
    if hit is None:
        return False, "好友列表里没有这个人"
    hit["note"] = note or ""
    if alias is not None:
        hit["alias"] = (alias or "").strip()
    if group is not None:
        hit["group"] = (group or "").strip()
    _write(data)
    return True, "已保存"


def groups():
    out = []
    for it in items():
        g = (it.get("group") or "").strip()
        if g and g not in out:
            out.append(g)
    return out


def label_of(it):
    """列表里显示的名字：有备注优先用备注。"""
    return (it.get("alias") or "").strip() or (it.get("name") or "")


def remove(uid=None, name=None):
    data = _read()
    keep = []
    for it in data.get("items") or []:
        if uid and it.get("uid") == uid:
            continue
        if name and (it.get("name") or "").lower() == (name or "").lower():
            continue
        keep.append(it)
    data["items"] = keep
    _write(data)


def count():
    return len(items())
