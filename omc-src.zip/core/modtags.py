# -*- coding: utf-8 -*-
"""模组标签与备注：~/.simple_mc_launcher/mod_tags.json

结构：{"v": 1, "items": {"xxx.jar": {"tags": ["必装"], "note": "说明"}}}
"""
import json
import os

DEFAULT_TAGS = ("必装", "测试", "危险", "备选")


def store_path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "mod_tags.json")


def _read():
    p = store_path()
    if not os.path.isfile(p):
        return {"v": 1, "items": {}}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("items", {})
        return data
    except Exception:
        return {"v": 1, "items": {}}


def _write(data):
    p = store_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def all_tags():
    out = list(DEFAULT_TAGS)
    for v in (_read().get("items") or {}).values():
        for t in v.get("tags") or []:
            if t and t not in out:
                out.append(t)
    return out


def get(fname):
    return (_read().get("items") or {}).get(fname) or {"tags": [], "note": ""}


def set_mod(fname, tags=None, note=None):
    if not fname:
        return False, "没有文件名"
    data = _read()
    items = data.setdefault("items", {})
    cur = items.get(fname) or {"tags": [], "note": ""}
    if tags is not None:
        cur["tags"] = [t.strip() for t in tags if t and t.strip()]
    if note is not None:
        cur["note"] = note.strip()
    if not cur.get("tags") and not cur.get("note"):
        items.pop(fname, None)
    else:
        items[fname] = cur
    _write(data)
    return True, "已保存"


def tags_of(fname):
    return list(get(fname).get("tags") or [])


def note_of(fname):
    return get(fname).get("note") or ""


def has_tag(fname, tag):
    if not tag:
        return True
    return tag in tags_of(fname)


def summary(fname):
    """列表右侧显示的一小串：[必装] 说明文字"""
    v = get(fname)
    tags = v.get("tags") or []
    note = (v.get("note") or "").strip()
    s = " ".join("[%s]" % t for t in tags)
    if note:
        s = (s + " " + note).strip()
    return s
