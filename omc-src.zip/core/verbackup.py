# -*- coding: utf-8 -*-
"""版本备份与还原：把 versions/<id> 整个目录打成带备注的 zip。

- 备份落在 <game_dir>/backups/omc-versions/ 下，不在 versions 里，
  所以版本列表不会把它当成一个能启动的版本。
- 还原时先把当前同名目录改名成 <id>_还原前-<时间戳>，再解压回去，
  这样「还原」本身也能被撤销。
"""
import json
import os
import time
import zipfile

META_NAME = "omc-backup.json"


def versions_dir(game_dir):
    return os.path.join(game_dir, "versions")


def backup_root(game_dir):
    d = os.path.join(game_dir, "backups", "omc-versions")
    os.makedirs(d, exist_ok=True)
    return d


def _stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def _dir_size_mb(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return round(total / 1048576.0, 1)


def list_versions(game_dir):
    """能备份的版本：versions 下的每个实例目录。"""
    d = versions_dir(game_dir)
    if not os.path.isdir(d):
        return []
    rows = []
    for name in sorted(os.listdir(d)):
        p = os.path.join(d, name)
        if not os.path.isdir(p):
            continue
        try:
            rows.append({"id": name, "path": p, "size_mb": _dir_size_mb(p)})
        except OSError:
            continue
    return rows


def read_meta(zip_path):
    """读出备份里的元信息；老包/损坏包退回文件名推断。"""
    meta = {}
    try:
        with zipfile.ZipFile(zip_path) as z:
            if META_NAME in z.namelist():
                meta = json.loads(z.read(META_NAME).decode("utf-8"))
    except Exception:
        meta = {}
    if not meta.get("version"):
        base = os.path.basename(zip_path)
        name = base[:-4] if base.lower().endswith(".zip") else base
        parts = name.split("-")
        meta["version"] = parts[0] if parts else name
    return meta


def make(game_dir, version_id, note="", log=None):
    """把一个版本打成 zip。返回 {path, version, note, files, size_mb, time}。"""
    log = log or (lambda _m: None)
    src = os.path.join(versions_dir(game_dir), version_id)
    if not os.path.isdir(src):
        raise RuntimeError("版本目录不存在：%s" % src)
    stamp = _stamp()
    base = "%s-%s" % (version_id, stamp)
    dst = os.path.join(backup_root(game_dir), base + ".zip")
    n = 1
    while os.path.exists(dst):
        dst = os.path.join(backup_root(game_dir), "%s-%d.zip" % (base, n))
        n += 1

    meta = {"version": version_id, "note": note or "", "time": stamp,
            "created": time.time(), "source": src}
    files = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.writestr(META_NAME, json.dumps(meta, ensure_ascii=False, indent=2))
        for root, dirs, names in os.walk(src):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for fn in names:
                fp = os.path.join(root, fn)
                rel = os.path.relpath(fp, src).replace(os.sep, "/")
                try:
                    z.write(fp, rel)
                    files += 1
                except OSError:
                    continue
    size = os.path.getsize(dst)
    log("已备份版本 %s：%d 个文件 / %.1f MB" % (version_id, files,
                                              size / 1048576.0))
    return {"path": dst, "version": version_id, "note": note or "",
            "files": files, "size_mb": round(size / 1048576.0, 1),
            "time": stamp}


def list_backups(game_dir):
    """全部版本备份，按时间倒序。"""
    root = backup_root(game_dir)
    rows = []
    try:
        names = os.listdir(root)
    except OSError:
        return rows
    for name in names:
        if not name.lower().endswith(".zip"):
            continue
        p = os.path.join(root, name)
        meta = read_meta(p)
        try:
            size_mb = round(os.path.getsize(p) / 1048576.0, 1)
            mtime = os.path.getmtime(p)
        except OSError:
            continue
        rows.append({"path": p, "version": meta.get("version") or "?",
                     "note": meta.get("note") or "",
                     "time": meta.get("time") or time.strftime(
                         "%Y%m%d-%H%M%S", time.localtime(mtime)),
                     "size_mb": size_mb, "mtime": mtime})
    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows


def verify(zip_path):
    """检查备份包能不能还原：zip 能开、里面至少有版本 json。"""
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        bad = z.testzip()
    ver = read_meta(zip_path).get("version") or ""
    has_json = any(n.lower().endswith(".json") and "/" not in n for n in names)
    return {"ok": bad is None and has_json, "entries": len(names),
            "version": ver, "bad_entry": bad}


def restore(game_dir, zip_path, log=None):
    """把备份解回 versions/<版本 id>；已存在则先改名留底。"""
    log = log or (lambda _m: None)
    if not os.path.isfile(zip_path):
        raise RuntimeError("备份包不存在：%s" % zip_path)
    info = verify(zip_path)
    if not info["ok"]:
        raise RuntimeError("备份包损坏，无法还原（%s）" % (info["bad_entry"] or "缺版本 json"))
    ver = info["version"]
    dst = os.path.join(versions_dir(game_dir), ver)
    prev = ""
    if os.path.isdir(dst):
        prev = dst + "_还原前-" + _stamp()
        os.rename(dst, prev)
    os.makedirs(versions_dir(game_dir), exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        for item in z.infolist():
            if item.filename == META_NAME:
                continue
            z.extract(item, dst)
    log("已还原版本 %s%s" % (ver, ("（旧目录留底 %s）" % os.path.basename(prev))
                             if prev else ""))
    return {"version": ver, "path": dst, "prev": prev}


def delete(zip_path):
    """删一个备份包（只删备份，不动任何版本目录）。"""
    if os.path.isfile(zip_path):
        os.remove(zip_path)
        return True
    return False
