# -*- coding: utf-8 -*-
"""模组更新检测：用 jar 的 SHA1 去 Modrinth 查对应项目，再取该项目最新版本。

只有能从 Modrinth 认出来的模组才能检测更新（自己做的或只有 CurseForge 的模组查不到），
认不出来就原样跳过，不误报。
"""
import hashlib
import json
import os

from . import http

API = "https://api.modrinth.com/v2"
UA = "OMC-Launcher/1.7"


def _post(path, payload, timeout=15):
    return http.post_json(API + path, payload, timeout=timeout,
                          mirror="official", retries=2)


def _get(path, timeout=15):
    return http.fetch_json(API + path, "official", timeout=timeout, retries=2)


def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(131072), b""):
            h.update(chunk)
    return h.hexdigest()


def check(game_dir, log=None, progress=None):
    """返回可更新列表： [{file, title, project, latest_version, url, project_id}]"""
    log = log or (lambda _m: None)
    progress = progress or (lambda _i, _n: None)
    mods_dir = os.path.join(game_dir, "mods")
    if not os.path.isdir(mods_dir):
        return []
    jars = [f for f in os.listdir(mods_dir) if f.lower().endswith(".jar")]
    if not jars:
        return []

    log("正在计算 %d 个模组的指纹......" % len(jars))
    hashes = {}
    for i, name in enumerate(jars):
        path = os.path.join(mods_dir, name)
        try:
            h = sha1_of(path)
        except Exception as e:
            log("跳过 %s：%s" % (name, e))
            continue
        hashes[h] = name
        progress(i + 1, len(jars))

    if not hashes:
        return []

    log("正在向 Modrinth 查询已装模组的版本信息......")
    try:
        payload = {"hashes": list(hashes.keys()), "algorithm": "sha1"}
        current = _post("/version_files", payload)
    except Exception as e:
        raise RuntimeError("连不上 Modrinth：%s" % e)

    if isinstance(current, dict):
        current = [v for v in current.values() if isinstance(v, dict)]

    result = []
    for h, ver in (current.items() if isinstance(current, dict) else
                   [(v.get("id", ""), v) for v in current]):
        project_id = ver.get("project_id") or ""
        if not project_id:
            continue
        # version_files 只回传匹配到的版本，没匹配上的模组不会出现在结果里
        try:
            versions = _get("/project/%s/version" % project_id)
        except Exception:
            versions = []
        if not versions:
            continue
        latest = versions[0]
        same = (latest.get("id") == ver.get("id")
                or latest.get("version_number") == ver.get("version_number"))
        if same:
            continue
        files = latest.get("files") or []
        url = ""
        for f in files:
            if f.get("primary"):
                url = f.get("url") or ""
                break
        if not url and files:
            url = files[0].get("url") or ""
        result.append({
            "file": hashes.get(h, ""),
            "project": project_id,
            "title": ver.get("name") or project_id,
            "current_version": ver.get("version_number") or "",
            "latest_version": latest.get("version_number") or "",
            "url": url,
        })

    log("检测完成：%d 个模组有更新" % len(result))
    return result
