# -*- coding: utf-8 -*-
"""主题商店：几套配色 + 按键形状的现成组合，一键换上，也能导出/导入。

设置页里已有的「主题 + 主色 + 按键」三项其实就是这三个值，
所以这里不新增机制，只是把常用组合包成预设。
"""
import json
import os
import time

from . import platform_utils

PRESETS = [
    {"id": "omc_dark", "name": "原版深色", "theme": "dark", "accent": "blue",
     "button": "round", "desc": "默认的深灰 + 蓝，最稳的一套"},
    {"id": "stone", "name": "石质深色", "theme": "dark", "accent": "green",
     "button": "round", "desc": "MC 石头底 + 草绿，和启动页最搭"},
    {"id": "amethyst", "name": "紫水晶", "theme": "dark", "accent": "violet",
     "button": "pill", "desc": "紫罗兰 + 胶囊键，偏安静"},
    {"id": "lava", "name": "熔岩", "theme": "dark", "accent": "orange",
     "button": "square", "desc": "橙红 + 方块键，像素味重"},
    {"id": "creeper", "name": "苦力怕绿", "theme": "dark", "accent": "#5FD35F",
     "button": "square", "desc": "像素绿，方角，最像 Minecraft 原生"},
    {"id": "ice", "name": "寒冰", "theme": "dark", "accent": "#22D3EE",
     "button": "pill", "desc": "青色冷调，夜间不刺眼"},
    {"id": "sakura", "name": "樱花", "theme": "dark", "accent": "pink",
     "button": "pill", "desc": "粉紫，配动漫头像"},
    {"id": "paper", "name": "纸白", "theme": "light", "accent": "blue",
     "button": "round", "desc": "浅色底 + 蓝，白天用省眼"},
    {"id": "paper_green", "name": "浅色森林", "theme": "light", "accent": "green",
     "button": "round", "desc": "浅色底 + 绿，配森林壁纸"},
    {"id": "mono", "name": "极简描边", "theme": "dark", "accent": "gold",
     "button": "outline", "desc": "透明键 + 金边，干净"},
]


def presets():
    return [dict(p) for p in PRESETS]


def get(preset_id):
    for p in PRESETS:
        if p["id"] == preset_id:
            return dict(p)
    return None


def current(cfg):
    """读当前配置成预设的形状（不是预设里的就返回 None）。"""
    cur = {"theme": cfg.get("theme") or "dark",
           "accent": cfg.get("ui_accent") or "blue",
           "button": cfg.get("ui_button") or "round"}
    for p in PRESETS:
        if (p["theme"], p["accent"].lower(), p["button"]) == (
                cur["theme"], cur["accent"].lower(), cur["button"]):
            return dict(p)
    return None


def apply(cfg, preset_id):
    p = get(preset_id)
    if not p:
        raise RuntimeError("没有这个主题：%s" % preset_id)
    cfg.set("theme", p["theme"])
    cfg.set("ui_accent", p["accent"])
    cfg.set("ui_button", p["button"])
    cfg.set("ui_preset", p["id"])
    cfg.save()
    return p


def export_current(cfg):
    """导出当前外观成一段 json 文本，发给别人就能导入。"""
    return json.dumps({"omc_theme": 1,
                       "name": cfg.get("ui_preset") or "自定义",
                       "theme": cfg.get("theme") or "dark",
                       "accent": cfg.get("ui_accent") or "blue",
                       "button": cfg.get("ui_button") or "round",
                       "exported": time.strftime("%Y-%m-%d %H:%M:%S")},
                      ensure_ascii=False, indent=2)


def import_text(text):
    """解析一段主题 json，返回 {"theme","accent","button","name"}。"""
    try:
        data = json.loads(text)
    except Exception as e:
        raise ValueError("不是有效的主题文件（%s）" % e)
    if not isinstance(data, dict):
        raise ValueError("主题文件格式不对")
    theme = str(data.get("theme") or "dark").lower()
    if theme not in ("dark", "light"):
        theme = "dark"
    accent = str(data.get("accent") or "blue").strip()
    if accent and not accent.startswith("#") and accent not in (
            "blue", "green", "violet", "orange", "pink", "gold"):
        accent = "blue"
    button = str(data.get("button") or "round").lower()
    if button not in ("round", "square", "pill", "outline"):
        button = "round"
    return {"theme": theme, "accent": accent, "button": button,
            "name": str(data.get("name") or "导入的主题")}


def apply_custom(cfg, theme, accent, button, name=""):
    cfg.set("theme", theme)
    cfg.set("ui_accent", accent)
    cfg.set("ui_button", button)
    cfg.set("ui_preset", name or "自定义")
    cfg.save()
    return {"theme": theme, "accent": accent, "button": button, "name": name}


def export_file(cfg, path):
    text = export_current(cfg)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path


def import_file(path, cfg):
    with open(path, "r", encoding="utf-8") as f:
        data = import_text(f.read())
    apply_custom(cfg, data["theme"], data["accent"], data["button"], data["name"])
    return data


def themes_dir():
    d = os.path.join(platform_utils.data_dir(), "themes")
    os.makedirs(d, exist_ok=True)
    return d
