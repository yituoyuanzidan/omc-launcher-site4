# -*- coding: utf-8 -*-
"""第三方登录（Yggdrasil / authlib-injector）：外置账号认证与注入器管理。"""
import hashlib
import json
import os
import urllib.error
import urllib.request

from . import http
from .config import app_dir

# 注入器镜像（GitHub 被墙时这个官方镜像可访问）
INJECTOR_META = "https://authlib-injector.yushi.moe/artifact/latest.json"


def _raw(api_url):
    return (api_url or "").strip().rstrip("/")


def _base(api_url):
    """所有接口地址入口都过一遍 normalize，手填裸地址也能用。"""
    return normalize_api(_raw(api_url))


# 只填域名时按各站惯例补齐；点名的站给准确端点
_DOMAIN_HINTS = {
    "littleskin.cn": "https://littleskin.cn/api/yggdrasil",
    "mcskin.cn": "https://mcskin.cn/api/yggdrasil",
    "mcskin.com.cn": "https://mcskin.cn/api/yggdrasil",
    "ely.by": "https://account.ely.by/api/authlib-injector",
}

# 自建站（本机 / 局域网 IP）默认没证书，一律按 http 处理
_LOCAL_HINTS = ("127.0.0.1", "localhost", "0.0.0.0", "192.168.", "10.",
                "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
                "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
                "172.26.", "172.27.", "172.28.", "172.29.", "172.30.",
                "172.31.")


def _is_local(host):
    h = host.split(":")[0]
    if h in ("127.0.0.1", "localhost", "0.0.0.0"):
        return True
    return any(h.startswith(p) for p in _LOCAL_HINTS if p not in
               ("127.0.0.1", "localhost", "0.0.0.0"))


def normalize_api(api_url):
    """把用户随手填的地址整理成可用的 Yggdrasil API 根。

    支持：带 https 的完整地址、只有域名（littleskin.cn / ely.by …）、
    自建站只写域名（会补 /api/yggdrasil）。自建站一律显式写 http:// 时保留 http，
    方便本地调试（http://127.0.0.1:8080/api/yggdrasil）。

    本机 / 局域网 IP（127.0.0.1、192.168.x、10.x …）没证书，默认按 http 走，
    免得手填 127.0.0.1:8080 时被强行补成 https 导致连不上。
    """
    u = _raw(api_url)
    if not u:
        return ""
    explicit_http = u.lower().startswith("http://")
    has_scheme = u.startswith("http://") or u.startswith("https://")
    if not has_scheme:
        rest0 = u.split("/")[0].lower()
        u = ("http://" if _is_local(rest0) else "https://") + u
    rest = u.split("://", 1)[1]
    host = rest.split("/")[0].lower()
    bare = "/" not in rest
    if bare:
        if host in _DOMAIN_HINTS and not explicit_http:
            return _DOMAIN_HINTS[host]
        return u + "/api/yggdrasil"
    if host in _DOMAIN_HINTS and "api/yggdrasil" not in u and \
            "authlib-injector" not in u:
        return _DOMAIN_HINTS[host]
    return u


#: 这些公共皮肤站没有 /authserver/register 接口，只能在网页上注册
PUBLIC_SITES = {
    "littleskin.cn": "https://littleskin.cn/auth/register",
    "mcskin.cn": "https://mcskin.cn/",
    "mcskin.com.cn": "https://mcskin.cn/",
    "ely.by": "https://account.ely.by/register",
}


def public_register_url(api_url):
    """如果这个地址是公共皮肤站，返回它的网页注册地址；自建站返回空。"""
    u = _raw(api_url).lower()
    if not u:
        return ""
    has_scheme = u.startswith("http://") or u.startswith("https://")
    host = u.split("://", 1)[1].split("/")[0] if has_scheme else u.split("/")[0]
    host = host.split(":")[0]
    for key, site in PUBLIC_SITES.items():
        if host == key or host.endswith("." + key):
            return site
    return ""


def register(api_url, email, password, username=""):
    """在自己搭的（或别人搭的）Yggdrasil 服务器上注册账号。

    返回 (ok, 说明)。服务器要支持 /authserver/register 这个非标准扩展端点
    （本工程附带的 thirdserver/omc_auth_server.py 就有）。
    """
    ok, msg, _acct = register_full(api_url, email, password, username)
    return ok, msg


def register_full(api_url, email, password, username=""):
    """注册，返回 (ok, 说明, 账号信息)。

    服务端如果顺便给了 accessToken（本工程自带的那个会给），直接返回可用的
    账号信息，客户端不用再补一次登录请求 —— 省一次往返，注册完立刻上线。
    """
    url = _base(api_url) + "/authserver/register"
    payload = {"email": email, "password": password,
               "username": username or email}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, method="POST",
        headers={"User-Agent": http.USER_AGENT,
                 "Content-Type": "application/json",
                 "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=25,
                                    context=http.ctx_for(url)) as resp:
            raw = resp.read().decode("utf-8", "replace")
        acct = None
        try:
            j = json.loads(raw)
            if j.get("accessToken") and j.get("uuid"):
                acct = {
                    "api_url": _base(api_url),
                    "name": j.get("name") or j.get("username") or username,
                    "uuid": j["uuid"],
                    "mc_token": j["accessToken"],
                }
        except Exception:
            acct = None
        return True, "注册成功，现在点「登录并绑定」就行", acct
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:
            pass
        msg = ""
        try:
            j = json.loads(body)
            msg = j.get("errorMessage") or j.get("message") or ""
        except Exception:
            msg = body[:120]
        if e.code == 404:
            msg = "这个服务器没开注册接口（/authserver/register）"
        return False, "注册没成功：%s" % (msg or ("HTTP %s" % e.code)), None
    except Exception as e:
        return False, "连不上服务器：%s" % e, None


def authserver_reachable(api_url):
    """粗略判断这个地址是不是真的 Yggdrasil API 根。"""
    try:
        data = http.fetch_json(_base(api_url) + "/", "official", 10, retries=1)
        meta = data.get("meta") or {}
        return True, meta.get("serverName") or _base(api_url)
    except Exception as e:
        return False, str(e)


def probe_api(api_url, timeout=8):
    """连接诊断：把「连不上」翻译成人能看懂的原因（防火墙 / 端口 / 路径 / 证书）。

    返回 (ok, 说明)。ok=True 时说明里带服务器自报的名字。
    """
    import socket
    base = _base(api_url)
    try:
        data = http.fetch_json(base + "/", "official", timeout, retries=1)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False, ("地址能连上，但这里没有 Yggdrasil 接口：%s\n"
                           "路径一般要是 http(s)://域名/api/yggdrasil" % base)
        if e.code in (403, 401):
            return False, ("服务器返回 HTTP %s（被挡了）：可能是防火墙/WAF 拦了，"
                           "或这个地址要登录才能看。" % e.code)
        return False, "服务器返回 HTTP %s，地址可能不对。" % e.code
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", e)
        text = str(reason)
        low = text.lower()
        if isinstance(reason, ConnectionRefusedError) or "refused" in low:
            return False, ("连接被拒绝：这个 IP/端口上没有程序在监听。\n"
                           "先确认服务器脚本在跑，端口号一致（默认 8080）。")
        if isinstance(reason, (socket.timeout, TimeoutError)) or "timed out" in low:
            return False, ("连接超时：多半是被防火墙或云服务器安全组拦了。\n"
                           "放行 TCP 端口；自建服务器脚本启动时会尝试自动加 Windows 防火墙规则"
                           "（需要管理员权限），云服务器还要在安全组里放行同一个端口。")
        if "certificate" in low or "ssl" in low:
            return False, ("HTTPS 证书有问题：%s\n"
                           "自签证书要换正式证书，或先用 http 在本机测。" % text)
        if "name or service not known" in low or "getaddrinfo" in low:
            return False, "域名解析不了：检查网址拼写，或换 IP 直接试。"
        return False, "连不上：%s" % text
    except (socket.timeout, TimeoutError):
        return False, ("连接超时：多半是被防火墙或云服务器安全组拦了。\n"
                       "放行 TCP 端口后再试。")
    except Exception as e:
        return False, "连不上：%s" % e
    meta = (data or {}).get("meta") or {}
    name = meta.get("serverName") or base
    return True, ("连上了：%s\n地址：%s" % (name, base))


def injector_dir():
    p = os.path.join(app_dir(), "authlib-injector")
    os.makedirs(p, exist_ok=True)
    return p


def injector_path():
    return os.path.join(injector_dir(), "authlib-injector.jar")


def server_meta(api_url):
    """读取服务器元信息，返回服务端名称等（用于校验地址是否有效）。"""
    data = http.fetch_json(_base(api_url) + "/", "official", 20)
    meta = data.get("meta") or {}
    return meta.get("serverName") or _base(api_url), data


def authenticate(api_url, username, password):
    """走 Yggdrasil authserver 认证，返回启动器账号字典。"""
    payload = {
        "agent": {"name": "Minecraft", "version": 1},
        "username": username,
        "password": password,
        "requestUser": True,
    }
    data = http.post_json(
        _base(api_url) + "/authserver/authenticate",
        payload, timeout=25)
    profile = data.get("selectedProfile") or {}
    if not profile.get("id"):
        raise RuntimeError("服务器没有返回角色资料")
    return {
        "type": "third_party",
        "api_url": _base(api_url),
        "name": profile.get("name") or username,
        "uuid": profile["id"],
        "mc_token": data.get("accessToken", "0"),
    }


def ensure_injector(log=None, progress_cb=None):
    """确保 authlib-injector jar 已下载并校验，返回其路径。"""
    say = log or (lambda m: None)
    dest = injector_path()
    meta = http.fetch_json(INJECTOR_META, "official", 20)
    url = meta["download_url"]
    expect_sha = (meta.get("checksums") or {}).get("sha256")
    need = True
    if os.path.exists(dest) and expect_sha:
        with open(dest, "rb") as f:
            need = hashlib.sha256(f.read()).hexdigest() != expect_sha
    if need:
        say("正在下载 authlib-injector...")
        http.download_file(url, dest, "official", progress=progress_cb)
        if expect_sha:
            with open(dest, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest()
            if actual != expect_sha:
                raise RuntimeError("authlib-injector 校验失败")
    return dest
