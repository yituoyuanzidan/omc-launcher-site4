# -*- coding: utf-8 -*-
"""模组冲突检测：只看 jar 里的元数据，不启动游戏也能提前发现装不上的组合。

支持三种主流格式：
- Fabric / Quilt：fabric.mod.json / quilt.mod.json
- Forge / NeoForge：META-INF/mods.toml（粗解析，够定位 modId 和依赖）

能查出来的问题：
1. 同一个 modId 装了多个版本（游戏里必然崩）
2. 缺前置（depends 里的 modId 没有任何 jar 提供）
3. 依赖的 Minecraft 版本对不上
4. 同名重复文件（复制粘贴出来的 xxx (1).jar）
"""
import json
import os
import re
import zipfile

# 加载器自己提供的虚拟 id，不该被当成「缺前置」
_VIRTUAL = {"minecraft", "java", "fabricloader", "fabric", "quilt_loader",
            "quiltloader", "forge", "neoforge", "fml", "mcp", "ommc"}


def _norm(spec):
    """把 maven 区间 [1.20,1.21) 这种写法翻成 >=1.20 <1.21。"""
    spec = (spec or "").strip()
    if not spec:
        return ""
    m = re.match(r"[\[\(]([^,]+)?,?([^\]\)]+)?[\]\)]", spec)
    if not m:
        return spec
    lo, hi = (m.group(1) or "").strip(), (m.group(2) or "").strip()
    left_open = spec.startswith("[")
    right_closed = spec.endswith("]")
    parts = []
    if lo:
        parts.append((">=" if left_open else ">") + lo)
    if hi:
        parts.append(("<=" if right_closed else "<") + hi)
    return " ".join(parts)


def _ver_key(v):
    """版本号切成可比较的元组，'1.20.1' -> (1,20,1)。"""
    v = (v or "").strip().lower()
    v = re.split(r"[-+]", v)[0]
    out = []
    for piece in re.split(r"[._]", v):
        if piece.isdigit():
            out.append(int(piece))
        else:
            num = re.match(r"(\d+)", piece)
            out.append(int(num.group(1)) if num else 0)
    return tuple(out)


def _cmp(a, b):
    ka, kb = _ver_key(a), _ver_key(b)
    n = max(len(ka), len(kb))
    ka = ka + (0,) * (n - len(ka))
    kb = kb + (0,) * (n - len(kb))
    return (ka > kb) - (ka < kb)


def fits(spec, ver):
    """判断 ver 是否满足 spec。支持 >= <= > < = ~ ^ *、空格 AND、| OR。"""
    spec = _norm(spec)
    if not spec or spec in ("*", "any", "x"):
        return True
    if not ver:
        return True
    for branch in spec.split("|"):
        branch = branch.strip()
        if not branch:
            continue
        ok = True
        for token in branch.split():
            token = token.strip()
            if not token or token == "*":
                continue
            m = re.match(r"(>=|<=|>|<|=|~|^)?\s*(\S+)", token)
            if not m:
                continue
            op, ref = m.group(1) or "=", m.group(2)
            if ref.endswith(".x"):
                base = ref[:-2]
                if _ver_key(ver)[:len(_ver_key(base))] != _ver_key(base):
                    ok = False
                    break
                continue
            c = _cmp(ver, ref)
            if op == ">=" and c < 0:
                ok = False
            elif op == "<=" and c > 0:
                ok = False
            elif op == ">" and c <= 0:
                ok = False
            elif op == "<" and c >= 0:
                ok = False
            elif op == "=" and c != 0:
                ok = False
            elif op == "~":
                # ~1.20 表示 1.20.x
                k = _ver_key(ref)
                if _cmp(ver, ref) < 0 or _ver_key(ver)[:len(k)] != k:
                    ok = False
            elif op == "^":
                k = _ver_key(ref)
                if _cmp(ver, ref) < 0 or (k and _ver_key(ver)[0] != k[0]):
                    ok = False
            if not ok:
                break
        if ok:
            return True
    return False


def _read_fabric(zf):
    for name in ("fabric.mod.json", "quilt.mod.json"):
        if name not in zf.namelist():
            continue
        try:
            data = json.loads(zf.read(name).decode("utf-8", "replace"))
        except Exception:
            continue
        if name == "quilt.mod.json":
            loader = data.get("quilt_loader") or {}
            mid = loader.get("id")
            mver = loader.get("version")
            deps = {}
            for d in (loader.get("depends") or []):
                if isinstance(d, dict) and d.get("id"):
                    deps[d["id"]] = d.get("versions") or ""
        else:
            mid = data.get("id")
            mver = data.get("version")
            deps = dict(data.get("depends") or {})
        deps = {
            k: (v if isinstance(v, str) else
                (v[0] if isinstance(v, list) and v else ""))
            for k, v in deps.items()
        }
        return {"id": (mid or "").strip(), "version": str(mver or "").strip(),
                "name": (data.get("name") or mid or "").strip(),
                "depends": deps, "loader": "fabric"}
    return None


def _read_forge(zf):
    if "META-INF/mods.toml" not in zf.namelist():
        return None
    try:
        text = zf.read("META-INF/mods.toml").decode("utf-8", "replace")
    except Exception:
        return None
    mid = ""
    mver = ""
    block = re.search(r"\[\[mods\]\](.*?)(?=\n\[|$)", text, re.S)
    if block:
        body = block.group(1)
        m = re.search(r'modId\s*=\s*"([^"]+)"', body)
        if m:
            mid = m.group(1)
        m = re.search(r'version\s*=\s*"([^"]+)"', body)
        if m:
            mver = m.group(1)
        m = re.search(r'displayName\s*=\s*"([^"]+)"', body)
    deps = {}
    for dm in re.finditer(r"\[\[dependencies\]\]", text):
        pass
    # 依赖段：[[dependencies.<主 modid>]] 下面 modId/versionRange/mandatory
    for dm in re.finditer(
            r'\[\[dependencies[^\]]*\]\](.*?)(?=\n\[\[|\Z)', text, re.S):
        body = dm.group(1)
        m = re.search(r'modId\s*=\s*"([^"]+)"', body)
        if not m:
            continue
        dep_id = m.group(1)
        rng = ""
        m = re.search(r'versionRange\s*=\s*"([^"]*)"', body)
        if m:
            rng = m.group(1)
        mand = re.search(r'mandatory\s*=\s*(true|false)', body)
        if mand and mand.group(1) == "false":
            continue
        deps[dep_id] = rng
    return {"id": mid.strip(), "version": mver.strip(), "name": mid.strip(),
            "depends": deps, "loader": "forge"}


def read_info(jar_path):
    """从 jar 里抠出 modId / 版本 / 依赖；不是模组返回 None。"""
    try:
        with zipfile.ZipFile(jar_path) as zf:
            info = _read_fabric(zf) or _read_forge(zf)
    except (zipfile.BadZipFile, OSError):
        return None
    if not info or not info.get("id"):
        return None
    info["file"] = os.path.basename(jar_path)
    info["path"] = jar_path
    try:
        info["size_mb"] = round(os.path.getsize(jar_path) / 1048576.0, 2)
    except OSError:
        info["size_mb"] = 0.0
    return info


def scan(game_dir, mc_version="", log=None):
    """扫 mods 目录，返回 {mods, issues}。

    issues 每条：{level(error/warn), kind, title, detail, files}
    """
    log = log or (lambda _m: None)
    mods_dir = os.path.join(game_dir, "mods")
    mods = []
    issues = []
    if not os.path.isdir(mods_dir):
        return {"mods": [], "issues": [], "mods_dir": mods_dir, "count": 0}

    payloads = []
    for name in sorted(os.listdir(mods_dir)):
        if not name.lower().endswith(".jar"):
            continue
        p = os.path.join(mods_dir, name)
        if not os.path.isfile(p):
            continue
        info = read_info(p)
        payloads.append(info or {"file": name, "path": p, "id": "",
                                 "version": "", "name": name,
                                 "depends": {}, "loader": "?"})
    by_id = {}
    for m in payloads:
        if m.get("id"):
            by_id.setdefault(m["id"], []).append(m)

    for mid, group in by_id.items():
        if len(group) > 1:
            issues.append({
                "level": "error", "kind": "duplicate",
                "title": "同一个模组装了 %d 个版本" % len(group),
                "detail": "modId=%s，版本 %s。游戏加载时只会认一个，"
                          "另一个必然报错，留最新那个就行。" % (
                              mid, " / ".join(g.get("version") or "?" for g in group)),
                "files": [g["file"] for g in group]})

    for m in payloads:
        for dep_id, spec in (m.get("depends") or {}).items():
            if dep_id in _VIRTUAL:
                if dep_id == "minecraft" and mc_version and spec and \
                        not fits(spec, mc_version):
                    issues.append({
                        "level": "error", "kind": "mc-mismatch",
                        "title": "%s 不支持当前 MC 版本" % m["file"],
                        "detail": "它要求 Minecraft %s，你这个实例是 %s。" % (
                            spec, mc_version),
                        "files": [m["file"]]})
                continue
            if dep_id not in by_id:
                issues.append({
                    "level": "error", "kind": "missing-dep",
                    "title": "%s 缺前置 %s" % (m["file"], dep_id),
                    "detail": "它依赖 %s%s，mods 目录里没有这个模组。"
                              "装上对应前置再启动。" % (
                                  dep_id, ("（需要 %s）" % spec) if spec else ""),
                    "files": [m["file"]]})
            else:
                if spec:
                    have = by_id[dep_id][0].get("version") or ""
                    if have and not fits(spec, have):
                        issues.append({
                            "level": "warn", "kind": "dep-version",
                            "title": "%s 要的 %s 版本对不上" % (m["file"], dep_id),
                            "detail": "要求 %s，实际装的是 %s。" % (spec, have),
                            "files": [m["file"]]})

    # 文件名里的 (1) / - 副本 这类重复
    norm = {}
    for m in payloads:
        base = re.sub(r"(?: - 副本)?(?: \(\d+\))?\.jar$", "", m["file"],
                      flags=re.I).lower()
        norm.setdefault(base, []).append(m["file"])
    for base, files in norm.items():
        if len(files) > 1:
            issues.append({
                "level": "warn", "kind": "dup-file",
                "title": "疑似重复文件 %d 个" % len(files),
                "detail": "名字去掉 (1)/副本 之后是同一个：%s" % " / ".join(files),
                "files": files})

    errors = sum(1 for i in issues if i["level"] == "error")
    log("模组扫描完成：%d 个 jar，%d 条问题（%d 条会直接导致启动失败）"
        % (len(payloads), len(issues), errors))
    return {"mods": payloads, "issues": issues, "mods_dir": mods_dir,
            "count": len(payloads), "errors": errors}
