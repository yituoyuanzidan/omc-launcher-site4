# -*- coding: utf-8 -*-
"""启动网易版《我的世界》（中国版）

这里只做一件事：**找到用户自己安装的网易版官方启动器，然后把它启动起来**。

为什么只做这一步：
  - 网易版的登录、账号、实名、版本下载全部在官方启动器里完成，我们没有、
    也不该有它的登录接口；自己拼一个"登录"出来既有账号风险，也等于伪造
    客户端行为。
  - 所以这里不写网易版目录里的任何文件、不注入、不改内存、不传任何登录
    参数，只是 CreateProcess 一下它的 MCLauncher.exe。这样对网易的反作弊
    （易盾/网易云盾）来说，OMC 就是一个"快捷方式"，看不到任何异常注入，
    不会被当成外挂。

对外接口（和 core/bedrock.py 保持一致）：
    list_installed() -> [{"label":..., "path":...}]
    launch(item) -> (ok, msg)
    open_site() -> bool
"""

import os
import subprocess
import sys

DISPLAY = "网易版《我的世界》"
SITE = "https://mc.163.com/"

# 常见安装位置。网易版默认装在 Program Files (x86)，也有用户改到别的盘。
_COMMON = [
    r"C:\Program Files (x86)\Netease\MCLauncher\MCLauncher.exe",
    r"C:\Program Files\Netease\MCLauncher\MCLauncher.exe",
    r"C:\Program Files (x86)\Netease\MCLauncher\MCLauncher3.exe",
    r"C:\Program Files (x86)\Netease\MCLauncher\x64\MCLauncher.exe",
    r"C:\Program Files (x86)\Netease\MCLauncher\bin\MCLauncher.exe",
    r"D:\Program Files (x86)\Netease\MCLauncher\MCLauncher.exe",
    r"D:\Netease\MCLauncher\MCLauncher.exe",
    r"E:\Netease\MCLauncher\MCLauncher.exe",
]
_PF_ROOTS = [
    r"C:\Program Files (x86)\Netease",
    r"C:\Program Files\Netease",
]
_EXE_NAMES = ("mcLauncher.exe", "mcLauncher3.exe")


def _looks_like_netease_mc(path):
    """目录里有没有启动器本体，顺便确认不是网易云音乐之类的。"""
    d = path if os.path.isdir(path) else os.path.dirname(path)
    try:
        for n in os.listdir(d):
            if n.lower() in _EXE_NAMES:
                return os.path.join(d, n)
    except Exception:
        pass
    return ""


def _scan_tree(root, depth=3):
    """在 Program Files 的 Netease 目录下浅扫几层，找启动器 exe。"""
    hits = []
    base = root.count(os.sep)
    for cur, dirs, files in os.walk(root):
        if cur.count(os.sep) - base > depth:
            dirs[:] = []
            continue
        for f in files:
            if f.lower() in _EXE_NAMES:
                hits.append(os.path.join(cur, f))
    return hits


def _from_registry():
    """扫卸载登记表，网易版注册名一般带「我的世界」或 Netease。"""
    hits = []
    try:
        import winreg
    except Exception:
        return hits
    roots = [
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER,
         r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    for hive, sub in roots:
        try:
            key = winreg.OpenKey(hive, sub)
        except Exception:
            continue
        n = 0
        try:
            n = winreg.QueryInfoKey(key)[0]
        except Exception:
            pass
        for i in range(n):
            try:
                name = winreg.EnumKey(key, i)
                k2 = winreg.OpenKey(key, name)
                dn = ""
                loc = ""
                pub = ""
                for j in range(winreg.QueryInfoKey(k2)[1]):
                    vn, vv, _t = winreg.EnumValue(k2, j)
                    if vn == "DisplayName":
                        dn = str(vv)
                    elif vn in ("InstallLocation", "DisplayIcon"):
                        loc = str(vv).strip('"').split(",")[0]
                    elif vn == "Publisher":
                        pub = str(vv)
                winreg.CloseKey(k2)
                if not dn:
                    continue
                low = dn.lower()
                if "网易" not in dn and "netease" not in (pub + dn).lower():
                    continue
                if ("我的世界" not in dn and "minecraft" not in low
                        and "mc" not in name.lower()):
                    continue
                if loc and os.path.isdir(loc):
                    exe = _looks_like_netease_mc(loc)
                    if exe:
                        hits.append(exe)
            except Exception:
                continue
        try:
            winreg.CloseKey(key)
        except Exception:
            pass
    return hits


def list_installed(saved=""):
    """返回所有找到的网易版启动器。saved 是用户上次手动指过的路径。"""
    found = []
    if saved and os.path.isfile(saved):
        found.append(saved)
    for p in _COMMON:
        if os.path.isfile(p):
            found.append(p)
    for root in _PF_ROOTS:
        if os.path.isdir(root):
            for p in _scan_tree(root):
                found.append(p)
    for p in _from_registry():
        found.append(p)
    # 去重 + 过滤掉明显不是的
    uniq = []
    seen = set()
    for p in found:
        try:
            key = os.path.normcase(os.path.abspath(p))
        except Exception:
            continue
        if key in seen:
            continue
        d = os.path.dirname(key)
        if "netease" not in key and "网易" not in p:
            continue
        if "cloudmusic" in key or "网易云音乐" in p:
            continue
        seen.add(key)
        label = "%s  ·  %s" % (os.path.basename(p), os.path.dirname(p))
        uniq.append({"label": label, "path": p})
    return uniq


def launch(item):
    """只把官方启动器启动起来，不带参数、不设注入、不改它的目录。"""
    path = (item or {}).get("path") or ""
    if not path or not os.path.isfile(path):
        return False, "找不到网易版启动器：%s" % (path or "(空)")
    try:
        kwargs = {"cwd": os.path.dirname(path), "close_fds": True}
        if sys.platform == "win32":
            kwargs["creationflags"] = 0x00000008  # DETACHED_PROCESS，别挂在 OMC 上
        subprocess.Popen([path], **kwargs)
        return True, "已启动网易版官方启动器：%s（登录和下载都在它自己的界面里，OMC 没有碰它任何文件）" % path
    except Exception as e:
        return False, "启动失败：%r" % (e,)


def open_site():
    try:
        os.startfile(SITE)
        return True
    except Exception:
        try:
            subprocess.Popen(["cmd", "/c", "start", "", SITE])
            return True
        except Exception:
            return False
