# -*- coding: utf-8 -*-
"""让选中的皮肤真正进游戏：写 CustomSkinLoader 本地皮肤 + 按需装模组。

离线账号的皮肤在原版游戏里根本不会被读取，必须靠 CustomSkinLoader（本地皮肤模式）
或正版登录，启动器这边能做的就是把它装好并写好配置。
"""
import json
import os

from . import modrinth, skinlib

FABRIC_HINTS = ("fabric-loader", "net.fabricmc")
QUILT_HINTS = ("org.quiltmc", "quilt-loader")
FORGE_HINTS = ("net.minecraftforge", "forge-")
NEOFORGE_HINTS = ("net.neoforged", "neoforge")


def detect_loader(game_dir, version_id):
    """从版本 json 的 libraries 猜加载器，返回 fabric/forge/neoforge/quilt 或空串。"""
    if not version_id:
        return ""
    path = os.path.join(game_dir, "versions", version_id, version_id + ".json")
    if not os.path.isfile(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return ""
    names = []
    for lib in data.get("libraries") or []:
        n = (lib.get("name") or "").lower()
        if n:
            names.append(n)
    blob = " ".join(names)
    if any(h in blob for h in NEOFORGE_HINTS):
        return "neoforge"
    if any(h in blob for h in FABRIC_HINTS):
        return "fabric"
    if any(h in blob for h in QUILT_HINTS):
        return "quilt"
    if any(h in blob for h in FORGE_HINTS):
        return "forge"
    return ""


def mc_version_of(game_dir, version_id):
    path = os.path.join(game_dir, "versions", version_id, version_id + ".json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        v = data.get("id") or ""
        if "inheritsFrom" in data and not v:
            v = data["inheritsFrom"]
        return v or version_id
    except Exception:
        return version_id


def install_csl(game_dir, version_id, log=None, progress=None):
    """从 Modrinth 装一个 CustomSkinLoader 到 mods，返回落地路径或空串。"""
    loader = detect_loader(game_dir, version_id)
    if not loader:
        if log:
            log("这个版本看起来是原版（没有加载器），装不了皮肤模组")
        return ""
    mcver = mc_version_of(game_dir, version_id)
    try:
        hits, _ = modrinth.search("mod", query="CustomSkinLoader", limit=10)
    except Exception as e:
        if log:
            log("查 CustomSkinLoader 失败：%s" % e)
        return ""
    project = ""
    for h in hits or []:
        slug = (h.get("slug") or "").lower()
        title = (h.get("title") or "").lower()
        if slug == "customskinloader" or "customskinloader" in title.replace(" ", ""):
            project = h.get("project_id") or slug
            break
    if not project:
        if log:
            log("Modrinth 上没找到 CustomSkinLoader")
        return ""
    try:
        versions = modrinth.project_versions(project, mcver, loader)
    except Exception:
        versions = []
    if not versions:
        try:
            versions = modrinth.project_versions(project, None, loader)
        except Exception:
            versions = []
    jar = None
    for v in versions or []:
        f = modrinth.pick_file(v)
        if f and (f.get("filename") or "").lower().endswith(".jar"):
            jar = f
            break
    if not jar:
        if log:
            log("CustomSkinLoader 没有适配 %s/%s 的文件" % (mcver, loader))
        return ""
    dest_dir = os.path.join(game_dir, "mods")
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, jar["filename"])
    try:
        from . import http
        http.download_file(jar["url"], dest, "official", progress=progress,
                           size=jar.get("size"),
                           sha1=(jar.get("hashes") or {}).get("sha1"))
    except Exception as e:
        if log:
            log("下载 CustomSkinLoader 失败：%s" % e)
        return ""
    if log:
        log("已安装皮肤模组：%s" % jar["filename"])
    return dest


def apply(game_dir, version_id, player_name, skin_path, cape_path="",
          log=None, auto_install=True):
    """把皮肤应用到某个版本。返回 dict：{ok, need_mod, messages}"""
    msgs = []
    need_mod = False
    written = skinlib.write_local_skin(game_dir, player_name, skin_path, cape_path)
    conf = skinlib.write_csl_config(game_dir)
    if not written:
        msgs.append("皮肤文件没写进去，检查一下游戏目录是否可写")
        return {"ok": False, "need_mod": need_mod, "messages": msgs}
    msgs.append("皮肤已写入 CustomSkinLoader 本地目录")
    if conf:
        msgs.append("CustomSkinLoader 配置已更新")
    if not skinlib.has_local_skin_mod(game_dir):
        need_mod = True
        msgs.append("还没装 CustomSkinLoader 模组，别人看不到你的皮肤")
        if auto_install:
            got = install_csl(game_dir, version_id, log=log)
            if got:
                need_mod = False
                msgs.append("已自动装上 CustomSkinLoader")
            else:
                msgs.append("自动安装没成功，可以在「模组」页手动装 CustomSkinLoader")
    if log:
        for m in msgs:
            log(m)
    return {"ok": True, "need_mod": need_mod, "messages": msgs}
