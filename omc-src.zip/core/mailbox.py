# -*- coding: utf-8 -*-
"""启动器内邮箱：分类收信，每次版本更新自动收到一封「更新内容」。

存在 ~/.simple_mc_launcher/mailbox.jsonl（一行一封），和反馈收件箱互不影响。
想真的发到外部邮箱，在配置里填 smtp 一段即可（没填就只在这里留着）。
"""
import json
import os
import smtplib
import time
import uuid
from email.header import Header
from email.mime.text import MIMEText
from email.utils import formataddr

KINDS = [("update", "更新内容"), ("notice", "公告"), ("system", "系统")]


def kind_label(kind):
    for k, label in KINDS:
        if k == kind:
            return label
    return "其他"


def mail_dir():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def path():
    return os.path.join(mail_dir(), "mailbox.jsonl")


def load(kind=None):
    p = path()
    rows = []
    if not os.path.isfile(p):
        return rows
    try:
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except OSError:
        return rows
    rows.sort(key=lambda r: (r.get("time") or "", r.get("seq") or 0), reverse=True)
    if kind and kind != "all":
        rows = [r for r in rows if r.get("kind") == kind]
    return rows


def _write_all(rows):
    p = path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(tmp, p)


def add(kind, subject, body, meta=None, dedupe_key=""):
    """写一封邮件；dedupe_key 相同且已存在就跳过，返回 (是否新增, 邮件)。"""
    rows = load()
    if dedupe_key:
        for r in rows:
            if r.get("key") == dedupe_key:
                return False, r
    mail = {
        "id": uuid.uuid4().hex[:12],
        "seq": max([r.get("seq") or 0 for r in rows] or [0]) + 1,
        "kind": kind,
        "subject": subject,
        "body": body,
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "read": False,
        "key": dedupe_key,
        "meta": meta or {},
    }
    with open(path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(mail, ensure_ascii=False) + "\n")
    return True, mail


def mark_read(mail_id):
    rows = load()
    changed = False
    for r in rows:
        if r.get("id") == mail_id and not r.get("read"):
            r["read"] = True
            changed = True
    if changed:
        _write_all(rows)
    return changed


def mark_all_read():
    rows = load()
    n = 0
    for r in rows:
        if not r.get("read"):
            r["read"] = True
            n += 1
    if n:
        _write_all(rows)
    return n


def unread_count(kind=None):
    return sum(1 for r in load(kind) if not r.get("read"))


def update_mail(version, took=""):
    """收到「更新完成」时写一封更新内容邮件（同版本只写一封）。"""
    from core import changelog
    title, items = changelog.notes_for(version)
    body = ["当前版本：%s" % version]
    if took:
        body.append("这次换包用了 %s 秒。" % took)
    body += ["", "这一版改了什么："]
    for it in items:
        body.append("· " + it)
    body += ["", "入口：模组与资源页最右边「附魔计算器」；更新进度条在窗口底部。"]
    return add("update", title, "\n".join(body),
               meta={"version": str(version), "took": str(took)},
               dedupe_key="update-%s" % version)


def new_version_mail(version, url=""):
    """检测到有新版本时提醒一封（同版本只写一封）。"""
    body = ["发现新版本：%s" % version,
            "",
            "启动器会在后台下载，下完提示你重启换上新版本。",
            "也可以手动下载：%s" % (url or "见下载页"),
            ]
    return add("update", "发现新版本 %s" % version, "\n".join(body),
               meta={"version": str(version), "url": url},
               dedupe_key="newver-%s" % version)


def smtp_send(smtp_conf, subject, body, to=None):
    """真的发到外部邮箱；配置不全就返回 (False, 原因)。"""
    conf = smtp_conf or {}
    host = (conf.get("host") or "").strip()
    user = (conf.get("user") or "").strip()
    pwd = (conf.get("password") or "").strip()
    to = (to or conf.get("to") or "").strip()
    if not (host and user and pwd and to):
        return False, "没配 SMTP"
    port = int(conf.get("port") or (465 if conf.get("ssl", True) else 587))
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = formataddr(("OMC 启动器", user))
    msg["To"] = to
    try:
        if conf.get("ssl", True):
            s = smtplib.SMTP_SSL(host, port, timeout=20)
        else:
            s = smtplib.SMTP(host, port, timeout=20)
            s.starttls()
        s.login(user, pwd)
        s.sendmail(user, [to], msg.as_string())
        s.quit()
        return True, "已发送"
    except Exception as e:
        return False, str(e)
