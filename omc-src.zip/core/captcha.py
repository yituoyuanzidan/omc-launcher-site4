# -*- coding: utf-8 -*-
"""人机验证用的图形验证码：纯本地随机生成，不联网、不依赖第三方服务。

用 QPainter 现画（不额外装 Pillow，打包体积不变）。字符带随机旋转、位移，
叠干扰线/噪点，人眼一眼能认，脚本和爬虫截下来还得再做识图。
"""
import random

# 去掉容易看混的 O/0、I/1、S/5、Z/2
CHARS = "ABCDEFGHJKMNPQRTUVWXY346789"


def new_code(n=4):
    """生成验证码字符串（大写字母+数字）。"""
    return "".join(random.choice(CHARS) for _ in range(n))


def render(code, w=200, h=64):
    """把验证码画成 QPixmap。"""
    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import (QColor, QFont, QPainter, QPainterPath, QPen,
                               QPixmap)

    pm = QPixmap(w, h)
    pm.fill(QColor("#0E1116"))
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)

    # 底纹：斜线
    p.setPen(QPen(QColor(120, 140, 170, 55), 1))
    for i in range(-h, w, 12):
        p.drawLine(i, 0, i + h, h)

    # 噪点
    for _ in range(110):
        p.setPen(QPen(QColor(150, 175, 205, random.randint(40, 110)), 1))
        p.drawPoint(random.randint(0, w - 1), random.randint(0, h - 1))

    # 字符：随机字号、旋转、上下浮动（按字体度量居中，别贴裁）
    from PySide6.QtGui import QFontMetrics

    step = w // (len(code) + 1)
    for i, ch in enumerate(code):
        f = QFont("Consolas")
        f.setPixelSize(random.randint(int(h * 0.40), int(h * 0.52)))
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor(random.randint(170, 255), random.randint(185, 255),
                        random.randint(200, 255)))
        fm = QFontMetrics(f)
        tw = fm.horizontalAdvance(ch)
        # 基线往上挪 (ascent - descent)/2，字符视觉中心才落在原点
        base_y = (fm.ascent() - fm.descent()) / 2.0
        p.save()
        cx = step * (i + 1) + random.randint(-3, 3)
        cy = h // 2 + random.randint(-4, 4)
        p.translate(cx, cy)
        p.rotate(random.randint(-18, 18))
        p.drawText(QPointF(-tw / 2.0, base_y), ch)
        p.restore()

    # 一条横穿的干扰曲线
    path = QPainterPath()
    path.moveTo(0, random.randint(6, h - 6))
    y = h // 2
    for x in range(0, w + 20, 20):
        y = max(4, min(h - 4, y + random.randint(-12, 12)))
        path.lineTo(x, y)
    p.setPen(QPen(QColor(90, 160, 255, 130), 1))
    p.drawPath(path)
    p.end()
    return pm
