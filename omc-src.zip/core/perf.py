# -*- coding: utf-8 -*-
"""进程内存体检：只读数字 + 主动回收，不碰系统设置。

工具箱里给用户看三个数：当前占用、峰值、整理后降了多少。
优化内存不靠猜——先量，再决定动哪块缓存。
"""
import ctypes
import gc
import os
import time


class _PMC(ctypes.Structure):
    """PROCESS_MEMORY_COUNTERS（psapi）。"""
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def _mb(n):
    return round(n / 1048576.0, 1)


def snapshot():
    """当前进程的占用。非 Windows 或调用失败时字段为 None，不抛异常。"""
    res = {"work_mb": None, "peak_mb": None, "private_mb": None,
           "cpu_s": None, "pid": os.getpid()}
    try:
        k32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        h = ctypes.c_void_p(k32.GetCurrentProcess())
        pmc = _PMC()
        pmc.cb = ctypes.sizeof(_PMC)
        fn = psapi.GetProcessMemoryInfo
        # 不声明 argtypes 时 ctypes 会把伪句柄按 32 位传，返回值就是 0；
        # 显式声明后一次就成（实测 ret=1）。
        fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PMC), ctypes.c_ulong]
        fn.restype = ctypes.c_int
        if fn(h, ctypes.byref(pmc), pmc.cb):
            res["work_mb"] = _mb(pmc.WorkingSetSize)
            res["peak_mb"] = _mb(pmc.PeakWorkingSetSize)
            res["private_mb"] = _mb(pmc.PagefileUsage)
        # 内核 + 用户态 CPU 累计时间（100ns 单位）
        vals = [ctypes.c_ulonglong(0) for _ in range(4)]
        gt = k32.GetProcessTimes
        gt.argtypes = [ctypes.c_void_p] + [ctypes.POINTER(ctypes.c_ulonglong)] * 4
        gt.restype = ctypes.c_int
        if gt(h, ctypes.byref(vals[0]), ctypes.byref(vals[1]),
              ctypes.byref(vals[2]), ctypes.byref(vals[3])):
            res["cpu_s"] = round((vals[2].value + vals[3].value) / 1e7, 1)
        hn = ctypes.c_ulong(0)
        gh = k32.GetProcessHandleCount
        gh.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        gh.restype = ctypes.c_int
        if gh(h, ctypes.byref(hn)):
            res["handles"] = hn.value
    except Exception as e:
        res["err"] = "%s: %s" % (type(e).__name__, e)
    return res


def trim(clear_pixmap=None):
    """主动回收：整套循环 GC + 可选清理 Qt 位图缓存。

    clear_pixmap 由调用方传 QPixmapCache.clear（core 层不引 Qt）。
    返回整理前后的数字，界面直接拿来说「降了多少」。
    """
    before = snapshot()
    try:
        gc.collect()
    except Exception:
        pass
    freed_pix = None
    if clear_pixmap is not None:
        try:
            clear_pixmap()
            freed_pix = True
        except Exception:
            freed_pix = False
    after = snapshot()
    drop = None
    if before.get("work_mb") is not None and after.get("work_mb") is not None:
        drop = round(before["work_mb"] - after["work_mb"], 1)
    return {"before": before, "after": after, "drop_mb": drop,
            "pixmap_cleared": freed_pix}


def human(res):
    """一行摘要，给界面标签用。"""
    if res.get("work_mb") is None:
        return "取不到内存数字（%s）" % (res.get("err") or "非 Windows")
    parts = ["占用 %s MB" % res["work_mb"]]
    if res.get("peak_mb") is not None:
        parts.append("峰值 %s MB" % res["peak_mb"])
    if res.get("private_mb") is not None:
        parts.append("私有 %s MB" % res["private_mb"])
    if res.get("cpu_s") is not None:
        parts.append("累计 CPU %ss" % res["cpu_s"])
    if res.get("handles") is not None:
        parts.append("句柄 %d" % res["handles"])
    return "，".join(parts)


# ---------- 实时监控：进程 CPU 占比 / 线程数 ----------
_cpu_prev = {"t": None, "cpu": None}


def cpu_percent(now=None):
    """进程 CPU 占一个核的百分比（多核可 >100）。

    采样是「上次调用到这次调用」的平均值，所以界面每秒调一次就得到近 1 秒的真实占用；
    第一次调用没有基准，返回 None。不 sleep，不阻塞界面。
    """
    now = time.time() if now is None else now
    s = snapshot()
    cur = s.get("cpu_s")
    prev = _cpu_prev
    out = None
    if cur is not None and prev["cpu"] is not None and prev["t"] is not None:
        dt = now - prev["t"]
        if dt > 0.05:
            out = round((cur - prev["cpu"]) / dt * 100.0, 1)
    if cur is not None:
        _cpu_prev["t"] = now
        _cpu_prev["cpu"] = cur
    return out


_TH32CS_SNAPTHREAD = 0x00000004


class _THREADENTRY32(ctypes.Structure):
    """THREADENTRY32（kernel32，固定 28 字节）。"""
    _fields_ = [
        ("dwSize", ctypes.c_ulong),
        ("cntUsage", ctypes.c_ulong),
        ("th32ThreadID", ctypes.c_ulong),
        ("th32OwnerProcessID", ctypes.c_ulong),
        ("tpBasePri", ctypes.c_long),
        ("tpDeltaPri", ctypes.c_long),
        ("dwFlags", ctypes.c_ulong),
    ]


def thread_count():
    """本进程当前线程数；取不到返回 None（不抛异常）。"""
    try:
        k32 = ctypes.windll.kernel32
        snap = k32.CreateToolhelp32Snapshot
        snap.argtypes = [ctypes.c_ulong, ctypes.c_ulong]
        snap.restype = ctypes.c_void_p
        first = k32.Thread32First
        nxt = k32.Thread32Next
        for fn in (first, nxt):
            fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(_THREADENTRY32)]
            fn.restype = ctypes.c_int
        close = k32.CloseHandle
        close.argtypes = [ctypes.c_void_p]
        h = snap(_TH32CS_SNAPTHREAD, 0)
        if not h:
            return None
        pid = os.getpid()
        cnt = 0
        try:
            te = _THREADENTRY32()
            te.dwSize = ctypes.sizeof(_THREADENTRY32)
            ok = first(h, ctypes.byref(te))
            while ok:
                if te.th32OwnerProcessID == pid:
                    cnt += 1
                te.dwSize = ctypes.sizeof(_THREADENTRY32)
                ok = nxt(h, ctypes.byref(te))
        finally:
            close(h)
        return cnt
    except Exception:
        return None
