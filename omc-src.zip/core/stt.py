# -*- coding: utf-8 -*-
"""语音识别（小矿语音通话用）。

走的是 Windows 自带的离线识别引擎（System.Speech + MS-2052-80-DESK zh-CN），
不联网、不上传音频。

实测基线（_ai_voice_base.txt，用 TTS 合成的 6 句话喂给识别器）：
- 6 句里 4 句有错：「附魔」听成「复活」、「红石」听成「过去」、
  「崩了」听成「钢缆」、「存档在哪」听成「当我看看存档在那」；置信度 0.14~0.40。
- 识别器每次都给出 5 个以上的候选，正确答案有时就在第 2 名（
  「当我看看存档在那」0.2525 与「当我看看存档在哪」0.2524 差 0.0001）。
  所以**只看第一个结果是被浪费掉的**。

于是这里做三件事，都不换引擎：
1. 一次拿 6 个候选（MaxAlternates），按「像不像 MC 话题」+ 置信度一起打分挑。
2. 挂断词之外再加一组常用指令语法，让「存档在哪 / 换主题 / 放首歌」这类
   整句走高置信的命令语法，而不是全靠听写去猜。
3. 同音字纠错：MC 专有词（附魔、红石、存档、下界……）在离线识别器上几乎
   必错，用上下文规则把常见错字掰回来。
另外一句话说得长时，识别器只给前半句就结束；现在最多接两段拼起来。
"""
import os
import shutil
import subprocess
import tempfile
import threading
import time

_LOCK = threading.Lock()
_STATE = {"ok": None, "reason": ""}

# 常用指令：整句命中时走命令语法，置信度比听写高得多
_PHRASES = (
    "挂断电话", "挂了吧", "把电话挂断", "挂断", "先挂了", "再见", "拜拜",
    "换主题", "换个主题", "换成深色主题", "换成浅色主题", "换壁纸",
    "换个壁纸", "放首歌", "放首音乐", "换一首歌", "换首歌", "上一首",
    "换一首歌吧", "换首歌吧", "来一首歌", "来首歌", "放首歌吧", "换首音乐",
    "下一首", "暂停", "继续播放", "声音大一点", "声音小一点",
    "把音量调大一点", "把音量调小一点", "存档在哪", "我的存档在哪",
    "附魔多少级", "红石农场怎么建", "钻石在哪挖", "下界合金锭怎么合成",
    "模组冲突了怎么办", "游戏启动就崩了怎么办", "附魔台怎么摆",
    "内存要给多少", "帮我看看存档在哪",
)

# 模式语法用的两端词表：开头修饰 + 疑问尾，中间随便说什么。
# 目的是让「帮我看一下存档到底在哪啊」这种带修饰的真人问法也有高置信落点，
# 而不是整句命令语法对不上、只能靠听写去猜。
_VERBS = (
    "帮我", "帮我看", "帮我看一下", "帮我查", "帮我找", "我想", "我要", "我想问",
    "请问", "问一下", "这个", "那个", "我的", "我", "你看", "看一下", "麻烦",
    "能不能", "怎么", "为什么", "告诉我", "说说", "讲一下",
)
_TAILS = (
    "在哪", "在哪里", "在哪儿", "多少级", "要多少级", "多少", "怎么建",
    "怎么弄", "怎么做", "怎么合成", "怎么办", "是什么", "有什么办法",
    "找不到了", "没有了", "不行了", "怎么解决", "要多少", "够不够",
)
# 模式语法默认不开（实测会拉低识别率，见 _script 里的注释），留着以便以后换引擎时再用
_USE_PATTERN = False

_VOCAB = (
    "存档", "附魔", "红石", "下界", "末地", "钻石", "村民", "鞘翅", "信标",
    "刷怪", "农场", "模组", "光影", "服务器", "内存", "壁纸", "主题", "歌曲",
    "启动", "崩溃", "闪退", "版本", "联机", "种子", "地图", "背包", "命令",
    "盖房子", "装备", "挖矿", "打龙", "合成", "附魔台", "经验",
    "镐", "合金", "锭", "音量", "音乐", "冲突", "镐子", "钻石镐",
    "沙子", "岩浆", "桶", "盾", "弓", "箭", "药水", "末影人", "凋灵",
    # 启动器/加载器语境：说的是启动器自己的事，同样算 MC 语境
    "加载器", "整合包", "坐标", "生物群系", "备份", "崩溃报告", "附魔书",
    "forge", "fabric", "optifine", "shader", "mods", "java", "jar",
)

# 英文词可能被识别成不同大小写，打分时统一小写
_VOCAB_LOWER = tuple(v.lower() for v in _VOCAB)

# (错词, 正确词, 触发上下文)：离线识别器最常犯的几类错
_FIX_RULES = (
    ("存党", "存档", ()), ("纯党", "存档", ()), ("存当", "存档", ()),
    ("传导", "存档", ()), ("存到", "存档", ("看看", "在哪", "备份")),
    ("复活", "附魔", ("级", "台", "书", "经验", "多少", "几")),
    ("过去", "红石", ("农场", "自动", "电路", "粉", "线")),
    ("工序", "红石", ("农场", "自动", "电路", "粉", "线")),
    ("洪石", "红石", ()), ("宏石", "红石", ()),
    ("钢缆", "崩了", ("游戏", "启动", "开")),
    ("帮了", "崩了", ("游戏", "启动", "开")),
    ("扛了", "崩了", ("游戏", "启动", "开")),
    ("更问", "崩溃", ("游戏", "启动", "开")),
    # 「多少级」的「级」常被听成旗/棋/琪/起
    ("多少旗", "多少级", ()), ("多少棋", "多少级", ()),
    ("多少琪", "多少级", ()), ("多少起", "多少级", ()),
    ("怎么解", "怎么建", ("农场", "房子", "塔", "刷怪")),
    ("莫地", "末地", ()), ("瞎界", "下界", ()),
    ("转石", "钻石", ()), ("赚石", "钻石", ()),
    ("存民", "村民", ()), ("翘翅", "鞘翅", ()),
    ("新标", "信标", ()), ("模阻", "模组", ()), ("模祖", "模组", ()),
    ("光英", "光影", ()), ("内纯", "内存", ()),
    ("壁志", "壁纸", ()), ("服务起", "服务器", ()),
    # 句首助词被听错：「帮我」几乎必成「当我」，「我想」偶尔成「国想」
    ("当我", "帮我", ("看看", "存档", "查", "帮", "音量", "主题", "壁纸",
                      "设置", "放", "换")),
    ("国想", "我想", ("换", "要", "想")),
    ("窝想", "我想", ("换", "要", "想")),
    # 名词尾字
    ("钻石搞", "钻石镐", ()), ("钻石高", "钻石镐", ()),
    ("合金定", "合金锭", ()), ("合金钉", "合金锭", ()),    ("亚铁合金", "下界合金", ()),
    # 「模组跟光影冲突了」里的「模组跟」常被听成「无主根」「没主根」
    ("无主根", "模组跟", ("光影", "冲突", "模组")),
    ("没主根", "模组跟", ("光影", "冲突", "模组")),
    ("冲突的", "冲突了", ("怎么办", "冲突")),
    ("要在的", "要怎么", ("合成", "建", "做", "弄")),
    ("条小", "调小", ("音量", "声音")), ("条大", "调大", ("音量", "声音")),
    ("贤不", "先不", ("玩", "聊")), ("闲不", "先不", ("玩", "聊")),
    ("果的", "我的", ("镐", "存档", "电脑", "号", "世界")),
    # 「换一首歌吧」实测被听成「观一手可把」：换→观、首→手、歌吧→可把。
    # 单字替换必须带上「歌/首/换」这类上下文才动，免得把正常句子改坏。
    ("观一", "换一", ("首", "歌", "换", "来", "听")),
    ("换一手", "换一首", ()), ("来一手歌", "来一首歌", ()),
    ("一手歌", "一首歌", ("换", "来", "听", "放")),
    # Whisper 把「挖」听成「吧」：只在「在哪」问位置的句式里改，别动「走吧」这种
    ("在哪吧", "在哪挖", ()),
    ("可把", "歌吧", ("首", "歌", "换", "来", "听")),
    ("首可把", "首歌吧", ("换", "来", "听")),
)

_SCRIPT = r'''Add-Type -AssemblyName System.Speech
$ErrorActionPreference = "Stop"
try {
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
  $e = New-Object System.Speech.Recognition.SpeechRecognitionEngine
  $e.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
  $cmds = New-Object System.Speech.Recognition.Choices
  __PHRASES__ | ForEach-Object { [void]$cmds.Add($_) }
  $gb = New-Object System.Speech.Recognition.GrammarBuilder
  $gb.Append($cmds)
  $e.LoadGrammar((New-Object System.Speech.Recognition.Grammar $gb))
  # 第二种语法：开头 + 任意内容 + 疑问尾。整句命令语法要求一字不差，真人说话
  # 会多带「帮我看一下」这种修饰、句尾多个「吧/呢」，听写语法又常常没抓住关键词；
  # 这个模式语法让「X 存档 在哪」这类常见问法有一个高置信的落点。
  $vb = New-Object System.Speech.Recognition.Choices
  __VERBS__ | ForEach-Object { [void]$vb.Add($_) }
  $tl = New-Object System.Speech.Recognition.Choices
  __TAILS__ | ForEach-Object { [void]$tl.Add($_) }
  $gb2 = New-Object System.Speech.Recognition.GrammarBuilder
  $gb2.Culture = [System.Globalization.CultureInfo]"zh-CN"
  $gb2.Append($vb)
  $gb2.AppendDictation()
  $gb2.Append($tl)
  $e.LoadGrammar((New-Object System.Speech.Recognition.Grammar $gb2))
  __INPUT__
  $e.MaxAlternates = 6
  $e.InitialSilenceTimeout = [TimeSpan]::FromSeconds(5)
  $e.BabbleTimeout = [TimeSpan]::FromSeconds(8)
  $e.EndSilenceTimeout = [TimeSpan]::FromSeconds(1.1)
  $e.EndSilenceTimeoutAmbiguous = [TimeSpan]::FromSeconds(1.6)
  for ($n = 1; $n -le 2; $n++) {
    # 第二段常常已经没有音频可读，Recognize 会抛异常；把异常就地吞掉，
    # 否则第一段已经识别出来的结果会跟着一起丢掉。
    try { $r = $e.Recognize() } catch { if ($n -eq 1) { Write-Output "TIMEOUT" }; break }
    if (-not $r) {
      if ($n -eq 1) { Write-Output "TIMEOUT" }
      break
    }
    Write-Output ("RESULT" + $n + "=" + $r.Text)
    Write-Output ("CONF" + $n + "=" + $r.Confidence)
    $i = 0
    foreach ($a in $r.Alternates) {
      Write-Output ("ALT" + $n + "_" + $i + "=" + $a.Text + "|" + $a.Confidence)
      $i = $i + 1
      if ($i -ge 6) { break }
    }
    # 只有头一段说得够长，才接着等第二段（短句多等 1 秒会显得迟钝）
    if ($r.Text.Length -le 12) { break }
  }
  $e.Dispose()
} catch {
  Write-Output ("ERR=" + $_.Exception.Message)
}
'''


def _ps():
    for exe in ("powershell", "pwsh"):
        p = shutil.which(exe)
        if p:
            return p
    return ""
def _flags():
    return (subprocess.CREATE_NO_WINDOW
            if hasattr(subprocess, "CREATE_NO_WINDOW") else 0)


# ---------------- Whisper 引擎（主力） ----------------
# 原来的 SAPI 中文听写只是命令词识别（12 句回归集里靠同音规则硬凑）；
# 换成 faster-whisper small（int8 / CPU / 8 线程）后同样 12 句只错 1 字，
# 实时率约 1.0x。模型不进安装包，首次用到时下到用户目录（约 461MB），
# 走 hf-mirror 国内镜像；下不到就自动落回 SAPI，不影响没模型的老机器。
_WMODEL = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher", "whisper")
# 提示词只把 MC 专有词带进解码上下文，不写成完整句子，否则会被当成上一句
_PROMPT = "存档、附魔台、红石农场、模组、光影、下界合金锭、启动器、联机、刷怪塔。"
_W = {"ok": None, "mod": None, "local": None, "model": None, "err": "",
      "dead": {}, "cooldown": 0.0, "tier": ""}

# 模型分级：small 最准但要 ~500MB 常驻；内存紧的机器（同时开着很多程序）
# 加载会直接 mkl_malloc 失败，这时依次退 base、tiny，别让用户掉回系统识别。
_TIERS = (("small", "Systran/faster-whisper-small"),
          ("base", "Systran/faster-whisper-base"),
          ("tiny", "Systran/faster-whisper-tiny"))
_WLOCK = threading.Lock()


def _mod_ok():
    """faster-whisper 装没装（只查一次）。"""
    if _W["mod"] is not None:
        return _W["mod"]
    try:
        import faster_whisper  # noqa: F401
        _W["mod"] = True
    except Exception as e:
        _W["mod"], _W["err"] = False, "没装 faster-whisper：" + str(e)[:50]
    return _W["mod"]


def _model_local():
    """模型文件在不在本地（只查一次）。"""
    if _W["local"] is not None:
        return _W["local"]
    found = False
    for _dirpath, _, files in os.walk(_WMODEL):
        if "model.bin" in files and "config.json" in files:
            found = True
            break
    _W["local"] = found
    if not found:
        _W["err"] = "Whisper 模型没下载完"
    return found


def model_ready():
    """模型是不是已经躺在本地，能直接用。"""
    return _mod_ok() and _model_local()


def ensure_model():
    """没模型就在后台下一次（约 461MB，只下一次）。返回 True 表示已就绪。"""
    if _model_local():
        return True
    if not _mod_ok():
        return False
    try:
        os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
        from huggingface_hub import snapshot_download
        snapshot_download("Systran/faster-whisper-small", cache_dir=_WMODEL,
                          max_workers=2)
        _W["local"] = None
        _W["ok"] = None
        return _model_local()
    except Exception as e:
        _W["err"] = "模型下载失败：" + str(e)[:60]
        return False


def _w_ok():
    """Whisper 能不能直接用：模块装了、模型也在。"""
    if _W["ok"] is not None:
        return _W["ok"]
    _W["ok"] = _mod_ok() and _model_local()
    return _W["ok"]


def _tier_local(name):
    """某个档位的模型在不在本地（按仓库目录名找，别把 small 当成 base）。"""
    prefix = "models--Systran--faster-whisper-" + name
    try:
        for d in os.listdir(_WMODEL):
            if d != prefix:
                continue
            for _dirpath, _dirs, files in os.walk(os.path.join(_WMODEL, d)):
                if "model.bin" in files and "config.json" in files:
                    return True
    except Exception:
        pass
    return False


def _model(allow_download=False):
    """加载模型（单例）。small 优先；装不下就依次退 base、tiny。

    allow_download=False（通话中临时加载）时只用本地已有的档位，绝不在
    用户说一句话的时候去下 100 多 MB；allow_download=True 只在预热线程里用。
    """
    if _W["model"] is not None:
        return _W["model"]
    with _WLOCK:
        if _W["model"] is not None:
            return _W["model"]
        if not _w_ok():
            return None
        if _W["cooldown"] > time.time():
            return None                  # 刚失败过，180 秒内不再每句白等几秒
        os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
        try:
            from faster_whisper import WhisperModel
        except Exception as e:
            _W["err"] = "Whisper 加载失败：" + str(e)[:60]
            _W["cooldown"] = time.time() + 180
            return None
        for name, repo in _TIERS:
            if _W["dead"].get(name):
                continue
            if not _tier_local(name):
                if not allow_download:
                    continue
                try:
                    from huggingface_hub import snapshot_download
                    snapshot_download(repo, cache_dir=_WMODEL, max_workers=2,
                                      allow_patterns=["config.json", "model.bin",
                                                      "tokenizer.json", "vocabulary.*"])
                except Exception as e:
                    _W["dead"][name] = "下载失败 " + str(e)[:40]
                    continue
            try:
                m = WhisperModel(name, device="cpu", compute_type="int8",
                                 download_root=_WMODEL,
                                 cpu_threads=min(8, os.cpu_count() or 4))
            except Exception as e:
                # mkl_malloc 失败 = 内存不够，这一档就别再试了
                _W["dead"][name] = str(e)[:40]
                continue
            _W["model"], _W["tier"] = m, name
            _W["err"] = ("" if name == "small" else
                         "内存不够跑 small，已降到 %s 模型" % name)
            return m
        _W["cooldown"] = time.time() + 180
        _W["err"] = "Whisper 加载失败：" + (_W["dead"].get("small", "") or "内存不足")
        return None


def warm(allow_download=False):
    """提前把模型加载好（进语音通话时调一次，省掉第一句的等待）。"""
    return _model(allow_download=allow_download) is not None


def model_state():
    """给界面看的人话状态：模型档位 / 内存不够 / 系统识别兜底。"""
    if _W["model"] is not None:
        t = _W["tier"] or "small"
        return "whisper-" + t if t == "small" else "whisper-" + t + "(降级)"
    if _W["cooldown"] > time.time():
        return "系统识别（内存不足）"
    if _model_local():
        return "whisper-small(未加载)"
    return "系统识别"


def engine():
    """当前真正会用哪个引擎：whisper / sapi / none。

    以前这里只看「模型文件在不在」，内存装不下时会显示 whisper 而实际上
    每句都退回系统识别，用户看到的就是「还是不准」。
    """
    if _W["model"] is not None:
        return "whisper"
    if _W["cooldown"] > time.time() or _W["dead"]:
        return "sapi" if _STATE["ok"] else "none"
    return "whisper" if _w_ok() else ("sapi" if _STATE["ok"] else "none")


def _read_wav(path):
    import wave

    import numpy as np
    with wave.open(path, "rb") as w:
        ch, n = w.getnchannels(), w.getnframes()
        raw = w.readframes(n)
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a


def _record(max_wait=14, sr=16000, start_timeout=5.0, end_silence=0.9):
    """等一句说完。返回 float32 单声道数组；没人说话返回 None。

    用能量做简易 VAD：开头 5 秒内等到第一次够响；之后持续收到静音 0.9 秒就收尾，
    最长不超过 max_wait。这样一句说完立刻出音频，比固定录满更跟手。
    """
    import time

    import numpy as np
    import sounddevice as sd

    blk = int(sr * 0.03)
    frames = []
    t0 = time.time()
    noise = 0.0
    th = 0.02
    voiced = None
    last = 0.0
    with sd.InputStream(samplerate=sr, channels=1, dtype="int16", blocksize=blk) as st:
        for i in range(int(max_wait / 0.03) + 220):
            data, _ = st.read(blk)
            f = data.reshape(-1).astype(np.float32) / 32768.0
            amp = float(np.abs(f).mean())
            now = time.time()
            if voiced is None:
                # 前 0.3 秒只听噪声定阈值；之后够响才算开始说话
                if i < 10:
                    noise = amp if i == 0 else (noise * i + amp) / (i + 1)
                    th = max(noise * 3.0, 0.02)
                if amp > th:
                    voiced, last = now, now
                    frames.append(f)
                elif now - t0 > start_timeout:
                    return None
            else:
                frames.append(f)
                if amp > th:
                    last = now
                if now - last > end_silence:
                    break
                if now - voiced > max_wait:
                    break
    if voiced is None or sum(len(x) for x in frames) < sr * 0.2:
        return None
    return np.concatenate(frames)


def _clean_whisper(text):
    """Whisper 会带标点、偶尔出繁体：统一成简体无标点，再走原来的同音纠错。"""
    t = (text or "").strip()
    if not t:
        return ""
    try:
        import zhconv
        t = zhconv.convert(t, "zh-cn")
    except Exception:
        pass
    for c in "，。？?！!、；;：:…·．.－-—\"'“”‘’（）()[]【】<>《》 \t\n,":
        t = t.replace(c, "")
    return _fix(t)


def _whisper_run(model, audio):
    # 一句话本来就短，再让 VAD 掐一遍容易把轻声的字整段判成静音（结果就是
    # 「没听清」）；3 秒以内的音频直接不启用 VAD。
    dur = len(audio) / 16000.0
    use_vad = dur > 3.0
    segs, info = model.transcribe(audio, language="zh", beam_size=1,
                                  vad_filter=use_vad, initial_prompt=_PROMPT,
                                  condition_on_previous_text=False)
    pick = _clean_whisper("".join(s.text for s in segs))
    if not pick:
        return "", "timeout"
    lp = float(getattr(info, "avg_logprob", 0.0) or 0.0)
    # 置信度极低又很短，基本是没听清（Whisper 不报置信度，用 logprob 替代）
    if lp < -1.0 and len(pick) < 6:
        return pick, "unclear"
    return pick, "ok"


def available():
    """有没有能用的识别引擎（问过一次就记住）。"""
    if _STATE["ok"] is not None:
        return _STATE["ok"]
    if _mod_ok():
        _STATE["ok"], _STATE["reason"] = True, ""
        return True
    if os.name != "nt" or not _ps():
        _STATE["ok"], _STATE["reason"] = False, "这个系统没有 Windows 语音识别"
        return False
    try:
        ps = _ps()
        script = ("Add-Type -AssemblyName System.Speech;"
                  "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"
                  "$rs=[System.Speech.Recognition.SpeechRecognitionEngine]"
                  "::InstalledRecognizers();"
                  "if($rs.Count -gt 0){'YES '+$rs[0].Culture.Name}else{'NO'}")
        out = subprocess.run([ps, "-NoProfile", "-NonInteractive", "-Command", script],
                             capture_output=True, timeout=25,
                             creationflags=_flags()).stdout.decode("utf-8", "replace")
        ok = out.strip().upper().startswith("YES")
        _STATE["ok"] = ok
        _STATE["reason"] = "" if ok else "系统里没装中文语音识别"
    except Exception as e:
        _STATE["ok"], _STATE["reason"] = False, str(e)[:80]
    return _STATE["ok"]


def reason():
    available()
    return _STATE["reason"]


# ---------------- 候选打分 + 同音纠错 ----------------
# _VOCAB / _FIX_RULES 在上面（和 _PHRASES 放一起，方便一次看全用什么词、
# 用什么纠错）；这里只放打分和纠错的逻辑。


def _fix(text):
    """把识别结果里常见的同音错字掰回来（只在上下文对得上时才动）。"""
    t = (text or "").strip()
    if not t:
        return ""
    for bad, good, need in _FIX_RULES:
        if bad not in t:
            continue
        if need and not any(k in t for k in need):
            continue
        t = t.replace(bad, good)
    # 「在那」在问位置时一定是「在哪」：只有整句带「存档/哪」才换，
    # 别把「他站在那」这种正常句子改坏
    if ("存档" in t or "在哪" in t) and "在那" in t:
        t = t.replace("在那", "在哪")
    return t.strip()


def _looks_mc(text):
    """这句像不像在聊 MC（用来在多个候选里挑最合理的一条）。"""
    t = (text or "").lower()
    return sum(1 for w in _VOCAB_LOWER if w in t)


def _pick(alts):
    """从识别器给的候选里挑一条：先看像不像 MC，再看置信度。"""
    best, best_key = "", None
    for text, conf in alts:
        t = (text or "").strip()
        if not t:
            continue
        key = (_looks_mc(t), round(float(conf), 3), len(t))
        if best_key is None or key > best_key:
            best, best_key = t, key
    return best


# 判断「这句是不是真没听清」用的闲聊词：不含 MC 词但含这些字，说明是正常聊天，
# 不能因为置信度低就判成乱码（"今天有点困先不玩了"就是这种）。
_CHAT_WORDS = (
    "困", "累", "睡", "吃", "饿", "无聊", "上班", "下班", "放学", "学校", "作业",
    "考试", "天气", "开心", "难受", "烦", "朋友", "歌", "听", "放", "主题", "壁纸",
    "音量", "声音", "你好", "在吗", "晚安", "早", "晚", "谢谢", "哈", "嗯", "哦",
    "行", "好", "喜欢", "爱", "想", "梦", "玩", "打", "忙", "休息", "开心", "笑",
    "哭", "饭", "水", "回家", "公司", "明天", "今天", "昨天", "点", "换", "调",
)


def _unclear(pick, conf):
    """识别结果像不像「瞎猜出来的一串字」（不是没听到，是听到了但没听懂）。

    只在三个条件同时成立时才判：置信度很低、完全不像在聊 MC、也不是正常闲聊。
    这样「观一手可把」这种会被丢掉让用户重说，而「今天有点困」不会被误伤。
    """
    t = (pick or "").strip()
    if not t or len(t) < 4:
        return False
    if float(conf or 0.0) >= 0.20:
        return False
    if _looks_mc(t) > 0:
        return False
    if any(w in t for w in _CHAT_WORDS):
        return False
    return True


def _parse(out):
    """把 PowerShell 的输出解析成 (文本, 状态)。"""
    alts, results, confs, timeout = [], [], [], False
    for line in out.splitlines():
        line = line.strip()
        if line == "TIMEOUT":
            timeout = True
        elif line.startswith("ERR="):
            # 把真实错误带回去：以前只留一句 "error"，出问题查不出是
            # 麦克风忙、语法装载失败还是引擎异常。
            err = line.split("=", 1)[1].strip()[:90]
            # 已经有识别结果就先认结果：第二段没音频导致的异常不算失败
            if results or alts:
                continue
            return "", "error:" + err
        elif line.startswith("RESULT") and "=" in line:
            results.append(line.split("=", 1)[1].strip())
        elif line.startswith("CONF") and "=" in line:
            try:
                confs.append(float(line.split("=", 1)[1]))
            except Exception:
                confs.append(0.0)
        elif line.startswith("ALT") and "=" in line:
            body = line.split("=", 1)[1]
            if "|" in body:
                txt, c = body.rsplit("|", 1)
                try:
                    alts.append((txt.strip(), float(c)))
                except Exception:
                    alts.append((txt.strip(), 0.0))
    # 主结果也进候选池，别只信第一个
    for i, r in enumerate(results):
        alts.append((r, confs[i] if i < len(confs) else 0.0))
    if not alts:
        return "", ("timeout" if timeout else "timeout")
    pick = _fix(_pick(alts))
    if not pick:
        return "", "timeout"
    # 两段拼起来（长句被切开的补救）
    if len(results) > 1 and results[1] and results[1] not in pick:
        pick = pick + "，" + _fix(results[1])
    best_conf = max((c for _, c in alts), default=0.0)
    if _unclear(pick, best_conf):
        return pick, "unclear"
    return pick, "ok"


def _script(input_line):
    phrases = ", ".join('"%s"' % p for p in _PHRASES)
    s = (_SCRIPT.replace("__PHRASES__", "@(%s)" % phrases)
         .replace("__VERBS__", "@(%s)" % ", ".join('"%s"' % v for v in _VERBS))
         .replace("__TAILS__", "@(%s)" % ", ".join('"%s"' % t for t in _TAILS))
         .replace("__INPUT__", input_line))
    if not _USE_PATTERN:
        # 实测（12 句回归集）：开了模式语法反而把两句原本读对的句子听错——
        # 「这个」这种泛词被锁成语法开头，中间的自由听写声学约束变松，
        # 「这个模组跟光影冲突了怎么办」被听成「这个我主干光影冲突了怎么办」。
        # 所以默认关掉，只留整句命令语法。
        s = s.replace("  $e.LoadGrammar((New-Object System.Speech.Recognition.Grammar $gb2))", "")
    return s


def _sapi_listen(max_wait=14, wav=""):
    """老的 Windows 离线识别（Whisper 不可用时的兜底）。"""
    if not available():
        return "", "unavailable"
    path = ""
    try:
        if wav:
            src = "$e.SetInputToWaveFile('%s')" % wav.replace("\\", "/")
        else:
            src = "$e.SetInputToDefaultAudioDevice()"
        fd, path = tempfile.mkstemp(suffix=".ps1", prefix="omc_stt_")
        os.close(fd)
        # PowerShell 5.1 读脚本认 BOM，中文注释/字符串没有 BOM 会乱码
        with open(path, "w", encoding="utf-8-sig") as f:
            f.write(_script(src))
        out = subprocess.run(
            [_ps(), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path],
            capture_output=True, timeout=max(8, int(max_wait)),
            creationflags=_flags()).stdout.decode("utf-8", "replace")
        return _parse(out)
    except subprocess.TimeoutExpired:
        return "", "timeout"
    except Exception as e:
        return "", "error:%s" % str(e)[:60]
    finally:
        if path:
            try:
                os.remove(path)
            except Exception:
                pass


def listen(max_wait=14, wav=""):
    """听一句。返回 (文本, 状态)。

    Whisper small 优先（本地 CPU、离线、不联网）；模型没装好就落回老的
    Windows 离线识别。状态：ok / unclear / timeout / busy / unavailable / error。
    wav 只在自测时用（从 wav 文件识别，不开麦克风）。
    """
    if not _LOCK.acquire(blocking=False):
        return "", "busy"
    try:
        model = _model()
        if model is not None:
            try:
                audio = _read_wav(wav) if wav else _record(max_wait)
                if audio is None:
                    return "", "timeout"
                return _whisper_run(model, audio)
            except Exception as e:
                _W["err"] = "Whisper 识别失败：" + str(e)[:60]
        return _sapi_listen(max_wait, wav)
    finally:
        _LOCK.release()



# ---------------- 识别结果 -> 意图 ----------------
_HANG_WORDS = ("挂断", "挂了吧", "挂了", "先挂", "挂电话", "别聊了", "拜拜", "再见",
               "不聊了", "结束通话", "收线", "挂段", "寡断", "刮断")


def is_hangup(text):
    """是不是要我挂电话。

    识别出来的字经常不准（「挂断」可能被听成「挂段」「寡断」），所以既认整词，
    也认「短句里带挂/拜/再见」这种松散说法。
    """
    t = (text or "").strip()
    if not t:
        return False
    t2 = t.replace(" ", "")
    if len(t2) > 18:
        return False                   # 一整段话里顺嘴提到不算
    for w in _HANG_WORDS:
        if w in t2:
            return True
    if "挂" in t2 and any(c in t2 for c in ("吧", "了", "断", "电", "掉")):
        return True
    if "拜" in t2 or "再建" in t2:      # 「再建」是「再见」的常见误识别
        return True
    return False
