# -*- coding: utf-8 -*-
"""皮肤库：内置热门皮肤/披风、联网按昵称拉取、搜索、穿搭保存与应用。

设计要点：
- 所有网络请求都走 core.http 的 `_read_url`（连接复用 + 重试 + 镜像），并落磁盘缓存，
  断网时直接用缓存，不让界面卡住；
- 皮肤来源按可用性排序：mc-heads -> minotar（外网，正版档案直出 PNG）；
- 内置名单里的"主播/名人"只是候选，真正下载成功后才算进库；没有档案的名字会明确报错，
  不会悄悄塞一张 Steve；
- 穿搭存成文件夹（outfits/<名字>/skin.png + cape.png + meta.json），去重按皮肤+披风内容哈希，
  同款不允许二次保存。
"""
import base64
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse

from . import config, http, platform_utils

# 主源：Mojang 官方档案（一次拿到皮肤+披风，能判断玩家到底有没有披风）
_UUID_URL = "https://api.mojang.com/users/profiles/minecraft/{}"
_SESSION_URL = "https://sessionserver.mojang.com/session/minecraft/profile/{}"
# 国内源：LittleSkin 皮肤站（支持中文名，国内玩家基本都在这里传皮肤）
LS_BASE = "https://littleskin.cn"
LS_PROFILES = LS_BASE + "/api/yggdrasil/api/profiles/minecraft"
LS_PROFILE = LS_BASE + "/api/yggdrasil/sessionserver/session/minecraft/profile/%s"
# 兜底源：第三方站直出 PNG。这些站对不存在的名字会返回默认 Steve/Alex，
# 容易误判成「拉到了」，所以默认关闭，只在明确需要时打开。
_SKIN_SOURCES = []
_CAPE_SOURCES = []

_STALE_SECONDS = 7 * 24 * 3600   # 超过一周的缓存视为过期，联网时顺带刷新
_BAD_SECONDS = 30 * 24 * 3600    # 查过不存在的名字，一个月内不再联网试

# (显示名, 查询昵称, 分组) —— 只放真实存在正版档案的名字，避免拉回默认皮肤
STARS = [
    # ---- 国外主播 / 名人 ----
    ("Dream", "Dream", "国际主播"),
    ("Technoblade", "Technoblade", "国际主播"),
    ("GeorgeNotFound", "GeorgeNotFound", "国际主播"),
    ("Sapnap", "Sapnap", "国际主播"),
    ("TommyInnit", "TommyInnit", "国际主播"),
    ("Wilbur Soot", "WilburSoot", "国际主播"),
    ("Tubbo", "Tubbo_", "国际主播"),
    ("Ranboo", "Ranboo", "国际主播"),
    ("Quackity", "Quackity", "国际主播"),
    ("Philza", "Ph1LzA", "国际主播"),
    ("CaptainSparklez", "CaptainSparklez", "国际主播"),
    ("DanTDM", "DanTDM", "国际主播"),
    # ---- 国外红石/建筑区主播 ----
    ("Mumbo Jumbo", "MumboJumbo", "HermitCraft"),
    ("Grian", "Grian", "HermitCraft"),
    ("Xisuma", "xisumavoid", "HermitCraft"),
    ("Rendog", "Rendog", "HermitCraft"),
    ("ImpulseSV", "ImpulseSV", "HermitCraft"),
    ("TangoTek", "TangoTek", "HermitCraft"),
    ("Smallishbeans", "Smallishbeans", "HermitCraft"),
    ("ZombieCleo", "ZombieCleo", "HermitCraft"),
    ("iJevin", "iJevin", "HermitCraft"),
    ("Etho", "Etho", "HermitCraft"),
    ("VintageBeef", "VintageBeef", "HermitCraft"),
    ("Keralis", "Keralis", "HermitCraft"),
    ("BdoubleO100", "BdoubleO100", "HermitCraft"),
    ("Docm77", "Docm77", "HermitCraft"),
    # ---- 官方/经典 ----
    ("Notch", "Notch", "经典"),
    ("jeb_", "jeb_", "经典"),
]

_INDEX_NAME = "index.json"

# 精选：从上面主播里人工挑的一批，界面「精选」分组只看这些
FEATURED = (
    "Dream", "Technoblade", "Sapnap", "GeorgeNotFound", "TommyInnit",
    "Wilbur Soot", "Ranboo", "Philza", "Quackity", "Tubbo",
    "Grian", "Mumbo Jumbo", "Xisuma", "Etho", "TangoTek", "ImpulseSV",
    "Notch", "jeb_",
)


# ------------------------------------------------------------------ 目录
def store_dir():
    d = os.path.join(config.app_dir(), "skinlib")
    os.makedirs(d, exist_ok=True)
    return d


def outfits_root():
    d = os.path.join(config.app_dir(), "outfits")
    os.makedirs(d, exist_ok=True)
    return d


def local_skins_dir():
    """本地导入的皮肤放这里（和 core.skins.skins_dir() 是同一个目录）。"""
    d = os.path.join(config.app_dir(), "skins")
    os.makedirs(d, exist_ok=True)
    return d


def import_local(path):
    """把本机一张皮肤 png 复制进库，返回库内路径；同名加时间戳。"""
    with open(path, "rb") as f:
        data = f.read()
    if not _is_png(data):
        raise RuntimeError("不是有效的 PNG")
    w, h = _png_size(data)
    if not (w % 64 == 0 and h in (32, 64, 128, 256)):
        raise RuntimeError("尺寸不对（%dx%d），皮肤要 64×64 或 64×32" % (w, h))
    base = os.path.basename(path)
    dest = os.path.join(local_skins_dir(), base)
    if os.path.exists(dest):
        stem, ext = os.path.splitext(base)
        dest = os.path.join(local_skins_dir(),
                            "%s_%d%s" % (stem, int(time.time() * 1000), ext))
    with open(dest, "wb") as f:
        f.write(data)
    return dest


# ------------------------------------------------------ 未下载皮肤的临时预览
def preview_dir():
    """没下载的皮肤先存成临时预览图，只在显示期间留着，不占正式库。"""
    import tempfile
    d = os.path.join(tempfile.gettempdir(), "omc_skin_preview")
    os.makedirs(d, exist_ok=True)
    return d


def preview_path(name):
    key = (name or "").strip().lower()
    if not key:
        return ""
    h = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
    return os.path.join(preview_dir(), h + ".png")


def _preview_cape_path(name):
    pp = preview_path(name)
    return pp[:-4] + "_cape.png" if pp else ""


def fetch_preview(name, want_cape=True, log=None):
    """把皮肤拉成临时预览文件（不进皮肤库），返回 (皮肤路径, 披风路径)。"""
    name = (name or "").strip()
    pp = preview_path(name)
    if not pp:
        return "", ""
    cp = _preview_cape_path(name)
    if os.path.isfile(pp) and os.path.getsize(pp) > 0:
        return pp, (cp if os.path.isfile(cp) else "")
    try:
        status, skin, cape, _src = _fetch_both(name, log)
    except Exception:
        return "", ""
    if status != "ok" or not skin:
        return "", ""
    if not _write(pp, skin):
        return "", ""
    if want_cape and cape:
        _write(cp, cape)
        return pp, cp
    return pp, ""


def drop_preview(name):
    """这张已经正式下载了，临时预览没用了。"""
    for p in (preview_path(name), _preview_cape_path(name)):
        if p and os.path.isfile(p):
            try:
                os.remove(p)
            except OSError:
                pass


def clear_previews(keep_names=()):
    """清掉当前不再显示、也没下载的临时预览，返回删掉的文件数。"""
    keep = set()
    for n in keep_names:
        for p in (preview_path(n), _preview_cape_path(n)):
            if p:
                keep.add(os.path.basename(p))
    removed = 0
    try:
        for fn in os.listdir(preview_dir()):
            if fn in keep or not fn.lower().endswith(".png"):
                continue
            try:
                os.remove(os.path.join(preview_dir(), fn))
                removed += 1
            except OSError:
                pass
    except OSError:
        pass
    return removed


def safe_name(name):
    name = (name or "").strip()
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name)
    return name[:64] or "unnamed"


# ------------------------------------------------------------------ 索引
def _index_path():
    return os.path.join(store_dir(), _INDEX_NAME)


def load_index():
    try:
        with open(_index_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_index(data):
    try:
        with open(_index_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _entry_key(name):
    return (name or "").strip().lower()


def item_path(name, kind):
    """kind: skin / cape，返回该名字在这台机器上的缓存文件路径。"""
    return os.path.join(store_dir(), "%s_%s.png" % (safe_name(name), kind))


# ------------------------------------------------------------------ 网络
def _is_png(data):
    return len(data) > 64 and data[:8] == b"\x89PNG\r\n\x1a\n"


def _png_size(data):
    try:
        if data[12:16] != b"IHDR":
            return (0, 0)
        w = int.from_bytes(data[16:20], "big")
        h = int.from_bytes(data[20:24], "big")
        return (w, h)
    except Exception:
        return (0, 0)


def _valid_kind(data, kind):
    if not _is_png(data):
        return False
    w, h = _png_size(data)
    if kind == "skin":
        return (w, h) in ((64, 64), (64, 32), (128, 128))
    return w >= 16 and h >= 8


def _download_png(url):
    for attempt in range(2):
        try:
            data = http._read_url(url, "official", 12, 2)
            if _is_png(data):
                return data
        except Exception:
            time.sleep(0.4)
    return None


def _uuid_lookup(name):
    """查正版档案：返回 ('ok', uuid) / ('notfound', None) / ('error', None)。"""
    url = _UUID_URL.format(urllib.parse.quote((name or "").strip()))
    last = None
    for attempt in range(2):
        try:
            with http.open_url(url, "official", 5) as resp:
                body = resp.read()
            if not body:
                return ("notfound", None)
            data = json.loads(body.decode("utf-8", "replace"))
            uid = data.get("id") if isinstance(data, dict) else ""
            return ("ok", uid) if uid else ("notfound", None)
        except urllib.error.HTTPError as e:
            if e.code in (204, 404):
                return ("notfound", None)
            last = e
        except Exception as e:
            last = e
        time.sleep(0.5 * (attempt + 1))
    return ("error", last)


def _mojang_textures(name):
    """走 Mojang 官方档案，返回 (status, {'skin': url, 'cape': url})。"""
    status, uid = _uuid_lookup(name)
    if status != "ok":
        return status, None
    try:
        raw = http._read_url(_SESSION_URL.format(uid), "official", 10, 2)
        prof = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return "error", None
    props = (prof or {}).get("properties") or []
    if not props:
        return "error", None
    try:
        tex = json.loads(base64.b64decode(props[0].get("value") or "").decode("utf-8", "replace"))
    except Exception:
        return "error", None
    found = {}
    for kind, key in (("skin", "SKIN"), ("cape", "CAPE")):
        url = ((tex.get("textures") or {}).get(key) or {}).get("url") or ""
        if url:
            found[kind] = url.replace("http://", "https://")
    return "ok", found


def _littleskin_textures(name):
    """国内皮肤站 LittleSkin：支持中文名，返回 (status, {'skin':url,'cape':url})。"""
    name = (name or "").strip()
    if not name:
        return "notfound", None
    try:
        data = http.post_json(LS_PROFILES, [name], timeout=8,
                              mirror="official", retries=2)
    except Exception:
        return "error", None
    if not data:
        return "notfound", None
    uid = ""
    if isinstance(data, list) and data:
        uid = str((data[0] or {}).get("id") or "")
    elif isinstance(data, dict):
        uid = str(data.get("id") or "")
    if not uid:
        return "notfound", None
    try:
        raw = http._read_url(LS_PROFILE % uid, "official", 8, 2)
        prof = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return "error", None
    props = (prof or {}).get("properties") or []
    if not props:
        return "notfound", None
    try:
        tex = json.loads(base64.b64decode(props[0].get("value") or "").decode("utf-8", "replace"))
    except Exception:
        return "error", None
    found = {}
    for kind, key in (("skin", "SKIN"), ("cape", "CAPE")):
        url = ((tex.get("textures") or {}).get(key) or {}).get("url") or ""
        if url:
            if url.startswith("/"):
                url = LS_BASE + url
            found[kind] = url.replace("http://", "https://")
    if not found:
        return "notfound", None
    return "ok", found


def _try_sources(name, kind, log=None):
    for url, timeout, retries in (_SKIN_SOURCES if kind == "skin" else _CAPE_SOURCES):
        target = url.format(urllib.parse.quote(name))
        try:
            data = http._read_url(target, "official", timeout, retries)
            if _valid_kind(data, kind):
                return data
        except Exception:
            continue
    return None


def _use_tex(tex, src):
    """下载皮肤/披风 PNG，成功返回 (ok, skin, cape, src)。"""
    skin = _download_png(tex["skin"])
    cape = _download_png(tex["cape"]) if tex.get("cape") else None
    if skin:
        return "ok", skin, cape, src
    return None


def _fetch_both(name, log=None):
    """返回 (status, skin_bytes, cape_bytes, source)；status 为 ok / notfound / error。

    两个可信源并发查：Mojang 官方档案（国际正版，皮肤+披风信息最全）和 LittleSkin
    （国内皮肤站，支持中文名）。哪路先给出皮肤就用哪路——实测 Mojang 走国际链路要
    6 秒多，LittleSkin 只要 0.5 秒；国内站先回来时再给官方 0.6 秒窗口，官方能在这么
    短时间里回来就仍然优先官方，超时就用国内站的结果，不再白等。
    """
    from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

    ex = ThreadPoolExecutor(max_workers=2)
    fm = ex.submit(_mojang_textures, name)
    fl = ex.submit(_littleskin_textures, name)
    pending = {fm, fl}
    got = {}

    def _good(entry):
        return (entry and entry[0] == "ok" and entry[1]
                and entry[1].get("skin"))

    while pending:
        done, pending = wait(pending, timeout=13, return_when=FIRST_COMPLETED)
        if not done:
            break
        for f in done:
            try:
                st, tex = f.result()
            except Exception:
                st, tex = "error", None
            got[f] = (st, tex)
            if not _good(got[f]):
                continue
            if f is fl and fm not in got:
                # 国内站先回来，给官方一个很短的窗口，官方能用就换官方
                try:
                    got[fm] = fm.result(timeout=0.6)
                except Exception:
                    got[fm] = ("error", None)
                pending.discard(fm)
                if _good(got[fm]):
                    ex.shutdown(wait=False)
                    r = _use_tex(got[fm][1], "mojang")
                    if r:
                        return r
                ex.shutdown(wait=False)
                r = _use_tex(tex, "littleskin")
                if r:
                    return r
                continue
            ex.shutdown(wait=False)
            r = _use_tex(tex, "mojang" if f is fm else "littleskin")
            if r:
                return r

    ex.shutdown(wait=False)
    statuses = [v[0] for v in got.values()]
    if "ok" in statuses:
        return "notfound", None, None, ""
    if statuses and all(s == "error" for s in statuses):
        return "error", None, None, ""
    return "notfound", None, None, ""


def _fetch(name, kind):
    """按源顺序拉一张 PNG，返回 bytes 或 None。"""
    status, skin, cape, _src = _fetch_both(name, None)
    return skin if kind == "skin" else cape


def _write(path, data):
    try:
        with open(path, "wb") as f:
            f.write(data)
        return True
    except Exception:
        return False


def _refresh_record(name, force=False, want_cape=True, log=None, retry_bad=False):
    name = (name or "").strip()
    if not name:
        return {"name": name, "skin": "", "cape": "", "status": "error"}
    skin_path = item_path(name, "skin")
    cape_path = item_path(name, "cape")
    idx = load_index()
    rec = idx.get(_entry_key(name)) or {}
    have = {"name": name,
            "skin": skin_path if os.path.isfile(skin_path) else "",
            "cape": cape_path if (want_cape and os.path.isfile(cape_path)) else ""}
    if not force and have["skin"]:
        age = time.time() - (rec.get("skin_ts") or 0)
        if age < _STALE_SECONDS:
            have["status"] = "ok"
            return have
    if not force and rec.get("bad_ts") and not retry_bad:
        if time.time() - rec["bad_ts"] < _BAD_SECONDS:
            if log:
                log("%s 在正版档案里查过了，没有这个玩家" % name)
            have["status"] = "notfound"
            return have
    status, skin, cape, source = _fetch_both(name, log)
    if status == "notfound":
        rec["bad_ts"] = int(time.time())
        rec["name"] = name
        idx[_entry_key(name)] = rec
        save_index(idx)
        if log:
            log("没有找到叫 %s 的正版玩家（正版 ID 要和游戏里完全一致，包括大小写和 _）" % name)
        have["status"] = "notfound"
        return have
    if not skin:
        if log:
            log("没拿到 %s 的皮肤，网络好像不太行，稍后再试一次" % name)
        have["status"] = "error"
        return have
    ok = _write(skin_path, skin)
    rec["skin_ts"] = int(time.time())
    rec["name"] = name
    rec["source"] = source
    rec.pop("bad_ts", None)
    if want_cape:
        if cape:
            _write(cape_path, cape)
            rec["cape_ts"] = int(time.time())
        else:
            rec["cape_ts"] = int(time.time())   # 记录"查过、没披风"
    idx[_entry_key(name)] = rec
    save_index(idx)
    have["skin"] = skin_path if ok else ""
    have["cape"] = cape_path if (want_cape and cape) else ""
    have["status"] = "ok" if ok else "error"
    have["source"] = source
    return have


def fetch_one(name, kind="skin", force=False, log=None):
    """拉取并写缓存，返回本地路径或空串。force=True 时忽略新鲜缓存。"""
    rec = _refresh_record(name, force=force, want_cape=(kind != "skin") or True, log=log)
    return rec.get("skin") if kind == "skin" else rec.get("cape")


def ensure_item(name, want_cape=True, log=None, retry_bad=False):
    """保证某个名字的皮肤（和披风）落盘，返回 dict。retry_bad=True 时忽略「查过了没有」。"""
    return _refresh_record(name, force=False, want_cape=want_cape, log=log,
                           retry_bad=retry_bad)


# ------------------------------------------------------------------ 搜索/列表
def _star_rows(keyword=""):
    kw = (keyword or "").strip().lower()
    rows = []
    for label, qname, group in STARS:
        hay = ("%s %s %s" % (label, qname, group)).lower()
        if kw and kw not in hay:
            continue
        sp = item_path(qname, "skin")
        cp = item_path(qname, "cape")
        rows.append({
            "name": qname,
            "label": label,
            "group": group,
            "source": "star",
            "skin": sp if os.path.isfile(sp) else "",
            "cape": cp if os.path.isfile(cp) else "",
            "featured": label in FEATURED,
        })
    return rows


def _local_rows(keyword=""):
    """已下载到本机皮肤库 + 设置页导入的皮肤。"""
    kw = (keyword or "").strip().lower()
    rows = []
    seen = set()
    idx = load_index()
    for key, rec in idx.items():
        name = rec.get("name") or key
        if kw and kw not in name.lower() and kw not in key:
            continue
        skin = item_path(name, "skin")
        cape = item_path(name, "cape")
        if not os.path.isfile(skin):
            continue
        seen.add(skin)
        rows.append({
            "name": name,
            "label": name,
            "group": "已下载",
            "source": "online",
            "skin": skin,
            "cape": cape if os.path.isfile(cape) else "",
        })
    # 设置页导入的本地皮肤
    try:
        for f in os.listdir(local_skins_dir()):
            if not f.lower().endswith(".png"):
                continue
            if kw and kw not in f.lower():
                continue
            path = os.path.join(local_skins_dir(), f)
            if path in seen:
                continue
            rows.append({
                "name": os.path.splitext(f)[0],
                "label": os.path.splitext(f)[0],
                "group": "本地导入",
                "source": "local",
                "skin": path,
                "cape": "",
            })
    except Exception:
        pass
    return rows


def search(keyword="", limit=400):
    """本地 + 内置名单合并搜索（不打网络，保证秒回）。

    关键词按空格拆成多个词，要求每个词都命中（名字、显示名、分组任意一处），
    这样「sw 主播」这种随手打的两个词也能筛出来。
    """
    words = [w for w in (keyword or "").lower().split() if w]
    rows = _local_rows("") + _star_rows("")
    if words:
        def hay(r):
            return ("%s %s %s" % (r.get("label") or "", r.get("name") or "",
                                 r.get("group") or "")).lower()
        rows = [r for r in rows if all(w in hay(r) for w in words)]
    # 同名的以内置名单为准（它有中文显示名）
    merged = {}
    for r in rows:
        merged.setdefault(r["name"].lower(), r)
    return list(merged.values())[:limit]


# ---------- 收藏（本地 JSON，收藏过的排在最前面）
def _fav_path():
    return os.path.join(config.app_dir(), "skin_favorites.json")


def load_favorites():
    try:
        with open(_fav_path(), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return set(str(x) for x in data if x)
    except Exception:
        pass
    return set()


def save_favorites(names):
    try:
        os.makedirs(config.app_dir(), exist_ok=True)
        with open(_fav_path(), "w", encoding="utf-8") as f:
            json.dump(sorted(names), f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def is_favorite(name):
    if not name:
        return False
    low = (name or "").lower()
    return any(low == n.lower() for n in load_favorites())


def toggle_favorite(name):
    """收藏 / 取消收藏，返回操作后是否处于收藏状态。"""
    favs = load_favorites()
    hit = None
    for n in favs:
        if n.lower() == (name or "").lower():
            hit = n
            break
    if hit is None:
        favs.add(name)
        save_favorites(favs)
        return True
    favs.discard(hit)
    save_favorites(favs)
    return False


def all_groups():
    return ["已下载", "本地导入", "国际主播", "HermitCraft", "经典"]


def download_missing(names, log=None, want_cape=True, limit=8):
    """按名单顺序补齐没下载过的条目，返回新下载成功的名字列表。"""
    done = []
    for name in names:
        if len(done) >= limit:
            break
        if os.path.isfile(item_path(name, "skin")):
            continue
        rec = ensure_item(name, want_cape=want_cape, log=log)
        if rec.get("skin"):
            done.append(name)
            if log:
                log("已加入皮肤库：%s" % name)
    return done


# ------------------------------------------------------------------ 穿搭
def _sha1_file(path):
    try:
        h = hashlib.sha1()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def fingerprint(skin_path, cape_path=""):
    key = _sha1_file(skin_path)
    if not key:
        return ""
    if cape_path and os.path.isfile(cape_path):
        key += "|" + _sha1_file(cape_path)
    else:
        key += "|nocape"
    return key


def list_outfits():
    """返回已保存的穿搭，按保存时间倒序。"""
    rows = []
    root = outfits_root()
    try:
        dirs = [d for d in os.listdir(root)
                if os.path.isdir(os.path.join(root, d))]
    except Exception:
        return rows
    for d in dirs:
        meta_path = os.path.join(root, d, "meta.json")
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            continue
        skin = os.path.join(root, d, "skin.png")
        cape = os.path.join(root, d, "cape.png")
        rows.append({
            "name": meta.get("name") or d,
            "dir": os.path.join(root, d),
            "key": meta.get("key", ""),
            "skin": skin if os.path.isfile(skin) else "",
            "cape": cape if os.path.isfile(cape) else "",
            "created": meta.get("created", 0),
            "source": meta.get("source", ""),
        })
    rows.sort(key=lambda r: r.get("created") or 0, reverse=True)
    return rows


def outfit_name_exists(name):
    name = (name or "").strip()
    if not name:
        return False
    return os.path.isdir(os.path.join(outfits_root(), safe_name(name)))


def save_outfit(name, skin_path, cape_path="", source=""):
    """保存穿搭。同名、同款都会拒绝。返回 (ok, 消息)。"""
    name = (name or "").strip()
    if not name:
        return False, "先给这套穿搭起个名字"
    if not skin_path or not os.path.isfile(skin_path):
        return False, "没有可保存的皮肤"
    key = fingerprint(skin_path, cape_path)
    if not key:
        return False, "皮肤文件读不出来"
    for o in list_outfits():
        if o.get("key") == key:
            return False, "这套穿搭已经存过了（叫「%s」），同款不能重复保存" % o["name"]
        if o["name"].strip() == name:
            return False, "已经有一套叫「%s」的穿搭了，换个名字" % name
    dest_dir = os.path.join(outfits_root(), safe_name(name))
    try:
        os.makedirs(dest_dir, exist_ok=True)
        with open(skin_path, "rb") as src, open(os.path.join(dest_dir, "skin.png"), "wb") as dst:
            dst.write(src.read())
        if cape_path and os.path.isfile(cape_path):
            with open(cape_path, "rb") as src, open(os.path.join(dest_dir, "cape.png"), "wb") as dst:
                dst.write(src.read())
        meta = {
            "name": name,
            "key": key,
            "created": int(time.time()),
            "source": source,
            "skin_sha1": _sha1_file(os.path.join(dest_dir, "skin.png")),
        }
        with open(os.path.join(dest_dir, "meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception as e:
        return False, "保存失败：%s" % e
    return True, "已保存穿搭「%s」" % name


def open_outfits_dir():
    return platform_utils.open_path(outfits_root())


# ------------------------------------------------------------------ 应用到游戏
CSL_DIRNAME = "CustomSkinLoader"


def _csl_conf(game_dir):
    return os.path.join(game_dir, CSL_DIRNAME, CSL_DIRNAME + ".json")


def write_local_skin(game_dir, player_name, skin_path, cape_path=""):
    """把皮肤/披风写进 CustomSkinLoader 的本地皮肤目录。"""
    base = os.path.join(game_dir, CSL_DIRNAME, "LocalSkin")
    written = []
    if skin_path and os.path.isfile(skin_path):
        for sub in ("skin", "skins"):
            d = os.path.join(base, sub)
            os.makedirs(d, exist_ok=True)
            dest = os.path.join(d, safe_name(player_name) + ".png")
            try:
                with open(skin_path, "rb") as src, open(dest, "wb") as dst:
                    dst.write(src.read())
                written.append(dest)
            except Exception:
                pass
    if cape_path and os.path.isfile(cape_path):
        for sub in ("cape", "capes"):
            d = os.path.join(base, sub)
            os.makedirs(d, exist_ok=True)
            dest = os.path.join(d, safe_name(player_name) + ".png")
            try:
                with open(cape_path, "rb") as src, open(dest, "wb") as dst:
                    dst.write(src.read())
                written.append(dest)
            except Exception:
                pass
    # 没有披风就删掉旧披风，避免与上一套混搭
    if not (cape_path and os.path.isfile(cape_path)):
        for sub in ("cape", "capes"):
            dest = os.path.join(base, sub, safe_name(player_name) + ".png")
            try:
                if os.path.isfile(dest):
                    os.remove(dest)
            except Exception:
                pass
    return written


def write_csl_config(game_dir):
    """确保 CustomSkinLoader 的配置里启用了本地皮肤。"""
    conf = _csl_conf(game_dir)
    data = {}
    if os.path.isfile(conf):
        try:
            with open(conf, "r", encoding="utf-8") as f:
                data = json.load(f) or {}
        except Exception:
            data = {}
    loadlist = data.get("loadlist")
    if not isinstance(loadlist, list):
        loadlist = []
    if not any(isinstance(x, dict) and x.get("type") == "LocalSkin" for x in loadlist):
        loadlist.insert(0, {
            "name": "LocalSkin",
            "type": "LocalSkin",
            "root": CSL_DIRNAME + "/LocalSkin/",
        })
    data["loadlist"] = loadlist
    data.setdefault("enableCape", True)
    data.setdefault("enableSkin", True)
    data.setdefault("enableTransparentSkin", True)
    data.setdefault("enableDynamicSkull", True)
    data.setdefault("forceLoadAllTextures", True)
    try:
        os.makedirs(os.path.join(game_dir, CSL_DIRNAME), exist_ok=True)
        with open(conf, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        return ""
    return conf


def has_local_skin_mod(game_dir):
    d = os.path.join(game_dir, "mods")
    try:
        for f in os.listdir(d):
            low = f.lower()
            if low.endswith(".jar") and "customskinloader" in low.replace(" ", ""):
                return os.path.join(d, f)
    except Exception:
        pass
    return ""
