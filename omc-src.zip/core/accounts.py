# -*- coding: utf-8 -*-
"""本地多账号系统。

一个设备上可以有很多账号，每个账号可以各自绑一套游戏身份
（离线昵称 / 微软正版 / 第三方外置登录），登录后启动游戏直接复用，
不用每次再输一遍。

数据全在本机：~/.simple_mc_launcher/accounts.json
用户名在本机唯一（不区分大小写），邮箱只能绑定一个账号。
"""
import base64
import hashlib
import json
import os
import string
import time
import uuid

PBKDF_ROUNDS = 120000
KINDS = (("offline", "离线账号"), ("msa", "微软正版"), ("third", "第三方登录"))


def store_path():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "accounts.json")


def _read():
    p = store_path()
    if not os.path.isfile(p):
        return {"v": 1, "users": [], "current": "", "remember": {}}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("users", [])
        data.setdefault("current", "")
        data.setdefault("remember", {})
        data["v"] = 1
        return data
    except Exception:
        return {"v": 1, "users": [], "current": "", "remember": {}}


def _write(data):
    p = store_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


# ---------- 口令 ----------
def _hash(pwd, salt=None):
    salt = salt or uuid.uuid4().hex[:16]
    raw = hashlib.pbkdf2_hmac("sha256", (pwd or "").encode("utf-8"),
                              salt.encode("utf-8"), PBKDF_ROUNDS)
    return salt, raw.hex()


def _obf(text):
    """记住的密码做一层混淆，避免直接摆在文件里被一眼看到。"""
    key = (os.environ.get("COMPUTERNAME", "") + "|" +
           os.environ.get("USERNAME", "") + "|omc-account")
    kb = hashlib.sha256(key.encode("utf-8")).digest()
    raw = bytes(b ^ kb[i % len(kb)] for i, b in enumerate((text or "").encode("utf-8")))
    return base64.b64encode(raw).decode("ascii")


def _unobf(text):
    key = (os.environ.get("COMPUTERNAME", "") + "|" +
           os.environ.get("USERNAME", "") + "|omc-account")
    kb = hashlib.sha256(key.encode("utf-8")).digest()
    try:
        raw = base64.b64decode((text or "").encode("ascii"))
    except Exception:
        return ""
    return bytes(b ^ kb[i % len(kb)] for i, b in enumerate(raw)).decode("utf-8", "replace")


# ---------- 查询 ----------
def users():
    return _read().get("users") or []


def find(key):
    key = (key or "").strip().lower()
    if not key:
        return None
    for u in users():
        if (u.get("name") or "").lower() == key or (u.get("email") or "").lower() == key:
            return u
    return None


def name_taken(name):
    name = (name or "").strip().lower()
    return any((u.get("name") or "").lower() == name for u in users())


def email_taken(email):
    email = (email or "").strip().lower()
    return any((u.get("email") or "").lower() == email for u in users())


def current_name():
    return (_read().get("current") or "").strip()


def current_user():
    n = current_name()
    return find(n) if n else None


def remember_of(name):
    return (_read().get("remember") or {}).get(name) or {}


def remembered_accounts():
    """下次可以自动登录的账号（勾了记住密码的）。"""
    data = _read()
    out = []
    for name, item in (data.get("remember") or {}).items():
        if item.get("password"):
            out.append({"name": name, "auto": bool(item.get("auto", True))})
    return out


# ---------- 密码规则 ----------
_PUNCT = set(string.punctuation)


def check_password(pwd):
    """密码规则：至少 6 位、必须有数字、必须有符号、不能有中文/空格。

    返回空字符串表示通过，否则是给人看的原因。
    """
    if not pwd:
        return "密码不能空"
    if len(pwd) < 6:
        return "密码至少 6 位"
    for c in pwd:
        if ord(c) > 126 or c.isspace():
            return "密码只能用英文字母、数字和符号，不能有中文或空格"
    if not any(c.isdigit() for c in pwd):
        return "密码里必须有数字"
    if not any(c in _PUNCT for c in pwd):
        return "密码里必须有符号（例如 ! @ # $ % & *）"
    return ""


# ---------- 校验 ----------
def check_register(name, email, password, password2):
    name = (name or "").strip()
    email = (email or "").strip()
    if not name:
        return "用户名不能空"
    if len(name) < 2 or len(name) > 16:
        return "用户名要 2-16 个字符"
    if not all(c.isalnum() or c in "_-" for c in name):
        return "用户名只能用字母、数字、下划线、短横线"
    if name_taken(name):
        return "这个用户名已经有人用了"
    if not email or "@" not in email or "." not in email.split("@")[-1]:
        return "邮箱格式不对"
    if email_taken(email):
        return "这个邮箱已经注册过了"
    err = check_password(password)
    if err:
        return err
    if password != password2:
        return "两次输入的密码不一样"
    return ""


def register(name, email, password, via="password"):
    name = (name or "").strip()
    email = (email or "").strip()
    err = check_register(name, email, password, password)
    if err:
        return False, err
    data = _read()
    salt, h = _hash(password)
    data.setdefault("users", []).append({
        "id": uuid.uuid4().hex[:12],
        "name": name,
        "email": email,
        "salt": salt,
        "hash": h,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "via": via or "password",
        "binds": {},
    })
    data["current"] = name
    _write(data)
    return True, name


def verify_password(name, pwd):
    """给注销这类危险操作用的：只校验密码对不对，不改任何状态。"""
    u = find(name)
    if not u:
        return False, "没有这个账号"
    if not pwd:
        return False, "密码不能空"
    salt, h = _hash(pwd, u.get("salt") or "")
    if h != u.get("hash"):
        return False, "密码不对"
    return True, ""


def via_of(name):
    """这个账号是怎么来的：password / phone / qq / wechat / qq_qr。"""
    u = find(name)
    if not u:
        return ""
    return u.get("via") or "password"


def set_via(name, via):
    u = find(name)
    if not u:
        return False
    data = _read()
    for it in data.get("users") or []:
        if (it.get("name") or "") == name:
            it["via"] = via
            break
    _write(data)
    return True


def email_of(name):
    u = find(name)
    return (u or {}).get("email") or ""


def login(key, password, remember=False, auto=False):
    u = find(key)
    if not u:
        return False, "没有这个账号"
    salt, h = _hash(password, u.get("salt") or "")
    if h != u.get("hash"):
        return False, "密码不对"
    data = _read()
    data["current"] = u.get("name") or ""
    if remember:
        data.setdefault("remember", {})[u.get("name") or ""] = {
            "password": _obf(password),
            "auto": bool(auto),
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
    _write(data)
    return True, u.get("name") or ""


def quick_login(name):
    """勾了记住密码的账号：不用再输密码直接上。"""
    item = remember_of(name)
    pwd = _unobf(item.get("password") or "")
    u = find(name)
    if not u or not pwd:
        return False, "没有记住这个账号的密码"
    salt, h = _hash(pwd, u.get("salt") or "")
    if h != u.get("hash"):
        return False, "记住的密码已经失效，请手动登录一次"
    data = _read()
    data["current"] = u.get("name") or ""
    _write(data)
    return True, u.get("name") or ""


def code_login(name, email="", via=""):
    """手机号 / QQ 号 + 验证码登录：本机还没有这个账号就自动建一个。

    验证码已经由上层校验过（手机号走本机码，QQ 号走 QQ 邮箱），
    所以这里不再要密码；新账号会给一个随机密码，之后也能用密码登录。
    返回 (ok, 账号名, 是否新建)。
    """
    name = (name or "").strip()
    email = (email or "").strip()
    if not name:
        return False, "号码是空的", False
    u = find(name) or (find(email) if email else None)
    if u:
        if via:
            set_via(u.get("name") or "", via)
        data = _read()
        data["current"] = u.get("name") or ""
        _write(data)
        return True, u.get("name") or "", False
    pwd = "OMC%s8!" % uuid.uuid4().hex[:6]
    ok, msg = register(name, email or "%s@omc.local" % name, pwd,
                       via=via or "phone")
    if not ok:
        return False, msg, False
    data = _read()
    data["current"] = name
    data.setdefault("remember", {})[name] = {
        "password": _obf(pwd),
        "auto": False,
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    _write(data)
    return True, name, True


def logout():
    data = _read()
    data["current"] = ""
    _write(data)


def change_password(name, old, new, new2):
    u = find(name)
    if not u:
        return False, "没有这个账号"
    salt, h = _hash(old, u.get("salt") or "")
    if h != u.get("hash"):
        return False, "旧密码不对"
    err = check_password(new)
    if err:
        return False, err.replace("密码", "新密码", 1)
    if new != new2:
        return False, "两次输入的新密码不一样"
    data = _read()
    for item in data.get("users", []):
        if item.get("name") == u.get("name"):
            item["salt"], item["hash"] = _hash(new)
            break
    rem = (data.get("remember") or {}).get(u.get("name") or "")
    if rem:
        rem["password"] = _obf(new)
    _write(data)
    return True, "密码已修改"


def forget_password(name):
    data = _read()
    (data.get("remember") or {}).pop(name, None)
    _write(data)


def delete_account(name):
    data = _read()
    data["users"] = [u for u in data.get("users", []) if u.get("name") != name]
    (data.get("remember") or {}).pop(name, None)
    if data.get("current") == name:
        data["current"] = ""
    _write(data)


# ---------- 绑定游戏身份 ----------
def get_bind(name, kind):
    u = find(name)
    if not u:
        return None
    return (u.get("binds") or {}).get(kind)


def bind(name, kind, payload):
    u = find(name)
    if not u:
        return False
    data = _read()
    for item in data.get("users", []):
        if item.get("name") == u.get("name"):
            item.setdefault("binds", {})[kind] = payload
            break
    _write(data)
    return True


def unbind(name, kind):
    u = find(name)
    if not u:
        return False
    data = _read()
    for item in data.get("users", []):
        if item.get("name") == u.get("name"):
            (item.get("binds") or {}).pop(kind, None)
            break
    _write(data)
    return True


def binds_of(name):
    u = find(name)
    return (u or {}).get("binds") or {}


def kind_label(kind):
    for k, label in KINDS:
        if k == kind:
            return label
    return kind


def bind_label(kind, payload):
    """把一条绑定排成一行说明。"""
    if not payload:
        return "没有绑定"
    if kind == "offline":
        return "离线昵称：" + str(payload.get("name") or "")
    if kind == "msa":
        return "%s（%s）" % (payload.get("name") or "", payload.get("uuid") or "")
    if kind == "third":
        return "%s @ %s" % (payload.get("name") or "", payload.get("api") or "")
    return ""


# ---------- 改用户名（每台设备每天一次）----------
def can_rename(name):
    """(能不能改, 说明)。已经改过就提示明天再来。"""
    u = find(name)
    if not u:
        return False, "没有这个账号"
    today = time.strftime("%Y-%m-%d")
    if (u.get("renamed_on") or "") == today:
        return False, "今天已经改过一次了，明天再改"
    return True, "今天还能改一次"


def rename(name, new_name):
    """每台设备每个账号每天只能改一次用户名。"""
    u = find(name)
    if not u:
        return False, "没有这个账号"
    ok, why = can_rename(name)
    if not ok:
        return False, why
    new_name = (new_name or "").strip()
    if not new_name:
        return False, "新用户名不能空"
    if len(new_name) < 2 or len(new_name) > 16:
        return False, "用户名要 2-16 个字符"
    if not all(c.isalnum() or c in "_-" for c in new_name):
        return False, "用户名只能用字母、数字、下划线、短横线"
    if new_name.lower() == (u.get("name") or "").lower():
        return False, "跟现在的一样，不用改"
    if name_taken(new_name):
        return False, "这个名字已经有人用了"
    data = _read()
    old = u.get("name") or ""
    for item in data.get("users", []):
        if item.get("name") == old:
            item["name"] = new_name
            item["renamed_on"] = time.strftime("%Y-%m-%d")
            item["renamed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            break
    rem = data.get("remember") or {}
    if old in rem:
        rem[new_name] = rem.pop(old)
    if data.get("current") == old:
        data["current"] = new_name
    _write(data)
    return True, "用户名已改成 %s" % new_name


# ---------- 导出 / 导入备份 ----------
def export_backup(path, password):
    """把本机全部账号加密导出。密码错/空则返回 (False, 说明)。"""
    if not password or len(password) < 4:
        return False, "备份口令至少 4 位"
    data = _read()
    payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
    salt = os.urandom(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 60000)
    stream = hashlib.sha256(key + b"omc-acc-backup").digest()
    ct = bytearray()
    for i, b in enumerate(payload):
        if i and i % 32 == 0:
            stream = hashlib.sha256(stream + b"x").digest()
        ct.append(b ^ stream[i % 32])
    blob = {
        "v": 1,
        "app": "omc-account-backup",
        "kdf": "pbkdf2-sha256-60000",
        "salt": salt.hex(),
        "data": base64.b64encode(bytes(ct)).decode("ascii"),
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "count": len(data.get("users") or []),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(blob, f, ensure_ascii=False, indent=2)
    return True, "已导出 %d 个账号" % blob["count"]


def import_backup(path, password, merge=True):
    """导入备份。同名账号跳过；返回 (ok, 说明)。"""
    try:
        with open(path, encoding="utf-8") as f:
            blob = json.load(f)
    except Exception as e:
        return False, "读不了这个文件：%s" % e
    if blob.get("app") != "omc-account-backup":
        return False, "这不是账号备份文件"
    try:
        salt = bytes.fromhex(blob.get("salt") or "")
        ct = base64.b64decode(blob.get("data") or "")
    except Exception:
        return False, "备份文件内容坏了"
    key = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"), salt, 60000)
    stream = hashlib.sha256(key + b"omc-acc-backup").digest()
    pt = bytearray()
    for i, b in enumerate(ct):
        if i and i % 32 == 0:
            stream = hashlib.sha256(stream + b"x").digest()
        pt.append(b ^ stream[i % 32])
    try:
        src = json.loads(bytes(pt).decode("utf-8"))
    except Exception:
        return False, "口令不对，解不开"
    data = _read()
    added = skipped = 0
    for u in src.get("users") or []:
        n = (u.get("name") or "").strip()
        if not n:
            continue
        if any((x.get("name") or "").lower() == n.lower()
               for x in data.get("users") or []):
            skipped += 1
            continue
        data.setdefault("users", []).append(u)
        added += 1
    if not merge:
        data["users"] = src.get("users") or []
        added = len(data["users"])
        skipped = 0
    _write(data)
    return True, "导入 %d 个账号，跳过重名 %d 个" % (added, skipped)
