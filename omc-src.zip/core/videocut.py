# -*- coding: utf-8 -*-
"""录屏剪辑：用 PyAV（自带 ffmpeg 编解码库）把一段区间重编码导出。

Qt 的 QMediaRecorder 只能整体录，切不了帧，所以剪辑走 PyAV：
按秒数取帧、重新编 H264、写新的 mp4。av 放在工程的 _libs 里，
打包时随包带上，运行时先把那个目录塞进 sys.path。
"""
import os
import sys
from fractions import Fraction

_AV = None
_AV_ERROR = ""


def _libs_dir():
    """找出 av 所在目录：源码运行是工程根/_libs，打包后是 _internal/_libs。"""
    cands = []
    mei = getattr(sys, "_MEIPASS", None)
    if mei:
        cands.append(os.path.join(mei, "_libs"))
        cands.append(os.path.join(os.path.dirname(mei), "_libs"))
    here = os.path.dirname(os.path.abspath(__file__))
    cands.append(os.path.join(os.path.dirname(here), "_libs"))
    cands.append(os.path.join(os.path.dirname(sys.executable), "_libs"))
    for p in cands:
        if os.path.isdir(p):
            return p
    return ""


def av_module():
    global _AV, _AV_ERROR
    if _AV is not None:
        return _AV
    if _AV_ERROR:
        return None
    libs = _libs_dir()
    if libs and libs not in sys.path:
        sys.path.insert(0, libs)
    try:
        import av
        _AV = av
    except Exception as e:
        _AV_ERROR = "%s: %s" % (type(e).__name__, e)
        return None
    return _AV


def has_av():
    return av_module() is not None


def av_error():
    return _AV_ERROR


def probe(path):
    """读时长 / 分辨率 / 帧率，读不出来返回 None。"""
    av = av_module()
    if av is None:
        return None
    try:
        with av.open(path) as inp:
            vs = inp.streams.video[0]
            if vs.duration and vs.time_base:
                dur = float(vs.duration * vs.time_base)
            elif inp.duration:
                dur = float(inp.duration / av.time_base)
            else:
                dur = 0.0
            fps = 0.0
            for attr in ("average_rate", "guessed_rate"):
                r = getattr(vs, attr, None)
                if r:
                    fps = float(r)
                    break
            return {"duration": dur,
                    "width": int(vs.codec_context.width or 0),
                    "height": int(vs.codec_context.height or 0),
                    "fps": fps}
    except Exception:
        return None


def cut(src, dst, start, end, crf=23, on_progress=None):
    """把 src 的 [start, end) 秒重编码写成 dst。返回 (ok, 说明)。"""
    av = av_module()
    if av is None:
        return False, "剪辑组件不可用：%s" % _AV_ERROR
    start = max(0.0, float(start))
    end = float(end)
    if end <= start + 0.05:
        return False, "结束时间要在开始时间之后"
    try:
        with av.open(src) as inp, av.open(dst, "w") as out:
            vs = inp.streams.video[0]
            vs.thread_type = "AUTO"
            fps = 0.0
            for attr in ("average_rate", "guessed_rate"):
                r = getattr(vs, attr, None)
                if r:
                    fps = float(r)
                    break
            rate = Fraction(fps or 30).limit_denominator(1000)
            ost = out.add_stream("h264", rate=rate)
            ost.time_base = Fraction(1, 1) / rate
            ost.width = int(vs.codec_context.width)
            ost.height = int(vs.codec_context.height)
            ost.pix_fmt = "yuv420p"
            ost.options = {"crf": str(int(crf)), "preset": "veryfast"}

            span = end - start
            last_pct = -1
            idx = 0
            tb = Fraction(1, 1) / Fraction(rate)
            for frame in inp.decode(vs):
                t = frame.time
                if t is None:
                    continue
                if t < start:
                    continue
                if t >= end:
                    break
                # 帧号按固定时基重新编号，否则编码器把每帧当成同一时刻，
                # 写出来的文件时长只有一帧（实测 0.03 秒 / 1800fps）
                frame.pts = idx
                frame.time_base = tb
                idx += 1
                for pkt in ost.encode(frame):
                    out.mux(pkt)
                if on_progress is not None:
                    pct = int(min(100, ((t - start) / span) * 100))
                    if pct != last_pct:
                        last_pct = pct
                        try:
                            on_progress(pct)
                        except Exception:
                            pass
            for pkt in ost.encode():
                out.mux(pkt)
        if not os.path.isfile(dst) or os.path.getsize(dst) <= 0:
            return False, "导出没有写出文件"
        if on_progress is not None:
            try:
                on_progress(100)
            except Exception:
                pass
        return True, os.path.getsize(dst)
    except Exception as e:
        try:
            if os.path.isfile(dst):
                os.remove(dst)
        except Exception:
            pass
        return False, "剪辑失败：%s: %s" % (type(e).__name__, e)
