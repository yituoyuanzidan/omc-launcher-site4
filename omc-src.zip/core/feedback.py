# -*- coding: utf-8 -*-
"""匿名反馈：客户端直接发到公共收集通道，作者用收件箱工具收。

通道用 ntfy.sh 的公共发布/订阅接口——不需要注册、不需要邮箱、不需要任何登录，
POST 一条就是一条消息，作者那边按同一个主题名拉取。免费服务器只保留 12 小时，
所以收件箱工具会把拉到的内容落到本地库里累积，不会因为没及时打开而丢掉。
"""
import json
import os
import time
import urllib.request

BASE = "https://ntfy.sh"
# 主题名相当于收件箱的地址，客户端只知道"往哪发"
TOPIC = "omc-fb-9m3t7xw2q8rk"
MAX_BYTES = 3800          # 服务器单条上限 4096，留点余量


def _mask(text):
    """把用户目录和用户名换成占位符，反馈里别带别人的私人路径。"""
    s = text or ""
    try:
        home = os.path.expanduser("~")
        if home:
            s = s.replace(home, "%USER%")
            s = s.replace(home.replace("\\", "/"), "%USER%")
        for key in ("USERNAME", "USER"):
            user = os.environ.get(key) or ""
            if len(user) >= 3:
                s = s.replace(user, "%USER%")
    except Exception:
        pass
    return s


def build(kind, text, version, extra=None, log_tail="", app="OMC"):
    """组一条反馈（尽量短，超过上限就砍日志尾巴）。"""
    import platform as _pf
    import datetime as _dt
    base = {
        "v": 1,
        "app": app,
        "ver": str(version),
        "kind": _mask(kind)[:40],
        "time": _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "os": _mask(_pf.platform() + " " + _pf.release()),
        "text": _mask((text or "").strip())[:1800],
    }
    for k, v in (extra or {}).items():
        base[k] = _mask(str(v))[:220]

    lines = [ln for ln in _mask(log_tail or "").splitlines() if ln.strip()]
    for keep in (12, 8, 4, 2, 0):
        payload = dict(base)
        if keep:
            payload["log"] = "\n".join(lines[-keep:])[:1200]
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        if len(data.encode("utf-8")) <= MAX_BYTES:
            return payload
    return base


def submit(payload):
    """发一条匿名反馈，返回 (ok, 消息编号或错误说明)。"""
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    if len(data.encode("utf-8")) > MAX_BYTES:
        raise ValueError("反馈内容太长")
    body = json.dumps({
        "topic": TOPIC,
        "message": data,
        "title": "OMC feedback",
        "tags": ["speech_balloon"],
        "priority": 3,
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BASE + "/", data=body, method="POST",
        headers={"Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode("utf-8", "replace")
    try:
        j = json.loads(raw)
        return True, j.get("id") or ""
    except Exception:
        return True, ""


def fetch_all(since="all"):
    """拉服务器上现存的反馈（免费服务器只有最近 12 小时）。"""
    url = "%s/%s/json?poll=1&since=%s" % (BASE, TOPIC, since)
    with urllib.request.urlopen(url, timeout=25) as r:
        raw = r.read().decode("utf-8", "replace")
    out = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if ev.get("event") not in (None, "message"):
            continue
        msg = ev.get("message")
        if not msg:
            continue
        try:
            payload = json.loads(msg)
        except Exception:
            payload = {"v": 1, "app": "OMC", "ver": "", "kind": "",
                       "time": "", "text": msg, "raw": True}
        out.append({
            "id": ev.get("id") or "",
            "time": ev.get("time") or 0,
            "payload": payload,
        })
    return out


def inbox_dir():
    d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
    os.makedirs(d, exist_ok=True)
    return d


def inbox_path():
    return os.path.join(inbox_dir(), "feedback_inbox.jsonl")


def load_local():
    p = inbox_path()
    rows = []
    if not os.path.isfile(p):
        return rows
    seen = set()
    try:
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                key = row.get("id") or ""
                if key and key in seen:
                    continue
                seen.add(key)
                rows.append(row)
    except OSError:
        pass
    rows.sort(key=lambda r: (r.get("time") or 0), reverse=True)
    return rows


def sync_local():
    """把服务器上的反馈并入本地库，返回 (新增条数, 总数)。"""
    remote = fetch_all("all")
    rows = load_local()
    have = {r.get("id") for r in rows if r.get("id")}
    added = 0
    with open(inbox_path(), "a", encoding="utf-8") as f:
        for r in remote:
            if r.get("id") and r["id"] in have:
                continue
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            have.add(r.get("id") or "")
            added += 1
    return added, len(have)


def count_local():
    return len(load_local())


# 反馈状态：待排查 / 已处理 / 无效
STATUS_TEXT = {"todo": "待排查", "done": "已处理", "invalid": "无效"}


def status_path():
    return os.path.join(inbox_dir(), "feedback_status.json")


def load_status():
    p = status_path()
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def set_status(row_id, status):
    """给一条反馈打标记：todo=待排查 / done=已处理 / invalid=无效，空值就是清掉。"""
    rid = str(row_id or "").strip()
    if not rid:
        return False
    data = load_status()
    if status:
        data[rid] = {"status": str(status), "at": now_text()}
    else:
        data.pop(rid, None)
    try:
        with open(status_path(), "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


def status_of(row):
    rid = str((row or {}).get("id") or "").strip()
    return (load_status().get(rid) or {}).get("status") or ""


def status_text(row):
    return STATUS_TEXT.get(status_of(row), "待排查")


def as_text(row):
    """把一条反馈排成看的人能直接读的文本。"""
    p = row.get("payload") or {}
    lines = [
        "时间：" + str(p.get("time") or ""),
        "类型：" + str(p.get("kind") or ""),
        "版本：%s %s" % (p.get("app") or "OMC", p.get("ver") or ""),
        "系统：" + str(p.get("os") or ""),
        "状态：" + status_text(row),
    ]
    for k, label in (("game_dir", "游戏目录"), ("java", "Java"),
                     ("mem", "内存"), ("last_version", "当前版本"),
                     ("language", "界面语言")):
        if p.get(k):
            lines.append(label + "：" + str(p[k]))
    lines += ["", "内容：", str(p.get("text") or "（没写内容）")]
    if p.get("log"):
        lines += ["", "日志末尾：", str(p["log"])]
    if p.get("raw"):
        lines.append("（这条是旧格式，原文如下）")
    return "\n".join(lines)


def now_text():
    return time.strftime("%Y-%m-%d %H:%M:%S")
