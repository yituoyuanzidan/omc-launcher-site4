# -*- coding: utf-8 -*-
"""官方最新版本预告片：跟下载站清单同步，取到本地再播。

思路：
- 下载站页面里的 <meta name="omc-update"> 清单新增两个字段：
    "trailer": 预告片 mp4 直链（可留空）
    "trailer_ver": 这支片子对应哪个启动器版本（留空就用 latest）
- 启动时后台核对一次：清单里的地址和上次落地的不一样 → 下到
  ~/.simple_mc_launcher/trailer/<版本>.mp4，之后一直用本地文件播
- 清单里没有 / 下载失败 / 没网 → 回退到包内自带的 assets/trailer/trailer.mp4
"""
import json
import os
import sys

from .config import app_dir

META_NAME = "meta.json"
BUILTIN_NAME = "trailer.mp4"


def assets_dir():
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "assets")


def builtin_path():
    """包内自带的兜底预告片。"""
    p = os.path.join(assets_dir(), "trailer", BUILTIN_NAME)
    return p if os.path.exists(p) else ""


def cache_dir():
    d = os.path.join(app_dir(), "trailer")
    os.makedirs(d, exist_ok=True)
    return d


def _meta_path():
    return os.path.join(cache_dir(), META_NAME)


def _read_meta():
    try:
        with open(_meta_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_meta(d):
    try:
        with open(_meta_path(), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def cached():
    """上次落地的片子，返回 (路径, 版本号)；没有就给包内的。"""
    meta = _read_meta()
    f = meta.get("file") or ""
    if f and os.path.exists(f):
        return f, str(meta.get("version") or "")
    return builtin_path(), ""


def sync(progress=None, timeout=12):
    """核对清单并（必要时）下载最新预告片。

    返回 (本地路径, 版本号, 附加说明)。不会抛异常，最差退回内置片。
    """
    from . import update

    try:
        data = update.check(timeout=timeout)
    except Exception as e:
        p, ver = cached()
        return p, ver, "清单没拿到（%s），先用本地的" % e

    url = str(data.get("trailer") or "").strip()
    ver = str(data.get("trailer_ver") or data.get("latest") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        p, v = cached()
        return p, v, ("用的是内置官方预告片，官方发了新片会自动换上" if p
                      else "官方还没放预告片")

    meta = _read_meta()
    if (meta.get("url") == url and meta.get("version") == ver
            and os.path.exists(meta.get("file") or "")):
        return meta["file"], ver, "已是这个版本的预告片"

    dest = os.path.join(cache_dir(), "%s.mp4" % (ver or "latest"))
    try:
        from . import http
        http.download_file(url, dest, "official", progress=progress, retries=2)
    except Exception as e:
        p, v = cached()
        return p, v, "预告片下载失败（%s），先用内置的" % e

    _write_meta({"url": url, "version": ver, "file": dest})
    return dest, ver, "已同步官方最新预告片"
