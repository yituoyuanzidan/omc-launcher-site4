# -*- coding: utf-8 -*-
"""存档自动备份：把 saves 下的世界按时间戳复制到 backups，可保留最近 N 份并一键还原。

备份只复制，不移动、不删除原存档；还原时若同名已存在，会另起一个带后缀的名字，
避免覆盖玩家正在用的世界。
"""
import os
import shutil
import time


def backups_root(game_dir):
    d = os.path.join(game_dir, "backups")
    os.makedirs(d, exist_ok=True)
    return d


def saves_dir(game_dir):
    return os.path.join(game_dir, "saves")


def _stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def _dir_size_mb(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return round(total / 1048576.0, 1)


def list_worlds(game_dir):
    d = saves_dir(game_dir)
    if not os.path.isdir(d):
        return []
    return sorted(name for name in os.listdir(d)
                  if os.path.isdir(os.path.join(d, name))
                  and os.path.exists(os.path.join(d, name, "level.dat")))


def backup_world(game_dir, world, log=None):
    """备份单个存档，返回备份目录路径；存档不存在返回 None。"""
    log = log or (lambda _m: None)
    src = os.path.join(saves_dir(game_dir), world)
    if not os.path.isdir(src):
        return None
    dest = os.path.join(backups_root(game_dir), world, _stamp())
    n = 1
    while os.path.exists(dest):
        dest = os.path.join(backups_root(game_dir), world, _stamp() + "-%d" % n)
        n += 1
    os.makedirs(dest, exist_ok=True)
    shutil.copytree(src, dest, dirs_exist_ok=True)
    log("已备份存档 %s（%.1f MB）" % (world, _dir_size_mb(dest)))
    return dest


def backup_all(game_dir, keep=5, log=None):
    """备份全部存档并清理超出 keep 的旧备份，返回备份数量。"""
    log = log or (lambda _m: None)
    done = 0
    for world in list_worlds(game_dir):
        if backup_world(game_dir, world, log):
            done += 1
        prune(game_dir, world, keep, log)
    if done:
        log("本次自动备份完成：%d 个存档（每个保留最近 %d 份）" % (done, keep))
    return done


def prune(game_dir, world, keep=5, log=None):
    """只保留最近 keep 份备份（按目录名时间戳排序）。"""
    log = log or (lambda _m: None)
    root = os.path.join(backups_root(game_dir), world)
    if not os.path.isdir(root):
        return 0
    items = sorted(d for d in os.listdir(root)
                   if os.path.isdir(os.path.join(root, d)))
    extra = items[:-keep] if keep > 0 else []
    removed = 0
    for name in extra:
        _rm_tree(os.path.join(root, name))
        removed += 1
    if removed:
        log("已清理 %s 的 %d 份旧备份" % (world, removed))
    return removed


def _rm_tree(path):
    """备份是启动器自己生成的临时产物，这里允许递归清理。"""
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def list_backups(game_dir):
    """列出所有备份：[(world, stamp, path, size_mb)]，按时间倒序。"""
    root = backups_root(game_dir)
    rows = []
    if not os.path.isdir(root):
        return rows
    for world in os.listdir(root):
        wdir = os.path.join(root, world)
        if not os.path.isdir(wdir):
            continue
        for stamp in os.listdir(wdir):
            p = os.path.join(wdir, stamp)
            if os.path.isdir(p):
                rows.append((world, stamp, p, _dir_size_mb(p)))
    rows.sort(key=lambda r: (r[0], r[1]), reverse=True)
    return rows


def restore(game_dir, backup_path, log=None):
    """把备份复制回 saves，返回还原后的存档名。"""
    log = log or (lambda _m: None)
    if not os.path.isdir(backup_path):
        raise RuntimeError("备份目录不存在：%s" % backup_path)
    world = os.path.basename(os.path.dirname(backup_path))
    dest = os.path.join(saves_dir(game_dir), world)
    if os.path.exists(dest):
        i = 1
        while os.path.exists(os.path.join(saves_dir(game_dir),
                                          "%s_还原%d" % (world, i))):
            i += 1
        dest = os.path.join(saves_dir(game_dir), "%s_还原%d" % (world, i))
    os.makedirs(saves_dir(game_dir), exist_ok=True)
    shutil.copytree(backup_path, dest)
    name = os.path.basename(dest)
    log("已还原存档：" + name)
    return name
