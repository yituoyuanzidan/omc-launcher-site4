# -*- coding: utf-8 -*-
"""游戏内设置（options.txt）的读写。

启动器里给"新装的版本"预设一套游戏设置，装完写进 game_dir/options.txt。
只覆盖用户明确设过的项，其余保持游戏自己的默认值。
"""
import os

# (key, 中文名, 类型, 可选值/范围, 默认值)
#   类型 c=下拉  i=整数  b=开关  f=浮点
SPEC = [
    ("lang", "游戏语言（模组名/道具名也跟着变）", "c",
     ["zh_cn", "en_us", "zh_tw", "ja_jp", "ko_kr", "ru_ru", "de_de", "fr_fr"],
     "zh_cn"),
    ("renderDistance", "渲染距离（区块）", "i", (2, 32), 12),
    ("simulationDistance", "模拟距离（区块）", "i", (5, 32), 12),
    ("graphics", "图形质量", "c", ["fast", "fancy", "fabulous"], "fancy"),
    ("fov", "视野 FOV", "i", (30, 110), 70),
    ("gamma", "亮度", "f", (0.0, 1.0), 0.5),
    ("guiScale", "界面缩放（0=自动）", "i", (0, 4), 0),
    ("particles", "粒子效果", "c", ["all", "decreased", "minimal"], "all"),
    ("maxFps", "最大帧率（260=不限）", "i", (10, 260), 260),
    ("ao", "平滑光照 AO", "b", None, True),
    ("smoothLighting", "平滑光照（旧键）", "b", None, True),
    ("biomeBlendRadius", "生物群系过渡", "i", (0, 7), 2),
    ("entityShadows", "实体阴影", "b", None, True),
    ("clouds", "云", "c", ["true", "fast", "false"], "true"),
    ("mipmapLevels", "贴图 mipmap", "i", (0, 4), 4),
    ("viewBobbing", "视角摆动", "b", None, True),
    ("autoJump", "自动跳跃", "b", None, False),
    ("fullscreen", "全屏启动", "b", None, False),
    ("vsync", "垂直同步", "b", None, False),
    ("rawMouseInput", "原始鼠标输入", "b", None, True),
    ("pauseOnLostFocus", "失焦自动暂停", "b", None, True),
    ("invertYMouse", "反转鼠标 Y", "b", None, False),
    ("mouseSensitivity", "鼠标灵敏度", "f", (0.0, 1.0), 0.5),
    ("attackIndicator", "攻击指示器", "c", ["off", "crosshair", "hotbar"], "crosshair"),
    ("heldItemTooltips", "手持物品提示", "c", ["off", "simple", "advanced"],
     "advanced"),
    ("showSubtitles", "字幕", "b", None, False),
    ("chatOpacity", "聊天框不透明度", "f", (0.0, 1.0), 0.5),
    ("chatScale", "聊天字号", "f", (0.0, 1.0), 1.0),
    ("chatWidth", "聊天宽度", "f", (0.0, 1.0), 1.0),
    ("chatHeightFocused", "聊天高度（输入时）", "f", (0.0, 1.0), 1.0),
    ("textBackgroundOpacity", "文字背景不透明度", "f", (0.0, 1.0), 0.5),
    ("touchscreen", "触屏模式", "b", None, False),
    ("soundCategory_master", "总音量", "f", (0.0, 1.0), 1.0),
    ("soundCategory_music", "音乐", "f", (0.0, 1.0), 1.0),
    ("soundCategory_blocks", "方块音效", "f", (0.0, 1.0), 1.0),
    ("soundCategory_hostile", "敌对生物", "f", (0.0, 1.0), 1.0),
    ("soundCategory_neutral", "中立生物", "f", (0.0, 1.0), 1.0),
    ("soundCategory_players", "玩家音效", "f", (0.0, 1.0), 1.0),
    ("soundCategory_weather", "天气", "f", (0.0, 1.0), 1.0),
    ("soundCategory_ambient", "环境", "f", (0.0, 1.0), 1.0),
    ("soundCategory_voice", "语音", "f", (0.0, 1.0), 1.0),
    ("difficulty", "新世界难度（0和平/1简单/2普通/3困难）", "i", (0, 3), 2),
    ("enableVsync", "垂直同步（旧键）", "b", None, False),
    ("renderClouds", "云（旧键）", "b", None, True),
]

LABELS = {item[0]: item[1] for item in SPEC}
BY_KEY = {item[0]: item for item in SPEC}


def options_path(game_dir):
    return os.path.join(game_dir, "options.txt")


def read_options(game_dir):
    """读现有 options.txt，返回 {key: str}。"""
    p = options_path(game_dir)
    out = {}
    if not os.path.exists(p):
        return out
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.rstrip("\r\n")
                if ":" not in line:
                    continue
                k, v = line.split(":", 1)
                out[k.strip()] = v.strip()
    except OSError:
        pass
    return out


def _fmt(key, value):
    item = BY_KEY.get(key)
    if not item:
        return str(value)
    kind = item[2]
    if kind == "b":
        return "true" if value else "false"
    if kind == "f":
        return "%.2f" % float(value)
    return str(value)


def apply_options(game_dir, values, only_missing=True):
    """把 values 写进 options.txt。

    only_missing=True 时，文件里已有的键保持不动（尊重玩家自己调过的设置）。
    返回 (写入键数, 实际文件路径)。
    """
    if not game_dir or not values:
        return 0, ""
    try:
        os.makedirs(game_dir, exist_ok=True)
    except OSError:
        return 0, ""
    path = options_path(game_dir)
    cur = read_options(game_dir)
    changed = 0
    for k, v in values.items():
        if only_missing and k in cur:
            continue
        newv = _fmt(k, v)
        if cur.get(k) == newv:
            continue
        cur[k] = newv
        changed += 1
    if not changed and os.path.exists(path):
        return 0, path
    order = [k for k, _l, _t, _c, _d in SPEC if k in cur]
    extra = [k for k in cur if k not in order]
    lines = ["%s:%s" % (k, cur[k]) for k in order + extra]
    try:
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
    except OSError:
        return 0, path
    return changed, path
