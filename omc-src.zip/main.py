# -*- coding: utf-8 -*-
"""OMC 启动器入口。"""
import os
import sys
import threading

# RNG 附魔破解的子进程入口：必须在导入 Qt 之前拦下，
# 否则每开一个破解进程都会把整个界面再拉一遍。
if "--rng-crack" in sys.argv:
    from core.enchant_rng import cli_main
    sys.exit(cli_main(sys.argv))

from PySide6.QtCore import QTimer
from PySide6.QtGui import QColor, QIcon, QPixmap
from PySide6.QtWidgets import QApplication

from core import shortcut, i18n, platform_utils, qtzh
from core.config import Config
from ui import style
from ui.main_window import MainWindow


def _resource(rel):
    """源码运行取项目目录；打包后取 PyInstaller 解包目录。"""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


def _warm_net():
    """把联网要用的模块提前导一遍。

    第一次 HTTP 请求会懒加载 urllib / socket / ssl / encodings.idna，
    这些导入要和界面线程抢 import 锁，实测能把「点登录」卡住十几秒。
    启动时在后台线程付这一次账，之后的登录、扫码、下载都是毫秒级。
    """
    import threading

    def work():
        try:
            import encodings.idna  # noqa: F401
            import socket  # noqa: F401
            import ssl  # noqa: F401
            import urllib.request  # noqa: F401
            from core import http as omc_http
            omc_http.ssl_context()
        except Exception:
            pass

    threading.Thread(target=work, name="net-warm", daemon=True).start()


def main():
    app = QApplication(sys.argv)
    _warm_net()
    cfg = Config()
    qss_text = style.qss(cfg.get("theme") or "dark",
                         cfg.get("ui_accent") or "blue",
                         cfg.get("ui_button") or "round")
    i18n.set_language(cfg.get("language") or "zh_CN")
    # Qt 自带对话框的按钮全换成中文（打包环境没有 Qt 翻译文件）
    try:
        qtzh.install()
    except Exception:
        pass
    app.setApplicationName(i18n.tr("app_title"))
    # 崩溃取证：真出 0xc0000005 这种 C 层挂掉时，把当时的栈写进
    # 用户数据目录的 crash.log，下次不用再靠猜。
    try:
        import faulthandler

        log_dir = os.path.expanduser("~/.simple_mc_launcher")
        os.makedirs(log_dir, exist_ok=True)
        _crash_fp = open(os.path.join(log_dir, "crash.log"), "a",
                         buffering=1, encoding="utf-8")
        faulthandler.enable(file=_crash_fp, all_threads=True)
    except Exception:
        _crash_fp = None
    # 图标：Windows 用 .ico（任务栏更清晰），macOS/Linux 用 PNG（Qt 原生支持）
    icon_name = "sword.ico" if platform_utils.WINDOWS else "sword_preview.png"
    icon_path = _resource(os.path.join("assets", icon_name))
    fallback = _resource(os.path.join("assets", "sword_preview.png"))
    icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
    if icon.isNull() or not icon.availableSizes():
        # 打包目录被部分覆盖 / ico 读不出来时，别让窗口掉成系统默认图标
        if os.path.exists(fallback):
            icon = QIcon(fallback)
        if icon.isNull() or not icon.availableSizes():
            pm = QPixmap(64, 64)
            pm.fill(QColor("#2F6F3E"))
            icon = QIcon(pm)
    app.setWindowIcon(icon)

    # 快捷方式：首次运行才真要建（.lnk 走 PowerShell，一秒上下）。
    # 以前放在窗口创建前同步跑，等于白等；现在窗口先出来，再在后台补。
    def _shortcut():
        try:
            shortcut.ensure_desktop_shortcut()
        except Exception:
            pass

    threading.Thread(target=_shortcut, name="shortcut", daemon=True).start()

    win = MainWindow(cfg)
    # 样式表放在窗口建完之后再套：建控件期间不用逐个解析 QSS，
    # 实测整体启动快 0.6 秒左右（套上时一次性 polish 只要 0.2 秒）。
    app.setStyleSheet(qss_text)
    # 窗口自己也挂一份图标：个别 Windows 主题下只认窗口级图标，
    # 少了它标题栏就会退成系统默认那个「白窗口」样子的占位图。
    try:
        if not icon.isNull():
            win.setWindowIcon(icon)
    except Exception:
        pass
    win.show()

    # 界面稳定后把这一大堆常驻对象推进永久代：以后 GC 不用反复扫它们，
    # 否则隔一会儿就来一次几十毫秒的全量扫描（表现为画面突然一顿）。
    def _freeze_gc():
        try:
            import gc
            gc.collect()
            gc.freeze()
        except Exception:
            pass

    QTimer.singleShot(2500, _freeze_gc)

    code = app.exec()

    # 显式等待全部后台线程，避免 Qt 线程未收敛（0xC0000409）
    win.shutdown()
    win.deleteLater()
    app.processEvents()
    # 直接结束进程，跳过解释器/Qt 回收顺序，彻底避免退出阶段崩溃
    os._exit(code)


if __name__ == "__main__":
    main()
