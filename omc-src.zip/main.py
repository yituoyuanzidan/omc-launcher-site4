# -*- coding: utf-8 -*-
"""OMC 启动器入口。"""
import os
import sys
import threading
import time

# ---------------------------------------------------------------- 启动前自检
# 必须放在 import PySide6 之前：老系统（Win7/8）或缺运行库的机器，
# Qt 的 DLL 是在 import 那一刻加载的，导入失败 Python 就没有机会解释了，
# 用户看到的就是「一闪就没」。先自检，跑不了就用系统原生框说清楚原因。
from core import syscheck

if "--doctor" in sys.argv:
    # 命令行自检报告：不用起界面，拷给别人看很方便
    print(syscheck.report_text())
    sys.exit(0)

# RNG 附魔破解的子进程入口：必须在导入 Qt 之前拦下，
# 否则每开一个破解进程都会把整个界面再拉一遍。
if "--rng-crack" in sys.argv:
    from core.enchant_rng import cli_main
    sys.exit(cli_main(sys.argv))

_CAN_RUN = syscheck.preflight()
if not _CAN_RUN:
    sys.exit(2)

try:
    from PySide6.QtCore import QTimer
    from PySide6.QtGui import QColor, QFont, QIcon, QPixmap
    from PySide6.QtWidgets import QApplication

    from core import shortcut, i18n, platform_utils, qtzh
    from core.config import Config
    from ui import style
    from ui.main_window import MainWindow
    _QT_ERROR = ""
except Exception as _e:                     # 运行库 / 显卡驱动把 Qt 挡住时
    _QT_ERROR = "%s: %s" % (type(_e).__name__, _e)


def _resource(rel):
    """源码运行取项目目录；打包后取 PyInstaller 解包目录。"""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


def _warm_net():
    """把联网要用的模块提前导一遍。

    第一次 HTTP 请求会懒加载 urllib / socket / ssl / encodings.idna，
    这些导入要和界面线程抢 import 锁，实测能把「点登录」卡住十几秒。
    启动时在后台线程付这一次账，之后的登录、扫码、下载都是毫秒级。
    """
    import threading

    def work():
        try:
            import encodings.idna  # noqa: F401
            import socket  # noqa: F401
            import ssl  # noqa: F401
            import urllib.request  # noqa: F401
            from core import http as omc_http
            omc_http.ssl_context()
        except Exception:
            pass

    threading.Thread(target=work, name="net-warm", daemon=True).start()


def main():
    if _QT_ERROR:
        # Qt 起来了又没完全起来：多半是运行库/显卡。给一条能照着做的路。
        syscheck.native_alert(
            "OMC 启动器：界面组件加载失败",
            "界面库（PySide6 / Qt）没能加载起来。\n\n"
            "错误信息：\n%s\n\n"
            "通常是这两种情况：\n"
            "1. 系统缺 Visual C++ 2015-2022 运行库 → 装一遍微软官方那个 x64 安装包，重启再开；\n"
            "2. 显卡驱动太旧 / 是虚拟机的软件显卡 → 更新显卡驱动，或在设置里关掉壁纸与预告片。\n\n"
            "自检报告已经写在：%s\n"
            % (_QT_ERROR, os.path.join(syscheck._log_dir(), "syscheck.log")))
        return 3
    app = QApplication(sys.argv)
    # 位图缓存定死上限：封面、皮肤预览、视频缩略图都走 QPixmapCache，
    # 默认上限偏大且只管单张大小，列表翻一天能把内存顶上去。64 MB 够日常
    # 用，超了自动淘汰最久没用的。
    try:
        from PySide6.QtGui import QPixmapCache

        QPixmapCache.setCacheLimit(64 * 1024)
    except Exception:
        pass
    # 单实例：反复双击桌面图标不该叠出一堆进程。它们共用同一个 AUMID，
    # 后启动的会改掉任务栏注册的图标路径，图标就是这么变坏的。
    try:
        from core import single

        _single_lock = single.acquire()
        if _single_lock is False:
            return 0
    except Exception:
        _single_lock = None
    # 关掉「最后一个窗口关了就直接退」：托盘、提示条、闹钟响铃窗都是独立顶层
    # 窗口，不能让它们一关就把进程带走（否则闹钟永远响不了）。
    try:
        app.setQuitOnLastWindowClosed(False)
    except Exception:
        pass
    _warm_net()
    cfg = Config()
    # 字体改成应用级一次性设置。以前 QSS 的 * 规则里写着 font-family/font-size，
    # 每换一次主题都要让主窗 1600 多个控件重算字体、重排文字（实测占掉
    # 换主题近 1/3 的耗时）；放到 app.setFont 之后，换主题只动颜色。
    try:
        _f = QFont()
        _fam = platform_utils.font_families()
        if _fam:
            try:
                _f.setFamilies(_fam)          # Qt 5.13+ / Qt 6
            except Exception:
                _f.setFamily(_fam[0])         # 老 Qt：只能给一个
        _f.setPixelSize(14)
        app.setFont(_f)
    except Exception as _e:
        print("[style] 设置界面字体失败：%s" % _e)
    qss_text = style.qss(cfg.get("theme") or "dark",
                         cfg.get("ui_accent") or "blue",
                         cfg.get("ui_button") or "round")
    i18n.set_language(cfg.get("language") or "zh_CN")
    # Qt 自带对话框的按钮全换成中文（打包环境没有 Qt 翻译文件）
    try:
        qtzh.install()
    except Exception:
        pass
    app.setApplicationName(i18n.tr("app_title"))
    # 崩溃取证：真出 0xc0000005 这种 C 层挂掉时，把当时的栈写进
    # 用户数据目录的 crash.log，下次不用再靠猜。
    try:
        import faulthandler

        log_dir = os.path.expanduser("~/.simple_mc_launcher")
        os.makedirs(log_dir, exist_ok=True)
        _crash_fp = open(os.path.join(log_dir, "crash.log"), "a",
                         buffering=1, encoding="utf-8")
        faulthandler.enable(file=_crash_fp, all_threads=True)
    except Exception:
        _crash_fp = None

    # 未处理异常兜底：以前 Python 抛到顶要么控制台一闪，要么让 Qt 自己把
    # 进程带走，Windows 随后弹「OMC.exe 已停止工作」——任务栏留下一条崩溃
    # 记录，看着就像启动器一直在崩。现在全部落进 crash.log，界面只提示一次。
    def _excepthook(etype, value, tb):
        import traceback

        try:
            with open(os.path.join(os.path.expanduser("~/.simple_mc_launcher"),
                                   "crash.log"), "a", encoding="utf-8") as f:
                f.write("\n=== %s 未捕获异常 %s ===\n"
                        % (time.strftime("%Y-%m-%d %H:%M:%S"),
                           getattr(etype, "__name__", etype)))
                traceback.print_exception(etype, value, tb, file=f)
        except Exception:
            pass
        try:
            print("".join(traceback.format_exception(etype, value, tb)))
        except Exception:
            pass

    sys.excepthook = _excepthook
    try:
        def _thread_hook(args):
            _excepthook(args.exc_type, args.exc_value, args.exc_traceback)

        threading.excepthook = _thread_hook
    except Exception:
        pass

    # 关掉 Windows 自己的「程序已停止工作」弹窗和错误上报：真崩也只在本地
    # 记日志，不让系统往任务栏里塞崩溃条目。
    try:
        import ctypes

        ctypes.windll.kernel32.SetErrorMode(0x0001 | 0x0002)
        ctypes.windll.kernel32.SetThreadErrorMode(0x0001 | 0x0002, None)
    except Exception:
        pass
    # 图标：Windows 用 .ico（任务栏更清晰），macOS/Linux 用 PNG（Qt 原生支持）
    icon_name = "sword.ico" if platform_utils.WINDOWS else "sword_preview.png"
    icon_path = _resource(os.path.join("assets", icon_name))
    fallback = _resource(os.path.join("assets", "sword_preview.png"))
    icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
    if icon.isNull() or not icon.availableSizes():
        # 打包目录被部分覆盖 / ico 读不出来时，别让窗口掉成系统默认图标
        if os.path.exists(fallback):
            icon = QIcon(fallback)
        if icon.isNull() or not icon.availableSizes():
            pm = QPixmap(64, 64)
            pm.fill(QColor("#2F6F3E"))
            icon = QIcon(pm)
    app.setWindowIcon(icon)
    # 任务栏图标：光设 AppUserModelID 不注册，Windows 会按这个 ID 去查图标，
    # 查不到就退回系统默认的「未知程序」占位图（看着像崩溃的程序）。
    # 所以先把 ID 连同显示名、图标路径写进 HKCU，再设进程 ID。
    try:
        if platform_utils.WINDOWS:
            from core import taskbar

            taskbar.apply(icon_path)
    except Exception:
        pass

    # 快捷方式：首次运行才真要建（.lnk 走 PowerShell，一秒上下）。
    # 以前放在窗口创建前同步跑，等于白等；现在窗口先出来，再在后台补。
    def _shortcut():
        try:
            shortcut.ensure_desktop_shortcut()
        except Exception:
            pass

    threading.Thread(target=_shortcut, name="shortcut", daemon=True).start()

    win = MainWindow(cfg)
    # 样式表放在窗口建完之后再套：建控件期间不用逐个解析 QSS，
    # 实测整体启动快 0.6 秒左右（套上时一次性 polish 只要 0.2 秒）。
    app.setStyleSheet(qss_text)
    # 窗口自己也挂一份图标：个别 Windows 主题下只认窗口级图标，
    # 少了它标题栏就会退成系统默认那个「白窗口」样子的占位图。
    try:
        if not icon.isNull():
            win.setWindowIcon(icon)
    except Exception:
        pass
    win.show()
    try:
        from PySide6.QtCore import QTimer as _QT
        _QT.singleShot(0, win._play_intro_anim)
    except Exception:
        pass

    # 界面稳定后把这一大堆常驻对象推进永久代：以后 GC 不用反复扫它们，
    # 否则隔一会儿就来一次几十毫秒的全量扫描（表现为画面突然一顿）。
    def _freeze_gc():
        try:
            import gc
            gc.collect()
            gc.freeze()
        except Exception:
            pass

    QTimer.singleShot(2500, _freeze_gc)

    code = app.exec_()

    # 显式等待全部后台线程，避免 Qt 线程未收敛（0xC0000409）
    win.shutdown()
    win.deleteLater()
    app.processEvents()
    # 直接结束进程，跳过解释器/Qt 回收顺序，彻底避免退出阶段崩溃
    os._exit(code)


if __name__ == "__main__":
    main()
