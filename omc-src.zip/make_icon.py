# -*- coding: utf-8 -*-
"""把钻石剑贴图生成多尺寸 ico，最近邻缩放保持像素风。"""
import os

from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "assets", "diamond_sword.png")
DST = os.path.join(BASE, "assets", "sword.ico")

img = Image.open(SRC).convert("RGBA")
print("source size:", img.size)

sizes = [16, 24, 32, 48, 64, 128, 256]
frames = []
for s in sizes:
    frames.append(img.resize((s, s), Image.NEAREST))

frames[-1].save(DST, format="ICO", sizes=[(s, s) for s in sizes])
print("written:", DST, os.path.getsize(DST), "bytes")

# 同时导出一张 256 预览图，方便确认效果
preview = os.path.join(BASE, "assets", "sword_preview.png")
img.resize((256, 256), Image.NEAREST).save(preview)
print("preview:", preview)
