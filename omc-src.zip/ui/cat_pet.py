# -*- coding: utf-8 -*-
"""侧栏底部的那只像素猫。

不用图片资源，直接按像素网格画：一块一块填色，缩放时关掉平滑，
这样在任何 DPI 下都是硬边像素，不会糊成半格。
"""
from PySide6.QtCore import Qt, QTimer, QRect
from PySide6.QtGui import QColor, QPainter, QPixmap, QFont, QPen
from PySide6.QtWidgets import QWidget

# 每块：x, y, 宽, 高, 颜色键（网格单位，1 格 = 6px）
_BLOCKS = [
    # 耳朵（阶梯状，故意不做斜边，保持像素味）
    (3, 0, 2, 1, "o"), (2, 1, 3, 1, "o"), (2, 2, 2, 1, "o"),
    (11, 0, 2, 1, "o"), (11, 1, 3, 1, "o"), (12, 2, 2, 1, "o"),
    # 头
    (2, 2, 12, 8, "o"),
    # 额头两道斑纹
    (6, 2, 1, 3, "d"), (9, 2, 1, 3, "d"),
    # 身体
    (4, 10, 8, 6, "o"),
    (5, 11, 6, 1, "d"),
    # 前爪
    (5, 14, 2, 2, "w"), (9, 14, 2, 2, "w"),
]
_EYES = ((4, 5), (10, 5))
_NOSE = (7, 7, 2, 1)
_TAIL = ((12, 11), (13, 10), (14, 9), (15, 8))

_COLORS = {
    "o": "#E8A44C",
    "d": "#C97F33",
    "w": "#F4F6F8",
    "k": "#20232A",
    "p": "#F2A0B4",
}


class CatPet(QWidget):
    """点一下会「喵」。"""

    PX = 6          # 每格 6px，16 格 = 96px

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(96, 104)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("摸摸它")
        self._blink = False
        self._wag = 0
        self._bubble_i = 0
        self._words = ["喵～", "喵？", "呼噜呼噜", "别摸啦"]

        self._tick = QTimer(self)
        self._tick.timeout.connect(self._on_tick)
        self._tick.start(220)
        self._n = 0

        self._bubble_timer = QTimer(self)
        self._bubble_timer.setSingleShot(True)
        self._bubble_timer.timeout.connect(self.update)

        self._cache = None

    # ---------- 交互 ----------
    def _on_tick(self):
        self._n += 1
        if self._n % 16 == 0:          # 约 3.5 秒眨一次
            self._blink = True
            QTimer.singleShot(260, self._unblink)
        self._wag = (self._wag + 1) % 4
        self._cache = None
        self.update()

    def _unblink(self):
        self._blink = False
        self._cache = None
        self.update()

    def mousePressEvent(self, e):
        self._bubble_text = self._words[self._bubble_i % len(self._words)]
        self._bubble_i += 1
        self._bubble_timer.start(1800)
        self.update()
        super().mousePressEvent(e)

    # ---------- 画 ----------
    def _render(self):
        pm = QPixmap(96, 96)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, False)
        px = self.PX

        def blk(x, y, w, h, c):
            p.fillRect(QRect(x * px, y * px, w * px, h * px), QColor(c))

        for x, y, w, h, c in _BLOCKS:
            blk(x, y, w, h, _COLORS[c])

        # 眼睛（眨眼时压成一条横线）
        for ex, ey in _EYES:
            if self._blink:
                blk(ex, ey + 1, 2, 1, _COLORS["k"])
            else:
                blk(ex, ey, 2, 2, _COLORS["k"])
                blk(ex, ey, 1, 1, "#5A6472")     # 一点高光，眼睛不那么死

        blk(*_NOSE, "p")

        # 嘴：两道短竖
        blk(7, 8, 1, 1, _COLORS["d"])
        blk(8, 8, 1, 1, _COLORS["d"])

        # 尾巴：四节阶梯，跟着 wag 前后摆
        for i, (tx, ty) in enumerate(_TAIL):
            off = (0, 0, 1, 1)[(self._wag + i) % 4]
            blk(tx, ty + off, 1, 1, _COLORS["d"])

        # 胡须（左右各两根）
        p.setPen(QPen(QColor("#C8CDD4"), 1))
        for dy in (6, 8):
            p.drawLine(0, dy * px + 2, 2 * px, dy * px + 1)
            p.drawLine(14 * px, dy * px + 1, 16 * px, dy * px + 2)
        p.end()
        return pm

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform, False)
        if self._cache is None:
            self._cache = self._render()
        p.drawPixmap(0, 10, self._cache)

        if self._bubble_timer.isActive():
            txt = getattr(self, "_bubble_text", "喵～")
            f = QFont()
            f.setPointSize(8)
            p.setFont(f)
            fm = p.fontMetrics()
            w = max(54, fm.horizontalAdvance(txt) + 18)
            box = QRect(max(0, (self.width() - w) // 2), 0, w, 22)
            p.setRenderHint(QPainter.Antialiasing, True)
            p.setBrush(QColor("#2A2F3A"))
            p.setPen(QPen(QColor(255, 255, 255, 46), 1))
            p.drawRoundedRect(box, 7, 7)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(box, Qt.AlignCenter, txt)
