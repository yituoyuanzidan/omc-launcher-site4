# -*- coding: utf-8 -*-
"""侧栏底部的那只像素猫。

不用图片资源，直接按像素网格画：一块一块填色，缩放时关掉平滑，
这样在任何 DPI 下都是硬边像素，不会糊成半格。
"""
from PySide6.QtCore import Qt, QTimer, QRect
from PySide6.QtGui import QColor, QPainter, QPixmap, QFont, QPen
from PySide6.QtWidgets import QWidget, QToolTip

import random
import time

# 每块：x, y, 宽, 高, 颜色键（网格单位，1 格 = 6px）
_BLOCKS = [
    # 耳朵（阶梯状，故意不做斜边，保持像素味）
    (3, 0, 2, 1, "o"), (2, 1, 3, 1, "o"), (2, 2, 2, 1, "o"),
    (11, 0, 2, 1, "o"), (11, 1, 3, 1, "o"), (12, 2, 2, 1, "o"),
    # 头
    (2, 2, 12, 8, "o"),
    # 额头两道斑纹
    (6, 2, 1, 3, "d"), (9, 2, 1, 3, "d"),
    # 身体
    (4, 10, 8, 6, "o"),
    (5, 11, 6, 1, "d"),
    # 前爪
    (5, 14, 2, 2, "w"), (9, 14, 2, 2, "w"),
]
_EYES = ((4, 5), (10, 5))
_NOSE = (7, 7, 2, 1)
_TAIL = ((12, 11), (13, 10), (14, 9), (15, 8))

_COLORS = {
    "o": "#E8A44C",
    "d": "#C97F33",
    "w": "#F4F6F8",
    "k": "#20232A",
    "p": "#F2A0B4",
}


class CatPet(QWidget):
    """点一下会「喵」。"""

    PX = 6          # 每格 6px，16 格 = 96px

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(96, 104)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("摸摸它")
        self._blink = False
        self._wag = 0
        self._bubble_i = 0
        self._words = ["喵～", "喵？", "呼噜呼噜", "别摸啦", "陪我玩会儿",
                       "今天玩哪个版本", "我饿了", "刚睡醒", "喵！",
                       "红石又炸了？"]
        self._last_click = 0.0
        self._clicks = 0
        self._happy = 0
        self._short_tips = [
            "设置里能调内存",
            "Ctrl+Alt+M 换歌",
            "工具页能清缓存",
            "壁纸能调亮度",
            "崩溃了看日志诊断",
            "试试暗夜主题",
            "点星标收藏版本",
            "开机自启能开",
            "资源包能看大图",
            "版本能一键备份",
        ]
        self._tips = [
            "左键点我就换一句；连点两下我会更开心。",
            "右键我，我告诉你今天能玩什么。",
            "想换壁纸：左侧「个性化」→ 外观与背景。",
            "嫌启动慢：设置 → 启动与动画，把预告片关掉。",
            "游戏卡：设置 → 按这台电脑推荐内存。",
            "出 bug 了：设置 → 一键打包日志，把 zip 发出去就行。",
            "在别的页面想换歌：Ctrl+Alt+M 播放/暂停，N 下一首，B 上一首。",
            "想让启动器自己开起来：设置 → 开机自动打开启动器。",
        ]
        # 空闲时自己开口讲的小知识（气泡只有 96px 宽，控制在 10 字以内）
        self._knowledge = [
            "按 F11 就全屏",
            "Shift+F5 刷房间",
            "游戏里 F3 看坐标",
            "钻石在 Y=-58 最多",
            "下界 1 格 = 主世界 8 格",
            "床在下界会炸",
            "苦力怕怕猫",
            "铁镐挖钻石啥也不掉",
            "鞘翅要靠烟花推",
            "末影人怕水",
            "信标底下要金字塔",
            "中继器延时 0.1 秒",
            "附魔台 30 级最划算",
            "火焰附加打末影人没用",
            "1.21 要用 Java 21",
            "加载器版本要选对",
            "模组冲突去工具页查",
            "种子地图能看地形",
            "皮肤和披风在个性化",
            "主页能看游戏时长",
        ]
        self._know_i = 0
        self._last_act = time.monotonic()
        self._idle_after = 45.0        # 45 秒没人动就自己讲一句
        self._idle_timer = QTimer(self)
        self._idle_timer.setInterval(20000)
        self._idle_timer.timeout.connect(self._on_idle)
        self._idle_timer.start()

        self._tick = QTimer(self)
        self._tick.timeout.connect(self._on_tick)
        self._tick.start(220)
        self._n = 0

        self._bubble_timer = QTimer(self)
        self._bubble_timer.setSingleShot(True)
        self._bubble_timer.timeout.connect(self.update)

        self._cache = None

    # ---------- 交互 ----------
    def say(self, text, ms=2600):
        """让小猫主动说一句（启动完成时用，不用人点）。"""
        self._bubble_text = text or "喵～"
        self._bubble_timer.start(int(ms))
        self.update()

    def _on_idle(self):
        """没人理它的时候，隔一会儿自己讲一条启动器 / 游戏的小知识。"""
        if self._bubble_timer.isActive():
            return
        if time.monotonic() - self._last_act < self._idle_after:
            return
        text = self._knowledge[self._know_i % len(self._knowledge)]
        self._know_i += 1
        self._last_act = time.monotonic()
        self.say(text, 7000)
        try:
            self.setToolTip(text)
        except Exception:
            pass

    def _on_tick(self):
        self._n += 1
        if self._n % 16 == 0:          # 约 3.5 秒眨一次
            self._blink = True
            QTimer.singleShot(260, self._unblink)
        step = 2 if self._happy > 0 else 1      # 被连点之后摇得更快
        if self._happy > 0:
            self._happy -= 1
        self._wag = (self._wag + step) % 4
        self._cache = None
        self.update()

    def _unblink(self):
        self._blink = False
        self._cache = None
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton:
            # 右键：随机说一句今天能用上的提示（长句放气泡会挤，用悬浮提示）
            QToolTip.showText(self.mapToGlobal(self.rect().topLeft()),
                             random.choice(self._tips), self)
            return
        now = time.monotonic()
        if now - self._last_click < 0.4:
            # 连点两下：开心一会儿，摇尾巴变快，说句更兴奋的
            self._happy = 20
            self._bubble_text = random.choice(["呼噜噜噜～", "喵！喵！", "舒服～"])
        else:
            self._bubble_text = self._words[self._bubble_i % len(self._words)]
            self._bubble_i += 1
        self._clicks += 1
        # 每点三次夹一句能用的短提示（长句留给右键，不然气泡装不下）
        if self._happy <= 0 and self._clicks % 3 == 0:
            self._bubble_text = random.choice(self._short_tips)
        self._last_click = now
        self._last_act = now
        self._bubble_timer.start(1800)
        self.update()
        super().mousePressEvent(e)

    # ---------- 画 ----------
    def _render(self):
        pm = QPixmap(96, 96)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, False)
        px = self.PX

        def blk(x, y, w, h, c):
            p.fillRect(QRect(x * px, y * px, w * px, h * px), QColor(c))

        for x, y, w, h, c in _BLOCKS:
            blk(x, y, w, h, _COLORS[c])

        # 眼睛（眨眼时压成一条横线）
        for ex, ey in _EYES:
            if self._blink:
                blk(ex, ey + 1, 2, 1, _COLORS["k"])
            else:
                blk(ex, ey, 2, 2, _COLORS["k"])
                blk(ex, ey, 1, 1, "#5A6472")     # 一点高光，眼睛不那么死

        blk(*_NOSE, "p")

        # 嘴：两道短竖
        blk(7, 8, 1, 1, _COLORS["d"])
        blk(8, 8, 1, 1, _COLORS["d"])

        # 尾巴：四节阶梯，跟着 wag 前后摆
        for i, (tx, ty) in enumerate(_TAIL):
            off = (0, 0, 1, 1)[(self._wag + i) % 4]
            blk(tx, ty + off, 1, 1, _COLORS["d"])

        # 胡须（左右各两根）
        p.setPen(QPen(QColor("#C8CDD4"), 1))
        for dy in (6, 8):
            p.drawLine(0, dy * px + 2, 2 * px, dy * px + 1)
            p.drawLine(14 * px, dy * px + 1, 16 * px, dy * px + 2)
        p.end()
        return pm

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform, False)
        if self._cache is None:
            self._cache = self._render()
        p.drawPixmap(0, 10, self._cache)

        if self._bubble_timer.isActive():
            txt = getattr(self, "_bubble_text", "喵～")
            f = QFont()
            f.setPointSize(8)
            p.setFont(f)
            fm = p.fontMetrics()
            w = max(54, fm.horizontalAdvance(txt) + 18)
            box = QRect(max(0, (self.width() - w) // 2), 0, w, 22)
            p.setRenderHint(QPainter.Antialiasing, True)
            p.setBrush(QColor("#2A2F3A"))
            p.setPen(QPen(QColor(255, 255, 255, 46), 1))
            p.drawRoundedRect(box, 7, 7)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(box, Qt.AlignCenter, txt)
