# -*- coding: utf-8 -*-
"""闹钟 / 倒计时 / 秒表的运行服务。

- 20ms 一跳（够 0.01 秒精度，又不至于空转太狠）
- 响铃窗口是无父窗口 + 置顶，所以主窗口最小化、缩到托盘都照样在屏幕右上角，
  右上角一个大按钮，点一下就停
- 铃声可以换、可以导入；闹钟声音不受「免打扰 / 静音 / 最小化」影响，
  这是用户明确要的
"""
import os
import time

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QPushButton,
                               QVBoxLayout, QWidget)

from core import alarm as _alarm

MEDIA_DIR = r"C:\Windows\Media"


def _builtin_path(name):
    p = os.path.join(MEDIA_DIR, name + ".wav")
    if os.path.isfile(p):
        return p
    for alt in ("Alarm01", "Alarm02", "Ring01", "Ding", "chimes"):
        q = os.path.join(MEDIA_DIR, alt + ".wav")
        if os.path.isfile(q):
            return q
    return ""


def ring_path(data=None):
    d = data or _alarm.load()
    custom = (d.get("custom_ring") or "").strip()
    if custom and os.path.isfile(custom):
        return custom
    return _builtin_path(d.get("ring") or "Ding")


class RingPlayer(QObject):
    """循环播放铃声（wav/mp3 都能放）。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pl = None
        self._out = None
        self.path = ""

    def _ensure(self):
        if self._pl is not None:
            return True
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            self._pl = QMediaPlayer()
            self._out = QAudioOutput()
            self._pl.setAudioOutput(self._out)
            self._pl.setLoops(QMediaPlayer.Infinite)
            return True
        except Exception:
            self._pl = None
            return False

    def play(self, path=None, volume=100):
        path = path or ring_path()
        self.path = path
        # 闹钟要吵得醒人：音量下限抬到 60%，别让人听到像蚊子叫
        vol = max(0.6, min(1.0, float(volume) / 100.0))
        if self._ensure():
            try:
                self._out.setVolume(vol)
                self._pl.setSource(QUrl.fromLocalFile(path))
                self._pl.play()
                return True
            except Exception:
                pass
        try:
            import winsound
            winsound.PlaySound(path or r"C:\Windows\Media\Ding.wav",
                               winsound.SND_FILENAME | winsound.SND_LOOP
                               | winsound.SND_ASYNC)
            return True
        except Exception:
            return False

    def stop(self):
        if self._pl is not None:
            try:
                self._pl.stop()
            except Exception:
                pass
            try:
                self._pl.setSource(QUrl(""))
            except Exception:
                pass
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass

    def set_volume(self, volume):
        if self._ensure():
            try:
                self._out.setVolume(max(0.6, min(1.0, float(volume) / 100.0)))
            except Exception:
                pass


class RingWindow(QWidget):
    """响铃窗口：屏幕右上角，点「停止」就停。"""

    stop_clicked = Signal()
    snooze_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(None, Qt.Window | Qt.FramelessWindowHint |
                         Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedWidth(420)
        self.setStyleSheet(
            "QWidget#ringWin{background:#1B1F27;border:2px solid #FFB020;"
            "border-radius:12px;}"
            "QLabel#ringTitle{color:#FFB020;font-size:15px;font-weight:700;}"
            "QLabel#ringClock{color:#FFFFFF;font-size:26px;font-weight:700;}"
            "QLabel#ringSub{color:#C6CEDB;font-size:12px;}"
            "QPushButton#ringStop{background:#E23B3B;color:#FFFFFF;"
            "border:none;border-radius:8px;font-size:17px;font-weight:700;}"
            "QPushButton#ringStop:hover{background:#F05050;}"
            "QPushButton#ringSnooze{background:#3A4150;color:#E8EDF5;"
            "border:none;border-radius:8px;}")
        self.setObjectName("ringWin")

        v = QVBoxLayout(self)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(6)
        self.lb_title = QLabel("闹钟")
        self.lb_title.setObjectName("ringTitle")
        v.addWidget(self.lb_title)
        self.lb_clock = QLabel("00:00:00.00")
        self.lb_clock.setObjectName("ringClock")
        f = QFont()
        f.setBold(True)
        f.setPointSize(16)
        self.lb_clock.setFont(f)
        v.addWidget(self.lb_clock)
        self.lb_sub = QLabel("")
        self.lb_sub.setObjectName("ringSub")
        self.lb_sub.setWordWrap(True)
        v.addWidget(self.lb_sub)
        row = QHBoxLayout()
        self.btn_snooze = QPushButton("贪睡 5 分钟")
        self.btn_snooze.setObjectName("ringSnooze")
        self.btn_snooze.clicked.connect(self.snooze_clicked.emit)
        row.addWidget(self.btn_snooze)
        self.btn_stop = QPushButton("停 止")
        self.btn_stop.setObjectName("ringStop")
        self.btn_stop.setFixedHeight(46)
        self.btn_stop.setMinimumWidth(150)
        self.btn_stop.clicked.connect(self.stop_clicked.emit)
        row.addWidget(self.btn_stop, 1)
        v.addLayout(row)
        self._tick = QTimer(self)
        self._tick.setInterval(100)
        self._tick.timeout.connect(self._update_clock)
        self._flash = 0

    def _update_clock(self):
        self.lb_clock.setText(time.strftime("%H:%M:%S") + ".%02d"
                              % (int(time.time() * 100) % 100))
        self._flash = 1 - self._flash
        c = "#FFB020" if self._flash else "#E23B3B"
        self.lb_title.setStyleSheet("color:%s;font-size:15px;"
                                    "font-weight:700;" % c)

    def open_ring(self, title, sub="", snooze=True):
        self.lb_title.setText(title)
        self.lb_sub.setText(sub)
        self.btn_snooze.setVisible(bool(snooze))
        self._update_clock()
        screen = QApplication.primaryScreen()
        if screen is not None:
            geo = screen.availableGeometry()
            self.adjustSize()
            self.move(geo.right() - self.width() - 16, geo.top() + 16)
        self.show()
        self.raise_()
        self._tick.start()

    def hide_ring(self):
        self._tick.stop()
        self.hide()


class AlarmService(QObject):
    """主窗口持有一份，负责所有闹钟/倒计时的计时与响铃。"""
    fired = Signal(str, str)          # 标题, 说明（给界面记日志用）

    def __init__(self, host=None):
        super().__init__()
        self.host = host
        self.data = _alarm.load()
        self.player = RingPlayer(self)
        self.win = RingWindow()
        self.win.stop_clicked.connect(self.stop_ring)
        self.win.snooze_clicked.connect(self.snooze)
        self._ring_reason = ""
        self._ring_info = None
        self._timer_start = {}       # id → 起点 unix
        self._timer_remain = {}      # id → 剩余秒
        self._lap = []               # 秒表计次
        self._sw0 = 0.0
        self._sw_elapsed = 0.0
        self._sw_on = False
        self._last_fire = {}         # alarm id → 上次触发时间（防止重复响）
        self.qt = QTimer()
        self.qt.setInterval(1000)    # 空闲时 1 秒一跳；有闹钟/计时器再提速（_tick 里自调）
        self.qt.timeout.connect(self._tick)
        self.qt.start()
        self._start_timers()

    # ---------- 数据 ----------
    def reload(self):
        self.data = _alarm.load()
        self._start_timers()

    def _start_timers(self):
        now = time.time()
        self._timer_start = {}
        self._timer_remain = {}
        for t in self.data.get("timers") or []:
            total = float(t.get("sec") or 0)
            left = t.get("left")
            if t.get("running"):
                if left is None:
                    left = total
                self._timer_remain[int(t["id"])] = float(left)
                self._timer_start[int(t["id"])] = now

    # ---------- 心跳 ----------
    def _tick(self):
        now = time.time()
        busy = bool(self.data.get("alarms") or []) or \
            any(t.get("running") for t in self.data.get("timers") or []) or \
            bool(self._sw_on)
        # 按负载自调频率：秒表要 0.01 秒精度才 20ms；有闹钟/倒计时 100ms；
        # 什么都没开就 1 秒一跳。以前固定 20ms，等于每秒唤醒 50 次，白耗 CPU。
        want = 20 if self._sw_on else (100 if busy else 1000)
        if self.qt.interval() != want:
            self.qt.setInterval(want)
        # 一个闹钟都没有、也没有在跑的倒计时 → 这一跳什么都不用做（省 CPU）
        if not busy:
            return
        # 闹钟
        for a in self.data.get("alarms") or []:
            if not a.get("on", True):
                continue
            nf = _alarm.next_fire(a, now, look_back=2.0)
            if not nf:
                continue
            key = int(a.get("id") or 0)
            prev = self._last_fire.get(key, 0)
            if nf <= now and prev != nf:
                self._last_fire[key] = nf
                self.fire_alarm(a)
        # 倒计时
        for t in self.data.get("timers") or []:
            if not t.get("running"):
                continue
            key = int(t.get("id") or 0)
            left = self._timer_remain.get(key)
            if left is None:
                continue
            step = now - self._timer_start.get(key, now)
            self._timer_start[key] = now
            self._timer_remain[key] = left - step
            if self._timer_remain[key] <= 0:
                self._timer_remain[key] = 0
                t["running"] = False
                t["left"] = 0
                _alarm.save(self.data)
                self.fire_timer(t)
                self.timers_changed()
        # 秒表
        if self._sw_on:
            pass

    # ---------- 响铃 ----------
    def fire_alarm(self, a):
        self._ring_reason = "alarm"
        self._ring_info = a
        label = (a.get("label") or "").strip() or "闹钟"
        sub = "现在 %s　·　%s" % (time.strftime("%H:%M:%S"),
                                 _alarm.day_text(a.get("days") or []))
        mins = _alarm.snooze_minutes(a)
        self.win.btn_snooze.setText("贪睡 %d 分钟" % mins)
        self.win.open_ring("闹钟 · " + label, sub)
        self._play()
        self.fired.emit("闹钟", "「%s」响了" % label)
        if (a.get("days") or []):
            pass
        else:
            # 非重复闹钟响过就关掉，避免明天再来一次
            a["on"] = False
            _alarm.save(self.data)

    def fire_timer(self, t):
        self._ring_reason = "timer"
        self._ring_info = t
        label = (t.get("label") or "").strip() or "计时器"
        self.win.btn_snooze.setVisible(False)
        self.win.open_ring("计时 · " + label, "时间到")
        self._play()
        self.fired.emit("计时器", "「%s」时间到" % label)

    def _play(self):
        vol = int(self.data.get("volume") or 100)
        vol = max(60, min(100, vol))     # 响铃音量下限 60%，往上顶到 100%
        self.player.set_volume(vol)
        self.player.play(ring_path(self.data), vol)

    def stop_ring(self):
        self.player.stop()
        self.win.hide_ring()
        self._ring_reason = ""
        self._ring_info = None

    def snooze(self):
        info = self._ring_info
        reason = self._ring_reason
        if not info:
            self.stop_ring()
            return
        if reason == "timer":
            # 计时器没有「贪睡」概念，直接停
            self.stop_ring()
            return
        mins = _alarm.snooze_minutes(info)
        self.stop_ring()
        if not info.get("id"):
            return
        # 临时闹钟：从现在开始再响一次
        now = time.time()
        lt = time.localtime(now + mins * 60)
        temp = {"id": -int(now), "hour": lt.tm_hour, "minute": lt.tm_min,
                "second": lt.tm_sec, "frac": 0, "label":
                (info.get("label") or "闹钟") + "（贪睡）", "days": [], "on": True,
                "snooze": mins}
        self.data.setdefault("alarms", []).append(temp)
        _alarm.save(self.data)
        self.fired.emit("贪睡", "%d 分钟后再响" % mins)

    def is_ringing(self):
        return bool(self._ring_reason)

    # ---------- 倒计时 ----------
    def timers_changed(self):
        try:
            if self.host is not None:
                self.host._alarm_refresh()
        except Exception:
            pass

    def add_timer(self, sec, label=""):
        t = {"id": _alarm.new_id(self.data), "sec": round(float(sec), 2),
             "left": round(float(sec), 2), "running": True, "label": label,
             "ts": time.time()}
        self.data.setdefault("timers", []).append(t)
        _alarm.save(self.data)
        now = time.time()
        self._timer_start[t["id"]] = now
        self._timer_remain[t["id"]] = float(sec)
        self.timers_changed()
        return t

    def pause_timer(self, tid):
        for t in self.data.get("timers") or []:
            if int(t.get("id") or 0) == int(tid):
                t["running"] = False
                t["left"] = round(self._timer_remain.get(int(tid), 0), 2)
                _alarm.save(self.data)
                self.timers_changed()

    def resume_timer(self, tid):
        for t in self.data.get("timers") or []:
            if int(t.get("id") or 0) == int(tid):
                t["running"] = True
                self._timer_start[int(tid)] = time.time()
                _alarm.save(self.data)
                self.timers_changed()

    def del_timer(self, tid):
        self.data["timers"] = [t for t in self.data.get("timers") or []
                               if int(t.get("id") or 0) != int(tid)]
        _alarm.save(self.data)
        self.timers_changed()

    def timer_left(self, tid):
        if int(tid) in self._timer_remain:
            return max(0.0, self._timer_remain[int(tid)])
        for t in self.data.get("timers") or []:
            if int(t.get("id") or 0) == int(tid):
                return float(t.get("left") or 0)
        return 0.0

    # ---------- 秒表 ----------
    def stopwatch(self):
        if self._sw_on:
            return self._sw_elapsed + (time.time() - self._sw0)
        return self._sw_elapsed

    def sw_toggle(self):
        if self._sw_on:
            self._sw_elapsed += time.time() - self._sw0
            self._sw_on = False
        else:
            self._sw0 = time.time()
            self._sw_on = True
        return self._sw_on

    def sw_reset(self):
        self._sw_on = False
        self._sw_elapsed = 0.0
        self._lap = []

    def sw_lap(self):
        val = self.stopwatch()
        self._lap.append(val)
        return val

    def laps(self):
        return list(self._lap)

    def active_count(self):
        n = sum(1 for a in self.data.get("alarms") or [] if a.get("on", True))
        n += sum(1 for t in self.data.get("timers") or [] if t.get("running"))
        return n
