# -*- coding: utf-8 -*-
"""工具中心：一页装下所有「平时用得少、出问题必须用」的功能。

页签：
1. 版本备份 —— 整版本打包 / 备注 / 还原 / 导入
2. 模组冲突 —— 重复 modId、缺前置、MC 版本不符
3. 日志诊断 —— 把 latest.log / crash-reports 翻成中文并给做法
4. Java 管理 —— 列出所有 Java，给当前版本钉死一个
5. 批量导入导出 —— 模组 / 光影 / 资源包 / 数据包 一次搬一批
6. 收藏夹 —— 全启动器的收藏集中管理
7. 截图相册 —— 预览、导出、设为背景
8. 主题商店 —— 整套配色预设，可导入导出

所有能力都是「能降级就不崩」：Windows 专属的（比如全局快捷键）在别的平台
直接显示不可用，不抛异常。
"""
import os
import shutil
import time

from PySide6.QtCore import Qt, QSize, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QFileDialog, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPushButton,
    QTabWidget, QTextEdit, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from core import (favorites, javaman, logview, modconflict, packflow,
                  screenshots, themes, verbackup)


class ToolboxPage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = host.config
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)
        title = QLabel("工具中心")
        title.setObjectName("PageTitle")
        v.addWidget(title)
        sub = QLabel("备份、体检、日志、Java、批量搬运、收藏、截图、主题，都在这一页。")
        sub.setObjectName("PageSub")
        v.addWidget(sub)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_verbackup(), "版本备份")
        self.tabs.addTab(self._tab_conflict(), "模组冲突")
        self.tabs.addTab(self._tab_logs(), "日志诊断")
        self.tabs.addTab(self._tab_java(), "Java 管理")
        self.tabs.addTab(self._tab_batch(), "批量导入导出")
        self.tabs.addTab(self._tab_favs(), "收藏夹")
        self.tabs.addTab(self._tab_shots(), "截图相册")
        self.tabs.addTab(self._tab_theme(), "主题商店")
        v.addWidget(self.tabs, 1)

    # ---------- 公共小工具 ----------
    def _gd(self):
        return self.cfg.get("game_dir") or ""

    def _log(self, msg):
        try:
            self.host._log("[工具] " + msg)
        except Exception:
            pass

    def _info(self, title, text):
        QMessageBox.information(self, title, text)

    def _ask(self, title, text):
        return QMessageBox.question(
            self, title, text,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes

    def _open_dir(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        except Exception as e:
            self._log("打开目录失败：%s" % e)

    def _btn_row(self, *pairs):
        """pairs: (文字, 回调)"""
        lay = QHBoxLayout()
        lay.setSpacing(8)
        for text, cb in pairs:
            b = QPushButton(text)
            b.clicked.connect(cb)
            lay.addWidget(b)
        lay.addStretch(1)
        return lay

    def _hint(self, text):
        lab = QLabel(text)
        lab.setObjectName("FieldLabel")
        lab.setWordWrap(True)
        return lab

    # ================= 1. 版本备份 =================
    def _tab_verbackup(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "把 versions/<版本> 整个目录打成一个 zip。换模组、试新版之前存一份；"
            "还原时当前目录会先改名成「<版本>_还原前-时间」留底，不会直接覆盖。"))

        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(QLabel("版本"))
        self.cb_vb_ver = QComboBox()
        self.cb_vb_ver.setMinimumWidth(220)
        row.addWidget(self.cb_vb_ver, 1)
        b_ref = QPushButton("刷新")
        b_ref.clicked.connect(self._vb_refresh)
        row.addWidget(b_ref)
        v.addLayout(row)

        self.in_vb_note = QLineEdit()
        self.in_vb_note.setPlaceholderText("备注（这次改了哪些模组 / 为什么备份），可留空")
        v.addWidget(self.in_vb_note)

        v.addLayout(self._btn_row(
            ("备份这个版本", self._vb_make),
            ("还原选中", self._vb_restore),
            ("删除选中", self._vb_delete),
            ("导入备份包", self._vb_import),
            ("打开备份文件夹", lambda: self._open_dir(
                verbackup.backup_root(self._gd()) if self._gd() else ""))))

        self.list_vb = QListWidget()
        self.list_vb.setSelectionMode(QAbstractItemView.SingleSelection)
        v.addWidget(self.list_vb, 1)
        self.lab_vb = self._hint("")
        v.addWidget(self.lab_vb)
        # 列版本要遍历目录算大小，等页面建好再扫，别拖慢启动
        QTimer.singleShot(300, self._vb_refresh)
        return w

    def _vb_versions(self, gd):
        """只列目录名，不算大小——算大小要 walk 整个版本目录，会卡界面。"""
        d = os.path.join(gd or "", "versions")
        if not os.path.isdir(d):
            return []
        names = []
        for n in sorted(os.listdir(d)):
            if "_还原前-" in n:
                continue      # 还原时留的底，不是能启动的版本
            if os.path.isdir(os.path.join(d, n)):
                names.append(n)
        return names

    def _vb_refresh(self):
        try:
            gd = self._gd()
            cur = self.cb_vb_ver.currentData()
            self.cb_vb_ver.clear()
            if not gd:
                self.lab_vb.setText("还没设置游戏目录。")
                self.list_vb.clear()
                return
            for vid in self._vb_versions(gd):
                self.cb_vb_ver.addItem(vid, vid)
            if cur:
                i = self.cb_vb_ver.findData(cur)
                if i >= 0:
                    self.cb_vb_ver.setCurrentIndex(i)
            self.list_vb.clear()
            rows = verbackup.list_backups(gd)
            for r in rows:
                txt = "%s　%s　%s　%.1f MB" % (
                    r["version"], r["time"], r["note"] or "（无备注）", r["size_mb"])
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, r["path"])
                self.list_vb.addItem(it)
            self.lab_vb.setText("共 %d 份版本备份。" % len(rows) if rows
                                else "还没有版本备份。")
        except Exception as e:
            self._log("读版本备份失败：%s" % e)

    def _vb_make(self):
        try:
            gd = self._gd()
            vid = self.cb_vb_ver.currentData()
            if not vid:
                self._info("先选版本", "上面下拉里还没有可备份的版本。")
                return
            r = verbackup.make(gd, vid, self.in_vb_note.text().strip(),
                               log=self._log)
            self.in_vb_note.clear()
            self._vb_refresh()
            self._info("备份好了",
                       "%s\n%d 个文件，%.1f MB" % (os.path.basename(r["path"]),
                                                r["files"], r["size_mb"]))
        except Exception as e:
            self._info("备份失败", str(e))

    def _vb_restore(self):
        it = self.list_vb.currentItem()
        if not it:
            self._info("先选一份", "在下面的列表里点一份备份。")
            return
        path = it.data(Qt.UserRole)
        if not self._ask("还原版本",
                         "用这份备份覆盖回去？\n%s\n\n当前版本目录会先留底。"
                         % os.path.basename(path)):
            return
        try:
            r = verbackup.restore(self._gd(), path, log=self._log)
            try:
                self.host._load_versions()
            except Exception:
                pass
            self._vb_refresh()
            self._info("还原完成", "已还原：%s%s" % (
                r["version"],
                ("\n旧目录留底：" + os.path.basename(r["prev"])) if r["prev"] else ""))
        except Exception as e:
            self._info("还原失败", str(e))

    def _vb_delete(self):
        it = self.list_vb.currentItem()
        if not it:
            return
        path = it.data(Qt.UserRole)
        if not self._ask("删除备份", "删掉这份备份？只删备份，不动任何版本。\n%s"
                         % os.path.basename(path)):
            return
        try:
            verbackup.delete(path)
            self._vb_refresh()
        except Exception as e:
            self._info("删除失败", str(e))

    def _vb_import(self):
        files, _f = QFileDialog.getOpenFileNames(
            self, "选备份包", verbackup.backup_root(self._gd() if self._gd() else "."),
            "备份包 (*.zip)")
        if not files:
            return
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            root = verbackup.backup_root(gd)
            for src in files:
                dst = os.path.join(root, os.path.basename(src))
                if os.path.abspath(src) != os.path.abspath(dst):
                    shutil.copy2(src, dst)
            self._vb_refresh()
            self._info("导入完成", "已放进备份列表，选中后点「还原选中」即可。")
        except Exception as e:
            self._info("导入失败", str(e))

    # ================= 2. 模组冲突 =================
    def _tab_conflict(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "只看 mods 目录里 jar 的元数据，不用启动游戏就能查出：同一个模组装了"
            "两个版本、缺前置、要求的 MC 版本不对、复制出来的重复文件。"))

        row = QHBoxLayout()
        row.addWidget(QLabel("MC 版本"))
        self.in_mc = QLineEdit()
        self.in_mc.setPlaceholderText("例如 1.21.1；留空就跳过版本匹配检查")
        row.addWidget(self.in_mc, 1)
        v.addLayout(row)

        v.addLayout(self._btn_row(
            ("扫描 mods", self._scan_mods),
            ("打开 mods 文件夹", lambda: self._open_dir(
                os.path.join(self._gd(), "mods") if self._gd() else "")),
            ("清空结果", lambda: self.tree_mods.clear())))

        self.tree_mods = QTreeWidget()
        self.tree_mods.setColumnCount(2)
        self.tree_mods.setHeaderLabels(["问题", "涉及文件 / 说明"])
        self.tree_mods.setColumnWidth(0, 320)
        v.addWidget(self.tree_mods, 1)
        self.lab_mods = self._hint("还没扫描。")
        v.addWidget(self.lab_mods)
        return w

    def _scan_mods(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            mc = self.in_mc.text().strip()
            if not mc:
                try:
                    mc = self.host._selected_version_id() or ""
                except Exception:
                    mc = ""
            res = modconflict.scan(gd, mc, log=self._log)
            self.tree_mods.clear()
            for issue in res["issues"]:
                child = QTreeWidgetItem([issue["title"], "；".join(issue["files"])])
                child.setForeground(0, Qt.red if issue["level"] == "error"
                                    else Qt.yellow)
                tip = QTreeWidgetItem([issue["detail"], ""])
                tip.setFirstColumnSpanned(True)
                self.tree_mods.addTopLevelItem(child)
                self.tree_mods.addTopLevelItem(tip)
            errs = res.get("errors", 0)
            if errs:
                self.lab_mods.setText(
                    "扫了 %d 个 jar，%d 条问题，其中 %d 条会直接启动失败。"
                    % (res["count"], len(res["issues"]), errs))
            elif res["issues"]:
                self.lab_mods.setText("扫了 %d 个 jar，只有警告，不影响启动。"
                                     % res["count"])
            else:
                self.lab_mods.setText("扫了 %d 个 jar，没发现问题。" % res["count"])
        except Exception as e:
            self._info("扫描失败", str(e))

    # ================= 3. 日志诊断 =================
    def _tab_logs(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "读 logs/latest.log 和 crash-reports 里最新一份，把常见报错翻成中文并给做法；"
            "下面同时保留最后几十行原文，方便发给别人看。"))
        v.addLayout(self._btn_row(
            ("分析最近日志", self._analyze_logs),
            ("打开日志文件夹", lambda: self._open_dir(
                os.path.join(self._gd(), "logs") if self._gd() else "")),
            ("打开崩溃报告", lambda: self._open_dir(
                os.path.join(self._gd(), "crash-reports") if self._gd() else "")),
            ("复制全部", lambda: self._copy_text(self.txt_logs))))
        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        v.addWidget(self.txt_logs, 1)
        return w

    def _copy_text(self, edit):
        try:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(edit.toPlainText())
            self._log("已复制到剪贴板")
        except Exception:
            pass

    def _analyze_logs(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            rep = logview.report(gd)
            lines = []
            lines.append("结论：" + rep["summary"])
            lines.append("最近日志：%s %s" % (rep["log_path"] or "（没有 latest.log）",
                                          rep["log_time"]))
            lines.append("崩溃报告：%s %s" % (rep["crash_path"] or "（没有 crash-reports）",
                                          rep["crash_time"]))
            lines.append("")
            for it in rep["items"]:
                lines.append("【%s】%s" % ("错误" if it["level"] == "error" else "警告",
                                       it["title"]))
                lines.append("  建议：" + it["advice"])
                lines.append("  原文：" + it["evidence"])
                lines.append("")
            if not rep["items"]:
                lines.append("没匹配到已知故障，把下面最后 40 行原文发给开发者。")
                lines.append("")
            lines.append("====== 日志末尾 ======")
            lines.append(rep["tail"] or "（空）")
            self.txt_logs.setPlainText("\n".join(lines))
            self._log("日志诊断：" + rep["summary"])
        except Exception as e:
            self.txt_logs.setPlainText("分析失败：%s" % e)

    # ================= 4. Java 管理 =================
    def _tab_java(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "自动检测出来的所有 Java（含 JAVA_HOME、PATH、各厂商安装目录）。"
            "给某个版本钉死一个 Java 后，启动它时就优先用这个，不再自动挑。"))
        v.addLayout(self._btn_row(
            ("重新检测", self._scan_java),
            ("用选中的 Java 跑当前版本", self._pin_java),
            ("改回自动挑选", self._unpin_java),
            ("打开 Java 目录", self._open_java_dir)))
        self.lab_java = self._hint("")
        v.addWidget(self.lab_java)
        self.list_java = QListWidget()
        v.addWidget(self.list_java, 1)
        # 检测 Java 要起子进程，晚一点再扫
        QTimer.singleShot(600, self._scan_java)
        return w

    def _scan_java(self):
        try:
            rows = javaman.list_all()
            self.list_java.clear()
            for r in rows:
                it = QListWidgetItem(r["label"])
                it.setToolTip(r["path"])
                it.setData(Qt.UserRole, r["path"])
                self.list_java.addItem(it)
            if not rows:
                self.lab_java.setText("没检测到任何 Java。可以在设置页点「自动检测」，"
                                      "或先装一个 Java 21。")
            else:
                try:
                    vid = self.host._selected_version_id() or ""
                except Exception:
                    vid = ""
                rec = javaman.recommended(vid) if vid else None
                pinned = javaman.get_pref(self.cfg, vid) if vid else ""
                txt = "检测到 %d 个 Java（主版本：%s）。" % (
                    len(rows), "、".join(str(r["major"]) for r in rows))
                if rec:
                    txt += " 当前版本 %s 建议 Java %d。" % (vid, rec["need"])
                if pinned:
                    txt += " 现在钉死用：%s" % os.path.basename(os.path.dirname(
                        os.path.dirname(pinned)))
                self.lab_java.setText(txt)
        except Exception as e:
            self.lab_java.setText("检测失败：%s" % e)

    def _pin_java(self):
        it = self.list_java.currentItem()
        if not it:
            self._info("先选一个", "在上面列表里点一个 Java。")
            return
        try:
            vid = self.host._selected_version_id() or ""
        except Exception:
            vid = ""
        if not vid:
            self._info("先选版本", "先在启动页选一个版本再钉 Java。")
            return
        try:
            javaman.set_pref(self.cfg, vid, it.data(Qt.UserRole))
            self._scan_java()
            self._log("已把 %s 的 Java 钉成：%s" % (vid, it.data(Qt.UserRole)))
        except Exception as e:
            self._info("设置失败", str(e))

    def _unpin_java(self):
        try:
            vid = self.host._selected_version_id() or ""
        except Exception:
            vid = ""
        if not vid:
            return
        javaman.set_pref(self.cfg, vid, "")
        self._scan_java()
        self._log("已改回自动挑选 Java（%s）" % vid)

    def _open_java_dir(self):
        it = self.list_java.currentItem()
        if it:
            self._open_dir(os.path.dirname(it.data(Qt.UserRole) or ""))
            return
        try:
            rows = javaman.list_all()
        except Exception:
            rows = []
        if rows:
            self._open_dir(os.path.dirname(os.path.dirname(rows[0]["path"])))

    # ================= 5. 批量导入导出 =================
    def _tab_batch(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        row = QHBoxLayout()
        row.addWidget(QLabel("类型"))
        self.cb_batch = QComboBox()
        for k in ("mod", "shader", "resourcepack", "datapack"):
            self.cb_batch.addItem(packflow.KIND_NAMES[k], k)
        self.cb_batch.currentIndexChanged.connect(self._refresh_installed)
        row.addWidget(self.cb_batch)
        row.addStretch(1)
        v.addLayout(row)
        v.addWidget(self._hint(
            "导入只复制、绝不覆盖同名文件：重名的自动加 -2、-3。"
            "导出会按 mods/、shaderpacks/ 这样的目录结构打包，对方解压就能用。"))
        v.addLayout(self._btn_row(
            ("导入文件…", self._batch_import_files),
            ("导入整个文件夹…", self._batch_import_dir),
            ("导出选中为 zip", self._batch_export),
            ("查重复", self._batch_dups),
            ("刷新", self._refresh_installed)))
        self.list_batch = QListWidget()
        self.list_batch.setSelectionMode(QAbstractItemView.ExtendedSelection)
        v.addWidget(self.list_batch, 1)
        self.lab_batch = self._hint("")
        v.addWidget(self.lab_batch)
        self._refresh_installed()
        return w

    def _refresh_installed(self, *_):
        try:
            gd = self._gd()
            kid = self.cb_batch.currentData() or "mod"
            self.list_batch.clear()
            if not gd:
                self.lab_batch.setText("还没设置游戏目录。")
                return
            rows = packflow.scan_installed(gd, kid)
            for r in rows:
                txt = "%s　%.2f MB%s" % (r["name"], r["size_mb"],
                                         "（已禁用）" if r["disabled"] else "")
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, r["name"])
                self.list_batch.addItem(it)
            self.lab_batch.setText("已装 %d 个%s；按住 Ctrl / Shift 可多选。"
                                   % (len(rows), packflow.KIND_NAMES.get(kid, "")))
        except Exception as e:
            self.lab_batch.setText("读取失败：%s" % e)

    def _batch_import_files(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        kid = self.cb_batch.currentData()
        files, _f = QFileDialog.getOpenFileNames(self, "选要导入的文件")
        if not files:
            return
        try:
            res = packflow.import_many(gd, files, kid, log=self._log)
            self._refresh_installed()
            msg = "导入 %d 个；重名改名 %d 个；跳过 %d 个；失败 %d 个。" % (
                len(res["ok"]), len(res["dup"]), len(res["skip"]),
                len(res["error"]))
            if res["skip"]:
                msg += "\n跳过：" + "；".join(res["skip"][:6])
            if res["error"]:
                msg += "\n失败：" + "；".join(res["error"][:6])
            self._info("批量导入", msg)
        except Exception as e:
            self._info("导入失败", str(e))

    def _batch_import_dir(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        d = QFileDialog.getExistingDirectory(self, "选一个文件夹（里面的文件全部导入）")
        if not d:
            return
        try:
            res = packflow.import_many(gd, [d], self.cb_batch.currentData(),
                                      log=self._log)
            self._refresh_installed()
            self._info("批量导入", "导入 %d 个；改名 %d 个；跳过 %d 个；失败 %d 个。"
                       % (len(res["ok"]), len(res["dup"]), len(res["skip"]),
                          len(res["error"])))
        except Exception as e:
            self._info("导入失败", str(e))

    def _batch_export(self):
        items = self.list_batch.selectedItems()
        if not items:
            self._info("先选条目", "在下面列表里选中要导出的（可多选）。")
            return
        gd = self._gd()
        kid = self.cb_batch.currentData() or "mod"
        names = [it.data(Qt.UserRole) for it in items]
        stamp = time.strftime("%Y%m%d-%H%M")
        default = os.path.join(os.path.dirname(gd) or ".",
                               "OMC-%s-%s.zip" % (packflow.KIND_NAMES.get(kid, kid),
                                                 stamp))
        out, _f = QFileDialog.getSaveFileName(self, "导出到哪里", default, "Zip (*.zip)")
        if not out:
            return
        try:
            r = packflow.export_zip(gd, kid, names, out, log=self._log)
            self._info("导出完成", "%s\n%d 个文件，%.1f MB"
                       % (r["path"], r["files"], r["size_mb"]))
        except Exception as e:
            self._info("导出失败", str(e))

    def _batch_dups(self):
        gd = self._gd()
        if not gd:
            return
        try:
            kid = self.cb_batch.currentData() or "mod"
            groups = packflow.find_duplicates(gd, kid)
            if not groups:
                self._info("查重结果", "没发现同名重复文件。")
                return
            self._info("查重结果", "发现 %d 组疑似重复：\n\n%s"
                       % (len(groups), "\n".join(" / ".join(g) for g in groups[:12])))
        except Exception as e:
            self._info("查重失败", str(e))

    # ================= 6. 收藏夹 =================
    def _tab_favs(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        row = QHBoxLayout()
        row.addWidget(QLabel("类型"))
        self.cb_fav = QComboBox()
        self.cb_fav.addItem("全部", "")
        for k, name in favorites.KINDS.items():
            self.cb_fav.addItem(name, k)
        self.cb_fav.currentIndexChanged.connect(self._refresh_favs)
        row.addWidget(self.cb_fav)
        row.addStretch(1)
        v.addLayout(row)
        v.addWidget(self._hint(
            "收藏是跨功能的：模组、光影、资源包、存档、版本、歌曲都在这里。"
            "可以导出成一份 json 换电脑带走。"))
        v.addLayout(self._btn_row(
            ("刷新", self._refresh_favs),
            ("移除选中", self._fav_remove),
            ("打开所在目录", self._fav_open),
            ("导出 json", self._fav_export),
            ("导入 json", self._fav_import)))
        self.list_fav = QListWidget()
        self.list_fav.setSelectionMode(QAbstractItemView.ExtendedSelection)
        v.addWidget(self.list_fav, 1)
        self.lab_fav = self._hint("")
        v.addWidget(self.lab_fav)
        self._refresh_favs()
        return w

    def _refresh_favs(self, *_):
        try:
            kind = self.cb_fav.currentData() or None
            rows = favorites.listing(kind)
            self.list_fav.clear()
            for r in rows:
                t = time.strftime("%m-%d %H:%M", time.localtime(r.get("at") or 0))
                txt = "[%s] %s　%s" % (favorites.KINDS.get(r.get("kind"), "?"),
                                      r.get("name") or r.get("id"), t)
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, (r.get("kind"), r.get("id")))
                it.setData(Qt.UserRole + 1, r.get("path") or "")
                self.list_fav.addItem(it)
            c = favorites.counts()
            self.lab_fav.setText("收藏 %d 条（模组 %d / 光影 %d / 资源包 %d / 存档 %d / 版本 %d / 歌曲 %d）"
                                 % (c["total"], c["mod"], c["shader"],
                                    c["resourcepack"], c["world"],
                                    c["version"], c["music"]))
        except Exception as e:
            self.lab_fav.setText("读取收藏失败：%s" % e)

    def _fav_remove(self):
        items = self.list_fav.selectedItems()
        if not items:
            return
        try:
            for it in items:
                kind, key = it.data(Qt.UserRole)
                favorites.remove(kind, key)
            self._refresh_favs()
        except Exception as e:
            self._log("移除收藏失败：%s" % e)

    def _fav_open(self):
        it = self.list_fav.currentItem()
        if not it:
            return
        p = it.data(Qt.UserRole + 1) or ""
        if p and os.path.exists(p):
            self._open_dir(os.path.dirname(p) if os.path.isfile(p) else p)
        else:
            self._info("没有路径", "这条收藏没记录本地路径（可能是线上条目）。")

    def _fav_export(self):
        out, _f = QFileDialog.getSaveFileName(
            self, "导出收藏", os.path.join(self._gd() or ".", "omc-favorites.json"),
            "JSON (*.json)")
        if not out:
            return
        try:
            with open(out, "w", encoding="utf-8") as f:
                f.write(favorites.export_all())
            self._info("导出完成", out)
        except Exception as e:
            self._info("导出失败", str(e))

    def _fav_import(self):
        path, _f = QFileDialog.getOpenFileName(self, "选收藏文件", "",
                                              "JSON (*.json);;所有文件 (*)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                n = favorites.import_text(f.read(), merge=True)
            self._refresh_favs()
            self._info("导入完成", "新增 %d 条收藏。" % n)
        except Exception as e:
            self._info("导入失败", str(e))

    # ================= 7. 截图相册 =================
    def _tab_shots(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint("游戏里按 F2 拍的截图都在这里。双击放大，可导出、可设为启动器背景。"))
        v.addLayout(self._btn_row(
            ("刷新", self._refresh_shots),
            ("打开截图文件夹", self._open_shots_dir),
            ("导出选中", self._export_shots),
            ("设为启动器背景", self._shot_as_bg)))
        self.list_shots = QListWidget()
        self.list_shots.setViewMode(QListWidget.IconMode)
        self.list_shots.setIconSize(QSize(176, 100))
        self.list_shots.setGridSize(QSize(190, 132))
        self.list_shots.setResizeMode(QListWidget.Adjust)
        self.list_shots.setSpacing(6)
        self.list_shots.setMovement(QListWidget.Static)
        self.list_shots.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list_shots.itemDoubleClicked.connect(lambda it: self._open_shot(it))
        v.addWidget(self.list_shots, 1)
        self.lab_shots = self._hint("")
        v.addWidget(self.lab_shots)
        self._refresh_shots()
        return w

    def _refresh_shots(self):
        try:
            gd = self._gd()
            self.list_shots.clear()
            if not gd:
                self.lab_shots.setText("还没设置游戏目录。")
                return
            rows = screenshots.list_shots(gd)
            for path, mtime, kb in rows[:60]:
                pix = QPixmap(path)
                if not pix.isNull():
                    icon = QIcon(pix.scaled(176, 100, Qt.KeepAspectRatio,
                                            Qt.SmoothTransformation))
                else:
                    icon = QIcon()
                it = QListWidgetItem(icon, os.path.basename(path))
                it.setData(Qt.UserRole, path)
                it.setToolTip("%s\n%.1f KB" % (path, kb))
                self.list_shots.addItem(it)
            self.lab_shots.setText("共 %d 张，显示最近 %d 张。"
                                   % (len(rows), min(60, len(rows)))
                                   if rows else "screenshots 目录还是空的。")
        except Exception as e:
            self.lab_shots.setText("读取截图失败：%s" % e)

    def _open_shots_dir(self):
        gd = self._gd()
        if gd:
            self._open_dir(screenshots.screenshots_dir(gd))

    def _open_shot(self, it):
        p = it.data(Qt.UserRole)
        if p and os.path.isfile(p):
            QDesktopServices.openUrl(QUrl.fromLocalFile(p))

    def _export_shots(self):
        items = self.list_shots.selectedItems()
        if not items:
            return
        d = QFileDialog.getExistingDirectory(self, "导出到哪个文件夹")
        if not d:
            return
        done, fail = 0, 0
        for it in items:
            try:
                shutil.copy2(it.data(Qt.UserRole), os.path.join(
                    d, os.path.basename(it.data(Qt.UserRole))))
                done += 1
            except Exception:
                fail += 1
        self._info("导出完成", "成功 %d 张，失败 %d 张。\n%s" % (done, fail, d))

    def _shot_as_bg(self):
        it = self.list_shots.currentItem() or (
            self.list_shots.selectedItems()[0]
            if self.list_shots.selectedItems() else None)
        if not it:
            self._info("先选一张", "点一张截图再设背景。")
            return
        p = it.data(Qt.UserRole)
        try:
            if hasattr(self.host, "_apply_background_path"):
                self.host._apply_background_path(p)
                self._info("换好了", "启动器背景已换成：%s" % os.path.basename(p))
            else:
                self.cfg.set("background_image", p)
                self.cfg.save()
        except Exception as e:
            self._info("设置失败", str(e))

    # ================= 8. 主题商店 =================
    def _tab_theme(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint("整套配色 + 按键形状一键换上，立刻生效并记住。也可以导出成文件发给别人。"))
        grid = QGridLayout()
        grid.setSpacing(9)
        self._theme_btns = {}
        for i, p in enumerate(themes.presets()):
            b = QPushButton("%s\n%s" % (p["name"], p["desc"]))
            b.setMinimumHeight(54)
            b.setToolTip(p["desc"])
            b.clicked.connect(lambda _c=False, pid=p["id"]: self._apply_theme(pid))
            grid.addWidget(b, i // 3, i % 3)
            self._theme_btns[p["id"]] = b
        v.addLayout(grid)
        v.addLayout(self._btn_row(
            ("导出当前主题", self._theme_export),
            ("导入主题文件", self._theme_import),
            ("恢复原版深色", lambda: self._apply_theme("omc_dark"))))
        self.lab_theme = self._hint("")
        v.addWidget(self.lab_theme)
        v.addStretch(1)
        self._refresh_theme_label()
        return w

    def _refresh_theme_label(self):
        cur = themes.current(self.cfg)
        if cur:
            self.lab_theme.setText("当前：%s（%s / %s / %s）" % (
                cur["name"], cur["theme"], cur["accent"], cur["button"]))
        else:
            self.lab_theme.setText("当前：自定义（%s / %s / %s）" % (
                self.cfg.get("theme") or "dark",
                self.cfg.get("ui_accent") or "blue",
                self.cfg.get("ui_button") or "round"))
        for pid, b in getattr(self, "_theme_btns", {}).items():
            b.setChecked(bool(cur and cur["id"] == pid))
            b.setCheckable(True)

    def _apply_theme(self, pid):
        try:
            themes.apply(self.cfg, pid)
            self._sync_style_ui()
            self._refresh_theme_label()
            self._log("换主题：%s" % pid)
        except Exception as e:
            self._info("换主题失败", str(e))

    def _sync_style_ui(self):
        """把设置页那几个控件也对齐，避免两处显示不一致。"""
        try:
            for k, b in getattr(self.host, "_accent_btns", {}).items():
                b.setChecked(k == (self.cfg.get("ui_accent") or "blue"))
            ct = getattr(self.host, "combo_theme", None)
            if ct is not None:
                i = ct.findData(self.cfg.get("theme") or "dark")
                if i >= 0:
                    ct.setCurrentIndex(i)
            cb = getattr(self.host, "combo_btn_style", None)
            if cb is not None:
                i = cb.findData(self.cfg.get("ui_button") or "round")
                if i >= 0:
                    cb.setCurrentIndex(i)
            self.host._apply_ui_style()
        except Exception as e:
            self._log("同步主题控件失败：%s" % e)

    def _theme_export(self):
        out, _f = QFileDialog.getSaveFileName(
            self, "导出主题", os.path.join(themes.themes_dir(), "omc-theme.json"),
            "JSON (*.json)")
        if not out:
            return
        try:
            themes.export_file(self.cfg, out)
            self._info("导出完成", out)
        except Exception as e:
            self._info("导出失败", str(e))

    def _theme_import(self):
        path, _f = QFileDialog.getOpenFileName(self, "选主题文件", themes.themes_dir(),
                                              "JSON (*.json);;所有文件 (*)")
        if not path:
            return
        try:
            data = themes.import_file(path, self.cfg)
            self._sync_style_ui()
            self._refresh_theme_label()
            self._info("导入完成", "已换成：%s" % data.get("name", "导入的主题"))
        except Exception as e:
            self._info("导入失败", str(e))

    # ================= 外部调用 =================
    def refresh(self):
        """切到这一页时刷新当前选中的页签内容。"""
        idx = self.tabs.currentIndex()
        try:
            if idx == 0:
                self._vb_refresh()
            elif idx == 4:
                self._refresh_installed()
            elif idx == 5:
                self._refresh_favs()
            elif idx == 6:
                self._refresh_shots()
            elif idx == 7:
                self._refresh_theme_label()
        except Exception:
            pass
