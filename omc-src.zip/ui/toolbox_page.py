# -*- coding: utf-8 -*-
"""工具中心：一页装下所有「平时用得少、出问题必须用」的功能。

页签：
1. 版本备份 —— 整版本打包 / 备注 / 还原 / 导入
2. 模组冲突 —— 重复 modId、缺前置、MC 版本不符
3. 日志诊断 —— 把 latest.log / crash-reports 翻成中文并给做法
4. Java 管理 —— 列出所有 Java，给当前版本钉死一个
5. 批量导入导出 —— 模组 / 光影 / 资源包 / 数据包 一次搬一批
6. 收藏夹 —— 全启动器的收藏集中管理
7. 截图相册 —— 预览、导出、设为背景
8. 主题商店 —— 整套配色预设，可导入导出
9. 缓存清理 —— 清掉联网缓存、预告片、临时残留、下载残片，能腾出空间

所有能力都是「能降级就不崩」：Windows 专属的（比如全局快捷键）在别的平台
直接显示不可用，不抛异常。
"""
import os
import shutil
import time

from PySide6.QtCore import Qt, QSize, QTimer, QUrl
from PySide6.QtGui import (QDesktopServices, QGuiApplication, QIcon, QPixmap,
                           QPixmapCache)
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QFileDialog,
    QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMessageBox, QProgressBar, QPushButton, QRadioButton,
    QScrollArea, QTabWidget, QTextEdit, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget,
)

from core import (cacheclean, favorites, feedback, fpsadvice, game_options,
                  javaman, logview, modconflict, netcheck, packflow,
                  screenshots, syscheck, themes, verbackup)


class ToolboxPage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = host.config
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)
        title = QLabel("工具中心")
        title.setObjectName("PageTitle")
        v.addWidget(title)
        sub = QLabel("备份、体检、日志、Java、批量搬运、收藏、截图、主题、清缓存，都在这一页。")
        sub.setObjectName("PageSub")
        v.addWidget(sub)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_verbackup(), "版本备份")
        self.tabs.addTab(self._tab_conflict(), "模组冲突")
        self.tabs.addTab(self._tab_logs(), "日志诊断")
        self.tabs.addTab(self._tab_netself(), "网络自检")
        self.tabs.addTab(self._tab_fps(), "帧率优化")
        self.tabs.addTab(self._tab_java(), "Java 管理")
        self.tabs.addTab(self._tab_batch(), "批量导入导出")
        self.tabs.addTab(self._tab_favs(), "收藏夹")
        self.tabs.addTab(self._tab_shots(), "截图相册")
        self.tabs.addTab(self._tab_record(), "录屏")
        self.tabs.addTab(self._tab_theme(), "主题商店")
        self.tabs.addTab(self._tab_clean(), "缓存清理")
        self.tabs.addTab(self._tab_inbox(), "反馈收件箱")
        self.tabs.addTab(self._tab_ench(), "附魔计算")
        self.tabs.addTab(self._tab_seedmap(), "种子地图")
        self.tabs.addTab(self._tab_modlang(), "模组汉化")
        self.tabs.addTab(self._tab_alarm(), "闹钟计时器")
        # 14 个页签横着排比屏幕还宽，会把整个主窗口的最小宽度撑到 1689，
        # 小屏机器右侧就被切掉了。改成溢出时出左右滚动箭头。
        # 另外页签名字一律不省略（以前 ElideRight 会显示成「批量导入…」，
        # 用户看不出这页到底是干什么的），排不下就靠箭头滚。
        bar = self.tabs.tabBar()
        try:
            bar.setExpanding(False)
            bar.setElideMode(Qt.ElideNone)
            bar.setUsesScrollButtons(True)
        except Exception:
            pass
        self.tabs.setUsesScrollButtons(True)
        self.tabs.setMinimumWidth(0)
        try:
            bar.setMinimumWidth(0)
            bar.setStyleSheet(
                "QTabBar::tab{padding:6px 12px;margin-right:2px;}")
        except Exception:
            pass
        v.addWidget(self.tabs, 1)
        self._wrap_tabs()
        self._fits_names()

    def _wrap_tabs(self):
        """每个页签内容再包一层滚动区。

        工具页里有几页（日志诊断、版本备份、主题商店、黑名单一类）内容最小宽度
        七八百像素，窗口窄到 880 时右侧就会被切掉一截，看着像「只显示一半」。
        包一层可横竖滚的 QScrollArea 之后，窄窗口也能左右拖到，不会丢内容。
        """
        for i in range(self.tabs.count() - 1, -1, -1):
            page = self.tabs.widget(i)
            if page is None or page is False:
                continue
            try:
                if page.metaObject().className() == "QScrollArea":
                    continue
            except Exception:
                pass
            sa = QScrollArea()
            sa.setWidgetResizable(True)
            sa.setFrameShape(QFrame.NoFrame)
            sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            sa.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            sa.setStyleSheet("QScrollArea{background:transparent;}")
            sa.setMinimumWidth(0)
            title = self.tabs.tabText(i)
            self.tabs.removeTab(i)
            sa.setWidget(page)
            self.tabs.insertTab(i, sa, title)

    def _fits_names(self):
        """每个选项都要能看全名字。

        - 页签：上面已经关掉省略号，排不下用箭头滚。
        - 下拉框：弹出列表的宽度按最长的一项算，别显示成「1.21.11 For…」。
        - 按钮 / 勾选：真被挤窄了，至少鼠标悬停能看到全名。
        """
        for cb in self.findChildren(QComboBox):
            try:
                fm = cb.fontMetrics()
                items = [cb.itemText(i) for i in range(cb.count())]
                w = max([fm.horizontalAdvance(t) for t in items] or [0]) + 48
                if w > 0:
                    cb.view().setMinimumWidth(w)
            except Exception:
                continue
        for w in self.findChildren(QWidget):
            try:
                if isinstance(w, (QPushButton, QCheckBox, QRadioButton)):
                    txt = w.text()
                    if txt and not w.toolTip():
                        w.setToolTip(txt)
            except Exception:
                continue

    def _tab_record(self):
        """录屏：设帧率/画质 → 录 → 回放 → 剪一段 → 导出。"""
        try:
            from .record_page import RecordPage
            self.record_page = RecordPage(self.host)
            return self.record_page
        except Exception as e:
            self.record_page = None
            w = QWidget()
            v = QVBoxLayout(w)
            v.addWidget(QLabel("录屏页加载失败：%s" % e))
            return w

    def _tab_alarm(self):
        """闹钟 / 倒计时 / 秒表：时间精确到 0.01 秒，响铃不受免打扰影响。"""
        try:
            from .alarm_page import AlarmPage
            svc = self.host.alarm_svc()
            self.alarm_page = AlarmPage(self.host, svc)
            return self.alarm_page
        except Exception as e:
            self.alarm_page = None
            w = QWidget()
            v = QVBoxLayout(w)
            v.addWidget(QLabel("闹钟页加载失败：%s" % e))
            return w

    def _tab_modlang(self):
        """模组汉化：把模组里的英文语言文件翻成中文，出资源包。"""
        try:
            from .modlang_page import ModLangPage
            self.modlang_page = ModLangPage(self.host)
            return self.modlang_page
        except Exception as e:
            self.modlang_page = None
            w = QWidget()
            v = QVBoxLayout(w)
            v.addWidget(QLabel("模组汉化加载失败：%s" % e))
            return w

    def _tab_seedmap(self):
        """种子地图：填种子直接画整图，能拖动、能切群系 / 遗迹。"""
        try:
            from .seed_map_page import SeedMapPage
            self.seedmap_page = SeedMapPage(self.host)
            return self.seedmap_page
        except Exception as e:
            self.seedmap_page = None
            w = QWidget()
            v = QVBoxLayout(w)
            v.addWidget(QLabel("种子地图加载失败：%s" % e))
            return w

    def _tab_ench(self):
        """附魔计算：原来是左栏单独一页，现在并进工具页，独立界面已删掉。"""
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 10, 0, 0)
        v.setSpacing(10)
        hint = QLabel("RNG 附魔操控、铁砧并书、附魔台书架，三个都在这页。")
        hint.setObjectName("PageSub")
        v.addWidget(hint)
        try:
            from .enchant_dialog import EnchantCalcWidget
            self.ench_widget = EnchantCalcWidget()
            v.addWidget(self.ench_widget, 1)
        except Exception as e:
            self.ench_widget = None
            v.addWidget(QLabel("附魔计算加载失败：%s" % e))
        return w

    # ---------- 公共小工具 ----------
    def _gd(self):
        return self.cfg.get("game_dir") or ""

    def _log(self, msg):
        try:
            self.host._log("[工具] " + msg)
        except Exception:
            pass

    def _info(self, title, text):
        QMessageBox.information(self, title, text)

    def _ask(self, title, text):
        return QMessageBox.question(
            self, title, text,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes

    def _open_dir(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        except Exception as e:
            self._log("打开目录失败：%s" % e)

    def _btn_row(self, *pairs):
        """pairs: (文字, 回调)"""
        lay = QHBoxLayout()
        lay.setSpacing(8)
        for text, cb in pairs:
            b = QPushButton(text)
            b.clicked.connect(cb)
            lay.addWidget(b)
        lay.addStretch(1)
        return lay

    def _hint(self, text):
        lab = QLabel(text)
        lab.setObjectName("FieldLabel")
        lab.setWordWrap(True)
        return lab

    # ================= 1. 版本备份 =================
    def _tab_verbackup(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "把 versions/<版本> 整个目录打成一个 zip。换模组、试新版之前存一份；"
            "还原时当前目录会先改名成「<版本>_还原前-时间」留底，不会直接覆盖。"))

        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(QLabel("版本"))
        self.cb_vb_ver = QComboBox()
        self.cb_vb_ver.setMinimumWidth(220)
        row.addWidget(self.cb_vb_ver, 1)
        b_ref = QPushButton("刷新")
        b_ref.clicked.connect(self._vb_refresh)
        row.addWidget(b_ref)
        v.addLayout(row)

        self.in_vb_note = QLineEdit()
        self.in_vb_note.setPlaceholderText("备注（这次改了哪些模组 / 为什么备份），可留空")
        v.addWidget(self.in_vb_note)

        v.addLayout(self._btn_row(
            ("备份这个版本", self._vb_make),
            ("备份全部版本", self._vb_make_all),
            ("还原选中", self._vb_restore),
            ("删除选中", self._vb_delete),
            ("导入备份包", self._vb_import),
            ("导出备份包", self._vb_export),
            ("打开备份文件夹", lambda: self._open_dir(
                verbackup.backup_root(self._gd()) if self._gd() else ""))))

        self.list_vb = QListWidget()
        self.list_vb.setSelectionMode(QAbstractItemView.SingleSelection)
        v.addWidget(self.list_vb, 1)
        self.lab_vb = self._hint("")
        v.addWidget(self.lab_vb)
        # 列版本要遍历目录算大小，等页面建好再扫，别拖慢启动
        QTimer.singleShot(300, self._vb_refresh)
        return w

    def _vb_versions(self, gd):
        """只列目录名，不算大小——算大小要 walk 整个版本目录，会卡界面。"""
        d = os.path.join(gd or "", "versions")
        if not os.path.isdir(d):
            return []
        names = []
        for n in sorted(os.listdir(d)):
            if "_还原前-" in n:
                continue      # 还原时留的底，不是能启动的版本
            if os.path.isdir(os.path.join(d, n)):
                names.append(n)
        return names

    def _vb_refresh(self):
        try:
            gd = self._gd()
            cur = self.cb_vb_ver.currentData()
            self.cb_vb_ver.clear()
            if not gd:
                self.lab_vb.setText("还没设置游戏目录。")
                self.list_vb.clear()
                return
            for vid in self._vb_versions(gd):
                self.cb_vb_ver.addItem(vid, vid)
            if cur:
                i = self.cb_vb_ver.findData(cur)
                if i >= 0:
                    self.cb_vb_ver.setCurrentIndex(i)
            self.list_vb.clear()
            rows = verbackup.list_backups(gd)
            for r in rows:
                txt = "%s　%s　%s　%.1f MB" % (
                    r["version"], r["time"], r["note"] or "（无备注）", r["size_mb"])
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, r["path"])
                self.list_vb.addItem(it)
            self.lab_vb.setText("共 %d 份版本备份。" % len(rows) if rows
                                else "还没有版本备份。")
        except Exception as e:
            self._log("读版本备份失败：%s" % e)

    def _vb_make(self):
        try:
            gd = self._gd()
            vid = self.cb_vb_ver.currentData()
            if not vid:
                self._info("先选版本", "上面下拉里还没有可备份的版本。")
                return
            r = verbackup.make(gd, vid, self.in_vb_note.text().strip(),
                               log=self._log)
            self.in_vb_note.clear()
            self._vb_refresh()
            self._info("备份好了",
                       "%s\n%d 个文件，%.1f MB" % (os.path.basename(r["path"]),
                                                r["files"], r["size_mb"]))
        except Exception as e:
            self._info("备份失败", str(e))

    def _vb_restore(self):
        it = self.list_vb.currentItem()
        if not it:
            self._info("先选一份", "在下面的列表里点一份备份。")
            return
        path = it.data(Qt.UserRole)
        if not self._ask("还原版本",
                         "用这份备份覆盖回去？\n%s\n\n当前版本目录会先留底。"
                         % os.path.basename(path)):
            return
        try:
            r = verbackup.restore(self._gd(), path, log=self._log)
            try:
                self.host._load_versions()
            except Exception:
                pass
            self._vb_refresh()
            self._info("还原完成", "已还原：%s%s" % (
                r["version"],
                ("\n旧目录留底：" + os.path.basename(r["prev"])) if r["prev"] else ""))
        except Exception as e:
            self._info("还原失败", str(e))

    def _vb_delete(self):
        it = self.list_vb.currentItem()
        if not it:
            return
        path = it.data(Qt.UserRole)
        if not self._ask("删除备份", "删掉这份备份？只删备份，不动任何版本。\n%s"
                         % os.path.basename(path)):
            return
        try:
            verbackup.delete(path)
            self._vb_refresh()
        except Exception as e:
            self._info("删除失败", str(e))

    def _vb_import(self):
        files, _f = QFileDialog.getOpenFileNames(
            self, "选备份包", verbackup.backup_root(self._gd() if self._gd() else "."),
            "备份包 (*.zip)")
        if not files:
            return
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            root = verbackup.backup_root(gd)
            for src in files:
                dst = os.path.join(root, os.path.basename(src))
                if os.path.abspath(src) != os.path.abspath(dst):
                    shutil.copy2(src, dst)
            self._vb_refresh()
            self._info("导入完成", "已放进备份列表，选中后点「还原选中」即可。")
        except Exception as e:
            self._info("导入失败", str(e))

    def _vb_make_all(self):
        """给 versions 下每个版本各打一份备份，一次搞定。"""
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        vers = [self.cb_vb_ver.itemData(i) for i in range(self.cb_vb_ver.count())]
        if not vers:
            self._info("没有版本", "versions 目录里还没有可备份的版本。")
            return
        if not self._ask("备份全部版本",
                         "把 %d 个版本各打一份备份？备份比较占空间，"
                         "打完可以在列表里删掉多余的。" % len(vers)):
            return
        note = self.in_vb_note.text().strip() or (
            "全部版本 · " + time.strftime("%m-%d %H:%M"))
        ok, fails = 0, []
        for vid in vers:
            try:
                verbackup.make(gd, vid, note, log=self._log)
                ok += 1
            except Exception as e:
                fails.append("%s：%s" % (vid, e))
        self.in_vb_note.clear()
        self._vb_refresh()
        txt = "备份好 %d 份。" % ok
        if fails:
            txt += "\n失败 %d 份：\n%s" % (len(fails), "\n".join(fails[:5]))
        self._info("全部备份完成", txt)

    def _vb_export(self):
        """把选中的备份包复制到别的地方（发给别人 / 存到移动硬盘）。"""
        it = self.list_vb.currentItem()
        if not it:
            self._info("先选一份", "在下面列表里点中一份备份再导出。")
            return
        src = it.data(Qt.UserRole)
        try:
            start_dir = self.host._desktop_dir()
        except Exception:
            start_dir = os.path.expanduser("~")
        dst_dir = QFileDialog.getExistingDirectory(self, "导出到哪个文件夹", start_dir)
        if not dst_dir:
            return
        try:
            dst = os.path.join(dst_dir, os.path.basename(src))
            shutil.copy2(src, dst)
            self._info("导出好了", "已复制到：\n%s" % dst)
        except Exception as e:
            self._info("导出失败", str(e))

    # ================= 2. 模组冲突 =================
    def _tab_conflict(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "只看 mods 目录里 jar 的元数据，不用启动游戏就能查出：同一个模组装了"
            "两个版本、缺前置、要求的 MC 版本不对、复制出来的重复文件。"))

        row = QHBoxLayout()
        row.addWidget(QLabel("MC 版本"))
        self.in_mc = QLineEdit()
        self.in_mc.setPlaceholderText("例如 1.21.1；留空就跳过版本匹配检查")
        row.addWidget(self.in_mc, 1)
        v.addLayout(row)

        v.addLayout(self._btn_row(
            ("扫描 mods", self._scan_mods),
            ("打开 mods 文件夹", lambda: self._open_dir(
                os.path.join(self._gd(), "mods") if self._gd() else "")),
            ("清空结果", lambda: self.tree_mods.clear())))

        self.tree_mods = QTreeWidget()
        self.tree_mods.setColumnCount(2)
        self.tree_mods.setHeaderLabels(["问题", "涉及文件 / 说明"])
        self.tree_mods.setColumnWidth(0, 320)
        v.addWidget(self.tree_mods, 1)
        self.lab_mods = self._hint("还没扫描。")
        v.addWidget(self.lab_mods)
        return w

    def _scan_mods(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            mc = self.in_mc.text().strip()
            if not mc:
                try:
                    mc = self.host._selected_version_id() or ""
                except Exception:
                    mc = ""
            res = modconflict.scan(gd, mc, log=self._log)
            self.tree_mods.clear()
            for issue in res["issues"]:
                child = QTreeWidgetItem([issue["title"], "；".join(issue["files"])])
                child.setForeground(0, Qt.red if issue["level"] == "error"
                                    else Qt.yellow)
                tip = QTreeWidgetItem([issue["detail"], ""])
                tip.setFirstColumnSpanned(True)
                self.tree_mods.addTopLevelItem(child)
                self.tree_mods.addTopLevelItem(tip)
            errs = res.get("errors", 0)
            if errs:
                self.lab_mods.setText(
                    "扫了 %d 个 jar，%d 条问题，其中 %d 条会直接启动失败。"
                    % (res["count"], len(res["issues"]), errs))
            elif res["issues"]:
                self.lab_mods.setText("扫了 %d 个 jar，只有警告，不影响启动。"
                                     % res["count"])
            else:
                self.lab_mods.setText("扫了 %d 个 jar，没发现问题。" % res["count"])
        except Exception as e:
            self._info("扫描失败", str(e))

    # ================= 3. 日志诊断 =================
    def _tab_logs(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "读 logs/latest.log 和 crash-reports 里最新一份，把常见报错翻成中文并给做法；"
            "下面同时保留最后几十行原文，方便发给别人看。"))
        v.addLayout(self._btn_row(
            ("分析最近日志", self._analyze_logs),
            ("一键打包日志（存桌面）", self._pack_all_logs),
            ("打包并上传日志", self._pack_and_upload),
            ("导出环境报告", self._export_env),
            ("打开日志文件夹", lambda: self._open_dir(
                os.path.join(self._gd(), "logs") if self._gd() else "")),
            ("打开崩溃报告", lambda: self._open_dir(
                os.path.join(self._gd(), "crash-reports") if self._gd() else "")),
            ("复制全部", lambda: self._copy_text(self.txt_logs))))
        v.addLayout(self._btn_row(
            ("看启动器崩溃日志", self._show_crash_log),
            ("清空启动器日志", self._clear_crash_log),
            ("打开启动器数据目录", lambda: self._open_dir(
                os.path.expanduser("~/.simple_mc_launcher")))))
        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        v.addWidget(self.txt_logs, 1)
        return w

    # ================= 网络自检 =================
    def _tab_netself(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "把「下载慢、登录慢、手机扫码打不开」拆成四项实测：本机局域网地址、"
            "扫码确认页端口、域名解析耗时、更新站点与两条下载短链的响应时间。"
            "报告是纯文本，可以直接复制发给别人。"))
        v.addLayout(self._btn_row(
            ("开始自检", self._run_netcheck),
            ("复制报告", lambda: self._copy_text(self.txt_net)),
            ("扫码打不开怎么办", self._net_qr_help)))
        self.txt_net = QTextEdit()
        self.txt_net.setReadOnly(True)
        self.txt_net.setPlainText(
            "点「开始自检」。整个过程 3-15 秒，在后台线程里跑，界面不会卡。")
        v.addWidget(self.txt_net, 1)
        return w

    def _run_netcheck(self):
        if getattr(self, "_net_worker", None) is not None:
            self._log("自检正在跑，等这次结果")
            return
        from .workers import NetCheckWorker
        self.txt_net.setPlainText("正在自检……\n\n（DNS 解析、站点、两条下载短链、扫码端口）")
        wk = NetCheckWorker()
        self._net_worker = wk

        def _done(res):
            try:
                if isinstance(res, dict) and res.get("error"):
                    self.txt_net.setPlainText("自检失败：%s" % res["error"])
                else:
                    self.txt_net.setPlainText(netcheck.report_text(res))
                    self._log("网络自检完成")
            except Exception as e:
                self.txt_net.setPlainText("自检结果处理失败：%s" % e)
            finally:
                self._net_worker = None
                try:
                    wk.deleteLater()
                except Exception:
                    pass

        wk.done.connect(_done)
        wk.start()

    def _net_qr_help(self):
        QMessageBox.information(
            self, "手机扫码打不开 / 很慢",
            "按顺序试，能一步解决就别往下走：\n\n"
            "1. 手机和电脑连同一个 Wi-Fi，手机别用流量。\n"
            "2. 微信里点右上角「…」→「在浏览器打开」；QQ 内置浏览器更严，"
            "建议直接用手机自带相机扫码，落到系统浏览器。\n"
            "3. 公寓 / 酒店 / 公司 / 校园 Wi-Fi 常开「设备隔离」，手机和电脑之间"
            "根本互相连不上。这种网络只能用手机开热点、让电脑连手机热点，再扫码。\n"
            "4. 第一次运行时 Windows 会弹「是否允许访问网络」，点允许。\n\n"
            "自检里扫码端口显示可用、站点也正常，而手机就是打不开，基本就是第 3 条。")

    # ================= 帧率优化 =================
    def _tab_fps(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "按本机 CPU 核数、内存余量和屏幕刷新率，给一套 options.txt 推荐值。"
            "应用时只写你没设过的项：自己调过的渲染距离、画质不会被悄悄改回去。"))
        v.addLayout(self._btn_row(
            ("重新检测", self._fps_scan),
            ("应用到游戏目录", self._fps_apply),
            ("复制建议", lambda: self._copy_text(self.txt_fps))))
        self.txt_fps = QTextEdit()
        self.txt_fps.setReadOnly(True)
        v.addWidget(self.txt_fps, 1)
        self._fps_values = {}
        self._fps_scan()
        return w

    def _refresh_rate(self):
        try:
            scr = QGuiApplication.primaryScreen()
            return scr.refreshRate() if scr is not None else 60
        except Exception:
            return 60

    def _fps_scan(self):
        try:
            h = fpsadvice.hw()
            values, reasons = fpsadvice.recommend(h, self._refresh_rate())
            self._fps_values = values
            tail = ("\n\n（还没设游戏目录：现在只给建议，选好目录后再点「应用到游戏目录」。）"
                    if not self._gd() else "")
            self.txt_fps.setPlainText(fpsadvice.text(h, values, reasons) + tail)
        except Exception as e:
            self.txt_fps.setPlainText("检测失败：%s" % e)

    def _fps_apply(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        if not getattr(self, "_fps_values", None):
            self._fps_scan()
        if not self._fps_values:
            self._info("没建议", "点一次「重新检测」再应用。")
            return
        try:
            changed, path = game_options.apply_options(
                gd, self._fps_values, only_missing=True)
        except Exception as e:
            self._info("写入失败", str(e))
            return
        if changed == 0:
            self._info("没改东西",
                       "这些项在 options.txt 里都已经设过，保持你原来的值。\n%s" % path)
        else:
            self._info("写好了",
                       "改了 %d 项：\n%s\n\n下次启动游戏生效；游戏现在开着的话先关掉再启动。"
                       % (changed, path))
        self._log("帧率设置写入 %d 项" % changed)


    # ---------- 启动器自己的崩溃日志 ----------
    def _crash_log_path(self):
        return os.path.expanduser("~/.simple_mc_launcher/crash.log")

    def _show_crash_log(self):
        """看启动器进程自己挂掉时留下的栈。

        任务栏里那个「像崩溃的程序」以前查不出原因，就是因为这类 0xc0000005
        根本没进过游戏日志；现在从 crash.log 里直接看得到。
        """
        path = self._crash_log_path()
        if not os.path.isfile(path):
            self.txt_logs.setPlainText(
                "启动器没有崩溃记录。\n\n%s 不存在，说明从上次清空到现在没出过"
                "未捕获异常，也没发生过 C 层崩溃。" % path)
            self._log("崩溃日志：没有记录")
            return
        try:
            size = os.path.getsize(path)
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                data = f.read()
        except Exception as e:
            self.txt_logs.setPlainText("读崩溃日志失败：%s" % e)
            return
        lines = data.splitlines()
        tail = lines[-160:]
        head = ["崩溃日志：%s（%d 字节，共 %d 行，下面只显示最后 %d 行）"
                % (path, size, len(lines), len(tail)), ""]
        self.txt_logs.setPlainText("\n".join(head + tail))
        self._log("崩溃日志：%d 字节" % size)

    def _clear_crash_log(self):
        path = self._crash_log_path()
        if not os.path.isfile(path):
            self._info("没什么可清的", "启动器还没有崩溃记录。")
            return
        if not self._ask("清空崩溃日志",
                         "把 %s 清空？\n清空前如果想留证据，先点「看启动器崩溃日志」"
                         "复制一份。" % path):
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("")
        except Exception as e:
            self._info("清不掉", "文件被占用或没权限：%s" % e)
            return
        self.txt_logs.setPlainText("崩溃日志已清空。")
        self._log("崩溃日志已清空")

    def _copy_text(self, edit):
        try:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(edit.toPlainText())
            self._log("已复制到剪贴板")
        except Exception:
            pass

    def _analyze_logs(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        try:
            rep = logview.report(gd)
            lines = []
            lines.append("结论：" + rep["summary"])
            lines.append("最近日志：%s %s" % (rep["log_path"] or "（没有 latest.log）",
                                          rep["log_time"]))
            lines.append("崩溃报告：%s %s" % (rep["crash_path"] or "（没有 crash-reports）",
                                          rep["crash_time"]))
            lines.append("")
            for it in rep["items"]:
                lines.append("【%s】%s" % ("错误" if it["level"] == "error" else "警告",
                                       it["title"]))
                lines.append("  建议：" + it["advice"])
                lines.append("  原文：" + it["evidence"])
                lines.append("")
            if not rep["items"]:
                lines.append("没匹配到已知故障，把下面最后 40 行原文发给开发者。")
                lines.append("")
            lines.append("====== 日志末尾 ======")
            lines.append(rep["tail"] or "（空）")
            self.txt_logs.setPlainText("\n".join(lines))
            self._log("日志诊断：" + rep["summary"])
        except Exception as e:
            self.txt_logs.setPlainText("分析失败：%s" % e)

    def _pack_all_logs(self):
        """一键：启动器日志 + 游戏日志 + 崩溃报告 + 环境报告 + 模组清单 → 桌面 zip。"""
        try:
            out = self.host._pack_logs_quick()
        except Exception as e:
            self._info("打包失败", str(e))
            return
        try:
            self.txt_logs.append("\n（已打包到：%s）" % out)
        except Exception:
            pass
        self._info("打包好了",
                   "日志、崩溃报告、环境报告、模组清单都收进去了：\n%s\n\n"
                   "路径已经复制到剪贴板，发给开发者时直接粘贴就行。" % out)
        self._open_dir(os.path.dirname(out))

    def _pack_and_upload(self):
        """打包日志后传到一个免登录的临时空间，直接把链接发出去。"""
        try:
            out = self.host._pack_logs_quick()
        except Exception as e:
            self._info("打包失败", str(e))
            return
        from PySide6.QtWidgets import QApplication
        from PySide6.QtCore import Qt as _Qt
        try:
            QApplication.setOverrideCursor(_Qt.WaitCursor)
        except Exception:
            pass
        try:
            from core import uploader
            ok, msg = uploader.upload(out)
        except Exception as e:
            ok, msg = False, "上传失败：%s" % e
        try:
            QApplication.restoreOverrideCursor()
        except Exception:
            pass
        if not ok:
            try:
                self.txt_logs.append("\n（zip 在：%s；上传没成功：%s）" % (out, msg))
            except Exception:
                pass
            self._info("上传没成功",
                       "日志已经打包在：\n%s\n\n原因：%s\n\n"
                       "直接把桌面这个 zip 发出去也一样。" % (out, msg))
            return
        try:
            QApplication.clipboard().setText(msg)
        except Exception:
            pass
        try:
            self.txt_logs.append("\n（日志已上传：%s（链接已复制））" % msg)
        except Exception:
            pass
        self._info("日志上传好了",
                   "把这个链接发出去就能看到全部日志：\n%s\n\n"
                   "链接已经复制到剪贴板。这是临时空间，别当长期存档用。" % msg)
        self._log("日志已上传：%s" % msg)

    def _export_env(self):
        """把启动器体检结果导成一份 txt，出问题发这一份最省事。"""
        try:
            txt = syscheck.report_text()
        except Exception as e:
            txt = "环境报告生成失败：%s" % e
        try:
            base = self.host._desktop_dir()
        except Exception:
            base = os.path.expanduser("~")
        out = os.path.join(base, "OMC环境报告_%s.txt"
                           % time.strftime("%Y%m%d_%H%M%S"))
        try:
            with open(out, "w", encoding="utf-8") as f:
                f.write(txt)
        except Exception as e:
            self._info("写入失败", str(e))
            return
        try:
            self.txt_logs.setPlainText(txt)
        except Exception:
            pass
        self._info("环境报告", "已存到：\n%s" % out)
        self._open_dir(os.path.dirname(out))

    # ================= 4. Java 管理 =================
    def _tab_java(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "自动检测出来的所有 Java（含 JAVA_HOME、PATH、各厂商安装目录）。"
            "给某个版本钉死一个 Java 后，启动它时就优先用这个，不再自动挑。"))
        v.addLayout(self._btn_row(
            ("重新检测", self._scan_java),
            ("用选中的 Java 跑当前版本", self._pin_java),
            ("改回自动挑选", self._unpin_java),
            ("打开 Java 目录", self._open_java_dir)))
        self.lab_java = self._hint("")
        v.addWidget(self.lab_java)
        self.list_java = QListWidget()
        v.addWidget(self.list_java, 1)
        # 检测 Java 要起子进程，晚一点再扫
        QTimer.singleShot(600, self._scan_java)
        return w

    def _scan_java(self):
        try:
            rows = javaman.list_all()
            self.list_java.clear()
            for r in rows:
                it = QListWidgetItem(r["label"])
                it.setToolTip(r["path"])
                it.setData(Qt.UserRole, r["path"])
                self.list_java.addItem(it)
            if not rows:
                self.lab_java.setText("没检测到任何 Java。可以在设置页点「自动检测」，"
                                      "或先装一个 Java 21。")
            else:
                try:
                    vid = self.host._selected_version_id() or ""
                except Exception:
                    vid = ""
                rec = javaman.recommended(vid) if vid else None
                pinned = javaman.get_pref(self.cfg, vid) if vid else ""
                txt = "检测到 %d 个 Java（主版本：%s）。" % (
                    len(rows), "、".join(str(r["major"]) for r in rows))
                if rec:
                    txt += " 当前版本 %s 建议 Java %d。" % (vid, rec["need"])
                if pinned:
                    txt += " 现在钉死用：%s" % os.path.basename(os.path.dirname(
                        os.path.dirname(pinned)))
                self.lab_java.setText(txt)
        except Exception as e:
            self.lab_java.setText("检测失败：%s" % e)

    def _pin_java(self):
        it = self.list_java.currentItem()
        if not it:
            self._info("先选一个", "在上面列表里点一个 Java。")
            return
        try:
            vid = self.host._selected_version_id() or ""
        except Exception:
            vid = ""
        if not vid:
            self._info("先选版本", "先在启动页选一个版本再钉 Java。")
            return
        try:
            javaman.set_pref(self.cfg, vid, it.data(Qt.UserRole))
            self._scan_java()
            self._log("已把 %s 的 Java 钉成：%s" % (vid, it.data(Qt.UserRole)))
        except Exception as e:
            self._info("设置失败", str(e))

    def _unpin_java(self):
        try:
            vid = self.host._selected_version_id() or ""
        except Exception:
            vid = ""
        if not vid:
            return
        javaman.set_pref(self.cfg, vid, "")
        self._scan_java()
        self._log("已改回自动挑选 Java（%s）" % vid)

    def _open_java_dir(self):
        it = self.list_java.currentItem()
        if it:
            self._open_dir(os.path.dirname(it.data(Qt.UserRole) or ""))
            return
        try:
            rows = javaman.list_all()
        except Exception:
            rows = []
        if rows:
            self._open_dir(os.path.dirname(os.path.dirname(rows[0]["path"])))

    # ================= 5. 批量导入导出 =================
    def _tab_batch(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        row = QHBoxLayout()
        row.addWidget(QLabel("类型"))
        self.cb_batch = QComboBox()
        for k in ("mod", "shader", "resourcepack", "datapack"):
            self.cb_batch.addItem(packflow.KIND_NAMES[k], k)
        self.cb_batch.currentIndexChanged.connect(self._refresh_installed)
        row.addWidget(self.cb_batch)
        row.addStretch(1)
        v.addLayout(row)
        v.addWidget(self._hint(
            "导入只复制、绝不覆盖同名文件：重名的自动加 -2、-3。"
            "导出会按 mods/、shaderpacks/ 这样的目录结构打包，对方解压就能用。"))
        v.addLayout(self._btn_row(
            ("导入文件…", self._batch_import_files),
            ("导入整个文件夹…", self._batch_import_dir),
            ("导出选中为 zip", self._batch_export),
            ("查重复", self._batch_dups),
            ("刷新", self._refresh_installed)))
        self.list_batch = QListWidget()
        self.list_batch.setSelectionMode(QAbstractItemView.ExtendedSelection)
        v.addWidget(self.list_batch, 1)
        self.lab_batch = self._hint("")
        v.addWidget(self.lab_batch)
        self._refresh_installed()
        return w

    def _refresh_installed(self, *_):
        try:
            gd = self._gd()
            kid = self.cb_batch.currentData() or "mod"
            self.list_batch.clear()
            if not gd:
                self.lab_batch.setText("还没设置游戏目录。")
                return
            rows = packflow.scan_installed(gd, kid)
            for r in rows:
                txt = "%s　%.2f MB%s" % (r["name"], r["size_mb"],
                                         "（已禁用）" if r["disabled"] else "")
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, r["name"])
                self.list_batch.addItem(it)
            self.lab_batch.setText("已装 %d 个%s；按住 Ctrl / Shift 可多选。"
                                   % (len(rows), packflow.KIND_NAMES.get(kid, "")))
        except Exception as e:
            self.lab_batch.setText("读取失败：%s" % e)

    def _batch_import_files(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        kid = self.cb_batch.currentData()
        files, _f = QFileDialog.getOpenFileNames(self, "选要导入的文件")
        if not files:
            return
        try:
            res = packflow.import_many(gd, files, kid, log=self._log)
            self._refresh_installed()
            msg = "导入 %d 个；重名改名 %d 个；跳过 %d 个；失败 %d 个。" % (
                len(res["ok"]), len(res["dup"]), len(res["skip"]),
                len(res["error"]))
            if res["skip"]:
                msg += "\n跳过：" + "；".join(res["skip"][:6])
            if res["error"]:
                msg += "\n失败：" + "；".join(res["error"][:6])
            self._info("批量导入", msg)
        except Exception as e:
            self._info("导入失败", str(e))

    def _batch_import_dir(self):
        gd = self._gd()
        if not gd:
            self._info("没游戏目录", "先在设置里选游戏目录。")
            return
        d = QFileDialog.getExistingDirectory(self, "选一个文件夹（里面的文件全部导入）")
        if not d:
            return
        try:
            res = packflow.import_many(gd, [d], self.cb_batch.currentData(),
                                      log=self._log)
            self._refresh_installed()
            self._info("批量导入", "导入 %d 个；改名 %d 个；跳过 %d 个；失败 %d 个。"
                       % (len(res["ok"]), len(res["dup"]), len(res["skip"]),
                          len(res["error"])))
        except Exception as e:
            self._info("导入失败", str(e))

    def _batch_export(self):
        items = self.list_batch.selectedItems()
        if not items:
            self._info("先选条目", "在下面列表里选中要导出的（可多选）。")
            return
        gd = self._gd()
        kid = self.cb_batch.currentData() or "mod"
        names = [it.data(Qt.UserRole) for it in items]
        stamp = time.strftime("%Y%m%d-%H%M")
        default = os.path.join(os.path.dirname(gd) or ".",
                               "OMC-%s-%s.zip" % (packflow.KIND_NAMES.get(kid, kid),
                                                 stamp))
        out, _f = QFileDialog.getSaveFileName(self, "导出到哪里", default, "Zip (*.zip)")
        if not out:
            return
        try:
            r = packflow.export_zip(gd, kid, names, out, log=self._log)
            self._info("导出完成", "%s\n%d 个文件，%.1f MB"
                       % (r["path"], r["files"], r["size_mb"]))
        except Exception as e:
            self._info("导出失败", str(e))

    def _batch_dups(self):
        gd = self._gd()
        if not gd:
            return
        try:
            kid = self.cb_batch.currentData() or "mod"
            groups = packflow.find_duplicates(gd, kid)
            if not groups:
                self._info("查重结果", "没发现同名重复文件。")
                return
            self._info("查重结果", "发现 %d 组疑似重复：\n\n%s"
                       % (len(groups), "\n".join(" / ".join(g) for g in groups[:12])))
        except Exception as e:
            self._info("查重失败", str(e))

    # ================= 6. 收藏夹 =================
    def _tab_favs(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        row = QHBoxLayout()
        row.addWidget(QLabel("类型"))
        self.cb_fav = QComboBox()
        self.cb_fav.addItem("全部", "")
        for k, name in favorites.KINDS.items():
            self.cb_fav.addItem(name, k)
        self.cb_fav.currentIndexChanged.connect(self._refresh_favs)
        row.addWidget(self.cb_fav)
        row.addStretch(1)
        v.addLayout(row)
        v.addWidget(self._hint(
            "收藏是跨功能的：模组、光影、资源包、存档、版本、歌曲都在这里。"
            "可以导出成一份 json 换电脑带走。"))
        v.addLayout(self._btn_row(
            ("刷新", self._refresh_favs),
            ("移除选中", self._fav_remove),
            ("打开所在目录", self._fav_open),
            ("导出 json", self._fav_export),
            ("导入 json", self._fav_import)))
        self.list_fav = QListWidget()
        self.list_fav.setSelectionMode(QAbstractItemView.ExtendedSelection)
        v.addWidget(self.list_fav, 1)
        self.lab_fav = self._hint("")
        v.addWidget(self.lab_fav)
        self._refresh_favs()
        return w

    def _refresh_favs(self, *_):
        try:
            kind = self.cb_fav.currentData() or None
            rows = favorites.listing(kind)
            self.list_fav.clear()
            for r in rows:
                t = time.strftime("%m-%d %H:%M", time.localtime(r.get("at") or 0))
                txt = "[%s] %s　%s" % (favorites.KINDS.get(r.get("kind"), "?"),
                                      r.get("name") or r.get("id"), t)
                it = QListWidgetItem(txt)
                it.setData(Qt.UserRole, (r.get("kind"), r.get("id")))
                it.setData(Qt.UserRole + 1, r.get("path") or "")
                self.list_fav.addItem(it)
            c = favorites.counts()
            self.lab_fav.setText("收藏 %d 条（模组 %d / 光影 %d / 资源包 %d / 存档 %d / 版本 %d / 歌曲 %d）"
                                 % (c["total"], c["mod"], c["shader"],
                                    c["resourcepack"], c["world"],
                                    c["version"], c["music"]))
        except Exception as e:
            self.lab_fav.setText("读取收藏失败：%s" % e)

    def _fav_remove(self):
        items = self.list_fav.selectedItems()
        if not items:
            return
        try:
            for it in items:
                kind, key = it.data(Qt.UserRole)
                favorites.remove(kind, key)
            self._refresh_favs()
        except Exception as e:
            self._log("移除收藏失败：%s" % e)

    def _fav_open(self):
        it = self.list_fav.currentItem()
        if not it:
            return
        p = it.data(Qt.UserRole + 1) or ""
        if p and os.path.exists(p):
            self._open_dir(os.path.dirname(p) if os.path.isfile(p) else p)
        else:
            self._info("没有路径", "这条收藏没记录本地路径（可能是线上条目）。")

    def _fav_export(self):
        out, _f = QFileDialog.getSaveFileName(
            self, "导出收藏", os.path.join(self._gd() or ".", "omc-favorites.json"),
            "JSON (*.json)")
        if not out:
            return
        try:
            with open(out, "w", encoding="utf-8") as f:
                f.write(favorites.export_all())
            self._info("导出完成", out)
        except Exception as e:
            self._info("导出失败", str(e))

    def _fav_import(self):
        path, _f = QFileDialog.getOpenFileName(self, "选收藏文件", "",
                                              "JSON (*.json);;所有文件 (*)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                n = favorites.import_text(f.read(), merge=True)
            self._refresh_favs()
            self._info("导入完成", "新增 %d 条收藏。" % n)
        except Exception as e:
            self._info("导入失败", str(e))

    # ================= 7. 截图相册 =================
    def _tab_shots(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint("游戏里按 F2 拍的截图都在这里。双击放大，可导出、可设为启动器背景。"))
        v.addLayout(self._btn_row(
            ("刷新", self._refresh_shots),
            ("打开截图文件夹", self._open_shots_dir),
            ("导出选中", self._export_shots),
            ("设为启动器背景", self._shot_as_bg)))
        self.list_shots = QListWidget()
        self.list_shots.setViewMode(QListWidget.IconMode)
        self.list_shots.setIconSize(QSize(176, 100))
        self.list_shots.setGridSize(QSize(190, 132))
        self.list_shots.setResizeMode(QListWidget.Adjust)
        self.list_shots.setSpacing(6)
        self.list_shots.setMovement(QListWidget.Static)
        self.list_shots.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list_shots.itemDoubleClicked.connect(lambda it: self._open_shot(it))
        v.addWidget(self.list_shots, 1)
        self.lab_shots = self._hint("")
        v.addWidget(self.lab_shots)
        self._refresh_shots()
        return w

    def _refresh_shots(self):
        try:
            gd = self._gd()
            self.list_shots.clear()
            if not gd:
                self.lab_shots.setText("还没设置游戏目录。")
                return
            rows = screenshots.list_shots(gd)
            for path, mtime, kb in rows[:60]:
                pix = QPixmap(path)
                if not pix.isNull():
                    icon = QIcon(pix.scaled(176, 100, Qt.KeepAspectRatio,
                                            Qt.SmoothTransformation))
                else:
                    icon = QIcon()
                it = QListWidgetItem(icon, os.path.basename(path))
                it.setData(Qt.UserRole, path)
                it.setToolTip("%s\n%.1f KB" % (path, kb))
                self.list_shots.addItem(it)
            self.lab_shots.setText("共 %d 张，显示最近 %d 张。"
                                   % (len(rows), min(60, len(rows)))
                                   if rows else "screenshots 目录还是空的。")
        except Exception as e:
            self.lab_shots.setText("读取截图失败：%s" % e)

    def _open_shots_dir(self):
        gd = self._gd()
        if gd:
            self._open_dir(screenshots.screenshots_dir(gd))

    def _open_shot(self, it):
        p = it.data(Qt.UserRole)
        if p and os.path.isfile(p):
            QDesktopServices.openUrl(QUrl.fromLocalFile(p))

    def _export_shots(self):
        items = self.list_shots.selectedItems()
        if not items:
            return
        d = QFileDialog.getExistingDirectory(self, "导出到哪个文件夹")
        if not d:
            return
        done, fail = 0, 0
        for it in items:
            try:
                shutil.copy2(it.data(Qt.UserRole), os.path.join(
                    d, os.path.basename(it.data(Qt.UserRole))))
                done += 1
            except Exception:
                fail += 1
        self._info("导出完成", "成功 %d 张，失败 %d 张。\n%s" % (done, fail, d))

    def _shot_as_bg(self):
        it = self.list_shots.currentItem() or (
            self.list_shots.selectedItems()[0]
            if self.list_shots.selectedItems() else None)
        if not it:
            self._info("先选一张", "点一张截图再设背景。")
            return
        p = it.data(Qt.UserRole)
        try:
            if hasattr(self.host, "_apply_background_path"):
                self.host._apply_background_path(p)
                self._info("换好了", "启动器背景已换成：%s" % os.path.basename(p))
            else:
                self.cfg.set("background_image", p)
                self.cfg.save()
        except Exception as e:
            self._info("设置失败", str(e))

    # ================= 8. 主题商店 =================
    def _tab_theme(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint("整套配色 + 按键形状一键换上，立刻生效并记住。也可以导出成文件发给别人。"))
        grid = QGridLayout()
        grid.setSpacing(9)
        self._theme_btns = {}
        for i, p in enumerate(themes.presets()):
            b = QPushButton("%s\n%s" % (p["name"], p["desc"]))
            b.setMinimumHeight(54)
            b.setToolTip(p["desc"])
            b.clicked.connect(lambda _c=False, pid=p["id"]: self._apply_theme(pid))
            grid.addWidget(b, i // 3, i % 3)
            self._theme_btns[p["id"]] = b
        v.addLayout(grid)
        v.addLayout(self._btn_row(
            ("导出当前主题", self._theme_export),
            ("导入主题文件", self._theme_import),
            ("恢复原版深色", lambda: self._apply_theme("omc_dark"))))
        self.lab_theme = self._hint("")
        v.addWidget(self.lab_theme)
        v.addStretch(1)
        self._refresh_theme_label()
        return w

    def _refresh_theme_label(self):
        cur = themes.current(self.cfg)
        if cur:
            self.lab_theme.setText("当前：%s（%s / %s / %s）" % (
                cur["name"], cur["theme"], cur["accent"], cur["button"]))
        else:
            self.lab_theme.setText("当前：自定义（%s / %s / %s）" % (
                self.cfg.get("theme") or "dark",
                self.cfg.get("ui_accent") or "blue",
                self.cfg.get("ui_button") or "round"))
        for pid, b in getattr(self, "_theme_btns", {}).items():
            b.setChecked(bool(cur and cur["id"] == pid))
            b.setCheckable(True)

    def _apply_theme(self, pid):
        try:
            themes.apply(self.cfg, pid)
            self._sync_style_ui()
            self._refresh_theme_label()
            self._log("换主题：%s" % pid)
        except Exception as e:
            self._info("换主题失败", str(e))

    def _sync_style_ui(self):
        """把设置页那几个控件也对齐，避免两处显示不一致。"""
        try:
            for k, b in getattr(self.host, "_accent_btns", {}).items():
                b.setChecked(k == (self.cfg.get("ui_accent") or "blue"))
            ct = getattr(self.host, "combo_theme", None)
            if ct is not None:
                i = ct.findData(self.cfg.get("theme") or "dark")
                if i >= 0:
                    ct.setCurrentIndex(i)
            cb = getattr(self.host, "combo_btn_style", None)
            if cb is not None:
                i = cb.findData(self.cfg.get("ui_button") or "round")
                if i >= 0:
                    cb.setCurrentIndex(i)
            self.host._apply_ui_style()
        except Exception as e:
            self._log("同步主题控件失败：%s" % e)

    def _theme_export(self):
        out, _f = QFileDialog.getSaveFileName(
            self, "导出主题", os.path.join(themes.themes_dir(), "omc-theme.json"),
            "JSON (*.json)")
        if not out:
            return
        try:
            themes.export_file(self.cfg, out)
            self._info("导出完成", out)
        except Exception as e:
            self._info("导出失败", str(e))

    def _theme_import(self):
        path, _f = QFileDialog.getOpenFileName(self, "选主题文件", themes.themes_dir(),
                                              "JSON (*.json);;所有文件 (*)")
        if not path:
            return
        try:
            data = themes.import_file(path, self.cfg)
            self._sync_style_ui()
            self._refresh_theme_label()
            self._info("导入完成", "已换成：%s" % data.get("name", "导入的主题"))
        except Exception as e:
            self._info("导入失败", str(e))

    # ================= 9. 缓存清理 =================
    def _tab_clean(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "把启动器攒下来的临时文件清掉。默认勾上的删掉都会自动重新生成；"
            "「音乐缓存」默认不勾，清了「我的列表」里的歌要重新下载才能听。"))
        self.tree_cache = QTreeWidget()
        self.tree_cache.setHeaderLabels(["项目", "占用", "说明"])
        self.tree_cache.setRootIsDecorated(False)
        self.tree_cache.setSelectionMode(QAbstractItemView.NoSelection)
        self.tree_cache.setColumnWidth(0, 180)
        self.tree_cache.setColumnWidth(1, 90)
        v.addWidget(self.tree_cache, 1)
        row = self._btn_row(
            ("重新扫描", self._scan_cache),
            ("清理勾选", self._clean_cache),
            ("全部清理", self._clean_cache_all),
            ("打开缓存目录", self._open_cache_dir))
        self.b_scan_cache = row.itemAt(0).widget()
        self.b_clean = row.itemAt(1).widget()
        self.b_clean_all = row.itemAt(2).widget()
        v.addLayout(row)
        self.bar_cache = QProgressBar()
        self.bar_cache.setRange(0, 100)
        self.bar_cache.setValue(0)
        self.bar_cache.setTextVisible(True)
        self.bar_cache.setFormat("准备清理… %p%")
        self.bar_cache.hide()
        v.addWidget(self.bar_cache)
        self.lab_cache = self._hint("")
        v.addWidget(self.lab_cache)
        v.addLayout(self._btn_row(
            ("看内存占用", self._show_mem),
            ("整理内存", self._trim_mem),
            ("清理位图缓存", self._clear_pixmaps)))
        self.lab_mem = self._hint("")
        v.addWidget(self.lab_mem)
        # ---- 实时性能面板：CPU / 内存 / 线程 / UI 帧率 ----
        row_perf = self._btn_row(
            ("开始性能监控", self._toggle_perf),
            ("采样一次", self._peek_perf))
        self.b_perf = row_perf.itemAt(0).widget()
        v.addLayout(row_perf)
        self.lab_perf = self._hint(
            "没开监控。点「开始性能监控」每秒刷新一次；监控用的两个定时器只在监控期间跑，"
            "不占额外线程，关掉就全停。")
        v.addWidget(self.lab_perf)
        self._perf_on = False
        self._perf_n = 0
        self._fps_n = 0
        self._perf_timer = QTimer(self)
        self._perf_timer.setInterval(1000)
        self._perf_timer.timeout.connect(self._tick_perf)
        self._fps_timer = QTimer(self)
        self._fps_timer.setInterval(16)
        self._fps_timer.timeout.connect(self._fps_tick)
        self._scan_cache()
        return w

    # ---------- 实时性能监控 ----------
    def _fps_tick(self):
        """16 ms 一下，纯粹用来数事件循环一秒能转多少圈，也就是界面帧率。"""
        self._fps_n += 1

    def _toggle_perf(self):
        if self._perf_on:
            self._perf_timer.stop()
            self._fps_timer.stop()
            self._perf_on = False
            self.b_perf.setText("开始性能监控")
            self.lab_perf.setText("监控已停止。")
            return
        self._perf_on = True
        self.b_perf.setText("停止性能监控")
        self._fps_n = 0
        self._perf_timer.start()
        self._fps_timer.start()
        self._tick_perf()

    def _perf_text(self):
        from core import perf
        s = perf.snapshot()
        cpu = perf.cpu_percent()
        th = perf.thread_count()
        fps = self._fps_n
        self._fps_n = 0
        parts = []
        parts.append("CPU %s" % ("—" if cpu is None else "%.1f%%" % cpu))
        parts.append("占用 %s MB" % (s.get("work_mb") if s.get("work_mb") is not None else "—"))
        parts.append("私有 %s MB" % (s.get("private_mb") if s.get("private_mb") is not None else "—"))
        parts.append("峰值 %s MB" % (s.get("peak_mb") if s.get("peak_mb") is not None else "—"))
        parts.append("线程 %s" % (th if th is not None else "—"))
        parts.append("句柄 %s" % (s.get("handles") if s.get("handles") is not None else "—"))
        parts.append("UI 帧率 %d" % fps)
        return "　".join(parts)

    def _tick_perf(self):
        try:
            self.lab_perf.setText(self._perf_text())
        except Exception as e:
            self.lab_perf.setText("取性能数字失败：%s" % e)

    def _peek_perf(self):
        try:
            self.lab_perf.setText("单次采样：" + self._perf_text())
            self._perf_n += 1
        except Exception as e:
            self.lab_perf.setText("采样失败：%s" % e)

    # ---------- 内存体检 ----------
    def _show_mem(self):
        from core import perf
        try:
            self.lab_mem.setText("启动器进程：" + perf.human(perf.snapshot()))
        except Exception as e:
            self.lab_mem.setText("取内存失败：%s" % e)

    def _trim_mem(self):
        """整套 GC + 清位图缓存。数字是实测前后差，不是估计。"""
        from core import perf
        try:
            r = perf.trim(QPixmapCache.clear)
            drop = r.get("drop_mb")
            if drop is None:
                self.lab_mem.setText("整理完成，但取不到前后对比。")
            elif drop > 0:
                self.lab_mem.setText("整理完成：%s MB → %s MB，降了 %s MB。"
                                     % (r["before"]["work_mb"],
                                        r["after"]["work_mb"], drop))
            else:
                self.lab_mem.setText("整理完成：没有可回收的（当前 %s MB，本来就是干净的）。"
                                     % r["after"]["work_mb"])
            self._log("内存整理：" + self.lab_mem.text())
        except Exception as e:
            self.lab_mem.setText("整理失败：%s" % e)

    def _clear_pixmaps(self):
        try:
            QPixmapCache.clear()
            self.lab_mem.setText("位图缓存已清空，之后再用到的图会重新画一次。")
        except Exception as e:
            self.lab_mem.setText("清位图缓存失败：%s" % e)

    def _scan_cache(self):
        try:
            self.tree_cache.clear()
            total = 0
            for r in cacheclean.targets(self._gd()):
                size, _cnt = cacheclean.measure(r["paths"])
                total += size
                it = QTreeWidgetItem(
                    [r["name"], cacheclean.human(size), r["desc"]])
                it.setData(0, Qt.UserRole, r["id"])
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                if r["default"] and r["paths"]:
                    it.setCheckState(0, Qt.Checked)
                else:
                    it.setCheckState(0, Qt.Unchecked)
                if not r["paths"]:
                    it.setDisabled(True)
                self.tree_cache.addTopLevelItem(it)
            self.lab_cache.setText("可以清出 %s。" % cacheclean.human(total))
        except Exception as e:
            self.lab_cache.setText("扫描失败：%s" % e)

    def _checked_rows(self):
        rows = {r["id"]: r for r in cacheclean.targets(self._gd())}
        out = []
        for i in range(self.tree_cache.topLevelItemCount()):
            it = self.tree_cache.topLevelItem(i)
            if it.checkState(0) != Qt.Checked:
                continue
            r = rows.get(it.data(0, Qt.UserRole))
            if r and r["paths"]:
                out.append(r)
        return out

    def _clean_cache(self):
        picked = self._checked_rows()
        if not picked:
            self.lab_cache.setText("没有勾选任何能清的项目。")
            return
        names = "、".join(r["name"] for r in picked)
        if not self._ask("确认清理",
                         "要清理：%s\n\n删掉的内容会自己重新生成（音乐缓存除外）。继续？"
                         % names):
            return
        self._do_clean(picked)

    def _clean_cache_all(self):
        rows = [r for r in cacheclean.targets(self._gd()) if r["paths"]]
        if not rows:
            self.lab_cache.setText("没有可清理的内容。")
            return
        if not self._ask("全部清理",
                         "要清理全部 %d 项？其中「音乐缓存」会连已下载的歌一起删掉，"
                         "之后要重新下载才能听。" % len(rows)):
            return
        self._do_clean(rows)

    def _do_clean(self, rows):
        paths = []
        names = []
        for r in rows:
            paths.extend(r["paths"])
            names.append(r["name"])
        if not paths:
            self.lab_cache.setText("没有可清理的内容。")
            return
        # 进度条：先按文件个数估一个总数，扫的过程中按真实回调推进
        self.bar_cache.setRange(0, 100)
        self.bar_cache.setValue(0)
        self.bar_cache.setFormat("正在统计要删的文件…")
        self.bar_cache.show()
        self.lab_cache.setText("正在清理：%s" % "、".join(names))
        self.btn_clean_state(False)
        state = {"last": -1, "files": 0, "size": 0}

        def _cb(done, total, cur):
            pct = int((done * 100) / total) if total else 0
            self.bar_cache.setValue(min(100, pct))
            self.bar_cache.setFormat("%d / %d 个文件　%p%%" % (done, total))
            if cur:
                short = os.path.basename(cur)
                self.lab_cache.setText("正在删：%s　（%s）"
                                       % (short, "、".join(names)))
            QApplication.processEvents()

        try:
            files, size, fails = cacheclean.clean(paths, progress=_cb)
        except Exception as e:
            self.bar_cache.hide()
            self.btn_clean_state(True)
            self.lab_cache.setText("清理失败：%s" % e)
            return
        self.bar_cache.setValue(100)
        self.bar_cache.setFormat("清完了　%p%%")
        QApplication.processEvents()
        self._scan_cache()
        self.bar_cache.hide()
        self.btn_clean_state(True)
        msg = "清掉 %d 个文件，腾出 %s。" % (files, cacheclean.human(size))
        if fails:
            msg += "　有 %d 个位置删不动（可能正被占用）：%s" % (
                len(fails), os.path.basename(fails[0]))
        self.lab_cache.setText(msg)
        self._log("[缓存] " + msg)

    def btn_clean_state(self, on):
        """清理过程中把几个按钮置灰，免得点一半又点一次。"""
        for name in ("b_clean", "b_clean_all", "b_scan_cache"):
            b = getattr(self, name, None)
            if b is not None:
                b.setEnabled(bool(on))

    def _open_cache_dir(self):
        self._open_dir(cacheclean.app_dir())

    # ================= 10. 反馈收件箱 =================
    def _tab_inbox(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        v.addWidget(self._hint(
            "玩家点「反馈」发出来的内容都存在本机，这里能看全部。"
            "给每条打个状态（待排查 / 已处理 / 无效），下次就不会重复看同一批。"))
        v.addLayout(self._btn_row(
            ("刷新", self._refresh_inbox),
            ("从服务器再拉一次", self._sync_inbox),
            ("标记为待排查", lambda: self._mark_inbox("todo")),
            ("标记为已处理", lambda: self._mark_inbox("done")),
            ("标记为无效", lambda: self._mark_inbox("invalid")),
            ("清掉标记", lambda: self._mark_inbox("")),
            ("复制这条", self._copy_inbox_row)))
        self.list_inbox = QListWidget()
        self.list_inbox.currentRowChanged.connect(self._show_inbox_row)
        v.addWidget(self.list_inbox, 1)
        self.txt_inbox = QTextEdit()
        self.txt_inbox.setReadOnly(True)
        v.addWidget(self.txt_inbox, 2)
        self.lab_inbox = self._hint("")
        v.addWidget(self.lab_inbox)
        self._inbox_rows = []
        QTimer.singleShot(300, self._refresh_inbox)
        return w

    def _refresh_inbox(self):
        try:
            rows = feedback.load_local()
        except Exception as e:
            self.lab_inbox.setText("读反馈失败：%s" % e)
            rows = []
        self._inbox_rows = rows
        cur = self.list_inbox.currentRow()
        counts = {"todo": 0, "done": 0, "invalid": 0}
        self.list_inbox.blockSignals(True)
        self.list_inbox.clear()
        for r in rows:
            p = r.get("payload") or {}
            st = feedback.status_of(r) or "todo"
            counts[st] = counts.get(st, 0) + 1
            label = "[%s] %s　%s" % (feedback.STATUS_TEXT.get(st, "待排查"),
                                    p.get("time") or "", p.get("kind") or "")
            text = (p.get("text") or "").replace("\n", " ").strip()
            if text:
                label += "　·　" + text[:48]
            self.list_inbox.addItem(QListWidgetItem(label))
        self.list_inbox.blockSignals(False)
        if self.list_inbox.count():
            row = cur if 0 <= cur < self.list_inbox.count() else 0
            self.list_inbox.setCurrentRow(row)
        self.lab_inbox.setText(
            "共 %d 条：待排查 %d · 已处理 %d · 无效 %d"
            % (len(rows), counts.get("todo", 0), counts.get("done", 0),
               counts.get("invalid", 0)))

    def _sync_inbox(self):
        try:
            added, total = feedback.sync_local()
            self._log("[反馈] 同步完成，新增 %d 条，共 %d 条" % (added, total))
        except Exception as e:
            self._info("同步失败", str(e))
        self._refresh_inbox()

    def _current_inbox_row(self):
        i = self.list_inbox.currentRow()
        rows = getattr(self, "_inbox_rows", [])
        if 0 <= i < len(rows):
            return rows[i]
        return None

    def _mark_inbox(self, status):
        row = self._current_inbox_row()
        if not row:
            self._info("先选一条", "在列表里点一条反馈，再打标记。")
            return
        rid = str(row.get("id") or "")
        if not rid:
            self._info("这条没编号", "旧格式的反馈没有 id，标不了状态。")
            return
        if not feedback.set_status(rid, status):
            self._info("没写进去", "状态文件写不了，多半是目录权限问题。")
            return
        self._refresh_inbox()
        self.lab_inbox.setText("已标为：%s（%s）" % (
            feedback.STATUS_TEXT.get(status, "清掉标记"), rid[:8]))

    def _show_inbox_row(self, idx):
        rows = getattr(self, "_inbox_rows", [])
        if not (0 <= idx < len(rows)):
            return
        try:
            self.txt_inbox.setPlainText(feedback.as_text(rows[idx]))
        except Exception as e:
            self.txt_inbox.setPlainText("渲染失败：%s" % e)

    def _copy_inbox_row(self):
        if not self._current_inbox_row():
            return
        self._copy_text(self.txt_inbox)

    # ================= 外部调用 =================
    def refresh(self):
        """切到这一页时刷新当前选中的页签内容。"""
        idx = self.tabs.currentIndex()
        try:
            if idx == 0:
                self._vb_refresh()
            elif idx == 4:
                self._refresh_installed()
            elif idx == 5:
                self._refresh_favs()
            elif idx == 6:
                self._refresh_shots()
            elif idx == 7:
                self._refresh_theme_label()
            elif idx == 8:
                self._scan_cache()
            elif idx == 9:
                self._refresh_inbox()
        except Exception:
            pass
