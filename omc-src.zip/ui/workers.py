# -*- coding: utf-8 -*-
"""后台线程：版本列表加载、版本安装、正版登录、模组安装，避免阻塞 UI。"""
import hashlib
import os
import threading
from concurrent.futures import ThreadPoolExecutor

from PySide6.QtCore import QThread, Signal

from core import (auth, avguard, downloader, frienddir, loaders, modpack,
                  modrinth, mods, worlds)


class BaseWorker(QThread):
    """带可设置取消事件的线程基类。"""

    def __init__(self):
        super().__init__()
        self._cancel = threading.Event()

    def cancel(self):
        self._cancel.set()

    def cancelled(self):
        return self._cancel.is_set()


class AvWhitelistWorker(BaseWorker):
    """后台跑「加入杀毒白名单」：会弹 UAC，不能阻塞 UI 线程。"""

    done = Signal(bool, str)

    def run(self):
        try:
            ok, msg = avguard.add_exclusion()
        except Exception as e:
            ok, msg = False, str(e)
        self.done.emit(ok, msg)


class FriendSearchWorker(BaseWorker):
    """按账号名查好友目录，网络慢也不卡界面。"""

    done = Signal(list)

    def __init__(self, query, local_names):
        super().__init__()
        self.query = query
        self.local_names = list(local_names or [])

    def run(self):
        try:
            hits = frienddir.search(self.query, self.local_names)
        except Exception:
            hits = []
        self.done.emit(hits)


class ModrinthSearchWorker(BaseWorker):
    done = Signal(list, int)
    failed = Signal(str)

    def __init__(self, kind, mc, query, loader=None, offset=0, category=None):
        super().__init__()
        self.kind = kind
        self.mc = mc
        self.query = query
        self.loader = loader
        self.offset = offset
        self.category = category

    def run(self):
        try:
            hits, total = modrinth.search(self.kind, self.mc, self.query,
                                          self.loader, offset=self.offset,
                                          category=self.category)
            self.done.emit(hits, total)
        except Exception as e:
            self.failed.emit(str(e))


class ModrinthDownloadWorker(BaseWorker):
    log = Signal(str)
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, pid, mc, loader, dest_dir):
        super().__init__()
        self.pid = pid
        self.mc = mc
        self.loader = loader
        self.dest_dir = dest_dir

    def run(self):
        try:
            path = modrinth.download_project(
                self.pid, self.mc, self.loader, self.dest_dir,
                log=lambda m: self.log.emit(m),
                progress_cb=lambda cur, tot: self.progress.emit(cur, tot))
            self.done.emit(path)
        except Exception as e:
            self.failed.emit(str(e))


class ModpackInstallWorker(BaseWorker):
    """装一个整合包（下载 .mrpack -> 装加载器 -> 下文件 -> 解配置）。"""
    log = Signal(str)
    progress = Signal(int, int)
    stage = Signal(str, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, slug, game_dir, java_path=""):
        super().__init__()
        self.slug = slug
        self.game_dir = game_dir
        self.java_path = java_path

    def run(self):
        try:
            vid = modpack.install(
                self.slug, self.game_dir, self.java_path,
                log=lambda m: self.log.emit(m),
                progress=lambda cur, tot: self.progress.emit(cur, tot),
                stage=lambda name, pct: self.stage.emit(name, pct))
            self.done.emit(str(vid))
        except Exception as e:
            self.failed.emit(str(e))


class ModpackIconUrlWorker(BaseWorker):
    """精选清单里的整合包没有封面地址，逐个问 Modrinth 要 icon_url。"""
    done = Signal(list)

    def __init__(self, slugs):
        super().__init__()
        self.slugs = list(slugs or [])

    def run(self):
        jobs = []
        for i, slug in enumerate(self.slugs):
            if self.cancelled():
                break
            try:
                info = modpack.project_info(slug)
                url = info.get("icon_url") or ""
                if url:
                    jobs.append((i, url))
            except Exception:
                continue
        self.done.emit(jobs)


class WorldUrlWorker(BaseWorker):
    """从网上下载存档（zip 直链）并装进 saves 目录。"""
    log = Signal(str)
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, url, game_dir):
        super().__init__()
        self.url = url
        self.game_dir = game_dir

    def run(self):
        try:
            name = worlds.install_from_url(
                self.url, self.game_dir,
                log=lambda m: self.log.emit(m),
                progress=lambda cur, tot: self.progress.emit(cur, tot))
            self.done.emit(str(name))
        except Exception as e:
            self.failed.emit(str(e))


class JavaDownloadWorker(BaseWorker):
    """没有 Java 时自动下载安装 JRE。"""
    log = Signal(str)
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, major=17):
        super().__init__()
        self.major = major

    def run(self):
        try:
            from core import java_download
            path = java_download.install_java(
                self.major,
                log=lambda m: self.log.emit(m),
                progress=lambda cur, tot: self.progress.emit(cur, tot))
            self.done.emit(path)
        except Exception as e:
            self.failed.emit(str(e))


class WorldImportWorker(BaseWorker):
    log = Signal(str)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, path, game_dir):
        super().__init__()
        self.path = path
        self.game_dir = game_dir

    def run(self):
        try:
            name = worlds.import_save(self.path, self.game_dir,
                                      log=lambda m: self.log.emit(m))
            self.done.emit(name)
        except Exception as e:
            self.failed.emit(str(e))


class LoaderVersionsWorker(BaseWorker):
    done = Signal(list, list)
    failed = Signal(str)

    def __init__(self, kind, mc, mirror="official"):
        super().__init__()
        self.kind = kind
        self.mc = mc
        self.mirror = mirror

    def run(self):
        try:
            versions, recommended = loaders.list_versions(self.kind, self.mc, self.mirror)
            self.done.emit(versions, recommended)
        except Exception as e:
            self.failed.emit(str(e))


class LoaderInstallWorker(BaseWorker):
    log = Signal(str)
    progress = Signal(int, int, float)   # 已下载字节, 总字节(0=不确定), 速度 B/s
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, kind, mc, ver, game_dir, java_path, mirror="official"):
        super().__init__()
        self.kind = kind
        self.mc = mc
        self.ver = ver
        self.game_dir = game_dir
        self.java_path = java_path
        self.mirror = mirror

    def run(self):
        try:
            vid = loaders.install(self.kind, self.mc, self.ver, self.game_dir,
                                  self.java_path,
                                  log=lambda m: self.log.emit(m),
                                  progress=lambda c, t, s=0.0: self.progress.emit(
                                      int(c), int(t), float(s)),
                                  mirror=self.mirror)
            self.done.emit(vid)
        except Exception as e:
            self.failed.emit(str(e))


class ModsWorker(BaseWorker):
    log = Signal(str)
    progress = Signal(int, int)
    done = Signal(list)
    failed = Signal(str)

    def __init__(self, paths, game_dir, mirror="official"):
        super().__init__()
        self.paths = paths
        self.game_dir = game_dir
        self.mirror = mirror

    def run(self):
        try:
            result = mods.install_paths(
                self.paths, self.game_dir,
                log=lambda m: self.log.emit(m),
                progress=lambda c, t: self.progress.emit(c, t),
                mirror=self.mirror,
            )
            self.done.emit(result)
        except Exception as e:
            self.failed.emit(str(e))


class LoginWorker(QThread):
    log = Signal(str)
    need_code = Signal()
    success = Signal(dict)
    failed = Signal(str)

    def __init__(self):
        super().__init__()
        self._code = None
        self._event = threading.Event()

    def run(self):
        try:
            account = auth.login_interactive(log=lambda m: self.log.emit(m),
                                             ask_code=self._ask_code)
            self.success.emit(account)
        except Exception as e:
            self.failed.emit(str(e))

    def _ask_code(self):
        """在子线程里等主线程弹窗把授权码或回调地址回传过来。"""
        self._event.clear()
        self.need_code.emit()
        self._event.wait(timeout=300)
        return self._code or ""

    def provide_code(self, text):
        self._code = text
        self._event.set()


class DeviceLoginWorker(QThread):
    """设备码登录：先拿到 8 位码给界面显示，再在后台等用户确认。"""
    log = Signal(str)
    code_ready = Signal(str, str)
    success = Signal(dict)
    failed = Signal(str)

    def __init__(self):
        super().__init__()
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            account = auth.device_login(
                log=lambda m: self.log.emit(m),
                on_code=lambda c, u: self.code_ready.emit(c, u),
                is_cancelled=lambda: self._cancelled)
            self.success.emit(account)
        except Exception as e:
            self.failed.emit(str(e))


class ThirdLoginWorker(QThread):
    log = Signal(str)
    success = Signal(dict)
    failed = Signal(str)

    def __init__(self, api_url, username, password):
        super().__init__()
        self.api_url = api_url
        self.username = username
        self.password = password

    def run(self):
        try:
            from core import yggdrasil
            self.log.emit("正在连接服务器...")
            account = yggdrasil.authenticate(
                self.api_url, self.username, self.password)
            self.log.emit("正在准备登录组件...")
            yggdrasil.ensure_injector(log=lambda m: self.log.emit(m))
            auth.save_account(account)
            self.success.emit(account)
        except Exception as e:
            self.failed.emit(str(e))


class LanDetectWorker(QThread):
    """后台检测本机正在运行的游戏局域网房间，避免扫描卡住 UI。"""
    found = Signal(list)

    def __init__(self, full=False, parent=None):
        super().__init__(parent)
        self.full = full

    def run(self):
        try:
            from core import lan
            rooms = lan.detect_rooms(full=self.full)
        except Exception:
            rooms = []
        self.found.emit(rooms)


class PublicStatusWorker(QThread):
    """后台探测公共服状态（在线人数 / 版本 / 延迟），避免 ping 卡住界面。"""
    done = Signal(object)

    def __init__(self, host, port, parent=None):
        super().__init__(parent)
        self.host = host
        self.port = port

    def run(self):
        try:
            from core import pubserver
            result = pubserver.ping(self.host, self.port, timeout=4)
        except Exception as e:
            result = {"online": False, "players": 0, "max_players": 0,
                      "version": "", "motd": "", "latency_ms": 0,
                      "error": str(e) or "连接失败"}
        self.done.emit(result)


class NetCheckWorker(QThread):
    """后台跑网络自检（DNS、站点、下载短链、扫码端口），最长几秒，别卡 UI。"""
    done = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)

    def run(self):
        try:
            from core import netcheck
            result = netcheck.check()
        except Exception as e:
            result = {"error": "%s: %s" % (type(e).__name__, e)}
        self.done.emit(result)


class RoomStartWorker(QThread):
    log = Signal(str)
    ready = Signal(object)
    failed = Signal(str)

    def __init__(self, game_dir, vid, version_data, mirror, java_path,
                 memory_mb, rcon_pwd, motd=None):
        super().__init__()
        self.args = (game_dir, vid, version_data, mirror, java_path,
                     memory_mb, rcon_pwd)
        self.motd = motd

    def run(self):
        from core import lan
        game_dir, vid, version_data, mirror, java_path, memory_mb, pwd = self.args
        try:
            lan.ensure_server(game_dir, vid, version_data, mirror,
                              log=lambda m: self.log.emit(m))
            server = lan.ServerProcess(game_dir, vid, java_path, memory_mb)
            server.start(pwd, log=lambda m: self.log.emit(m), motd=self.motd)
            self.ready.emit(server)
        except Exception as e:
            self.failed.emit(str(e))


class RoomMetaWorker(QThread):
    """批量拉取房间的自定义名称与封面（由房主的启动器对外发布）。"""

    ready = Signal(object)   # [(ip, port, meta|None, cover_bytes|None)]
    failed = Signal(str)

    def __init__(self, rooms):
        super().__init__()
        self.rooms = rooms or []

    def run(self):
        from core import lanroom
        out = []
        for r in self.rooms:
            ip = r.get("ip") or "127.0.0.1"
            try:
                port = int(r.get("port") or 25565)
            except Exception:
                continue
            meta = None
            cover = None
            try:
                meta = lanroom.fetch_meta(ip, port)
                if meta and meta.get("cover"):
                    cover = lanroom.fetch_cover(
                        ip, port, meta_port=meta.get("meta_port"))
            except Exception:
                meta, cover = None, None
            out.append((ip, port, meta, cover))
        self.ready.emit(out)


class UpdateWorker(QThread):
    """拉远端版本清单，比对是否有新版本。"""

    done = Signal(object)
    failed = Signal(str)

    def __init__(self, url=None):
        super().__init__()
        self.url = (url or "").strip() or None

    def run(self):
        from core import update
        try:
            self.done.emit(update.check(self.url))
        except Exception as e:
            self.failed.emit(str(e))


class LatestVersionWorker(QThread):
    """拉官方最新版本号 + 封面图（每次启动都重新拉，官方发新版就自动变）。"""

    done = Signal(object)
    failed = Signal(str)

    def run(self):
        try:
            from core import latest
            from concurrent.futures import ThreadPoolExecutor
            info = latest.latest_versions()
            ver, snap = info.get("release") or "", info.get("snapshot") or ""
            with ThreadPoolExecutor(max_workers=2) as ex:
                f1 = ex.submit(latest.get_cover, ver)
                f2 = ex.submit(latest.get_cover, snap) if snap else None
                info["cover"] = f1.result()
                info["snapshot_cover"] = f2.result() if f2 else ""
            self.done.emit(info)
        except Exception as e:
            self.failed.emit(str(e))


class UpdateDownloadWorker(BaseWorker):
    """下载并解压新版更新包，供退出后替换。"""
    log = Signal(str)
    progress = Signal(int, int)
    stage = Signal(str, int)
    done = Signal(str, str)
    failed = Signal(str)

    def __init__(self, url):
        super().__init__()
        self.url = url

    def run(self):
        try:
            from core import updater
            payload, work = updater.download_package(
                self.url,
                log=lambda m: self.log.emit(m),
                progress=lambda cur, tot: self.progress.emit(cur, tot),
                stage=lambda name, pct: self.stage.emit(name, int(pct)))
            self.done.emit(payload, work)
        except Exception as e:
            self.failed.emit(str(e))


class ModrinthIconWorker(QThread):
    """并发拉取封面图；带本地磁盘缓存，第二次进同一页几乎瞬间显示。

    只回传图片字节，QPixmap 交给主线程创建（Qt 要求 GUI 对象在 GUI 线程）。
    """
    icon_ready = Signal(int, object)

    def __init__(self, jobs, workers=6):
        super().__init__()
        self.jobs = jobs  # [(row_index, icon_url)]
        self.workers = workers

    def _cache_dir(self):
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                         "iconcache")
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            return None
        return d

    def _fetch(self, idx, url):
        from core import http
        cache = self._cache_dir()
        key = hashlib.sha1(url.encode("utf-8")).hexdigest()
        path = os.path.join(cache, key) if cache else None
        if path and os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    self.icon_ready.emit(idx, f.read())
                    return
            except Exception:
                pass
        try:
            data = http._read_url(url, "official", timeout=10, retries=2)
        except Exception:
            return
        if not data:
            return
        if path:
            try:
                with open(path, "wb") as f:
                    f.write(data)
            except Exception:
                pass
        self.icon_ready.emit(idx, data)

    def run(self):
        if not self.jobs:
            return
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            for idx, url in self.jobs:
                pool.submit(self._fetch, idx, url)


class VersionListWorker(QThread):
    versions = Signal(list)
    failed = Signal(str)

    def __init__(self, mirror):
        super().__init__()
        self.mirror = mirror

    def run(self):
        try:
            self.versions.emit(downloader.list_versions(self.mirror))
        except Exception as e:
            self.failed.emit(str(e))


class InstallWorker(QThread):
    log = Signal(str)
    progress = Signal(int, int)
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, game_dir, mirror, version_id, manifest_url):
        super().__init__()
        self.game_dir = game_dir
        self.mirror = mirror
        self.version_id = version_id
        self.manifest_url = manifest_url
        self.installer = None

    def run(self):
        try:
            self.installer = downloader.Installer(
                self.game_dir, self.mirror,
                log=lambda m: self.log.emit(m),
                progress=lambda c, t: self.progress.emit(c, t),
            )
            json_path = self.installer.install(self.version_id, self.manifest_url)
            self.finished_ok.emit(json_path)
        except Exception as e:
            self.failed.emit(str(e))

    def cancel(self):
        if self.installer:
            self.installer.cancel()


class ImportWorker(BaseWorker):
    """拖进窗口的东西，在后台识别并装进对应目录。"""

    log = Signal(str)
    done = Signal(list)

    def __init__(self, paths, game_dir):
        super().__init__()
        self.paths = list(paths or [])
        self.game_dir = game_dir

    def run(self):
        try:
            from core import importer
            res = importer.import_all(
                self.paths, self.game_dir,
                log=lambda m: self.log.emit(m))
            self.done.emit(res)
        except Exception as e:
            self.done.emit([(p, "unknown", False, "导入出错：%s" % e)
                            for p in self.paths])


class ProjectVersionsWorker(BaseWorker):
    """拉某个项目的全部版本（不做 MC / 加载器筛选）。"""

    done = Signal(list)
    failed = Signal(str)

    def __init__(self, project_id):
        super().__init__()
        self.project_id = project_id

    def run(self):
        try:
            rows = modrinth.project_versions(self.project_id, None, None) or []
            self.done.emit(rows)
        except Exception as e:
            self.failed.emit(str(e))


class FileDownloadWorker(BaseWorker):
    """按给定文件 URL 下载（用于装某个指定版本）。"""

    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, url, dest, size=None, sha1=None):
        super().__init__()
        self.url = url
        self.dest = dest
        self.size = size
        self.sha1 = sha1

    def run(self):
        try:
            from core import http
            http.download_file(
                self.url, self.dest, "official",
                progress=lambda c, t: self.progress.emit(c, t or 0),
                size=self.size, sha1=self.sha1)
            self.done.emit(self.dest)
        except Exception as e:
            self.failed.emit(str(e))


class WorldMapWorker(BaseWorker):
    """读存档 region，渲染生物群系地图。"""

    done = Signal(str, dict)
    failed = Signal(str)

    def __init__(self, world_dir, out_png, max_regions=9, scale=2):
        super().__init__()
        self.world_dir = world_dir
        self.out_png = out_png
        self.max_regions = max_regions
        self.scale = scale

    def run(self):
        try:
            from core import seedmap
            grid, info = seedmap.scan_world(self.world_dir, self.max_regions)
            if not grid:
                self.failed.emit("这个存档里还没有已生成的区块（或版本不认识）。")
                return
            w, h, n = seedmap.render_png(grid, self.out_png, self.scale)
            info.update({"w": w, "h": h, "pixels": n})
            self.done.emit(self.out_png, info)
        except Exception as e:
            self.failed.emit(str(e))


class SeedStructWorker(BaseWorker):
    """本地算种子里的结构遗迹坐标。"""

    done = Signal(object)
    failed = Signal(str)

    def __init__(self, version, seed, radius=3000):
        super().__init__()
        self.version = version
        self.seed = int(seed)
        self.radius = int(radius)

    def run(self):
        try:
            from core import seedcalc
            data = seedcalc.find_structures(self.version, self.seed,
                                            self.radius)
            self.done.emit(data)
        except Exception as e:
            self.failed.emit(str(e))


class SeedBiomeMapWorker(BaseWorker):
    """本地算一片区域的生物群系并画成图。"""

    done = Signal(str, dict)
    failed = Signal(str)

    def __init__(self, version, seed, center_x, center_z, size, out_png,
                 scale=4, marks=None):
        super().__init__()
        self.version = version
        self.seed = int(seed)
        self.center_x = int(center_x)
        self.center_z = int(center_z)
        self.size = int(size)
        self.out_png = out_png
        self.scale = int(scale)
        self.marks = marks or []

    def run(self):
        try:
            from core import seedcalc
            half = self.size // 2
            x0 = self.center_x - half
            z0 = self.center_z - half
            data = seedcalc.biome_grid(self.version, self.seed, x0, z0,
                                       self.size // self.scale,
                                       self.size // self.scale, self.scale)
            w, h = seedcalc.render_biome_png(data, self.out_png, x0, z0,
                                             self.marks)
            legend = data.get("legend") or {}
            names = sorted(set(legend.values()))
            self.done.emit(self.out_png, {
                "w": w, "h": h, "x0": x0, "z0": z0,
                "scale": self.scale, "biomes": names,
            })
        except Exception as e:
            self.failed.emit(str(e))


class ExportPackWorker(BaseWorker):
    """把游戏目录打成整合包 zip。"""

    progress = Signal(int, int)
    log = Signal(str)
    done = Signal(str, int, int)
    failed = Signal(str)

    def __init__(self, game_dir, out_zip, name="我的整合包",
                 include_resourcepacks=True, include_shaders=True):
        super().__init__()
        self.game_dir = game_dir
        self.out_zip = out_zip
        self.name = name
        self.include_resourcepacks = include_resourcepacks
        self.include_shaders = include_shaders

    def run(self):
        try:
            from core import export_pack
            path, count, size = export_pack.export_pack(
                self.game_dir, self.out_zip, self.name,
                progress=lambda d, t, m: (self.progress.emit(d, t),
                                          self.log.emit(m)),
                include_resourcepacks=self.include_resourcepacks,
                include_shaders=self.include_shaders)
            self.done.emit(path, count, size)
        except Exception as e:
            self.failed.emit(str(e))
