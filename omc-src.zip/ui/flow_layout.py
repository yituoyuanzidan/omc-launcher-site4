# -*- coding: utf-8 -*-
"""能自动换行的水平布局。

Qt 自带的 QHBoxLayout 不会换行：窗口一窄，右边那几个控件就顶出可视区，
用户看到的就是「只显示一半」。这里按宽度把控件一行一行铺，放不下就自动折行，
所以任何窗口尺寸下所有按钮都在可视范围内、也不会叠在一起。
"""
from PySide6.QtCore import QPoint, QRect, QSize, Qt
from PySide6.QtWidgets import QLayout, QLineEdit


class FlowLayout(QLayout):
    def __init__(self, parent=None, margin=0, spacing=8):
        super().__init__(parent)
        self._items = []
        self.setContentsMargins(margin, margin, margin, margin)
        self.setSpacing(spacing)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        if 0 <= i < len(self._items):
            return self._items[i]
        return None

    def takeAt(self, i):
        if 0 <= i < len(self._items):
            return self._items.pop(i)
        return None

    def expandingDirections(self):
        return Qt.Orientations(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for it in self._items:
            size = size.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        size += QSize(m.left() + m.right(), m.top() + m.bottom())
        return size

    def _do_layout(self, rect, test_only):
        m = self.contentsMargins()
        area = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y = area.x(), area.y()
        line_h = 0
        sp = self.spacing()
        for it in self._items:
            hint = it.sizeHint()
            w, h = hint.width(), hint.height()
            wid = it.widget()
            # 搜索框这类想铺满的输入框给它一个像样的固定宽度，
            # 否则默认 sizeHint 太窄，折行后一行只剩一个小口子
            if wid is not None and isinstance(wid, QLineEdit):
                w = max(w, 200)
            if x + w > area.right() + 1 and line_h > 0:
                x = area.x()
                y += line_h + sp
                line_h = 0
            if not test_only:
                it.setGeometry(QRect(QPoint(x, y), QSize(w, h)))
            x += w + sp
            line_h = max(line_h, h)
        if test_only:
            return y + line_h - rect.y() + m.bottom()
        return y + line_h - rect.y() + m.bottom()
