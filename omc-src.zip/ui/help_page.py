# -*- coding: utf-8 -*-
"""帮助：常见问题。

左边一列问题，点一条右边出答案；上面能搜。内容都是这版启动器真用得上的，
不写「请检查网络连接」这种废话。
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QSplitter,
    QTextBrowser, QVBoxLayout, QWidget,
)

FAQ = [
    ("启动器打不开 / 双击没反应",
     "1) 先看任务管理器里有没有后台的 OMC.exe 卡着，有就结束掉再开。\n"
     "2) 杀毒软件可能把它隔离了，去隔离区恢复并加白名单（这不影响安全，只是别让它拦自己）。\n"
     "3) 还不行就看启动器目录下的 logs，工具页「日志诊断」能把报错翻成中文。"),
    ("启动游戏卡在「正在启动」",
     "多数是 Java 版本不对或内存给小了。\n"
     "· 设置里「Java 全自动」保持打开，让它按版本挑；\n"
     "· 内存至少给 2048 MB，1.20 之后的版本建议 4096 MB；\n"
     "· 第一次启动要生成资源文件，慢一点正常，超过 3 分钟才算卡住。"),
    ("游戏很卡 / 帧率低",
     "先把渲染距离降两格，比换显卡便宜。\n"
     "工具页「帧率优化」能按你的显卡给建议；「内存与清理」里的一键优化能腾出内存。\n"
     "光影（shader）是最吃帧的，先关光影试一次。"),
    ("内存不够 / 启动器占内存高",
     "工具页「内存与清理」是唯一入口：\n"
     "· 一键优化：清垃圾 + 清缓存 + 整理内存；\n"
     "· 「看内存占用」看当前多少 MB；\n"
     "· 「按这台电脑推荐内存」按物理内存算出游戏该给多少。"),
    ("模组装了但游戏里没有",
     "看三件事：模组是不是放进了 mods 文件夹、是不是 Forge/Fabric 对应的版本、\n"
     "有没有缺前置（工具页「模组冲突」会直接列出来）。\n"
     "1.20.5 之后 Forge 和 Fabric 的模组不通用，别混装。"),
    ("游戏崩溃了怎么办",
     "工具页「日志诊断」会读 crash-reports 和 latest.log，把原因按条列出来。\n"
     "最常见三类：缺前置模组、Java 版本不符、内存不够。\n"
     "「一键打包日志」能打成一个 zip，反馈时直接发。"),
    ("存档会不会丢",
     "默认启动前会自动备份存档（设置里可关）。\n"
     "工具页「版本备份」能把整个版本连存档打成一个包，换电脑也能带走。\n"
     "存档别放 C 盘根目录，系统重装会一起没。"),
    ("搜好友搜不到",
     "对方要开着 1.7.64 的启动器、并且点过好友页的「把我也挂到目录」，\n"
     "目录只保留最近 12 小时登录过的人。\n"
     "可以直接输完整账号名再搜；也能在「主页」页按名字直接拉他的资料。"),
    ("加好友显示两遍同一个人",
     "1.7.63 的老 bug：本机账号和在线目录各塞了一条，没按名字合并。\n"
     "1.7.64 起按名字合并，只显示一条，来源标成「本机/在线」。"),
    ("别人加我要不要同意",
     "好友页「别人加我的方式」四档：直接通过 / 需要申请 / 需要输入指定文本 / 禁止别人加我。\n"
     "选「禁止」就没人能加你，只能你去加别人。"),
    ("拉黑的人还能发消息吗",
     "不能。拉黑后对方的申请和消息在本机直接丢掉，也不会上报。\n"
     "好友页「黑名单」里能看到全部被拉黑的人，随时能移出。"),
    ("怎么把好友删了",
     "好友列表里选中点「删除选中的好友」，或者右键。\n"
     "对方那边会收到一条「已删除」，两边列表同步，不会出现一边有一边没有。"),
    ("皮肤和披风在哪",
     "1.7.64 起侧栏不再单独放「皮肤库」，改到「个性化」页的第三个标签\n"
     "「皮肤库与披风」，穿搭码、披风上传都在里面。"),
    ("怎么换头像 / 改背景",
     "「个性化」页：第一个标签改主题、按键颜色、背景图和亮度；\n"
     "第二个标签换头像、写主页简介、设置主页上显示什么。"),
    ("主页上的游戏时长是怎么算的",
     "从这台电脑上通过启动器启动的游戏，启动成功开始算，进程退出为止，\n"
     "按分钟累加存在本机。别人要看到得你先点「发布到主页」。"),
    ("今日人品准吗",
     "不准，纯玩梗。按「账号名 + 日期」算，同一天同一个人固定，换天才换。\n"
     "如果今天结果不好看，可以明天再看。"),
    ("自定义下载怎么用",
     "工具页「自定义下载」：填网址、选文件夹、填文件名（留空自动猜）。\n"
     "断网或取消后再点开始会接着下（服务器支持断点续传时）。\n"
     "下完会算 SHA256，能对一下有没有被改过。"),
    ("被举报的名字会怎样",
     "名字命中违禁词才会被强制改成「未命名（四位编号）」，编号由原名决定。\n"
     "改名要对方客户端在线同步才生效；对方一直离线就是本机显示成未命名。\n"
     "没命中词库的举报只记录，不会误伤。"),
    ("更新怎么更",
     "设置页「检查更新」，或者到官网下整包换掉。\n"
     "启动器的设置、账号、好友都存在用户目录，换包不会丢。"),
    ("小猫说的是什么",
     "空闲时它会讲游戏知识、启动器用法和一些攻略；右键它会给你一条当前能用的提示。\n"
     "嫌吵可以在「个性化 → 外观」里把小猫关掉。"),
    ("日志在哪",
     "启动器日志：工具页「日志诊断」直接能看；\n"
     "游戏日志：游戏目录下 logs/latest.log，崩溃在 crash-reports。"),
]


class HelpPage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        title = QLabel("帮助")
        title.setObjectName("PageTitle")
        v.addWidget(title)
        sub = QLabel("常见问题。搜关键词能直接筛，点一条看答案。")
        sub.setObjectName("PageSub")
        v.addWidget(sub)

        self.input_search = QLineEdit()
        self.input_search.setPlaceholderText("搜：内存 / 崩溃 / 好友 / 皮肤 / 下载…")
        self.input_search.textChanged.connect(self._filter)
        v.addWidget(self.input_search)

        self.list_q = QListWidget()
        self.list_q.setMinimumWidth(220)
        self.list_q.setMaximumWidth(320)
        for q, _a in FAQ:
            it = QListWidgetItem(q)
            it.setData(Qt.UserRole, q)
            self.list_q.addItem(it)
        self.list_q.currentRowChanged.connect(self._show)
        self.txt_a = QTextBrowser()
        self.txt_a.setOpenExternalLinks(True)

        split = QSplitter(Qt.Horizontal)
        split.addWidget(self.list_q)
        split.addWidget(self.txt_a)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        v.addWidget(split, 1)

        tip = QLabel("没找到答案：设置页「反馈 / 报 Bug」能带上日志一起发过来。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)
        self.list_q.setCurrentRow(0)

    def _filter(self, text):
        q = (text or "").strip().lower()
        for i in range(self.list_q.count()):
            it = self.list_q.item(i)
            title = it.data(Qt.UserRole) or it.text()
            ans = ""
            for a, b in FAQ:
                if a == title:
                    ans = b
                    break
            it.setHidden(bool(q) and q not in title.lower() and q not in ans.lower())
        for i in range(self.list_q.count()):
            if not self.list_q.item(i).isHidden():
                self.list_q.setCurrentRow(i)
                break

    def _show(self, row):
        if row < 0:
            return
        it = self.list_q.item(row)
        if not it:
            return
        title = it.data(Qt.UserRole) or it.text()
        ans = ""
        for a, b in FAQ:
            if a == title:
                ans = b
                break
        self.txt_a.setHtml(
            "<div style='font-size:16px;font-weight:700;margin-bottom:8px'>%s</div>"
            "<div style='font-size:13px;line-height:1.9'>%s</div>"
            % (title, ans.replace("&", "&amp;").replace("<", "&lt;").replace("\n", "<br>")))
