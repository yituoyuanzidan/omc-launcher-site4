# -*- coding: utf-8 -*-
"""官方最新版本预告片卡片：循环播放 + 可暂停 + 可静音。

片源来自下载站清单（core.trailer.sync），拿不到就用包里自带的那支。
环境里没有 QtMultimedia 时整卡降级成一行说明，不会影响启动器其它功能。
"""
import threading

from PySide6.QtCore import Qt, QObject, QTimer, QUrl, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton,
                               QSlider, QVBoxLayout, QWidget)

try:
    from PySide6.QtMultimediaWidgets import QVideoWidget
    from ui.media_compat import HAS_MEDIA as _HAS_MEDIA
    from ui.media_compat import (IMPORT_ERROR as _MEDIA_ERR, QMediaPlayer,
                                 connect_error, make_audio, set_muted, set_source)
    HAS_VIDEO = _HAS_MEDIA
    _IMPORT_ERROR = _MEDIA_ERR
except Exception as _e:               # 精简版 Qt 没有多媒体模块
    HAS_VIDEO = False
    _IMPORT_ERROR = "%s: %s" % (type(_e).__name__, _e)


def _fmt(ms):
    if ms <= 0:
        return "0:00"
    s = int(ms // 1000)
    return "%d:%02d" % (s // 60, s % 60)


class _Sig(QObject):
    ready = Signal(str, str, str)      # 路径, 版本, 说明


class TrailerCard(QFrame):
    """放在启动页「官方最新版本」下面的一块。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self._sig = _Sig()
        self._sig.ready.connect(self._on_ready)
        self._alive = True
        self._muted = False
        self._seeking = False

        v = QVBoxLayout(self)
        v.setContentsMargins(22, 16, 22, 16)
        v.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(8)
        self.lbl_title = QLabel("官方最新版本预告片")
        self.lbl_title.setObjectName("FieldLabel")
        head.addWidget(self.lbl_title)
        head.addStretch(1)
        self.lbl_loop = QLabel("循环播放")
        self.lbl_loop.setObjectName("FieldLabel")
        head.addWidget(self.lbl_loop)
        v.addLayout(head)

        if not HAS_VIDEO:
            tip = QLabel("当前环境没有视频组件，预告片暂时放不了。\n%s"
                         % (_IMPORT_ERROR or "（PySide6 缺少 QtMultimedia）"))
            tip.setWordWrap(True)
            tip.setObjectName("FieldLabel")
            v.addWidget(tip)
            self.lbl_state = tip
            self.player = None
            self.audio = None
            return

        self.video = QVideoWidget()
        self.video.setMinimumHeight(220)
        self.video.setStyleSheet("background:#0B0D10;border-radius:10px;")
        v.addWidget(self.video, 1)

        self.player = QMediaPlayer(self)
        self.audio = make_audio(self.player, self, 0.6)
        self.player.setVideoOutput(self.video)
        self.player.setLoops(QMediaPlayer.Infinite)     # 播完自动从头再来
        connect_error(self.player, self._on_error)
        self.player.positionChanged.connect(self._on_pos)
        self.player.durationChanged.connect(self._on_dur)
        self.player.mediaStatusChanged.connect(self._on_status)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.btn_play = QPushButton("暂停")
        self.btn_play.setMinimumWidth(76)
        self.btn_play.clicked.connect(self._toggle_play)
        bar.addWidget(self.btn_play)

        self.btn_mute = QPushButton("静音")
        self.btn_mute.setMinimumWidth(96)
        self.btn_mute.clicked.connect(self._toggle_mute)
        bar.addWidget(self.btn_mute)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderPressed.connect(self._seek_start)
        self.slider.sliderReleased.connect(self._seek_end)
        self.slider.sliderMoved.connect(self._seek_move)
        bar.addWidget(self.slider, 1)

        self.lbl_time = QLabel("0:00 / 0:00")
        self.lbl_time.setObjectName("FieldLabel")
        bar.addWidget(self.lbl_time)
        v.addLayout(bar)

        self.lbl_state = QLabel("正在找官方预告片…")
        self.lbl_state.setObjectName("FieldLabel")
        self.lbl_state.setWordWrap(True)
        v.addWidget(self.lbl_state)

        self._toggle_mute()          # 默认静音起播，别一打开启动器就突然出声
        QTimer.singleShot(200, self._load)
        self.video.installEventFilter(self)
        # 暂停图案：盖在视频那块上面（父控件是卡片，视频层是原生的，子控件压不上去）
        try:
            from .pause_overlay import PauseOverlay
            self._pause_ov = PauseOverlay(self, 84)
            self.player.playbackStateChanged.connect(self._sync_pause)
        except Exception:
            self._pause_ov = None

    def _place_pause(self):
        if getattr(self, "_pause_ov", None) is None:
            return
        try:
            self._pause_ov.setGeometry(self.video.geometry())
            self._pause_ov.raise_()
        except Exception:
            pass

    def _sync_pause(self, st=None):
        ov = getattr(self, "_pause_ov", None)
        if ov is None:
            return
        try:
            paused = (self.player is not None
                      and self.player.playbackState() != QMediaPlayer.PlayingState
                      and self.player.source().isValid())
            self._place_pause()
            ov.set_active(bool(paused))
        except Exception:
            pass

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._place_pause()

    # ---------- 取片 ----------
    def _load(self):
        def work():
            from core import trailer
            path, ver, note = trailer.sync(timeout=12)
            try:
                self._sig.ready.emit(path or "", ver or "", note or "")
            except RuntimeError:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _on_ready(self, path, ver, note):
        if not self._alive:
            return
        if ver:
            self.lbl_title.setText("官方 %s 预告片" % ver)
        if not path:
            self.lbl_state.setText(note or "官方还没放预告片")
            self.btn_play.setEnabled(False)
            self.btn_mute.setEnabled(False)
            return
        self.lbl_state.setText(note)
        set_source(self.player, QUrl.fromLocalFile(path))
        self.player.play()

    def _on_error(self, err, text):
        if not self._alive:
            return
        self.lbl_state.setText("放不出来：%s" % (text or err))

    def _on_status(self, status):
        if not self._alive or self.player is None:
            return
        if status == QMediaPlayer.EndOfMedia:      # 老版本 Qt 不会自己循环时兜底
            self.player.setPosition(0)
            self.player.play()

    # ---------- 控制 ----------
    def _toggle_play(self):
        if self.player is None or not self.player.source().isValid():
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            self.btn_play.setText("播放")
        else:
            self.player.play()
            self.btn_play.setText("暂停")

    def _toggle_mute(self):
        if self.audio is None:
            return
        self._muted = not self._muted
        set_muted(self.player, self.audio, self._muted)
        self.btn_mute.setText("取消静音" if self._muted else "静音")

    def _on_pos(self, pos):
        if self._seeking:
            return
        self.slider.setValue(int(pos))
        self.lbl_time.setText("%s / %s" % (_fmt(pos), _fmt(self.player.duration())))

    def _on_dur(self, dur):
        self.slider.setRange(0, int(max(0, dur)))
        self.lbl_time.setText("%s / %s" % (_fmt(0), _fmt(dur)))

    def _seek_start(self):
        self._seeking = True

    def _seek_move(self, val):
        self.lbl_time.setText("%s / %s" % (_fmt(val), _fmt(self.player.duration())))

    def _seek_end(self):
        self._seeking = False
        self.player.setPosition(self.slider.value())

    def eventFilter(self, obj, ev):
        # 点画面本身就能暂停/继续，跟视频网站一样
        if obj is getattr(self, "video", None) and ev.type() == ev.Type.MouseButtonRelease:
            self._toggle_play()
            return True
        return super().eventFilter(obj, ev)

    def shutdown(self):
        """主窗口要退出时先停掉播放，别让音频线程卡住 close。

        Qt 的多媒体后端在 Windows 上是独立线程跑的：窗口先没、播放器还在
        解码，就很容易在 pyside6.abi3.dll 里访问到已经释放的对象（0xc0000005）。
        所以这里按「停 → 摘输出 → 清片源 → 断开信号」的顺序彻底拆开。
        """
        self._alive = False
        try:
            self._sig.ready.disconnect()
        except Exception:
            pass
        try:
            if self.player is not None:
                self.player.stop()
                try:
                    self.player.setVideoOutput(None)
                except Exception:
                    pass
                set_source(self.player, QUrl())
                try:
                    self.player.setAudioOutput(None)
                except Exception:
                    pass
        except Exception:
            pass
        self.player = None
        self.audio = None
        self.video = None

    def closeEvent(self, event):
        self.shutdown()
        super().closeEvent(event)
