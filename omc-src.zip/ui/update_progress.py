# -*- coding: utf-8 -*-
"""更新进度窗口：一个看得见的大进度条，不用盯窗口标题。

底部那条细进度条还在（窗口底部常驻），这个窗口是给「我点了更新到底下了多少」
一个正面答案：版本号、百分比、已下载 / 总大小、速度、剩余时间、现在在干什么。
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QProgressBar,
                               QPushButton, QVBoxLayout)

_QSS = """
QDialog#UpdCard { background: #1E2128; }
QLabel#UpdTitle { font-size: 16px; font-weight: 700; color: #FFFFFF; }
QLabel#UpdSub { color: #9AA4B4; }
QLabel#UpdPct { font-size: 22px; font-weight: 700; color: #4ADE80; }
"""

_STAGE_HINT = {
    "下载": "正在下载新版本安装包",
    "校验": "正在校验更新包，确认没下坏",
    "解压": "正在解压新版本",
    "替换": "正在换上新的文件，重启后生效",
}


class UpdateProgressDialog(QDialog):
    def __init__(self, version="", parent=None):
        super().__init__(parent)
        self.setObjectName("UpdCard")
        self.setStyleSheet(_QSS)
        self.setWindowTitle("更新 OMC %s" % version)
        self.setMinimumWidth(460)
        self.setModal(True)
        self.setWindowFlag(Qt.WindowContextHelpButtonHint, False)

        v = QVBoxLayout(self)
        v.setSpacing(10)
        self.lbl_title = QLabel("正在下载新版本 %s" % version)
        self.lbl_title.setObjectName("UpdTitle")
        v.addWidget(self.lbl_title)
        self.lbl_sub = QLabel("正在连接下载源……")
        self.lbl_sub.setObjectName("UpdSub")
        self.lbl_sub.setWordWrap(True)
        v.addWidget(self.lbl_sub)

        row = QHBoxLayout()
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(22)
        row.addWidget(self.bar, 1)
        self.lbl_pct = QLabel("0%")
        self.lbl_pct.setObjectName("UpdPct")
        self.lbl_pct.setFixedWidth(64)
        self.lbl_pct.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row.addWidget(self.lbl_pct)
        v.addLayout(row)

        self.lbl_speed = QLabel("")
        self.lbl_speed.setObjectName("UpdSub")
        v.addWidget(self.lbl_speed)

        brow = QHBoxLayout()
        brow.addStretch(1)
        self.btn_bg = QPushButton("后台继续")
        self.btn_bg.setToolTip("关掉这个窗口，底部那条进度条还会一直显示进度")
        self.btn_bg.clicked.connect(self.hide)
        brow.addWidget(self.btn_bg)
        v.addLayout(brow)

    def set_state(self, pct=None, text=None, sub=None, busy=False, stage=""):
        if text is not None:
            self.lbl_title.setText(text)
        if stage:
            self.lbl_sub.setText(_STAGE_HINT.get(stage, stage))
        if sub is not None:
            self.lbl_speed.setText(sub)
        if busy:
            self.bar.setRange(0, 0)
            self.lbl_pct.setText("…")
        else:
            self.bar.setRange(0, 100)
            val = 0 if pct is None else max(0, min(100, int(pct)))
            self.bar.setValue(val)
            self.lbl_pct.setText("%d%%" % val)

    def finish(self, text="新版本已经准备好"):
        self.bar.setRange(0, 100)
        self.bar.setValue(100)
        self.lbl_pct.setText("100%")
        self.lbl_title.setText(text)
        self.lbl_sub.setText("可以从这里关掉；重启后就是新版本。")
