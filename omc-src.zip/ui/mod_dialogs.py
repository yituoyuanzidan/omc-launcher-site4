# -*- coding: utf-8 -*-
"""模组标签 / 黑名单的弹窗。"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QGridLayout,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton,
                               QVBoxLayout, QWidget)

from core import modblock, modtags

_CARD_QSS = "QDialog#Card{background:#1E2128;}"


class ModTagDialog(QDialog):
    """给一个模组打标签、写备注。"""

    def __init__(self, filename, cur=None, parent=None):
        super().__init__(parent)
        self.filename = filename
        cur = cur or {}
        self.setObjectName("Card")
        self.setWindowTitle("模组标签")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(430)
        v = QVBoxLayout(self)
        v.setSpacing(10)
        head = QLabel("给 <b>%s</b> 打标签（只存本机，不改模组文件）" % filename)
        head.setWordWrap(True)
        v.addWidget(head)

        self.boxes = {}
        have = set(cur.get("tags") or [])
        grid = QGridLayout()
        for i, t in enumerate(modtags.DEFAULT_TAGS):
            cb = QCheckBox(t)
            cb.setChecked(t in have)
            self.boxes[t] = cb
            grid.addWidget(cb, i // 2, i % 2)
        v.addLayout(grid)

        self.extra = QLineEdit()
        self.extra.setPlaceholderText("再加别的标签，用逗号分开，例如：联机专用,低配")
        self.extra.setText(",".join(t for t in have if t not in modtags.DEFAULT_TAGS))
        v.addWidget(self.extra)

        self.note = QLineEdit()
        self.note.setPlaceholderText("备注，例如：改过配置，别更新")
        self.note.setText(cur.get("note") or "")
        v.addWidget(self.note)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("保存")
        bb.button(QDialogButtonBox.Cancel).setText("取消")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def values(self):
        tags = [t for t, cb in self.boxes.items() if cb.isChecked()]
        for t in (self.extra.text() or "").replace("，", ",").split(","):
            t = t.strip()
            if t and t not in tags:
                tags.append(t)
        return tags, self.note.text()


class ModBlacklistDialog(QDialog):
    """模组黑名单：导入/拖入时直接拦下的文件名与通配规则。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setWindowTitle("模组黑名单")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(520)
        v = QVBoxLayout(self)
        v.setSpacing(10)

        tip = QLabel("名单里的模组在导入、拖进来时直接拦下来，不复制进游戏。"
                     "文件名写全（如 xxx.jar），规则可以用 * 通配（如 *hack*）。")
        tip.setWordWrap(True)
        v.addWidget(tip)

        self.lst = QListWidget()
        self.lst.setMinimumHeight(160)
        v.addWidget(self.lst)

        r1 = QHBoxLayout()
        self.input_name = QLineEdit()
        self.input_name.setPlaceholderText("文件名，例如 badmod-1.0.jar")
        r1.addWidget(self.input_name, 1)
        b1 = QPushButton("加文件")
        b1.clicked.connect(self._add_name)
        r1.addWidget(b1)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        self.input_pat = QLineEdit()
        self.input_pat.setPlaceholderText("通配规则，例如 *hack* 或 *cheat*")
        r2.addWidget(self.input_pat, 1)
        b2 = QPushButton("加规则")
        b2.clicked.connect(self._add_pat)
        r2.addWidget(b2)
        v.addLayout(r2)

        r3 = QHBoxLayout()
        b_del = QPushButton("删掉选中的")
        b_del.clicked.connect(self._del_one)
        r3.addWidget(b_del)
        r3.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.setObjectName("PrimaryButton")
        b_close.clicked.connect(self.accept)
        r3.addWidget(b_close)
        v.addLayout(r3)

        self._reload()

    def _reload(self):
        self.lst.clear()
        for n in modblock.names():
            it = QListWidgetItem("文件：%s" % n)
            it.setData(Qt.UserRole, ("name", n))
            self.lst.addItem(it)
        for p in modblock.patterns():
            it = QListWidgetItem("规则：%s" % p)
            it.setData(Qt.UserRole, ("pat", p))
            self.lst.addItem(it)
        if self.lst.count() == 0:
            self.lst.addItem(QListWidgetItem("黑名单是空的。"))

    def _add_name(self):
        ok, msg = modblock.add_name(self.input_name.text())
        if ok:
            self.input_name.clear()
        self._reload()
        QMessageBox.information(self, "黑名单", msg)

    def _add_pat(self):
        ok, msg = modblock.add_pattern(self.input_pat.text())
        if ok:
            self.input_pat.clear()
        self._reload()
        QMessageBox.information(self, "黑名单", msg)

    def _del_one(self):
        it = self.lst.currentItem()
        if it is None:
            return
        data = it.data(Qt.UserRole)
        if not data:
            return
        modblock.remove(data[1])
        self._reload()
