# -*- coding: utf-8 -*-
"""好友备注 / 分组的小弹窗。"""
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QLabel,
                               QLineEdit, QPushButton, QWidget)

from core import friendbook

_CARD_QSS = "QDialog#Card{background:#1E2128;}"


class FriendEditDialog(QDialog):
    def __init__(self, item, parent=None):
        super().__init__(parent)
        self.item = item or {}
        self.setObjectName("Card")
        self.setWindowTitle("好友备注 / 分组")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(400)
        f = QFormLayout(self)
        f.setSpacing(10)
        who = QLabel("账号：<b>%s</b>" % (self.item.get("name") or ""))
        f.addRow(who)

        self.input_alias = QLineEdit()
        self.input_alias.setPlaceholderText("列表里显示的名字，留空就用账号名")
        self.input_alias.setText(self.item.get("alias") or "")
        f.addRow("备注名", self.input_alias)

        self.input_group = QLineEdit()
        self.input_group.setPlaceholderText("例如：生存、测试、建筑")
        self.input_group.setText(self.item.get("group") or "")
        f.addRow("分组", self.input_group)

        quick = QWidget()
        row = QFormLayout(quick)
        row.setContentsMargins(0, 0, 0, 0)
        f.addRow("", QLabel("已有分组：%s" % ("、".join(friendbook.groups()) or "（还没有）")))

        self.input_note = QLineEdit()
        self.input_note.setPlaceholderText("随手记一句，比如「一起玩 1.20 的」")
        self.input_note.setText(self.item.get("note") or "")
        f.addRow("备注", self.input_note)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("保存")
        bb.button(QDialogButtonBox.Cancel).setText("取消")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        f.addRow(bb)

    def values(self):
        return {
            "alias": self.input_alias.text().strip(),
            "group": self.input_group.text().strip(),
            "note": self.input_note.text().strip(),
        }
