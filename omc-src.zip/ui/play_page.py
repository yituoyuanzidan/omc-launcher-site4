# -*- coding: utf-8 -*-
"""娱乐页：棋牌大厅 + 对局 + 结算。

规矩（照用户要求来的）：
  * **必须登录账号才能进**，没登录就只显示一块提示和「去登录」；
  * 左上角固定一行「珍惜生命，远离赌博」；
  * 真人对局（邀请好友 / 匹配真人）输了要扣积分给对方，结算界面里写清楚；
  * 积分按账号分开存（core/coins.py），AI 对战不结算积分，只算胜负纪录；
  * 这里的一切都只是虚拟积分，没有充值入口，也不能提现。
"""
import threading
import time

from PySide6.QtCore import QObject, QRect, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QListWidget, QListWidgetItem,
                               QPushButton, QSpinBox, QStackedWidget,
                               QVBoxLayout, QWidget)

from core import accounts, coins, gamesync, minigames as mg, sfx

WARN_TEXT = "珍惜生命，远离赌博"


# ===================== 棋盘控件（五子棋 / 围棋共用） =====================
class BoardCanvas(QWidget):
    """自绘棋盘。点击某一格就发 clicked(r, c)。"""

    clicked = Signal(int, int)

    def __init__(self, size=15, cell=30, parent=None):
        super().__init__(parent)
        self.size = size
        self.cell = cell
        self.pad = 18
        self.cells = [[0] * size for _ in range(size)]
        self.last = None
        self.hover = None
        self.winline = []
        self.setFixedSize(self.pad * 2 + (size - 1) * cell,
                          self.pad * 2 + (size - 1) * cell)
        self.setMouseTracking(True)

    def set_board(self, cells, last=None):
        self.cells = [list(row) for row in cells]
        self.last = last
        self.update()

    def set_winline(self, pts):
        """把获胜的那几颗子连成一条线（结算前先让人看清楚怎么输/赢的）。"""
        self.winline = list(pts or [])
        self.update()

    def _to_grid(self, x, y):
        c = int(round((x - self.pad) / float(self.cell)))
        r = int(round((y - self.pad) / float(self.cell)))
        if 0 <= r < self.size and 0 <= c < self.size:
            return r, c
        return None

    def mouseMoveEvent(self, e):
        g = self._to_grid(e.position().x(), e.position().y())
        if g != self.hover:
            self.hover = g
            self.update()

    def leaveEvent(self, e):
        self.hover = None
        self.update()

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        g = self._to_grid(e.position().x(), e.position().y())
        if g:
            self.clicked.emit(g[0], g[1])

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        # 棋盘底
        p.fillRect(self.rect(), QColor("#C8A063"))
        pen = QPen(QColor("#6B4E2E"))
        pen.setWidth(1)
        p.setPen(pen)
        n = self.size
        end = self.pad + (n - 1) * self.cell
        for i in range(n):
            v = self.pad + i * self.cell
            p.drawLine(self.pad, v, end, v)
            p.drawLine(v, self.pad, v, end)
        # 星位
        if n == 15:
            stars = [(3, 3), (3, 11), (11, 3), (11, 11), (7, 7)]
        elif n == 9:
            stars = [(2, 2), (2, 6), (6, 2), (6, 6), (4, 4)]
        else:
            stars = []
        p.setBrush(QColor("#6B4E2E"))
        for (r, c) in stars:
            x = self.pad + c * self.cell
            y = self.pad + r * self.cell
            p.drawEllipse(QRect(x - 3, y - 3, 6, 6))
        # 悬停提示
        if self.hover and not self.cells[self.hover[0]][self.hover[1]]:
            r, c = self.hover
            x = self.pad + c * self.cell
            y = self.pad + r * self.cell
            p.setBrush(QColor(255, 255, 255, 90))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QRect(x - self.cell // 2 + 3, y - self.cell // 2 + 3,
                                self.cell - 6, self.cell - 6))
        # 棋子
        for r in range(n):
            for c in range(n):
                v = self.cells[r][c]
                if not v:
                    continue
                x = self.pad + c * self.cell
                y = self.pad + r * self.cell
                rad = self.cell // 2 - 2
                box = QRect(x - rad, y - rad, rad * 2, rad * 2)
                p.setPen(QPen(QColor("#3A3A3A"), 1))
                if v == 1:
                    p.setBrush(QColor("#1E2228"))
                elif v == 2:
                    p.setBrush(QColor("#F2F4F8"))
                else:
                    p.setBrush(QColor("#9AA0AA"))
                p.drawEllipse(box)
        # 最后一手
        if self.last:
            r, c = self.last
            x = self.pad + c * self.cell
            y = self.pad + r * self.cell
            p.setPen(QPen(QColor("#E5533D"), 2))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRect(x - 5, y - 5, 10, 10))
        # 获胜连线：整条从第一颗子拉到最后两颗子
        if len(self.winline) >= 2:
            for (r, c) in self.winline:
                x = self.pad + c * self.cell
                y = self.pad + r * self.cell
                p.setPen(QPen(QColor("#FFD34D"), 3))
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(QRect(x - self.cell // 2 + 2,
                                    y - self.cell // 2 + 2,
                                    self.cell - 4, self.cell - 4))
            r0, c0 = self.winline[0]
            r1, c1 = self.winline[-1]
            pen = QPen(QColor("#FFD34D"), 3)
            p.setPen(pen)
            p.drawLine(self.pad + c0 * self.cell, self.pad + r0 * self.cell,
                       self.pad + c1 * self.cell, self.pad + r1 * self.cell)


class _PollSig(QObject):
    """后台轮询线程 → 主线程的唯一通道（跨线程 emit 自动排队到主线程）。"""
    done = Signal(object)


class PlayPage(QWidget):
    """娱乐页主体。host 是主窗（要它看登录态和切页）。"""

    def __init__(self, host=None, parent=None):
        super().__init__(parent)
        self.host = host
        # 铺一层半透明深色底，别让界面直接浮在壁纸上（文字看不清）
        self.setObjectName("PlayPanel")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.net = {}             # 联机状态：room/role/opp/game/bet
        self.game_id = ""
        self.bet = 0
        self.mode = "ai"          # ai / invite / match
        self._room_seen = set()
        self._inv_seen = set()    # 已经列过的邀请（按房间号去重，别每次轮询都插一条）
        self._inv_pending = []    # 收到的邀请
        self._my_inv = None       # 我发出去、等对方接的邀请
        self._finished = False
        self._searching = False   # 正在等真人匹配
        self._pool_room = ""      # 匹配时自己占的房间号
        self._search_ts = 0.0
        self._poll_busy = False   # 上一轮后台请求还没回来就别再发
        self._poll_ts = 0.0
        self._remote_amt = 0
        self._remote_win = 0
        self._poll_sig = _PollSig(self)
        self._poll_sig.done.connect(self._on_poll)

        v = QVBoxLayout(self)
        v.setContentsMargins(14, 10, 14, 12)
        v.setSpacing(8)

        # ---- 顶栏：左边那句提示必须在，右边账号 + 积分 ----
        top = QHBoxLayout()
        self.lbl_warn = QLabel(WARN_TEXT)
        self.lbl_warn.setStyleSheet(
            "color:#E5533D;font-size:15px;font-weight:700;"
            "letter-spacing:1px;")
        self.lbl_warn.setToolTip("娱乐区只用虚拟积分，不能充值、不能提现")
        top.addWidget(self.lbl_warn)
        top.addStretch(1)
        self.lbl_who = QLabel("未登录")
        self.lbl_who.setObjectName("PageSub")
        top.addWidget(self.lbl_who)
        self.lbl_coin = QLabel("积分 —")
        self.lbl_coin.setStyleSheet("color:#E8B04D;font-weight:700;")
        top.addWidget(self.lbl_coin)
        b_reset = QPushButton("重置积分")
        b_reset.setFixedWidth(86)
        b_reset.setToolTip("点一下要再确认一次，确认后这个账号的积分回到 %d"
                           % coins.START_COINS)
        b_reset.clicked.connect(self._reset_coins)
        top.addWidget(b_reset)
        b_refresh = QPushButton("刷新")
        b_refresh.setFixedWidth(64)
        b_refresh.clicked.connect(self.refresh)
        top.addWidget(b_refresh)
        v.addLayout(top)

        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        self.page_gate = self._build_gate()
        self.page_lobby = self._build_lobby()
        self.page_game = self._build_game_shell()
        self.page_result = self._build_result()
        for w in (self.page_gate, self.page_lobby, self.page_game,
                  self.page_result):
            self.stack.addWidget(w)

        # 房间 / 邀请轮询：只在娱乐页可见时跑（切走就停，别在后台一直发请求）
        self.timer = QTimer(self)
        self.timer.setInterval(3000)
        self.timer.timeout.connect(self._tick)

        self.refresh()

    # ---------- 身份 / 金币 ----------
    def me(self):
        try:
            n = (accounts.current_name() or "").strip()
        except Exception:
            n = ""
        if n:
            return n
        # 用户自己点了「退出登录」：到这里就停，不能替他登回去。
        # （下面那段兜底只该救「登录态被动丢失」，不该把主动退出当成故障。）
        try:
            if accounts.logged_out_by_user():
                return ""
        except Exception:
            pass
        # 兜底：登录过、但登录态被更新重启/强杀弄丢了（accounts.json 里 current 空），
        # 机器上只有一个账号就认它并把登录态写回去，别让人「明明登录了却进不去」。
        try:
            us = accounts.users()
            if len(us) == 1:
                cand = (us[0].get("name") or "").strip()
                if cand and accounts.set_current(cand):
                    return cand
        except Exception:
            pass
        return ""

    def logged(self):
        return bool(self.me())

    def refresh(self):
        me = self.me()
        if me:
            bal = coins.balance(me)
            acc = coins.account(me)
            self.lbl_who.setText("账号 %s" % me)
            self.lbl_coin.setText("积分 %d" % bal)
            self.lbl_coin.setToolTip(
                "胜 %d / 负 %d / 平 %d，输一局扣自己当前积分的 10%%"
                % (acc.get("wins", 0), acc.get("losses", 0),
                   acc.get("draws", 0)))
            if self.stack.currentWidget() is self.page_gate:
                self.stack.setCurrentWidget(self.page_lobby)
        else:
            self.lbl_who.setText("未登录")
            self.lbl_coin.setText("积分 —")
            self.stack.setCurrentWidget(self.page_gate)

    # ---------- 未登录 ----------
    def _build_gate(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addStretch(1)
        lab = QLabel("娱乐区需要先登录账号")
        lab.setObjectName("PageTitle")
        lab.setAlignment(Qt.AlignCenter)
        v.addWidget(lab)
        sub = QLabel("登录之后每个账号有自己的积分，换账号就是另一份，互不影响。")
        sub.setObjectName("FieldLabel")
        sub.setAlignment(Qt.AlignCenter)
        sub.setWordWrap(True)
        v.addWidget(sub)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("去登录")
        b.setObjectName("PrimaryButton")
        b.setFixedWidth(140)
        b.clicked.connect(self._goto_account)
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        v.addStretch(1)
        return w

    def _goto_account(self):
        try:
            if self.host is not None and hasattr(self.host, "_refresh_account"):
                self.host._refresh_account()
        except Exception:
            pass

    def _reset_coins(self):
        """重置积分：必须二次确认，确认后这个账号回到 500。"""
        from PySide6.QtWidgets import QMessageBox
        me = self.me()
        if not me:
            self.lab_inv.setText("先登录账号。")
            return
        box = QMessageBox(self)
        box.setWindowTitle("重置积分")
        box.setIcon(QMessageBox.Question)
        box.setText("确认把账号「%s」的积分重置成 %d？" % (me, coins.START_COINS))
        box.setInformativeText(
            "现在的积分和胜负记录都会清掉，重置以后不能撤回。\n"
            "娱乐区只有虚拟积分，不涉及任何真实充值。")
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setDefaultButton(QMessageBox.No)
        yes_btn = box.button(QMessageBox.Yes)
        no_btn = box.button(QMessageBox.No)
        yes_btn.setText("确认重置")
        no_btn.setText("取消")
        if box.exec() == QMessageBox.Yes:
            coins.reset(me)
            self.refresh()
            try:
                if self.host is not None and hasattr(self.host, "_log"):
                    self.host._log("[娱乐] 账号 %s 的积分已重置为 %d"
                                   % (me, coins.START_COINS))
            except Exception:
                pass

    # ---------- 大厅 ----------
    def _build_lobby(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)

        v.addWidget(self._hint(
            "选个玩法。跟 AI 玩不花积分；跟真人玩，输一局扣自己积分的 10% 给对方。"))

        # 模式
        mrow = QHBoxLayout()
        lab_mode = QLabel("怎么玩：")
        lab_mode.setObjectName("FieldLabel")
        lab_mode.setMinimumWidth(72)
        mrow.addWidget(lab_mode)
        self.cb_mode = QComboBox()
        self.cb_mode.addItem("跟 AI 对战（不结算积分）", "ai")
        self.cb_mode.addItem("邀请好友（真人，结算积分）", "invite")
        self.cb_mode.addItem("匹配真人（结算积分）", "match")
        self.cb_mode.currentIndexChanged.connect(self._on_mode)
        mrow.addWidget(self.cb_mode)
        mrow.addSpacing(12)
        self.lab_bet = QLabel("")
        self.lab_bet.setStyleSheet("color:#E8B04D;")
        mrow.addWidget(self.lab_bet)
        mrow.addStretch(1)
        v.addLayout(mrow)

        # 好友 + 发起邀请（单独一行，别把上面那行挤满）
        frow = QHBoxLayout()
        lab_f = QLabel("好友：")
        lab_f.setObjectName("FieldLabel")
        lab_f.setMinimumWidth(72)
        frow.addWidget(lab_f)
        self.cb_friend = QComboBox()
        self.cb_friend.setMinimumWidth(170)
        # 以前只有切到「邀请好友」才启用，用户看到灰框就以为「有好友也不能选」。
        # 现在一直可选，选中好友就自动切到邀请模式。
        self.cb_friend.currentIndexChanged.connect(self._on_pick_friend)
        frow.addWidget(self.cb_friend)
        b_ref = QPushButton("刷新好友")
        b_ref.setFixedWidth(84)
        b_ref.clicked.connect(self._reload_friends)
        frow.addWidget(b_ref)
        frow.addSpacing(8)
        self.b_invite = QPushButton("发起邀请")
        self.b_invite.clicked.connect(self._do_invite)
        frow.addWidget(self.b_invite)
        b_go_f = QPushButton("去好友页加人")
        b_go_f.setFixedWidth(112)
        b_go_f.clicked.connect(self._goto_friends)
        frow.addWidget(b_go_f)
        frow.addStretch(1)
        v.addLayout(frow)

        # 收到 / 发出的邀请
        self.lab_inv = QLabel("")
        self.lab_inv.setObjectName("FieldLabel")
        self.lab_inv.setWordWrap(True)
        v.addWidget(self.lab_inv)
        self.lst_inv = QListWidget()
        self.lst_inv.setMaximumHeight(104)
        v.addWidget(self.lst_inv)
        irow = QHBoxLayout()
        b_yes = QPushButton("接受选中的邀请")
        b_yes.clicked.connect(lambda: self._answer_invite(True))
        b_no = QPushButton("拒绝")
        b_no.clicked.connect(lambda: self._answer_invite(False))
        irow.addWidget(b_yes)
        irow.addWidget(b_no)
        self.b_cancel_match = QPushButton("取消匹配")
        self.b_cancel_match.setFixedWidth(96)
        self.b_cancel_match.clicked.connect(self._cancel_match)
        self.b_cancel_match.hide()
        irow.addWidget(self.b_cancel_match)
        irow.addStretch(1)
        v.addLayout(irow)

        # 游戏卡片
        grid = QGridLayout()
        grid.setSpacing(10)
        self._cards = []
        for i, g in enumerate(mg.GAMES):
            card = QFrame()
            card.setObjectName("GameCard")
            card.setStyleSheet(
                "QFrame#GameCard{background:#20242C;border:1px solid #2E3440;"
                "border-radius:10px;} QLabel{background:transparent;}")
            cv = QVBoxLayout(card)
            cv.setContentsMargins(12, 10, 12, 10)
            t = QLabel(g["name"])
            t.setStyleSheet("font-size:15px;font-weight:700;color:#E8EDF5;")
            cv.addWidget(t)
            d = QLabel(g["desc"])
            d.setObjectName("FieldLabel")
            d.setWordWrap(True)
            cv.addWidget(d)
            b = QPushButton("开始")
            b.setFixedWidth(96)
            b.clicked.connect(lambda _=False, gid=g["id"]: self._start(gid))
            cv.addWidget(b, 0, Qt.AlignRight)
            grid.addWidget(card, i // 3, i % 3)
            self._cards.append(card)
        v.addLayout(grid, 1)
        self.lab_tip = QLabel("")
        self.lab_tip.setObjectName("FieldLabel")
        self.lab_tip.setWordWrap(True)
        v.addWidget(self.lab_tip)
        self._on_mode()
        return w

    def _hint(self, text):
        lab = QLabel(text)
        lab.setObjectName("FieldLabel")
        lab.setWordWrap(True)
        return lab

    def _on_mode(self):
        m = self.cb_mode.currentData() or "ai"
        if m != "match" and self._searching:
            self._cancel_match(silent=True)
        self.mode = m
        self.cb_friend.setEnabled(True)
        self.b_invite.setEnabled(True)
        me = self.me()
        if me:
            amt = coins.loss_amount(me)
            self.lab_bet.setText("输一局扣当前积分的 10%%，现在会扣 %d 分" % amt)
        else:
            self.lab_bet.setText("")
        if m == "invite":
            self._reload_friends()
            self.lab_tip.setText("邀请发给好友，他打开娱乐页点「接受」就开局；"
                                 "两边都开着启动器就行，不用进游戏。")
        elif m == "match":
            self._reload_friends()
            self.lab_tip.setText("匹配只匹配真人：点下面某个玩法卡片上的「开始」，"
                                 "就会进公共池子等人。等不到真人不会偷偷塞人机，"
                                 "超过 45 秒会提示你可以继续等或取消。")
        else:
            self.lab_tip.setText("跟 AI 玩不扣积分，只记胜负局数。")

    def _friend_names(self):
        """本机好友表里的账号名（发邀请要用真名，不是备注）。"""
        try:
            from core import friendbook
            return [(it.get("name") or "").strip() for it in friendbook.items()
                    if (it.get("name") or "").strip()]
        except Exception:
            return []

    def _reload_friends(self):
        prev = self.cb_friend.currentData()
        self.cb_friend.blockSignals(True)
        self.cb_friend.clear()
        names = []
        try:
            from core import friendbook
            for it in friendbook.items():
                n = (it.get("name") or "").strip()
                if not n:
                    continue
                names.append(n)
                # 显示用备注名，数据存真名 —— 拿显示名去发邀请会发错人
                self.cb_friend.addItem(friendbook.label_of(it) or n, n)
        except Exception:
            pass
        if names:
            i = self.cb_friend.findData(prev) if prev else 0
            self.cb_friend.setCurrentIndex(i if i >= 0 else 0)
        else:
            self.cb_friend.addItem("（还没有好友，点右边「去好友页加人」）", "")
        self.cb_friend.blockSignals(False)
        self.b_invite.setEnabled(bool(names))
        if names and self.mode == "invite":
            self.lab_inv.setText("好友共 %d 个，选一个点「发起邀请」。" % len(names))
        return names

    def _on_pick_friend(self, _i=None):
        peer = (self.cb_friend.currentData() or "").strip()
        if peer and self.mode != "invite":
            self.lab_tip.setText("已选好友 %s：点「发起邀请」会自动切到邀请模式。"
                                 % peer)

    def _goto_friends(self):
        """跳到主窗好友页加人。"""
        try:
            host = self.host
            if host is None:
                return
            b = getattr(host, "btn_friends", None)
            if b is not None:
                b.setChecked(True)
            host.stack.setCurrentIndex(6)
            if hasattr(host, "_reload_friends"):
                host._reload_friends()
        except Exception:
            pass

    # ---------- 发起 / 接受邀请 ----------
    def _do_invite(self):
        me = self.me()
        peer = (self.cb_friend.currentData() or "").strip()
        if not me:
            self.lab_inv.setText("先登录账号。")
            return
        if not peer:
            self._reload_friends()
            peer = (self.cb_friend.currentData() or "").strip()
        if not peer:
            self.lab_inv.setText("好友列表是空的，先去好友页加人再回来。")
            return
        if peer.lower() == me.lower():
            self.lab_inv.setText("不能邀请自己，选一个好友。")
            return
        if self.mode != "invite":
            # 好友已经选好了，就别让人再去切模式（之前灰掉的下拉框就是这么卡住的）
            idx = self.cb_mode.findData("invite")
            if idx >= 0:
                self.cb_mode.setCurrentIndex(idx)
        game = self.game_id or "gomoku"
        okc, why = coins.can_play(me)
        if not okc:
            self.lab_inv.setText(why)
            return
        bet = coins.loss_amount(me)
        room = gamesync.new_room()
        ok2, msg = gamesync.send_invite(me, peer, game, bet, room)
        self.lab_inv.setText(msg)
        if ok2:
            self._my_inv = {"peer": peer, "room": room, "game": game,
                            "bet": bet, "ts": time.time()}

    def _answer_invite(self, yes):
        it = self.lst_inv.currentItem()
        if not it:
            self.lab_inv.setText("先在上面点一条邀请。")
            return
        d = it.data(Qt.UserRole) or {}
        me = self.me()
        if not d or not me:
            return
        opp = d.get("f") or ""
        game = d.get("game") or "gomoku"
        bet = int(d.get("bet") or 0)
        room = d.get("room") or ""
        gamesync.send_ack(me, opp, room, yes)
        if not yes:
            self.lab_inv.setText("已拒绝。")
            self.lst_inv.takeItem(self.lst_inv.currentRow())
            return
        ok, why = coins.can_play(me)
        if not ok:
            self.lab_inv.setText(why)
            return
        # 我这边输了要扣多少，按我自己的积分算，跟对方给的数字无关
        self._enter_room(room, opp, game, coins.loss_amount(me),
                         role="o", creator=opp)

    # ---------- 联机轮询（网络全在后台线程，主线程只接结果） ----------
    def _tick(self):
        me = self.me()
        if not me:
            return
        if self._poll_busy:
            # 上一次请求万一卡死（信号没回来），20 秒后强制复位，别让轮询永久停摆
            if time.time() - self._poll_ts < 20:
                return
            self._poll_busy = False
        room = ""
        if self.stack.currentWidget() is self.page_game:
            room = (self.net or {}).get("room") or ""
        elif self._searching:
            room = self._pool_room      # 房主在等别人敲门，得守着自己的房间
        snap = {"me": me, "room": room,
                "inv_since": "60s", "room_since": "25s",
                "searching": bool(self._searching),
                "game": self.game_id, "bet": int(self.bet or 0),
                "pool_room": self._pool_room}
        self._poll_busy = True
        self._poll_ts = time.time()
        threading.Thread(target=self._poll_work, args=(snap,),
                         name="omc-play-poll", daemon=True).start()

    def _poll_work(self, snap):
        """后台线程：只做网络，不碰任何控件；结果丢回主线程。"""
        try:
            data = gamesync.poll_all(snap)
        except Exception as e:
            data = {"inv": [], "room": [], "matched": None, "err": "%s" % e}
        try:
            self._poll_sig.done.emit(data)
        except Exception:
            pass

    def _on_poll(self, data):
        self._poll_busy = False
        if not isinstance(data, dict):
            return
        me = self.me()
        if not me:
            return
        rows = data.get("inv") or []
        # 1) 我发出的邀请有没有被接
        got_ack = False
        if self._my_inv:
            for r in rows:
                if r.get("t") != "ack":
                    continue
                if (r.get("room") or "") != self._my_inv.get("room"):
                    continue
                got_ack = True
                d = self._my_inv
                self._my_inv = None
                if int(r.get("yes") or 0):
                    self.lab_inv.setText("%s 接受了邀请，开局。" % d["peer"])
                    self._enter_room(d["room"], d["peer"], d["game"], d["bet"],
                                     role="x", creator=me)
                else:
                    self.lab_inv.setText("%s 拒绝了你的邀请。" % (r.get("f") or ""))
                break
        # 2) 别人发来的邀请：to 已在上游过滤，自己发的不会进来
        if not got_ack and self.stack.currentWidget() is self.page_lobby:
            for r in rows:
                if r.get("t") != "inv":
                    continue
                rid = (r.get("room") or "")
                if not rid or rid in self._inv_seen:
                    continue
                self._inv_seen.add(rid)
                self._add_invite_row(r)
        # 3) 房间消息：开局 / 棋步 / 结算 / 退出
        if self.stack.currentWidget() is self.page_game and \
                (self.net or {}).get("room"):
            self._apply_room_rows(data.get("room") or [])
        elif self._searching:
            # 我是房主，等客人敲门（只认 to==我 的 join）
            for r in data.get("room") or []:
                if r.get("t") != "join":
                    continue
                if (r.get("to") or "").strip().lower() != me.strip().lower():
                    continue
                joiner = (r.get("f") or "").strip()
                if not joiner or joiner.lower() == me.lower():
                    continue
                bet = int(r.get("bet") or 0) or coins.loss_amount(me)
                game = self.game_id or (r.get("game") or "gomoku")
                my_room = self._pool_room
                self._stop_search()
                self.lab_tip.setText("匹配到了 %s，正在开局……" % joiner)
                self._enter_room(my_room, joiner, game, bet,
                                 role="x", creator=me)
                break
        # 4) 匹配结果：我当客人进对方房间
        m = data.get("matched")
        if m and self._searching:
            opp = (m.get("f") or "").strip()
            room = (m.get("room") or "").strip()
            if opp and room and opp.lower() != me.lower():
                self._stop_search()
                self.lab_tip.setText("匹配到了 %s，正在开局……" % opp)
                self._enter_room(room, opp, self.game_id or "gomoku",
                                 int(m.get("bet") or 0) or coins.loss_amount(me),
                                 role="o", creator=opp)
        # 5) 匹配超时提示：宁可告诉用户没真人，也不拿人机凑数
        if self._searching and time.time() - self._search_ts > 45:
            self.lab_tip.setText("已经等了 45 秒还没匹配到真人。匹配只连真人，"
                                 "不会拿人机凑数 —— 可以继续等，或点「取消匹配」。")

    def _add_invite_row(self, r):
        f = (r.get("f") or "").strip()
        game = mg.game_name(r.get("game") or "")
        bet = int(r.get("bet") or 0)
        it = QListWidgetItem("%s 邀你玩「%s」（输了扣自己积分的 10%%）"
                             % (f, game))
        it.setData(Qt.UserRole, r)
        self.lst_inv.addItem(it)
        if not self.lst_inv.currentItem():
            self.lst_inv.setCurrentRow(0)
        self.lab_inv.setText("有新的对局邀请，选一条点「接受」。")

    def _enter_room(self, room, opp, game, bet, role="x", creator=""):
        self.net = {"room": room, "opp": opp, "game": game, "bet": int(bet),
                    "role": role, "creator": creator or (self.me() if role == "x" else opp),
                    "started": False}
        self._room_seen = set()
        if role == "x":
            # 房主广播开局，先手归房主
            gamesync.send_room(room, {"t": "start", "f": self.me(),
                                      "x": self.me(), "o": opp,
                                      "game": game, "bet": int(bet)})
            self.net["started"] = True
        self._start(game, bet=bet, net=True)
        self.lab_state.setText("房间 %s　对手 %s　输一局扣自己积分的 10%%"
                               % (room[:6], opp))

    def _apply_room_rows(self, rows):
        """处理房间消息（开局 / 棋步 / 结算 / 退出）。数据来自后台线程。"""
        for r in rows:
            nid = r.get("_nid") or ""
            if nid:
                if nid in self._room_seen:
                    continue
                self._room_seen.add(nid)
            f = (r.get("f") or "").strip()
            t = r.get("t")
            if t == "start" and not self.net.get("started"):
                self.net["started"] = True
                if not self.net.get("role"):
                    self.net["role"] = "o" if f == self.net.get("creator") else "x"
                self.lab_state.setText("开局了：对手 %s" % (r.get("o") or f))
            elif t == "mv" and f.lower() != self.me().lower():
                self._apply_remote_move(r.get("m") or {})
            elif t == "res" and f.lower() != self.me().lower():
                # 对方先结算了：把金额记下来，等我这边判定时按这个数入账
                amt = int(r.get("amt") or 0)
                if amt > 0:
                    self._remote_amt = amt
                self._remote_win = int(r.get("win") or 0)
                if not self._finished and self._remote_win:
                    # 对方说我输：立刻按我自己的 10% 结算
                    self._finish(2 if self._remote_win == 1 else 1,
                                 opp=f, bet=0, game=self.net.get("game"),
                                 real=True,
                                 note="对方那边已经结算了这局")
            elif t == "bye" and f.lower() != self.me().lower():
                self._finish(1 if not self._finished else 0, opp=f,
                             bet=self.net.get("bet", 0), game=self.net.get("game"),
                             real=True, note="%s 退出了，这局算你赢" % f)

    def _apply_remote_move(self, m):
        view = getattr(self, "view", None)
        if view is None:
            return
        if hasattr(view, "apply_remote"):
            view.apply_remote(m)

    # ---------- 对局外壳 ----------
    def _build_game_shell(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)
        row = QHBoxLayout()
        b_back = QPushButton("← 回大厅")
        b_back.setFixedWidth(110)
        b_back.clicked.connect(self._back_lobby)
        row.addWidget(b_back)
        self.lab_title = QLabel("")
        self.lab_title.setStyleSheet(
            "font-size:18px;font-weight:800;color:#E8EDF5;")
        row.addWidget(self.lab_title)
        row.addStretch(1)
        b_give = QPushButton("认输")
        b_give.setFixedWidth(80)
        b_give.clicked.connect(self._give_up)
        row.addWidget(b_give)
        v.addLayout(row)
        self.lab_state = QLabel("")
        self.lab_state.setObjectName("FieldLabel")
        self.lab_state.setWordWrap(True)
        v.addWidget(self.lab_state)
        self.game_host = QWidget()
        self.game_host_lay = QVBoxLayout(self.game_host)
        self.game_host_lay.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self.game_host, 1)
        self.view = None
        return w

    def _build_result(self):
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.addStretch(1)
        card = QFrame()
        card.setObjectName("PlayResultCard")
        card.setStyleSheet(
            "QFrame#PlayResultCard{background:rgba(28,32,40,170);"
            "border-radius:14px;border:1px solid rgba(255,255,255,20);}")
        card.setFixedWidth(520)
        v = QVBoxLayout(card)
        v.setContentsMargins(30, 26, 30, 26)
        v.setSpacing(10)
        self.lab_res = QLabel("")
        self.lab_res.setAlignment(Qt.AlignCenter)
        self.lab_res.setStyleSheet("font-size:24px;font-weight:800;")
        v.addWidget(self.lab_res)
        self.lab_res_sub = QLabel("")
        self.lab_res_sub.setAlignment(Qt.AlignCenter)
        self.lab_res_sub.setObjectName("FieldLabel")
        self.lab_res_sub.setWordWrap(True)
        v.addWidget(self.lab_res_sub)
        self.lab_res_money = QLabel("")
        self.lab_res_money.setAlignment(Qt.AlignCenter)
        self.lab_res_money.setStyleSheet("font-size:15px;color:#E8B04D;")
        self.lab_res_money.setWordWrap(True)
        v.addWidget(self.lab_res_money)
        self.lab_res_hist = QLabel("")
        self.lab_res_hist.setAlignment(Qt.AlignCenter)
        self.lab_res_hist.setObjectName("FieldLabel")
        self.lab_res_hist.setWordWrap(True)
        v.addWidget(self.lab_res_hist)
        row = QHBoxLayout()
        row.addStretch(1)
        b1 = QPushButton("再来一局")
        b1.setObjectName("PrimaryButton")
        b1.setFixedWidth(130)
        b1.clicked.connect(lambda: self._start(self.game_id, bet=self.bet))
        row.addWidget(b1)
        b2 = QPushButton("回大厅")
        b2.setFixedWidth(130)
        b2.clicked.connect(self._back_lobby)
        row.addWidget(b2)
        row.addStretch(1)
        v.addLayout(row)
        hrow = QHBoxLayout()
        hrow.addStretch(1)
        hrow.addWidget(card)
        hrow.addStretch(1)
        outer.addLayout(hrow)
        outer.addStretch(1)
        return w

    def _clear_game(self):
        while self.game_host_lay.count():
            it = self.game_host_lay.takeAt(0)
            w = it.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
        self.view = None

    def _back_lobby(self):
        self._stop_search()
        self._clear_game()
        self.net = {}
        self._finished = False
        self.stack.setCurrentWidget(self.page_lobby if self.logged()
                                    else self.page_gate)
        self.refresh()

    def _give_up(self):
        if self._finished:
            return
        # 认输 = 自己判负，先把要扣的数额算出来，广播给对方好入账
        amt = coins.loss_amount(self.me())
        room = self.net.get("room")
        self._finish(2, opp=self.net.get("opp") or "对手",
                     game=self.game_id, real=bool(room),
                     note="你认输了，这局算对方赢")
        if room:
            gamesync.send_result(room, self.me(), 1, amt)
            gamesync.send_bye(room, self.me())

    def auto_leave_game(self):
        """切到别的界面时，正在打的这局自动认输。

        以前离开娱乐页后对局还挂着，对手（联机时）一直等着；现在一离开就
        按认输结算，真人局照样扣分给对方，AI 局只是把这局结束掉。
        顺便把轮询定时器停掉，别在后台一直发请求（这也是卡顿来源之一）。
        """
        try:
            self.timer.stop()
        except Exception:
            pass
        self._stop_search()
        if self.view is None:
            return
        if getattr(self, "_finished", True):
            self._clear_game()
            return
        try:
            self._give_up()
        except Exception:
            self._finished = True

    # ---------- 开局 ----------
    def _begin_match(self, gid):
        """匹配真人：不本地开局，先把自己放进池子等真人。

        以前点卡片上的「开始」不管什么模式都直接进 AI 对局，
        「匹配真人」实际匹配到的还是人机 —— 就是这里漏了模式判断。
        """
        me = self.me()
        if not me:
            self.stack.setCurrentWidget(self.page_gate)
            return
        self.game_id = gid
        self._pool_room = gamesync.new_room()
        self.bet = coins.loss_amount(me)
        self._searching = True
        self._search_ts = time.time()
        self.stack.setCurrentWidget(self.page_lobby)
        self.lab_tip.setText("正在匹配真人（%s）……等不到真人就一直等，"
                             "不会拿人机凑数。" % mg.game_name(gid))
        self.b_cancel_match.show()
        # 立刻跑一轮，别干等第一个 3 秒
        self._tick()

    def _stop_search(self):
        self._searching = False
        self._pool_room = ""
        b = getattr(self, "b_cancel_match", None)
        if b is not None:
            b.hide()

    def _cancel_match(self, silent=False):
        was = self._searching
        self._stop_search()
        if not silent and was:
            self.lab_tip.setText("已取消匹配。")

    def _start(self, gid, bet=0, net=False):
        me = self.me()
        if not me:
            self.stack.setCurrentWidget(self.page_gate)
            return
        if not net and self.mode == "match":
            self._begin_match(gid)
            return
        self.game_id = gid
        self.bet = int(bet or 0)
        self._finished = False
        self._clear_game()
        self.lab_title.setText(mg.game_name(gid))
        self.stack.setCurrentWidget(self.page_game)
        ver = (self.net or {}).get("room") and net
        if gid == "gomoku":
            self.view = _GomokuView(self)
        elif gid == "go":
            self.view = _GoView(self)
        elif gid == "tic":
            self.view = _TicView(self)
        elif gid == "landlord":
            self.view = _LandlordView(self)
        elif gid == "duel":
            self.view = _DuelView(self)
        elif gid == "rps":
            self.view = _RpsView(self)
        else:
            self.view = _GomokuView(self)
        self.game_host_lay.addWidget(self.view)
        if net:
            self.view.set_net(True, role=(self.net or {}).get("role", "x"))
        else:
            self.view.set_net(False)
        self.lab_state.setText("开局：%s　%s" % (
            mg.game_name(gid),
            "真人对局，输一局扣自己积分的 10%" if self.bet
            else "跟 AI 玩，不结算积分"))

    # ---------- 结算 ----------
    def _opp_on_this_pc(self, opp):
        """对手的账号是不是也在这台机器上（是的话两边账一起记）。"""
        name = (opp or "").strip().lower()
        if not name:
            return False
        try:
            for u in accounts.users():
                if (u.get("name") or "").strip().lower() == name:
                    return True
        except Exception:
            pass
        try:
            return name in [k.lower() for k in coins.all_accounts()]
        except Exception:
            return False

    def _finish(self, win, opp="", bet=0, game="", real=False, note=""):
        if self._finished:
            return
        self._finished = True
        me = self.me()
        game = game or self.game_id
        gname = mg.game_name(game)
        before = coins.balance(me) if me else 0
        amt = 0
        detail = ""
        if real and me:
            opp = (opp or "对手").strip()
            local = self._opp_on_this_pc(opp)
            if win == 1:
                # 赢：拿到对方输掉的那一份（对方余额的 10%）
                amt = int(getattr(self, "_remote_amt", 0) or 0)
                if amt <= 0:
                    amt = coins.loss_amount(opp)
                if amt > 0:
                    if local:
                        coins.settle(me, opp, amt, gname)
                    else:
                        coins.add(me, amt, "赢了", opp, gname)
                    detail = "你把 %d 积分赢过来了（%s 输了这 %d 分）" % (
                        amt, opp, amt)
                else:
                    detail = "对方积分是 0，这局没得扣"
            elif win == 2:
                # 输：扣自己当前积分的 10% 给对方
                amt = coins.loss_amount(me)
                if amt > 0:
                    if local:
                        coins.settle(opp, me, amt, gname)
                    else:
                        coins.add(me, -amt, "输了", opp, gname)
                    detail = "你输了，扣自己积分的 10%%（%d 分）给对方" % amt
                else:
                    detail = "你已经 0 分了，这局没扣动"
            else:
                detail = "平局，积分不动"
        else:
            detail = "AI 对战不结算积分" if win != 0 else "平局"
        after = coins.balance(me) if me else 0
        self.lab_res.setText({1: "你赢了", 2: "你输了", 0: "平局"}.get(win, "结束"))
        color = {1: "#4CD08A", 2: "#E5533D", 0: "#E8B04D"}.get(win, "#E8EDF5")
        self.lab_res.setStyleSheet(
            "font-size:24px;font-weight:800;color:%s;" % color)
        sub = "%s　对手：%s" % (gname, opp or "AI")
        if note:
            sub += "　·　" + note
        self.lab_res_sub.setText(sub)
        money = detail
        if me:
            money += "\n积分：%d → %d（%+d）" % (before, after, after - before)
        self.lab_res_money.setText(money)
        hist = ""
        if me:
            rows = coins.recent(me, 5)
            parts = []
            for r in rows:
                parts.append("%s %+d（%s）" % (
                    mg.game_name(r.get("game") or "") or r.get("reason") or "对局",
                    int(r.get("delta") or 0), r.get("opponent") or "-"))
            hist = "最近：" + "　".join(parts) if parts else "还没有对局记录"
        self.lab_res_hist.setText(hist)
        self.net = {}
        sfx.play({1: "win", 2: "lose", 0: "draw"}.get(win, "click"))
        self.stack.setCurrentWidget(self.page_result)
        self.refresh()

    def set_page(self):
        """主窗切到娱乐页时调一次：刷登录态、刷好友、把轮询开起来。"""
        self.refresh()
        try:
            self._reload_friends()
        except Exception:
            pass
        if not self.timer.isActive():
            self.timer.start()


# ===================== 各玩法视图 =====================
class _GameView(QWidget):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.net = False
        self.role = "x"
        self.bet = 0
        self.opp = ""

    def set_net(self, on, role="x"):
        self.net = bool(on)
        self.role = role

    def apply_remote(self, m):
        pass

    def finish(self, win, note=""):
        net = self.page.net or {}          # 离线局网表格是空的，别在结算时炸
        self.page._finish(win, opp=net.get("opp") or self.opp,
                          bet=self.page.bet, game=self.page.game_id,
                          real=self.net, note=note)


class _GomokuView(_GameView):
    def __init__(self, page):
        super().__init__(page)
        self._ending = False
        self.game = mg.Gomoku()
        v = QVBoxLayout(self)
        v.setSpacing(8)
        self.canvas = BoardCanvas(self.game.size, 30)
        self.canvas.clicked.connect(self._click)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.canvas)
        row.addStretch(1)
        v.addLayout(row)
        self.lab = QLabel("你先下（黑子）")
        self.lab.setObjectName("FieldLabel")
        self.lab.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab)
        v.addStretch(1)
        self.my_turn = True

    def _settle(self, who, note):
        """先把连成的那条线拉出来，停一下（让人看清怎么输的）再结算。"""
        if self._ending:
            return
        self._ending = True
        sfx.play("stone")
        line = self.game.winner_line()
        if line:
            self.canvas.set_winline(line)
        self.lab.setText(note)
        QTimer.singleShot(850, lambda: self.finish(who, note))

    def _click(self, r, c):
        if self.page._finished or not self.my_turn:
            return
        if not self.game.place(r, c, 1):
            return
        sfx.play("stone")
        self.canvas.set_board(self.game.board, self.game.last)
        self.my_turn = False
        w = self.game.winner()
        if w == 1:
            self._settle(1, "五子连珠")
            self._send_res(1)
            return
        if self.game.full():
            self.finish(0, "棋盘下满了")
            return
        if self.net:
            gamesync.send_move(self.page.net["room"], self.page.me(),
                               {"r": r, "c": c})
            self.lab.setText("等对手落子……")
            return
        self.lab.setText("AI 在想……")
        QTimer.singleShot(280, self._ai)

    def _ai(self):
        if self.page._finished or self._ending:
            return
        mv = self.game.ai_move(2)
        self.game.place(mv[0], mv[1], 2)
        sfx.play("stone")
        self.canvas.set_board(self.game.board, self.game.last)
        w = self.game.winner()
        if w == 2:
            self._settle(2, "对手连成五子，看这条线")
            return
        if self.game.full():
            self.finish(0, "棋盘下满了")
            return
        self.my_turn = True
        self.lab.setText("该你了（黑子）")

    def apply_remote(self, m):
        try:
            r, c = int(m.get("r")), int(m.get("c"))
        except Exception:
            return
        if self.game.place(r, c, 2):
            sfx.play("stone")
            self.canvas.set_board(self.game.board, self.game.last)
            self.my_turn = True
            w = self.game.winner()
            if w == 2:
                self._settle(2, "对手连成五子，看这条线")
                return
            if self.game.full():
                self.finish(0, "棋盘下满了")
                return
            self.lab.setText("该你了（黑子）")

    def _send_res(self, win):
        if self.net:
            gamesync.send_result(self.page.net["room"], self.page.me(), win)


class _GoView(_GameView):
    def __init__(self, page):
        super().__init__(page)
        self.game = mg.Go()
        v = QVBoxLayout(self)
        self.canvas = BoardCanvas(self.game.size, 40)
        self.canvas.clicked.connect(self._click)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.canvas)
        row.addStretch(1)
        v.addLayout(row)
        self.lab = QLabel("你先下（黑子）。两边都停一手就终局数子。")
        self.lab.setObjectName("FieldLabel")
        self.lab.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab)
        brow = QHBoxLayout()
        brow.addStretch(1)
        b = QPushButton("停一手 / 数子定胜负")
        b.setFixedWidth(220)
        b.clicked.connect(self._pass)
        brow.addWidget(b)
        brow.addStretch(1)
        v.addLayout(brow)
        v.addStretch(1)
        self.my_turn = True

    def _click(self, r, c):
        if not self.my_turn:
            return
        ok, taken = self.game.play(r, c, 1)
        if not ok:
            self.lab.setText("这里不能下（没气或者劫争）。")
            sfx.play("pass")
            return
        sfx.play("stone")
        if taken:
            QTimer.singleShot(120, lambda: sfx.play("coin"))
        self.canvas.set_board(self.game.board, self.game.last)
        self.my_turn = False
        self.lab.setText("提了 %d 子，AI 在想……" % taken if taken else "AI 在想……")
        QTimer.singleShot(320, self._ai)

    def _ai(self):
        mv = self.game.ai_move(2)
        if mv:
            taken = self.game.play(mv[0], mv[1], 2)[1]
            sfx.play("stone")
            self.canvas.set_board(self.game.board, self.game.last)
            if taken:
                self.lab.setText("AI 提了你 %d 子" % taken)
        else:
            self.game.pass_turn()
            sfx.play("pass")
        self.my_turn = True
        if not self.lab.text().startswith("AI 提了"):
            self.lab.setText("该你了（黑子）")

    def _pass(self):
        b, w = self.game.score()
        if b >= w:
            self.finish(1, "数子：黑 %d 对白 %d" % (b, w))
        else:
            self.finish(2, "数子：黑 %d 对白 %d" % (b, w))


class _TicView(_GameView):
    def __init__(self, page):
        super().__init__(page)
        self._ending = False
        self.game = mg.Tic()
        v = QVBoxLayout(self)
        grid = QGridLayout()
        grid.setSpacing(8)
        self.btns = []
        for i in range(9):
            b = QPushButton("")
            b.setFixedSize(92, 92)
            b.setStyleSheet("font-size:30px;font-weight:700;")
            b.clicked.connect(lambda _=False, i=i: self._click(i))
            grid.addWidget(b, i // 3, i % 3)
            self.btns.append(b)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addLayout(grid)
        row.addStretch(1)
        v.addLayout(row)
        self.lab = QLabel("你先下 X")
        self.lab.setObjectName("FieldLabel")
        self.lab.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab)
        v.addStretch(1)
        self.my_turn = True

    MARK = {0: "", 1: "X", 2: "O"}

    def _paint(self):
        for i, b in enumerate(self.btns):
            b.setText(self.MARK.get(self.game.cells[i], ""))

    def _mark_line(self, pts):
        """把连成线的那三格标出来（结算前让人看清是哪三格）。"""
        for i in pts or []:
            if 0 <= i < 9:
                self.btns[i].setStyleSheet(
                    "font-size:30px;font-weight:700;"
                    "background:#FFD34D;color:#20242A;border-radius:8px;")

    def _settle(self, who, note):
        if self._ending:
            return
        self._ending = True
        line = self.game.winner_line()
        if line:
            self._mark_line(line)
        self.lab.setText(note)
        QTimer.singleShot(850, lambda: self.finish(who, note))

    def _click(self, i):
        if self.page._finished or not self.my_turn:
            return
        if not self.game.place(i, 1):
            return
        sfx.play("select")
        self._paint()
        self.my_turn = False
        if self.game.winner() == 1:
            self._settle(1, "三连成功")
            self._send_res(1)
            return
        if self.game.full():
            self.finish(0, "下满了")
            return
        if self.net:
            gamesync.send_move(self.page.net["room"], self.page.me(), {"i": i})
            self.lab.setText("等对手下……")
            return
        self.lab.setText("AI 在想……")
        QTimer.singleShot(220, self._ai)

    def _ai(self):
        if self.page._finished or self._ending:
            return
        i = self.game.ai_move(2)
        self.game.place(i, 2)
        sfx.play("select")
        self._paint()
        if self.game.winner() == 2:
            self._settle(2, "对手三连，看这三格")
            return
        if self.game.full():
            self.finish(0, "下满了")
            return
        self.my_turn = True
        self.lab.setText("该你了（X）")

    def apply_remote(self, m):
        try:
            i = int(m.get("i"))
        except Exception:
            return
        if self.game.place(i, 2):
            sfx.play("select")
            self._paint()
            self.my_turn = True
            if self.game.winner() == 2:
                self._settle(2, "对手三连，看这三格")
            elif self.game.full():
                self.finish(0, "下满了")

    def _send_res(self, win):
        if self.net:
            gamesync.send_result(self.page.net["room"], self.page.me(), win)


# ===================== 斗地主：牌面与桌面 =====================
_CARD_BG = "#FCF8EE"
_CARD_EDGE = "#CBC3AF"
_CARD_SEL = "#F0B429"
_CARD_RED = "#D33A2C"
_CARD_BLACK = "#20242A"

_LD_QSS = """
#LDTable {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #12733F, stop:0.5 #0A5B33, stop:1 #05391B);
    border-radius: 14px;
}
#LDTable QLabel { background: transparent; color: #E8F5EC; }
#LDSeat {
    background: rgba(255, 255, 255, 28);
    border: 1px solid rgba(255, 255, 255, 70);
    border-radius: 12px;
    color: #F4FBF6;
    font-size: 12px;
}
#LDTip { color: #CFF3DB; font-size: 13px; }
#LDBig { color: #FFE9A8; font-size: 15px; font-weight: 700; }
#LDBtnGo {
    background: #F6B12B; color: #3E2A00; border: none; border-radius: 18px;
    padding: 8px 32px; font-size: 15px; font-weight: 700;
}
#LDBtnGo:disabled { background: #6E7D71; color: #C8D2CA; }
#LDBtnPass {
    background: rgba(255, 255, 255, 34); color: #EAF6EF;
    border: 1px solid rgba(255, 255, 255, 80); border-radius: 18px;
    padding: 8px 24px; font-size: 14px;
}
#LDBtnPass:disabled { color: #9DB0A2; border-color: rgba(255,255,255,40); }
#LDBtnAgain {
    background: transparent; color: #BFE8CC; border: none;
    font-size: 12px; text-decoration: underline;
}
"""


def paint_card(p, rect, card, face_down=False, selected=False):
    """画一张扑克牌：白底圆角、左上角点数与花色、中间一个大花色。

    欢乐斗地主那套牌面就长这样，比纯文字「♠A」直观得多。
    """
    p.save()
    p.setRenderHint(QPainter.Antialiasing, True)
    w, h = rect.width(), rect.height()
    radius = max(3, int(w * 0.10))
    if face_down:
        p.setBrush(QColor("#2B5C8C"))
        p.setPen(QPen(QColor("#1B3E5F"), 1))
        p.drawRoundedRect(rect, radius, radius)
        p.setPen(QPen(QColor("#6FA3CF"), 1))
        p.drawRoundedRect(rect.adjusted(4, 4, -4, -4), max(2, radius - 2),
                          max(2, radius - 2))
        p.setPen(QPen(QColor("#8FBCE0"), 1))
        p.drawLine(rect.left() + w * 0.3, rect.top() + h * 0.2,
                   rect.right() - w * 0.3, rect.bottom() - h * 0.2)
        p.drawLine(rect.right() - w * 0.3, rect.top() + h * 0.2,
                   rect.left() + w * 0.3, rect.bottom() - h * 0.2)
        p.restore()
        return
    p.setBrush(QColor(_CARD_BG))
    p.setPen(QPen(QColor(_CARD_SEL if selected else _CARD_EDGE),
                  2 if selected else 1))
    p.drawRoundedRect(rect, radius, radius)

    if card == 52:
        head, mid, col = "小", "王", QColor(_CARD_BLACK)
    elif card == 53:
        head, mid, col = "大", "王", QColor(_CARD_RED)
    else:
        suit = "♠♥♣♦"[card // 13]
        v = card % 13 + 3
        head = {11: "J", 12: "Q", 13: "K", 14: "A", 15: "2"}.get(v, str(v))
        mid = suit
        col = QColor(_CARD_RED) if suit in "♥♦" else QColor(_CARD_BLACK)

    p.setPen(col)
    f = QFont()
    f.setPixelSize(max(9, int(h * 0.22)))
    f.setBold(True)
    p.setFont(f)
    p.drawText(QRect(rect.left() + 4, rect.top() + 2, int(w * 0.62), int(h * 0.26)),
               Qt.AlignLeft | Qt.AlignVCenter, head)
    fs = QFont()
    fs.setPixelSize(max(8, int(h * 0.18)))
    p.setFont(fs)
    p.drawText(QRect(rect.left() + 4, rect.top() + int(h * 0.25), int(w * 0.6),
                     int(h * 0.22)), Qt.AlignLeft | Qt.AlignVCenter, mid)
    big = QFont()
    big.setPixelSize(max(12, int(h * 0.40)))
    big.setBold(True)
    p.setFont(big)
    p.drawText(QRect(rect.left(), rect.top() + int(h * 0.36), w, int(h * 0.48)),
               Qt.AlignCenter, mid)
    p.restore()


class _CardStrip(QWidget):
    """只显示一组牌（出牌区 / 底牌 / 别人手里的背面）。"""

    def __init__(self, parent=None, face_down=False):
        super().__init__(parent)
        self.cards = []
        self.face_down = face_down
        self.cw, self.ch = 56, 78
        self.gap = 34
        self.setMinimumHeight(self.ch + 6)

    def set_cards(self, cards):
        self.cards = list(cards or [])
        self.setMinimumHeight(self.ch + 6)
        n = len(self.cards)
        need = self.gap * max(0, n - 1) + self.cw + 8
        self.setMinimumWidth(min(need, 500))
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        n = len(self.cards)
        if n:
            span = self.gap * (n - 1) + self.cw
            x0 = max(4, (self.width() - span) // 2)
            for i, c in enumerate(self.cards):
                r = QRect(x0 + i * self.gap, 3, self.cw, self.ch)
                paint_card(p, r, c, face_down=self.face_down)
        p.end()


class _HandCanvas(QWidget):
    """手里的牌：叠着排，点哪张就选上（选中的抬起来）。"""

    picked = Signal(object)
    cleared = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cards = []
        self.selected = set()
        self.cw, self.ch = 78, 108
        self.gap = 36
        self.lift = 18
        self.setMinimumHeight(self.ch + self.lift + 8)
        self.setObjectName("LDHand")

    def set_cards(self, cards, selected=None):
        self.cards = list(cards or [])
        self.selected = set(selected or ())
        self._relayout()
        self.update()

    def _relayout(self):
        n = len(self.cards)
        if n <= 1:
            self.gap = 0
            self.setMinimumWidth(self.cw + 12)
        else:
            avail = max(self.cw + 40, self.width() - self.cw - 14)
            g = int(avail / (n - 1))
            self.gap = max(20, min(int(self.cw * 0.62), g))
            self.setMinimumWidth(self.cw + 12)
        self.update()

    def _x_for(self, i):
        return 6 + i * self.gap

    def _top_for(self, i):
        """选中的牌是往上抬的（以前画反了，会往下掉，看着像被压下去）。"""
        sel = self.cards[i] in self.selected
        return 4 if sel else 4 + self.lift

    def _hit(self, x, y):
        for i in range(len(self.cards) - 1, -1, -1):
            cx = self._x_for(i)
            top = self._top_for(i)
            if cx <= x <= cx + self.cw and top <= y <= top + self.ch:
                return i
        return -1

    def mousePressEvent(self, e):
        i = self._hit(int(e.position().x()), int(e.position().y()))
        if i >= 0:
            self.picked.emit(self.cards[i])
        elif self.selected:
            # 点牌的空白处 = 取消所有选择（手滑点多了一键还原）
            self.cleared.emit()
        else:
            super().mousePressEvent(e)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._relayout()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        for i, c in enumerate(self.cards):
            sel = c in self.selected
            r = QRect(self._x_for(i), self._top_for(i), self.cw, self.ch)
            paint_card(p, r, c, selected=sel)
        p.end()


class _Seat(QWidget):
    """桌上一个座位：头像圈 + 名字 + 还剩几张牌（地主戴金冠）。

    以前这里就是一串文字，看不出身份；现在有头像圈、身份图标和牌背堆。
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(158, 66)
        self._name = ""
        self._n = 0
        self._lord = False
        self._note = None
        self.set_who("", 0, False)

    def set_who(self, name, n, lord=False, note=None):
        self._name = name or ""
        self._n = int(n or 0)
        self._lord = bool(lord)
        self._note = note          # 给了就顶掉「剩 N 张」，21 点用它显示点数
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self.rect().adjusted(0, 0, -1, -1)
        # 底板
        p.setPen(QPen(QColor(255, 255, 255, 70), 1))
        p.setBrush(QColor(255, 255, 255, 26))
        p.drawRoundedRect(r, 12, 12)
        if not self._name:
            p.end()
            return
        # 头像圈
        av = QRect(r.left() + 7, r.top() + 9, 46, 46)
        p.setPen(QPen(QColor("#F0B429" if self._lord else "#7FD6A2"), 2))
        p.setBrush(QColor("#123A24"))
        p.drawEllipse(av)
        f = QFont()
        f.setPixelSize(22)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#F0B429" if self._lord else "#BEF3D2"))
        p.drawText(av, Qt.AlignCenter, "♛" if self._lord else "♠")
        # 名字 + 张数
        tx = r.left() + 60
        f2 = QFont()
        f2.setPixelSize(13)
        f2.setBold(True)
        p.setFont(f2)
        p.setPen(QColor("#FFFFFF"))
        p.drawText(QRect(tx, r.top() + 9, r.width() - tx - 6, 20),
                   Qt.AlignLeft | Qt.AlignVCenter, self._name)
        f3 = QFont()
        f3.setPixelSize(12)
        p.setFont(f3)
        p.setPen(QColor("#FF8A80" if self._n <= 2 else "#CFEEDB"))
        p.drawText(QRect(tx, r.top() + 30, r.width() - tx - 6, 18),
                   Qt.AlignLeft | Qt.AlignVCenter,
                   self._note if self._note is not None
                   else (("剩 %d 张" % self._n) if self._n else "出完了"))
        # 张数旁边的牌背小图标
        if self._n and self._note is None:
            x = r.right() - 26
            for i in range(3):
                rr = QRect(x - i * 5, r.top() + 44, 18, 14)
                paint_card(p, rr, 0, face_down=True)
        p.end()


class _LandlordView(_GameView):
    """斗地主对局：绿呢桌面 + 真牌面 + 底部手牌，照欢乐斗地主那个样子摆的。"""

    def __init__(self, page):
        super().__init__(page)
        self.game = mg.Landlord()
        self._selected = set()
        self.setObjectName("LDTable")
        self.setStyleSheet(_LD_QSS)
        v = QVBoxLayout(self)
        v.setContentsMargins(20, 14, 20, 12)
        v.setSpacing(8)

        top = QHBoxLayout()
        self.seat_a = _Seat(self)
        self.seat_me = _Seat(self)
        self.seat_b = _Seat(self)
        top.addWidget(self.seat_a)
        top.addStretch(1)
        top.addWidget(self.seat_me)
        top.addStretch(1)
        top.addWidget(self.seat_b)
        v.addLayout(top)

        self.lab_tip = QLabel("你是地主，先出牌")
        self.lab_tip.setObjectName("LDTip")
        self.lab_tip.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_tip)

        # 桌中央：上一手出的牌
        self.lab_last = QLabel("")
        self.lab_last.setObjectName("LDBig")
        self.lab_last.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_last)
        self.strip_last = _CardStrip(self)
        v.addWidget(self.strip_last, 1)

        # 底部：自己的手牌
        self.hand_canvas = _HandCanvas(self)
        self.hand_canvas.picked.connect(self._toggle)
        self.hand_canvas.cleared.connect(self._clear_pick)
        v.addWidget(self.hand_canvas)

        self.lab_type = QLabel("点牌选中，再点一次取消；点空白处全取消")
        self.lab_type.setObjectName("LDTip")
        self.lab_type.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_type)

        brow = QHBoxLayout()
        brow.setSpacing(12)
        brow.addStretch(1)
        self.b_hint = QPushButton("提示")
        self.b_hint.setObjectName("LDBtnPass")
        self.b_hint.clicked.connect(self._hint)
        brow.addWidget(self.b_hint)
        self.b_pass = QPushButton("不出")
        self.b_pass.setObjectName("LDBtnPass")
        self.b_pass.clicked.connect(self._pass)
        brow.addWidget(self.b_pass)
        self.b_play = QPushButton("出牌")
        self.b_play.setObjectName("LDBtnGo")
        self.b_play.clicked.connect(self._play)
        brow.addWidget(self.b_play)
        brow.addStretch(1)
        v.addLayout(brow)

        arow = QHBoxLayout()
        arow.addStretch(1)
        self.b_again = QPushButton("重新发牌")
        self.b_again.setObjectName("LDBtnAgain")
        self.b_again.clicked.connect(self._reshuffle)
        arow.addWidget(self.b_again)
        arow.addStretch(1)
        v.addLayout(arow)

        self._reload()

    # ---- 画 ----
    def paintEvent(self, e):
        """自己画桌面：绿呢渐变 + 中间一圈桌纹，别让中间空一大片。"""
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self.rect()
        grad = QLinearGradient(0, 0, 0, r.height())
        grad.setColorAt(0.0, QColor("#12733F"))
        grad.setColorAt(0.5, QColor("#0A5B33"))
        grad.setColorAt(1.0, QColor("#05391B"))
        p.fillRect(r, grad)
        table = r.adjusted(44, 96, -44, -168)
        if table.width() > 40 and table.height() > 40:
            p.setPen(QPen(QColor(255, 255, 255, 26), 2))
            p.setBrush(QColor(255, 255, 255, 12))
            p.drawEllipse(table)
            p.setPen(QPen(QColor(255, 255, 255, 16), 1))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(table.adjusted(12, 12, -12, -12))
        p.end()

    def _reload(self):
        hand = self.game.hand(1)
        self.hand_canvas.set_cards(hand, self._selected)
        self.seat_me.set_who("你 · 地主", len(hand), True)
        self.seat_a.set_who(self.game.label(2), len(self.game.hands[2]))
        self.seat_b.set_who(self.game.label(3), len(self.game.hands[3]))
        if self.game.last:
            who, cs = self.game.last
            self.lab_last.setText("%s 出" % self.game.label(who))
            self.strip_last.set_cards(cs)
        else:
            self.lab_last.setText("新一局开始")
            self.strip_last.set_cards([])
        if self.game.over:
            self.lab_tip.setText("这局结束了，点「重新发牌」再来")
        elif self.game.turn == 1:
            self.lab_tip.setText("轮到你了，选牌再点「出牌」")
        else:
            self.lab_tip.setText("%s 在想……" % self.game.label(self.game.turn))
        self._refresh_buttons()

    def _refresh_buttons(self):
        """按当前选牌算牌型，合不合法、压不压得住都在按钮上体现。"""
        my_turn = (not self.game.over) and self.game.turn == 1
        cards = sorted(self._selected)
        pt = mg.play_type(cards)
        ok_shape = bool(pt[0])
        can_beat = True
        if ok_shape and self.game.last and self.game.last[0] != 1:
            can_beat = bool(mg.beats(pt, self.game.last_type))
        if not cards:
            self.lab_type.setText("点牌选中，再点一次取消；点空白处全取消")
        elif not ok_shape:
            self.lab_type.setText("这几张凑不成牌型，不能出")
        elif not can_beat:
            self.lab_type.setText("牌型：%s　压不过上家" % mg.TYPE_NAMES.get(pt[0], pt[0]))
        else:
            self.lab_type.setText("牌型：%s" % mg.TYPE_NAMES.get(pt[0], pt[0]))
        self.b_play.setEnabled(bool(my_turn and ok_shape and can_beat))
        self.b_pass.setEnabled(bool(my_turn and self.game.last
                                    and self.game.last[0] != 1))
        self.b_hint.setEnabled(bool(my_turn))

    def _toggle(self, card):
        if card in self._selected:
            self._selected.discard(card)
        else:
            self._selected.add(card)
        sfx.play("select")
        self.hand_canvas.set_cards(self.game.hand(1), self._selected)
        self._refresh_buttons()

    def _clear_pick(self):
        if not self._selected:
            return
        self._selected = set()
        self.hand_canvas.set_cards(self.game.hand(1), self._selected)
        self._refresh_buttons()

    def _hint(self):
        """提示：替你把该出的那几张直接选上。"""
        if self.game.over or self.game.turn != 1:
            return
        cards = self.game.hint(1)
        if not cards:
            self._selected = set()
            self.hand_canvas.set_cards(self.game.hand(1), self._selected)
            self._refresh_buttons()
            self.lab_type.setText("这手牌压不住上家，只能点「不出」")
            return
        self._selected = set(cards)
        self.hand_canvas.set_cards(self.game.hand(1), self._selected)
        self._refresh_buttons()

    def _reshuffle(self):
        self.game = mg.Landlord()
        self._selected = set()
        sfx.play("deal")
        self.page.lab_state.setText("新开一局斗地主（跟 AI 玩，不结算积分）"
                                    if not self.page.bet else "新开一局斗地主")
        self._reload()

    # ---- 打 ----
    def _play(self):
        if self.game.over or self.game.turn != 1:
            return
        cards = sorted(self._selected)
        if not cards:
            self.lab_type.setText("先选牌")
            return
        ok, why = self.game.play(1, cards)
        if not ok:
            # 出不掉的牌不能「糊」过去：牌留在手上，选择也留着，只有提示换掉
            self._refresh_buttons()
            self.lab_type.setText(why)
            return
        self._selected = set()
        sfx.play("play")
        self._reload()
        if self.game.over:
            self.finish(1 if self.game.win == 1 else 2,
                        "你先出完牌" if self.game.win == 1 else "农民出完了")
            return
        QTimer.singleShot(320, self._ai_step)

    def _pass(self):
        ok, why = self.game.pass_turn(1)
        self.lab_tip.setText(why if not ok else "你不出，让给下家")
        if ok:
            sfx.play("pass")
            self._selected = set()
            self._reload()
            QTimer.singleShot(320, self._ai_step)

    def _ai_step(self):
        if self.game.over:
            return
        who = self.game.turn
        if who == 1:
            self._reload()
            return
        hand = self.game.hands.get(who) or []
        cards = self.game.ai_play(who)
        ok = False
        if cards:
            ok = self.game.play(who, cards)[0]
            if ok:
                sfx.play("play")
        if not ok:
            ok = self.game.pass_turn(who)[0]
            if ok:
                sfx.play("pass")
        if not ok:
            # 头家不能不出：兜底出一手最小的，绝不让 AI 卡在原地
            cards = self.game._pick_lead(hand)
            self.game.play(who, cards)
        self._reload()
        if self.game.over:
            self.finish(1 if self.game.win == 1 else 2,
                        "你先出完牌" if self.game.win == 1 else "农民出完了")
            return
        QTimer.singleShot(280, self._ai_step)


class _DuelView(_GameView):
    """一对一 21 点：沿用斗地主那套绿呢桌面、真牌面、金按钮和音效。"""

    def __init__(self, page):
        super().__init__(page)
        self._settling = False
        self.game = mg.Blackjack()
        self.setObjectName("LDTable")
        self.setStyleSheet(_LD_QSS)
        v = QVBoxLayout(self)
        v.setContentsMargins(20, 14, 20, 12)
        v.setSpacing(8)

        top = QHBoxLayout()
        self.seat_me = _Seat(self)
        self.seat_opp = _Seat(self)
        top.addWidget(self.seat_me)
        top.addStretch(1)
        top.addWidget(self.seat_opp)
        v.addLayout(top)

        self.lab_tip = QLabel("点「要一张」继续摸牌，超过 21 点就爆")
        self.lab_tip.setObjectName("LDTip")
        self.lab_tip.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_tip)

        self.lab_big = QLabel("")
        self.lab_big.setObjectName("LDBig")
        self.lab_big.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_big)

        self.lab_opp = QLabel("")
        self.lab_opp.setObjectName("LDTip")
        self.lab_opp.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_opp)
        self.strip_opp = _CardStrip(self)
        v.addWidget(self.strip_opp, 1)

        self.lab_me = QLabel("")
        self.lab_me.setObjectName("LDTip")
        self.lab_me.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab_me)
        self.strip_me = _CardStrip(self)
        v.addWidget(self.strip_me, 1)

        brow = QHBoxLayout()
        brow.setSpacing(12)
        brow.addStretch(1)
        self.b_hit = QPushButton("要一张")
        self.b_hit.setObjectName("LDBtnGo")
        self.b_hit.clicked.connect(self._hit)
        brow.addWidget(self.b_hit)
        self.b_stand = QPushButton("停牌，比大小")
        self.b_stand.setObjectName("LDBtnPass")
        self.b_stand.clicked.connect(self._stand)
        brow.addWidget(self.b_stand)
        brow.addStretch(1)
        v.addLayout(brow)

        arow = QHBoxLayout()
        arow.addStretch(1)
        self.b_again = QPushButton("重新开局")
        self.b_again.setObjectName("LDBtnAgain")
        self.b_again.clicked.connect(self._again)
        arow.addWidget(self.b_again)
        arow.addStretch(1)
        v.addLayout(arow)

        self._paint()

    # ---- 画 ----
    def paintEvent(self, e):
        """绿呢桌面 + 中间桌纹，和斗地主一致。"""
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self.rect()
        grad = QLinearGradient(0, 0, 0, r.height())
        grad.setColorAt(0.0, QColor("#12733F"))
        grad.setColorAt(0.5, QColor("#0A5B33"))
        grad.setColorAt(1.0, QColor("#05391B"))
        p.fillRect(r, grad)
        table = r.adjusted(40, 88, -40, -150)
        if table.width() > 40 and table.height() > 40:
            p.setPen(QPen(QColor(255, 255, 255, 26), 2))
            p.setBrush(QColor(255, 255, 255, 12))
            p.drawEllipse(table)
        p.end()

    def _paint(self):
        g = self.game
        mv = mg.bj_value(g.me)
        ov = mg.bj_value(g.opp)
        self.seat_me.set_who("你", len(g.me), False, note="%d 点" % mv)
        self.seat_opp.set_who("对家", len(g.opp), False,
                              note=("%d 点" % ov) if g.done else "暗牌")
        self.lab_me.setText("你的手牌 · %d 点" % mv)
        self.strip_me.set_cards(g.me)
        if g.done:
            self.lab_opp.setText("对家的手牌 · %d 点" % ov)
            self.strip_opp.set_cards(g.opp)
            self.b_hit.setEnabled(False)
            self.b_stand.setEnabled(False)
            if mv > 21:
                self.lab_big.setText("爆了")
            elif ov > 21:
                self.lab_big.setText("对家爆了")
            elif mv > ov:
                self.lab_big.setText("你赢")
            elif mv < ov:
                self.lab_big.setText("你输")
            else:
                self.lab_big.setText("平")
        else:
            self.lab_opp.setText("对家的手牌 · 还没揭")
            self.strip_opp.set_cards(g.opp[:1])
            self.b_hit.setEnabled(True)
            self.b_stand.setEnabled(True)
            self.lab_big.setText("")

    def _hit(self):
        if self.game.done or self._settling:
            return
        self.game.hit()
        sfx.play("flip")
        self._paint()
        if mg.bj_value(self.game.me) > 21:
            sfx.play("bust")
        if self.game.done:
            self._settling = True
            note = "爆点了" if mg.bj_value(self.game.me) > 21 else ""
            QTimer.singleShot(700, lambda: self.finish(self.game.win, note))

    def _stand(self):
        if self.game.done or self._settling:
            return
        self.game.stand()
        sfx.play("flip")
        self._paint()
        self._settling = True
        QTimer.singleShot(500, lambda: self.finish(self.game.win, "比完了"))

    def _again(self):
        if self._settling:
            return
        self.game = mg.Blackjack()
        sfx.play("deal")
        self._paint()


class _RpsView(_GameView):
    def __init__(self, page):
        super().__init__(page)
        self.round = 0
        self.mine = 0
        self.theirs = 0
        self.history = []          # 对手出过的手，AI 拿它预测
        v = QVBoxLayout(self)
        v.setSpacing(10)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btns = []
        for i, name in enumerate(mg.RPS_NAMES):
            b = QPushButton(name)
            b.setFixedSize(96, 56)
            b.clicked.connect(lambda _=False, i=i: self._pick(i))
            row.addWidget(b)
            self.btns.append(b)
        row.addStretch(1)
        v.addLayout(row)
        self.lab = QLabel("五局三胜。石头胜剪刀，剪刀胜布，布胜石头。")
        self.lab.setObjectName("FieldLabel")
        self.lab.setAlignment(Qt.AlignCenter)
        v.addWidget(self.lab)
        v.addStretch(1)

    def _pick(self, i):
        if self.page._finished:
            return
        ai = mg.rps_ai(self.history)
        self.history.append(i)
        r = mg.rps_result(i, ai)
        sfx.play("select")
        if r == 1:
            self.mine += 1
            QTimer.singleShot(160, lambda: sfx.play("coin"))
        elif r == 2:
            self.theirs += 1
            QTimer.singleShot(160, lambda: sfx.play("pass"))
        self.round += 1
        self.lab.setText("你出%s，对手出%s → %s　（%d : %d）"
                         % (mg.RPS_NAMES[i], mg.RPS_NAMES[ai],
                            {1: "你赢这一手", 2: "你输这一手", 0: "平"}.get(r),
                            self.mine, self.theirs))
        if self.net:
            gamesync.send_move(self.page.net["room"], self.page.me(), {"k": i})
        if self.mine >= 3:
            self.finish(1, "五局三胜，你拿下")
        elif self.theirs >= 3:
            self.finish(2, "五局三胜，对手拿下")
        elif self.round >= 5:
            self.finish(0, "打平")
