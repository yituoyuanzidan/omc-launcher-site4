# -*- coding: utf-8 -*-
"""个性化：外观、头像与简介、皮肤库与披风，全部收在这一页。

以前这些散在「设置」和「皮肤库」两页：主题、按键颜色、背景图在设置页，
皮肤和披风要单独点侧栏的「皮肤库」。1.7.64 起合成一页三个标签，
侧栏只留「个性化」一个入口。

这一页用的还是主窗口原来那些处理函数（_on_theme_changed / _on_accent_changed /
_pick_background …），只是把控件搬了个地方，所以改了之后的行为跟以前一模一样。
"""
import os

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QSlider, QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

from ui import style as style_mod
from core import themes


class PersonalizePage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = host.config
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)
        title = QLabel("个性化")
        title.setObjectName("PageTitle")
        v.addWidget(title)
        sub = QLabel("外观、头像、简介、皮肤库、披风，都在这一页。")
        sub.setObjectName("PageSub")
        v.addWidget(sub)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll(self._tab_look()), "外观与背景")
        self.tabs.addTab(self._scroll(self._tab_me()), "头像与简介")
        self._skin_tab_index = self.tabs.addTab(QWidget(), "皮肤库与披风")
        self.tabs.currentChanged.connect(self._ensure_skins)
        v.addWidget(self.tabs, 1)

    def _scroll(self, page):
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(page)
        return sa

    # ---------- 外观 ----------
    def _tab_look(self):
        host = self.host
        page = QWidget()
        form = QVBoxLayout(page)
        form.setSpacing(10)

        form.addWidget(self._label("界面主题"))
        host.combo_theme = QComboBox()
        host.combo_theme.addItem("深色（默认）", "dark")
        host.combo_theme.addItem("浅色", "light")
        host.combo_theme.addItem("暗夜（更黑，晚上看）", "night")
        host.combo_theme.addItem("樱花（浅粉）", "sakura")
        ti = host.combo_theme.findData(self.cfg.get("theme") or "dark")
        if ti >= 0:
            host.combo_theme.setCurrentIndex(ti)
        host.combo_theme.currentIndexChanged.connect(host._on_theme_changed)
        form.addWidget(host.combo_theme)

        form.addWidget(self._label("按键颜色"))
        row = QHBoxLayout()
        row.setSpacing(8)
        host._accent_btns = {}
        cur = self.cfg.get("ui_accent") or "blue"
        for key, cname, color in style_mod.ACCENTS:
            b = QPushButton(cname)
            b.setFixedSize(58, 30)
            b.setCheckable(True)
            b.setChecked(key == cur)
            b.setStyleSheet(
                "QPushButton{background:%s;border:1px solid rgba(255,255,255,40);"
                "border-radius:8px;color:#101318;font-weight:600;}"
                "QPushButton:checked{border:2px solid #FFFFFF;}"
                "QPushButton:hover{background:%s;}" % (color, color))
            b.clicked.connect(lambda _=False, k=key: host._on_accent_changed(k))
            row.addWidget(b)
            host._accent_btns[key] = b
        row.addStretch(1)
        form.addLayout(row)

        form.addWidget(self._label("按键样式"))
        host.combo_btn_style = QComboBox()
        for key, label in style_mod.BUTTON_STYLES:
            host.combo_btn_style.addItem(label, key)
        bi = host.combo_btn_style.findData(self.cfg.get("ui_button") or "round")
        if bi >= 0:
            host.combo_btn_style.setCurrentIndex(bi)
        host.combo_btn_style.currentIndexChanged.connect(host._on_btn_style_changed)
        form.addWidget(host.combo_btn_style)
        form.addWidget(self._hint("按键颜色和样式改了立刻生效；「描边」是透明底 + 主色边框。"))

        form.addWidget(self._label("整套主题预设"))
        row_t = QHBoxLayout()
        row_t.setSpacing(6)
        for pid in ("omc_dark", "stone", "amethyst", "ice"):
            p = themes.get(pid)
            if not p:
                continue
            b = QPushButton(p["name"])
            b.setToolTip(p["desc"])
            b.clicked.connect(lambda _c=False, x=pid: host._apply_theme_preset(x))
            row_t.addWidget(b)
        b_more = QPushButton("更多主题…")
        b_more.setToolTip("主题商店：10 套整套预设，可导出、可导入（在工具页也有入口）")
        b_more.clicked.connect(host._goto_theme_store)
        row_t.addWidget(b_more)
        row_t.addStretch(1)
        form.addLayout(row_t)

        host.chk_cat = QCheckBox("左下角放一只小猫（点它会喵，闲着会讲点游戏知识）")
        host.chk_cat.setChecked(
            True if self.cfg.get("ui_cat") is None else bool(self.cfg.get("ui_cat")))
        host.chk_cat.toggled.connect(host._on_cat_toggled)
        form.addWidget(host.chk_cat)

        form.addWidget(self._label("背景图"))
        cur_bg = self.cfg.get("background_image") or ""
        if cur_bg.startswith("builtin:"):
            cur_bg = host._wall_label(cur_bg) or "内置壁纸"
        host.label_bg_name = QLabel(cur_bg or "默认（跟随主题底色）")
        host.label_bg_name.setObjectName("FieldLabel")
        form.addWidget(host.label_bg_name)

        form.addWidget(self._label("内置壁纸"))
        host.combo_wall = QComboBox()
        host.combo_wall.addItem("不用（纯主题底色）", "")
        for fn, label in host.BUILTIN_WALLS:
            if os.path.exists(host._wall_path(fn)):
                host.combo_wall.addItem(label, "builtin:" + fn)
        wi = host.combo_wall.findData(self.cfg.get("background_image") or "")
        host.combo_wall.setCurrentIndex(wi if wi >= 0 else 0)
        host.combo_wall.currentIndexChanged.connect(host._on_wall_changed)
        form.addWidget(host.combo_wall)

        row_bg = QHBoxLayout()
        host.btn_pick_bg = QPushButton("导入自己的图片")
        host.btn_pick_bg.clicked.connect(host._pick_background)
        host.btn_reset_bg = QPushButton("恢复默认背景")
        host.btn_reset_bg.clicked.connect(host._reset_background)
        row_bg.addWidget(host.btn_pick_bg)
        row_bg.addWidget(host.btn_reset_bg)
        row_bg.addStretch(1)
        form.addLayout(row_bg)

        host.chk_randwall = QCheckBox("每次启动随机换一张内置壁纸")
        host.chk_randwall.setChecked(bool(self.cfg.get("bg_random")))
        host.chk_randwall.setToolTip("勾上后每次打开启动器从内置风景里随机选一张；"
                                     "自己导入的图片不会被换掉")
        host.chk_randwall.toggled.connect(host._on_rand_wall_toggled)
        form.addWidget(host.chk_randwall)
        try:
            host._sync_rand_wall_lock(host.chk_randwall.isChecked())
        except Exception:
            pass

        form.addWidget(self._label("壁纸亮度"))
        host.slider_bgdim = QSlider(Qt.Horizontal)
        host.slider_bgdim.setRange(-40, 80)
        host.slider_bgdim.setValue(int(self.cfg.get("bg_dim") or 0))
        host.slider_bgdim.setToolTip("中间是原图亮度；往左提亮，往右压暗")
        host.slider_bgdim.valueChanged.connect(host._on_bg_dim_changed)
        host.slider_bgdim.sliderReleased.connect(host._save_bg_dim)
        form.addWidget(host.slider_bgdim)
        host.lbl_bgdim = QLabel("")
        host.lbl_bgdim.setObjectName("FieldLabel")
        form.addWidget(host.lbl_bgdim)
        try:
            host._on_bg_dim_changed(host.slider_bgdim.value())
        except Exception:
            pass

        b_save = QPushButton("保存外观设置")
        b_save.setObjectName("PrimaryButton")
        b_save.clicked.connect(host._save_settings)
        form.addWidget(b_save)
        form.addStretch(1)
        return page

    # ---------- 头像与简介 ----------
    def _tab_me(self):
        host = self.host
        page = QWidget()
        form = QVBoxLayout(page)
        form.setSpacing(10)

        form.addWidget(self._label("当前头像"))
        row = QHBoxLayout()
        self.lab_avatar = QLabel()
        self.lab_avatar.setFixedSize(72, 72)
        self.lab_avatar.setAlignment(Qt.AlignCenter)
        self.lab_avatar.setObjectName("AvatarPreview")
        row.addWidget(self.lab_avatar)
        col = QVBoxLayout()
        self.lab_who = QLabel("当前账号：—")
        self.lab_who.setObjectName("FieldLabel")
        col.addWidget(self.lab_who)
        b_av = QPushButton("换头像（内置头像或自己导入图片）")
        b_av.clicked.connect(host._pick_avatar)
        col.addWidget(b_av)
        b_av2 = QPushButton("刷新预览")
        b_av2.clicked.connect(self._refresh_me)
        col.addWidget(b_av2)
        row.addLayout(col, 1)
        form.addLayout(row)

        form.addWidget(self._label("主页简介（随时能改，别人打开你的主页就能看到）"))
        self.input_bio = QTextEdit()
        self.input_bio.setPlaceholderText("写点什么：常玩的版本、在哪个服、找不找人一起开黑…最多 200 字")
        self.input_bio.setFixedHeight(110)
        self.input_bio.setText(self.cfg.get("profile_bio") or "")
        form.addWidget(self.input_bio)
        row_bio = QHBoxLayout()
        b_savebio = QPushButton("保存简介")
        b_savebio.setObjectName("PrimaryButton")
        b_savebio.clicked.connect(self._save_bio)
        b_pub = QPushButton("保存并发布到主页")
        b_pub.clicked.connect(lambda: self._save_bio(publish=True))
        row_bio.addWidget(b_savebio)
        row_bio.addWidget(b_pub)
        row_bio.addStretch(1)
        form.addLayout(row_bio)

        form.addWidget(self._label("主页上显示什么（不勾就是隐藏，别人打开只看到「已隐藏」）"))
        self._hide_boxes = {}
        hide = self.cfg.get("profile_hide") or {}
        # 名称不在列表里：主页靠名字认人，名字藏了对方就不知道该看谁的主页
        for key, label in (("avatar", "头像"),
                           ("play", "游戏时长"), ("friends", "好友数量"),
                           ("online", "启动器在线时长"), ("bio", "主页简介")):
            cb = QCheckBox("显示" + label)
            cb.setChecked(not bool(hide.get(key)))
            cb.toggled.connect(self._save_hide)
            form.addWidget(cb)
            self._hide_boxes[key] = cb
        form.addWidget(self._hint("勾掉以后，发布时就把那项从消息里删掉，别人拉到的资料里根本没有，"
                                  "不是在前端遮一下。名称一定显示，不然别人不知道这是谁的主页。"))
        form.addStretch(1)
        self._refresh_me()
        return page

    def _refresh_me(self):
        host = self.host
        name = "—"
        try:
            from core import accounts
            name = accounts.current_name() or "未登录"
        except Exception:
            pass
        try:
            self.lab_who.setText("当前账号：%s" % name)
        except Exception:
            pass
        try:
            icon = host._avatar_icon(name) if name and name != "未登录" else None
            if icon is not None:
                self.lab_avatar.setPixmap(icon.pixmap(72, 72))
            else:
                self.lab_avatar.setText("无")
        except Exception:
            self.lab_avatar.setText("—")

    def _save_bio(self, publish=False):
        text = (self.input_bio.toPlainText() or "").strip()[:200]
        try:
            self.cfg.set("profile_bio", text)
            self.cfg.save()
        except Exception as e:
            self.lab_who.setText("保存失败：%s" % e)
            return
        self.lab_who.setText("简介已保存（%d 字）%s"
                             % (len(text), "，正在发布…" if publish else ""))
        if publish:
            try:
                self.host._publish_profile(force=True)
                self.lab_who.setText("简介已保存并发布（%d 字）" % len(text))
            except Exception as e:
                self.lab_who.setText("简介已存本机，发布失败：%s" % e)

    def _save_hide(self, *_):
        hide = {}
        for k, cb in self._hide_boxes.items():
            if not cb.isChecked():
                hide[k] = True
        try:
            self.cfg.set("profile_hide", hide)
            self.cfg.save()
        except Exception:
            pass
        try:
            self.host._publish_profile(force=True)
        except Exception:
            pass

    # ---------- 皮肤库与披风 ----------
    def _ensure_skins(self, idx):
        if idx != getattr(self, "_skin_tab_index", -1):
            return
        if getattr(self, "_skins_ready", False):
            return
        self._skins_ready = True
        holder = self.tabs.widget(idx)
        lay = QVBoxLayout(holder)
        lay.setContentsMargins(0, 0, 0, 0)
        try:
            area = self.host._build_skins_page()
            area.setParent(holder)
            lay.addWidget(area)
        except Exception as e:
            lay.addWidget(QLabel("皮肤库加载失败：%s" % e))

    # ---------- 小工具 ----------
    def _label(self, text):
        lb = QLabel(text)
        lb.setObjectName("FieldLabel")
        f = lb.font()
        f.setBold(True)
        lb.setFont(f)
        return lb

    def _hint(self, text):
        lb = QLabel(text)
        lb.setObjectName("FieldLabel")
        lb.setWordWrap(True)
        return lb
