# -*- coding: utf-8 -*-
"""启动器里的聊天窗：好友私聊 + 群聊。

消息走公共中转频道，所有网络请求都在后台线程，界面不卡。
头像随消息捎带（32×32），直接画在气泡旁边。
"""
import html
import os
import threading
import time

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (QComboBox, QDialog, QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QPushButton, QScrollArea,
                               QTextBrowser, QVBoxLayout, QWidget)

from core import avatar, chat

_CARD_QSS = "QDialog#AccountCard { background: #1E2128; }"


def _avatar_tag(name, size=26):
    p = avatar.lookup(name)
    if not p:
        return ""
    url = p.replace("\\", "/")
    return ("<img src='file:///%s' width='%d' height='%d'>"
            % (url, size, size))


class _BaseChat(QDialog):
    sig_rows = Signal(list)
    sig_state = Signal(str)

    POLL_MS = 3000
    KIND = "私聊"

    def __init__(self, me, title, parent=None):
        super().__init__(parent)
        self.me = (me or "").strip()
        self._busy = False
        self._closed = False

        self.setObjectName("AccountCard")
        self.setWindowTitle(title)
        self.setStyleSheet(_CARD_QSS)
        self.resize(560, 620)

        v = QVBoxLayout(self)
        v.setSpacing(8)

        self.lbl_top = QLabel("")
        self.lbl_top.setObjectName("PageSub")
        self.lbl_top.setWordWrap(True)
        v.addWidget(self.lbl_top)

        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(False)
        self.view.setStyleSheet(
            "QTextBrowser{background:#151820;border:1px solid #2A2E38;"
            "border-radius:10px;padding:8px;}")
        v.addWidget(self.view, 1)

        row = QHBoxLayout()
        self.in_text = QLineEdit()
        self.in_text.setPlaceholderText("说点什么，回车发送")
        self.in_text.returnPressed.connect(self._send)
        row.addWidget(self.in_text, 1)
        self.b_send = QPushButton("发送")
        self.b_send.setObjectName("PrimaryButton")
        self.b_send.setFixedWidth(84)
        self.b_send.clicked.connect(self._send)
        row.addWidget(self.b_send)
        v.addLayout(row)

        bottom = QHBoxLayout()
        self.lbl_state = QLabel("正在同步……")
        self.lbl_state.setObjectName("FieldLabel")
        bottom.addWidget(self.lbl_state, 1)
        b_sync = QPushButton("刷新")
        b_sync.setFixedWidth(72)
        b_sync.clicked.connect(lambda: self._pull(force=True))
        bottom.addWidget(b_sync)
        v.addLayout(bottom)

        self.sig_rows.connect(self._render)
        self.sig_state.connect(self.lbl_state.setText)

        self._rows = []
        self._pull(force=True)
        self.timer = QTimer(self)
        self.timer.setInterval(self.POLL_MS)
        self.timer.timeout.connect(lambda: self._pull())
        self.timer.start()

    # ---------- 收发 ----------
    def _do_send(self, text):
        raise NotImplementedError

    def _do_pull(self):
        raise NotImplementedError

    def _send(self):
        text = self.in_text.text().strip()
        if not text:
            return
        self.in_text.clear()
        self.lbl_state.setText("正在发送……")

        def work():
            try:
                ok, why = self._do_send(text)
            except Exception as e:
                ok, why = False, str(e)
            if self._closed:
                return
            if ok:
                self.sig_state.emit("已发送")
                self._pull(force=True)
            else:
                self.sig_state.emit(why)

        threading.Thread(target=work, daemon=True).start()

    def _pull(self, force=False):
        if self._busy or self._closed:
            return
        self._busy = True

        def work():
            try:
                rows = self._do_pull()
            except Exception as e:
                rows = []
                if not self._closed:
                    self.sig_state.emit("拉消息失败：%s" % e)
            if self._closed:
                return
            self._busy = False
            self.sig_rows.emit(rows or [])

        threading.Thread(target=work, daemon=True).start()

    # ---------- 显示 ----------
    def _render(self, rows):
        self._rows = rows
        bubbles = []
        for m in rows:
            mine = (m.get("from") or "").lower() == self.me.lower()
            when = time.strftime("%H:%M", time.localtime(m.get("ts") or 0))
            body = html.escape(m.get("text") or "").replace("\n", "<br>")
            bg = "#2E5B45" if mine else "#2A2F3A"
            align = "right" if mine else "left"
            who = "我" if mine else html.escape(m.get("from") or "")
            av = _avatar_tag(m.get("from") or "")
            bubbles.append(
                "<div style='text-align:%s;margin:8px 0;'>%s"
                "<span style='color:#7f8794;font-size:11px;'>%s · %s</span><br>"
                "<span style='background:%s;color:#E8EDF5;padding:6px 10px;"
                "border-radius:8px;display:inline-block;'>%s</span></div>"
                % (align, (av + "&nbsp;") if av else "", who, when, bg, body))
        if not bubbles:
            self.view.setHtml(
                "<div style='color:#7f8794;padding:20px;text-align:center;'>"
                "还没有消息。说第一句话吧。</div>")
        else:
            self.view.setHtml("<div style='font-size:13px;'>%s</div>"
                              % "".join(bubbles))
        bar = self.view.verticalScrollBar()
        bar.setValue(bar.maximum())
        if rows:
            self.lbl_state.setText("共 %d 条" % len(rows))

    def closeEvent(self, e):
        self._closed = True
        try:
            self.timer.stop()
        except Exception:
            pass
        super().closeEvent(e)


class ChatDialog(_BaseChat):
    """和某个好友一对一私聊。"""

    def __init__(self, me, peer, parent=None):
        self.peer = (peer or "").strip()
        super().__init__(me, "私聊 · %s" % self.peer, parent)
        self.lbl_top.setText(
            "和 %s 私聊。只要两边都开着启动器（不用进游戏）就能收到；"
            "消息经公共中转，不要在聊天里发密码。" % self.peer)

    def _do_send(self, text):
        return chat.send(self.me, self.peer, text)

    def _do_pull(self):
        return chat.history(self.me, self.peer, since="12h")


class GroupChatDialog(_BaseChat):
    """群聊：知道群号的人都在同一个群里。"""

    def __init__(self, me, gid, title="", parent=None):
        self.gid = (gid or "").strip()
        self.gtitle = (title or self.gid)
        super().__init__(me, "群聊 · %s" % self.gtitle, parent)
        self.lbl_top.setText(
            "群「%s」，群号 %s。把群号发给别人，他填进「加入群聊」就在同一个群里；"
            "两边开着启动器就能聊。" % (self.gtitle, self.gid))

    def _members(self):
        for g in chat.group_list():
            if (g.get("id") or "") == self.gid:
                return g.get("members") or []
        return []

    def _do_send(self, text):
        return chat.send_group(self.me, self.gid, text)

    def _do_pull(self):
        return chat.group_history(self.gid, since="12h",
                                  members=self._members() or None)


class AvatarPickerDialog(QDialog):
    """选头像：五个分类的头像包 + 经典像素 + 导入自己的图。

    头像包来自 assets/avatars/（男生 / 女生 / 二次元 / 动漫 / 可爱），
    开源头像引擎生成、无水印，随包离线可用。
    """

    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = (name or "").strip()
        self.picked = ""
        self.setObjectName("AccountCard")
        self.setWindowTitle("选择头像")
        self.setStyleSheet(_CARD_QSS)
        self.resize(660, 560)
        self._cells = []
        self._cur_cat = ""

        v = QVBoxLayout(self)
        t = QLabel("挑一个喜欢的头像：「男生 / 女生 / 二次元 / 动漫 / 可爱」五类，"
                   "还有经典像素头像。点一下就直接换成它。")
        t.setObjectName("PageSub")
        t.setWordWrap(True)
        v.addWidget(t)

        bar = QHBoxLayout()
        bar.addWidget(QLabel("分类"))
        self.combo_cat = QComboBox()
        self._cats = avatar.pack_categories()
        for cat, files in self._cats:
            self.combo_cat.addItem("%s（%d）" % (cat, len(files)), cat)
        self.combo_cat.addItem("经典像素（%d）" % len(avatar.builtin_ids()), "pixel")
        self.combo_cat.currentIndexChanged.connect(self._on_cat)
        bar.addWidget(self.combo_cat, 1)
        self.lbl_count = QLabel("")
        self.lbl_count.setObjectName("PageSub")
        bar.addWidget(self.lbl_count)
        v.addLayout(bar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        self.scroll.setMinimumHeight(300)
        self._host = QWidget()
        self.grid = QGridLayout(self._host)
        self.grid.setContentsMargins(2, 2, 2, 2)
        self.grid.setSpacing(8)
        self.scroll.setWidget(self._host)
        v.addWidget(self.scroll, 1)

        row = QHBoxLayout()
        b_file = QPushButton("导入自己的图片…")
        b_file.clicked.connect(self._import)
        row.addWidget(b_file)
        b_def = QPushButton("清除头像")
        b_def.clicked.connect(self._clear)
        row.addWidget(b_def)
        row.addStretch(1)
        b_ok = QPushButton("关闭")
        b_ok.clicked.connect(self.accept)
        row.addWidget(b_ok)
        v.addLayout(row)

        if self._cats:
            self._on_cat(0)
        else:
            self.combo_cat.setCurrentIndex(self.combo_cat.count() - 1)
            self._on_cat(self.combo_cat.currentIndex())

    # ---- 网格
    def _clear_grid(self):
        self._cells = []
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()

    def _add_cell(self, idx, pix, tip, handler):
        b = QPushButton()
        b.setFixedSize(86, 86)
        b.setToolTip(tip)
        b.setCursor(Qt.PointingHandCursor)
        if pix is not None and not pix.isNull():
            b.setIcon(QIcon(pix))
            b.setIconSize(QSize(74, 74))
        else:
            b.setText(tip)
        b.clicked.connect(handler)
        row, col = idx // 6, idx % 6
        self.grid.addWidget(b, row, col)
        self._cells.append(b)
        return b

    def _on_cat(self, _i=None):
        cat = self.combo_cat.currentData() or "pixel"
        self._cur_cat = cat
        self._clear_grid()
        n = 0
        if cat == "pixel":
            for bid in avatar.builtin_ids():
                img = avatar.builtin_image(bid)
                pix = None
                if img is not None:
                    tmp = avatar.me_path(self.name + "_" + bid + "_preview")
                    try:
                        img.save(tmp, "PNG")
                        pix = QPixmap(tmp)
                    except Exception:
                        pix = None
                self._add_cell(n, pix, "经典像素 %s" % bid,
                               lambda _c=False, x=bid: self._pick_builtin(x))
                n += 1
            self.lbl_count.setText("经典像素头像")
        else:
            files = dict(self._cats).get(cat, [])
            for path in files:
                pix = QPixmap(path)
                self._add_cell(n, pix, os.path.basename(path),
                               lambda _c=False, q=path: self._pick_pack(q))
                n += 1
            self.lbl_count.setText("%d 个" % n)
        # 底部对齐，避免最后一页被拉伸
        self.grid.setRowStretch((n + 5) // 6, 1)

    # ---- 选择
    def _pick_pack(self, path):
        if not self.name:
            self.setWindowTitle("选择头像 · 先在账号页选中一个账号")
            return
        if avatar.save_pack(self.name, path):
            self.picked = "pack"
            self.setWindowTitle("选择头像 · 已换上")
            self.lbl_count.setText("已设为这个头像")

    def _pick_builtin(self, bid):
        if avatar.save_builtin(self.name, bid):
            self.picked = bid
            self.setWindowTitle("选择头像 · 已设为经典像素 %s" % bid)

    def _import(self):
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        p, _ = QFileDialog.getOpenFileName(
            self, "挑一张图片当头像", "",
            "图片 (*.png *.jpg *.jpeg *.bmp *.webp);;全部文件 (*)")
        if not p:
            return
        ok, why = avatar.save_from_file(self.name, p)
        if ok:
            self.picked = "file"
            self.setWindowTitle("选择头像 · 已用你的图片")
        else:
            QMessageBox.warning(self, "导入失败", why)

    def _clear(self):
        avatar.clear(self.name)
        self.picked = ""
        self.setWindowTitle("选择头像 · 已清除")
