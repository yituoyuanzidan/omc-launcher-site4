# -*- coding: utf-8 -*-
"""启动器里的聊天窗：好友私聊 + 群聊。

消息走公共中转频道，所有网络请求都在后台线程，界面不卡。
头像随消息捎带（32×32），直接画在气泡旁边。
"""
import html
import os
import threading
import time

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (QComboBox, QDialog, QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QPushButton, QScrollArea, QTextBrowser,
                               QVBoxLayout, QWidget)

from core import avatar, chat

_CARD_QSS = "QDialog#AccountCard { background: #1E2128; }"


def _avatar_tag(name, av_b64="", size=26):
    """气泡旁边的头像。

    顺序：先用这条消息自己捎带的 32×32 小图（data URI，不用落盘、跨机器也能看到），
    再用本地头像库里这个人的图，都没有就不显示。
    """
    src = ""
    if av_b64:
        b64 = str(av_b64).strip()
        if b64.startswith("data:"):
            src = b64
        elif len(b64) >= 32:
            src = "data:image/png;base64," + b64
    if not src:
        p = avatar.lookup(name)
        if p:
            src = "file:///" + p.replace("\\", "/")
    if not src:
        return ""
    return ("<img src='%s' width='%d' height='%d' "
            "style='border-radius:4px;vertical-align:middle;'>"
            % (src, size, size))


def _hl_mentions(escaped_text, ats, highlight_me="", me=""):
    """把正文里的 @某某 标成彩色；@ 到自己的那个用醒目一点的色。"""
    out = escaped_text
    for n in sorted(set([str(x) for x in (ats or [])]), key=len, reverse=True):
        if not n:
            continue
        key = "@" + html.escape(n)
        color = "#FFB74D" if n.lower() == (me or "").lower() else "#7FD1FF"
        out = out.replace(
            key, "<span style='color:%s;font-weight:600;'>%s</span>"
                 % (color, key))
    return out


class _BaseChat(QDialog):
    sig_rows = Signal(list)
    sig_state = Signal(str)

    POLL_MS = 3000
    KIND = "私聊"

    def __init__(self, me, title, parent=None):
        super().__init__(parent)
        self.me = (me or "").strip()
        self._busy = False
        self._closed = False

        self.setObjectName("AccountCard")
        self.setWindowTitle(title)
        self.setStyleSheet(_CARD_QSS)
        self.resize(560, 620)

        v = QVBoxLayout(self)
        v.setSpacing(8)

        self.lbl_top = QLabel("")
        self.lbl_top.setObjectName("PageSub")
        self.lbl_top.setWordWrap(True)
        v.addWidget(self.lbl_top)

        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(False)
        self.view.setStyleSheet(
            "QTextBrowser{background:#151820;border:1px solid #2A2E38;"
            "border-radius:10px;padding:8px;}")
        v.addWidget(self.view, 1)

        row = QHBoxLayout()
        self.row_input = row
        self.in_text = QLineEdit()
        self.in_text.setPlaceholderText("说点什么，回车发送")
        self.in_text.returnPressed.connect(self._send)
        row.addWidget(self.in_text, 1)
        self.b_send = QPushButton("发送")
        self.b_send.setObjectName("PrimaryButton")
        self.b_send.setFixedWidth(84)
        self.b_send.clicked.connect(self._send)
        row.addWidget(self.b_send)
        v.addLayout(row)

        bottom = QHBoxLayout()
        self.bottom = bottom
        self.lbl_state = QLabel("正在同步……")
        self.lbl_state.setObjectName("FieldLabel")
        bottom.addWidget(self.lbl_state, 1)
        b_sync = QPushButton("刷新")
        b_sync.setFixedWidth(72)
        b_sync.clicked.connect(lambda: self._pull(force=True))
        bottom.addWidget(b_sync)
        v.addLayout(bottom)

        self.sig_rows.connect(self._render)
        self.sig_state.connect(self.lbl_state.setText)

        self._rows = []
        self._pull(force=True)
        self.timer = QTimer(self)
        self.timer.setInterval(self.POLL_MS)
        self.timer.timeout.connect(lambda: self._pull())
        self.timer.start()

    def showEvent(self, e):
        """重新打开时把轮询开起来并立刻拉一次（隐藏期间已经停掉了）。"""
        super().showEvent(e)
        try:
            if hasattr(self, "timer") and not self.timer.isActive():
                self.timer.start()
            self._pull(force=True)
        except Exception:
            pass

    def hideEvent(self, e):
        """浮窗被收起时停掉轮询：以前隐藏了还按 POLL_MS 一直拉网络。"""
        try:
            if hasattr(self, "timer"):
                self.timer.stop()
        except Exception:
            pass
        super().hideEvent(e)

    # ---------- 收发 ----------
    def _do_send(self, text):
        raise NotImplementedError

    def _do_pull(self):
        raise NotImplementedError

    def _send(self):
        text = self.in_text.text().strip()
        if not text:
            return
        self.in_text.clear()
        self.lbl_state.setText("正在发送……")

        def work():
            try:
                ok, why = self._do_send(text)
            except Exception as e:
                ok, why = False, str(e)
            if self._closed:
                return
            if ok:
                self.sig_state.emit((why or "").strip() or "已发送")
                self._pull(force=True)
            else:
                self.sig_state.emit(why)

        threading.Thread(target=work, daemon=True).start()

    def _pull(self, force=False):
        if self._busy or self._closed:
            return
        self._busy = True

        def work():
            try:
                rows = self._do_pull()
            except Exception as e:
                rows = []
                if not self._closed:
                    self.sig_state.emit("拉消息失败：%s" % e)
            if self._closed:
                return
            self._busy = False
            self.sig_rows.emit(rows or [])

        threading.Thread(target=work, daemon=True).start()

    # ---------- 显示 ----------
    def _render(self, rows):
        self._rows = rows
        bubbles = []
        for m in rows:
            mine = (m.get("from") or "").lower() == self.me.lower()
            when = time.strftime("%H:%M", time.localtime(m.get("ts") or 0))
            body = html.escape(m.get("text") or "").replace("\n", "<br>")
            body = _hl_mentions(body, m.get("at") or [], me=self.me)
            bg = "#2E5B45" if mine else "#2A2F3A"
            align = "right" if mine else "left"
            who = "我" if mine else html.escape(m.get("from") or "")
            if (not mine) and chat.at_me(m, self.me):
                who += "　<span style='color:#FFB74D;font-size:11px;'>@了你</span>"
            av = _avatar_tag(m.get("from") or "", m.get("av") or "")
            bubbles.append(
                "<div style='text-align:%s;margin:8px 0;'>%s"
                "<span style='color:#7f8794;font-size:11px;'>%s · %s</span><br>"
                "<span style='background:%s;color:#E8EDF5;padding:6px 10px;"
                "border-radius:8px;display:inline-block;'>%s</span></div>"
                % (align, (av + "&nbsp;") if av else "", who, when, bg, body))
        if not bubbles:
            self.view.setHtml(
                "<div style='color:#7f8794;padding:20px;text-align:center;'>"
                "还没有消息。说第一句话吧。</div>")
        else:
            self.view.setHtml("<div style='font-size:13px;'>%s</div>"
                              % "".join(bubbles))
        bar = self.view.verticalScrollBar()
        bar.setValue(bar.maximum())
        if rows:
            self.lbl_state.setText("共 %d 条" % len(rows))

    def closeEvent(self, e):
        self._closed = True
        try:
            self.timer.stop()
        except Exception:
            pass
        super().closeEvent(e)


class ChatDialog(_BaseChat):
    """和某个好友一对一私聊。"""

    def __init__(self, me, peer, parent=None):
        self.peer = (peer or "").strip()
        super().__init__(me, "私聊 · %s" % self.peer, parent)
        self.lbl_top.setText(
            "和 %s 私聊。只要两边都开着启动器（不用进游戏）就能收到；"
            "消息经公共中转，不要在聊天里发密码。" % self.peer)

    def _do_send(self, text):
        return chat.send(self.me, self.peer, text)

    def _do_pull(self):
        return chat.history(self.me, self.peer, since="12h")


class GroupChatDialog(_BaseChat):
    """群聊：知道群号的人都在同一个群里。群主可以踢人、禁言。"""

    def __init__(self, me, gid, title="", parent=None):
        self.gid = (gid or "").strip()
        self.gtitle = (title or self.gid)
        super().__init__(me, "群聊 · %s" % self.gtitle, parent)
        self.lbl_top.setText(
            "群「%s」，群号 %s。把群号发给别人，他填进「加入群聊」就在同一个群里；"
            "两边开着启动器就能聊。" % (self.gtitle, self.gid))
        # 我是群主/管理员才有管理入口
        self._role = chat.group_role(self.gid, self.me)
        self._at_sel = []
        self.b_at = QPushButton("＠")
        self.b_at.setFixedWidth(40)
        self.b_at.setToolTip("点一下选要 @ 的人")
        self.b_at.clicked.connect(self._open_at_menu)
        self.row_input.insertWidget(1, self.b_at)
        self.b_manage = None
        if self._role in ("owner", "admin"):
            self.b_manage = QPushButton("成员管理")
            self.b_manage.setToolTip("踢人 / 禁言群员")
            self.b_manage.clicked.connect(self._open_manage)
            self.bottom.insertWidget(self.bottom.count() - 1, self.b_manage)
            role_txt = "群主" if self._role == "owner" else "管理员"
            self.lbl_state.setText("你是这个群的%s，可以踢人和禁言。" % role_txt)

    def _members(self):
        g = chat.group_get(self.gid)
        return list(g.get("members") or [])

    def _do_send(self, text):
        ats = [n for n in self._at_sel if n]
        ok, why = chat.send_group(self.me, self.gid, text, ats=ats)
        if ok:
            self._at_sel = []
        return ok, why

    def _open_at_menu(self):
        """@ 谁：列出群成员（去掉自己），选一个就把「@名字」塞进输入框。"""
        from PySide6.QtWidgets import QMenu
        members = [m for m in self._members()
                   if m and m.lower() != (self.me or "").lower()]
        m = QMenu(self)
        a_all = m.addAction("@所有人")
        m.addSeparator()
        known = set(members)
        # 本地没记到的人也得能 @：从最近聊天里出现过的人补上
        try:
            for r in self._rows:
                n = (r.get("from") or "").strip()
                if n and n.lower() != (self.me or "").lower() and n not in known:
                    known.add(n)
                    members.append(n)
        except Exception:
            pass
        acts = {}
        for name in members[:40]:
            acts[m.addAction("@" + name)] = name
        if not members:
            m.addAction("群里还没人说过话，先在输入框打 @名字").setEnabled(False)
        m.addSeparator()
        acts[m.addAction("手动输入 @名字")] = ""
        picked = m.exec_(self.b_at.mapToGlobal(self.b_at.rect().bottomLeft()))
        if picked is None:
            return
        if picked.text() == "@所有人":
            self._insert_at("所有人")
            return
        name = acts.get(picked, None)
        if name is None:
            return
        if name == "":
            self.in_text.setText(self.in_text.text() + "@")
        else:
            self._insert_at(name)
        self.in_text.setFocus()

    def _insert_at(self, name):
        t = self.in_text.text()
        token = "@" + name + " "
        if token.strip() in t:
            return
        self.in_text.setText((t + ("" if t.endswith(" ") or not t else " ")
                              + token).lstrip())
        if name != "所有人" and name not in self._at_sel:
            self._at_sel.append(name)

    def _do_pull(self):
        # 不按成员名单过滤：名单是各端本地记的，按它过滤会看不到别人说话
        return chat.group_history(self.gid, since="12h")

    def _open_manage(self):
        dlg = GroupManageDialog(self.me, self.gid, self.gtitle, self)
        dlg.exec()
        self._pull(force=True)


class GroupManageDialog(QDialog):
    """群主 / 管理员：踢人、禁言群员。"""

    def __init__(self, me, gid, title="", parent=None):
        super().__init__(parent)
        self.me = (me or "").strip()
        self.gid = (gid or "").strip()
        self.setObjectName("AccountCard")
        self.setWindowTitle("成员管理 · %s" % (title or self.gid))
        self.setStyleSheet(_CARD_QSS)
        self.resize(520, 460)

        v = QVBoxLayout(self)
        v.setSpacing(8)
        g = chat.group_get(self.gid)
        owner = g.get("owner") or ""
        self.lbl_role = QLabel(
            "群号 %s　·　群主：%s\n只有群主和管理员能踢人、禁言；"
            "别人那边会同步收到这条管理消息。" % (self.gid, owner or "（未知）"))
        self.lbl_role.setObjectName("PageSub")
        self.lbl_role.setWordWrap(True)
        v.addWidget(self.lbl_role)

        self.lst = QListWidget()
        self.lst.setStyleSheet(
            "QListWidget{background:#151820;border:1px solid #2A2E38;"
            "border-radius:10px;padding:6px;}")
        v.addWidget(self.lst, 1)

        row = QHBoxLayout()
        row.setSpacing(8)
        self.cb_min = QComboBox()
        for m in (1, 5, 10, 30, 60, 1440):
            self.cb_min.addItem("%d 分钟" % m if m < 60 else "1 天", m)
        self.cb_min.setCurrentIndex(2)
        row.addWidget(self.cb_min)
        b_mute = QPushButton("禁言")
        b_mute.clicked.connect(self._mute)
        row.addWidget(b_mute)
        b_unmute = QPushButton("解除禁言")
        b_unmute.clicked.connect(self._unmute)
        row.addWidget(b_unmute)
        b_kick = QPushButton("踢出群")
        b_kick.clicked.connect(self._kick)
        row.addWidget(b_kick)
        row.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.clicked.connect(self.accept)
        row.addWidget(b_close)
        v.addLayout(row)

        self._reload()

    def _reload(self):
        self.lst.clear()
        g = chat.group_get(self.gid)
        owner = (g.get("owner") or "").strip()
        members = list(g.get("members") or [])
        if not members:
            it = QListWidgetItem("还没有记录到成员。群里有人发过言才会出现在这里。")
            it.setFlags(Qt.NoItemFlags)
            self.lst.addItem(it)
            return
        for name in members:
            left = chat.mute_left(self.gid, name)
            tag = "（群主）" if name.lower() == owner.lower() else ""
            if left > 0:
                tag += "　禁言中 %d 分 %d 秒" % (left // 60, left % 60)
            it = QListWidgetItem("%s%s" % (name, tag))
            it.setData(Qt.UserRole, name)
            self.lst.addItem(it)

    def _sel(self):
        it = self.lst.currentItem()
        name = (it.data(Qt.UserRole) or "") if it else ""
        if not name:
            self.lbl_role.setText("先在列表里点一个人。")
            return ""
        if name.lower() == self.me.lower():
            self.lbl_role.setText("不能管自己。")
            return ""
        return name

    def _mute(self):
        name = self._sel()
        if not name:
            return
        mins = self.cb_min.currentData() or 10
        ok, why = chat.group_mute(self.gid, name, mins)
        self.lbl_role.setText("已禁言 %s %d 分钟" % (name, mins))
        self._reload()

    def _unmute(self):
        name = self._sel()
        if not name:
            return
        chat.group_mute(self.gid, name, 0)
        self.lbl_role.setText("已解除 %s 的禁言" % name)
        self._reload()

    def _kick(self):
        name = self._sel()
        if not name:
            return
        from PySide6.QtWidgets import QMessageBox
        r = QMessageBox.question(
            self, "踢出群", "把 %s 踢出这个群？他再发消息也不会显示了。" % name,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if r != QMessageBox.Yes:
            return
        chat.group_kick(self.gid, name)
        self.lbl_role.setText("已踢出 %s" % name)
        self._reload()


class AvatarPickerDialog(QDialog):
    """选头像：五个分类的头像包 + 经典像素 + 导入自己的图。

    头像包来自 assets/avatars/（男生 / 女生 / 二次元 / 动漫 / 可爱），
    开源头像引擎生成、无水印，随包离线可用。
    """

    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = (name or "").strip()
        self.picked = ""
        self.setObjectName("AccountCard")
        self.setWindowTitle("选择头像")
        self.setStyleSheet(_CARD_QSS)
        self.resize(660, 560)
        self._cells = []
        self._cur_cat = ""

        v = QVBoxLayout(self)
        t = QLabel("挑一个喜欢的头像：「男生 / 女生 / 二次元 / 动漫 / 可爱」五类，"
                   "还有经典像素头像。点一下就直接换成它。")
        t.setObjectName("PageSub")
        t.setWordWrap(True)
        v.addWidget(t)

        bar = QHBoxLayout()
        bar.addWidget(QLabel("分类"))
        self.combo_cat = QComboBox()
        self._cats = avatar.pack_categories()
        for cat, files in self._cats:
            self.combo_cat.addItem("%s（%d）" % (cat, len(files)), cat)
        self.combo_cat.addItem("经典像素（%d）" % len(avatar.builtin_ids()), "pixel")
        self.combo_cat.currentIndexChanged.connect(self._on_cat)
        bar.addWidget(self.combo_cat, 1)
        self.lbl_count = QLabel("")
        self.lbl_count.setObjectName("PageSub")
        bar.addWidget(self.lbl_count)
        v.addLayout(bar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        self.scroll.setMinimumHeight(300)
        self._host = QWidget()
        self.grid = QGridLayout(self._host)
        self.grid.setContentsMargins(2, 2, 2, 2)
        self.grid.setSpacing(8)
        self.scroll.setWidget(self._host)
        v.addWidget(self.scroll, 1)

        row = QHBoxLayout()
        b_file = QPushButton("导入自己的图片…")
        b_file.clicked.connect(self._import)
        row.addWidget(b_file)
        b_def = QPushButton("清除头像")
        b_def.clicked.connect(self._clear)
        row.addWidget(b_def)
        row.addStretch(1)
        b_ok = QPushButton("关闭")
        b_ok.clicked.connect(self.accept)
        row.addWidget(b_ok)
        v.addLayout(row)

        if self._cats:
            self._on_cat(0)
        else:
            self.combo_cat.setCurrentIndex(self.combo_cat.count() - 1)
            self._on_cat(self.combo_cat.currentIndex())

    # ---- 网格
    def _clear_grid(self):
        self._cells = []
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()

    def _add_cell(self, idx, pix, tip, handler):
        b = QPushButton()
        b.setFixedSize(86, 86)
        b.setToolTip(tip)
        b.setCursor(Qt.PointingHandCursor)
        if pix is not None and not pix.isNull():
            b.setIcon(QIcon(pix))
            b.setIconSize(QSize(74, 74))
        else:
            b.setText(tip)
        b.clicked.connect(handler)
        row, col = idx // 6, idx % 6
        self.grid.addWidget(b, row, col)
        self._cells.append(b)
        return b

    def _on_cat(self, _i=None):
        cat = self.combo_cat.currentData() or "pixel"
        self._cur_cat = cat
        self._clear_grid()
        n = 0
        if cat == "pixel":
            for bid in avatar.builtin_ids():
                img = avatar.builtin_image(bid)
                pix = None
                if img is not None:
                    tmp = avatar.me_path(self.name + "_" + bid + "_preview")
                    try:
                        img.save(tmp, "PNG")
                        pix = QPixmap(tmp)
                    except Exception:
                        pix = None
                self._add_cell(n, pix, "经典像素 %s" % bid,
                               lambda _c=False, x=bid: self._pick_builtin(x))
                n += 1
            self.lbl_count.setText("经典像素头像")
        else:
            files = dict(self._cats).get(cat, [])
            for path in files:
                pix = QPixmap(path)
                self._add_cell(n, pix, os.path.basename(path),
                               lambda _c=False, q=path: self._pick_pack(q))
                n += 1
            self.lbl_count.setText("%d 个" % n)
        # 底部对齐，避免最后一页被拉伸
        self.grid.setRowStretch((n + 5) // 6, 1)

    # ---- 选择
    def _pick_pack(self, path):
        if not self.name:
            self.setWindowTitle("选择头像 · 先在账号页选中一个账号")
            return
        if avatar.save_pack(self.name, path):
            self.picked = "pack"
            self.setWindowTitle("选择头像 · 已换上")
            self.lbl_count.setText("已设为这个头像")

    def _pick_builtin(self, bid):
        if avatar.save_builtin(self.name, bid):
            self.picked = bid
            self.setWindowTitle("选择头像 · 已设为经典像素 %s" % bid)

    def _import(self):
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        p, _ = QFileDialog.getOpenFileName(
            self, "挑一张图片当头像", "",
            "图片 (*.png *.jpg *.jpeg *.bmp *.webp);;全部文件 (*)")
        if not p:
            return
        ok, why = avatar.save_from_file(self.name, p)
        if ok:
            self.picked = "file"
            self.setWindowTitle("选择头像 · 已用你的图片")
        else:
            QMessageBox.warning(self, "导入失败", why)

    def _clear(self):
        avatar.clear(self.name)
        self.picked = ""
        self.setWindowTitle("选择头像 · 已清除")
