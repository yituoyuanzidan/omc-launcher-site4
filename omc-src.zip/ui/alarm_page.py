# -*- coding: utf-8 -*-
"""工具页里的「闹钟 / 计时器」页签。

里面三块：
1. 闹钟：多组、可重复周几、精确到 0.01 秒、可贪睡、可改名；
2. 倒计时：填秒数（支持 1:05.30 这种写法），精确到 0.01 秒，可暂停/继续；
3. 秒表：计时 + 计次。
铃声统一在服务里，可切内置、可导入自己的 wav/mp3。
"""
import os
import shutil
import time

from PySide6.QtCore import Qt, QSize, QTimer
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton,
                               QSpinBox, QTabWidget, QVBoxLayout, QWidget)

from core import alarm as _alarm

_DAY_NAMES = ["一", "二", "三", "四", "五", "六", "日"]


class AlarmPage(QWidget):
    def __init__(self, host, service):
        super().__init__()
        self.host = host
        self.svc = service
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)

        tabs = QTabWidget()
        tabs.addTab(self._tab_alarm(), "闹钟")
        tabs.addTab(self._tab_timer(), "倒计时")
        tabs.addTab(self._tab_sw(), "秒表")
        v.addWidget(tabs, 1)

        self._ui_timer = QTimer(self)
        # 以前固定 50ms，等于每秒 20 次刷新（页面切走也照刷）。
        # 现在按「有没有在跑的东西 + 页面可不可见」自调：秒表 50ms、
        # 倒计时 100ms、什么都没跑就 1 秒，切到别的页直接停。
        self._ui_timer.setInterval(1000)
        self._ui_timer.timeout.connect(self._refresh)
        self._ui_timer.start()
        self.refresh_alarms()
        self.refresh_timers()

    # ========== 闹钟 ==========
    def _tab_alarm(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        row = QHBoxLayout()
        row.addWidget(QLabel("时间"))
        self.ed_time = QLineEdit("07:00:00.00")
        self.ed_time.setFixedWidth(150)
        self.ed_time.setToolTip("写法 时:分:秒.百分，例如 07:30:00.00；"
                                "秒可以带两位小数")
        row.addWidget(self.ed_time)
        row.addWidget(QLabel("名字"))
        self.ed_label = QLineEdit()
        self.ed_label.setPlaceholderText("比如 起床 / 喝口水 / 下矿")
        row.addWidget(self.ed_label, 1)
        v.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("重复"))
        self.days = {}
        for i, n in enumerate(_DAY_NAMES):
            cb = QCheckBox(n)
            self.days[i] = cb
            row2.addWidget(cb)
        row2.addWidget(QLabel("全不选＝只响一次；全选＝每天"))
        row2.addStretch(1)
        b_all = QPushButton("每天都响")
        b_all.setFixedWidth(92)
        b_all.clicked.connect(lambda: [cb.setChecked(True)
                                       for cb in self.days.values()])
        row2.addWidget(b_all)
        b_none = QPushButton("清空星期")
        b_none.setFixedWidth(92)
        b_none.clicked.connect(lambda: [cb.setChecked(False)
                                        for cb in self.days.values()])
        row2.addWidget(b_none)
        v.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("贪睡"))
        self.sp_snooze = QSpinBox()
        self.sp_snooze.setRange(1, 60)
        self.sp_snooze.setValue(5)
        self.sp_snooze.setSuffix(" 分钟")
        self.sp_snooze.setFixedWidth(110)
        row3.addWidget(self.sp_snooze)
        b_add = QPushButton("加一个闹钟")
        b_add.setObjectName("PrimaryButton")
        b_add.setFixedWidth(120)
        b_add.clicked.connect(self.add_alarm)
        row3.addWidget(b_add)
        row3.addStretch(1)
        v.addLayout(row3)

        self.lst = QListWidget()
        self.lst.setMinimumHeight(130)
        v.addWidget(self.lst, 1)

        row4 = QHBoxLayout()
        b_on = QPushButton("启用/停用")
        b_on.clicked.connect(self.toggle_alarm)
        row4.addWidget(b_on)
        b_del = QPushButton("删除")
        b_del.clicked.connect(self.del_alarm)
        row4.addWidget(b_del)
        b_test = QPushButton("试一下铃声")
        b_test.clicked.connect(self.test_ring)
        row4.addWidget(b_test)
        row4.addStretch(1)
        v.addLayout(row4)

        # 铃声
        row5 = QHBoxLayout()
        row5.addWidget(QLabel("铃声"))
        self.cb_ring = QComboBox()
        for key, label in _alarm.BUILTIN_RINGS:
            self.cb_ring.addItem(label, key)
        self.cb_ring.addItem("我导入的铃声", "custom")
        row5.addWidget(self.cb_ring, 1)
        b_imp = QPushButton("导入铃声")
        b_imp.setToolTip("支持 wav / mp3，导入后一直保存在本机")
        b_imp.clicked.connect(self.import_ring)
        row5.addWidget(b_imp)
        v.addLayout(row5)
        row6 = QHBoxLayout()
        row6.addWidget(QLabel("音量"))
        self.sp_vol = QSpinBox()
        self.sp_vol.setRange(0, 100)
        self.sp_vol.setValue(80)
        self.sp_vol.setSuffix(" %")
        self.sp_vol.setFixedWidth(96)
        self.sp_vol.valueChanged.connect(self._save_vol)
        row6.addWidget(self.sp_vol)
        self.lbl_ring_now = QLabel("")
        self.lbl_ring_now.setObjectName("FieldLabel")
        row6.addWidget(self.lbl_ring_now, 1)
        v.addLayout(row6)

        self._load_ring_state()
        return w

    def _load_ring_state(self):
        d = self.svc.data
        idx = self.cb_ring.findData(d.get("ring") or "Ding")
        if idx >= 0:
            self.cb_ring.setCurrentIndex(idx)
        self.cb_ring.currentIndexChanged.connect(self._save_ring)
        self.sp_vol.setValue(int(d.get("volume") or 80))
        self._show_ring_now()

    def _show_ring_now(self):
        from ui.alarm_service import ring_path
        p = ring_path(self.svc.data)
        self.lbl_ring_now.setText("当前铃声：%s" % (os.path.basename(p) or "系统提示音"))

    def _save_ring(self, _i=None):
        key = self.cb_ring.currentData()
        self.svc.data["ring"] = key
        _alarm.save(self.svc.data)
        self._show_ring_now()

    def _save_vol(self, v):
        self.svc.data["volume"] = int(v)
        _alarm.save(self.svc.data)

    def import_ring(self):
        path, _f = QFileDialog.getOpenFileName(
            self, "选一个铃声", "", "音频 (*.wav *.mp3 *.flac *.ogg *.m4a)")
        if not path:
            return
        dst_dir = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                               "rings")
        os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, os.path.basename(path))
        try:
            shutil.copy2(path, dst)
        except Exception as e:
            QMessageBox.warning(self, "导入失败", str(e))
            return
        self.svc.data["custom_ring"] = dst
        self.svc.data["ring"] = "custom"
        _alarm.save(self.svc.data)
        i = self.cb_ring.findData("custom")
        if i >= 0:
            self.cb_ring.setCurrentIndex(i)
        self._show_ring_now()
        QMessageBox.information(self, "已导入",
                                "铃声已保存：%s\n以后一直用它，除非你再换。"
                                % os.path.basename(dst))

    def test_ring(self):
        from ui.alarm_service import ring_path
        self.svc.player.set_volume(int(self.sp_vol.value()))
        self.svc.player.play(ring_path(self.svc.data))
        QTimer.singleShot(2600, self.svc.player.stop)

    def add_alarm(self):
        hms = _alarm.parse_clock(self.ed_time.text())
        if hms is None:
            QMessageBox.warning(self, "时间写法不对",
                                "照这个写：07:30:00.00（时:分:秒.百分）\n"
                                "也可以只写 07:30。")
            return
        h, m, s, frac = hms
        days = [i for i, cb in self.days.items() if cb.isChecked()]
        a = {"id": _alarm.new_id(self.svc.data), "hour": h, "minute": m,
             "second": s, "frac": frac,
             "label": (self.ed_label.text() or "").strip(),
             "days": days, "on": True,
             "snooze": int(self.sp_snooze.value())}
        self.svc.data.setdefault("alarms", []).append(a)
        _alarm.save(self.svc.data)
        self.ed_label.clear()
        self.refresh_alarms()
        nf = _alarm.next_fire(a)
        when = (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nf))
                if nf else "不会响")
        self.host._log("加了闹钟 %s，下次 %s" % (_alarm.fmt_hms(h, m, s, frac),
                                             when))

    def _sel_alarm(self):
        it = self.lst.currentItem()
        if not it:
            return None
        return it.data(Qt.UserRole)

    def toggle_alarm(self):
        a = self._sel_alarm()
        if not a:
            return
        a["on"] = not a.get("on", True)
        _alarm.save(self.svc.data)
        self.svc._last_fire.pop(int(a.get("id") or 0), None)
        self.refresh_alarms()

    def del_alarm(self):
        a = self._sel_alarm()
        if not a:
            return
        aid = int(a.get("id") or 0)
        self.svc.data["alarms"] = [x for x in self.svc.data.get("alarms") or []
                                   if int(x.get("id") or 0) != aid]
        self.svc._last_fire.pop(aid, None)
        _alarm.save(self.svc.data)
        self.refresh_alarms()

    def refresh_alarms(self):
        self.lst.clear()
        now = time.time()
        for a in self.svc.data.get("alarms") or []:
            nf = _alarm.next_fire(a, now)
            when = ""
            if nf:
                left = nf - now
                when = "还有 " + _alarm.fmt_clock(left) if left < 86400 else \
                    time.strftime("%m-%d %H:%M", time.localtime(nf))
            txt = "%s　%s　%s%s" % (
                _alarm.fmt_hms(a.get("hour", 0), a.get("minute", 0),
                               a.get("second", 0), a.get("frac", 0)),
                _alarm.day_text(a.get("days") or []),
                (a.get("label") or "闹钟"),
                "" if a.get("on", True) else "　（已停用）")
            if when:
                txt += "　·　" + when
            item = QListWidgetItem(txt)
            item.setData(Qt.UserRole, a)
            item.setToolTip(txt)
            # 宽度必须给足：给 0 的话列表会把文本区压成零宽，看起来像空白条目
            w = max(120, self.lst.viewport().width() - 16)
            item.setSizeHint(QSize(w, item.sizeHint().height() + 8))
            self.lst.addItem(item)

    # ========== 倒计时 ==========
    def _tab_timer(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)
        row = QHBoxLayout()
        row.addWidget(QLabel("时长"))
        self.ed_dur = QLineEdit("5:00.00")
        self.ed_dur.setFixedWidth(140)
        self.ed_dur.setToolTip("写法：秒（90.50）或 分:秒.百分（5:00.00）"
                               "或 时:分:秒.百分")
        row.addWidget(self.ed_dur)
        row.addWidget(QLabel("名字"))
        self.ed_tlabel = QLineEdit()
        self.ed_tlabel.setPlaceholderText("比如 泡面 / 洗澡")
        row.addWidget(self.ed_tlabel, 1)
        b = QPushButton("开始")
        b.setObjectName("PrimaryButton")
        b.setFixedWidth(84)
        b.clicked.connect(self.add_timer)
        row.addWidget(b)
        v.addLayout(row)

        self.tlst = QListWidget()
        self.tlst.setMinimumHeight(140)
        v.addWidget(self.tlst, 1)

        row2 = QHBoxLayout()
        for text, slot in (("暂停", self.pause_timer), ("继续", self.resume_timer),
                           ("删除", self.del_timer)):
            bb = QPushButton(text)
            bb.setFixedWidth(84)
            bb.clicked.connect(slot)
            row2.addWidget(bb)
        row2.addStretch(1)
        self.lbl_dur_now = QLabel("")
        self.lbl_dur_now.setObjectName("FieldLabel")
        row2.addWidget(self.lbl_dur_now)
        v.addLayout(row2)
        return w

    def add_timer(self):
        sec = _alarm.parse_hms(self.ed_dur.text())
        if not sec or sec <= 0:
            QMessageBox.warning(self, "时长写法不对",
                                "照这个写：5:00.00（分:秒.百分），或直接写 90.5。")
            return
        self.svc.add_timer(sec, (self.ed_tlabel.text() or "").strip())
        self.refresh_timers()

    def _sel_timer(self):
        it = self.tlst.currentItem()
        return it.data(Qt.UserRole) if it else None

    def pause_timer(self):
        t = self._sel_timer()
        if t:
            self.svc.pause_timer(t["id"])
            self.refresh_timers()

    def resume_timer(self):
        t = self._sel_timer()
        if t:
            self.svc.resume_timer(t["id"])
            self.refresh_timers()

    def del_timer(self):
        t = self._sel_timer()
        if t:
            self.svc.del_timer(t["id"])
            self.refresh_timers()

    def refresh_timers(self):
        cur = self.tlst.currentRow()
        self.tlst.clear()
        for t in self.svc.data.get("timers") or []:
            left = self.svc.timer_left(t["id"])
            item = QListWidgetItem("%s　剩余 %s%s" % (
                (t.get("label") or "计时器"),
                _alarm.fmt_clock(left),
                "" if t.get("running") else "（暂停）"))
            item.setData(Qt.UserRole, t)
            self.tlst.addItem(item)
        if cur >= 0 and cur < self.tlst.count():
            self.tlst.setCurrentRow(cur)

    # ========== 秒表 ==========
    def _tab_sw(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)
        self.lbl_sw = QLabel("00:00.00")
        self.lbl_sw.setStyleSheet("font-size:30px;font-weight:700;")
        v.addWidget(self.lbl_sw)
        row = QHBoxLayout()
        self.b_start = QPushButton("开始")
        self.b_start.setObjectName("PrimaryButton")
        self.b_start.setFixedWidth(96)
        self.b_start.clicked.connect(self.sw_toggle)
        row.addWidget(self.b_start)
        b_lap = QPushButton("计次")
        b_lap.setFixedWidth(96)
        b_lap.clicked.connect(self.sw_lap)
        row.addWidget(b_lap)
        b_reset = QPushButton("归零")
        b_reset.setFixedWidth(96)
        b_reset.clicked.connect(self.sw_reset)
        row.addWidget(b_reset)
        row.addStretch(1)
        v.addLayout(row)
        self.lst_lap = QListWidget()
        v.addWidget(self.lst_lap, 1)
        return w

    def sw_toggle(self):
        on = self.svc.sw_toggle()
        self.b_start.setText("暂停" if on else "开始")

    def sw_lap(self):
        val = self.svc.sw_lap()
        laps = self.svc.laps()
        prev = laps[-2] if len(laps) > 1 else 0.0
        self.lst_lap.insertItem(0, "第 %d 次　%s（本段 %s）" % (
            len(laps), _alarm.fmt_clock(val), _alarm.fmt_clock(val - prev)))

    def sw_reset(self):
        self.svc.sw_reset()
        self.lst_lap.clear()
        self.b_start.setText("开始")
        self.lbl_sw.setText("00:00.00")

    # ========== 刷新 ==========
    def _adapt_interval(self):
        """按当前负载调刷新频率，空闲时不烧 CPU。"""
        try:
            running = any((t or {}).get("running")
                          for t in (self.svc.data.get("timers") or []))
            sw = bool(getattr(self.svc, "_sw_on", False))
        except Exception:
            running, sw = False, False
        if not self.isVisible():
            want = 1000
        elif sw:
            want = 50
        elif running:
            want = 100
        else:
            want = 1000
        if self._ui_timer.interval() != want:
            self._ui_timer.setInterval(want)

    def showEvent(self, e):
        super().showEvent(e)
        self._adapt_interval()
        self._refresh()
        if not self._ui_timer.isActive():
            self._ui_timer.start()

    def hideEvent(self, e):
        self._ui_timer.stop()
        super().hideEvent(e)

    def _refresh(self):
        self._adapt_interval()
        if self.isVisible():
            self.lbl_sw.setText(_alarm.fmt_clock(self.svc.stopwatch()))
        # 倒计时剩余：只更新文本，不重建列表（避免每 50ms 抢选中）
        for i in range(self.tlst.count()):
            t = self.tlst.item(i).data(Qt.UserRole)
            if not t or not t.get("running"):
                continue
            self.tlst.item(i).setText("%s　剩余 %s" % (
                (t.get("label") or "计时器"),
                _alarm.fmt_clock(self.svc.timer_left(t["id"])))
            )
