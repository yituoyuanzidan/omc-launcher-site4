# -*- coding: utf-8 -*-
"""播放器差异封装：同一套代码在 Qt6(PySide6) 与 Qt5(PySide2) 上都能用。

Qt6 把音量/静音拆到了独立的 QAudioOutput 对象上，Qt5 直接挂在 QMediaPlayer；
Qt6 用 setSource()，Qt5 用 setMedia()。注意 Qt5 也有个同名的 QAudioOutput，
但那是「音频输出设备」，和 Qt6 那个只是名字撞车，所以判定要认 setSource 而不是认导入成不成功。
"""
try:
    # Qt6 里 QMediaContent 已经没了（换成 QUrl），只导 QMediaPlayer，
    # 否则整块多媒体会被误判成「不可用」，预告片和音乐全哑。
    from PySide6.QtMultimedia import QMediaPlayer
    IMPORT_ERROR = ""
    HAS_MEDIA = True
except Exception as _e:                     # 包被精简掉多媒体时降级
    QMediaPlayer = None
    HAS_MEDIA = False
    IMPORT_ERROR = "%s: %s" % (type(_e).__name__, _e)

#: True = Qt6 那套（QAudioOutput 管音量）；False = Qt5 那套（QMediaPlayer 自己管）
QT6_MEDIA = bool(HAS_MEDIA and hasattr(QMediaPlayer, "setSource"))

_MEDIA_CONTENT = None


def _media_content_cls():
    """QMediaContent 只有 Qt5 有，用到时再去拿；Qt6 下返回 None。"""
    global _MEDIA_CONTENT
    if _MEDIA_CONTENT is not None:
        return _MEDIA_CONTENT
    for mod in ("PySide2.QtMultimedia", "PySide6.QtMultimedia"):
        try:
            m = __import__(mod, fromlist=["QMediaContent"])
        except Exception:
            continue
        cls = getattr(m, "QMediaContent", None)
        if cls is not None:
            _MEDIA_CONTENT = cls
            break
    return _MEDIA_CONTENT


def make_player(parent=None):
    if not HAS_MEDIA:
        return None
    return QMediaPlayer(parent) if parent is not None else QMediaPlayer()


def make_audio(player, parent=None, volume=0.6):
    """Qt6 返回 QAudioOutput；Qt5 返回 None（音量已设到播放器上）。"""
    if not HAS_MEDIA or player is None:
        return None
    v = max(0.0, min(1.0, float(volume)))
    if QT6_MEDIA:
        from PySide6.QtMultimedia import QAudioOutput
        out = QAudioOutput(parent) if parent is not None else QAudioOutput()
        out.setVolume(v)
        player.setAudioOutput(out)
        return out
    try:
        player.setVolume(int(round(v * 100)))
    except Exception:
        pass
    return None


def set_source(player, url):
    if player is None:
        return
    if QT6_MEDIA:
        player.setSource(url)
        return
    cls = _media_content_cls()
    try:
        player.setMedia(cls(url) if cls is not None else None)
    except Exception:
        pass


def infinite_loops():
    return getattr(QMediaPlayer, "Infinite", -1)


def set_loops(player, loops):
    if player is None:
        return
    try:
        player.setLoops(int(loops))
    except Exception:
        pass


def set_volume(player, audio, v01):
    v = max(0.0, min(1.0, float(v01)))
    if audio is not None:
        audio.setVolume(v)
    elif player is not None:
        try:
            player.setVolume(int(round(v * 100)))
        except Exception:
            pass


def set_muted(player, audio, muted):
    if audio is not None:
        audio.setMuted(bool(muted))
    elif player is not None:
        try:
            player.setMuted(bool(muted))
        except Exception:
            pass


def is_muted(player, audio):
    try:
        if audio is not None:
            return bool(audio.isMuted())
        if player is not None:
            return bool(player.isMuted())
    except Exception:
        pass
    return False


def connect_state(player, slot):
    """Qt6 叫 playbackStateChanged，Qt5 叫 stateChanged。"""
    if player is None:
        return
    for name in ("playbackStateChanged", "stateChanged"):
        sig = getattr(player, name, None)
        if sig is None:
            continue
        try:
            sig.connect(slot)
            return
        except Exception:
            continue


def connect_error(player, slot):
    """Qt6 叫 errorOccurred，Qt5 叫 error。"""
    if player is None:
        return
    for name in ("errorOccurred", "error"):
        sig = getattr(player, name, None)
        if sig is None:
            continue
        try:
            sig.connect(slot)
            return
        except Exception:
            continue


def playing_state():
    return getattr(QMediaPlayer, "PlayingState", 1)


def end_of_media():
    return getattr(QMediaPlayer, "EndOfMedia", 7)
