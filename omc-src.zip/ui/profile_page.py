# -*- coding: utf-8 -*-
"""主页：看自己、看别人。

自己这半边是本地数据（简介、游戏时长、好友数、启动器在线时长），
别人那半边靠对方发布的消息（core.profile），对方没发布/把某项隐藏了，
这里就显示「对方没公开」——不编数字。
"""
import time

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QVBoxLayout, QWidget,
)

from core import accounts, friendbook, profile


class _ProfileFetch(QThread):
    done = Signal(object)

    def __init__(self, name):
        super().__init__()
        self.name = name

    def run(self):
        try:
            self.done.emit(profile.fetch(self.name))
        except Exception as e:
            self.done.emit({"__err": str(e)})


class ProfilePage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = host.config
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        title = QLabel("主页")
        title.setObjectName("PageTitle")
        v.addWidget(title)
        sub = QLabel("自己的资料在左边，看别人的在右边。别人那半边靠对方自己发布，"
                     "没发布或隐藏了就看不到。")
        sub.setObjectName("PageSub")
        sub.setWordWrap(True)
        v.addWidget(sub)

        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(self._scroll(self._me_card()), 1)
        row.addWidget(self._scroll(self._other_card()), 1)
        v.addLayout(row, 1)
        self._fetch = None
        self._refresh_me()

    def _scroll(self, w):
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(w)
        return sa

    # ---------- 自己 ----------
    def _me_card(self):
        w = QWidget()
        w.setObjectName("Card")
        v = QVBoxLayout(w)
        v.setSpacing(10)
        head = QLabel("我的主页")
        head.setObjectName("FieldLabel")
        f = head.font()
        f.setBold(True)
        head.setFont(f)
        v.addWidget(head)

        row = QHBoxLayout()
        self.lab_me_avatar = QLabel()
        self.lab_me_avatar.setFixedSize(88, 88)
        self.lab_me_avatar.setAlignment(Qt.AlignCenter)
        self.lab_me_avatar.setObjectName("AvatarPreview")
        row.addWidget(self.lab_me_avatar)
        col = QVBoxLayout()
        self.lab_me_name = QLabel("—")
        nf = self.lab_me_name.font()
        nf.setPointSize(13)
        nf.setBold(True)
        self.lab_me_name.setFont(nf)
        col.addWidget(self.lab_me_name)
        self.lab_me_bio = QLabel("")
        self.lab_me_bio.setWordWrap(True)
        self.lab_me_bio.setObjectName("FieldLabel")
        col.addWidget(self.lab_me_bio)
        row.addLayout(col, 1)
        v.addLayout(row)

        self.lab_me_stats = QLabel("")
        self.lab_me_stats.setWordWrap(True)
        v.addWidget(self.lab_me_stats)
        self.lab_me_hide = QLabel("")
        self.lab_me_hide.setWordWrap(True)
        self.lab_me_hide.setObjectName("FieldLabel")
        v.addWidget(self.lab_me_hide)

        br = QHBoxLayout()
        b_edit = QPushButton("改简介 / 改头像")
        b_edit.clicked.connect(self.host._goto_personalize)
        br.addWidget(b_edit)
        b_ref = QPushButton("刷新")
        b_ref.clicked.connect(self._refresh_me)
        br.addWidget(b_ref)
        b_pub = QPushButton("发布到主页")
        b_pub.setObjectName("PrimaryButton")
        b_pub.clicked.connect(self._publish_me)
        br.addWidget(b_pub)
        br.addStretch(1)
        v.addLayout(br)
        self.lab_me_tip = QLabel("")
        self.lab_me_tip.setWordWrap(True)
        self.lab_me_tip.setObjectName("FieldLabel")
        v.addWidget(self.lab_me_tip)
        v.addStretch(1)
        return w

    def _my_name(self):
        try:
            return accounts.current_name() or ""
        except Exception:
            return ""

    def _refresh_me(self):
        name = self._my_name()
        self.lab_me_name.setText(name or "未登录（去「账号」页登录一个）")
        bio = (self.cfg.get("profile_bio") or "").strip()
        self.lab_me_bio.setText(bio or "还没写简介。点下面的按钮写一个。")
        play = int(self.cfg.get("play_minutes") or 0)
        online = int(self.cfg.get("online_minutes") or 0)
        fr = friendbook.count()
        self.lab_me_stats.setText(
            "游戏时长：%s\n好友数量：%d 人\n启动器在线时长：%s\n"
            % (profile.fmt_minutes(play), fr, profile.fmt_minutes(online)))
        hide = self.cfg.get("profile_hide") or {}
        hidden = [profile.FIELD_LABELS.get(k, k) for k, v in hide.items() if v]
        self.lab_me_hide.setText(
            ("主页隐藏：" + "、".join(hidden)) if hidden
            else "主页隐藏：无（全部公开）")
        try:
            if name:
                self.lab_me_avatar.setPixmap(self.host._avatar_icon(name).pixmap(88, 88))
            else:
                self.lab_me_avatar.setText("—")
        except Exception:
            self.lab_me_avatar.setText("—")

    def _publish_me(self):
        ok = self.host._publish_profile(force=True)
        self.lab_me_tip.setText("已发布到主页。" if ok else "发布失败，检查一下网络。")
        self._refresh_me()

    # ---------- 别人 ----------
    def _other_card(self):
        w = QWidget()
        w.setObjectName("Card")
        v = QVBoxLayout(w)
        v.setSpacing(10)
        head = QLabel("看别人的主页")
        head.setObjectName("FieldLabel")
        f = head.font()
        f.setBold(True)
        head.setFont(f)
        v.addWidget(head)

        row = QHBoxLayout()
        self.combo_peer = QComboBox()
        self.combo_peer.setMinimumWidth(140)
        row.addWidget(self.combo_peer, 1)
        b_pick = QPushButton("刷新好友")
        b_pick.clicked.connect(self._load_peers)
        row.addWidget(b_pick)
        v.addLayout(row)

        row2 = QHBoxLayout()
        self.input_peer = QLineEdit()
        self.input_peer.setPlaceholderText("也可以直接输账号名")
        self.input_peer.returnPressed.connect(self._load_peer)
        row2.addWidget(self.input_peer, 1)
        b_load = QPushButton("看他的主页")
        b_load.setObjectName("PrimaryButton")
        b_load.clicked.connect(self._load_peer)
        row2.addWidget(b_load)
        v.addLayout(row2)

        self.lab_peer = QLabel("选一个好友，或者直接输名字。")
        self.lab_peer.setWordWrap(True)
        self.lab_peer.setTextFormat(Qt.RichText)
        self.lab_peer.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.lab_peer.setMinimumHeight(200)
        v.addWidget(self.lab_peer, 1)

        br = QHBoxLayout()
        b_rep = QPushButton("举报这个人的名字")
        b_rep.setToolTip("名字命中违禁词才会被强制改成「未命名（编号）」")
        b_rep.clicked.connect(self._report_name)
        br.addWidget(b_rep)
        br.addStretch(1)
        v.addLayout(br)
        self._load_peers()
        return w

    def _load_peers(self):
        try:
            rows = friendbook.items()
        except Exception:
            rows = []
        self.combo_peer.clear()
        self.combo_peer.addItem("（选一个好友）", "")
        for it in rows:
            nm = it.get("name") or it.get("alias") or ""
            if nm:
                self.combo_peer.addItem(nm, nm)
        self.combo_peer.currentIndexChanged.connect(
            lambda _i: self.input_peer.setText(self.combo_peer.currentData() or ""))

    def _load_peer(self):
        name = (self.input_peer.text() or "").strip()
        if not name:
            self.lab_peer.setText("先选或先填一个名字。")
            return
        if self._fetch is not None and self._fetch.isRunning():
            return
        self.lab_peer.setText("正在拉 %s 的主页…" % name)
        self._fetch = _ProfileFetch(name)
        self._fetch.done.connect(lambda d: self._show_peer(name, d))
        self._fetch.start()

    def _show_peer(self, name, data):
        if not data:
            self.lab_peer.setText(
                "<b>%s</b><br>没拉到主页：对方可能没登录 1.7.64 的启动器，"
                "或者根本没点过「发布到主页」。" % name)
            return
        if data.get("__err"):
            self.lab_peer.setText("拉取失败：%s" % data["__err"])
            return
        hide = data.get("hide") or {}
        ts = int(data.get("ts") or 0)
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts)) if ts else "—"
        lines = ["<div style='font-size:14px'><b>%s</b>　"
                 "<span style='color:#9AA3AE'>更新于 %s</span></div>" % (name, when)]
        bio = data.get("bio")
        lines.append("<div>简介：%s</div>" % (
            bio if bio else ("对方没公开" if hide.get("bio") else "还没写")))
        if "play" in data:
            lines.append("<div>游戏时长：%s</div>" % profile.fmt_minutes(data.get("play")))
        else:
            lines.append("<div>游戏时长：对方没公开</div>")
        if "fr" in data:
            lines.append("<div>好友数量：%d 人</div>" % int(data.get("fr") or 0))
        else:
            lines.append("<div>好友数量：对方没公开</div>")
        if "on" in data:
            lines.append("<div>启动器在线时长：%s</div>" % profile.fmt_minutes(data.get("on")))
        else:
            lines.append("<div>启动器在线时长：对方没公开</div>")
        fresh = ts and (time.time() - ts) < 30 * 60
        lines.append("<div style='margin-top:6px;color:%s'>%s</div>"
                     % ("#7CD07C" if fresh else "#9AA3AE",
                        "现在在线（30 分钟内有动静）" if fresh else "当前不在线"))
        self.lab_peer.setText("".join(lines))

    def _report_name(self):
        name = (self.input_peer.text() or "").strip()
        if not name:
            self.lab_peer.setText("先选一个要举报的人。")
            return
        try:
            from core import moderation
            from PySide6.QtWidgets import QInputDialog
            reason, ok = QInputDialog.getText(self, "举报名字",
                                              "这个人的名字哪里有问题？（可以不写）")
            if not ok:
                return
            me = self._my_name()
            ok2, msg = moderation.report(me, name, reason)
            self.lab_peer.setText(("已举报：%s" if ok2 else "举报失败：%s") % msg)
        except Exception as e:
            self.lab_peer.setText("举报失败：%s" % e)
