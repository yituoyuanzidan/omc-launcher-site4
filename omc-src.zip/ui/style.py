# -*- coding: utf-8 -*-
"""现代扁平风格 QSS。

深色为主，另一套浅色由 qss() 现推出来。
面板底色一律用不透明的深色（以前是半透明白，壁纸一透出来字就看不清了）。

qss() 支持两个可选项，都从设置页传进来：
  accent —— 主色，决定主按钮、选中项、进度条、焦点边框的颜色
  btn    —— 按键样式：round（圆角）/ square（方块）/ pill（胶囊）/ outline（描边）
"""
import os
import re

from core import platform_utils

_FONT = platform_utils.font_family()
_MONO = platform_utils.mono_family()

# Qt 5（Win7 老系统分支）的 QSS 对 ::down-arrow 只认图片，不认 border 画三角，
# 照搬 Qt 6 那套会渲染成一个空白方块，所以老内核包直接用系统默认箭头。
_QT5 = os.environ.get("OMC_QT5") == "1"
_RE_DOWN_ARROW = re.compile(r"QComboBox::down-arrow \{[^}]*\}")

# 主色可选值：(配置里存的值, 名字, 颜色)
ACCENTS = (
    ("blue", "蓝", "#4C8DFF"),
    ("green", "绿", "#3ED598"),
    ("violet", "紫", "#A78BFA"),
    ("orange", "橙", "#FF8A47"),
    ("pink", "粉", "#F472B6"),
    ("gold", "金", "#FFC53D"),
)
ACCENT_MAP = dict((k, v) for k, _n, v in ACCENTS)

# 按键样式：(配置里存的值, 名字)
BUTTON_STYLES = (
    ("round", "圆角"),
    ("square", "方块"),
    ("pill", "胶囊"),
    ("outline", "描边"),
)

QSS_T = """
* {
    color: #E6E8EC;
    outline: none;
}

QWidget { background: transparent; }

#Root { background: #1E2128; }
#Sidebar { background: #14161C; border: none; }
#Brand { font-size: 18px; font-weight: 700; color: #FFFFFF; }
#BrandSub { font-size: 12px; color: #7C828D; }

#Content { background: #1B1F27; }
#PageTitle { font-size: 24px; font-weight: 700; color: #FFFFFF; }
#PageSub { font-size: 13px; color: #9AA0AB; }

#VersionRail {
    background: #1A1D24;
    border: 1px solid rgba(255, 255, 255, 26);
    border-radius: 14px;
}

#Card {
    background: #232730;
    border: 1px solid rgba(255, 255, 255, 26);
    border-radius: 14px;
}
#PlayPanel {
    background: rgba(20, 24, 31, 184);
    border: 1px solid rgba(255, 255, 255, 20);
    border-radius: 14px;
}
#FieldLabel { font-size: 13px; color: #9AA0AB; }

QLineEdit, QComboBox {
    background: #20242C;
    border: 1px solid rgba(255, 255, 255, 34);
    border-radius: 9px;
    padding: 8px 12px;
    selection-background-color: %(accent)s;
}
QLineEdit:focus, QComboBox:focus { border: 1px solid %(accent)s; }
QComboBox::drop-down { border: none; width: 26px; }
QComboBox::down-arrow {
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid #9AA0AB;
    margin-right: 10px;
}
QComboBox QAbstractItemView {
    background: #1C2029;
    border: 1px solid rgba(255, 255, 255, 34);
    border-radius: 8px;
    padding: 6px;
    selection-background-color: %(accent_soft)s;
}

QSpinBox, QDoubleSpinBox {
    background: #20242C;
    border: 1px solid rgba(255, 255, 255, 34);
    border-radius: 9px;
    padding: 6px 8px;
}
QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid %(accent)s; }

QPushButton#NavButton {
    background: transparent;
    border: none;
    border-radius: 10px;
    padding: 11px 14px;
    text-align: left;
    color: #B8BCC4;
}
QPushButton#NavButton:hover { background: rgba(255, 255, 255, 16); }
QPushButton#NavButton:checked {
    background: %(accent_soft)s;
    color: #FFFFFF;
}

QPushButton {
    background: #2B303A;
    border: 1px solid rgba(255, 255, 255, 22);
    border-radius: %(btn_radius)s;
    padding: 9px 16px;
    color: #E6E8EC;
}
QPushButton:hover { background: #343A46; }
QPushButton:pressed { background: #242932; }
QPushButton:disabled { color: #7C828D; background: #20242C; }

QPushButton#PrimaryButton {
    background: %(accent)s;
    color: #FFFDFA;
    font-size: 16px;
    font-weight: 700;
    border: none;
    border-radius: %(btn_radius_big)s;
    padding: 14px;
}
QPushButton#PrimaryButton:hover { background: %(accent_hi)s; }
QPushButton#PrimaryButton:pressed { background: %(accent_lo)s; }
QPushButton#PrimaryButton:disabled { background: #242932; color: #7C828D; }

QListWidget, QTableWidget, QTreeWidget {
    background: #1A1D24;
    border: 1px solid rgba(255, 255, 255, 24);
    border-radius: 10px;
    padding: 4px;
}
QListWidget::item { padding: 4px; border-radius: 8px; }
QListWidget::item:hover { background: rgba(255, 255, 255, 18); }
QListWidget::item:selected { background: %(accent_soft)s; color: #FFFFFF; }
QTreeWidget::item:hover { background: rgba(255, 255, 255, 14); }
QTreeWidget::item:selected { background: %(accent_soft)s; color: #FFFFFF; }
QHeaderView::section {
    background: #20242C;
    color: #9AA0AB;
    border: none;
    padding: 5px;
}

QTabWidget::pane {
    background: #1A1D24;
    border: 1px solid rgba(255, 255, 255, 24);
    border-radius: 10px;
}
QTabBar::tab {
    background: #20242C;
    border: 1px solid rgba(255, 255, 255, 20);
    border-radius: 8px;
    padding: 7px 16px;
    margin-right: 6px;
    color: #B8BCC4;
}
QTabBar::tab:selected { background: %(accent)s; color: #FFFFFF; }
QTabBar::tab:hover { background: #2B303A; }

QProgressBar {
    background: #1A1D24;
    border: 1px solid rgba(255, 255, 255, 24);
    border-radius: 8px;
    height: 14px;
    text-align: center;
    font-size: 11px;
    color: #C9CDD4;
}
QProgressBar::chunk { background: %(accent)s; border-radius: 7px; }

QSlider::groove:horizontal {
    height: 6px;
    background: #1A1D24;
    border-radius: 3px;
}
QSlider::sub-page:horizontal { background: %(accent)s; border-radius: 3px; }
QSlider::handle:horizontal {
    background: #FFFFFF;
    width: 16px;
    height: 16px;
    margin: -6px 0;
    border-radius: 8px;
}

QTextEdit {
    background: #15181E;
    border: 1px solid rgba(255, 255, 255, 24);
    border-radius: 10px;
    padding: 8px;
    font-family: %(mono)s;
    font-size: 12px;
    color: #9AA0AB;
}

QRadioButton { spacing: 8px; color: #C9CDD4; }
QRadioButton::indicator {
    width: 16px; height: 16px;
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 60);
    background: #20242C;
}
QRadioButton::indicator:checked {
    border: 4px solid %(accent)s;
}

QCheckBox { spacing: 8px; color: #C9CDD4; }

QScrollArea { border: none; background: transparent; }
QScrollArea > QWidget > QWidget { background: transparent; }
QAbstractScrollArea::viewport { background: #1A1D24; }

QScrollBar:vertical {
    background: #1A1D24;
    width: 10px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: rgba(255, 255, 255, 46);
    border-radius: 4px;
    min-height: 28px;
}
QScrollBar::handle:vertical:hover { background: rgba(255, 255, 255, 72); }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: #1A1D24; }

QScrollBar:horizontal {
    background: #1A1D24;
    height: 10px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background: rgba(255, 255, 255, 46);
    border-radius: 4px;
    min-width: 28px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: #1A1D24; }

#SeedBanner {
    border: 1px solid rgba(255, 255, 255, 30);
    background: #12202E;
}
#SeedLegend {
    background: #1A1D24;
    border: 1px solid rgba(255, 255, 255, 24);
    border-radius: 8px;
    padding: 4px;
}

QToolTip {
    background: #1C2029;
    color: #E6E8EC;
    border: 1px solid rgba(255, 255, 255, 34);
    border-radius: 6px;
    padding: 6px;
}

QMenu {
    background: #1C2029;
    border: 1px solid rgba(255, 255, 255, 34);
    border-radius: 8px;
    padding: 6px;
}
QMenu::item { padding: 7px 18px; border-radius: 6px; }
QMenu::item:selected { background: %(accent_soft)s; }
"""

# 描边样式：按键改成透明底 + 主色描边
_BTN_OUTLINE = """
QPushButton {
    background: transparent;
    border: 1px solid %(accent)s;
    color: %(accent)s;
}
QPushButton:hover { background: %(accent_faint)s; }
QPushButton:pressed { background: %(accent_soft)s; }
QPushButton:disabled { border-color: #3A404B; color: #7C828D; background: transparent; }
"""

# 深色主题：面板/卡片/列表/输入框一律改成半透明深色（「深色玻璃」），
# 让窗口底下那张壁纸（Backdrop 画的）透出来一点点。弹窗类控件
# （QMenu / 下拉列表 / tooltip）是独立窗口，底下没有壁纸，必须保持实色，
# 所以它们用的是单独的 #1C2029，不在这张表里。
_GLASS_MAP = (
    ("#1B1F27", "rgba(24, 28, 34, 0.87)"),     # Content 主区
    ("#14161C", "rgba(15, 17, 22, 0.90)"),     # Sidebar
    ("#232730", "rgba(30, 34, 42, 0.82)"),     # Card / 卡片
    ("#20242C", "rgba(28, 32, 40, 0.86)"),     # 输入框 / 页签 / 表头
    ("#1A1D24", "rgba(20, 23, 29, 0.82)"),     # 列表 / 进度槽 / 滑槽 / 滚动条
    ("#15181E", "rgba(17, 20, 25, 0.85)"),     # 日志框
    ("#2B303A", "rgba(40, 45, 55, 0.86)"),     # 普通按钮
    ("#343A46", "rgba(52, 58, 70, 0.90)"),     # 按钮 hover
    ("#242932", "rgba(34, 39, 48, 0.86)"),     # 按钮按下 / 禁用
    ("#12202E", "rgba(18, 30, 44, 0.85)"),     # 种子横幅
    ("#3A404B", "rgba(58, 64, 75, 0.78)"),     # 描边按钮禁用边框
)

# 浅色主题只是换配色，布局不动。
# 注意面板色别用纯 #FFFFFF：后面还会把 #FFFFFF 当文字色改成深色。
_LIGHT_MAP = (
    ("#1E2128", "#F4F6FA"),
    ("#1B1F27", "#F4F6FA"),
    ("#14161C", "#F8FAFC"),
    ("#232730", "#FDFEFF"),
    ("#1C2029", "#FDFEFF"),
    ("#20242C", "#F1F4F9"),
    ("#1A1D24", "#EDF0F5"),
    ("#15181E", "#E8ECF2"),
    ("#2B303A", "#E4E8EE"),
    ("#343A46", "#D9DEE6"),
    ("#242932", "#DDE2E9"),
    ("#12202E", "#DDE5EE"),
    ("#3A404B", "#C7CDD6"),
)

_TEXT_LIGHT = (
    ("#FFFFFF", "#1B1F26"),
    ("#E6E8EC", "#22262E"),
    ("#B8BCC4", "#5A616B"),
    ("#C9CDD4", "#4A515B"),
    ("#9AA0AB", "#6B727C"),
    ("#7C828D", "#8A909A"),
)

# 暗夜：还是深色那套结构，但底更黑、更不透明，晚上看着不刺眼
_NIGHT_MAP = (
    ("#1E2128", "#0B0D11"),
    ("#1B1F27", "rgba(8, 10, 14, 0.94)"),
    ("#14161C", "rgba(5, 7, 10, 0.96)"),
    ("#232730", "rgba(14, 17, 23, 0.92)"),
    ("#1C2029", "#0A0C10"),
    ("#20242C", "rgba(11, 14, 19, 0.94)"),
    ("#1A1D24", "rgba(8, 10, 15, 0.92)"),
    ("#15181E", "rgba(7, 9, 13, 0.94)"),
    ("#2B303A", "rgba(22, 26, 34, 0.94)"),
    ("#343A46", "rgba(32, 37, 48, 0.96)"),
    ("#242932", "rgba(18, 22, 29, 0.94)"),
    ("#12202E", "rgba(10, 18, 30, 0.94)"),
    ("#3A404B", "rgba(40, 46, 58, 0.86)"),
)

# 樱花：浅粉底，配粉色强调色
_SAKURA_MAP = (
    ("#1E2128", "#FFF7FA"),
    ("#1B1F27", "#FFF7FA"),
    ("#14161C", "#FFF9FB"),
    ("#232730", "#FFFFFF"),
    ("#1C2029", "#FFFFFF"),
    ("#20242C", "#FDEEF4"),
    ("#1A1D24", "#F9E7EF"),
    ("#15181E", "#F6E2EA"),
    ("#2B303A", "#F7E3EC"),
    ("#343A46", "#F1D7E3"),
    ("#242932", "#F4DCE6"),
    ("#12202E", "#F7E7EF"),
    ("#3A404B", "#E3CBD6"),
)


def _hex_of(rgb):
    return "#%02X%02X%02X" % tuple(rgb)


def _mix(color, target, ratio):
    """把 color 朝 target 混 ratio（0~1）。"""
    c = color.lstrip("#")
    t = target.lstrip("#")
    rgb = [int(c[i:i + 2], 16) for i in (0, 2, 4)]
    tg = [int(t[i:i + 2], 16) for i in (0, 2, 4)]
    return _hex_of([int(rgb[i] + (tg[i] - rgb[i]) * ratio) for i in range(3)])


def _rgba_of(color, alpha):
    c = color.lstrip("#")
    return "rgba(%d, %d, %d, %d)" % (int(c[0:2], 16), int(c[2:4], 16),
                                     int(c[4:6], 16), alpha)


def _glass_out(s):
    """深色主题下把实色面板换成半透明深色（顺序从浅到深无所谓，六位 hex 不重叠）。"""
    for a, b in _GLASS_MAP:
        s = s.replace(a, b)
    return s


def qss(theme="dark", accent="", btn=""):
    """返回对应主题的样式表。

    theme: dark（默认深色半透）/ night（暗夜，更黑）/ light（浅色）/
    sakura（樱花，浅粉）。accent 可以是配置里存的代号（blue/green/...），
    也可以直接给 #RRGGBB。
    """
    theme_l = (theme or "dark").lower()
    if theme_l == "sakura" and not accent:
        accent = "pink"
    color = ACCENT_MAP.get(accent or "blue", accent or ACCENT_MAP["blue"])
    if not color.startswith("#"):
        color = ACCENT_MAP["blue"]
    btn = btn or "round"
    radius = {"square": "3px", "pill": "18px"}.get(btn, "9px")
    radius_big = {"square": "4px", "pill": "26px"}.get(btn, "12px")

    s = QSS_T % {
        "font": _FONT,
        "mono": _MONO,
        "accent": color,
        "accent_hi": _mix(color, "#FFFFFF", 0.14),
        "accent_lo": _mix(color, "#000000", 0.12),
        "accent_soft": _rgba_of(color, 130),
        "accent_faint": _rgba_of(color, 40),
        "btn_radius": radius,
        "btn_radius_big": radius_big,
    }
    if _QT5:
        s = _RE_DOWN_ARROW.sub("", s)
    if btn == "outline":
        s += _BTN_OUTLINE % {"accent": color,
                             "accent_soft": _rgba_of(color, 130),
                             "accent_faint": _rgba_of(color, 40)}

    if theme_l == "night":
        # 暗夜：在深色基础上再压一层更黑的底，不额外加任何透明装饰
        for a, b in _NIGHT_MAP:
            s = s.replace(a, b)
        return s

    if theme_l == "sakura":
        # 樱花：浅粉底 + 粉色主色，文字色跟浅色主题同一套（深字）
        for a, b in _SAKURA_MAP:
            s = s.replace(a, b)
        s = _light_lines(s)
        for a, b in _TEXT_LIGHT:
            s = s.replace(a, b)
        return s

    if theme_l != "light":
        return _glass_out(s)

    for a, b in _LIGHT_MAP:
        s = s.replace(a, b)
    # 半透明白线在浅底上要反过来压深
    s = _light_lines(s)
    for a, b in _TEXT_LIGHT:
        s = s.replace(a, b)
    return s


def _light_lines(s):
    """浅色主题里，白色半透的装饰线/悬停底反过来用黑色。"""
    import re
    return re.sub(r"rgba\(255, 255, 255, (\d+)\)",
                  lambda m: "rgba(0, 0, 0, %d)"
                  % int(round(int(m.group(1)) * 0.8)), s)
