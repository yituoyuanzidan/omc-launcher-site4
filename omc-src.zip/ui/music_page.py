# -*- coding: utf-8 -*-
"""音乐页：本地歌单 + 在线搜歌（试听），跟启动器其它页同一套 Qt multimedia。

本地：可以「加一个文件夹」整目录加进来，也可以「添加文件」挑几首，列表存在
~/.simple_mc_launcher/music.json。

在线：写歌名或歌手就能搜（iTunes 公开试听流），结果带封面、能翻页；右键一条结果
可以「加到我的列表」，会把那段试听音频下到本地缓存，之后离线也能听。
"""
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor

from PySide6.QtCore import QSize, Qt, QThread, QUrl, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout, QLabel,
                               QLineEdit, QListWidget, QListWidgetItem, QMenu,
                               QMessageBox, QProgressBar, QPushButton, QSlider,
                               QTabWidget, QVBoxLayout, QWidget)

from ui.media_compat import (HAS_MEDIA, IMPORT_ERROR, QMediaPlayer,
                             infinite_loops, is_muted, make_audio, make_player,
                             connect_state, set_loops, set_muted, set_source, set_volume)

AUDIO_EXT = (".mp3", ".wav", ".flac", ".m4a", ".ogg", ".opus", ".aac", ".wma")
COVER_PX = 46

# 搜索页上的快捷标签：左是人看的名字，右是实际拿去搜的词
CHIPS = (
    ("周杰伦", "周杰伦"),
    ("愉快", "愉快"),
    ("悲伤", "悲伤"),
    ("我的世界", "Minecraft"),
    ("伤感", "伤感"),
    ("搞怪", "搞怪"),
    ("轻快", "轻快"),
    ("热门", "热门"),
)

# 列表底色也走半透明，跟整窗的深色玻璃面板一致；壁纸透过来的那点亮度
# 靠 item 文字色和选中底撑住，不会糊成一片
_LIST_QSS = (
    "QListWidget{background:rgba(20, 23, 29, 0.55);"
    "border:1px solid rgba(255,255,255,30);border-radius:10px;padding:4px;}"
    "QListWidget::item{padding:5px;border-radius:6px;color:#E8ECF3;"
    "background:transparent;}"
    "QListWidget::item:hover{background:rgba(255,255,255,26);}"
    "QListWidget::item:selected{background:rgba(76,141,255,120);color:#FFFFFF;}")


def _fmt(ms):
    if not ms or ms < 0:
        return "00:00"
    s = int(ms // 1000)
    return "%02d:%02d" % (s // 60, s % 60)


def _safe_name(text):
    text = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", text or "").strip()
    return (text[:60] or "track")


def _cache_dir():
    from core.config import app_dir
    d = os.path.join(app_dir(), "music_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


_OPENER = None


def _music_opener():
    """音乐站的请求一律直连，绕开系统代理（开了加速器/梯子也能搜到歌、下得动）。"""
    global _OPENER
    if _OPENER is None:
        import urllib.request
        try:
            _OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        except Exception:
            _OPENER = urllib.request.build_opener()
    return _OPENER


def _download_bytes(url, timeout=8):
    import urllib.request
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with _music_opener().open(req, timeout=timeout) as r:
            return r.read()
    except Exception:
        return b""


def _download_stream(url, on_progress=None, timeout=25):
    """边下边回报进度的下载。

    on_progress(pct)：0~100 是已知总大小时的百分比；
    服务器没给 Content-Length 时先回调一次 -1（界面切成「不确定」的转圈态）。
    """
    import urllib.request
    total = 0
    got = 0
    chunks = []
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with _music_opener().open(req, timeout=timeout) as r:
            try:
                total = int(r.headers.get("Content-Length") or 0)
            except Exception:
                total = 0
            if total <= 0 and on_progress is not None:
                on_progress(-1)
            last = -1
            while True:
                buf = r.read(262144)
                if not buf:
                    break
                chunks.append(buf)
                got += len(buf)
                if on_progress is not None and total > 0:
                    pct = min(99, int(got * 100 / total))
                    if pct != last:
                        last = pct
                        on_progress(pct)
    except Exception:
        return b""
    if on_progress is not None:
        on_progress(100)
    return b"".join(chunks)


def _ext_of(url):
    """从地址里猜容器后缀；猜不到返回空串（交给内容嗅探）。"""
    raw = url or ""
    path = raw.split("?", 1)[0]
    ext = os.path.splitext(path)[1].lower()
    if ext in (".m4a", ".mp3", ".aac", ".wav", ".ogg", ".flac"):
        return ext
    # 有些源把后缀放在查询串里，如 .../outer/url?id=xxx.mp3
    if "?" in raw:
        ext2 = os.path.splitext(raw.split("?", 1)[1])[1].lower()
        if ext2 in (".m4a", ".mp3", ".aac", ".wav", ".ogg", ".flac"):
            return ext2
    return ""


def _ext_of_data(data):
    """按文件头判断真实容器，别把 mp3 存成 .m4a（播放器会认不出来）。"""
    if not data:
        return ""
    if data[:3] == b"ID3":
        return ".mp3"
    if data[0] == 0xFF and (data[1] & 0xE0) == 0xE0:
        return ".mp3"
    if data[:4] == b"OggS":
        return ".ogg"
    if data[4:8] == b"ftyp":
        return ".m4a"
    return ""


def _round_cover(data, px=COVER_PX):
    """把封面字节裁成圆角方块；取不到就返回 None。"""
    if not data:
        return None
    pm = QPixmap()
    if not pm.loadFromData(data):
        return None
    src = pm.scaled(px, px, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    out = QPixmap(px, px)
    out.fill(Qt.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing, True)
    path = QPainterPath()
    path.addRoundedRect(0.0, 0.0, float(px), float(px), 7.0, 7.0)
    p.setClipPath(path)
    dx = (src.width() - px) // 2
    dy = (src.height() - px) // 2
    p.drawPixmap(-dx, -dy, src)
    p.end()
    return out


def _note_pixmap(px=COVER_PX):
    """本地曲目没有封面时用的占位：深灰圆角块 + 一个音符。"""
    pm = QPixmap(px, px)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor("#2B303A"))
    p.drawRoundedRect(0, 0, px, px, 7, 7)
    p.setBrush(QColor("#8E97A6"))
    r = px // 6
    p.drawEllipse(int(px * 0.24), int(px * 0.52), r * 2, r * 2)
    p.drawEllipse(int(px * 0.52), int(px * 0.40), r * 2, r * 2)
    p.setBrush(QColor("#C9D0DB"))
    p.drawRect(int(px * 0.42), int(px * 0.20), 3, int(px * 0.42))
    p.drawRect(int(px * 0.70), int(px * 0.10), 3, int(px * 0.42))
    p.end()
    return pm


class _SearchWorker(QThread):
    """在线搜歌 + 顺手把封面图抓下来，全在后台，别把界面卡住。"""

    done = Signal(dict)

    def __init__(self, keyword, page, parent=None):
        super().__init__(parent)
        self.keyword = keyword
        self.page = page

    def run(self):
        try:
            from core import music_search
            res = music_search.search(self.keyword, self.page)
        except Exception as e:
            self.done.emit({"rows": [], "page": self.page, "has_more": False,
                            "country": "", "error": str(e)})
            return
        rows = res.get("rows") or []
        if rows:
            try:
                with ThreadPoolExecutor(max_workers=6) as ex:
                    futs = [ex.submit(_download_bytes, r["cover"]) if r.get("cover")
                            else None for r in rows]
                    for r, f in zip(rows, futs):
                        r["cover_bytes"] = f.result() if f is not None else b""
            except Exception:
                for r in rows:
                    r.setdefault("cover_bytes", b"")
        self.done.emit(res)


class _AddWorker(QThread):
    """把在线试听音频下到本地缓存，过程中把进度回报给界面。"""

    done = Signal(bool, str, str, bool)    # ok, 文件路径, 提示/封面, 是不是只有试听
    progress = Signal(int)                 # 0~100；-1 = 总大小未知

    def __init__(self, row, parent=None):
        super().__init__(parent)
        self.row = row

    def _grab(self, url, timeout=25):
        data = _download_stream(url, on_progress=self.progress.emit,
                                timeout=timeout)
        return data or b""

    @staticmethod
    def _is_audio(data):
        """整首源没版权时返回的是 404 的 HTML 页面（status 仍是 200），要挡掉。"""
        if not data or len(data) < 8:
            return False
        if data[:1] == b"<":
            return False
        head = data[:3]
        if head == b"ID3":
            return True
        # MPEG 帧同步：11 个 1
        if data[0] == 0xFF and (data[1] & 0xE0) == 0xE0:
            return True
        # 有的源是 m4a / ogg 容器
        if data[:4] in (b"ftyp", b"OggS") or data[4:8] == b"ftyp":
            return True
        return False

    def run(self):
        row = self.row or {}
        name = row.get("name") or "track"
        base = _safe_name("%s - %s" % (name, row.get("artist") or ""))
        dest = None
        data = b""
        preview_only = True

        full = row.get("full_url") or ""
        if full:
            try:
                data = self._grab(full, timeout=60)
            except Exception as e:
                data = b""
            if self._is_audio(data):
                ext = _ext_of_data(data) or _ext_of(full) or ".mp3"
                if ext not in AUDIO_EXT:
                    ext = ".mp3"
                dest = self._dest(base, ext)
                preview_only = False
            else:
                data = b""

        if not data:
            url = row.get("preview") or ""
            if not url:
                self.done.emit(False, "", "这首既没有整首地址也没有试听地址", True)
                return
            try:
                data = self._grab(url, timeout=25)
            except Exception as e:
                self.done.emit(False, "", "下载失败：%s" % e, True)
                return
            if not data:
                self.done.emit(False, "", "下载失败，检查一下网络", True)
                return
            dest = self._dest(base, _ext_of_data(data) or _ext_of(url) or ".m4a")
            preview_only = True

        tmp = dest + ".part"
        try:
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, dest)
        except Exception as e:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            self.done.emit(False, "", "写文件失败：%s" % e, preview_only)
            return
        # 封面存一份，列表里就一直有图了
        cover = ""
        try:
            cb = self.row.get("cover_bytes") or b""
            if cb:
                cover = os.path.splitext(dest)[0] + ".jpg"
                with open(cover, "wb") as f:
                    f.write(cb)
        except Exception:
            cover = ""
        self.done.emit(True, dest, cover, preview_only)

    def _dest(self, base, ext):
        """落盘位置。同名同后缀的文件已经存在就直接复用。

        以前是一律加 (2)(3) 往后排，结果是每次重下同一首歌都多留一份 ——
        用户反复试听、或者反复点「加到我的列表」，缓存目录里就堆出一串副本。
        """
        dest = os.path.join(_cache_dir(), base + ext)
        try:
            if os.path.isfile(dest) and os.path.getsize(dest) > 0:
                return dest
        except OSError:
            pass
        n = 2
        while os.path.exists(dest):
            dest = os.path.join(_cache_dir(), "%s (%d)%s" % (base, n, ext))
            n += 1
        return dest


class MusicPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tracks = []          # [{path|url, name, artist, cover}]
        self._current = -1
        self._seeking = False
        self._add_worker = None
        self._build()
        self._load()
        if HAS_MEDIA:
            self._init_player()

    # ---------- 界面 ----------
    def resizeEvent(self, ev):
        super().resizeEvent(ev)

    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        head = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        title = QLabel("音乐")
        title.setObjectName("PageTitle")
        sub = QLabel("放你电脑里的歌，也能直接在线搜")
        sub.setObjectName("PageSub")
        col.addWidget(title)
        col.addWidget(sub)
        head.addLayout(col)
        head.addStretch(1)

        self.btn_dir = QPushButton("加一个文件夹")
        self.btn_dir.clicked.connect(self._add_dir)
        head.addWidget(self.btn_dir)
        self.btn_file = QPushButton("添加文件")
        self.btn_file.clicked.connect(self._add_files)
        head.addWidget(self.btn_file)
        self.btn_del = QPushButton("删除选中")
        self.btn_del.clicked.connect(self._del_selected)
        head.addWidget(self.btn_del)
        v.addLayout(head)

        # 进度 + 时间
        row = QHBoxLayout()
        self.lbl_cur = QLabel("00:00")
        self.lbl_cur.setObjectName("FieldLabel")
        row.addWidget(self.lbl_cur)
        self.bar = QSlider(Qt.Horizontal)
        self.bar.setRange(0, 0)
        self.bar.sliderPressed.connect(self._seek_start)
        self.bar.sliderReleased.connect(self._seek_end)
        self.bar.sliderMoved.connect(self._seek_move)
        row.addWidget(self.bar, 1)
        self.lbl_len = QLabel("00:00")
        self.lbl_len.setObjectName("FieldLabel")
        row.addWidget(self.lbl_len)
        v.addLayout(row)

        # 控制行
        ctl = QHBoxLayout()
        ctl.setSpacing(8)
        self.btn_prev = QPushButton("上一首")
        self.btn_prev.clicked.connect(lambda: self._jump(-1))
        ctl.addWidget(self.btn_prev)
        self.btn_play = QPushButton("播放")
        self.btn_play.setObjectName("Primary")
        self.btn_play.setMinimumWidth(96)
        self.btn_play.clicked.connect(self._toggle)
        ctl.addWidget(self.btn_play)
        self.btn_next = QPushButton("下一首")
        self.btn_next.clicked.connect(lambda: self._jump(1))
        ctl.addWidget(self.btn_next)

        ctl.addSpacing(16)
        ctl.addWidget(QLabel("循环"))
        self.combo_loop = QComboBox()
        self.combo_loop.addItem("播完停", "none")
        self.combo_loop.addItem("列表循环", "loop")
        self.combo_loop.addItem("单曲循环", "one")
        self.combo_loop.setFixedWidth(110)
        self.combo_loop.currentIndexChanged.connect(self._apply_loop)
        ctl.addWidget(self.combo_loop)

        ctl.addSpacing(8)
        self.btn_mute = QPushButton("静音")
        self.btn_mute.setMinimumWidth(76)
        self.btn_mute.clicked.connect(self._toggle_mute)
        ctl.addWidget(self.btn_mute)
        self.vol = QSlider(Qt.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(60)
        self.vol.setFixedWidth(120)
        self.vol.valueChanged.connect(self._set_vol)
        ctl.addWidget(self.vol)

        ctl.addStretch(1)
        self.btn_clear = QPushButton("清空列表")
        self.btn_clear.clicked.connect(self._clear)
        ctl.addWidget(self.btn_clear)
        v.addLayout(ctl)

        self.lbl_tip = QLabel("")
        self.lbl_tip.setObjectName("FieldLabel")
        if not HAS_MEDIA:
            self.lbl_tip.setText("这个包里的 Qt 多媒体模块没装好，放不了歌（%s）"
                                 % IMPORT_ERROR[:60])
        v.addWidget(self.lbl_tip)

        # 两个页签：我的列表 / 在线搜歌
        self.tabs = QTabWidget()

        w_local = QWidget()
        lv = QVBoxLayout(w_local)
        lv.setContentsMargins(0, 8, 0, 0)
        lv.setSpacing(8)
        self.list = QListWidget()
        self.list.setAlternatingRowColors(False)   # 交替色会顶掉自定义 item 底色，白条很难看
        self.list.setStyleSheet(_LIST_QSS)
        self.list.setIconSize(QSize(COVER_PX, COVER_PX))
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu_local)
        self.list.itemDoubleClicked.connect(
            lambda *_: self._play_row(self.list.currentRow()))
        lv.addWidget(self.list, 1)
        self.tabs.addTab(w_local, "我的列表")

        w_online = QWidget()
        ov = QVBoxLayout(w_online)
        ov.setContentsMargins(0, 8, 0, 0)
        ov.setSpacing(8)

        srow = QHBoxLayout()
        srow.setSpacing(8)
        self.input_kw = QLineEdit()
        self.input_kw.setPlaceholderText("搜歌名或歌手，例如：起风了 / 周杰伦")
        self.input_kw.returnPressed.connect(lambda: self._search(1))
        srow.addWidget(self.input_kw, 1)
        self.btn_search = QPushButton("搜一下")
        self.btn_search.clicked.connect(lambda: self._search(1))
        srow.addWidget(self.btn_search)
        ov.addLayout(srow)

        # 快捷标签
        crow = QHBoxLayout()
        crow.setSpacing(6)
        self.chips = []
        for label, query in CHIPS:
            b = QPushButton(label)
            b.setFixedHeight(30)
            b.setStyleSheet("QPushButton{padding:2px 10px;font-size:12.5px;}")
            b.clicked.connect(lambda _=False, q=query: self._chip(q))
            crow.addWidget(b)
            self.chips.append(b)
        crow.addStretch(1)
        ov.addLayout(crow)

        prow = QHBoxLayout()
        prow.setSpacing(8)
        self.btn_pg_prev = QPushButton("上一页")
        self.btn_pg_prev.setEnabled(False)
        self.btn_pg_prev.clicked.connect(lambda: self._search(self._page - 1))
        prow.addWidget(self.btn_pg_prev)
        self.lbl_page = QLabel("第 1 页")
        self.lbl_page.setObjectName("FieldLabel")
        prow.addWidget(self.lbl_page)
        self.btn_pg_next = QPushButton("下一页")
        self.btn_pg_next.setEnabled(False)
        self.btn_pg_next.clicked.connect(lambda: self._search(self._page + 1))
        prow.addWidget(self.btn_pg_next)
        self.lbl_online = QLabel("双击试听，右键可以「加到我的列表」")
        self.lbl_online.setObjectName("FieldLabel")
        prow.addWidget(self.lbl_online)
        prow.addStretch(1)
        ov.addLayout(prow)

        self.online_list = QListWidget()
        self.online_list.setAlternatingRowColors(False)
        self.online_list.setStyleSheet(_LIST_QSS)
        self.online_list.setIconSize(QSize(COVER_PX, COVER_PX))
        self.online_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.online_list.customContextMenuRequested.connect(self._menu_online)
        self.online_list.itemDoubleClicked.connect(
            lambda *_: self._play_online(self.online_list.currentRow()))
        ov.addWidget(self.online_list, 1)
        self.tabs.addTab(w_online, "在线搜歌")

        v.addWidget(self.tabs, 1)

        # 下载进度：把在线歌加进「我的列表」时，这里显示百分比
        self.dl_lbl = QLabel("")
        self.dl_lbl.setObjectName("FieldLabel")
        self.dl_lbl.setVisible(False)
        v.addWidget(self.dl_lbl)
        self.dl_bar = QProgressBar()
        self.dl_bar.setRange(0, 100)
        self.dl_bar.setValue(0)
        self.dl_bar.setFixedHeight(10)
        self.dl_bar.setTextVisible(False)
        self.dl_bar.setVisible(False)
        v.addWidget(self.dl_bar)
        # 缓存
        self._kw = ""
        self._page = 1
        self._has_more = False
        self._rows = []
        self._worker = None
        self._kind = "local"
        self._note_icon_cache = None
        self._cover_cache = {}

    # ---------- 播放器 ----------
    def _init_player(self):
        self.player = make_player(self)
        self.out = make_audio(self.player, self, 0.6)
        self.player.positionChanged.connect(self._on_pos)
        self.player.durationChanged.connect(self._on_dur)
        self.player.mediaStatusChanged.connect(self._on_status)
        connect_state(self.player, self._on_state)
        # 在线直链放不出来就自动改成本地缓存播（见 _on_play_error）
        try:
            self.player.errorOccurred.connect(self._on_play_error)
        except Exception:
            pass
        self._apply_loop()

    def _note_icon(self):
        if self._note_icon_cache is None:
            self._note_icon_cache = QIcon(_note_pixmap())
        return self._note_icon_cache

    def _row_url(self, i):
        if not (0 <= i < len(self.tracks)):
            return None
        t = self.tracks[i]
        p = t.get("path") or ""
        if p and os.path.isfile(p):
            return QUrl.fromLocalFile(p)
        u = t.get("url") or ""
        if u:
            return QUrl(u)
        return None

    def _play_row(self, row):
        if not HAS_MEDIA or not (0 <= row < len(self.tracks)):
            return
        url = self._row_url(row)
        if url is None:
            self.lbl_tip.setText("这首歌的文件找不到了：%s" % self.tracks[row]["name"])
            return
        self._kind = "local"
        self._current = row
        set_source(self.player, url)
        self.player.play()
        self.list.setCurrentRow(row)
        self.lbl_tip.setText("正在放：%s" % self.tracks[row]["name"])

    # ---------- 在线搜歌 ----------
    def _chip(self, query):
        self.input_kw.setText(query)
        self._search(1)

    def _search(self, page):
        kw = self.input_kw.text().strip()
        if not kw:
            self.lbl_online.setText("先写个歌名或歌手，再点搜一下")
            return
        page = max(1, int(page or 1))
        if self._worker is not None and self._worker.isRunning():
            return                      # 上一次还没回来，别叠着发
        self._kw = kw
        self._page = page
        self.btn_search.setEnabled(False)
        self.btn_pg_prev.setEnabled(False)
        self.btn_pg_next.setEnabled(False)
        self.lbl_online.setText("正在搜「%s」第 %d 页…" % (kw, page))
        self._worker = _SearchWorker(kw, page, self)
        self._worker.done.connect(self._on_search_done)
        self._worker.start()

    def _on_search_done(self, res):
        self.btn_search.setEnabled(True)
        rows = res.get("rows") or []
        self._rows = rows
        self._has_more = bool(res.get("has_more"))
        self._page = int(res.get("page") or 1)
        self.online_list.clear()
        if rows:
            for r in rows:
                artist = r.get("artist") or "未知"
                dur = _fmt(r.get("ms"))
                mark = ""
                if r.get("full_url"):
                    mark = "　〔可下整首〕"
                elif not r.get("preview"):
                    mark = "（这段没试听）"
                else:
                    mark = "　〔仅 30 秒试听〕"
                icon = QIcon(_round_cover(r.get("cover_bytes"))) \
                    if r.get("cover_bytes") else self._note_icon()
                item = QListWidgetItem(icon, "%s — %s　%s%s"
                                       % (r.get("name"), artist, dur, mark),
                                       self.online_list)
                item.setToolTip("%s\n%s\n%s" % (r.get("name"), artist,
                                                r.get("album") or ""))
            self.lbl_page.setText("第 %d 页" % self._page)
            self.lbl_online.setText(
                "这一页 %d 首%s；标「可下整首」的能下完整首，"
                "标「仅 30 秒试听」的源本身只有试听片段"
                % (len(rows), "，还有下一页" if self._has_more else "，到底了"))
        else:
            self.lbl_page.setText("第 %d 页" % self._page)
            self.lbl_online.setText(res.get("error") or "没搜到，换个写法试试")
        self.btn_pg_prev.setEnabled(self._page > 1)
        self.btn_pg_next.setEnabled(self._has_more)
        self._worker = None
        # AI 搭子点的歌：搜完直接放第一条
        if getattr(self, "_ai_auto_play", False):
            self._ai_auto_play = False
            if self._rows:
                self._play_online(0)

    def _play_online(self, row):
        if not HAS_MEDIA or not (0 <= row < len(self._rows)):
            return
        r = self._rows[row]
        full = r.get("full_url") or ""
        src_url = full or (r.get("preview") or "")
        if not src_url:
            self.lbl_tip.setText("这首既没整首也没试听地址，换一首试试")
            return
        self._kind = "online"
        self._current = row
        self._online_now = r
        set_source(self.player, QUrl(src_url))
        self.player.play()
        self.online_list.setCurrentRow(row)
        self.lbl_tip.setText(
            "正在播：%s — %s%s"
            % (r.get("name"), r.get("artist"),
               "" if full else "（这个源只有试听片段）"))

    def _on_play_error(self, *args):
        """在线直链放不出来时，退一步：下到本地缓存再放。

        网易云的外链对一部分歌会 302 到防盗链地址、或者干脆给一页 HTML，
        播放器只会报一个笼统的错误。这时候别让用户对着 0:00 发呆，
        直接在后台把整首（没有就 30 秒试听）抓下来，用本地文件播。
        """
        try:
            if self._kind != "online" or getattr(self, "_fallback_on", False):
                return
            r = getattr(self, "_online_now", None)
            if not r:
                return
            if not ((r.get("full_url") or "") or (r.get("preview") or "")):
                self.lbl_tip.setText("这首既没有整首也没有试听地址，换一首试试")
                return
            self._fallback_on = True
            self.lbl_tip.setText("在线直链播不了，正在下到本地再放…")
            self._show_dl("正在下载「%s」" % (r.get("name") or ""))
            w = _AddWorker(r, self)
            self._fallback_worker = w
            w.progress.connect(self._on_add_progress)
            w.done.connect(
                lambda ok, p, c, pv: self._on_fallback_done(r, ok, p, c, pv))
            w.start()
        except Exception:
            self._fallback_on = False

    def _on_fallback_done(self, r, ok, path, why, preview_only=True):
        self._fallback_on = False
        self._fallback_worker = None
        self._hide_dl()
        if not ok or not path or not os.path.isfile(path):
            self.lbl_tip.setText("这首播不了也下不下来：%s" % (why or "网络不通"))
            return
        try:
            self._kind = "local"
            set_source(self.player, QUrl.fromLocalFile(path))
            self.player.play()
        except Exception as e:
            self.lbl_tip.setText("下到了但放不了：%s" % e)
            return
        self.lbl_tip.setText("在线直链播不了，已下到本地在放：%s%s"
                             % (r.get("name") or "",
                                "（试听片段）" if preview_only else ""))

    # ---------- AI 搭子「小矿」能调的接口 ----------
    def ai_play_keyword(self, kw):
        """按歌名搜一首并直接播。返回给用户看的说明。"""
        kw = (kw or "").strip()
        if not kw:
            return "没说要放什么歌"
        if not HAS_MEDIA:
            return "这台机器上装不了播放器，放不出来"
        self.input_kw.setText(kw)
        self._ai_auto_play = True
        self._search(1)
        return "在找《%s》，找到了就放" % kw

    def ai_pause(self):
        if HAS_MEDIA and self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            return "音乐暂停了"
        return "现在没在放歌"

    def ai_resume(self):
        if HAS_MEDIA and self.player.source().isValid():
            self.player.play()
            return "接着放"
        return "没有可以续放的歌"

    def ai_next(self):
        if not HAS_MEDIA:
            return "放不了"
        self._jump(1)
        return "换下一首"

    def ai_volume(self, v):
        try:
            v = max(0, min(100, int(v)))
        except Exception:
            return "音量值看不懂"
        try:
            self.vol.setValue(v)
        except Exception:
            pass
        return "音量 %d" % v

    def _toggle(self):
        """点播放：没在放就放「当前选中的那首」（单击选中也算，不用双击）。"""
        if not HAS_MEDIA:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            return
        if self._kind == "online":
            row = self.online_list.currentRow()
            if row >= 0 and (row != self._current or not self.player.source().isValid()):
                self._play_online(row)
                return
            if self._current >= 0 and self.player.source().isValid():
                self.player.play()
                return
            self._play_online(row if row >= 0 else 0)
            return
        row = self.list.currentRow()
        if row >= 0 and (row != self._current or not self.player.source().isValid()):
            self._play_row(row)
            return
        if self._current >= 0 and self.player.source().isValid():
            self.player.play()
            return
        self._play_row(row if row >= 0 else 0)

    def _jump(self, step):
        if self._kind == "online":
            if not self._rows:
                return
            base = self._current if self._current >= 0 else 0
            self._play_online((base + step) % len(self._rows))
            return
        if not self.tracks:
            return
        base = self._current if self._current >= 0 else 0
        nxt = (base + step) % len(self.tracks)
        self._play_row(nxt)

    def _apply_loop(self):
        if not HAS_MEDIA or getattr(self, "player", None) is None:
            return                  # _load() 里设下拉框时播放器还没造出来
        mode = self.combo_loop.currentData()
        if mode == "one":
            set_loops(self.player, infinite_loops())
        else:
            set_loops(self.player, 1)      # Qt 语义：1 = 播一次，播完发 EndOfMedia

    def _toggle_mute(self):
        if not HAS_MEDIA:
            return
        muted = not is_muted(self.player, self.out)
        set_muted(self.player, self.out, muted)
        self.btn_mute.setText("取消静音" if muted else "静音")
        self.btn_mute.setMinimumWidth(96 if muted else 76)

    def _set_vol(self, val):
        out = getattr(self, "out", None)
        if HAS_MEDIA and out is not None:      # 同理：_load() 时会先设一次音量
            set_volume(self.player, out, val / 100.0)

    # ---------- 播放器回调 ----------
    def _on_pos(self, ms):
        if self._seeking:
            return
        self.bar.setValue(int(ms))
        self.lbl_cur.setText(_fmt(ms))

    def _on_dur(self, ms):
        self.bar.setRange(0, max(0, int(ms)))
        self.lbl_len.setText(_fmt(ms))

    def _on_state(self, st):
        playing = st == QMediaPlayer.PlayingState
        self.btn_play.setText("暂停" if playing else "播放")

    def _has_music(self):
        try:
            return bool(self.player.source().isValid())
        except Exception:
            return False

    def _on_status(self, st):
        if st != QMediaPlayer.EndOfMedia:
            return
        mode = self.combo_loop.currentData()
        if mode == "loop":
            self._jump(1)
        else:
            self.btn_play.setText("播放")

    def _seek_start(self):
        self._seeking = True

    def _seek_move(self, val):
        self.lbl_cur.setText(_fmt(val))

    def _seek_end(self):
        self._seeking = False
        if HAS_MEDIA:
            self.player.setPosition(self.bar.value())

    # ---------- 右键菜单 ----------
    def _menu_local(self, pos):
        item = self.list.itemAt(pos)
        if item is None:
            return
        row = self.list.row(item)
        if not (0 <= row < len(self.tracks)):
            return
        t = self.tracks[row]
        p = t.get("path") or ""
        menu = QMenu(self)
        act_play = menu.addAction("放这首")
        act_ring = menu.addAction("设为闹钟铃声")
        act_ring.setEnabled(bool(p) and os.path.isfile(p))
        act_del = menu.addAction("从我的列表删除这首")
        menu.addSeparator()
        act_folder = menu.addAction("打开所在文件夹")
        act_folder.setEnabled(bool(p) and os.path.isfile(p))
        act = menu.exec_(self.list.viewport().mapToGlobal(pos))
        if act == act_play:
            self._play_row(row)
        elif act == act_ring:
            self._set_alarm_ring(p, t.get("name") or "")
        elif act == act_del:
            self._remove_track(row)
        elif act == act_folder:
            self._open_folder(p)

    def _set_alarm_ring(self, path, name=""):
        """把这一首设成闹钟铃声：写进 alarm.json，正在跑的闹钟也同步换掉。"""
        name = name or os.path.basename(path or "")
        if not path or not os.path.isfile(path):
            self.lbl_tip.setText("这首歌的文件找不到了，没法当铃声")
            return
        try:
            from core import alarm
            d = alarm.load()
            d["custom_ring"] = path
            alarm.save(d)
        except Exception as e:
            self.lbl_tip.setText("设铃声失败：%s" % e)
            return
        # 闹钟服务内存里还留着一份数据，顺手改掉，下回响铃立刻就是新歌
        try:
            win = self.window()
            svc = win.alarm_svc() if hasattr(win, "alarm_svc") else None
            if svc is not None and hasattr(svc, "data"):
                svc.data["custom_ring"] = path
        except Exception:
            pass
        self.lbl_tip.setText("已把「%s」设为闹钟铃声（在「工具 - 闹钟」里也能换回去）" % name)

    def _menu_online(self, pos):
        row = self.online_list.row(self.online_list.itemAt(pos))
        if not (0 <= row < len(self._rows)):
            return
        r = self._rows[row]
        menu = QMenu(self)
        act_play = menu.addAction("试听这首")
        act_add = menu.addAction("加到我的列表")
        # 不再因为「没有试听地址」就把这个菜单项灰掉：灰掉点了什么都不发生，
        # 看起来就像功能坏了。留成可点，点了会明确告诉你为什么加不了。
        menu.addSeparator()
        act_open = menu.addAction("打开这首歌的页面")
        act_open.setEnabled(bool(r.get("page_url")))
        act = menu.exec_(self.online_list.viewport().mapToGlobal(pos))
        if act == act_play:
            self._play_online(row)
        elif act == act_add:
            # 这里必须传这一条搜索结果（dict），不是列表行号：
            # 传 row 会在 _add_to_local 里对 int 调 .get()，直接抛 AttributeError，
            # 界面看起来就是「点了没反应」。
            self._add_to_local(r)
        elif act == act_open:
            from PySide6.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl(r["page_url"]))

    def _open_folder(self, path):
        try:
            from PySide6.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
        except Exception as e:
            self.lbl_tip.setText("打不开文件夹：%s" % e)

    # ---------- 加到我的列表 ----------
    def _already_have(self, r):
        for t in self.tracks:
            if (t.get("name") or "") == (r.get("name") or "") and \
                    (t.get("artist") or "") == (r.get("artist") or ""):
                return True
        return False

    def _add_to_local(self, r):
        name = r.get("name") or ""
        if not ((r.get("full_url") or "") or (r.get("preview") or "")):
            QMessageBox.information(
                self, "这首加不了",
                "「%s」这条搜索结果没有可下载的地址（整首和试听都拿不到），"
                "所以加不进本地列表。\n换同名的另一条结果试试，多数都有。" % name)
            return
        if self._already_have(r):
            msg = "「%s」已经在「我的列表」里了（点上面那个页签切过去看）" % name
            self.lbl_tip.setText(msg)
            self.lbl_online.setText(msg)
            return
        if self._add_worker is not None and self._add_worker.isRunning():
            self.lbl_tip.setText("上一首还在下载，等它下完再加")
            return
        self.lbl_tip.setText("正在把「%s」下到本地…（能拿到整首就下整首）" % name)
        self.lbl_online.setText("正在下载「%s」…（下完会告诉你）" % name)
        self._show_dl("正在下载「%s」" % name)
        self._add_worker = _AddWorker(r, self)
        self._add_worker.progress.connect(self._on_add_progress)
        self._add_worker.done.connect(
            lambda ok, p, c, pv: self._on_add_done(r, ok, p, c, pv))
        self._add_worker.start()

    # ---------- 下载进度条 ----------
    def _show_dl(self, text):
        self._dl_base = text          # 记住不带百分比的前半段，进度只改后半截
        self.dl_lbl.setText(text)
        self.dl_lbl.setVisible(True)
        self.dl_bar.setRange(0, 100)
        self.dl_bar.setValue(0)
        self.dl_bar.setVisible(True)

    def _hide_dl(self):
        self.dl_lbl.setVisible(False)
        self.dl_bar.setVisible(False)

    def _on_add_progress(self, pct):
        if pct < 0:
            # 服务器没给总大小：切成「不确定」的来回滚动
            self.dl_bar.setRange(0, 0)
            return
        if self.dl_bar.maximum() == 0:
            self.dl_bar.setRange(0, 100)
        pct = max(0, min(100, int(pct)))
        self.dl_bar.setValue(pct)
        self.dl_lbl.setText("%s  %d%%" % (getattr(self, "_dl_base", ""), pct))

    def _on_add_done(self, r, ok, path, cover, preview_only=True):
        self._add_worker = None
        self._hide_dl()
        name = r.get("name") or ""
        if not ok:
            why = cover or "加不进来"
            self.lbl_tip.setText(why)
            self.lbl_online.setText("没加成：%s" % why)
            QMessageBox.warning(self, "没加到本地列表", "「%s」没加成：%s" % (name, why))
            return
        self.tracks.append({"path": path, "name": r.get("name") or os.path.basename(path),
                            "artist": r.get("artist") or "", "cover": cover or "",
                            "from": "online", "preview": bool(preview_only)})
        self._fill()
        self._save()
        size_mb = 0.0
        try:
            size_mb = os.path.getsize(path) / 1048576.0
        except OSError:
            pass
        if preview_only:
            tail = ("（在线源这首只有 30 秒试听片段，已标出来；"
                    "要整首可以换同名的另一条结果，或用「从文件夹加」导入）")
        else:
            tail = "（整首，%.1f MB）" % size_mb
        msg = ("已加到「我的列表」：%s — %s%s，现在共 %d 首"
               % (name, r.get("artist") or "", tail, len(self.tracks)))
        self.lbl_tip.setText(msg)
        # 在线搜歌页里也写一遍：用户右键的就在这一页，提示要出现在眼前
        self.lbl_online.setText("✓ " + msg)

    # ---------- 列表维护 ----------
    def _store_path(self):
        from core.config import app_dir
        return os.path.join(app_dir(), "music.json")

    def _load(self):
        try:
            with open(self._store_path(), "r", encoding="utf-8") as f:
                data = json.load(f)
            for it in data.get("tracks") or []:
                if isinstance(it, str):                 # 旧格式：只有路径
                    if os.path.isfile(it):
                        self.tracks.append({"path": it,
                                            "name": os.path.basename(it)})
                    continue
                if not isinstance(it, dict):
                    continue
                p = it.get("path") or ""
                u = it.get("url") or ""
                name = it.get("name") or os.path.basename(p) or "（网络）"
                if p and os.path.isfile(p):
                    self.tracks.append({"path": p, "name": name,
                                        "artist": it.get("artist") or "",
                                        "cover": it.get("cover") or "",
                                        "from": it.get("from") or "",
                                        "preview": bool(it.get("preview"))})
                elif u:
                    self.tracks.append({"url": u, "name": name,
                                        "artist": it.get("artist") or "",
                                        "from": it.get("from") or ""})
            vol = data.get("volume")
            self.vol.setValue(int(vol if vol is not None else 60))
            mode = data.get("loop") or "none"
            for i in range(self.combo_loop.count()):
                if self.combo_loop.itemData(i) == mode:
                    self.combo_loop.setCurrentIndex(i)
        except Exception:
            pass
        self._fill()

    def _save(self):
        try:
            items = []
            for t in self.tracks:
                d = {"name": t.get("name") or ""}
                if t.get("path"):
                    d["path"] = t["path"]
                if t.get("url"):
                    d["url"] = t["url"]
                if t.get("artist"):
                    d["artist"] = t["artist"]
                if t.get("cover"):
                    d["cover"] = t["cover"]
                if t.get("from"):
                    d["from"] = t["from"]
                if t.get("preview"):
                    d["preview"] = True
                items.append(d)
            with open(self._store_path(), "w", encoding="utf-8") as f:
                json.dump({"tracks": items,
                           "volume": self.vol.value(),
                           "loop": self.combo_loop.currentData()},
                          f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    def _fill(self):
        self.list.blockSignals(True)
        self.list.clear()
        for t in self.tracks:
            label = t.get("name") or ""
            if t.get("artist"):
                label += "　%s" % t["artist"]
            # 只有真拿不到整首、退回试听片段的才标出来
            if t.get("preview"):
                label += "　（试听 30 秒）"
            icon = self._note_icon()
            cp = t.get("cover") or ""
            if cp and os.path.isfile(cp):
                ic = self._cover_cache.get(cp)
                if ic is None:
                    try:
                        with open(cp, "rb") as f:
                            pm = _round_cover(f.read())
                        ic = QIcon(pm) if pm is not None else self._note_icon()
                    except Exception:
                        ic = self._note_icon()
                    # 歌单一长（几百首）这个缓存就会一直涨，每个 QIcon 都带位图。
                    # 留最近 60 个够滚动时命中，其余丢掉重新解码也只要几毫秒。
                    if len(self._cover_cache) >= 80:
                        for _k in list(self._cover_cache.keys())[:-60]:
                            self._cover_cache.pop(_k, None)
                    self._cover_cache[cp] = ic
                icon = ic
            item = QListWidgetItem(icon, label, self.list)
            item.setToolTip(t.get("path") or t.get("url") or "")
        self.list.blockSignals(False)
        # 页签上直接带个数：加完歌一眼就能看到「我的列表」的数字变了
        self.tabs.setTabText(0, "我的列表 (%d)" % len(self.tracks))

    def _remove_track(self, row):
        if not (0 <= row < len(self.tracks)):
            return
        name = self.tracks[row].get("name") or ""
        del self.tracks[row]
        if self._current == row:
            if HAS_MEDIA:
                self.player.stop()
                set_source(self.player, QUrl())
            self._current = -1
        elif self._current > row:
            self._current -= 1
        self._fill()
        self._save()
        self.lbl_tip.setText("从我的列表删了「%s」（硬盘上的歌没动）" % name)

    def _del_selected(self):
        row = self.list.currentRow()
        if row < 0:
            self.lbl_tip.setText("先在「我的列表」里点一首，再点删除")
            return
        self._remove_track(row)

    def _add_dir(self):
        start = ""
        for t in self.tracks:
            if t.get("path"):
                start = t["path"]
                break
        d = QFileDialog.getExistingDirectory(self, "选一个放音乐的文件夹", start)
        if not d:
            return
        n = 0
        try:
            for root, _dirs, files in os.walk(d):
                for name in sorted(files):
                    if os.path.splitext(name)[1].lower() in AUDIO_EXT:
                        full = os.path.join(root, name)
                        if full not in [t.get("path") for t in self.tracks]:
                            self.tracks.append({"path": full, "name": name})
                            n += 1
        except Exception as e:
            self.lbl_tip.setText("读文件夹出错：%s" % e)
        self._fill()
        self._save()
        self.lbl_tip.setText("加进来 %d 首，列表里共 %d 首" % (n, len(self.tracks)))

    def _add_files(self):
        start = ""
        for t in self.tracks:
            if t.get("path"):
                start = t["path"]
                break
        files, _ = QFileDialog.getOpenFileNames(
            self, "选几首歌", start,
            "音频 (%s);;所有文件 (*)" % " ".join("*" + e for e in AUDIO_EXT))
        n = 0
        for p in files or []:
            if p not in [t.get("path") for t in self.tracks]:
                self.tracks.append({"path": p, "name": os.path.basename(p)})
                n += 1
        if n:
            self._fill()
            self._save()
            self.lbl_tip.setText("加进来 %d 首" % n)

    def _clear(self):
        if HAS_MEDIA:
            self.player.stop()
        self._current = -1
        self.tracks = []
        self._fill()
        self._save()
        self.lbl_tip.setText("列表清空了（歌本身没删）")

    def shutdown(self):
        """关窗口时把播放停掉，别让音频线程挂着退出。"""
        for attr in ("_worker", "_add_worker"):
            w = getattr(self, attr, None)
            if w is not None and w.isRunning():
                try:
                    w.quit()
                    w.wait(1500)
                except Exception:
                    pass
        if HAS_MEDIA and getattr(self, "player", None) is not None:
            try:
                self.player.stop()
                self.player.setAudioOutput(None)
            except Exception:
                pass
