# -*- coding: utf-8 -*-
"""小矿的语音通话窗。

- 语音识别走 Windows 自带的离线引擎（core.stt），不上传音频
- 一轮一轮来：听 → 想 → 说 → 再听。说话时麦克风不监听，避免自己听见自己
- 通话里说「把电话挂断 / 挂了吧 / 拜拜」它就自己挂断，并且回一句再关窗
- 所有耗时动作都在后台线程，界面不卡
"""
import time

from PySide6.QtCore import QThread, QTimer, Qt, Signal
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QPushButton,
                               QTextBrowser, QVBoxLayout)

from core import ai_friend, stt, tts
from ui.ai_chat_dialog import _ai_avatar

AI_NAME = ai_friend.NAME

_QSS = """
QDialog#CallCard { background: #14161C; }
QTextBrowser#CallLog { background:#0F1116; border:1px solid #262A34;
                       border-radius:12px; padding:10px; }
QPushButton{background:#232833;border:1px solid #333A46;border-radius:8px;
            color:#DDE3EC;font-size:14px;padding:8px 12px;}
QPushButton:hover{background:#2C333F;}
QPushButton:checked{background:#3C4A5E;color:#FFFFFF;}
QPushButton:disabled{color:#6B7280;}
"""


class _ListenThread(QThread):
    got = Signal(str, str)          # 文本, 状态

    def run(self):
        try:
            text, why = stt.listen(14)
        except Exception as e:
            text, why = "", "error:%s" % str(e)[:40]
        self.got.emit(text, why)


class _WarmThread(QThread):
    """提前把 Whisper 模型装进内存，省掉第一句话的 3~5 秒等待。

    模型还没下过的话，这里顺手把它下下来（约 461MB，只下一次）；
    下载期间识别会自动用回老的 Windows 引擎，通话不会卡住。
    """
    noticed = Signal(str)

    def run(self):
        try:
            if not stt.model_ready():
                self.noticed.emit("首次用语音要先下语音模型（约 460MB，只需一次），"
                                  "下好之前先用系统自带识别顶着。")
                stt.ensure_model()
            # 允许预热线程顺手把小一号的模型也备着：内存不够跑 small 时能降级，
            # 否则只能掉回系统识别（后者准确率差得多）。
            if not stt.warm(allow_download=True):
                self.noticed.emit("内存不够，语音模型没装上，这次先用系统识别"
                                  "（准确率会差些）；关掉几个程序再来会好很多。")
        except Exception:
            pass


class _ReplyThread(QThread):
    got = Signal(str, object)       # 回复文本, 动作

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.text = text

    def run(self):
        try:
            say, act, _engine = ai_friend.reply(self.text, mode="call")
        except Exception as e:
            say, act = "我一走神没接上，你再说一遍？", None
        self.got.emit(say or "", act)


class _SpeakThread(QThread):
    done = Signal()

    def __init__(self, text, style, parent=None):
        super().__init__(parent)
        self.text = text
        self.style = style

    def run(self):
        try:
            # 通话里稍微慢一点、压低一点，像面对面聊天而不是播报
            tts.say_block(self.text, self.style, mood=ai_friend.last_mood())
        except Exception:
            pass
        self.done.emit()


class AICallDialog(QDialog):
    """和小矿打电话（语音）。"""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self._phase = "idle"        # idle / listen / think / speak / over
        self._silent = False        # 用户点了静音
        self._closed = False
        self._miss = 0              # 连续没听清的次数
        self._t0 = time.time()
        self._style = host.config.get("ai_voice_style") or "xiaokuang"
        if self._style == "guan":
            self._style = "xiaokuang"        # 通话必须出声
        self._listen = None
        self._reply = None
        self._speak = None

        self.setObjectName("CallCard")
        self.setWindowTitle("和小矿通话")
        self.setStyleSheet(_QSS)
        self.resize(400, 620)

        v = QVBoxLayout(self)
        v.setSpacing(12)
        v.setContentsMargins(16, 16, 16, 16)

        pic = QLabel()
        pic.setPixmap(_ai_avatar(96))
        pic.setFixedSize(98, 98)
        pic.setAlignment(Qt.AlignCenter)
        v.addWidget(pic, 0, Qt.AlignHCenter)

        self.lbl_name = QLabel(AI_NAME)
        self.lbl_name.setAlignment(Qt.AlignCenter)
        self.lbl_name.setStyleSheet(
            "color:#FFFFFF;font-size:20px;font-weight:700;")
        v.addWidget(self.lbl_name)

        self.lbl_state = QLabel("准备中…")
        self.lbl_state.setAlignment(Qt.AlignCenter)
        self.lbl_state.setStyleSheet("color:#8FC98B;font-size:14px;")
        v.addWidget(self.lbl_state)

        self.log = QTextBrowser()
        self.log.setObjectName("CallLog")
        self.log.setOpenExternalLinks(False)
        self.log.setStyleSheet(
            "QTextBrowser{background:#0F1116;border:1px solid #262A34;"
            "border-radius:12px;padding:10px;color:#D7DCE6;font-size:14px;}")
        v.addWidget(self.log, 1)

        bar = QHBoxLayout()
        self.b_mute = QPushButton("静音麦克风")
        self.b_mute.setCheckable(True)
        self.b_mute.setFixedHeight(40)
        self.b_mute.clicked.connect(self._on_mute)
        bar.addWidget(self.b_mute, 1)
        self.b_hang = QPushButton("挂断")
        self.b_hang.setFixedHeight(40)
        self.b_hang.setStyleSheet(
            "QPushButton{background:#C0392B;border:none;border-radius:8px;"
            "color:#FFFFFF;font-size:15px;font-weight:700;}"
            "QPushButton:hover{background:#D74634;}")
        self.b_hang.setFixedWidth(110)
        self.b_hang.clicked.connect(self._hang_up)
        bar.addWidget(self.b_hang)
        v.addLayout(bar)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)

        if not stt.available():
            QTimer.singleShot(0, self._no_stt)
            return
        # Whisper 模型加载要 3~5 秒，先在后台热起来，别让第一句话白等
        self._warm = _WarmThread(self)
        self._warm.noticed.connect(
            lambda s: self.log.append('<span style="color:#8A93A5;">%s</span>' % s))
        self._warm.start()
        self.log.append('<span style="color:#8FC98B;">小矿</span>：'
                        '喂，我在呢，你说。')
        QTimer.singleShot(200, self._open_line)

    # ---------- 开场 ----------
    def _open_line(self):
        if self._closed:
            return
        self._phase = "speak"
        self.lbl_state.setText("小矿在说话…")
        self._speak = _SpeakThread("喂，我在呢，有事你说。", self._style, self)
        self._speak.done.connect(self._after_speak)
        self._speak.start()

    def _no_stt(self):
        self.log.append(
            '<span style="color:#E0A03D;">这台电脑没有可用的中文语音识别，'
            '通话开不起来。</span><br>可以在系统「设置 → 时间和语言 → 语音」里'
            '装一下中文语音包，再回来试。文字聊天照样能用。')
        self.lbl_state.setText("语音识别不可用")
        self.b_mute.setEnabled(False)
        self._phase = "over"

    # ---------- 听 ----------
    def _start_listen(self):
        if self._closed or self._phase == "over":
            return
        if self._silent:
            self._phase = "idle"
            self.lbl_state.setText("麦克风已静音（点「静音麦克风」恢复）")
            return
        self._phase = "listen"
        self.lbl_state.setText("我在听…")
        self._listen = _ListenThread(self)
        self._listen.got.connect(self._on_heard)
        self._listen.start()

    def _on_heard(self, text, why):
        if self._closed or self._phase == "over":
            return
        if why == "unclear":
            # 听到了但不像人话（识别器瞎猜出来的串字）。第一次静默重听，
            # 连着第二次才出声说明——真人接电话没听清也是先说一句再让对方重说。
            self._miss += 1
            if self._miss >= 2 and not self._closed:
                self.lbl_state.setText("没听清，再说一遍")
                self.log.append('<span style="color:#8FC98B;">%s</span>：'
                                '刚才没听清，你再说一遍？' % _esc(AI_NAME))
                self._scroll()
                self._phase = "speak"
                self._speak = _SpeakThread("刚才没听清，你再说一遍？", self._style, self)
                self._speak.done.connect(self._after_speak)
                self._speak.start()
                return
            QTimer.singleShot(300, self._start_listen)
            return
        if why != "ok" or not text:
            if why == "unavailable":
                self._no_stt()
                return
            self._miss += 1
            if self._miss >= 3:
                self.lbl_state.setText("还没听到你说话，说一句就行")
            else:
                self.lbl_state.setText("在听…")
            QTimer.singleShot(300 if why == "ok" else 500, self._start_listen)
            return
        self._miss = 0
        self.log.append('<span style="color:#7FB2F0;">你</span>：%s'
                        % _esc(text))
        self._scroll()

        if stt.is_hangup(text):
            self._say_bye()
            return
        self._phase = "think"
        self.lbl_state.setText("小矿在想…")
        self._reply = _ReplyThread(text, self)
        self._reply.got.connect(self._on_reply)
        self._reply.start()

    def _on_reply(self, say, act):
        if self._closed or self._phase == "over":
            return
        say = (say or "").strip() or "嗯，你说。"
        self.log.append('<span style="color:#8FC98B;">%s</span>：%s'
                        % (_esc(AI_NAME), _esc(say)))
        self._scroll()
        if act:
            try:
                self.host.ai_run_action(act)     # 改设置 / 放歌，和聊天窗同一个入口
            except Exception:
                pass
        self._phase = "speak"
        self.lbl_state.setText("小矿在说话…")
        self._speak = _SpeakThread(say, self._style, self)
        self._speak.done.connect(self._after_speak)
        self._speak.start()

    def _after_speak(self):
        if self._closed or self._phase == "over":
            return
        QTimer.singleShot(300, self._start_listen)

    # ---------- 挂断 ----------
    def _say_bye(self):
        self._phase = "speak"
        self.lbl_state.setText("小矿在说话…")
        self.log.append('<span style="color:#8FC98B;">%s</span>：行，那我先挂了，'
                        '有事随时叫我。' % _esc(AI_NAME))
        self._scroll()
        self._speak = _SpeakThread("行，那我先挂了，有事随时叫我。",
                                   self._style, self)
        self._speak.done.connect(self._close_after_bye)
        self._speak.start()

    def _close_after_bye(self):
        self._phase = "over"
        self.lbl_state.setText("通话已结束")
        QTimer.singleShot(400, self.close)

    def _hang_up(self):
        if self._phase == "over":
            self.close()
            return
        self._phase = "over"
        try:
            tts.stop()
        except Exception:
            pass
        self.lbl_state.setText("已挂断")
        QTimer.singleShot(120, self.close)

    def _on_mute(self, checked):
        self._silent = bool(checked)
        self.b_mute.setText("麦克风已静音" if self._silent else "静音麦克风")
        if self._silent:
            self._phase = "idle"
            self.lbl_state.setText("麦克风已静音（点一下恢复）")
        else:
            QTimer.singleShot(300, self._start_listen)

    # ---------- 杂项 ----------
    def _tick(self):
        if self._phase == "over" or self._closed:
            return
        n = int(time.time() - self._t0)
        self.lbl_name.setText("%s · %02d:%02d" % (AI_NAME, n // 60, n % 60))

    def _scroll(self):
        try:
            self.log.moveCursor(self.log.textCursor().End)
            sb = self.log.verticalScrollBar()
            sb.setValue(sb.maximum())
        except Exception:
            pass

    def closeEvent(self, ev):
        self._closed = True
        self._phase = "over"
        for th in (self._listen, self._reply, self._speak):
            try:
                if th is not None and th.isRunning():
                    th.quit()
            except Exception:
                pass
        try:
            self._timer.stop()
        except Exception:
            pass
        try:
            tts.stop()
        except Exception:
            pass
        super().closeEvent(ev)


def _esc(s):
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))
