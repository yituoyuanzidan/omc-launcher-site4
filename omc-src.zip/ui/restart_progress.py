# -*- coding: utf-8 -*-
"""重启进度窗：点了「现在重启」之后，替换文件、退出、拉起新版本这段过程给个看得见的进度。

之前这里只有窗口标题上一句话，点完窗口就消失，看着像程序自己跑了。
这个窗口占前台的 2 秒多，把「替换 → 退出旧版本 → 启动新版本」三段进度走完再退。
"""
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QProgressBar,
                               QVBoxLayout)

_QSS = """
QDialog#RstCard { background: #1E2128; }
QLabel#RstTitle { font-size: 16px; font-weight: 700; color: #FFFFFF; }
QLabel#RstSub { color: #9AA4B4; }
QLabel#RstPct { font-size: 22px; font-weight: 700; color: #4ADE80; }
"""

# 进度区间 → 现在在做什么（左闭右开）
_STAGES = (
    (0, "正在准备替换脚本"),
    (28, "正在退出旧版本"),
    (62, "正在启动新版本"),
    (97, "马上就好"),
)


class RestartProgressDialog(QDialog):
    """无父窗口：主窗口先隐藏了，挂在它下面会被一起藏掉。"""

    def __init__(self, version="", on_done=None, total_ms=2200, step_ms=40):
        super().__init__(None)
        self._on_done = on_done
        self._total = max(400, int(total_ms))
        self._step = max(10, int(step_ms))
        self._elapsed = 0
        self._finished = False

        self.setObjectName("RstCard")
        self.setStyleSheet(_QSS)
        self.setWindowTitle("正在重启 OMC")
        self.setMinimumWidth(440)
        self.setWindowFlag(Qt.WindowContextHelpButtonHint, False)
        # 这时候不该再被点关掉，否则用户会以为更新没做完
        self.setWindowFlag(Qt.WindowCloseButtonHint, False)

        v = QVBoxLayout(self)
        v.setSpacing(10)
        self.lbl_title = QLabel("正在重启换上 %s" % (version or "新版本"))
        self.lbl_title.setObjectName("RstTitle")
        v.addWidget(self.lbl_title)

        self.lbl_sub = QLabel(_STAGES[0][1])
        self.lbl_sub.setObjectName("RstSub")
        self.lbl_sub.setWordWrap(True)
        v.addWidget(self.lbl_sub)

        row = QHBoxLayout()
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(22)
        row.addWidget(self.bar, 1)
        self.lbl_pct = QLabel("0%")
        self.lbl_pct.setObjectName("RstPct")
        self.lbl_pct.setFixedWidth(64)
        self.lbl_pct.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row.addWidget(self.lbl_pct)
        v.addLayout(row)

        self.lbl_tail = QLabel("替换完成后会自动打开新版本，不用手动点。")
        self.lbl_tail.setObjectName("RstSub")
        self.lbl_tail.setWordWrap(True)
        v.addWidget(self.lbl_tail)

        self._timer = QTimer(self)
        self._timer.setInterval(self._step)
        self._timer.timeout.connect(self._tick)

    # ---------- 进度 ----------
    def start(self):
        self.adjustSize()          # 别留一大片空白
        self.show()
        self.raise_()
        self._timer.start()

    def _tick(self):
        self._elapsed += self._step
        pct = min(100, int(self._elapsed * 100 / self._total))
        self.set_progress(pct)
        if pct >= 100:
            self._timer.stop()
            self._finish()

    def set_progress(self, pct):
        pct = max(0, min(100, int(pct)))
        self.bar.setValue(pct)
        self.lbl_pct.setText("%d%%" % pct)
        stage = _STAGES[0][1]
        for lo, text in _STAGES:
            if pct >= lo:
                stage = text
        # 留一点停留，让人看得清最后一句
        if pct >= 100:
            stage = "完成，新版本正在打开"
        self.lbl_sub.setText(stage)

    def _finish(self):
        if self._finished:
            return
        self._finished = True
        self.bar.setValue(100)
        self.lbl_pct.setText("100%")
        # 让 100% 停一下再走，否则窗口一闪就没了
        QTimer.singleShot(260, self._call_done)

    def _call_done(self):
        cb = self._on_done
        self._on_done = None
        if cb:
            try:
                cb()
            except Exception:
                pass
