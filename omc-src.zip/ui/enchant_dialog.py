# -*- coding: utf-8 -*-
"""附魔计算器：RNG 附魔操控 / 铁砧并书（给结果）/ 附魔台书架。

RNG 页复刻 Earthcomputer/EnchantmentCracker 的原理：
拿玩家存档里的 XP 种子（或反推），预测附魔台三格各出什么。
"""
import os
import threading

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QProgressBar, QPushButton, QSpinBox,
                               QTabWidget, QTextEdit, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)
from PySide6.QtWidgets import QSizePolicy

from .flow_layout import FlowLayout

from core import enchant_calc as ec
from core import enchant_rng as rng

SLOT_CN = {"top": "顶槽", "middle": "中槽", "bottom": "底槽"}
SLOT_NUM = ["第 1 格（顶格）", "第 2 格（中格）", "第 3 格（底格）"]


class EnchantCalcWidget(QWidget):
    """附魔计算的全部内容，可嵌进页面，也可以裹一层对话框单独弹。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = {}
        self._build()
        self._fill_list()
        self._tone_boxes()

    def _tone_boxes(self):
        """几块大文本框/列表压一层深底，不然壁纸亮的区域字看不清。"""
        qss = ("background:#161A20;border:1px solid rgba(255,255,255,28);"
               "border-radius:8px;color:#E8ECF3;"
               "QTreeWidget::item, QListWidget::item{"
               "padding:4px;border-radius:6px;background:transparent;color:#E8ECF3;}")
        for cls in (QTextEdit, QListWidget, QTreeWidget):
            for wdg in self.findChildren(cls):
                wdg.setStyleSheet(qss)

    # ---------- 界面 ----------
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(10)

        top = FlowLayout(spacing=10)
        top.addWidget(QLabel("要附在哪件物品上"))
        self.combo_item = QComboBox()
        for key, label, _tags in ec.ITEM_TYPES:
            self.combo_item.addItem(label, key)
        self.combo_item.setFixedWidth(210)
        self.combo_item.currentIndexChanged.connect(self._fill_list)
        top.addWidget(self.combo_item)
        top.addWidget(QLabel("书架"))
        self.spin_shelf = QSpinBox()
        self.spin_shelf.setRange(0, 15)
        self.spin_shelf.setValue(15)
        self.spin_shelf.setFixedWidth(70)
        self.spin_shelf.valueChanged.connect(lambda *_: self._generate())
        top.addWidget(self.spin_shelf)
        self.btn_gen = QPushButton("算一遍")
        self.btn_gen.setObjectName("Primary")
        self.btn_gen.clicked.connect(self._generate)
        top.addWidget(self.btn_gen)
        root.addLayout(top)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        # 页签 0：RNG 附魔操控
        self.rng_panel = RngPanel(self)
        self.tabs.addTab(self.rng_panel, "RNG 附魔操控")

        # 页签 1：铁砧
        p1 = QWidget()
        l1 = QVBoxLayout(p1)
        l1.setContentsMargins(4, 8, 4, 4)
        l1.setSpacing(6)
        hint1 = QLabel("勾选想要的附魔和等级。算的是「先合书、最后一次性上物品」，"
                       "按这个顺序做就能拿到目标，超 39 级会提示。"
                       "（RNG 页会读这里的勾选当作目标）")
        hint1.setObjectName("FieldLabel")
        # 这行说明是整段长句，不换行的话它一个人就要 700 多像素，
        # 把整个「铁砧并书」页顶到 918 宽，窄窗口里右边全看不见。
        hint1.setWordWrap(True)
        l1.addWidget(hint1)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(3)
        self.tree.setHeaderLabels(["附魔", "等级", "备注"])
        self.tree.setColumnWidth(0, 150)
        self.tree.setColumnWidth(1, 90)
        self.tree.setRootIsDecorated(False)
        self.tree.setAlternatingRowColors(True)
        self.tree.itemChanged.connect(self._on_check)
        l1.addWidget(self.tree, 1)
        row1 = QHBoxLayout()
        b_all = QPushButton("全部选上")
        b_all.clicked.connect(lambda: self._check_all(True))
        b_none = QPushButton("全部清空")
        b_none.clicked.connect(lambda: self._check_all(False))
        row1.addWidget(b_all)
        row1.addWidget(b_none)
        row1.addStretch(1)
        l1.addLayout(row1)
        self.out1 = QTextEdit()
        self.out1.setReadOnly(True)
        self.out1.setFont(QFont("Consolas", 10))
        self.out1.setMinimumHeight(260)
        l1.addWidget(self.out1)
        self.page1 = p1
        self.tabs.addTab(p1, "铁砧并书（必得）")

        # 页签 2：附魔台
        p2 = QWidget()
        l2 = QVBoxLayout(p2)
        l2.setContentsMargins(4, 8, 4, 4)
        l2.setSpacing(6)
        hint2 = QLabel("算附魔台要摆几个书架、走哪一档。附魔台本身有随机浮动，"
                       "这里给的是「门槛」——照着摆，目标和等级才有机会刷出来。")
        hint2.setObjectName("FieldLabel")
        hint2.setWordWrap(True)
        l2.addWidget(hint2)
        self.out2 = QTextEdit()
        self.out2.setReadOnly(True)
        self.out2.setFont(QFont("Consolas", 10))
        l2.addWidget(self.out2, 1)
        self.page2 = p2
        self.tabs.addTab(p2, "附魔台（摆几个书架）")

        bottom = QHBoxLayout()
        self.btn_copy = QPushButton("复制当前页")
        self.btn_copy.clicked.connect(self._copy)
        bottom.addWidget(self.btn_copy)
        bottom.addStretch(1)
        root.addLayout(bottom)

    def _fill_list(self, *_):
        keep = {}
        if self._rows:
            for k, (it, combo) in self._rows.items():
                if it.checkState(0) == Qt.Checked:
                    keep[k] = combo.currentData()
        self.tree.blockSignals(True)
        self.tree.clear()
        self._rows = {}
        item = self.combo_item.currentData()
        for eid in ec.available(item):
            info = ec.ENCHANTS[eid]
            name, top_lv, anvil, _w, _mn, _mx, _tags, treasure = info
            it = QTreeWidgetItem([" " + name, "", ""])
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked)
            self.tree.addTopLevelItem(it)
            combo = QComboBox()
            for lv in range(1, top_lv + 1):
                combo.addItem(ec.enchant_label(eid, lv).split(" ")[-1], lv)
            combo.setCurrentIndex(top_lv - 1)
            self.tree.setItemWidget(it, 1, self._wrap(combo))
            notes = []
            if treasure:
                notes.append("宝藏")
            notes.append("铁砧倍率 书×%d / 物品×%d" % (ec.mult_book(eid), anvil))
            it.setText(2, "、".join(notes))
            self._rows[eid] = (it, combo)
        for eid, lv in keep.items():
            if eid in self._rows:
                it, combo = self._rows[eid]
                it.setCheckState(0, Qt.Checked)
                idx = combo.findData(lv)
                if idx >= 0:
                    combo.setCurrentIndex(idx)
        self.tree.blockSignals(False)
        self._generate()

    @staticmethod
    def _wrap(w):
        box = QWidget()
        lay = QHBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(w)
        return box

    def _check_all(self, on):
        self.tree.blockSignals(True)
        for it, _c in self._rows.values():
            it.setCheckState(0, Qt.Checked if on else Qt.Unchecked)
        self.tree.blockSignals(False)
        self._generate()

    def _on_check(self, *_):
        self._generate()

    def targets(self):
        out = {}
        for eid, (it, combo) in self._rows.items():
            if it.checkState(0) == Qt.Checked:
                out[eid] = int(combo.currentData())
        return out

    # ---------- 计算 ----------
    def _generate(self):
        item = self.combo_item.currentData()
        tg = self.targets()
        if not tg:
            self.out1.setPlainText("先勾几个附魔。")
            self.out2.setPlainText("先勾几个附魔。")
            return
        self.out1.setPlainText(self._render_anvil(item, tg))
        self.out2.setPlainText(self._render_table(item, tg))

    def _render_anvil(self, item, tg):
        res = ec.plan(item, tg)
        if res["errors"]:
            return ("这么附不了：\n" + "\n".join("· " + e for e in res["errors"]))
        naive = ec.naive_plan(item, tg)
        L = ["目标：%s　%s"
             % (ec.item_label(item),
                "、".join(ec.enchant_label(e, lv)
                          for e, lv in sorted(tg.items(),
                                              key=lambda kv: ec.info_order(kv[0])))),
             "", "【要准备的书】"]
        for e, lv in sorted(tg.items(), key=lambda kv: ec.info_order(kv[0])):
            tag = "（宝藏：附魔台刷不出，靠村民/箱子/钓鱼）" if ec.is_treasure(e) else ""
            L.append("　· %s%s" % (ec.enchant_label(e, lv), tag))
        L.append("")

        if res["steps"]:
            L.append("【第一阶段：书和书互相合，别先碰装备】")
            for i, s in enumerate(res["steps"], 1):
                L.append("　%2d. 左槽【%s】+ 右槽【%s】" % (i, s["target"], s["sacrifice"]))
                L.append("　　　→ %s" % s["result"])
                L.append("　　　花 %d 级（惩罚 %d + %d）%s"
                         % (s["cost"], s["penalty"][0], s["penalty"][1],
                            "" if s["ok"] else "　← 超 39 级"))
            L.append("")

        f = res["final"]
        L.append("【最后一步：装备只上一次砧】")
        L.append("　左槽【%s】+ 右槽【%s】" % (f["target"], f["sacrifice"]))
        L.append("　→ %s" % f["result"])
        L.append("　花 %d 级（惩罚 %d + %d）%s"
                 % (f["cost"], f["penalty"][0], f["penalty"][1],
                    "" if f["ok"] else "　← 过于昂贵，做不了"))
        L.append("")
        L.append("合计约 %d 级；成品经过 %d 次砧，惩罚 %d"
                 % (res["total"], f["result_uses"], res["final_penalty"]))
        L.append("")

        if res["warnings"]:
            L.append("【要注意】")
            for w in res["warnings"]:
                L.append("　· " + w)
            L.append("")

        if naive["steps"]:
            L.append("【对照：一本一本直接往物品上加】")
            for s in naive["steps"]:
                L.append("　· %s → %d 级（物品第 %d 次上砧）%s"
                         % (s["book"], s["cost"], s["item_uses"],
                            "" if s["ok"] else "　← 已经做不了"))
            L.append("　合计 %d 级，惩罚 %d%s"
                     % (naive["total"], naive["final_penalty"],
                        ("；比上面的方案多花 %d 级" % (naive["total"] - res["total"]))
                        if naive["total"] > res["total"] else ""))
            L.append("")

        L.append("【为什么这么排】")
        L.append("　· 左槽那件留到最后，右槽那件会被消耗；左右反了要多花钱。")
        L.append("　· 每上一次砧，那件的惩罚翻倍（1、3、7、15……），所以书先互相合，物品只上一次。")
        L.append("　· 改名在第一次上砧时一起做，只多 1 级。")
        return "\n".join(L)

    def _render_table(self, item, tg):
        adv = ec.table_advice(item, tg)
        if adv["errors"]:
            return ("这么附不了：\n" + "\n".join("· " + e for e in adv["errors"]))
        L = ["目标：%s　%s"
             % (ec.item_label(item),
                "、".join(ec.enchant_label(e, lv)
                          for e, lv in sorted(tg.items(),
                                              key=lambda kv: ec.info_order(kv[0])))),
             ""]

        ok_rows = [r for r in adv["rows"] if r.get("ok")]
        bad_rows = [r for r in adv["rows"] if not r.get("ok")]

        if ok_rows:
            need = adv["shelves"]
            L.append("【书架】至少摆 %d 个有效书架（最多算 15 个）" % need)
            L.append("　摆法：离附魔台正好 2 格、和台子同层或高一格，书和台子之间不能挡东西。")
            L.append("　" + ec.shelf_note(need))
            L.append("　满配 15 个时三档是：顶槽 2–10、中槽 6–21、底槽 30（30 级满档）")
            L.append("")

            L.append("【每个目标怎么出】")
            for r in ok_rows:
                L.append("　· %s：%s满档能出到 %s（门槛 %d，这档强度上限 %d）"
                         % (r["name"], SLOT_CN[r["slot"]],
                            ec.enchant_label(r["eid"], r["can"]) if r["can"] else "0 级",
                            r["min_cost"], r["power_max"]))
            L.append("")

            shelf_now = int(self.spin_shelf.value())
            rng_ = ec.slot_ranges(shelf_now)
            L.append("【当前 %d 个书架的实际档位】" % shelf_now)
            for slot in ("top", "middle", "bottom"):
                L.append("　%s %d–%d 级" % (SLOT_CN[slot], rng_[slot][0], rng_[slot][1]))
            L.append("")
            L.append("【这档可能出现什么（按强度上限筛）】")
            for slot in ("bottom", "middle", "top"):
                hi = rng_[slot][1]
                pool = ec.pool_at(item, hi)
                if not pool:
                    L.append("　%s：这档太低，出不了附魔" % SLOT_CN[slot])
                    continue
                names = ["%s" % ec.enchant_label(e, lv) for e, lv, _w in pool]
                L.append("　%s（按 %d 级算）：%s"
                         % (SLOT_CN[slot], hi, "、".join(names)))
            L.append("")

            L.append("【操作】")
            L.append("　1. 书架摆够，物品放进去，三个选项就会出来（每项都要青金石）。")
            L.append("　2. 只有真正附魔了，三个选项才会换；走开、拿下来、重进都不会变。")
            L.append("　3. 没刷到想要的，就拿个便宜物品花 1 级刷顶槽，把选项换一批再来。")
            L.append("　4. 附魔台给的等级是随机的（同一档也可能只出低一级），多刷几次。")
            L.append("　5. 想直接知道「这三格到底会出什么」，用第一页 RNG 附魔操控。")
            L.append("")

        if bad_rows:
            L.append("【附魔台刷不出来的】")
            for r in bad_rows:
                L.append("　· %s：%s" % (r["name"], r.get("why", "")))
            if item != "book":
                L.append("　提示：附魔台上放「书」，连经验修补、冰霜行者这些宝藏附魔都能刷出来。")
            L.append("")
        return "\n".join(L)

    def _copy(self):
        w = self.tabs.currentWidget()
        if w is self.rng_panel:
            text = self.rng_panel.out.toPlainText()
        elif w is self.page2:
            text = self.out2.toPlainText()
        else:
            text = self.out1.toPlainText()
        QApplication.clipboard().setText(text)


class RngPanel(QWidget):
    """RNG 附魔操控：读存档种子 / 反推种子 → 预测附魔台三格。"""

    sig_prog = Signal(int, int)
    sig_done = Signal(object)
    sig_state = Signal(str)

    def __init__(self, dlg):
        super().__init__()
        self.dlg = dlg
        self._obs = []          # [(书架, [a, b, c])]
        self._seeds = None      # array('i') 候选种子
        self._xseed = None
        self._stop = False
        self._th = None
        self._worlds = []
        self._build()
        self.sig_prog.connect(self._on_prog)
        self.sig_done.connect(self._on_done)
        self.sig_state.connect(self.lbl_state.setText)
        self.scan_saves()

    # ---------- 界面 ----------
    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(4, 8, 4, 4)
        v.setSpacing(8)

        hint = QLabel(
            "原理和电脑上的 EnchantmentCracker 一样：拿你存档里的 XP 种子，"
            "或者用附魔台上的三个数字反推出种子，然后直接算出三格各会出什么附魔。\n"
            "只对原版服务端准（Fabric/Forge 不影响）；Paper / Purpur / Leaves 这类"
            "改过随机数的核心会算错。附魔台开界面不会改种子——拆书架再看一次数字，"
            "是同一颗种子，所以可以多记几组来夹逼。")
        hint.setWordWrap(True)
        hint.setObjectName("FieldLabel")
        v.addWidget(hint)

        r1 = QHBoxLayout()
        r1.setSpacing(8)
        r1.addWidget(QLabel("存档"))
        self.combo_save = QComboBox()
        self.combo_save.setMinimumWidth(180)
        self.combo_save.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        r1.addWidget(self.combo_save, 1)
        self.btn_scan = QPushButton("重新扫描")
        self.btn_scan.clicked.connect(self.scan_saves)
        r1.addWidget(self.btn_scan)
        self.btn_use = QPushButton("用这个存档")
        self.btn_use.setObjectName("Primary")
        self.btn_use.clicked.connect(self.use_save)
        r1.addWidget(self.btn_use)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        r2.setSpacing(8)
        r2.addWidget(QLabel("或直接填种子"))
        self.edit_seed = QLineEdit()
        self.edit_seed.setPlaceholderText("十进制，或 0x 开头的十六进制（XpSeed）")
        r2.addWidget(self.edit_seed, 1)
        self.btn_manual = QPushButton("用这个种子")
        self.btn_manual.clicked.connect(self.use_manual)
        r2.addWidget(self.btn_manual)
        v.addLayout(r2)

        r3 = QHBoxLayout()
        r3.setSpacing(8)
        r3.addWidget(QLabel("物品"))
        self.combo_item2 = QComboBox()
        self.combo_item2.setFixedWidth(210)
        for key, label in rng.RNG_ITEMS:
            self.combo_item2.addItem(label, key)
        idx = self.combo_item2.findData("diamond_sword")
        if idx >= 0:
            self.combo_item2.setCurrentIndex(idx)
        self.combo_item2.currentIndexChanged.connect(self._refresh_predict)
        r3.addWidget(self.combo_item2)
        r3.addWidget(QLabel("（附魔台里放的东西，决定能出哪些附魔）"))
        r3.addStretch(1)
        v.addLayout(r3)

        # 这一排以前是死板的横排，窗口一窄就把右边的「记下这组」挤出去；
        # 换成能折行的布局，窄窗口下自动排成两行。
        r4 = FlowLayout(spacing=6)
        r4.addWidget(QLabel("附魔台上的三个数字　书架"))
        self.sp_obs_shelf = QSpinBox()
        self.sp_obs_shelf.setRange(0, 15)
        self.sp_obs_shelf.setValue(15)
        self.sp_obs_shelf.setFixedWidth(64)
        r4.addWidget(self.sp_obs_shelf)
        r4.addWidget(QLabel("个 →"))
        self.sp_a = QSpinBox()
        self.sp_b = QSpinBox()
        self.sp_c = QSpinBox()
        for sp in (self.sp_a, self.sp_b, self.sp_c):
            sp.setRange(0, 64)
            sp.setFixedWidth(64)
        for sp, tag in ((self.sp_a, "上"), (self.sp_b, "中"), (self.sp_c, "下")):
            r4.addWidget(QLabel(tag))
            r4.addWidget(sp)
        self.btn_add = QPushButton("记下这组")
        self.btn_add.clicked.connect(self.add_obs)
        r4.addWidget(self.btn_add)
        v.addLayout(r4)

        self.list_obs = QListWidget()
        self.list_obs.setMaximumHeight(84)
        v.addWidget(self.list_obs)

        r5 = FlowLayout(spacing=8)
        self.btn_del = QPushButton("删掉选中")
        self.btn_del.clicked.connect(self.del_obs)
        self.btn_clear = QPushButton("清空观测")
        self.btn_clear.clicked.connect(self.clear_obs)
        r5.addWidget(self.btn_del)
        r5.addWidget(self.btn_clear)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setFixedWidth(200)
        r5.addWidget(self.bar)
        self.lbl_state = QLabel("至少记 3 组观测才能反推（拆书架再看一次，别点附魔）")
        self.lbl_state.setObjectName("FieldLabel")
        self.lbl_state.setWordWrap(True)
        self.lbl_state.setMaximumWidth(260)
        r5.addWidget(self.lbl_state)
        self.btn_crack = QPushButton("开始反推（约 3 分钟）")
        self.btn_crack.setObjectName("Primary")
        self.btn_crack.clicked.connect(self.start_crack)
        r5.addWidget(self.btn_crack)
        v.addLayout(r5)

        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setFont(QFont("Microsoft YaHei UI", 10))
        v.addWidget(self.out, 1)

    # ---------- 存档 ----------
    def scan_saves(self):
        from core import enchant_world as ew
        game_dir = ""
        try:
            from core.config import Config
            game_dir = Config().get("game_dir") or ""
        except Exception:
            pass
        self._worlds = []
        try:
            self._worlds = ew.scan_all(game_dir)
        except Exception:
            self._worlds = []
        self.combo_save.clear()
        if not self._worlds:
            self.combo_save.addItem("没找到存档（先进一次单人世界，再点重新扫描）", None)
            self.lbl_state.setText("没找到存档。只能用下面的「三个数字反推」。")
            return
        for world, seeds in self._worlds:
            s = seeds[0]
            name = os.path.basename(world.rstrip("\\/"))
            self.combo_save.addItem(
                "%s ・ %s ・ %d 级 ・ 种子 %d"
                % (name, ew.seed_age_text(s["mtime"]), s["xp_level"], s["xseed"]),
                world)
        self.lbl_state.setText("找到 %d 个存档，选一个点「用这个存档」。"
                               % len(self._worlds))

    def _world_seed(self, world):
        for w, seeds in self._worlds:
            if w == world and seeds:
                return seeds[0]
        return None

    def use_save(self):
        world = self.combo_save.currentData()
        if not world:
            self.out.setPlainText("没找到存档。\n"
                                  "先在启动器里进一次单人世界，存档里才会写进玩家数据；"
                                  "或者用上面「三个数字反推」的路子。")
            return
        info = self._world_seed(world)
        if not info:
            self.out.setPlainText("这个存档里没读到玩家数据（可能还没进过世界）。")
            return
        self._xseed = info["xseed"]
        self._seeds = None
        self._render_predict(self._xseed, info["xp_level"])

    def use_manual(self):
        txt = (self.edit_seed.text() or "").strip()
        if not txt:
            return
        try:
            xp = int(txt, 16) if txt.lower().startswith("0x") else int(txt)
        except Exception:
            self.out.setPlainText("这个数填得不对，填十进制整数或者 0x 开头的十六进制。")
            return
        if xp > 0x7FFFFFFF:
            xp -= 0x100000000
        self._xseed = xp
        self._seeds = None
        self._render_predict(self._xseed, 0)

    # ---------- 观测 ----------
    def add_obs(self):
        shelves = int(self.sp_obs_shelf.value())
        nums = [int(self.sp_a.value()), int(self.sp_b.value()),
                int(self.sp_c.value())]
        if min(nums) < 1:
            self.lbl_state.setText("三格数字都要填（附魔台上至少显示 1）。")
            return
        if max(nums) > 60:
            self.lbl_state.setText("数字这么大不像附魔台的等级，检查一下。")
            return
        self._obs = [o for o in self._obs if o[0] != shelves]
        self._obs.append((shelves, nums))
        self._obs.sort(key=lambda o: -o[0])
        self._sync_obs()
        # 已经有候选就当场过滤，不用重扫
        if self._seeds is not None and len(self._seeds) > 0:
            self._seeds = rng.filter_seeds(self._seeds, shelves, nums)
            self._after_filter()

    def del_obs(self):
        row = self.list_obs.currentRow()
        if 0 <= row < len(self._obs):
            del self._obs[row]
            self._sync_obs()

    def clear_obs(self):
        self._obs = []
        self._sync_obs()

    def _sync_obs(self):
        self.list_obs.clear()
        for shelves, nums in self._obs:
            self.list_obs.addItem(
                QListWidgetItem("书架 %2d 个　→　%2d / %2d / %2d"
                                % (shelves, nums[0], nums[1], nums[2])))
        if len(self._obs) < 3:
            self.lbl_state.setText(
                "已记 %d 组；至少 3 组（把书架拆到别的数量，再看一次三个数字）"
                % len(self._obs))
        else:
            self.lbl_state.setText("已记 %d 组，可以开始反推。" % len(self._obs))

    # ---------- 反推 ----------
    def start_crack(self):
        if self._th and self._th.is_alive():
            self._stop = True
            self.lbl_state.setText("正在停止反推……")
            return
        if len(self._obs) < 3:
            self.lbl_state.setText(
                "至少 3 组观测。做法：附魔台开着时把书架拆掉几个（回到台子前），"
                "三个数字会变，再记一组；全程别点附魔，种子就不会变。")
            return
        groups = [(s, n) for s, n in self._obs]
        self._stop = False
        self._seeds = None
        self.btn_crack.setEnabled(False)
        self.bar.setValue(0)
        self.lbl_state.setText("正在反推……")
        self.out.setPlainText("正在扫全部 2^32 个种子（%d 个进程并行，已降优先级，"
                              "不会把机器拖死），大约 3 分钟。\n"
                              "期间别关这个窗口；想停就再点一次按钮。"
                              % rng.default_workers())

        def work():
            try:
                seeds, trunc = rng.crack_all(
                    groups, workers=rng.default_workers(),
                    progress=lambda pct, n: self.sig_prog.emit(pct, n),
                    should_stop=lambda: self._stop)
            except Exception as e:
                seeds, trunc = e, True
            self.sig_done.emit((seeds, trunc))

        self._th = threading.Thread(target=work, daemon=True)
        self._th.start()

    def _on_prog(self, pct, n):
        self.bar.setValue(int(pct))
        self.lbl_state.setText("正在反推…… %d%%　已命中 %d 个" % (pct, n))

    def _on_done(self, payload):
        seeds, trunc = payload
        self.btn_crack.setEnabled(True)
        self.bar.setValue(100)
        if isinstance(seeds, Exception):
            self.lbl_state.setText("反推失败")
            self.out.setPlainText("反推失败：%s\n\n可以改用「直接填种子」或者读存档。" % seeds)
            return
        self._seeds = seeds
        self.lbl_state.setText("反推完成，命中 %d 个种子" % len(seeds))
        if trunc:
            self.lbl_state.setText("命中太多被截断了——再记一组观测（又是别的书架数）重新反推。")
        self._after_filter()

    def _after_filter(self):
        n = 0 if self._seeds is None else len(self._seeds)
        if n == 0:
            self.out.setPlainText(
                "没有种子能同时满足这些数字。检查一下：\n"
                "· 每组的三格数字是不是从同一个附魔台界面抄的\n"
                "· 书架数有没有填错（摆了几个就填几个，最多 15 个有效）\n"
                "· 中途有没有真的点过附魔（点了数字就换了）")
            return
        if n > 60:
            self.out.setPlainText(
                "还剩 %d 个候选，信息量不够。\n\n"
                "再做一步：回游戏把书架拆到另一个数量（比如 3 个），"
                "看一眼新的三个数字，点「记下这组」——不用重新反推，"
                "会在这 %d 个候选里当场过滤。" % (n, n))
            return
        item = self.combo_item2.currentData()
        shelf_default = self._obs[0][0] if self._obs else 15
        blocks = ["命中 %d 个种子。下面是每个候选在本附魔台（%d 个书架）里的三格结果：\n"
                  % (n, shelf_default)]
        for xp in list(self._seeds)[:20]:
            blocks.append(self._render_one(xp, shelf_default, item))
        if n > 20:
            blocks.append("……另有 %d 个候选没列。" % (n - 20))
        self.out.setPlainText("\n".join(blocks))

    # ---------- 预测 ----------
    def _refresh_predict(self, *_):
        if self._xseed is not None:
            self._render_predict(self._xseed, 0)
        elif self._seeds is not None:
            self._after_filter()

    def _render_predict(self, xp, xp_level):
        item = self.combo_item2.currentData()
        shelf = int(self.sp_obs_shelf.value())
        self.out.setPlainText(self._render_one(xp, shelf, item, xp_level))

    def _render_one(self, xp, shelves, item, xp_level=0):
        try:
            p = rng.predict(xp, shelves, item)
        except Exception as e:
            return "种子 %d 预测失败：%s" % (xp, e)
        tg = {}
        try:
            tg = self.dlg.targets()
        except Exception:
            tg = {}
        L = ["种子 %d（0x%08X）　物品：%s　书架：%d 个"
             % (xp, xp & 0xFFFFFFFF, rng.item_label(item), shelves)]
        if xp_level:
            L.append("存档里记的玩家等级：%d" % xp_level)
        if tg:
            L.append("目标（「铁砧并书」页勾的）：%s"
                     % "、".join(rng.ench_label(e, lv) for e, lv in tg.items()))
        L.append("")
        hit_any = []
        for i, slot in enumerate(p["slots"]):
            head = "  %s　%d 级" % (SLOT_NUM[i], slot["level"])
            if not slot["usable"]:
                L.append(head + "　← 等级不够，这一格在游戏里是灰的")
                continue
            if not slot["enchants"]:
                L.append(head + "　← 这一格什么附魔都没有")
                continue
            parts = []
            hits = 0
            for e, lv in slot["enchants"]:
                mark = ""
                if e in tg:
                    if lv >= tg[e]:
                        mark = " ★目标"
                        hits += 1
                    else:
                        mark = "（目标要 %d 级，不够）" % tg[e]
                parts.append(rng.ench_label(e, lv) + mark)
            L.append(head + "：" + "、".join(parts))
            if hits:
                hit_any.append(i)
        L.append("")
        if hit_any:
            L.append("→ 点第 %s 格就能拿到目标。"
                     % "、".join(str(i + 1) for i in hit_any))
            L.append("　（真正点之前，先确认三个数字还是这几行——数字变了说明种子变了）")
        elif tg:
            L.append("→ 这三格都不出你要的。")
            L.append("　可选：拿便宜东西花 1 级把顶格刷掉（数字会全换一批），"
                     "再回来读一次存档/重新反推。")
        L.append("")
        L.append("提示：上表是「现在这一刻」的种子算出来的。只要不真的附魔，"
                 "关掉界面、走开、拿下来都不会变。")
        return "\n".join(L)

