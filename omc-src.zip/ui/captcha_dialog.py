# -*- coding: utf-8 -*-
"""人机验证弹窗：只有把图里的字符输对，才允许往下走（登录 / 注册）。

用法：
    from .captcha_dialog import require_human
    if not require_human(self, "登录"):
        return
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QVBoxLayout)

from core import captcha

_CARD_QSS = """
QDialog#AccountCard { background: #1E2128; }
QLabel#FieldLabel { color: #8B93A1; }
QLineEdit { background:#151820; color:#E8EDF5; border:1px solid #2A2E38;
            border-radius:8px; padding:7px 9px; }
QPushButton { background:#2A2F3A; color:#E8EDF5; border:1px solid #343A46;
              border-radius:8px; padding:6px 12px; }
QPushButton:hover { background:#333A47; }
QPushButton#PrimaryButton { background:#2E5B45; border:1px solid #3B7A5C; }
"""

MAX_FAILS = 5          # 错 5 次就关掉，别让人在这页反复试


class CaptchaDialog(QDialog):
    """4 位图形验证码。输对了 accept()，输错刷新一张新的。"""

    def __init__(self, parent=None, action="登录"):
        super().__init__(parent)
        self.setObjectName("AccountCard")
        self.setWindowTitle("人机验证")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(360)
        self._action = action or "登录"
        self._fails = 0
        self._code = ""

        v = QVBoxLayout(self)
        v.setSpacing(10)

        tip = QLabel("确认是人在操作，才能%s。把下面图里的 4 个字符输进去"
                     "（不区分大小写）。" % self._action)
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        img_row = QHBoxLayout()
        self.img = QLabel()
        self.img.setFixedSize(200, 64)
        img_row.addWidget(self.img)
        self.b_new = QPushButton("换一张")
        self.b_new.setFixedWidth(84)
        self.b_new.clicked.connect(self._refresh)
        img_row.addWidget(self.b_new)
        img_row.addStretch(1)
        v.addLayout(img_row)

        self.in_code = QLineEdit()
        self.in_code.setPlaceholderText("看图输入 4 个字符")
        self.in_code.setMaxLength(6)
        self.in_code.returnPressed.connect(self._confirm)
        v.addWidget(self.in_code)

        self.lbl_err = QLabel("")
        self.lbl_err.setStyleSheet("color:#E07070;")
        self.lbl_err.setWordWrap(True)
        v.addWidget(self.lbl_err)

        row = QHBoxLayout()
        row.addStretch(1)
        b_cancel = QPushButton("取消")
        b_cancel.clicked.connect(self.reject)
        row.addWidget(b_cancel)
        self.b_ok = QPushButton("验证并继续")
        self.b_ok.setObjectName("PrimaryButton")
        self.b_ok.clicked.connect(self._confirm)
        row.addWidget(self.b_ok)
        v.addLayout(row)

        self._refresh()
        self.in_code.setFocus()

    # ---------- 内部 ----------
    def _refresh(self):
        self._code = captcha.new_code(4)
        self.img.setPixmap(captcha.render(self._code))
        self.in_code.clear()
        self.in_code.setFocus()

    def _confirm(self):
        got = (self.in_code.text() or "").strip().upper()
        if not got:
            self.lbl_err.setText("先看图把字符输进去")
            return
        if got == self._code.upper():
            self.accept()
            return
        self._fails += 1
        left = MAX_FAILS - self._fails
        if left <= 0:
            self.lbl_err.setText("错太多次了，关掉重试一次")
            self.reject()
            return
        self.lbl_err.setText("不对，换一张重新看图（还能再试 %d 次）" % left)
        self._refresh()


def require_human(parent=None, action="登录"):
    """弹人机验证，通过返回 True。用户取消或错太多次返回 False。"""
    try:
        dlg = CaptchaDialog(parent, action)
        return dlg.exec_() == QDialog.Accepted
    except Exception:
        # 验证组件本身出问题时不要把人挡在门外
        return True
