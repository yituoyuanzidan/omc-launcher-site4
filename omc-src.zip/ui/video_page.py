# -*- coding: utf-8 -*-
"""刷视频：只推《我的世界》。

- 上滑 / 滚轮向上 = 上一条，下滑 / 滚轮向下 = 下一条
- B 站的能直接在窗口里播；油管只能看封面 + 中文标题（YouTube 视频流和字幕都加了
  防抓取，本机拿不到可播直链，也不给逐句字幕），抖音和小红书要登录，只给入口
- 只读：没有任何评论、点赞、关注之类的入口
- 卡顿控制：列表、直链、封面、翻译全在后台，切条时先停旧播放器再换源
"""
import time
import urllib.request

from PySide6.QtCore import (QEvent, QPoint, QPointF, QSize, QThread, QTimer,
                            QUrl, Qt, Signal)
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMenu, QPushButton, QSizePolicy, QSlider,
    QStackedWidget, QVBoxLayout, QWidget,
)

from core import modlang, videofeed, videoproxy
from . import media_compat as mc
from .flow_layout import FlowLayout
from .media_compat import connect_error, make_audio, set_source
from .pause_overlay import PauseOverlay

try:
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAS_VIDEO = True
except Exception:
    QVideoWidget = None
    HAS_VIDEO = False


def _alive(thread):
    """线程还活着吗？

    QThread 一旦跑完、deleteLater 已经执行，C++ 那边就没了，这时再问
    isRunning() 会抛 RuntimeError（libshiboken: Internal C++ object already
    deleted）。以前 goto 里直接列表推导式问 isRunning，旧播放线程刚好销毁就
    整条切条流程被打断——表现出来就是「点了视频播不起来」。
    """
    if thread is None:
        return False
    try:
        return bool(thread.isRunning())
    except RuntimeError:
        return False
    except Exception:
        return False


class _FeedWorker(QThread):
    done = Signal(str, object, str, int)   # platform, items, err, 丢掉的条数

    def __init__(self, platform, page=1, category="", query="", parent=None,
                 kinds=None, skip=None, scene="", kind="both"):
        super().__init__(parent)
        self.platform = platform
        self.page = page
        self.category = category
        self.query = query
        self.kinds = list(kinds or [])
        self.skip = set(skip or ())
        self.scene = scene
        self.kind = kind
        self._cancel = False

    def cancel(self):
        """换了专区/平台就别再要这一批的结果了，回来也是旧内容。"""
        self._cancel = True

    def run(self):
        try:
            if self._cancel:
                return
            if self.platform in ("douyin", "xiaohongshu"):
                self.done.emit(self.platform, [], "这个平台要登录，拿不到列表", 0)
                return
            if self.query:
                items, dropped = videofeed.search(self.query, self.platform,
                                                  kinds=self.kinds)
            else:
                items, dropped = videofeed.feed(self.platform, self.category,
                                                 self.page, kinds=self.kinds,
                                                 skip=self.skip,
                                                 scene=self.scene,
                                                 kind=self.kind)
            if self._cancel:
                return
            self.done.emit(self.platform, items, "", dropped)
        except Exception as e:
            if not self._cancel:
                self.done.emit(self.platform, [], str(e), 0)


class _ModWorker(QThread):
    """按当前这条视频的标题去 Modrinth 认模组（联网，别卡 UI）。"""
    done = Signal(object)

    def __init__(self, video, parent=None):
        super().__init__(parent)
        self.video = dict(video or {})

    def run(self):
        try:
            from core import modmatch
            res = modmatch.find(self.video)
        except Exception as e:
            res = {"items": [], "used": [], "note": "查询失败：%s" % e}
        self.done.emit(res)


class _ModDialog(QDialog):
    """这条视频相关模组的结果窗。双击一条直接打开 Modrinth 页面。"""

    def __init__(self, video_title, result, parent=None):
        super().__init__(parent)
        self.setWindowTitle("这条视频相关的模组")
        self.resize(760, 540)
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 12, 14, 12)
        head = QLabel("视频：%s" % (video_title or "（无标题）"))
        head.setWordWrap(True)
        head.setObjectName("PageSub")
        v.addWidget(head)
        note = (result or {}).get("note") or ""
        self.lbl_note = QLabel(note if note else
                               "按标题和标签认出来的，双击一条打开模组页；"
                               "点错了也别慌，只是跳网页，不会动你的游戏。")
        self.lbl_note.setWordWrap(True)
        v.addWidget(self.lbl_note)

        self.lst = QListWidget()
        for it in (result or {}).get("items") or []:
            two = it.get("title") or ""
            if it.get("level") and it.get("level") != "完全同名":
                two = "%s（%s）" % (two, it["level"])
            line2 = "命中「%s」 · %s 次下载 · %s" % (
                it.get("matched") or "", it.get("downloads_text") or "0",
                it.get("matched_by") or "")
            line3 = (it.get("desc") or "").strip()
            item = QListWidgetItem("%s\n%s\n%s" % (two, line2, line3) if line3
                                   else "%s\n%s" % (two, line2))
            item.setData(Qt.UserRole, it.get("url") or "")
            self.lst.addItem(item)
        if self.lst.count():
            self.lst.setCurrentRow(0)
        self.lst.itemDoubleClicked.connect(lambda _i: self.open_selected())
        v.addWidget(self.lst, 1)

        row = QHBoxLayout()
        self.btn_open = QPushButton("打开模组页")
        self.btn_open.clicked.connect(self.open_selected)
        row.addWidget(self.btn_open)
        self.btn_copy = QPushButton("复制模组名")
        self.btn_copy.clicked.connect(self.copy_selected)
        row.addWidget(self.btn_copy)
        row.addStretch(1)
        btn_close = QPushButton("关闭")
        btn_close.clicked.connect(self.reject)
        row.addWidget(btn_close)
        v.addLayout(row)

    def _sel(self):
        it = self.lst.currentItem() if self.lst.count() else None
        return it

    def open_selected(self):
        it = self._sel()
        if it is None:
            return
        url = it.data(Qt.UserRole) or ""
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def copy_selected(self):
        it = self._sel()
        if it is None:
            return
        name = (it.text() or "").split("\n")[0].split("（")[0]
        try:
            QApplication.clipboard().setText(name)
            self.lbl_note.setText("已复制：%s" % name)
        except Exception:
            pass


class _PlayWorker(QThread):
    done = Signal(str, str, str)      # vid, url, err

    def __init__(self, vid, cid=None, platform="bilibili", parent=None):
        super().__init__(parent)
        self.vid = vid
        self.cid = cid
        self.platform = platform

    def run(self):
        try:
            if self.platform == "youtube":
                url, err = videofeed.yt_play(self.vid)
            else:
                url, err = videofeed.bili_play(self.vid, self.cid)
            self.done.emit(self.vid, url, err)
        except Exception as e:
            self.done.emit(self.vid, "", str(e))


class _BgmWorker(QThread):
    """后台去拿这条视频的简介，把背景音乐抠出来（界面线程不发网络请求）。"""
    done = Signal(str, str)           # vid, bgm

    def __init__(self, item, parent=None):
        super().__init__(parent)
        self.item = dict(item or {})

    def run(self):
        vid = self.item.get("id") or ""
        try:
            d = videofeed.info(self.item)
            bgm = videofeed.find_bgm(d.get("desc") or "")
            if not bgm:
                bgm = videofeed.find_bgm(d.get("title") or "")
            self.done.emit(vid, bgm)
        except Exception:
            self.done.emit(vid, "")


class _SubWorker(QThread):
    done = Signal(str, object, str)   # vid, [(t, text)], err

    def __init__(self, vid, parent=None):
        super().__init__(parent)
        self.vid = vid

    def run(self):
        try:
            code, segs, err = videofeed.yt_subtitles(self.vid)
            self.done.emit(self.vid, segs, err)
        except Exception as e:
            self.done.emit(self.vid, [], str(e))


class _TrWorker(QThread):
    done = Signal(str, object)

    def __init__(self, vid, texts, parent=None):
        super().__init__(parent)
        self.vid = vid
        self.texts = texts

    def run(self):
        try:
            got = modlang.translate_texts(self.texts)
        except Exception:
            got = {}
        self.done.emit(self.vid, got)


class _AuthorWorker(QThread):
    """取某个 UP 主 / 频道的主页数据（含全部投稿）。"""
    done = Signal(object, object, str)

    def __init__(self, item, parent=None):
        super().__init__(parent)
        self.item = dict(item or {})

    def run(self):
        try:
            info, vids, err = videofeed.author_page(self.item, need=30)
        except Exception as e:
            info, vids, err = {}, [], "取作者主页失败：%s" % e
        self.done.emit(info, vids, err)


class _AvatarWorker(QThread):
    """下作者头像（放后台，避免卡界面）。"""

    done = Signal(bytes)

    def __init__(self, url, parent=None):
        super().__init__(parent)
        self.url = url

    def run(self):
        data = b""
        if self.url:
            try:
                req = urllib.request.Request(
                    self.url, headers={"User-Agent": videofeed.UA,
                                       "Referer": "https://www.bilibili.com/"})
                op = urllib.request.build_opener(
                    urllib.request.ProxyHandler({}))
                data = op.open(req, timeout=8).read()
            except Exception:
                data = b""
        self.done.emit(data)


class AuthorDialog(QDialog):
    """UP 主主页：头像 + 名字 + 粉丝/投稿数 + 全部视频的封面标题网格。"""

    def __init__(self, info, videos, parent=None):
        super().__init__(parent)
        self.videos = list(videos or [])
        self.picked = -1
        self.setWindowTitle("UP 主主页")
        self.resize(880, 640)
        self.setMinimumSize(620, 460)

        v = QVBoxLayout(self)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(12)
        self.avatar = QLabel("")
        self.avatar.setFixedSize(64, 64)
        self.avatar.setAlignment(Qt.AlignCenter)
        self.avatar.setStyleSheet(
            "background:#eef1f6;border-radius:32px;color:#8b93a6;font-size:13px;")
        self.avatar.setText("头像")
        head.addWidget(self.avatar)

        col = QVBoxLayout()
        col.setSpacing(2)
        self.lbl_name = QLabel(info.get("name") or "未知作者")
        self.lbl_name.setStyleSheet("font-size:18px;font-weight:700;")
        col.addWidget(self.lbl_name)
        bits = []
        if info.get("fans"):
            bits.append("粉丝 %s" % _fmt_num(info.get("fans")))
        elif info.get("fans_text"):
            bits.append(str(info.get("fans_text")))
        if info.get("count"):
            bits.append("投稿 %s" % _fmt_num(info.get("count")))
        bits.append("这里共 %d 条" % len(self.videos))
        self.lbl_stat = QLabel(" · ".join(bits))
        self.lbl_stat.setObjectName("PageSub")
        col.addWidget(self.lbl_stat)
        if info.get("sign"):
            sign = QLabel(info.get("sign"))
            sign.setObjectName("FieldLabel")
            sign.setWordWrap(True)
            col.addWidget(sign)
        head.addLayout(col, 1)
        v.addLayout(head)

        self.list = QListWidget()
        self.list.setViewMode(QListWidget.IconMode)
        self.list.setIconSize(QSize(168, 96))
        self.list.setGridSize(QSize(190, 154))
        self.list.setResizeMode(QListWidget.Adjust)
        self.list.setMovement(QListWidget.Static)
        self.list.setSpacing(8)
        self.list.setWordWrap(True)
        self.list.setUniformItemSizes(True)
        self.list.setStyleSheet(
            "QListWidget{background:#ffffff;border:1px solid #e3e7ee;"
            "border-radius:10px;padding:8px;}"
            "QListWidget::item{border-radius:8px;}"
            "QListWidget::item:selected{background:#e8f0ff;}")
        for it in self.videos:
            title = it.get("title") or "（无标题）"
            if it.get("duration"):
                title += "\n" + str(it.get("duration"))
            item = QListWidgetItem(title)
            item.setData(Qt.UserRole, it)
            item.setTextAlignment(Qt.AlignHCenter | Qt.AlignTop)
            self.list.addItem(item)
        self.list.itemDoubleClicked.connect(self._pick)
        self.list.itemActivated.connect(self._pick)
        v.addWidget(self.list, 1)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.btn_web = QPushButton("在平台上打开主页")
        self.btn_web.clicked.connect(self._open_web)
        bar.addWidget(self.btn_web)
        bar.addStretch(1)
        self.btn_go = QPushButton("看这条")
        self.btn_go.setMinimumWidth(96)
        self.btn_go.clicked.connect(lambda: self._pick(self.list.currentItem()))
        bar.addWidget(self.btn_go)
        btn_close = QPushButton("关闭")
        btn_close.clicked.connect(self.reject)
        bar.addWidget(btn_close)
        v.addLayout(bar)

        self._info = info
        self._nam = QNetworkAccessManager(self)
        self._nam.finished.connect(self._on_cover)
        self._avatar_worker = None
        if info.get("face"):
            self._avatar_worker = _AvatarWorker(info.get("face"), self)
            self._avatar_worker.done.connect(self._on_avatar)
            self._avatar_worker.start()
        # 封面也异步补，先给文字占位
        self._queue = [i for i, it in enumerate(self.videos) if it.get("cover")]
        self._pump(4)

    def _pump(self, n):
        """一次只并发 n 张封面，下完一张再补一张。"""
        for _ in range(n):
            if not self._queue:
                return
            i = self._queue.pop(0)
            url = self.videos[i].get("cover") or ""
            req = QNetworkRequest(QUrl(url))
            req.setRawHeader(b"User-Agent", videofeed.UA.encode())
            req.setRawHeader(b"Referer", b"https://www.bilibili.com/")
            reply = self._nam.get(req)
            reply.setProperty("idx", i)

    def _on_cover(self, reply):
        i = reply.property("idx")
        try:
            data = reply.readAll()
            pm = QPixmap()
            pm.loadFromData(data)
            if not pm.isNull() and i is not None and 0 <= int(i) < self.list.count():
                pm = pm.scaled(168, 96, Qt.KeepAspectRatioByExpanding,
                               Qt.SmoothTransformation)
                self.list.item(int(i)).setIcon(QIcon(pm))
        except Exception:
            pass
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
            self._pump(1)

    def _on_avatar(self, data):
        if not data:
            return
        pm = QPixmap()
        if pm.loadFromData(data) and not pm.isNull():
            self.avatar.setStyleSheet("background:transparent;border-radius:32px;")
            self.avatar.setPixmap(pm.scaled(64, 64, Qt.KeepAspectRatioByExpanding,
                                            Qt.SmoothTransformation))

    def _open_web(self):
        url = self._info.get("page_url") or ""
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def _pick(self, item):
        if item is None:
            return
        self.picked = self.list.row(item)
        self.accept()


def _fmt_num(n):
    try:
        n = int(n)
    except Exception:
        return str(n or "")
    if n >= 10000:
        return "%.1f 万" % (n / 10000.0)
    return str(n)


class VideoPage(QWidget):
    """一屏一条的 MC 视频流。"""

    _yt_ready = Signal(bool, str)      # 后台查完网络地区后回到界面线程
    _geo_done = Signal(object)         # 地区复查结果（dict，见 videofeed.visitor_region）

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = getattr(host, "config", None)
        self.platform = "bilibili"
        self.items = []
        self.idx = -1
        self.page = 1
        self._seen = set()              # 这次已经刷到过的 (platform, id)，不再重复
        self._pending_feed = False      # 上批没回来时按下的「换一批」
        self._feed = None
        self._author = None             # 作者主页线程
        self._author_name = ""          # 当前是不是在翻某个作者
        self._author_info = {}
        self._play = None
        self._sub = None
        self._tr = None
        self._player = None
        self._audio = None
        self._cover_cache = {}
        self._wheel_acc = 0
        self._wheel_t = 0.0
        self._cover_pm = None            # 当前封面的原图，按画面区等比缩放
        self._nam = QNetworkAccessManager(self)
        self._nam.finished.connect(self._on_cover)
        self._pending_cover = None       # 当前封面请求（切条时取消）
        self._prefetch = []             # 预取直链的线程，别被 GC 掉
        self._drag_y = None
        self._sub_timer = None
        self._title_zh = ""
        self._keyword = ""              # 站内搜索词，空就是按类型推荐

        v = QVBoxLayout(self)
        self._vbox = v                    # 全屏观看时要把画面区之外的控件都藏起来
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)

        # ---- 顶部工具行（自动换行：窗口窄了会折到下一行，不会被切掉） ----
        row = FlowLayout(spacing=8)
        self.btn_platforms = {}
        for key, text in (("bilibili", "B 站"), ("youtube", "油管"),
                          ("douyin", "抖音"), ("xiaohongshu", "小红书")):
            b = QPushButton(text)
            b.setCheckable(True)
            b.setChecked(key == "bilibili")
            b.setMinimumWidth(56)
            b.clicked.connect(lambda _x=False, k=key: self.switch_platform(k))
            row.addWidget(b)
            self.btn_platforms[key] = b
        self.btn_more = QPushButton("换一批")
        self.btn_more.clicked.connect(self.next_batch)
        row.addWidget(self.btn_more)
        self.btn_refresh = QPushButton("刷新")
        self.btn_refresh.setToolTip("重新拉一遍列表：正在看的这条不换，播放进度也不动")
        self.btn_refresh.clicked.connect(self.refresh_keep)
        row.addWidget(self.btn_refresh)
        self.btn_author = QPushButton("UP 主主页")
        self.btn_author.setToolTip("看这个作者的全部视频，点进去接着刷")
        self.btn_author.clicked.connect(self.open_author)
        row.addWidget(self.btn_author)
        self.lbl_pos = QLabel("— / —")
        self.lbl_pos.setObjectName("FieldLabel")
        row.addWidget(self.lbl_pos)
        # 当前出口地区：查不到就写「未知地域」；观看过程中会一直复查
        self.lbl_geo = QLabel("地区：检测中…")
        self.lbl_geo.setObjectName("FieldLabel")
        self.lbl_geo.setToolTip(
            "按你当前的出口 IP 判断。看视频的时候也会反复复查，IP 一变就自动刷新。")
        row.addWidget(self.lbl_geo)
        v.addLayout(row)

        # ---- 第二行：看什么类型 + 站内搜索 ----
        row2 = FlowLayout(spacing=8)
        lab = QLabel("看什么")
        lab.setObjectName("FieldLabel")
        row2.addWidget(lab)
        self.cb_cat = QComboBox()
        self.cb_cat.setMinimumWidth(96)
        for name, _kw in videofeed.CATEGORIES:
            self.cb_cat.addItem(name)
        # 不单给样式，跟着全局 QSS 走（浅色边框的白底跟整页不搭）
        self.cb_cat.currentIndexChanged.connect(
            lambda _i: self.load_feed(reset_page=True))
        row2.addWidget(self.cb_cat)

        # 过滤：勾上就不推那类片子（恐怖 / 引人不适 / 剧情演绎 / 搬运 / 超长）
        self.btn_filter = QPushButton("过滤")
        self.btn_filter.setMinimumWidth(58)
        self.btn_filter.setToolTip("选择你不想看的类型，勾上后刷新就不会再推")
        self.menu_filter = QMenu(self.btn_filter)
        self._filter_acts = {}
        for key, name in videofeed.FILTER_KINDS:
            act = self.menu_filter.addAction(name)
            act.setCheckable(True)
            act.toggled.connect(self._on_filter_toggled)
            self._filter_acts[key] = act
        self.menu_filter.addSeparator()
        self.act_forget = self.menu_filter.addAction("清空「这次都刷过」的记录")
        self.act_forget.setToolTip("清空后之前看过的那批允许再次出现")
        self.act_forget.triggered.connect(self._forget_seen)
        self.btn_filter.setMenu(self.menu_filter)
        self._load_filters()
        row2.addWidget(self.btn_filter)

        self.ed_search = QLineEdit()
        self.ed_search.setPlaceholderText("搜你想要的：红石农场 / 建筑教程 / 整合包…")
        self.ed_search.setClearButtonEnabled(True)
        self.ed_search.returnPressed.connect(self.do_search)
        row2.addWidget(self.ed_search)
        self.btn_search = QPushButton("搜")
        self.btn_search.setMinimumWidth(58)
        self.btn_search.clicked.connect(self.do_search)
        row2.addWidget(self.btn_search)
        self.btn_clear = QPushButton("回到推荐")
        self.btn_clear.clicked.connect(self.clear_search)
        row2.addWidget(self.btn_clear)
        v.addLayout(row2)

        # ---- 第二行半：专区（主播 / 系列）+ 原视频还是二创 ----
        row3 = FlowLayout(spacing=8)
        lb_sc = QLabel("专区")
        lb_sc.setObjectName("FieldLabel")
        row3.addWidget(lb_sc)
        self.cb_scene = QComboBox()
        self.cb_scene.setMinimumWidth(130)
        self.cb_scene.addItem("默认推荐（不限定）", "")
        for name, kw in videofeed.SCENES:
            self.cb_scene.addItem(name, kw)
        self.cb_scene.currentIndexChanged.connect(
            lambda _i: self.load_feed(reset_page=True))
        self.cb_scene.setToolTip("挑一个主播或系列，就只看这个专区；"
                                 "已逝创作者的作品也都留着")
        row3.addWidget(self.cb_scene)
        lb_k = QLabel("看哪种")
        lb_k.setObjectName("FieldLabel")
        row3.addWidget(lb_k)
        self.cb_kind = QComboBox()
        for key, name in videofeed.SCENE_KINDS:
            self.cb_kind.addItem(name, key)
        self.cb_kind.setCurrentIndex(len(videofeed.SCENE_KINDS) - 1)  # 默认都看
        self.cb_kind.currentIndexChanged.connect(
            lambda _i: self.load_feed(reset_page=True))
        self.cb_kind.setToolTip("原视频＝主播自己发的；二创＝别人剪的解说、熟肉、搬运")
        row3.addWidget(self.cb_kind)
        self.lbl_scene = QLabel("涉政、违法违规的片子会自动挡掉，不用自己挑")
        self.lbl_scene.setObjectName("FieldLabel")
        # 这句以前是最小宽度的大头（273px），窗口一窄就把整行顶出可视区。
        # 允许换行 + 限个最大宽度，窄窗口下折两行显示，不再把右边控件顶出去。
        self.lbl_scene.setWordWrap(True)
        self.lbl_scene.setMaximumWidth(320)
        row3.addWidget(self.lbl_scene)
        v.addLayout(row3)

        # ---- 画面区 ----
        stage = QFrame()
        self.stage = stage
        # 画面区最小高度按窗口给：以前写死 430，窗口矮一点（比如 940×620
        # 不全屏）底部控制条就被挤到看不见，用户看到的就是「下面被切掉」。
        stage.setMinimumHeight(200)
        stage.setStyleSheet(
            "QFrame#VideoStage{background:#0B0D10;border-radius:12px;}")
        stage.setObjectName("VideoStage")
        sv = QVBoxLayout(stage)
        sv.setContentsMargins(0, 0, 0, 0)
        sv.setSpacing(0)

        # 视频和封面叠在同一块区域里，靠 QStackedWidget 切换，
        # 不能放进同一个 QVBoxLayout —— 否则隐藏的那个还占着一半高度。
        self.stage_stack = QStackedWidget()
        sv.addWidget(self.stage_stack, 1)

        if HAS_VIDEO:
            self.video = QVideoWidget()
            # 不给视频组件套 QSS：一给它就变成「样式绘制」的普通控件，
            # Windows 上画面会被那层背景盖住，只剩声音（用户报的「只播音频」）。
            self.video.setAttribute(Qt.WA_StyledBackground, False)
            self.video.setStyleSheet("")
            try:
                self.video.setAspectRatioMode(Qt.KeepAspectRatio)
            except Exception:
                pass
            self.video.setMinimumHeight(200)
            self.stage_stack.addWidget(self.video)
        else:
            self.video = None

        self.cover = QLabel("正在取 MC 视频…")
        self.cover.setAlignment(Qt.AlignCenter)
        self.cover.setStyleSheet("background:#0B0D10;border-radius:12px;color:#9aa3b8;")
        self.cover.setMinimumHeight(200)
        self.cover.setScaledContents(False)
        self.stage_stack.addWidget(self.cover)
        self.stage_stack.setCurrentWidget(self.cover)

        # 字幕条做成覆盖层，显示/隐藏不影响画面区高度（否则一切换就跳一下）
        self.lbl_sub = QLabel("", stage)
        self.lbl_sub.setWordWrap(True)
        self.lbl_sub.setStyleSheet(
            "background:rgba(12,14,18,0.86);color:#f2f5fa;padding:8px 12px;"
            "border-radius:10px;font-size:14px;")
        self.lbl_sub.setVisible(False)
        self.lbl_sub.setAttribute(Qt.WA_TransparentForMouseEvents, True)

        # 暂停图案 + 缓冲提示，都盖在画面区上（不吃鼠标，点画面还能暂停）
        self.pause_ov = PauseOverlay(stage, 92)
        self.buf_lbl = QLabel("正在缓冲…", stage)
        self.buf_lbl.setAlignment(Qt.AlignCenter)
        self.buf_lbl.setStyleSheet(
            "color:#E7ECF3;background:rgba(8,10,14,0.62);"
            "border-radius:10px;padding:6px 16px;font-size:14px;")
        self.buf_lbl.setVisible(False)
        self.buf_lbl.setAttribute(Qt.WA_TransparentForMouseEvents, True)

        # 全屏时才出现的退出按钮：右下角一直是黑的，键盘万一没焦点也点得到
        self.btn_fs_exit = QPushButton("退出全屏", stage)
        self.btn_fs_exit.setCursor(Qt.PointingHandCursor)
        self.btn_fs_exit.setStyleSheet(
            "QPushButton{background:rgba(14,18,24,0.86);color:#eef2f8;"
            "border:1px solid rgba(150,170,200,0.45);border-radius:8px;"
            "padding:6px 14px;font-size:13px;}"
            "QPushButton:hover{background:rgba(24,30,40,0.96);}")
        self.btn_fs_exit.clicked.connect(self.exit_stage_full)
        self.btn_fs_exit.setVisible(False)

        # ---- 全屏浮层控制条 ----
        # 全屏时页面上的进度条、播放、音量、上一条/下一条都被收起来了，以前
        # 全屏就只剩右上角一个「退出全屏」——想暂停只能点画面，想拖进度、想
        # 调音量根本没入口。这里给全屏单独做一条浮层控制条，鼠标一动就出来，
        # 停 2.5 秒自动收起，不挡画面。
        self.fs_bar = QFrame(stage)
        self.fs_bar.setObjectName("VideoFsBar")
        self.fs_bar.setStyleSheet(
            "QFrame#VideoFsBar{background:rgba(10,12,16,0.86);"
            "border:1px solid rgba(140,160,190,0.30);border-radius:10px;}"
            "QFrame#VideoFsBar QLabel{color:#eef2f8;background:transparent;}"
            "QFrame#VideoFsBar QPushButton{color:#eef2f8;background:rgba(40,48,62,0.9);"
            "border:1px solid rgba(140,160,190,0.35);border-radius:6px;"
            "padding:4px 10px;font-size:13px;}"
            "QFrame#VideoFsBar QPushButton:hover{background:rgba(60,72,92,0.95);}"
            "QFrame#VideoFsBar QSlider::groove:horizontal{height:4px;"
            "background:#3a4250;border-radius:2px;}"
            "QFrame#VideoFsBar QSlider::handle:horizontal{width:12px;margin:-5px 0;"
            "border-radius:6px;background:#dfe7f2;}")
        fb = QHBoxLayout(self.fs_bar)
        fb.setContentsMargins(12, 6, 12, 6)
        fb.setSpacing(8)
        self.btn_fs_pp = QPushButton("暂停")
        self.btn_fs_pp.setMinimumWidth(56)
        self.btn_fs_pp.clicked.connect(self.toggle_play)
        fb.addWidget(self.btn_fs_pp)
        self.btn_fs_prev = QPushButton("上一条")
        self.btn_fs_prev.clicked.connect(self.prev_item)
        fb.addWidget(self.btn_fs_prev)
        self.btn_fs_next = QPushButton("下一条")
        self.btn_fs_next.clicked.connect(self.next_item)
        fb.addWidget(self.btn_fs_next)
        self.lbl_fs_cur = QLabel("0:00")
        fb.addWidget(self.lbl_fs_cur)
        self.fs_slider = QSlider(Qt.Horizontal)
        self.fs_slider.setRange(0, 0)
        self.fs_slider.sliderPressed.connect(self._fs_seek_start)
        self.fs_slider.sliderMoved.connect(self._fs_seek_move)
        self.fs_slider.sliderReleased.connect(self._fs_seek_end)
        fb.addWidget(self.fs_slider, 1)
        self.lbl_fs_len = QLabel("0:00")
        fb.addWidget(self.lbl_fs_len)
        self.btn_fs_mute = QPushButton("静音")
        self.btn_fs_mute.setMinimumWidth(58)
        self.btn_fs_mute.clicked.connect(self.toggle_mute)
        fb.addWidget(self.btn_fs_mute)
        self.vol_fs = QSlider(Qt.Horizontal)
        self.vol_fs.setRange(0, 100)
        self.vol_fs.setValue(55)
        self.vol_fs.setFixedWidth(84)
        self.vol_fs.valueChanged.connect(self._on_fs_vol)
        fb.addWidget(self.vol_fs)
        self.fs_bar.setVisible(False)
        self._fs_seeking = False
        self._fs_idle = QTimer(self)
        self._fs_idle.setSingleShot(True)
        self._fs_idle.setInterval(2500)
        self._fs_idle.timeout.connect(self._hide_fs_ui)

        v.addWidget(stage, 1)

        # ---- 标题行 ----
        self.lbl_list = QLabel("")
        self.lbl_list.setObjectName("PageSub")
        v.addWidget(self.lbl_list)
        self.lbl_title = QLabel("")
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setStyleSheet("font-size:17px;font-weight:600;")
        v.addWidget(self.lbl_title)
        self.lbl_meta = QLabel("")
        self.lbl_meta.setObjectName("PageSub")
        v.addWidget(self.lbl_meta)
        # 背景音乐：从这条的简介/标题里自动抠出来
        self.lbl_bgm = QLabel("")
        self.lbl_bgm.setObjectName("FieldLabel")
        self.lbl_bgm.setWordWrap(True)
        self.lbl_bgm.setVisible(False)
        v.addWidget(self.lbl_bgm)

        # ---- 进度条（可以拖） ----
        self._seeking = False
        prog = QHBoxLayout()
        prog.setSpacing(8)
        self.lbl_cur = QLabel("0:00")
        self.lbl_cur.setObjectName("FieldLabel")
        prog.addWidget(self.lbl_cur)
        self.bar = QSlider(Qt.Horizontal)
        self.bar.setRange(0, 0)
        self.bar.setToolTip("拖动可以调整播放进度")
        self.bar.sliderPressed.connect(self.seek_start)
        self.bar.sliderMoved.connect(self.seek_move)
        self.bar.sliderReleased.connect(self.seek_end)
        prog.addWidget(self.bar, 1)
        self.lbl_len = QLabel("0:00")
        self.lbl_len.setObjectName("FieldLabel")
        prog.addWidget(self.lbl_len)
        v.addLayout(prog)

        # ---- 底部控制（同样自动换行，窄窗口下折成两排才不会挤丢按钮） ----
        bar = FlowLayout(spacing=8)
        self.btn_prev = QPushButton("上一条")
        self.btn_prev.clicked.connect(self.prev_item)
        bar.addWidget(self.btn_prev)
        self.btn_next = QPushButton("下一条")
        self.btn_next.clicked.connect(self.next_item)
        bar.addWidget(self.btn_next)
        self.btn_pp = QPushButton("播放")
        self.btn_pp.setMinimumWidth(62)
        self.btn_pp.clicked.connect(self.toggle_play)
        bar.addWidget(self.btn_pp)
        self.btn_mute = QPushButton("静音")
        self.btn_mute.setMinimumWidth(62)
        self.btn_mute.clicked.connect(self.toggle_mute)
        bar.addWidget(self.btn_mute)
        # 音量：只在视频页生效，不动系统音量
        bar.addWidget(QLabel("音量"))
        self.vol = QSlider(Qt.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(55)
        self.vol.setFixedWidth(96)
        self.vol.setToolTip("视频音量（不影响系统音量）")
        self.vol.valueChanged.connect(self._on_vol)
        bar.addWidget(self.vol)
        self.lbl_vol = QLabel("55%")
        self.lbl_vol.setObjectName("FieldLabel")
        self.lbl_vol.setFixedWidth(38)
        bar.addWidget(self.lbl_vol)
        # 倍速：听不清的教程可以调到 0.75，赶时间的用 1.5/2
        self.cb_speed = QComboBox()
        self.cb_speed.setFixedWidth(68)
        for t in ("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "2.0x"):
            self.cb_speed.addItem(t)
        self.cb_speed.setCurrentText("1.0x")
        self.cb_speed.currentTextChanged.connect(self._on_speed)
        self.cb_speed.setToolTip("播放速度（不影响进度条位置）")
        bar.addWidget(self.cb_speed)
        self.btn_big = QPushButton("全屏观看")
        self.btn_big.setMinimumWidth(84)
        self.btn_big.setToolTip("画面铺满整块屏幕；Esc 或点画面右上角的「退出全屏」回来")
        self.btn_big.clicked.connect(self.toggle_stage_full)
        bar.addWidget(self.btn_big)
        self.btn_open = QPushButton("在平台上打开")
        self.btn_open.clicked.connect(self.open_page)
        bar.addWidget(self.btn_open)
        # 查模组：按这条的标题认是哪个模组，直接给 Modrinth 的项目页
        self.btn_mods = QPushButton("查这片的模组")
        self.btn_mods.setMinimumWidth(106)
        self.btn_mods.setToolTip("按当前这条视频的标题/标签去模组站认模组，认不出来会直说，不瞎推")
        self.btn_mods.clicked.connect(self.find_mods)
        bar.addWidget(self.btn_mods)
        self.lbl_hint = QLabel("滚轮或上下拖动 = 切下一条")
        self.lbl_hint.setObjectName("FieldLabel")
        bar.addWidget(self.lbl_hint)
        self.state = QLabel("只推我的世界相关的视频；没有评论、点赞，看就完了。")
        self.state.setObjectName("PageSub")
        self.state.setWordWrap(True)
        v.addWidget(self.state)

        v.addLayout(bar)

        # 播放器（懒创建，避免启动时初始化多媒体后端）
        self._player_ready = False
        self._want_play = False        # 用户此刻想不想播（切条/暂停都看它）
        self._retry = 0                # 起播卡住时自动重试的次数
        self._stuck = 0                # 已经等了几个 tick（600ms 一次）
        self._nopic = 0                # 进度在走却一直没有视频轨的连续次数
        self._src_url = ""
        self._watch = QTimer(self)
        self._watch.setInterval(600)
        self._watch.timeout.connect(self._check_stuck)

        # 画面区点击 = 暂停 / 继续
        # stage 也要装：暂停图案铺满之后它自己不吃鼠标，点击会穿透到 stage 上，
        # 以前没装这里，暂停后再点画面就没反应了。
        for w in (self.stage, self.stage_stack, self.cover, self.video,
                  getattr(self, "fs_bar", None)):
            if w is not None:
                w.installEventFilter(self)
                # 全屏浮层靠鼠标移动唤醒：不打开鼠标跟踪，画面区收不到
                # MouseMove，控制条就永远出不来。
                try:
                    w.setMouseTracking(True)
                except Exception:
                    pass
        self._app_filter_on = False
        self.setFocusPolicy(Qt.StrongFocus)
        self._restore_prefs()
        # 后台查一次出口 IP 的地区：国内就把「油管」置灰，别等点了才拦
        self._yt_ready.connect(self._on_yt_ready)
        self._yt_chk = None
        self._geo_last = ""             # 上次看到的地区码，用来判断「IP 变了没有」
        self._geo_blocked = None
        self._geo_thread = None
        self._geo_first = True
        self._blocked_hint = False       # 上一屏是不是「油管不开放」的提示
        self._want_yt = False            # 点了油管、还在等地区查完
        self._geo_done.connect(self._on_geo_done)
        # 看视频的过程中也要一直复查：换网络 / 挂上或撤掉代理之后，
        # 列表和封面必须跟着换成新的地区口径（用户要求「IP 变了就刷新」）。
        self._ip_timer = QTimer(self)
        self._ip_timer.setInterval(45 * 1000)
        self._ip_timer.timeout.connect(self._check_yt_region)
        self._ip_timer.start()
        QTimer.singleShot(0, self._check_yt_region)

    # ---------- 油管地区限制 ----------
    def _check_yt_region(self, force=False):
        """起个后台线程查地区，别卡界面（查不到就当能用，只是点的时候再判一次）。

        force=True 是「强制复查」：清掉缓存重新查，用于 IP 可能刚变的时候。
        """
        try:
            import threading
            if force:
                try:
                    videofeed.youtube_region_force_recheck()
                except Exception:
                    pass
            if (self._geo_thread is not None and self._geo_thread.is_alive()) \
                    or (self._yt_chk is not None and self._yt_chk.is_alive()):
                return
            self._geo_thread = threading.Thread(
                target=self._yt_probe, daemon=True)
            self._geo_thread.start()
        except Exception:
            pass

    def _yt_probe(self):
        try:
            info = videofeed.visitor_region()
        except Exception:
            info = {"code": "", "text": "未知地域", "n": 0, "seen": [],
                    "blocked": True, "why": "查不到网络地区"}
        try:
            self._geo_done.emit(info)
        except Exception:
            pass

    def _on_geo_done(self, info):
        """地区查回来了：更新标签；地区变了就按新口径刷新。"""
        try:
            code = (info or {}).get("code") or ""
            text = (info or {}).get("text") or "未知地域"
            blocked = bool((info or {}).get("blocked"))
            if code:
                self.lbl_geo.setText("地区：%s" % text)
            else:
                self.lbl_geo.setText("地区：未知地域")
            detail = ("%d 个源一致" % info.get("n", 0)) if code else "没查到"
            self.lbl_geo.setToolTip(
                "按你当前的出口 IP 判断（%s）。看视频时也会反复复查，IP 一变就刷新。"
                % detail)
        except Exception:
            pass
        want = getattr(self, "_want_yt", False)
        if want:
            self._want_yt = False
        self._respond_to_region_change(code, blocked)
        if want:
            if not blocked:
                try:
                    self.switch_platform("youtube")
                except Exception:
                    pass
            else:
                try:
                    self.state.setText("此功能暂时不对中国大陆开放")
                except Exception:
                    pass

    def _respond_to_region_change(self, code, blocked):
        """IP / 地区变了之后怎么处理。

        - 第一次查：只把结果记下来，不打扰用户；
        - 之后地区码变了，或者「能不能用油管」这个结论翻转了：
          正在看油管时立刻换成 B 站，列表和封面重新拉一遍。
        """
        had = self._geo_blocked
        self._geo_blocked = blocked
        same = (code == self._geo_last) and (had == blocked)
        self._geo_last = code
        if self._geo_first:
            self._geo_first = False
            if blocked:
                b = self.btn_platforms.get("youtube")
                if b is not None:
                    b.setToolTip("此功能暂时不对中国大陆开放")
            return
        if same:
            return
        # 地区变了：如果正在油管上看，先退回 B 站（大陆口径下油管不给内容）
        if blocked and self.platform == "youtube":
            try:
                self.state.setText("网络地区变了：%s，油管先停下" % (code or "未知地域"))
                self.switch_platform("bilibili")
            except Exception:
                pass
            return
        # 别的平台在看：只刷新列表，不动当前正在播的这条
        try:
            self.load_feed(reset_page=True)
        except Exception:
            pass
        try:
            where = self.lbl_geo.text().replace("地区：", "")
            self.state.setText("网络地区变成 %s，列表已刷新" % where)
        except Exception:
            pass

    def _on_yt_ready(self, blocked, why):
        b = self.btn_platforms.get("youtube")
        if b is None or not blocked:
            return
        # 按钮留着能点：点了才把「暂时不对中国大陆开放」这条给用户看
        b.setToolTip("此功能暂时不对中国大陆开放")


    # ---------- 播放器 ----------
    def _ensure_player(self):
        if self._player_ready:
            return True
        if not (HAS_VIDEO and mc.HAS_MEDIA):
            return False
        self._player = mc.make_player(self)
        self._audio = make_audio(self._player, self,
                                 (self.vol.value() if hasattr(self, "vol") else 55) / 100.0)
        try:
            self._player.setVideoOutput(self.video)
        except Exception:
            return False
        connect_error(self._player, self._on_media_error)
        self._player.mediaStatusChanged.connect(self._on_media_status)
        try:
            self._player.positionChanged.connect(self._on_pos)
            self._player.durationChanged.connect(self._on_dur)
        except Exception:
            pass
        self._player_ready = True
        return True

    # ---------- 进度条 ----------
    def _fmt_ms(self, ms):
        try:
            ms = max(0, int(ms))
        except Exception:
            ms = 0
        s = ms // 1000
        if s >= 3600:
            return "%d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60)
        return "%d:%02d" % (s // 60, s % 60)

    def _on_pos(self, ms):
        if getattr(self, "_seeking", False) or getattr(self, "_fs_seeking", False):
            return
        try:
            self.bar.setValue(int(ms))
            self.lbl_cur.setText(self._fmt_ms(ms))
        except Exception:
            pass
        try:
            fs = getattr(self, "fs_slider", None)
            if fs is not None:
                fs.blockSignals(True)
                fs.setValue(int(ms))
                fs.blockSignals(False)
                self.lbl_fs_cur.setText(self._fmt_ms(ms))
        except Exception:
            pass

    def _on_dur(self, ms):
        try:
            self.bar.setRange(0, max(0, int(ms)))
            self.lbl_len.setText(self._fmt_ms(ms))
        except Exception:
            pass
        try:
            fs = getattr(self, "fs_slider", None)
            if fs is not None:
                fs.setRange(0, max(0, int(ms)))
                self.lbl_fs_len.setText(self._fmt_ms(ms))
        except Exception:
            pass

    def seek_start(self):
        self._seeking = True

    def seek_move(self, val):
        try:
            self.lbl_cur.setText(self._fmt_ms(val))
        except Exception:
            pass

    def seek_end(self):
        self._seeking = False
        if self._player is None:
            return
        try:
            self._player.setPosition(int(self.bar.value()))
            self.lbl_cur.setText(self._fmt_ms(self.bar.value()))
        except Exception:
            pass

    def _on_media_error(self, *a):
        msg = ""
        try:
            msg = self._player.errorString()
        except Exception:
            pass
        self.buf_lbl.setVisible(False)
        self.state.setText("这条播不了（%s），点「在平台上打开」看原视频。" % (msg or "播放出错"))

    def _on_media_status(self, st):
        try:
            v = getattr(st, "value", st)
            # 2=Loaded 3=Buffering 4=Buffered 5=BufferedMedia 都算「可以出画面了」
            ready = (v == 2 or v == 3 or v == 4 or v == 5)
            if v == mc.end_of_media():
                self._sync_pause(False)
                self.next_item()
                return
            if ready and self._want_play:
                # 状态说能播了就把画面切过去，不让它停在封面上
                self.buf_lbl.setVisible(False)
                self._show_stage("video")
                self._stuck = 0
                # 之前等太久报过「没播起来」，其实已经播上了：把话说回来
                txt = self.state.text() or ""
                if ("没播起来" in txt or "播不了" in txt or "缓冲" in txt):
                    self.state.setText("正在播放…")
                # 页面已经不在前台（切去别的页 / 窗口最小化）就别自动起播：
                # 地址刚解析完就 play()，人已经走了，声音却开始响。
                if not self.isVisible():
                    self._want_play = False
                    if self._player is not None:
                        try:
                            self._player.pause()
                        except Exception:
                            pass
                    return
                if self._player is not None and \
                        getattr(self._player.playbackState(), "value", 0) != 1:
                    self._player.play()
        except Exception:
            pass

    def _sync_pause(self, paused):
        """暂停图案：视频区正中盖一层大大的暂停符号。"""
        try:
            if paused and not self._show_stage_is_cover():
                self._place_overlays()
                self.pause_ov.fit()
                self.pause_ov.set_active(True)
                self.pause_ov.raise_()
            else:
                self.pause_ov.set_active(False)
            self.btn_pp.setText("继续" if paused else "暂停")
            bf = getattr(self, "btn_fs_pp", None)
            if bf is not None:
                bf.setText("继续" if paused else "暂停")
        except Exception:
            pass

    def toggle_play(self):
        """左键点画面 / 点按钮 / 按空格都走这里。

        以前是按播放器的 playbackState 判断「现在是不是在播」，可缓冲阶段它会在
        Playing/Stopped 之间来回跳，于是暂停点了没反应、按钮文字和暂停图案还跟
        播放状态对不上。现在统一以 _want_play（我想不想让它播）为准。
        """
        if self._player is None:
            if self._cur() is not None:
                self._start_play(self._cur())
            return
        try:
            if getattr(self, "_want_play", False):
                self._want_play = False
                self._player.pause()
                self._sync_pause(True)
            else:
                self._want_play = True
                if self._src_url and self._show_stage_is_cover():
                    self._show_stage("video")
                self._player.play()
                self._sync_pause(False)
        except Exception:
            pass

    def _show_stage_is_cover(self):
        try:
            return self.stage_stack.currentWidget() is self.cover
        except Exception:
            return True

    def toggle_mute(self):
        if self._player is None:
            return
        try:
            muted = mc.is_muted(self._player, self._audio)
            mc.set_muted(self._player, self._audio, not muted)
            self.btn_mute.setText("开声音" if not muted else "静音")
            bf = getattr(self, "btn_fs_mute", None)
            if bf is not None:
                bf.setText("开声音" if not muted else "静音")
        except Exception:
            pass

    # ---------- 全屏浮层控制条 ----------
    def _show_fs_ui(self):
        """全屏下鼠标一动：把浮层控制条和退出按钮亮出来，2.5 秒后自动收。"""
        if not getattr(self, "_fs_on", False):
            return
        try:
            fb = getattr(self, "fs_bar", None)
            if fb is not None and not fb.isVisible():
                fb.setVisible(True)
                self._place_overlays()
            btn = getattr(self, "btn_fs_exit", None)
            if btn is not None and not btn.isVisible():
                btn.setVisible(True)
                btn.raise_()
            self._fs_idle.start()
        except Exception:
            pass

    def _hide_fs_ui(self):
        if not getattr(self, "_fs_on", False):
            return
        try:
            fb = getattr(self, "fs_bar", None)
            # 鼠标停在控制条上就别收，否则刚想点按钮它就消失了
            if fb is not None and fb.underMouse():
                self._fs_idle.start()
                return
            if fb is not None:
                fb.setVisible(False)
            btn = getattr(self, "btn_fs_exit", None)
            if btn is not None:
                btn.setVisible(False)
        except Exception:
            pass

    def _fs_seek_start(self):
        self._fs_seeking = True

    def _fs_seek_move(self, val):
        try:
            self.lbl_fs_cur.setText(self._fmt_ms(val))
        except Exception:
            pass

    def _fs_seek_end(self):
        self._fs_seeking = False
        if self._player is None:
            return
        pos = 0
        try:
            pos = int(self.fs_slider.value())
            self._player.setPosition(pos)
            self.bar.blockSignals(True)
            self.bar.setValue(pos)
            self.bar.blockSignals(False)
            self.lbl_cur.setText(self._fmt_ms(pos))
            self.lbl_fs_cur.setText(self._fmt_ms(pos))
        except Exception:
            pass

    def _on_fs_vol(self, v):
        try:
            self.vol.blockSignals(True)
            self.vol.setValue(int(v))
            self.vol.blockSignals(False)
        except Exception:
            pass
        self._on_vol(v)

    # ---------- 音量 / 倍速 / 放大 ----------
    def _on_vol(self, v):
        self._vol = v
        try:
            self.lbl_vol.setText("%d%%" % int(v))
        except Exception:
            pass
        try:
            vf = getattr(self, "vol_fs", None)
            if vf is not None and int(vf.value()) != int(v):
                vf.blockSignals(True)
                vf.setValue(int(v))
                vf.blockSignals(False)
        except Exception:
            pass
        if self._player is None:
            pass
        else:
            try:
                mc.set_volume(self._player, self._audio, max(0, min(100, v)) / 100.0)
            except Exception:
                pass
        self._save_prefs()

    def _on_speed(self, text):
        rate = 1.0
        try:
            rate = float((text or "1.0x").lower().replace("x", ""))
        except Exception:
            rate = 1.0
        self._rate = rate
        if self._player is not None:
            try:
                self._player.setPlaybackRate(rate)
            except Exception:
                pass
        self._save_prefs()

    def _save_prefs(self):
        """音量和倍速记下来，下次打开还是这个手感（拖滑块时防抖，别一直写盘）。"""
        if getattr(self, "_prefs_timer", None) is None:
            self._prefs_timer = QTimer(self)
            self._prefs_timer.setSingleShot(True)
            self._prefs_timer.setInterval(1500)
            self._prefs_timer.timeout.connect(self._write_prefs)
        self._prefs_timer.start()

    def _write_prefs(self):
        cfg = getattr(self.host, "config", None)
        if cfg is None:
            return
        try:
            cfg.set("video_volume", int(getattr(self, "_vol", 55)))
            cfg.set("video_speed", float(getattr(self, "_rate", 1.0)))
            cfg.save()
        except Exception:
            pass

    def _restore_prefs(self):
        cfg = getattr(self.host, "config", None)
        if cfg is None:
            return
        try:
            v = cfg.get("video_volume")
            if v is not None:
                self.vol.setValue(max(0, min(100, int(v))))
        except Exception:
            pass
        try:
            r = cfg.get("video_speed")
            if r is not None:
                txt = "%.2fx" % float(r)
                txt = txt.replace("0.50x", "0.5x").replace("0.75x", "0.75x")
                self.cb_speed.setCurrentText(txt)
        except Exception:
            pass

    def _page_items(self):
        """画面区之外的那些控件（全屏时全藏起来）。"""
        out = []
        lay = getattr(self, "_vbox", None)
        if lay is None:
            return out
        stage = getattr(self, "stage", None)
        for i in range(lay.count()):
            it = lay.itemAt(i)
            w = it.widget()
            if w is not None:
                if w is not stage:
                    out.append(w)
                continue
            sub = it.layout()
            if sub is not None:
                for j in range(sub.count()):
                    cw = sub.itemAt(j).widget()
                    if cw is not None:
                        out.append(cw)
        return out

    def toggle_stage_full(self):
        """全屏观看：主窗口铺满整屏，画面区之外的东西全收起来。

        以前的做法是另开一个无边框全屏窗口，再把播放器的输出换到新窗口里的
        另一个视频组件上。Windows 上换输出那一下画面会整个黑掉（有的机器连
        桌面都黑），而且那个窗口没焦点，Esc 根本按不进来——用户只能强杀。
        现在不新建窗口、也绝不重新绑输出：只把主窗口全屏 + 藏起别的控件，
        画面一直在原来那块组件里画，退出时原样恢复。
        """
        if getattr(self, "_fs_on", False):
            self.exit_stage_full()
            return
        if not (HAS_VIDEO and self.video is not None):
            self.state.setText("这台机器没有视频组件，全屏用不了。")
            return
        self._fs_on = True
        try:
            self._fs_hidden = [w for w in self._page_items() if w.isVisible()]
            for w in self._fs_hidden:
                w.setVisible(False)
            try:
                self._stage_min = self.stage.minimumHeight()
                self.stage.setMinimumHeight(0)
            except Exception:
                pass
            # 全屏时把画面区的圆角去掉：窗口化时那 12px 圆角好看，铺满整屏后
            # 四个角就变成四块黑色缺口。
            try:
                self._stage_qss = self.stage.styleSheet()
                self.stage.setStyleSheet(
                    "QFrame#VideoStage{background:#000;border-radius:0;}")
            except Exception:
                pass
            try:
                self.btn_fs_exit.setVisible(True)
                self.btn_fs_exit.raise_()
            except Exception:
                pass
            try:
                fb = getattr(self, "fs_bar", None)
                if fb is not None:
                    fb.setVisible(True)
                    fb.raise_()
                    self._fs_idle.start()
            except Exception:
                pass
            win = self.window()
            self._fs_win = win
            if win is not None:
                self._fs_was_max = bool(win.isMaximized())
                self._fs_geo = win.geometry()
                # 不再用 showFullScreen()：Windows 上它经常只是把窗口撑到
            # 比屏幕还高（顶部一截永远看不见），而且和主窗口 F11 那套自管全屏
            # 互相打架。有主窗口的自管全屏就直接用，进出都确定。
                if hasattr(win, "_enter_fullscreen"):
                    win._enter_fullscreen()
                else:
                    win.showFullScreen()
            self.btn_big.setText("退出全屏")
            self.state.setText("全屏观看中：Esc 或点画面右上角「退出全屏」回来。")
            try:
                self.video.setFocus()
            except Exception:
                pass
            QTimer.singleShot(120, self._place_overlays)
            # 主窗口全屏是异步的：120ms 后可能还没真正 resize 完，暂停图案
            # 和浮层就按旧尺寸摆了一次。这里再补两拍，确保全屏后位置正确。
            QTimer.singleShot(320, self._place_overlays)
            QTimer.singleShot(700, self._place_overlays)
        except Exception as e:
            self._fs_on = False
            self.state.setText("全屏失败：%s" % e)

    def exit_stage_full(self):
        if not getattr(self, "_fs_on", False):
            return
        self._fs_on = False
        try:
            for w in getattr(self, "_fs_hidden", []):
                w.setVisible(True)
            self._fs_hidden = []
            try:
                self.stage.setMinimumHeight(getattr(self, "_stage_min", 430) or 430)
            except Exception:
                pass
            try:
                self.btn_fs_exit.setVisible(False)
            except Exception:
                pass
            try:
                fb = getattr(self, "fs_bar", None)
                if fb is not None:
                    fb.setVisible(False)
                if getattr(self, "_fs_idle", None) is not None:
                    self._fs_idle.stop()
                if getattr(self, "_stage_qss", None):
                    self.stage.setStyleSheet(self._stage_qss)
                else:
                    self.stage.setStyleSheet(
                        "QFrame#VideoStage{background:#0B0D10;border-radius:12px;}")
            except Exception:
                pass
            win = getattr(self, "_fs_win", None)
            if win is not None:
                # 进的时候走的是主窗口自管全屏，退也得走同一套，
                # 否则 showNormal() 之后的尺寸不受控，窗口又被内容撑出屏幕。
                if hasattr(win, "_leave_fullscreen") and getattr(win, "_fs_on", False):
                    win._leave_fullscreen()
                elif getattr(self, "_fs_was_max", False):
                    win.showMaximized()
                else:
                    win.showNormal()
                    geo = getattr(self, "_fs_geo", None)
                    if geo is not None and geo.width() > 200:
                        win.setGeometry(geo)
            self.btn_big.setText("全屏观看")
            self.state.setText("已退出全屏。")
            self._place_overlays()
            try:
                self.setFocus()
            except Exception:
                pass
        except Exception:
            pass

    # ---------- 平台切换 ----------
    def switch_platform(self, key):
        if key == "youtube":
            got = videofeed.youtube_region_quick()
            if got is None:
                # 还没查过：别在点击这一下同步查 7 个源（要几秒，界面会像卡死）。
                # 起后台线程查，查完在 _on_geo_done 里接着放行或拒绝。
                self._want_yt = True
                self.state.setText("正在判断你的网络地区…")
                self._check_yt_region(force=True)
                return
            blocked, why = got
            if blocked:
                for k, b in self.btn_platforms.items():
                    b.setChecked(k == self.platform)
                self.state.setText("此功能暂时不对中国大陆开放")
                self.lbl_title.setText("油管暂时不可用")
                self.lbl_meta.setText("当前是国内的网络，切回 B 站接着刷吧")
                self.lbl_pos.setText("— / —")
                self._stop_play()
                self._show_stage("cover")
                self.cover.setPixmap(QPixmap())
                self.cover.setText("此功能暂时不对中国大陆开放")
                # 这里没有真的换平台（还是 B 站），但界面被提示占住了。
                # 用户再点「B 站」时 key 和当前平台相同，如果直接 return，
                # 就会一直停在「暂时不开放」那一屏 —— 用户报的「切到 B 站切不了」
                # 就是这条路。所以记个标记，下面撞到同平台时补一次真正的加载。
                self._blocked_hint = True
                return
        was_hint = getattr(self, "_blocked_hint", False)
        self._blocked_hint = False
        if key == self.platform:
            if was_hint:
                # 上一屏是「油管不开放」的提示，重新把本平台列表铺回来
                try:
                    self.load_feed(reset_page=True)
                except Exception:
                    pass
            elif self.items and self.idx >= 0 and not self._src_url:
                try:
                    self.show_item(self.idx)
                except Exception:
                    pass
            return
        self.platform = key
        for k, b in self.btn_platforms.items():
            b.setChecked(k == key)
        self.items = []
        self.idx = -1
        # 上一个平台的列表线程可能还没走完，别让它挡住新请求
        # （它的回调按 platform 过滤，不会污染新平台的数据）
        self._feed = None
        if key in ("douyin", "xiaohongshu"):
            hint = videofeed.douyin_hint() if key == "douyin" else videofeed.xhs_hint()
            self._stop_play()
            self.state.setText(hint["msg"])
            self.lbl_title.setText("这个平台要登录，不能在启动器里浏览")
            self.lbl_meta.setText("点下面的按钮去平台网页上搜「我的世界」")
            self.lbl_pos.setText("— / —")
            self.lbl_sub.setVisible(False)
            self._open_url = hint["url"]
            self._show_stage("cover")
            self._cover_pm = None
            self.cover.setPixmap(QPixmap())
            self.cover.setText("直接去网页看")
            return
        # 换平台先把正在放的掐掉：播放器是复用的，不主动停就会一边取新地址
        # 一边继续响上一个平台那条视频的音频（用户报的就是这个）。
        self._stop_play()
        self.load_feed(reset_page=True)

    def do_search(self):
        kw = self.ed_search.text().strip()
        if not kw:
            self.clear_search()
            return
        self._keyword = kw
        self.load_feed(reset_page=True)

    def clear_search(self):
        self._keyword = ""
        self._author_name = ""
        try:
            self.ed_search.clear()
        except Exception:
            pass
        self.load_feed(reset_page=True)

    def next_batch(self):
        if self.platform in ("douyin", "xiaohongshu"):
            self.open_page()
            return
        self.page += 1
        self.load_feed()

    def _cat_kw(self):
        try:
            name = self.cb_cat.currentText()
        except Exception:
            return ""
        for n, kw in videofeed.CATEGORIES:
            if n == name:
                return kw
        return ""

    # ---------- 过滤项 ----------
    def filters(self):
        """用户勾上的过滤类型（key 列表）。"""
        return [k for k, act in self._filter_acts.items() if act.isChecked()]

    def _load_filters(self):
        saved = None
        try:
            saved = (self.host.config.get("video_filters")
                     if self.host and self.host.config is not None else None)
        except Exception:
            saved = None
        if not isinstance(saved, list):
            # 默认先挡掉恐怖、引人不适、剧情演绎（含外国卡通小剧场）
            saved = ["horror", "unwell", "story", "kiddie"]
        for k, act in self._filter_acts.items():
            act.setChecked(k in saved)

    def _save_filters(self):
        try:
            if self.host and self.host.config is not None:
                self.host.config.set("video_filters", self.filters())
                self.host.config.save()
        except Exception:
            pass

    def _on_filter_toggled(self, _on):
        n = len(self.filters())
        self.btn_filter.setText(("过滤 · %d" % n) if n else "过滤")
        if not hasattr(self, "state"):
            return          # 构造阶段 _load_filters 会触发一次，此时还没建 state
        self._save_filters()
        removed = self._apply_filter_now()
        if removed:
            self.state.setText(
                "已就地滤掉 %d 条（含刚才那几条恐怖/惊悚的），不用等刷新。" % removed)
        else:
            self.state.setText(
                "过滤项改好了，点「刷新」或「换一批」就按新规则取。"
                if n else "过滤全关了，点「刷新」后会按原来的规则取。")

    def _apply_filter_now(self):
        """勾选一变，立刻把手里这批按新规则过一遍。

        以前只保存设置、要用户自己点刷新，用户勾完「恐怖」照样能往下刷到
        恐怖片，自然觉得「勾了没用」。这一步是本地纯字符串判断，毫秒级。
        """
        try:
            if not getattr(self, "items", None):
                return 0
            kinds = self.filters()
            cur_id = id(self._cur()) if self._cur() is not None else None
            kept = videofeed.apply_filters(self.items, kinds)
            removed = len(self.items) - len(kept)
            if not removed:
                return 0
            pos = 0
            for i, it in enumerate(kept):
                if id(it) == cur_id:
                    pos = i
                    break
            self.items = kept
            if not kept:
                self.state.setText("按现在的过滤条件这批一条都不剩，点「刷新」重新取。")
                return removed
            if pos:
                self.idx = pos
            else:
                # 正在看的那条被滤掉了，换到列表第一条（不去碰播放器以外的状态）
                self.idx = 0
                self.goto(0)
                return removed
            try:
                self.lbl_pos.setText("%d / %d" % (self.idx + 1, len(kept)))
            except Exception:
                pass
            return removed
        except Exception:
            return 0

    # ---------- 防重复 ----------
    def _remember(self, items):
        for it in items or []:
            self._seen.add((it.get("platform"), it.get("id")))
        if len(self._seen) > 3000:       # 刷很久也不会把内存顶起来
            self._seen = set(list(self._seen)[-2000:])

    def _forget_seen(self):
        n = len(self._seen)
        self._seen.clear()
        try:
            self.state.setText("清空了，之前刷过的 %d 条现在也可能再出现。" % n)
        except Exception:
            pass

    def _flush_pending(self):
        """上一批取完了，把排队的那次「换一批」接着做掉。"""
        if not getattr(self, "_pending_feed", False):
            return
        try:
            if _alive(self._feed):
                QTimer.singleShot(150, self._flush_pending)
                return
        except Exception:
            pass
        self._pending_feed = False
        self.load_feed()

    def _scene_kw(self):
        """当前专区（关键词，空=不限定）和「原视频 / 二创」。"""
        try:
            return (self.cb_scene.currentData() or "",
                    self.cb_kind.currentData() or "both")
        except Exception:
            return "", "both"

    def _scene_name(self):
        try:
            return self.cb_scene.currentText() or ""
        except Exception:
            return ""

    def load_feed(self, reset_page=False):
        if reset_page:
            self.page = 1
        # 上一批还在路上就直接作废，不等它：换专区 / 换平台之后旧结果回来
        # 会把列表覆盖成旧内容，用户看到的就是「换专区没生效」。
        old = self._feed
        if _alive(old):
            try:
                old.cancel()
            except Exception:
                pass
            self.state.setText("正在换「%s」专区…" % (self._scene_name() or "全部"))
        self._pending_feed = False
        scene, kind = self._scene_kw()
        if scene:
            self.state.setText("正在取「%s」专区的片子…" % self._scene_name())
        else:
            self.state.setText("正在取视频列表…（会先滤掉不相关和不值得看的，稍等）")
        self.btn_more.setEnabled(False)
        self._feed_seq = getattr(self, "_feed_seq", 0) + 1
        seq = self._feed_seq
        self._feed = _FeedWorker(self.platform, self.page, self._cat_kw(),
                                 self._keyword, self,
                                 kinds=self.filters(), skip=self._seen,
                                 scene=scene, kind=kind)
        self._feed.done.connect(lambda p, it, e, d, s=seq: self._on_feed(p, it, e, d, s))
        self._feed.start()

    # ---------- 刷新（不动正在播的这条） ----------
    def refresh_keep(self):
        """刷新列表：当前这条继续播，播放进度不重来。"""
        old = self._feed
        if _alive(old):
            try:
                old.cancel()
            except Exception:
                pass
        self.btn_refresh.setEnabled(False)
        self.state.setText("正在刷新列表…当前这条继续播，进度不动")
        scene, kind = self._scene_kw()
        self._feed_seq = getattr(self, "_feed_seq", 0) + 1
        seq = self._feed_seq
        self._feed = _FeedWorker(self.platform, max(1, self.page),
                                 self._cat_kw(), self._keyword, self,
                                 kinds=self.filters(), skip=self._seen,
                                 scene=scene, kind=kind)
        self._feed.done.connect(
            lambda p, it, e, d, s=seq: self._on_refresh_keep(p, it, e, d, s))
        self._feed.start()

    def _on_refresh_keep(self, platform, items, err, dropped=0, seq=None):
        if seq is not None and seq != getattr(self, "_feed_seq", 0):
            return
        self.btn_refresh.setEnabled(True)
        if platform != self.platform:
            return
        if err:
            self.state.setText("刷新失败：%s" % err)
            return
        if not items:
            self.state.setText("刷新没取到新内容，当前这条照旧播着。")
            return
        cur = self._cur()
        if cur:
            cid = cur.get("id")
            items = [it for it in items if it.get("id") != cid]
            items.insert(0, cur)         # 当前这条置顶，播放照旧接着走
            self.idx = 0
        else:
            self.idx = -1
        self.items = items
        self._remember(items)
        head = "%s · %d 条" % (
            videofeed.PLATFORM_NAMES.get(platform, platform), len(items))
        if self._keyword:
            head = "搜索「%s」· %d 条" % (self._keyword, len(items))
        tail = "已刷新，最新发布和热度优先"
        if dropped:
            tail += "，滤掉 %d 条无关的" % dropped
        self.lbl_list.setText(head + "，" + tail + "；滚轮或上下拖动切换。")
        self.state.setText("列表已刷新，正在播的这条和播放进度都没动。")
        try:
            self.lbl_pos.setText("%d / %d" % (self.idx + 1, len(self.items)))
        except Exception:
            pass

    def open_author(self):
        """打开当前这条视频的作者主页：头像 + 名字 + 全部视频封面标题。"""
        cur = self._cur()
        if not cur:
            self.state.setText("还没选中视频，先等列表出来。")
            return
        if cur.get("platform") in ("douyin", "xiaohongshu"):
            self.state.setText("这个平台的作者主页只能在它的 App / 网页上看。")
            self._open_url = cur.get("page_url") or self._open_url
            return
        if _alive(self._author):
            return
        self.btn_author.setEnabled(False)
        self.state.setText("正在取 %s 的主页…" % (cur.get("author") or "作者"))
        self._author = _AuthorWorker(cur, self)
        self._author.done.connect(self._on_author)
        self._author.start()

    def _on_author(self, info, vids, err):
        self.btn_author.setEnabled(True)
        if err and not vids:
            self.state.setText("作者主页没取到：%s" % err)
            return
        if not vids:
            self.state.setText("这个作者没有取到可列的视频。")
            return
        dlg = AuthorDialog(info or {}, vids, self)
        if dlg.exec() != QDialog.Accepted or dlg.picked < 0:
            self.state.setText("")
            return
        # 进了作者主页：把这个人的视频当成新的一批接着刷
        self._author_info = info or {}
        self._author_name = (info or {}).get("name") or ""
        self.items = list(vids)
        self.idx = -1
        head = "%s 的全部视频 · %d 条" % (self._author_name or "这个作者",
                                       len(vids))
        self.lbl_list.setText(head + "；滚轮或上下拖动切换，点「回到推荐」回主列表。")
        self.state.setText("")
        self.goto(max(0, dlg.picked))

    def _on_feed(self, platform, items, err, dropped=0, seq=None):
        if seq is not None and seq != getattr(self, "_feed_seq", 0):
            return                      # 换过专区了，这是旧批次的结果，扔掉
        self.btn_more.setEnabled(True)
        QTimer.singleShot(150, self._flush_pending)
        if platform != self.platform:
            return
        if err:
            self.state.setText("列表没取到：%s" % err)
            return
        if not items:
            self.state.setText("这次没找到合适的：换一批，或者换个类型/关键词再搜。")
            return
        self.items = items
        self.idx = -1
        self._author_name = ""
        head = "%s · %d 条" % (videofeed.PLATFORM_NAMES.get(platform, platform),
                                len(items))
        if self._keyword:
            head = "搜索「%s」· %d 条" % (self._keyword, len(items))
        elif self.cb_cat.currentIndex() > 0:
            head = "%s · %s · %d 条" % (
                videofeed.PLATFORM_NAMES.get(platform, platform),
                self.cb_cat.currentText(), len(items))
        tail = "最新发布和热度优先"
        if dropped:
            tail += "，已滤掉 %d 条无关或凑数的" % dropped
        tail += "；滚轮或上下拖动切换。"
        self.lbl_list.setText(head + "，" + tail)
        self.state.setText("")
        self._remember(items)
        self.goto(0)

    # ---------- 条目 ----------
    def _cur(self):
        if 0 <= self.idx < len(self.items):
            return self.items[self.idx]
        return None

    def goto(self, i):
        if not self.items:
            return
        i = max(0, min(i, len(self.items) - 1))
        self.idx = i
        it = self.items[i]
        # 油管：开播前再查一次地区。刚连上/刚断开代理，这里就是最后一道闸。
        if it.get("platform") == "youtube":
            # 每隔十几秒真查一次出口 IP（缓存只有 60 秒，这里再往下压一点），
            # 不能靠「上次判断过」就一直放行。
            if time.time() - getattr(self, "_yt_geo_ts", 0.0) > 12.0:
                videofeed.youtube_region_force_recheck()
                self._yt_geo_ts = time.time()
            blocked, why = videofeed.youtube_region_blocked()
            if blocked:
                self._stop_play()
                self._show_stage("cover")
                self.cover.setPixmap(QPixmap())
                self.cover.setText(why or "此功能暂时不对中国大陆开放")
                self.lbl_title.setText(it.get("title") or "油管视频")
                self.lbl_meta.setText(why or "此功能暂时不对中国大陆开放")
                self.lbl_pos.setText("%d / %d" % (i + 1, len(self.items)))
                self.lbl_sub.setVisible(False)
                self.btn_pp.setEnabled(False)
                self.state.setText(why or "此功能暂时不对中国大陆开放")
                return
        self.lbl_pos.setText("%d / %d" % (i + 1, len(self.items)))
        self._title_zh = ""
        self.lbl_title.setText(it.get("title") or "（无标题）")
        meta = "%s · %s" % (videofeed.PLATFORM_NAMES.get(it["platform"], it["platform"]),
                            it.get("author") or "未知作者")
        if it.get("duration"):
            meta += " · " + str(it["duration"])
        if it.get("playable"):
            meta += " · 可在窗口内直接播"
        else:
            meta += " · 本机不能直接播（看封面，或点右下「在平台上打开」）"
        self.lbl_meta.setText(meta)
        self.btn_pp.setEnabled(bool(it.get("playable")))
        self.lbl_sub.setVisible(False)

        # 背景音乐：后台读这条的简介再抠，别卡住界面
        self._bgm(it)

        # 封面：先显示缓存，没有就异步下
        self._show_cover(it)

        # 播放
        self._reset_play_ui()
        if it.get("playable"):
            self._start_play(it)
        # 油管：英文标题顺手翻一段中文（字幕接口那边拿不到，别等它）
        if it["platform"] == "youtube":
            self._translate_title(it)
        # 预取后一条直链，切过去就不用等
        if self.idx + 1 < len(self.items):
            nxt = self.items[self.idx + 1]
            if nxt.get("playable"):
                self._prefetch = [p for p in self._prefetch if _alive(p)]
                pw = _PlayWorker(nxt["id"], nxt.get("cid"),
                                 nxt.get("platform") or self.platform, self)
                pw.done.connect(lambda *_: None)   # 只为预热缓存，结果不用
                pw.finished.connect(pw.deleteLater)
                self._prefetch.append(pw)
                pw.start()

    def _bgm(self, it):
        """去简介里查背景音乐，查到了显示在标题下面。"""
        self._bgm_item_id = it.get("id")
        self.lbl_bgm.setText("背景音乐：正在查简介…")
        self.lbl_bgm.setVisible(True)
        self._bgm_threads = [w for w in getattr(self, "_bgm_threads", [])
                             if _alive(w)]
        bw = _BgmWorker(it, self)
        bw.done.connect(self._on_bgm)
        self._bgm_threads.append(bw)
        bw.start()

    def _on_bgm(self, vid, bgm):
        cur = self._cur()
        if not cur or cur.get("id") != vid:
            return
        if bgm:
            self.lbl_bgm.setText("背景音乐：%s" % bgm)
        else:
            self.lbl_bgm.setText("背景音乐：这条的简介里没写")
        self.lbl_bgm.setVisible(True)

    def _start_play(self, it):
        if not self._ensure_player():
            self.state.setText("没有视频组件，只能看封面。")
            return
        self._drop_old_play()
        # 播放器是复用的：不先停掉，上一条的音频会在取新地址的这几秒继续响
        if self._player is not None:
            try:
                self._player.stop()
                set_source(self._player, QUrl(""))
            except Exception:
                pass
        self._want_play = True
        self._retry = 0
        self._nopic = 0
        self.buf_lbl.setVisible(True)
        self._place_overlays()
        # 这条的直链要是已经缓存着（比如刚才预取过），直接开播，不用再等一次接口
        hit = videofeed.cached_play(it.get("platform") or self.platform,
                                    it.get("id"))
        if hit:
            self._on_play_url(it["id"], hit, "")
            return
        self._show_stage("cover")
        self._play = _PlayWorker(it["id"], it.get("cid"),
                                 it.get("platform") or self.platform, self)
        self._play.done.connect(self._on_play_url)
        self._play.start()
        self.state.setText("正在取这条的播放地址…")

    def _drop_old_play(self):
        """旧的取直链线程还在跑就直接放着别等：它的回调按 id 过滤，
        结果会被丢掉，但线程自己得有人管，所以挂进 _prefetch 等它结束再删。
        以前这里 wait(200)，切条硬等 0.2 秒，就是「卡一下」的来源。
        """
        old = self._play
        self._play = None
        if old is None:
            return
        try:
            old.done.disconnect()
        except Exception:
            pass
        try:
            if _alive(old):
                old.finished.connect(old.deleteLater)
                self._prefetch.append(old)
        except Exception:
            pass

    def _on_play_url(self, bvid, url, err):
        cur = self._cur()
        if not cur or cur.get("id") != bvid:
            return              # 已经切到别的条了，这条的结果丢掉
        if err or not url:
            self.buf_lbl.setVisible(False)
            self._stop_play()          # 取不到地址就别让上一条的声音一直响
            self.state.setText("这条播不了：%s（点「在平台上打开」）" % (err or "没有地址"))
            self._show_stage("cover")
            return
        if self._player is None:
            return
        try:
            # 直链要 Referer / UA，播放器不能带头，走本机转发
            self._src_url = videoproxy.local_url(url)
            _s = self._player
            try:
                _s.stop()
            except Exception:
                pass
            set_source(_s, QUrl(self._src_url))
            self._want_play = True
            self._player.play()
            self.state.setText("正在播放…")
            self._sync_pause(False)
            self._stuck = 0
            self._watch.start()          # 盯着前几秒，别真卡死
            # 代理流有时候一直停在 Buffering、等不来 Loaded/Buffered 状态，
            # 只靠状态回调会把画面一直留在封面上（声音有、画面没有）。
            # 这里起播后自己再兜一层，0.4 秒还没切就把画面切过去。
            QTimer.singleShot(400, self._ensure_stage_video)
            # 换了源，播放器会把音量/倍速复位，这里补回来
            try:
                self._player.setPlaybackRate(getattr(self, "_rate", 1.0))
            except Exception:
                pass
            if hasattr(self, "vol"):
                self._on_vol(self.vol.value())
        except Exception as e:
            self.buf_lbl.setVisible(False)
            self.state.setText("播放失败：%s" % e)

    def _check_stuck(self):
        """起播卡住的自救：3 秒还没走动就重播一次，第二次仍不行就说明这条播不了。"""
        try:
            if not self._want_play or self._player is None:
                self._watch.stop()
                return
            pos = self._player.position()
            if pos > 0:
                self._watch.stop()
                self.buf_lbl.setVisible(False)
                if self._show_stage_is_cover():
                    self._show_stage("video")
                # 进度在走但一直没有视频轨：YouTube 的 adaptive 流是音视频分开的，
                # 万一挑到纯音频流就是「进度条动、画面全黑」。这里明确说出来，
                # 别让用户对着黑屏等到结尾。
                try:
                    hv = bool(self._player.hasVideo())
                except Exception:
                    hv = True
                if not hv:
                    self._nopic += 1
                    if self._nopic >= 2:
                        self.state.setText("这条只有声音、没有画面（视频流没取到），"
                                           "点「在平台上打开」能看原片")
                else:
                    self._nopic = 0
                return
            cur = self._cur()
            if cur is None:
                self._watch.stop()
                return
            # 地址已经塞进播放器、正在加载/缓冲的，别急着重播：油管的地址要
            # 本地拼流，头几秒本来就在等，重播等于再解析一次（6 秒起步）。
            mv = 0
            try:
                mv = getattr(self._player.mediaStatus(), "value", 0)
            except Exception:
                mv = 0
            self._stuck = getattr(self, "_stuck", 0) + 1
            if mv >= 2 and self._stuck <= 26:
                return                  # 状态已经在加载/缓冲，再等它十几秒
            self._retry += 1
            if self._retry <= 2:
                self.state.setText("正在缓冲…重试第 %d 次" % self._retry)
                self._drop_old_play()
                self._play = _PlayWorker(cur["id"], cur.get("cid"),
                                         cur.get("platform") or self.platform, self)
                self._play.done.connect(self._on_play_url)
                self._play.start()
            else:
                self._watch.stop()
                self.buf_lbl.setVisible(False)
                self.state.setText("这条一直没播起来，点「在平台上打开」去网页看。")
        except Exception:
            self._watch.stop()

    def _reset_play_ui(self):
        """换条时只清界面状态，播放器不拆（拆一次要多等一轮重建）。"""
        self._want_play = False
        self._src_url = ""
        try:
            self._watch.stop()
        except Exception:
            pass
        self.buf_lbl.setVisible(False)
        self.pause_ov.set_active(False)
        try:
            self.btn_pp.setText("播放")       # 换条后是没在播，按钮别还写着「暂停」
            self._seeking = False
            self.bar.setRange(0, 0)
            self.bar.setValue(0)
            self.lbl_cur.setText("0:00")
            self.lbl_len.setText("0:00")
        except Exception:
            pass

    def _stop_play(self):
        self._want_play = False
        self._src_url = ""
        try:
            self._watch.stop()
        except Exception:
            pass
        self.buf_lbl.setVisible(False)
        self.pause_ov.set_active(False)
        try:
            self.btn_pp.setText("播放")
            self._seeking = False
            self.bar.setRange(0, 0)
            self.bar.setValue(0)
            self.lbl_cur.setText("0:00")
            self.lbl_len.setText("0:00")
        except Exception:
            pass
        if self._player is not None:
            try:
                self._player.stop()
                set_source(self._player, QUrl(""))
            except Exception:
                pass
        if self.video is not None:
            self._show_stage("cover")

    def next_item(self):
        if not self.items:
            self.load_feed()
            return
        if self.idx + 1 >= len(self.items):
            self.next_batch()
            return
        self.goto(self.idx + 1)

    def prev_item(self):
        if not self.items:
            return
        if self.idx <= 0:
            self.state.setText("已经是第一条了。")
            return
        self.goto(self.idx - 1)

    def open_page(self):
        cur = self._cur()
        url = (cur or {}).get("page_url") or getattr(self, "_open_url", "")
        if not url:
            return
        try:
            QDesktopServices.openUrl(QUrl(url))
        except Exception:
            self.state.setText("打不开链接：%s" % url)

    # ---------- 查这条视频的模组 ----------
    def find_mods(self):
        """按当前这条的标题/标签去 Modrinth 认模组，结果弹窗里给项目页。"""
        cur = self._cur()
        if not cur:
            self.state.setText("先有视频再点「查这片的模组」。")
            return
        if _alive(getattr(self, "_mod_worker", None)):
            self.state.setText("上一条还在查，等它一下。")
            return
        self.btn_mods.setEnabled(False)
        self.state.setText("正在按「%s」去模组站认模组…" % (cur.get("title") or "")[:28])
        w = _ModWorker(cur, self)
        self._mod_worker = w
        w.done.connect(self._on_mods)
        w.start()

    def _on_mods(self, result):
        self.btn_mods.setEnabled(True)
        items = (result or {}).get("items") or []
        if items:
            self.state.setText("认出 %d 个模组：%s" % (
                len(items), "、".join((result.get("used") or [])[:3]))
                            if result.get("used") else "认出 %d 个模组" % len(items))
        else:
            self.state.setText((result or {}).get("note")
                               or "没从这条标题里认出模组")
        try:
            dlg = _ModDialog((self._cur() or {}).get("title") or "", result, self)
            dlg.exec()
        except Exception:
            pass

    # ---------- 封面 ----------
    def _show_cover(self, it):
        url = it.get("cover") or ""
        if not url:
            self._show_stage("cover")
            self.cover.setText("（没有封面）")
            return
        hit = self._cover_cache.get(url)
        if hit:
            self._show_stage("cover")
            self._cover_pm = hit
            self._fit_cover()
            return
        self._show_stage("cover")
        self._cover_pm = None
        self.cover.setText("封面加载中…")
        # 切条时把上一张没下完的取消掉，别抢带宽
        old = self._pending_cover
        if old is not None:
            try:
                if getattr(old, "isRunning", lambda: False)():
                    old.abort()
            except Exception:
                pass
        req = QNetworkRequest(QUrl(url))
        req.setRawHeader(b"User-Agent", videofeed.UA.encode())
        req.setRawHeader(b"Referer", b"https://www.bilibili.com/")
        reply = self._nam.get(req)
        reply.setProperty("tag_url", url)
        self._pending_cover = reply

    def _on_cover(self, reply):
        url = reply.property("tag_url")
        try:
            if reply is self._pending_cover:
                self._pending_cover = None
            code = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
            if code is None or int(code) >= 400:
                return
            data = reply.readAll()
            pm = QPixmap()
            pm.loadFromData(data)
            if pm.isNull():
                return
            if pm.width() > 960:
                pm = pm.scaledToWidth(960, Qt.SmoothTransformation)
            # 按插入顺序丢最旧的，别一刀清空（清空后下一屏全要重下，看着就卡）
            if len(self._cover_cache) >= 40:
                drop = list(self._cover_cache.keys())[:-28]
                for k in drop:
                    self._cover_cache.pop(k, None)
            self._cover_cache.pop(url, None)
            self._cover_cache[url] = pm
            cur = self._cur()
            if cur and (cur.get("cover") or "") == url:
                self._cover_pm = pm
                self._show_stage("cover")
                self._fit_cover()
        except Exception:
            pass
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass

    # ---------- 翻译 / 字幕 ----------
    def _translate_title(self, it):
        texts = [t for t in (it.get("title"), it.get("author")) if t]
        if not texts:
            return
        self._tr = _TrWorker(it["id"], texts, self)
        self._tr.done.connect(self._on_title_zh)
        self._tr.start()

    def _on_title_zh(self, vid, got):
        cur = self._cur()
        if not cur or cur.get("id") != vid:
            return
        zh = got.get(cur.get("title") or "")
        if zh:
            self._title_zh = zh
            self.lbl_title.setText("%s\n%s" % (cur.get("title") or "", zh))
        self.state.setText("英文标题已经翻成中文了；这条可以在窗口里直接播，"
                           "点画面暂停/继续，滚轮切下一条。")

    def _try_subtitles(self, it):
        self._sub = _SubWorker(it["id"], self)
        self._sub.done.connect(self._on_subs)
        self._sub.start()

    def _on_subs(self, vid, segs, err):
        cur = self._cur()
        if not cur or cur.get("id") != vid:
            return
        if not segs:
            return
        texts = [t for _s, t in segs[:200]]
        self._sub_texts = texts
        self._sub_segs = segs
        self._tr = _TrWorker(vid, texts, self)
        self._tr.done.connect(self._on_subs_zh)
        self._tr.start()

    def _on_subs_zh(self, vid, got):
        cur = self._cur()
        if not cur or cur.get("id") != vid:
            return
        segs = getattr(self, "_sub_segs", [])
        if not segs:
            return
        # 按播放进度显示对应那几句
        self._zh_segs = [(t, got.get(txt, "") or txt) for t, txt in segs]
        self.state.setText("字幕已翻成中文，播放进度到哪里就显示哪几句。")
        if self._sub_timer is None:
            self._sub_timer = QTimer(self)
            self._sub_timer.setInterval(400)
            self._sub_timer.timeout.connect(self._tick_subs)
        self._sub_timer.start()

    def _tick_subs(self):
        if self._player is None:
            return
        try:
            pos = self._player.position() / 1000.0
        except Exception:
            return
        zh = getattr(self, "_zh_segs", None)
        if not zh:
            return
        cur = ""
        for i, (t, txt) in enumerate(zh):
            if t <= pos + 0.2:
                cur = txt
                if i + 1 < len(zh) and zh[i + 1][0] > pos + 0.2:
                    break
            else:
                break
        if cur:
            self.lbl_sub.setText(cur)
            self.lbl_sub.setVisible(True)

    def _ensure_stage_video(self):
        """在播就把画面切出来，不等媒体状态回调。

        B 站/油管的直链走本机代理，QMediaPlayer 在代理流下经常一直报
        Buffering、迟迟不发 LoadedMedia，于是画面永远停在封面上——只剩声音。
        这里以「在播 + 有源」为准，直接把画面切过去。
        """
        try:
            if not getattr(self, "_want_play", False) or not self._src_url:
                return
            if self._show_stage_is_cover() and self.video is not None:
                self.buf_lbl.setVisible(False)
                self._show_stage("video")
        except Exception:
            pass

    def _show_stage(self, which):
        """画面区只显示一块：'video' 或 'cover'。"""
        try:
            if which == "video" and self.video is not None:
                self.stage_stack.setCurrentWidget(self.video)
            else:
                self.stage_stack.setCurrentWidget(self.cover)
                self._fit_cover()
        except Exception:
            pass

    def _fit_cover(self):
        """封面按画面区尺寸等比缩放：别让一张原图撑破版面。"""
        pm = getattr(self, "_cover_pm", None)
        if pm is None or pm.isNull():
            return
        box = self.cover.size()
        if box.width() < 40 or box.height() < 40:
            return
        self.cover.setPixmap(pm.scaled(box, Qt.KeepAspectRatio,
                                      Qt.SmoothTransformation))

    def _place_overlays(self):
        """暂停图案铺满画面区，缓冲提示落在正中，全屏退出按钮贴右上角。

        层级顺序必须守住：暂停图案在下面、按钮和提示压在上面。以前是先
        raise 暂停图案再 raise 按钮，看似一样，但全屏后画面区尺寸变了以后
        谁先谁后取决于调用顺序——图案一旦压在按钮上，全屏时按钮就点不到。

        重入保护是必须的：这里会对浮层控制条 resize，而控制条也在 eventFilter
        里看着 Resize，没有这个标志就是「resize → 重排 → resize」死循环。
        """
        if getattr(self, "_placing", False):
            return
        self._placing = True
        try:
            box = self.stage.rect()
            stage_size = (box.width(), box.height())
            self.pause_ov.setGeometry(box)
            self.pause_ov.fit()
            self.buf_lbl.adjustSize()
            self.buf_lbl.move(box.center().x() - self.buf_lbl.width() // 2,
                              box.top() + 16)
            btn = getattr(self, "btn_fs_exit", None)
            if btn is not None:
                btn.adjustSize()
                btn.move(max(8, box.right() - btn.width() - 16), box.top() + 16)
            # 字幕条贴左上，宽度留边
            try:
                w = stage_size[0] - 24
                if w > 60:
                    self.lbl_sub.setGeometry(12, 12, w, self.lbl_sub.height())
            except Exception:
                pass
            fb = getattr(self, "fs_bar", None)
            if fb is not None and fb.isVisible():
                fw = min(max(360, box.width() - 96), 820)
                fh = fb.sizeHint().height() or 44
                if (fb.width(), fb.height()) != (fw, fh):
                    fb.resize(fw, fh)
                fb.move((box.width() - fw) // 2,
                        max(8, box.height() - fh - 20))
            # 统一重排一次层级
            if self.pause_ov.isVisible():
                self.pause_ov.raise_()
            self.lbl_sub.raise_()
            if self.buf_lbl.isVisible():
                self.buf_lbl.raise_()
            if fb is not None and fb.isVisible():
                fb.raise_()
            if btn is not None and btn.isVisible():
                btn.raise_()
        except Exception:
            pass
        finally:
            self._placing = False

    def _is_stage_hit(self, obj):
        return obj in (self.stage, self.stage_stack, self.cover, self.video)

    def _seek_by(self, delta_ms):
        if self._player is None:
            return
        try:
            pos = self._player.position() + delta_ms
            dur = self._player.duration()
            if dur and dur > 0:
                pos = max(0, min(dur, pos))
            else:
                pos = max(0, pos)
            self._player.setPosition(pos)
            self.bar.setValue(int(pos))
            self.lbl_cur.setText(self._fmt_ms(pos))
        except Exception:
            pass

    def keyPressEvent(self, ev):
        """空格暂停、←→ 前后 5 秒、↑↓ 切条——在搜索框里打字时不抢键。"""
        try:
            fw = QApplication.focusWidget()
        except Exception:
            fw = None
        if isinstance(fw, QLineEdit):
            return super().keyPressEvent(ev)
        k = ev.key()
        if k == Qt.Key_Space:
            self.toggle_play()
            return
        if k == Qt.Key_Left:
            self._seek_by(-5000)
            return
        if k == Qt.Key_Right:
            self._seek_by(5000)
            return
        if k == Qt.Key_Up:
            self.prev_item()
            return
        if k == Qt.Key_Down:
            self.next_item()
            return
        if k == Qt.Key_Escape and getattr(self, "_fs_on", False):
            self.exit_stage_full()
            return
        super().keyPressEvent(ev)

    def eventFilter(self, obj, ev):
        """画面区：左键单击 = 暂停 / 继续；按住上下拖 = 切条。

        另外全局拦一下鼠标按下：搜索框在编辑状态时，点别处就收起来。
        """
        try:
            t = ev.type()
            if t == QEvent.KeyPress and ev.key() == Qt.Key_Escape \
                    and getattr(self, "_fs_on", False):
                self.exit_stage_full()
                return True
            if t == QEvent.MouseButtonPress:
                # 点搜索框以外的地方 → 结束输入状态
                es = getattr(self, "ed_search", None)
                if es is not None and es.hasFocus():
                    w = obj
                    if w is not es and not es.isAncestorOf(w):
                        es.clearFocus()
                if self._is_stage_hit(obj) and ev.button() == Qt.LeftButton:
                    self._drag_y = ev.position().y()
                return False
            if t == QEvent.MouseButtonRelease and ev.button() == Qt.LeftButton:
                if self._is_stage_hit(obj) and self._drag_y is not None:
                    dy = ev.position().y() - self._drag_y
                    self._drag_y = None
                    if abs(dy) <= 14:
                        self.toggle_play()
                        return True
                return False
            if t == QEvent.MouseMove:
                # 全屏下鼠标一动就把浮层控制条亮出来
                if getattr(self, "_fs_on", False):
                    self._show_fs_ui()
            if t == QEvent.Resize and obj is not getattr(self, "fs_bar", None):
                self._place_overlays()
        except Exception:
            pass
        return super().eventFilter(obj, ev)

    def showEvent(self, ev):
        super().showEvent(ev)
        if not getattr(self, "_app_filter_on", False):
            app = QApplication.instance()
            if app is not None:
                app.installEventFilter(self)
                self._app_filter_on = True

    def hideEvent(self, ev):
        app = QApplication.instance()
        if app is not None and getattr(self, "_app_filter_on", False):
            app.removeEventFilter(self)
            self._app_filter_on = False
        # 离开这一页就彻底停掉：不只是 pause。pause 在某些后端会留着音频输出，
        # 切到别的页面还能听见声音；stop + 卸载源才是真的不出声。
        try:
            if self._player is not None:
                st = 0
                try:
                    st = getattr(self._player.playbackState(), "value", 0)
                except Exception:
                    st = 1 if getattr(self, "_want_play", False) else 0
                if st == 1 or getattr(self, "_want_play", False):
                    self._stop_play()
        except Exception:
            pass
        super().hideEvent(ev)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._fit_cover()
        self._place_overlays()
        # 字幕条贴着画面区左上，宽度留 24px 边距
        try:
            w = self.stage.width() - 24
            if w > 60:
                self.lbl_sub.setGeometry(12, 12, w, self.lbl_sub.height())
                self.lbl_sub.raise_()
        except Exception:
            pass

    # ---------- 手势：滚轮 / 上下拖动 ----------
    def _ev_pos(self, ev):
        """滚轮事件的落点。Qt5 老版本没有 position()，退到 posF()/pos()。"""
        for name in ("position", "posF", "pos"):
            fn = getattr(ev, name, None)
            if fn is None:
                continue
            try:
                p = fn()
                if isinstance(p, QPoint):
                    return QPointF(p)
                return p
            except Exception:
                continue
        return QPointF(0, 0)

    def _wheel_on_stage(self, ev):
        """滚轮落点是不是在视频画面里。只有画面里滚才切条。

        不能用 ev.position()：滚轮被子控件（标题、封面、按钮）忽略后冒泡上来时，
        坐标还在那个子控件的坐标系里，直接拿去和画面矩形比会一直判不中，
        表现就是「滚轮完全没反应」。这里一律换算成屏幕坐标再比。
        """
        st = getattr(self, "stage", None)
        if st is None or not st.isVisible():
            return False
        gp = None
        for name in ("globalPosition", "globalPos"):
            fn = getattr(ev, name, None)
            if fn is None:
                continue
            try:
                v = fn()
                gp = v.toPoint() if hasattr(v, "toPoint") else v
                break
            except Exception:
                continue
        if gp is None:
            return False
        try:
            top_left = st.mapTo(self, QPoint(0, 0))
            box = QRect(top_left, st.size())
            return box.contains(self.mapFromGlobal(gp))
        except Exception:
            return False

    def wheelEvent(self, ev):
        """滚轮切条：只有在画面里滚才切；画面外照常让界面自己滚。"""
        dy = ev.angleDelta().y()
        if not dy:
            ev.ignore()
            return
        es = getattr(self, "ed_search", None)
        if es is not None and es.hasFocus():
            ev.ignore()                 # 正在打字，滚轮别乱换视频
            return
        if not self._wheel_on_stage(ev):
            # 标题、简介、按钮、列表这些地方滚轮只滚界面，不切视频
            ev.ignore()
            return
        self._wheel_acc += dy
        if abs(self._wheel_acc) < 120:
            ev.accept()
            return
        step = -1 if self._wheel_acc < 0 else 1
        self._wheel_acc = 0
        now = time.monotonic()
        if now - self._wheel_t < 0.6:
            ev.accept()
            return
        self._wheel_t = now
        if step > 0:
            self.next_item()
        else:
            self.prev_item()
        ev.accept()

    def mousePressEvent(self, ev):
        self._drag_y = ev.position().y()
        super().mousePressEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._drag_y is not None:
            dy = ev.position().y() - self._drag_y
            self._drag_y = None
            if abs(dy) > 60:
                if dy < 0:
                    self.next_item()
                else:
                    self.prev_item()
        super().mouseReleaseEvent(ev)

    def refresh(self):
        """被切到这一页时调用：没内容就自动取。"""
        if not self.items and self.platform not in ("douyin", "xiaohongshu"):
            self.load_feed(reset_page=True)

    def stop(self):
        """离开这一页：停掉播放，别在后台占着解码器。"""
        self._stop_play()
        if self._sub_timer is not None:
            self._sub_timer.stop()
