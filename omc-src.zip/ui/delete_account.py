# -*- coding: utf-8 -*-
"""注销账号向导：5 道确认，注销这种不可恢复的操作必须一道都不能省。

  1. 明白后果（必须勾选）
  2. 把账号名一字不差打一遍
  3. 输入密码（用和登录一样的哈希校验）
  4. 验证码（发到账号邮箱；手机号账号走本机码）
     微信 / QQ 扫码建的账号改成「扫码 + 手机确认」这一道
  5. 输入「注销」两个字 + 点红色按钮，才真正删
"""
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPushButton,
                               QStackedWidget, QVBoxLayout, QWidget)
import threading

from core import accounts, avatar, frienddir, mailcode, qrlogin

CARD_QSS = "QDialog#AccountCard { background: #1E2128; }"

_STEP = [
    ("第 1 / 5 步 · 明白后果", "注销会把「%(name)s」从这台设备上彻底删掉："
     "密码、记住的密码、绑定的游戏账号、头像一起清空。删掉之后没法恢复，"
     "客服也找不回来。想留条后路，先回账号页点「导出账号备份」。"),
    ("第 2 / 5 步 · 打账号名", "把要注销的账号名一字不差打一遍："),
    ("第 3 / 5 步 · 验证密码", "输入「%(name)s」的登录密码（跟登录时校验的是同一套哈希）："),
    ("第 4 / 5 步 · 验证码", "点「发送验证码」，会发到 %(email)s；收到后填进来："),
    ("第 5 / 5 步 · 最后确认", "最后一步：在下面输入「注销」两个字，再点红色按钮。"),
]


class DeleteAccountDialog(QDialog):
    def __init__(self, name, config, parent=None):
        super().__init__(parent)
        self.name = name or ""
        self.config = config
        self.email = accounts.email_of(self.name)
        self.via = accounts.via_of(self.name)
        self._code = ""
        self._qr_ticket = ""
        self._qr_server = None
        self.done_delete = False
        self.setObjectName("AccountCard")
        self.setWindowTitle("注销账号 · %s" % self.name)
        self.setStyleSheet(CARD_QSS)
        self.setMinimumWidth(520)
        self._build()
        self._render()

    # ---------- 界面 ----------
    def _build(self):
        v = QVBoxLayout(self)
        v.setSpacing(10)
        self.lbl_step = QLabel("")
        self.lbl_step.setStyleSheet(
            "font-size: 15px; font-weight: 700; color: #FF9A9A;")
        v.addWidget(self.lbl_step)
        self.lbl_tip = QLabel("")
        self.lbl_tip.setObjectName("PageSub")
        self.lbl_tip.setWordWrap(True)
        v.addWidget(self.lbl_tip)

        self.stack = QStackedWidget()
        v.addWidget(self.stack)

        # 1 明白后果
        p1 = QWidget()
        c1 = QVBoxLayout(p1)
        self.chk_known = QCheckBox(
            "我知道注销后账号、密码、绑定、头像全部清掉，且无法恢复")
        self.chk_backup = QCheckBox("我已经导出过账号备份（可选）")
        c1.addWidget(self.chk_known)
        c1.addWidget(self.chk_backup)
        c1.addStretch(1)
        self.stack.addWidget(p1)

        # 2 账号名
        p2 = QWidget()
        c2 = QVBoxLayout(p2)
        self.in_name = QLineEdit()
        self.in_name.setPlaceholderText("在这里打账号名")
        c2.addWidget(self.in_name)
        c2.addStretch(1)
        self.stack.addWidget(p2)

        # 3 密码
        p3 = QWidget()
        c3 = QVBoxLayout(p3)
        self.in_pwd = QLineEdit()
        self.in_pwd.setEchoMode(QLineEdit.Password)
        self.in_pwd.setPlaceholderText("登录密码")
        c3.addWidget(self.in_pwd)
        c3.addStretch(1)
        self.stack.addWidget(p3)

        # 4 验证码 或 扫码
        p4 = QWidget()
        c4 = QVBoxLayout(p4)
        self.row4 = QHBoxLayout()
        self.in_code = QLineEdit()
        self.in_code.setMaxLength(6)
        self.in_code.setPlaceholderText("6 位验证码")
        self.b_send = QPushButton("发送验证码")
        self.b_send.setFixedWidth(110)
        self.b_send.clicked.connect(self._send_code)
        self.row4.addWidget(self.in_code, 1)
        self.row4.addWidget(self.b_send)
        c4.addLayout(self.row4)
        self.lbl_qr = QLabel("还没有生成二维码，点下面的按钮。")
        self.lbl_qr.setAlignment(Qt.AlignCenter)
        self.lbl_qr.setMinimumHeight(180)
        self.lbl_qr.setStyleSheet(
            "QLabel{background:#151820;border:1px solid #2A2E38;border-radius:10px;"
            "color:#7f8794;}")
        c4.addWidget(self.lbl_qr)
        self.row4b = QHBoxLayout()
        self.b_qr = QPushButton("生成二维码（手机扫码确认）")
        self.b_qr.clicked.connect(self._make_qr)
        self.lbl_qr_state = QLabel("")
        self.lbl_qr_state.setObjectName("PageSub")
        self.row4b.addWidget(self.b_qr)
        self.row4b.addWidget(self.lbl_qr_state, 1)
        c4.addLayout(self.row4b)
        c4.addStretch(1)
        self.stack.addWidget(p4)

        # 5 终确认
        p5 = QWidget()
        c5 = QVBoxLayout(p5)
        self.in_word = QLineEdit()
        self.in_word.setPlaceholderText("在这里输入「注销」")
        c5.addWidget(self.in_word)
        c5.addStretch(1)
        self.stack.addWidget(p5)

        self.lbl_err = QLabel("")
        self.lbl_err.setWordWrap(True)
        self.lbl_err.setStyleSheet("color: #FF7A7A;")
        v.addWidget(self.lbl_err)

        row = QHBoxLayout()
        row.addStretch(1)
        self.b_back = QPushButton("上一步")
        self.b_back.clicked.connect(self._back)
        row.addWidget(self.b_back)
        self.b_next = QPushButton("下一步")
        self.b_next.setObjectName("PrimaryButton")
        self.b_next.clicked.connect(self._next)
        row.addWidget(self.b_next)
        b_cancel = QPushButton("取消")
        b_cancel.clicked.connect(self.reject)
        row.addWidget(b_cancel)
        v.addLayout(row)

        self.chk_known.toggled.connect(self._render)
        self.in_word.textChanged.connect(self._update_next)

    def _render(self):
        self.lbl_step.setText(_STEP[self._idx][0])
        t = _STEP[self._idx][1]
        t = t % {"name": self.name, "email": self.email or "（这个账号没有邮箱）"}
        self.lbl_tip.setText(t)
        self.stack.setCurrentIndex(self._idx)
        self.b_back.setVisible(self._idx > 0)
        is_qr = self._use_qr()
        if self._idx == 3:
            self.in_code.setVisible(not is_qr)
            self.b_send.setVisible(not is_qr)
            self.lbl_qr.setVisible(is_qr)
            self.b_qr.setVisible(is_qr)
            self.lbl_qr_state.setVisible(is_qr)
        if self._idx == 4:
            self.b_next.setText("确认注销")
            self.b_next.setStyleSheet(
                "background:#B32222;color:#fff;font-weight:700;")
        else:
            self.b_next.setText("下一步")
            self.b_next.setStyleSheet("")
        self._update_next()

    def _update_next(self):
        if self._idx == 0:
            self.b_next.setEnabled(self.chk_known.isChecked())
        elif self._idx == 4:
            self.b_next.setEnabled(self.in_word.text().strip() == "注销")
        else:
            self.b_next.setEnabled(True)

    def _use_qr(self):
        """微信 / QQ 扫码建的账号：这一道必须是手机扫码确认。"""
        return self.via in ("wechat", "qq_qr", "qq") and "@omc.local" not in (
            self.email or "")

    @property
    def _idx(self):
        return self.stack.currentIndex()

    # ---------- 步骤 ----------
    def _back(self):
        if self._idx > 0:
            self.stack.setCurrentIndex(self._idx - 1)
            self.lbl_err.setText("")
            self._render()

    def _next(self):
        self.lbl_err.setText("")
        i = self._idx
        if i == 0:
            if not self.chk_known.isChecked():
                self.lbl_err.setText("先把上面那个框勾上。")
                return
        elif i == 1:
            if (self.in_name.text() or "").strip() != self.name:
                self.lbl_err.setText("账号名对不上，一个字都不能差。")
                return
        elif i == 2:
            ok, why = accounts.verify_password(self.name, self.in_pwd.text())
            if not ok:
                self.lbl_err.setText(why)
                return
        elif i == 3:
            if self._use_qr():
                if qrlogin.state(self._qr_ticket) != "confirmed":
                    self.lbl_err.setText("还要在手机上点「确认登录 / 确认注销」这一步。")
                    return
            else:
                ok, why = mailcode.verify(self.email, self.in_code.text())
                if not ok:
                    self.lbl_err.setText(why)
                    return
        elif i == 4:
            if self.in_word.text().strip() != "注销":
                self.lbl_err.setText("要输入「注销」两个字。")
                return
            self._do_delete()
            return
        self.stack.setCurrentIndex(i + 1)
        self._render()

    # 第 4 步：验证码
    def _send_code(self):
        if not self.email:
            self.lbl_err.setText("这个账号没留邮箱，用扫码那一道。")
            return
        conf = self.config.get("smtp") or {}
        has_smtp = bool((conf.get("user") or "").strip())
        dev_ok = (not has_smtp) or self.email.endswith("@omc.local")
        ok, msg, code = mailcode.send_code(self.email, conf, dev_ok=dev_ok)
        if not ok:
            self.lbl_err.setText(msg)
            return
        if code:
            self.in_code.setText(code)
            msg = "验证码：%s（已经填好了）" % code
        self.lbl_err.setStyleSheet("color: #9AA4B4;")
        self.lbl_err.setText(msg)

    # 第 4 步：扫码
    def _make_qr(self):
        if self._qr_server is None:
            self._qr_server = qrlogin.QrServer()
        port = self._qr_server.start()
        if not port:
            self.lbl_qr_state.setText("开不了本地端口，8901 起都被占了。")
            return
        kind = "微信扫码" if self.via == "wechat" else "QQ 扫码"
        self._qr_ticket = qrlogin.new_ticket(kind, self.name, port)
        png = qrlogin.qr_png(self._qr_ticket, port)
        if png:
            pm = QPixmap()
            pm.loadFromData(png)
            self.lbl_qr.setPixmap(pm.scaled(170, 170, Qt.KeepAspectRatio,
                                            Qt.SmoothTransformation))
        else:
            self.lbl_qr.setText("没装 qrcode，画不出图，手动打开下面的网址。")
        self.lbl_qr_state.setText("网址：%s（3 分钟有效）"
                                  % qrlogin.url_for(self._qr_ticket, port))
        if not hasattr(self, "_qr_timer"):
            self._qr_timer = QTimer(self)
            self._qr_timer.timeout.connect(self._poll_qr)
        self._qr_timer.start(1500)

    def _poll_qr(self):
        st = qrlogin.state(self._qr_ticket)
        if st == "confirmed":
            self._qr_timer.stop()
            self.lbl_qr_state.setText("手机已确认，可以点「下一步」。")
            self.lbl_err.setStyleSheet("color: #4ADE80;")
            self.lbl_err.setText("手机上已经确认。")
        elif st in ("cancelled", "expired", "missing"):
            self._qr_timer.stop()
            self.lbl_qr_state.setText("二维码失效了，重新生成一个。")

    # 真正删
    def _do_delete(self):
        accounts.delete_account(self.name)
        try:
            avatar.clear(self.name)
        except Exception:
            pass
        try:
            threading.Thread(
                target=frienddir.announce,
                args=(self.name, self.name, False), daemon=True).start()
        except Exception:
            pass
        try:
            if self._qr_server:
                self._qr_server.stop()
        except Exception:
            pass
        self.done_delete = True
        self.accept()
