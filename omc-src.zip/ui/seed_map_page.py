# -*- coding: utf-8 -*-
"""种子地图：填个种子就把整张地图画出来，鼠标能拖着走。

- 底图按 1 像素 = N 格现算，不再二次放大，所以不糊
- 勾了「显示遗迹」：每个遗迹位置画一个对应的小图案（房子 / 塔 / 船 / 石砖…）
- 勾了「显示生物群系」：按色块之外，再叠一层「方块图案」（草方块 / 沙子 /
  水 / 雪 / 树木…），放大到一定程度才显示，免得密集到看不清
- 右键任意位置：复制坐标 / 在此加标记
- 右键自己加的标记：删除标记 / 复制标记坐标
"""
import os
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QThread, Signal
from PySide6.QtGui import (
    QAction, QColor, QFont, QPainter, QPen, QPixmap,
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QGraphicsItem, QGraphicsPixmapItem,
    QGraphicsScene, QGraphicsView, QHBoxLayout, QLabel, QLineEdit, QMenu,
    QPushButton, QVBoxLayout, QWidget,
)

from core import seedarchive, seedcalc

VER_LIST = ("1.21", "1.20", "1.19", "1.18", "1.17", "1.16")
SPAN_LIST = (("±1024（近处，最细）", 1024), ("±2048（常用）", 2048),
             ("±4096（大范围）", 4096))

ICON = 22          # 图案边长（场景坐标）
SAMPLE = 20        # 群系图案每隔几个底图像素放一个


# ---------------------------------------------------------------- 图案
def _base_pix(bg, fg, border="#2b2b2b"):
    """一个像素风格的方块底图。"""
    pm = QPixmap(ICON, ICON)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, False)
    p.fillRect(1, 1, ICON - 2, ICON - 2, QColor(bg))
    p.setPen(QPen(QColor(border), 1))
    p.drawRect(1, 1, ICON - 3, ICON - 3)
    # 左上高光，看着像方块
    p.fillRect(2, 2, ICON - 4, 2, QColor(255, 255, 255, 46))
    p.setPen(QPen(QColor(fg), 2))
    p.end()
    return pm, p


def _struct_icon(kind):
    """遗迹图案：用地标方块的样子画，一眼能认出是什么。"""
    kind = (kind or "").lower()
    pm = QPixmap(ICON, ICON)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, False)
    C = lambda h: QColor(h)

    def frame(bg, edge="#202020"):
        p.fillRect(1, 1, ICON - 2, ICON - 2, C(bg))
        p.setPen(QPen(C(edge), 1))
        p.drawRect(1, 1, ICON - 3, ICON - 3)

    if kind == "village":
        frame("#79c94b")
        p.fillRect(6, 8, 10, 9, C("#8b5a2b"))          # 木墙
        p.fillRect(4, 4, 14, 5, C("#c9a227"))          # 草顶
        p.fillRect(9, 12, 4, 5, C("#3d2a12"))          # 门
    elif kind == "outpost":
        frame("#8a8a8a")
        p.fillRect(5, 10, 12, 7, C("#5b4b32"))
        p.fillRect(6, 3, 10, 8, C("#6f6f6f"))
        p.fillRect(9, 2, 4, 2, C("#c0392b"))
    elif kind == "monument":
        frame("#3f9fd6")
        p.fillRect(4, 8, 14, 10, C("#2f7fa6"))
        p.fillRect(6, 5, 4, 3, C("#7fd6f2"))
        p.fillRect(12, 5, 4, 3, C("#7fd6f2"))
    elif kind == "mansion":
        frame("#5b4b8a")
        p.fillRect(4, 8, 14, 9, C("#6b4f2a"))
        p.fillRect(5, 4, 12, 5, C("#4a3b6b"))
        p.fillRect(9, 13, 4, 4, C("#2e2418"))
    elif kind == "ancient_city":
        frame("#2f5f8f")
        p.fillRect(4, 10, 14, 7, C("#1f3f5f"))
        p.fillRect(7, 5, 8, 6, C("#4fa3d1"))
    elif kind == "desert_pyramid":
        frame("#e0c46b")
        for i in range(5):
            p.fillRect(4 + i, 5 + i * 3, 14 - 2 * i, 3, C("#cfae55"))
    elif kind == "jungle_temple":
        frame("#2f8f4a")
        for y in range(3):
            for x in range(3):
                p.fillRect(4 + x * 6, 6 + y * 5, 5, 4, C("#6f8f5f"))
        p.fillRect(9, 16, 4, 4, C("#1f5f2a"))
    elif kind == "swamp_hut":
        frame("#8a5bb0")
        p.fillRect(5, 7, 12, 10, C("#4a3b2a"))
        p.fillRect(9, 13, 4, 4, C("#86d8ff"))
        p.fillRect(7, 4, 8, 3, C("#2f1f3f"))
    elif kind == "igloo":
        frame("#dfe9f2")
        p.setPen(QPen(C("#9fb8cc"), 1))
        p.drawArc(QRectF(4, 5, 14, 14), 0, 180 * 16)
        p.fillRect(9, 12, 4, 5, C("#b8d8ff"))
    elif kind == "ruined_portal":
        frame("#a463d6")
        p.fillRect(5, 5, 4, 13, C("#3b2a4a"))
        p.fillRect(13, 5, 4, 13, C("#3b2a4a"))
        p.fillRect(9, 6, 4, 11, C("#8a2be2"))
    elif kind == "shipwreck":
        frame("#8a6234")
        p.fillRect(4, 11, 14, 4, C("#6b4a24"))
        p.fillRect(10, 5, 2, 8, C("#d8c8a8"))
    elif kind == "ocean_ruin":
        frame("#4fb3b3")
        for x in (5, 9, 13):
            p.fillRect(x, 9, 3, 8, C("#2f8f8f"))
        p.fillRect(4, 7, 14, 3, C("#7fd6d6"))
    elif kind == "buried_treasure":
        frame("#e8b53a")
        p.fillRect(6, 8, 10, 8, C("#ffd84a"))
        p.fillRect(8, 11, 6, 2, C("#a87a10"))
    elif kind == "trail_ruins":
        frame("#d98a3f")
        p.fillRect(4, 12, 14, 6, C("#c1762f"))
        p.fillRect(6, 6, 4, 6, C("#9aa0a6"))
    elif kind == "trial_chambers":
        frame("#c96b3f")
        p.fillRect(5, 8, 12, 9, C("#a8542f"))
        p.fillRect(7, 5, 8, 4, C("#d98a6f"))
    elif kind == "stronghold":
        frame("#b04ad6")
        for y in range(2):
            for x in range(2):
                p.fillRect(4 + x * 7, 6 + y * 6, 6, 5, C("#8a8a8a"))
        p.fillRect(9, 9, 4, 4, C("#3b2a4a"))
        p.fillRect(10, 14, 2, 3, C("#22c55e"))
    else:
        frame("#a0a0a0")
        p.fillRect(7, 7, 8, 8, C("#d0d0d0"))
    p.end()
    return pm


_BIOME_SHAPE = (
    # (关键词, 底图色, 图案色, 形状)
    (("ocean", "river"), "#2f6fa8", "#bfe4ff", "wave"),
    (("beach", "shore"), "#dcc98a", "#fff3c4", "dot"),
    (("desert", "badlands"), "#d8b867", "#a8802a", "dune"),
    (("snow", "frozen", "ice", "grove", "peak"), "#e8f2f8", "#9fb8cc", "snow"),
    (("jungle", "bamboo", "mangrove"), "#2f8f3f", "#1f6b2a", "tree"),
    (("taiga", "forest", "grove", "meadow", "windswept"), "#3f8f3f", "#2a5f2a", "tree"),
    (("swamp",), "#4a6b3a", "#7fbf5f", "lily"),
    (("mushroom",), "#8f6f8f", "#e0d0e0", "mush"),
    (("cherry",), "#f6c8dd", "#d98fb0", "flower"),
    (("cave", "deep_dark", "dripstone"), "#4a4a4a", "#7a7a7a", "stone"),
    (("plains", "savanna", "sunflower", "flower"), "#7fc94b", "#e8d84a", "grass"),
    (("nether", "crimson", "warped", "basalt", "soul"), "#8f3f3f", "#d98a6a", "stone"),
    (("end",), "#d8d0a8", "#8a8a6a", "stone"),
)


def _biome_style(name):
    low = (name or "").lower()
    for keys, bg, fg, shape in _BIOME_SHAPE:
        if any(k in low for k in keys):
            return bg, fg, shape
    return "#6b8f6b", "#3f5f3f", "grass"


def _biome_icon(name):
    """群系图案：画成对应方块（水/沙/雪/草/树…），方块上带一点纹样。"""
    bg, fg, shape = _biome_style(name)
    pm = QPixmap(ICON, ICON)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, False)
    p.fillRect(1, 1, ICON - 2, ICON - 2, QColor(bg))
    p.setPen(QPen(QColor(0, 0, 0, 90), 1))
    p.drawRect(1, 1, ICON - 3, ICON - 3)
    p.setPen(QPen(QColor(fg), 2))
    w = ICON
    if shape == "wave":
        for i in range(3):
            y = 6 + i * 5
            p.drawLine(3, y, w - 4, y)
    elif shape == "dune":
        p.drawArc(QRectF(3, 8, w - 6, 10), 0, 180 * 16)
    elif shape == "snow":
        cx = cy = w // 2
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (1, 1),
                       (-1, 1), (1, -1)):
            p.drawLine(cx, cy, cx + dx * 7, cy + dy * 7)
    elif shape == "tree":
        p.fillRect(w // 2 - 1, 11, 3, 8, QColor("#6b4a24"))
        p.fillRect(6, 5, 11, 7, QColor(fg))
        p.setPen(QPen(QColor(0, 0, 0, 60), 1))
        p.drawRect(6, 5, 10, 6)
    elif shape == "lily":
        p.drawEllipse(QRectF(4, 6, w - 9, w - 11))
    elif shape == "mush":
        p.fillRect(9, 12, 4, 6, QColor("#efd8c0"))
        p.fillRect(5, 6, 12, 7, QColor("#e05555"))
    elif shape == "flower":
        p.drawEllipse(QRectF(7, 7, 8, 8))
    elif shape == "stone":
        p.drawLine(4, 8, 10, 10)
        p.drawLine(10, 10, w - 5, 6)
        p.drawLine(5, 14, 9, 16)
    elif shape == "dot":
        p.drawPoint(8, 9)
        p.drawPoint(14, 13)
        p.drawPoint(10, 16)
    else:                     # grass
        p.drawLine(6, 16, 6, 9)
        p.drawLine(10, 17, 10, 7)
        p.drawLine(14, 16, 14, 10)
    p.end()
    return pm


# ---------------------------------------------------------------- 视图
class _UserMark(QGraphicsPixmapItem):
    """用户自己加的标记：一面小旗，右键能删、能复制坐标。"""

    SIZE = 18

    def __init__(self, wx, wz, note=""):
        pm = QPixmap(self.SIZE, self.SIZE)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor("#ffd84a"), 1))
        p.drawLine(3, 2, 3, self.SIZE - 2)
        p.fillRect(4, 3, 11, 8, QColor("#ff5a5a"))
        p.setPen(QPen(QColor("#7a2020"), 1))
        p.drawRect(4, 3, 10, 7)
        p.end()
        super().__init__(pm)
        self.wx = int(wx)
        self.wz = int(wz)
        self.note = note
        self.setZValue(20)
        self.setToolTip("标记 x=%d z=%d" % (wx, wz))


class MapView(QGraphicsView):
    """能拖动、能滚轮缩放、能右键操作的地图视图。"""

    coords = Signal(int, int)        # 鼠标所指的方块坐标

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("SeedMapView")
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setMouseTracking(True)
        self._zoom = 1.0
        self._item = None
        self._step = 1
        self._span = 2048
        self._pattern_group = None
        self._pattern_items = []
        self.marks = []                   # [(wx, wz, note)]
        self.on_mark_added = None         # 回调，页面拿去存配置

    # ---------- 底图 ----------
    def show_pixmap(self, pix, block_per_px=1, fit=True):
        sc = QGraphicsScene(self)
        self._item = QGraphicsPixmapItem(pix)
        self._step = max(1, int(block_per_px))
        # 注意：底图不要再 setScale(step)。1 底图像素 = step 格是由换算函数
        # 负责的（to_world / add_mark 都乘了 step）；这里再放大就会重复算，
        # 右键点到的坐标会偏成 step 倍。
        sc.addItem(self._item)
        self.setScene(sc)
        self._pattern_group = None
        self._pattern_items = []
        self._zoom = 1.0
        for wx, wz, note in self.marks:
            self.add_mark(wx, wz, note, save=False)
        if fit:
            self.fit_map()

    def set_extent(self, span, step):
        self._span = int(span)
        self._step = max(1, int(step))

    # ---------- 群系图案层 ----------
    def set_patterns(self, samples):
        """samples: [(像素 x, 像素 y, 群系名)]，按底图像素坐标给。"""
        if self.scene() is None:
            return
        if self._pattern_group is not None:
            self.scene().removeItem(self._pattern_group)
            self._pattern_group = None
            self._pattern_items = []
        if not samples:
            return
        cache = {}
        for px, py, name in samples:
            pm = cache.get(name)
            if pm is None:
                pm = _biome_icon(name)
                cache[name] = pm
            it = QGraphicsPixmapItem(pm, self._item)
            it.setFlag(QGraphicsItem.ItemIgnoresTransformations, True)
            it.setOffset(-ICON / 2.0, -ICON / 2.0)
            it.setPos(px, py)
            it.setZValue(6)
            it.setOpacity(0.94)
            it.setToolTip(seedcalc.biome_cn(name))
            self._pattern_items.append(it)
        self._pattern_group = True
        self._apply_pattern_visibility()

    def _apply_pattern_visibility(self):
        # 图案是屏幕固定大小（不随缩放变大），全图时挤在一起会糊成一片，
        # 所以放大到一定程度才显示；看群系整体分布时底图色块已经够用。
        show = self._zoom >= 0.8
        for it in self._pattern_items:
            it.setVisible(show)

    # ---------- 缩放 / 定位 ----------
    def fit_map(self):
        if self.scene() is None:
            return
        self.fitInView(self.scene().itemsBoundingRect(), Qt.KeepAspectRatio)
        tr = self.transform()
        self._zoom = tr.m11()
        self._apply_pattern_visibility()

    def wheelEvent(self, ev):
        if self.scene() is None:
            return
        step = 1.15 if ev.angleDelta().y() > 0 else 1 / 1.15
        nz = self._zoom * step
        if nz < 0.05 or nz > 30:
            return
        self._zoom = nz
        self.scale(step, step)
        self._apply_pattern_visibility()

    def mouseDoubleClickEvent(self, ev):
        self.fit_map()

    # ---------- 坐标换算 ----------
    def to_world(self, view_pos):
        pt = self.mapToScene(view_pos)
        wx = int(round(pt.x() * self._step)) - self._span
        wz = int(round(pt.y() * self._step)) - self._span
        return wx, wz

    def mouseMoveEvent(self, ev):
        wx, wz = self.to_world(ev.position().toPoint())
        self.coords.emit(wx, wz)
        super().mouseMoveEvent(ev)

    # ---------- 标记 ----------
    def add_mark(self, wx, wz, note="", save=True):
        if self.scene() is None:
            return None
        px = (wx + self._span) / float(self._step)
        py = (wz + self._span) / float(self._step)
        it = _UserMark(wx, wz, note)
        it.setPos(QPointF(px - 9, py - 18))
        self.scene().addItem(it)
        rec = (int(wx), int(wz), note or "")
        if rec not in self.marks:
            self.marks.append(rec)
        if save and callable(self.on_mark_added):
            self.on_mark_added(self.marks)
        return it

    def remove_mark(self, item):
        try:
            for wx, wz, note in list(self.marks):
                if wx == item.wx and wz == item.wz:
                    self.marks.remove((wx, wz, note))
                    break
            self.scene().removeItem(item)
            if callable(self.on_mark_added):
                self.on_mark_added(self.marks)
            return True
        except Exception:
            return False

    def mark_at(self, view_pos):
        """点在哪面旗附近才算点中它——按距离判，不靠图元边缘（旗子小、容易点偏）。"""
        if self.scene() is None:
            return None
        pt = self.mapToScene(view_pos)
        tol = 16.0 / max(0.05, self._zoom)     # 屏幕上约 16 像素的范围
        best, bestd = None, tol
        for it in self.scene().items():
            if not isinstance(it, _UserMark):
                continue
            px = (it.wx + self._span) / float(self._step)
            py = (it.wz + self._span) / float(self._step)
            d = ((pt.x() - px) ** 2 + (pt.y() - py) ** 2) ** 0.5
            if d <= bestd:
                best, bestd = it, d
        return best

    # ---------- 右键 ----------
    def menu_for(self, view_pos):
        """建右键菜单并返回 (菜单, 上下文)，方便单独验证菜单项。"""
        wx, wz = self.to_world(view_pos)
        mark = self.mark_at(view_pos)
        menu = QMenu(self)
        # QMenu 走实色样式，别跟着玻璃化变半透明
        menu.setStyleSheet(
            "QMenu{background:#232326;color:#e8e8ea;border:1px solid #3a3a40;"
            "padding:4px;}QMenu::item{padding:6px 18px;}"
            "QMenu::item:selected{background:#3a6ea5;}")
        ctx = {"wx": wx, "wz": wz, "mark": mark}
        if mark is not None:
            ctx["del"] = QAction("删除这个标记", menu)
            ctx["copy"] = QAction("复制标记坐标（%d, %d）"
                                  % (mark.wx, mark.wz), menu)
            menu.addAction(ctx["del"])
            menu.addAction(ctx["copy"])
        else:
            ctx["pin"] = QAction("在此加标记（%d, %d）" % (wx, wz), menu)
            ctx["copy"] = QAction("复制此点坐标", menu)
            menu.addAction(ctx["pin"])
            menu.addAction(ctx["copy"])
        return menu, ctx

    def run_menu(self, act, ctx):
        if act is None or not ctx:
            return
        mark = ctx.get("mark")
        if act is ctx.get("del") and mark is not None:
            self.remove_mark(mark)
        elif act is ctx.get("copy"):
            text = ("%d %d" % (mark.wx, mark.wz)) if mark is not None \
                else ("%d %d" % (ctx.get("wx"), ctx.get("wz")))
            QApplication.clipboard().setText(text)
        elif act is ctx.get("pin"):
            self.add_mark(ctx.get("wx"), ctx.get("wz"))

    def contextMenuEvent(self, ev):
        menu, ctx = self.menu_for(ev.pos())
        self.run_menu(menu.exec(ev.globalPos()), ctx)


class _MapWorker(QThread):
    done = Signal(object, str)
    failed = Signal(str)

    def __init__(self, ver, seed, span, want_struct, want_biome=True, parent=None):
        super().__init__(parent)
        self.ver = ver
        self.seed = seed
        self.span = span
        self.want_struct = want_struct
        self.want_biome = want_biome

    def run(self):
        try:
            side = self.span * 2
            step = max(1, int(round(side / 512.0)))
            data = seedcalc.biome_grid(self.ver, self.seed,
                                       -self.span, -self.span,
                                       side, side, step)
            marks = []
            if self.want_struct:
                try:
                    res = seedcalc.find_structures(self.ver, self.seed,
                                                   self.span)
                    for it in res.get("structures") or []:
                        marks.append((it.get("x"), it.get("z"),
                                      it.get("type"),
                                      seedcalc.STRUCT_LABELS.get(
                                          it.get("type"), it.get("type")))
                                     )
                except Exception:
                    marks = []
            out = os.path.join(_cache_dir(), "seedmap_live.png")
            # 底图只画群系色块，遗迹改成场景里的图案图元（缩放时不会糊）
            w, h = seedcalc.render_biome_png(data, out, -self.span, -self.span,
                                             marks=None, scale=1)
            # 群系图案抽样：每 SAMPLE 个底图像素取一个
            samples = []
            legend = data.get("legend") or {}
            ids = data.get("biomes") or []
            if legend and ids:
                sw, sh = int(data.get("w") or 0), int(data.get("h") or 0)
                for py in range(0, sh, SAMPLE):
                    for px in range(0, sw, SAMPLE):
                        idx = py * sw + px
                        if idx >= len(ids):
                            continue
                        name = legend.get(str(ids[idx])) or legend.get(ids[idx])
                        if name:
                            samples.append((px, py, name))
            self.done.emit({"png": out, "w": w, "h": h, "step": step,
                            "span": self.span, "marks": marks,
                            "samples": samples}, "")
        except Exception as e:
            self.failed.emit(str(e))


def _cache_dir():
    base = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher", "maps")
    try:
        os.makedirs(base, exist_ok=True)
    except OSError:
        return os.path.expanduser("~")
    return base


class SeedMapPage(QWidget):
    """工具页里的「种子地图」。"""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = getattr(host, "config", None)
        self._worker = None
        self._last = None
        self._marks = []          # [(wx, wz, note)]

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 10, 0, 0)
        v.setSpacing(10)

        # 工具行拆成两行：原来一行 20 多个控件，最小宽度 1421，
        # 会把主窗口撑到 1689（屏幕 1536 都放不下，右侧直接被切掉）。
        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(QLabel("用存档的种子"))
        self.cb_save = QComboBox()
        self.cb_save.setMinimumWidth(120)
        self.cb_save.setToolTip("直接读存档里的种子，不用自己记")
        self.cb_save.activated.connect(self._on_save_picked)
        row.addWidget(self.cb_save, 1)
        self.btn_scan = QPushButton("刷新存档")
        self.btn_scan.setMinimumWidth(76)
        self.btn_scan.clicked.connect(lambda: self.fill_saves())
        row.addWidget(self.btn_scan)
        row.addWidget(QLabel("种子"))
        self.ed_seed = QLineEdit()
        self.ed_seed.setPlaceholderText("填数字种子，回车就画")
        self.ed_seed.setMinimumWidth(120)
        self.ed_seed.returnPressed.connect(self.draw)
        row.addWidget(self.ed_seed, 1)
        row.addWidget(QLabel("版本"))
        self.cb_ver = QComboBox()
        for x in VER_LIST:
            self.cb_ver.addItem(x)
        self.cb_ver.setMinimumWidth(76)
        self.cb_ver.currentTextChanged.connect(lambda _x: self.draw())
        row.addWidget(self.cb_ver)
        self.btn_draw = QPushButton("画地图")
        self.btn_draw.clicked.connect(self.draw)
        row.addWidget(self.btn_draw)
        v.addLayout(row)

        row2 = QHBoxLayout()
        row2.setSpacing(8)
        row2.addWidget(QLabel("范围"))
        self.cb_span = QComboBox()
        for lab, _span in SPAN_LIST:
            self.cb_span.addItem(lab)
        self.cb_span.setCurrentIndex(1)
        self.cb_span.setMinimumWidth(120)
        row2.addWidget(self.cb_span)
        self.ck_biome = QCheckBox("显示生物群系图案")
        self.ck_biome.setChecked(True)
        self.ck_biome.toggled.connect(lambda _x: self.draw())
        row2.addWidget(self.ck_biome)
        self.ck_struct = QCheckBox("显示遗迹图案")
        self.ck_struct.setChecked(True)
        self.ck_struct.toggled.connect(lambda _x: self.draw())
        row2.addWidget(self.ck_struct)
        self.btn_fit = QPushButton("看全图")
        self.btn_fit.clicked.connect(lambda: self.view.fit_map())
        row2.addWidget(self.btn_fit)
        self.btn_clear = QPushButton("清标记")
        self.btn_clear.clicked.connect(self._clear_marks)
        row2.addWidget(self.btn_clear)
        row2.addStretch(1)
        v.addLayout(row2)

        self.view = MapView()
        self.view.setMinimumHeight(420)
        self.view.on_mark_added = self._save_marks
        self.view.coords.connect(self._on_coords)
        v.addWidget(self.view, 1)

        tip = QLabel("按住左键拖动，滚轮缩放，双击回全图。"
                     "右键：复制坐标 / 在此加标记；右键自己加的标记：删除或复制坐标。")
        tip.setObjectName("PageSub")
        v.addWidget(tip)
        self.state = QLabel("填个种子（不知道就先填 0），点「画地图」或直接回车。")
        self.state.setObjectName("PageSub")
        v.addWidget(self.state)

        self._load_marks()
        try:
            last = (self.cfg.get("last_seed") if self.cfg else "") or ""
            if last:
                self.ed_seed.setText(str(last))
        except Exception:
            pass
        self.fill_saves()

    # ---------- 读存档的种子 ----------
    def _game_dir(self):
        try:
            gd = (self.cfg.get("game_dir") if self.cfg else "") or ""
        except Exception:
            gd = ""
        if not gd or not os.path.isdir(gd):
            gd = os.path.join(os.path.expanduser("~"), ".minecraft")
        return gd

    def fill_saves(self):
        """把 saves 目录里的存档列进下拉，选中就能直接用它的种子。"""
        self._saves = []
        try:
            self._saves = seedarchive.list_saves(self._game_dir())
        except Exception:
            self._saves = []
        self.cb_save.blockSignals(True)
        self.cb_save.clear()
        if not self._saves:
            self.cb_save.addItem("（saves 里没有存档）")
            self.cb_save.setEnabled(False)
        else:
            self.cb_save.setEnabled(True)
            for it in self._saves:
                label = it.get("label") or it.get("folder") or "未命名"
                tail = it.get("version") or ""
                if it.get("seed") is None:
                    txt = "%s（种子读不出来）" % label
                    seed_val = None
                else:
                    txt = "%s（%s）" % (label, tail or "版本未知")
                    seed_val = it.get("seed")
                self.cb_save.addItem(txt, seed_val)
                self.cb_save.setItemData(self.cb_save.count() - 1,
                                         "%s\n种子：%s\n时间：%s" % (
                                             label, seed_val,
                                             time.strftime(
                                                 "%Y-%m-%d %H:%M",
                                                 time.localtime(it.get("mtime") or 0))),
                                         Qt.ToolTipRole)
        self.cb_save.blockSignals(False)
        if self.state is not None:
            n_ok = sum(1 for x in self._saves if x.get("seed") is not None)
            self.state.setText("找到 %d 个存档（%d 个读到种子）。选存档会自动填种子并画图。"
                               % (len(self._saves), n_ok))

    def _on_save_picked(self, idx):
        if idx < 0 or idx >= len(self._saves):
            return
        it = self._saves[idx]
        seed = it.get("seed")
        if seed is None:
            self.state.setText("这个存档的 level.dat 读不出种子（可能是加密存档或被占用）。")
            return
        self.ed_seed.setText(str(seed))
        # 版本下拉没有 1.21.11 这种小版本，取前两段匹配
        ver = (it.get("version") or "")[:4]
        for x in VER_LIST:
            if ver and x == ver:
                self.cb_ver.setCurrentText(x)
                break
        self.state.setText("已用存档「%s」的种子 %d（%s），正在画图…"
                           % (it.get("label"), seed, it.get("version") or "版本未知"))
        self.draw()

    # ---------- 标记存取 ----------
    def _load_marks(self):
        try:
            raw = (self.cfg.get("seed_marks") if self.cfg else None) or []
            out = []
            for it in raw:
                if isinstance(it, (list, tuple)) and len(it) >= 2:
                    out.append((int(it[0]), int(it[1]),
                                str(it[2]) if len(it) > 2 else ""))
            self._marks = out
        except Exception:
            self._marks = []
        self.view.marks = list(self._marks)

    def _save_marks(self, marks):
        self._marks = list(marks)
        if self.cfg is None:
            return
        try:
            self.cfg.set("seed_marks", [[int(a), int(b), str(c or "")[:40]]
                                        for a, b, c in self._marks])
            self.cfg.save()
        except Exception:
            pass

    def _clear_marks(self):
        try:
            for item in list(self.view.scene().items()):
                if isinstance(item, _UserMark):
                    self.view.scene().removeItem(item)
        except Exception:
            pass
        self.view.marks = []
        self._save_marks([])
        self.state.setText("标记已清空。")

    def _on_coords(self, wx, wz):
        self.state.setText("鼠标位置：x=%d，z=%d（右键可复制 / 标记）" % (wx, wz))

    # ---------- 画图 ----------
    def draw(self):
        if self._worker is not None and self._worker.isRunning():
            return
        raw = self.ed_seed.text().strip()
        if not raw:
            self.state.setText("先填个种子再画。")
            return
        if not seedcalc.available():
            self.state.setText("本地种子计算器缺失（bin/omcseeds.exe 没找到），"
                               "这个功能暂时用不了。")
            return
        try:
            seed = int(raw)
        except ValueError:
            self.state.setText("种子要是数字（1.18 之后版本都是数字种子）。")
            return
        ver = self.cb_ver.currentText()
        span = SPAN_LIST[max(0, self.cb_span.currentIndex())][1]
        self.btn_draw.setEnabled(False)
        self.state.setText("正在算 %s 版本、种子 %d 的地图…（几秒钟）" % (ver, seed))
        if self.cfg is not None:
            try:
                self.cfg.set("last_seed", raw)
                self.cfg.save()
            except Exception:
                pass
        self._worker = _MapWorker(ver, seed, span, self.ck_struct.isChecked(),
                                  self.ck_biome.isChecked(), self)
        self._worker.done.connect(self._on_done)
        self._worker.failed.connect(self._on_fail)
        self._worker.start()

    def _on_done(self, payload, _msg):
        self.btn_draw.setEnabled(True)
        pix = QPixmap(payload["png"])
        if pix.isNull():
            self.state.setText("图没生成出来（写文件失败）。")
            return
        step = payload["step"]
        span = payload["span"]
        self._last = payload["png"]
        self.view.set_extent(span, step)
        self.view.show_pixmap(pix, step, fit=True)

        # 遗迹图案：数量少，设成「不随缩放变大变小」，全图时也能一眼看到
        marks = payload.get("marks") or []
        for x, z, kind, _label in marks:
            it = QGraphicsPixmapItem(_struct_icon(kind), self.view._item)
            it.setFlag(QGraphicsItem.ItemIgnoresTransformations, True)
            it.setOffset(-ICON / 2.0, -ICON / 2.0)
            px = (x + span) / float(step)
            py = (z + span) / float(step)
            it.setPos(QPointF(px, py))
            it.setZValue(10)
            it.setToolTip("%s（x=%d, z=%d）"
                          % (seedcalc.STRUCT_LABELS.get(kind, kind), x, z))
            self.view.scene().addItem(it)

        # 群系图案
        if self.ck_biome.isChecked():
            self.view.set_patterns(payload.get("samples") or [])
        else:
            self.view.set_patterns([])

        msg = "已画出 %d × %d 像素，1 像素 = %d 格；范围 %s" % (
            payload["w"], payload["h"], step, SPAN_LIST[max(0, self.cb_span.currentIndex())][0])
        if self.ck_struct.isChecked():
            msg += "；遗迹图案 %d 个" % len(marks)
        if self.ck_biome.isChecked():
            msg += "；群系图案 %d 格" % len(payload.get("samples") or [])
        self.state.setText(msg)

    def _on_fail(self, err):
        self.btn_draw.setEnabled(True)
        self.state.setText("没画出来：%s" % err)
