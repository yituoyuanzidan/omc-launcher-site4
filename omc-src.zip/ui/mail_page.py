# -*- coding: utf-8 -*-
"""邮件页：按分类收信，每次更新自动收到一封「更新内容」。"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QPushButton, QSplitter,
                               QTextEdit, QVBoxLayout, QWidget)

from core import mailbox


class MailPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = []
        self._auto_select = False
        self.on_unread = None          # 未读数变了就喊一声，给左栏角标用
        self._build()
        self.refresh()

    # ---------- 界面 ----------
    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        head = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        title = QLabel("邮件")
        title.setObjectName("PageTitle")
        sub = QLabel("每次启动器更新完，这里会自动收到一封「更新内容」")
        sub.setObjectName("PageSub")
        col.addWidget(title)
        col.addWidget(sub)
        head.addLayout(col)
        head.addStretch(1)

        head.addWidget(QLabel("分类"))
        self.combo = QComboBox()
        self.combo.addItem("全部", "all")
        for key, label in mailbox.KINDS:
            self.combo.addItem(label, key)
        self.combo.setFixedWidth(130)
        self.combo.currentIndexChanged.connect(lambda *_: self.refresh())
        head.addWidget(self.combo)

        self.lbl_unread = QLabel("")
        self.lbl_unread.setObjectName("FieldLabel")
        head.addWidget(self.lbl_unread)

        self.btn_read_all = QPushButton("全部标为已读")
        self.btn_read_all.clicked.connect(self._read_all)
        head.addWidget(self.btn_read_all)
        v.addLayout(head)

        split = QSplitter(Qt.Vertical)
        self.list = QListWidget()
        self.list.setAlternatingRowColors(True)
        self.list.currentRowChanged.connect(self._show_row)
        # 点同一条（行号没变）currentRowChanged 不会发，这里补一刀
        self.list.itemClicked.connect(
            lambda it: self._show_row(self.list.row(it)))
        split.addWidget(self.list)

        self.body = QTextEdit()
        self.body.setReadOnly(True)
        self.body.setMinimumHeight(180)
        split.addWidget(self.body)
        split.setSizes([300, 260])
        v.addWidget(split, 1)

    # ---------- 数据 ----------
    def refresh(self):
        kind = self.combo.currentData()
        rows = mailbox.load(kind)
        keep = None
        cur = self.list.currentRow()
        if 0 <= cur < len(self._rows):
            keep = self._rows[cur].get("id")
        self._rows = rows
        self.list.blockSignals(True)
        self.list.clear()
        for r in rows:
            mark = "● " if not r.get("read") else "　 "
            item = QListWidgetItem("%s[%s] %s    %s"
                                   % (mark, mailbox.kind_label(r.get("kind")),
                                      r.get("subject") or "(无主题)",
                                      r.get("time") or ""))
            if not r.get("read"):
                f = item.font()
                f.setBold(True)
                item.setFont(f)
            self.list.addItem(item)
        self.list.blockSignals(False)

        n_unread = mailbox.unread_count()
        self.lbl_unread.setText("未读 %d 封" % n_unread if n_unread else "没有未读")
        self.btn_read_all.setEnabled(bool(n_unread))
        self._sync_unread()
        if not rows:
            self.body.setPlainText("这个分类下还没有邮件。\n\n"
                                   "启动器更新完会自动收到一封「更新内容」；"
                                   "发现新版本时也会先在这里通知你。")
            return

        idx = 0
        if keep:
            for i, r in enumerate(rows):
                if r.get("id") == keep:
                    idx = i
                    break
        self._auto_select = True
        self.list.blockSignals(True)
        self.list.setCurrentRow(idx)
        self.list.blockSignals(False)
        self._show_row(idx)
        self._auto_select = False

    def _show_row(self, row):
        if not (0 <= row < len(self._rows)):
            return
        r = self._rows[row]
        head = "[%s] %s\n%s\n%s\n" % (
            mailbox.kind_label(r.get("kind")), r.get("subject") or "",
            r.get("time") or "", "-" * 40)
        self.body.setPlainText(head + "\n" + (r.get("body") or ""))
        # 只有用户自己点开才标已读；程序刷新时保留未读圆点
        if not r.get("read") and not getattr(self, "_auto_select", False):
            mailbox.mark_read(r.get("id"))
            r["read"] = True
            item = self.list.item(row)
            if item is not None:
                item.setText(item.text().replace("● ", "　 ", 1))
                f = item.font()
                f.setBold(False)
                item.setFont(f)
            n_unread = mailbox.unread_count()
            self.lbl_unread.setText("未读 %d 封" % n_unread if n_unread else "没有未读")
            self.btn_read_all.setEnabled(bool(n_unread))
            self._sync_unread()

    def _sync_unread(self):
        """让左栏导航的未读角标立刻跟上，不用等下次进页面刷新。"""
        cb = getattr(self, "on_unread", None)
        if cb is None:
            return
        try:
            cb()
        except Exception:
            pass

    def _read_all(self):
        mailbox.mark_all_read()
        self.refresh()
        self._sync_unread()

    def badge(self):
        """给左栏导航用的未读数。"""
        return mailbox.unread_count()
