# -*- coding: utf-8 -*-
"""好友列表里的 AI 搭子「小矿」的聊天窗。

- 有情绪、能闲聊；能改设置、能放歌；别的动作一律拒绝（由 core.ai_friend 控制）
- 网络/模型调用全在后台线程，界面不卡
- 可以开语音朗读：打游戏时不用看屏幕也能听它说话
"""
import html
import threading
import time

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QPushButton,
                               QTextBrowser, QVBoxLayout)

from core import ai_friend, tts

_CARD_QSS = "QDialog#AccountCard { background: #1E2128; }"
AI_NAME = ai_friend.NAME


def _ai_avatar(size=64):
    """画一个像素风小矿头像（不需要图片文件，任何主题下都清楚）。"""
    pm = QPixmap(size, size)
    pm.fill(QColor("#2A2F3A"))
    p = QPainter(pm)
    unit = max(2, size // 16)
    # 方块脸
    p.fillRect(int(size * 0.12), int(size * 0.12),
               int(size * 0.76), int(size * 0.76), QColor("#8FC98B"))
    # 头顶矿灯
    p.fillRect(int(size * 0.38), int(size * 0.04),
               int(size * 0.24), int(size * 0.12), QColor("#FFC53D"))
    # 眼睛
    p.fillRect(int(size * 0.28), int(size * 0.40), unit * 2, unit * 2,
               QColor("#20242C"))
    p.fillRect(int(size * 0.60), int(size * 0.40), unit * 2, unit * 2,
               QColor("#20242C"))
    # 嘴
    p.fillRect(int(size * 0.34), int(size * 0.68), int(size * 0.32), unit,
               QColor("#20242C"))
    p.end()
    return pm


class AIChatDialog(QDialog):
    sig_reply = Signal(str, str)      # 文本, 引擎
    sig_state = Signal(str)

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self._rows = []
        self._busy = False
        self._closed = False
        # 默认**不**朗读：只在用户自己打开过（配置里明确为 true）时才开。
        # 以前这里是「配置没有就当成开」，等于默认出声音，吵人。
        self._voice = (host.config.get("ai_voice") is True)
        self.setObjectName("AccountCard")
        self.setWindowTitle("和小矿聊天")
        self.setStyleSheet(_CARD_QSS)
        self.resize(620, 660)
        if host.config.get("ai_always_on_top"):
            self.setWindowFlag(Qt.WindowStaysOnTopHint, True)

        v = QVBoxLayout(self)
        v.setSpacing(8)

        head = QHBoxLayout()
        pic = QLabel()
        pic.setPixmap(_ai_avatar(56))
        pic.setFixedSize(58, 58)
        head.addWidget(pic)
        col = QVBoxLayout()
        t1 = QLabel(AI_NAME)
        t1.setStyleSheet("color:#FFFFFF;font-size:17px;font-weight:700;")
        col.addWidget(t1)
        t2 = QLabel("你的 MC 搭子。能陪你聊，也能帮你改设置、放歌；"
                    "别的事它不碰（删文件、改账号、装模组都拒绝）。")
        t2.setObjectName("PageSub")
        t2.setWordWrap(True)
        col.addWidget(t2)
        head.addLayout(col, 1)
        v.addLayout(head)

        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(False)
        self.view.setStyleSheet(
            "QTextBrowser{background:#151820;border:1px solid #2A2E38;"
            "border-radius:10px;padding:10px;}")
        v.addWidget(self.view, 1)

        # QTextBrowser 自带的右键菜单是 Qt 原生英文（Copy / Select All），
        # 中文界面里冒出来一串英文就是用户说的「右键选项翻译异常」。
        # 这里整个换成自己的中文菜单，顺手加「朗读这条」。
        self.view.setContextMenuPolicy(Qt.CustomContextMenu)
        self.view.customContextMenuRequested.connect(self._view_menu)

        row = QHBoxLayout()
        self.in_text = QLineEdit()
        self.in_text.setPlaceholderText("跟它说点什么，回车发送")
        self.in_text.returnPressed.connect(self._send)
        row.addWidget(self.in_text, 1)
        self.b_send = QPushButton("发送")
        self.b_send.setObjectName("PrimaryButton")
        self.b_send.setFixedWidth(84)
        self.b_send.clicked.connect(self._send)
        row.addWidget(self.b_send)
        v.addLayout(row)

        bar = QHBoxLayout()
        self.cb_voice = QCheckBox("语音朗读（打游戏时也能听它说话）")
        self.cb_voice.setChecked(self._voice)
        self.cb_voice.stateChanged.connect(self._on_voice)
        bar.addWidget(self.cb_voice)
        bar.addWidget(QLabel("声线"))
        self.cb_style = QComboBox()
        for key, label, *_rest in tts.VOICE_STYLES:
            self.cb_style.addItem(label, key)
        self.cb_style.setFixedWidth(150)
        cur_style = (host.config.get("ai_voice_style") or "xiaokuang")
        idx = self.cb_style.findData(cur_style)
        if idx >= 0:
            self.cb_style.setCurrentIndex(idx)
        self.cb_style.currentIndexChanged.connect(self._on_style)
        self.cb_style.setToolTip("就一个声线「小矿」；选「关闭声音」就彻底不出声")
        bar.addWidget(self.cb_style)
        self.b_try = QPushButton("试听")
        self.b_try.setFixedWidth(66)
        self.b_try.clicked.connect(self._try_voice)
        bar.addWidget(self.b_try)
        self.cb_top = QCheckBox("窗口置顶")
        self.cb_top.setChecked(bool(host.config.get("ai_always_on_top")))
        self.cb_top.stateChanged.connect(self._on_top)
        bar.addWidget(self.cb_top)
        bar.addStretch(1)
        self.lbl_state = QLabel("")
        self.lbl_state.setObjectName("FieldLabel")
        bar.addWidget(self.lbl_state)
        b_call = QPushButton("语音通话")
        b_call.setFixedWidth(88)
        b_call.setToolTip("直接对着麦克风跟它说话；通话里说「挂了吧」它会自己挂断")
        b_call.clicked.connect(self._open_call)
        bar.addWidget(b_call)
        b_clear = QPushButton("清空对话")
        b_clear.setFixedWidth(88)
        b_clear.clicked.connect(self._clear)
        bar.addWidget(b_clear)
        v.addLayout(bar)

        self.sig_reply.connect(self._on_reply)
        self.sig_state.connect(self.lbl_state.setText)

        self._load_history()
        self.in_text.setFocus()

    # ---------- 历史 ----------
    def _load_history(self):
        self._rows = []
        for h in ai_friend.recent(20):
            self._rows.append({"r": h.get("r") or "u",
                               "t": h.get("t") or "",
                               "ts": int(h.get("ts") or 0)})
        if not self._rows:
            welcome = ("我在。今天想聊点什么，还是想让我帮你调点什么？"
                       "（设置和音乐我能动，别的我不碰）")
            self._rows.append({"r": "a", "t": welcome, "ts": int(time.time())})
        self._render()

    # ---------- 发送 ----------
    def _send(self):
        text = self.in_text.text().strip()
        if not text or self._busy:
            return
        self.in_text.clear()
        self._rows.append({"r": "u", "t": text, "ts": int(time.time())})
        ai_friend.remember("u", text)
        self._render()
        self._busy = True
        self.lbl_state.setText("小矿在想……")
        self.b_send.setEnabled(False)

        def work():
            try:
                say, act, engine = ai_friend.reply(text)
            except Exception as e:
                say, act, engine = ("我这边卡了一下：%s" % str(e)[:80], None,
                                    "local")
            if self._closed:
                return
            done = ""
            if act:
                try:
                    done = self.host.ai_run_action(act) or ""
                except Exception as e:
                    done = "动作没做成：%s" % str(e)[:80]
            self.sig_reply.emit(say + (("\n（%s）" % done) if done else ""),
                                engine)

        threading.Thread(target=work, daemon=True).start()

    def _on_reply(self, say, engine):
        self._busy = False
        self.b_send.setEnabled(True)
        self._rows.append({"r": "a", "t": say, "ts": int(time.time())})
        ai_friend.remember("a", say)
        self._render()
        self.lbl_state.setText("本机模式" if engine == "local" else "模型在线")
        if self._voice:
            # 情绪小幅影响语气：吐槽时压低一点、说高兴事时抬高一点
            tts.speak(say, self._style(), mood=ai_friend.last_mood())

    def _view_menu(self, pos):
        """右键菜单全部中文。Qt 自带的是英文 Copy / Select All，
        在中文界面里跳出来就成了「右键选项翻译异常」。"""
        m = QMenu(self)
        a_copy = m.addAction("复制选中的文字")
        a_copy.setEnabled(self.view.textCursor().hasSelection())
        a_copy.triggered.connect(self.view.copy)
        a_all = m.addAction("全选")
        a_all.triggered.connect(self.view.selectAll)
        m.addSeparator()
        a_say = m.addAction("读出最后一条回复")
        a_say.triggered.connect(self._say_last)
        a_clear = m.addAction("清空对话")
        a_clear.triggered.connect(self._clear)
        m.exec(self.view.mapToGlobal(pos))

    def _say_last(self):
        """不勾朗读也能念一句：右键点一下就想听。"""
        text = ""
        for r in reversed(getattr(self, "_rows", [])):
            if r.get("r") == "a":
                text = r.get("t") or ""
                break
        if not text:
            self.lbl_state.setText("还没有可以念的回复")
            return
        if self._style() == "guan":
            self.lbl_state.setText("声线选的是「关闭声音」，先换成别的声线")
            return
        tts.speak(text, self._style(), 100)
        self.lbl_state.setText("正在念…")

    def _style(self):
        """当前声线；勾了「语音朗读」才出声，选了「关闭声音」也不出声。"""
        key = self.cb_style.currentData() or "xiaokuang"
        return key

    def _on_style(self, _i=None):
        key = self._style()
        self.host.config.set("ai_voice_style", key)
        try:
            self.host.config.save()
        except Exception:
            pass
        if key == "guan":
            # 选「关闭声音」等于连朗读一起关掉，界面上就去掉勾，别骗人
            self.cb_voice.blockSignals(True)
            self.cb_voice.setChecked(False)
            self.cb_voice.blockSignals(False)
            self._voice = False
            self.host.config.set("ai_voice", False)
            try:
                self.host.config.save()
            except Exception:
                pass
            self.lbl_state.setText("声音已关")

    def _try_voice(self):
        key = self._style()
        if key == "guan":
            self.lbl_state.setText("现在是「关闭声音」，不出声")
            return
        if not tts.available():
            self.lbl_state.setText("这台机器没有系统语音，念不了")
            return
        self.lbl_state.setText("试听中…")
        tts.preview(key)
        QTimer.singleShot(3200, lambda: self.lbl_state.setText("试听完了"))

    # ---------- 渲染 ----------
    def _render(self):
        bubbles = []
        for m in self._rows:
            mine = (m.get("r") == "u")
            when = time.strftime("%H:%M", time.localtime(m.get("ts") or 0))
            body = html.escape(m.get("t") or "").replace("\n", "<br>")
            bg = "#2E5B45" if mine else "#2A2F3A"
            align = "right" if mine else "left"
            who = "我" if mine else AI_NAME
            bubbles.append(
                "<div style='text-align:%s;margin:9px 0;'>"
                "<span style='color:#7f8794;font-size:11px;'>%s · %s</span><br>"
                "<span style='background:%s;color:#E8EDF5;padding:7px 11px;"
                "border-radius:9px;display:inline-block;'>%s</span></div>"
                % (align, who, when, bg, body))
        self.view.setHtml("<div style='font-size:13px;'>%s</div>"
                          % "".join(bubbles))
        bar = self.view.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _on_voice(self, state):
        self._voice = bool(state) and int(state) != 0
        self.host.config.set("ai_voice", self._voice)
        try:
            self.host.config.save()
        except Exception:
            pass

    def _on_top(self, state):
        on = bool(state) and int(state) != 0
        self.host.config.set("ai_always_on_top", on)
        try:
            self.host.config.save()
        except Exception:
            pass
        self.setWindowFlag(Qt.WindowStaysOnTopHint, on)
        self.show()

    def _open_call(self):
        """切到语音通话（关掉聊天窗，省得两边抢麦克风）。"""
        try:
            self.host._open_ai_call()
        except Exception as e:
            self.lbl_state.setText("通话开不起来：%s" % str(e)[:40])
            return
        self.close()

    def _clear(self):
        self._rows = []
        ai_friend.save({"history": [], "mood": 0})
        self._rows.append({"r": "a", "t": "刚才说的我都忘了，再说一遍？",
                           "ts": int(time.time())})
        self._render()
        self.lbl_state.setText("已清空")

    def closeEvent(self, e):
        self._closed = True
        super().closeEvent(e)
