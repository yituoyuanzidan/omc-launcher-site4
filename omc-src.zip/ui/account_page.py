# -*- coding: utf-8 -*-
"""账号页 + 登录/注册/改密码/发信邮箱设置。"""
from PySide6.QtCore import QSize, Qt, QTimer, QUrl
from PySide6.QtGui import (QColor, QDesktopServices, QFont, QIcon, QPainter,
                           QPixmap)
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                               QFormLayout,
                               QHBoxLayout, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox,
                               QPushButton, QStackedWidget, QTabWidget,
                               QTextBrowser, QVBoxLayout, QWidget)
import threading
from pathlib import Path

from core import accounts, avatar, frienddir, mailcode, mailbox, qrlogin

_CARD_QSS = "QDialog#AccountCard { background: #1E2128; }"


def _card_dialog(title, parent=None, w=520):
    d = QDialog(parent)
    d.setObjectName("AccountCard")
    d.setWindowTitle(title)
    d.setStyleSheet(_CARD_QSS)
    d.setMinimumWidth(w)
    return d


# ---------- 授权码教程 ----------
AUTH_HELP_HTML = """
<style>
  body { color: #D8DEE9; font-size: 13px; }
  h3 { color: #7FD1A0; margin: 2px 0 8px 0; }
  ol { margin-left: 18px; }
  li { margin-bottom: 7px; }
  code { color: #F0C674; background: #2B2F38; padding: 1px 4px; }
  .warn { color: #E7A0A0; }
</style>
<h3>QQ 邮箱授权码怎么拿</h3>
<ol>
  <li>电脑浏览器打开 <code>mail.qq.com</code>，登进你的 QQ 邮箱。</li>
  <li>点右上角「设置」→ 里面找「账号与安全」（有些版本叫「账号」）。</li>
  <li>往下找到「POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV 服务」这一块。</li>
  <li>点开「POP3/SMTP 服务」或「IMAP/SMTP 服务」后面的「开启」。</li>
  <li>按提示用手机发一条短信验证，通过后会直接给出一个
      <b>16 位授权码</b>（形如 <code>abcd efgh ijkl mnop</code>）。</li>
  <li>把这个 16 位授权码填回上一页的「授权码」，<b>不要填 QQ 登录密码</b>。</li>
</ol>
<p>注意：</p>
<ul>
  <li>授权码只显示一次，关掉就找不到了——可以随时回这个页面「生成授权码」再来一个。</li>
  <li>复制的时候把中间的空格去掉，只留 16 个字母／数字。</li>
  <li>服务器填 <code>smtp.qq.com</code>，端口 <code>465</code>，必须开 SSL。</li>
  <li>163 邮箱的话服务器是 <code>smtp.163.com</code>，端口也是 465，
      授权码在「设置 → POP3/SMTP/IMAP」里开。</li>
  <li class="warn">填错或没开启 SMTP，发验证码会直接失败——先用弹窗里的
      「给发信邮箱自己发一封试试」验证一遍。</li>
</ul>
"""


class AuthHelpDialog(QDialog):
    """授权码从哪来：一步一步写清楚，带一键打开邮箱设置。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AccountCard")
        self.setWindowTitle("查看授权码教程")
        self.setStyleSheet(_CARD_QSS)
        self.resize(560, 520)
        v = QVBoxLayout(self)
        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(True)
        self.view.setHtml(AUTH_HELP_HTML)
        v.addWidget(self.view, 1)
        row = QHBoxLayout()
        b_open = QPushButton("打开 QQ 邮箱网页")
        b_open.clicked.connect(self._open_mail)
        row.addWidget(b_open)
        row.addStretch(1)
        b_ok = QPushButton("知道了")
        b_ok.setObjectName("Primary")
        b_ok.clicked.connect(self.accept)
        row.addWidget(b_ok)
        v.addLayout(row)

    @staticmethod
    def _open_mail():
        QDesktopServices.openUrl(QUrl("https://mail.qq.com"))


# ---------- 发信邮箱 ----------
class SmtpDialog(QDialog):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setObjectName("AccountCard")
        self.setWindowTitle("发信邮箱（QQ 邮箱）")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(520)
        conf = config.get("smtp") or {}
        v = QVBoxLayout(self)
        tip = QLabel("验证码用这个邮箱发出去。QQ 邮箱要填「授权码」不是登录密码：\n"
                     "QQ 邮箱网页版 → 设置 → 账号 → 开启 POP3/SMTP → 生成授权码。")
        tip.setObjectName("PageSub")
        tip.setWordWrap(True)
        v.addWidget(tip)
        form = QFormLayout()
        self.in_host = QLineEdit(conf.get("host") or "smtp.qq.com")
        self.in_port = QLineEdit(str(conf.get("port") or 465))
        self.in_user = QLineEdit(conf.get("user") or "")
        self.in_user.setPlaceholderText("你的QQ邮箱@qq.com")
        self.in_pass = QLineEdit(conf.get("password") or "")
        self.in_pass.setEchoMode(QLineEdit.Password)
        self.in_pass.setPlaceholderText("授权码（16 位那个，不是密码）")
        auth_row = QHBoxLayout()
        auth_row.setContentsMargins(0, 0, 0, 0)
        auth_row.setSpacing(6)
        auth_row.addWidget(self.in_pass, 1)
        self.btn_auth_help = QPushButton("查看授权码教程")
        self.btn_auth_help.setFixedWidth(132)
        self.btn_auth_help.clicked.connect(self._show_auth_help)
        auth_row.addWidget(self.btn_auth_help)
        form.addRow("SMTP 服务器", self.in_host)
        form.addRow("端口", self.in_port)
        form.addRow("发信邮箱", self.in_user)
        form.addRow("授权码", auth_row)
        v.addLayout(form)
        row = QHBoxLayout()
        b_test = QPushButton("给发信邮箱自己发一封试试")
        b_test.clicked.connect(self._test)
        row.addWidget(b_test)
        row.addStretch(1)
        v.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Save).setText("保存")
        bb.button(QDialogButtonBox.Cancel).setText("取消")
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def _show_auth_help(self):
        AuthHelpDialog(self).exec()

    def _collect(self):
        return {
            "host": self.in_host.text().strip() or "smtp.qq.com",
            "port": int(self.in_port.text().strip() or 465),
            "ssl": True,
            "user": self.in_user.text().strip(),
            "password": self.in_pass.text().strip(),
            "to": "",
        }

    def _test(self):
        conf = self._collect()
        if not conf["user"]:
            QMessageBox.warning(self, "还差一步", "先填发信邮箱地址")
            return
        ok, why = mailbox.smtp_send(conf, "OMC 发信测试",
                                    "能收到这封，说明验证码也能发出去。",
                                    to=conf["user"])
        QMessageBox.information(self, "测试结果",
                                "已发出，去邮箱看看" if ok else "没发出去：%s" % why)

    def _save(self):
        conf = self._collect()
        self.config.set("smtp", conf)
        try:
            self.config.save()
        except Exception:
            pass
        self.accept()


# ---------- 登录 / 注册 ----------
class LoginDialog(QDialog):
    def __init__(self, config, parent=None, start_tab=0):
        super().__init__(parent)
        self.config = config
        self.setObjectName("AccountCard")
        self.setWindowTitle("登录 / 注册")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(460)
        self.result_name = ""
        v = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_login(), "登录")
        self.tabs.addTab(self._build_register(), "注册")
        self.tabs.addTab(self._build_mobile(), "扫码 / 手机号")
        self.tabs.setCurrentIndex(start_tab)
        v.addWidget(self.tabs)
        btn = QPushButton("关闭")
        btn.clicked.connect(self.reject)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(btn)
        v.addLayout(row)

    # 登录页
    def _build_login(self):
        w = QWidget()
        f = QFormLayout(w)
        self.in_key = QLineEdit()
        self.in_key.setPlaceholderText("用户名或邮箱")
        self.in_pwd = QLineEdit()
        self.in_pwd.setEchoMode(QLineEdit.Password)
        self.chk_remember = QCheckBox("记住密码，这台设备下次自动登录")
        self.chk_remember.setChecked(True)
        f.addRow("账号", self.in_key)
        f.addRow("密码", self.in_pwd)
        f.addRow("", self.chk_remember)
        b = QPushButton("登录")
        b.clicked.connect(self._do_login)
        f.addRow("", b)
        return w

    def _do_login(self):
        key = self.in_key.text().strip()
        pwd = self.in_pwd.text()
        if not key or not pwd:
            QMessageBox.warning(self, "还差一步", "账号和密码都要填")
            return
        ok, msg = accounts.login(key, pwd, remember=self.chk_remember.isChecked(),
                                 auto=self.chk_remember.isChecked())
        if not ok:
            QMessageBox.warning(self, "登录失败", msg)
            return
        self.result_name = msg
        self.accept()

    # 扫码 / 手机号
    def _build_mobile(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        t1 = QLabel("扫码登录：点「生成二维码」，手机（要跟电脑同一个 Wi-Fi）扫一下，"
                    "在手机浏览器里核对信息、点「确认登录」，电脑这边才会登进去。"
                    "微信和 QQ 走同一套流程——都必须手机上二次确认，扫到码也不能直接进。")
        t1.setObjectName("PageSub")
        t1.setWordWrap(True)
        v.addWidget(t1)

        r1 = QHBoxLayout()
        r1.addWidget(QLabel("渠道"))
        self.qr_kind = QComboBox()
        self.qr_kind.addItems(["微信扫码", "QQ 扫码"])
        self.qr_kind.setFixedWidth(120)
        r1.addWidget(self.qr_kind)
        r1.addWidget(QLabel("登录到"))
        self.qr_name = QLineEdit()
        self.qr_name.setPlaceholderText("账号名，留空就用当前登录/上次的账号")
        cur = accounts.current_name()
        if cur:
            self.qr_name.setText(cur)
        r1.addWidget(self.qr_name, 1)
        b_qr = QPushButton("生成二维码")
        b_qr.setObjectName("PrimaryButton")
        b_qr.setFixedWidth(110)
        b_qr.clicked.connect(self._make_qr)
        r1.addWidget(b_qr)
        v.addLayout(r1)

        self.lbl_qr = QLabel("还没生成二维码。")
        self.lbl_qr.setAlignment(Qt.AlignCenter)
        self.lbl_qr.setMinimumHeight(190)
        self.lbl_qr.setStyleSheet(
            "QLabel{background:#151820;border:1px solid #2A2E38;border-radius:10px;"
            "color:#7f8794;}")
        v.addWidget(self.lbl_qr)

        self.lbl_qr_url = QLabel("")
        self.lbl_qr_url.setObjectName("FieldLabel")
        self.lbl_qr_url.setWordWrap(True)
        v.addWidget(self.lbl_qr_url)

        self.lbl_qr_state = QLabel("")
        self.lbl_qr_state.setObjectName("FieldLabel")
        v.addWidget(self.lbl_qr_state)

        t2 = QLabel("号码登录：手机号或 QQ 号 + 6 位验证码。QQ 号的验证码发到「QQ号@qq.com」"
                    "的邮箱；手机号没接短信通道，验证码会直接显示在下面（只在本机试的时候能这么用）。"
                    "本机还没有这个号码的账号会自动建一个。")
        t2.setObjectName("PageSub")
        t2.setWordWrap(True)
        v.addWidget(t2)

        r2 = QHBoxLayout()
        self.in_num = QLineEdit()
        self.in_num.setPlaceholderText("手机号或 QQ 号")
        r2.addWidget(self.in_num, 1)
        self.b_send2 = QPushButton("发送验证码")
        self.b_send2.setFixedWidth(110)
        self.b_send2.clicked.connect(self._send_num_code)
        r2.addWidget(self.b_send2)
        v.addLayout(r2)

        r3 = QHBoxLayout()
        self.in_code2 = QLineEdit()
        self.in_code2.setMaxLength(6)
        self.in_code2.setPlaceholderText("6 位验证码")
        r3.addWidget(self.in_code2, 1)
        b_login2 = QPushButton("验证码登录")
        b_login2.setObjectName("PrimaryButton")
        b_login2.setFixedWidth(110)
        b_login2.clicked.connect(self._num_login)
        r3.addWidget(b_login2)
        v.addLayout(r3)

        self.lbl_num_tip = QLabel("")
        self.lbl_num_tip.setObjectName("PageSub")
        self.lbl_num_tip.setWordWrap(True)
        v.addWidget(self.lbl_num_tip)
        v.addStretch(1)
        return w

    # ---------- 扫码 ----------
    def _make_qr(self):
        name = (self.qr_name.text() or "").strip() or accounts.current_name()
        if not name:
            QMessageBox.warning(self, "先选账号", "填一个要登录的账号名，或者先登录一次再扫码。")
            return
        if not accounts.find(name):
            QMessageBox.warning(self, "没有这个账号",
                                "本机没有「%s」这个账号。先在「注册」页建一个，"
                                "或者把账号名填对。" % name)
            return
        if getattr(self, "_qr_server", None) is None:
            self._qr_server = qrlogin.QrServer()
        port = self._qr_server.start()
        if not port:
            QMessageBox.warning(self, "开不了端口",
                                "扫码要在本机开一个小服务（8901 起），端口都被占了。")
            return
        kind = self.qr_kind.currentText()
        self._qr_ticket = qrlogin.new_ticket(kind, name, port)
        png, why = qrlogin.qr_png_bytes(self._qr_ticket, port)
        if png:
            pm = QPixmap()
            pm.loadFromData(png)
            self.lbl_qr.setPixmap(pm.scaled(180, 180, Qt.KeepAspectRatio,
                                            Qt.SmoothTransformation))
        else:
            self.lbl_qr.setPixmap(QPixmap())
            self.lbl_qr.setText("二维码没画出来（%s）；用下面的网址手动打开也能确认。"
                                % (why or "未知原因"))
        self.lbl_qr_url.setText("手机扫码网址：%s　（%s，3 分钟内有效）"
                                % (qrlogin.url_for(self._qr_ticket, port), kind))
        self.lbl_qr_state.setText("等待手机确认……")
        if getattr(self, "_qr_timer", None) is None:
            self._qr_timer = QTimer(self)
            self._qr_timer.timeout.connect(self._poll_qr)
        # 300ms 一次足够快，state() 只是查内存字典，开销可以忽略
        self._qr_timer.start(300)

    def _poll_qr(self):
        tk = getattr(self, "_qr_ticket", "")
        if not tk:
            return
        st = qrlogin.state(tk)
        if st == "confirmed":
            self._qr_timer.stop()
            name = (self.qr_name.text() or "").strip() or accounts.current_name()
            ok, msg, _created = accounts.code_login(
                name, "", via=("qq_qr" if "QQ" in (self.qr_kind.currentText() or "")
                               else "wechat"))
            if ok:
                self.lbl_qr_state.setText("手机上已确认，登录成功：%s" % name)
                self.result_name = msg or name
                qrlogin.drop(tk)
                self.accept()
            else:
                self.lbl_qr_state.setText("确认了，但登录没成功：%s" % msg)
        elif st in ("cancelled", "expired", "missing"):
            self._qr_timer.stop()
            self.lbl_qr_state.setText("这次二维码失效了（取消或超时），重新生成一个。")

    # ---------- 号码 + 验证码 ----------
    def _send_num_code(self):
        num = (self.in_num.text() or "").strip()
        if not num:
            QMessageBox.warning(self, "还差一步", "先填手机号或 QQ 号")
            return
        if getattr(self, "_cd2_left", 0) > 0:
            return
        email = self._num_email(num)
        if not email:
            QMessageBox.warning(self, "号码不对",
                                "手机号填 11 位数字，QQ 号填 5-12 位数字。")
            return
        conf = self.config.get("smtp") or {}
        has_smtp = bool((conf.get("user") or "").strip())
        dev_ok = not has_smtp or "@omc.local" in email
        ok, msg, code = mailcode.send_code(email, conf, dev_ok=dev_ok)
        if not ok:
            self.lbl_num_tip.setText(msg)
            QMessageBox.warning(self, "没发出去", msg)
            return
        if code:
            self.in_code2.setText(code)
            msg = "验证码直接显示：%s，已经填好了，点「验证码登录」。" % code
        self.lbl_num_tip.setText(msg)
        self._cd2_left = 10
        if getattr(self, "_cd2_timer", None) is None:
            self._cd2_timer = QTimer(self)
            self._cd2_timer.timeout.connect(self._tick_cd2)
        self.b_send2.setEnabled(False)
        self.b_send2.setText("10s 后重发")
        self._cd2_timer.start(1000)

    def _tick_cd2(self):
        self._cd2_left = int(getattr(self, "_cd2_left", 0)) - 1
        if self._cd2_left <= 0:
            self._cd2_timer.stop()
            self._cd2_left = 0
            self.b_send2.setEnabled(True)
            self.b_send2.setText("发送验证码")
        else:
            self.b_send2.setText("%ds 后重发" % self._cd2_left)

    def _num_email(self, num):
        num = (num or "").strip()
        if num.isdigit() and len(num) == 11 and num[0] == "1":
            return "%s@omc.local" % num
        if num.isdigit() and 5 <= len(num) <= 12:
            return "%s@qq.com" % num
        return ""

    def _num_login(self):
        num = (self.in_num.text() or "").strip()
        email = self._num_email(num)
        if not email:
            QMessageBox.warning(self, "号码不对",
                                "手机号填 11 位数字，QQ 号填 5-12 位数字。")
            return
        ok, msg = mailcode.verify(email, self.in_code2.text())
        if not ok:
            QMessageBox.warning(self, "验证码", msg)
            return
        ok, name, created = accounts.code_login(
            num, email, via=("phone" if "@omc.local" in email else "qq"))
        if not ok:
            QMessageBox.warning(self, "登录没成功", name)
            return
        self.lbl_num_tip.setText(
            "登录成功：%s%s" % (name, "（本机新建的账号）" if created else ""))
        self.result_name = name
        self.accept()

    # 注册页
    def _build_register(self):
        w = QWidget()
        f = QFormLayout(w)
        self.r_name = QLineEdit()
        self.r_name.setMaxLength(16)
        self.r_name.setPlaceholderText("2-16 个字符，字母数字下划线，本机不能重名")
        self.r_email = QLineEdit()
        self.r_email.setPlaceholderText("用来收验证码，例如 xxxx@qq.com")
        code_row = QHBoxLayout()
        self.r_code = QLineEdit()
        self.r_code.setMaxLength(6)
        self.r_code.setPlaceholderText("6 位验证码")
        b_send = QPushButton("发送验证码")
        b_send.setFixedWidth(110)
        b_send.clicked.connect(self._send_code)
        self.b_send = b_send
        code_row.addWidget(self.r_code, 1)
        code_row.addWidget(b_send)
        self.r_pwd = QLineEdit()
        self.r_pwd.setEchoMode(QLineEdit.Password)
        self.r_pwd.setPlaceholderText("至少 6 位，要带数字和符号，不能有中文")
        self.r_pwd2 = QLineEdit()
        self.r_pwd2.setEchoMode(QLineEdit.Password)
        self.r_pwd2.setPlaceholderText("再写一遍")
        self.lbl_code_tip = QLabel("")
        self.lbl_code_tip.setObjectName("PageSub")
        self.lbl_code_tip.setWordWrap(True)
        f.addRow("用户名", self.r_name)
        f.addRow("邮箱", self.r_email)
        f.addRow("验证码", code_row)
        f.addRow("", self.lbl_code_tip)
        f.addRow("密码", self.r_pwd)
        f.addRow("确认密码", self.r_pwd2)
        b = QPushButton("注册并登录")
        b.clicked.connect(self._do_register)
        f.addRow("", b)
        return w

    def _send_code(self):
        email = self.r_email.text().strip()
        if "@" not in email:
            QMessageBox.warning(self, "还差一步", "先填一个正确的邮箱")
            return
        if getattr(self, "_cd_left", 0) > 0:
            return
        conf = self.config.get("smtp") or {}
        has_smtp = bool((conf.get("user") or "").strip())
        # 没配发信邮箱时直接把码显示出来（本机模式，不弹窗拦人）
        ok, msg, code = mailcode.send_code(email, conf, dev_ok=not has_smtp)
        if not ok:
            self.lbl_code_tip.setText(msg)
            QMessageBox.warning(self, "没发出去", msg)
            return
        if code:
            self.r_code.setText(code)
            msg = ("没配发信邮箱，验证码直接显示：(%s)，已自动填好，点「注册并登录」就行。"
                   % code)
        self.lbl_code_tip.setText(msg)
        self._start_cooldown()

    def _start_cooldown(self):
        """发完一次要等 10 秒才能再发。"""
        self._cd_left = 10
        if not hasattr(self, "_cd_timer"):
            self._cd_timer = QTimer(self)
            self._cd_timer.timeout.connect(self._tick_cooldown)
        self.b_send.setEnabled(False)
        self.b_send.setText("%ds 后重发" % self._cd_left)
        self._cd_timer.start(1000)

    def _tick_cooldown(self):
        self._cd_left = int(getattr(self, "_cd_left", 0)) - 1
        if self._cd_left <= 0:
            self._cd_timer.stop()
            self._cd_left = 0
            self.b_send.setEnabled(True)
            self.b_send.setText("发送验证码")
        else:
            self.b_send.setText("%ds 后重发" % self._cd_left)

    def _do_register(self):
        name = self.r_name.text().strip()
        email = self.r_email.text().strip()
        pwd = self.r_pwd.text()
        pwd2 = self.r_pwd2.text()
        err = accounts.check_register(name, email, pwd, pwd2)
        if err:
            QMessageBox.warning(self, "注册没通过", err)
            return
        ok, msg = mailcode.verify(email, self.r_code.text())
        if not ok:
            QMessageBox.warning(self, "验证码", msg)
            return
        ok, msg = accounts.register(name, email, pwd)
        if not ok:
            QMessageBox.warning(self, "注册没通过", msg)
            return
        self.result_name = msg
        self.accept()


# ---------- 改密码 ----------
class PasswordDialog(QDialog):
    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = name
        self.setObjectName("AccountCard")
        self.setWindowTitle("修改密码")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(400)
        f = QFormLayout(self)
        self.in_old = QLineEdit()
        self.in_old.setEchoMode(QLineEdit.Password)
        self.in_new = QLineEdit()
        self.in_new.setEchoMode(QLineEdit.Password)
        self.in_new2 = QLineEdit()
        self.in_new2.setEchoMode(QLineEdit.Password)
        self.in_new2.setPlaceholderText("再写一遍")
        f.addRow("旧密码", self.in_old)
        f.addRow("新密码", self.in_new)
        f.addRow("确认新密码", self.in_new2)
        row = QHBoxLayout()
        row.addStretch(1)
        b_ok = QPushButton("保存")
        b_ok.clicked.connect(self._save)
        b_cancel = QPushButton("取消")
        b_cancel.clicked.connect(self.reject)
        row.addWidget(b_ok)
        row.addWidget(b_cancel)
        f.addRow("", row)

    def _save(self):
        ok, msg = accounts.change_password(
            self.name, self.in_old.text(), self.in_new.text(), self.in_new2.text())
        if not ok:
            QMessageBox.warning(self, "改不了", msg)
            return
        QMessageBox.information(self, "好了", msg)
        self.accept()


# ---------- 账号页 ----------
class AccountPage(QWidget):
    def __init__(self, config, apply_bind=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.apply_bind = apply_bind or (lambda kind, payload: None)
        self._build()
        self.refresh()

    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        head = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        title = QLabel("账号")
        title.setObjectName("PageTitle")
        sub = QLabel("登录后可以绑定离线昵称、微软正版、第三方账号；不登录也能正常玩")
        sub.setObjectName("PageSub")
        col.addWidget(title)
        col.addWidget(sub)
        head.addLayout(col)
        head.addStretch(1)
        self.lbl_avatar = QLabel("")
        self.lbl_avatar.setFixedSize(56, 56)
        self.lbl_avatar.setAlignment(Qt.AlignCenter)
        self.lbl_avatar.setStyleSheet(
            "QLabel{background:#1b1f27;border:1px solid #2b303b;border-radius:10px;"
            "color:#7f8794;font-size:11px;}")
        self.lbl_avatar.setText("无头像")
        head.addWidget(self.lbl_avatar)
        self.btn_avatar = QPushButton("换头像")
        self.btn_avatar.setToolTip("选内置头像，或者导入自己的图片")
        self.btn_avatar.clicked.connect(self._pick_avatar)
        head.addWidget(self.btn_avatar)
        self.btn_smtp = QPushButton("发信邮箱")
        self.btn_smtp.clicked.connect(self._open_smtp)
        head.addWidget(self.btn_smtp)
        self.btn_login = QPushButton("登录 / 注册")
        self.btn_login.setObjectName("PrimaryButton")
        self.btn_login.clicked.connect(self._open_login)
        head.addWidget(self.btn_login)
        self.btn_logout = QPushButton("退出登录")
        self.btn_logout.clicked.connect(self._logout)
        head.addWidget(self.btn_logout)
        v.addLayout(head)

        card = QWidget()
        card.setObjectName("Card")
        cv = QVBoxLayout(card)
        self.lbl_who = QLabel("")
        self.lbl_who.setStyleSheet("font-size: 16px; font-weight: 700; color: #FFFFFF;")
        self.lbl_sub = QLabel("")
        self.lbl_sub.setObjectName("PageSub")
        cv.addWidget(self.lbl_who)
        cv.addWidget(self.lbl_sub)
        bind_row = QHBoxLayout()
        self.lbl_binds = QLabel("")
        self.lbl_binds.setObjectName("FieldLabel")
        bind_row.addWidget(self.lbl_binds, 1)
        self.btn_rename = QPushButton("改用户名")
        self.btn_rename.setToolTip("同一台设备上每个账号每天只能改一次")
        self.btn_rename.clicked.connect(self._rename)
        bind_row.addWidget(self.btn_rename)
        self.btn_pwd = QPushButton("修改密码")
        self.btn_pwd.clicked.connect(self._change_pwd)
        bind_row.addWidget(self.btn_pwd)
        self.btn_del = QPushButton("注销账号")
        self.btn_del.setToolTip("把账号从这台设备删掉，删了不能恢复")
        self.btn_del.clicked.connect(self._delete_account)
        bind_row.addWidget(self.btn_del)
        cv.addLayout(bind_row)
        v.addWidget(card)

        v.addWidget(QLabel("这台设备上的账号"))
        self.list = QListWidget()
        self.list.setAlternatingRowColors(True)
        self.list.itemDoubleClicked.connect(self._switch)
        # 选中哪个账号，上面的大头像就跟谁走（没登录也能看）
        self.list.itemSelectionChanged.connect(self._on_row_selected)
        v.addWidget(self.list, 1)

        brow = QHBoxLayout()
        for kind, text in (("offline", "绑定离线昵称"), ("msa", "绑定微软正版"),
                           ("third", "绑定第三方账号")):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, k=kind: self._bind(k))
            brow.addWidget(b)
        b_unbind = QPushButton("解除当前账号的绑定")
        b_unbind.clicked.connect(self._unbind_all)
        brow.addWidget(b_unbind)
        brow.addStretch(1)
        v.addLayout(brow)

        self.chk_dir = QCheckBox("允许别人按账号名搜到我（只公开账号名，不带邮箱）")
        self.chk_dir.setChecked(bool(self.config.get("dir_allow") if
                                     self.config.get("dir_allow") is not None else True))
        self.chk_dir.toggled.connect(self._toggle_dir)
        v.addWidget(self.chk_dir)

        br = QHBoxLayout()
        b_exp = QPushButton("导出账号备份")
        b_exp.setToolTip("把本机全部账号打包成一个加密文件，换电脑能导回来")
        b_exp.clicked.connect(self._export_backup)
        br.addWidget(b_exp)
        b_imp = QPushButton("导入账号备份")
        b_imp.clicked.connect(self._import_backup)
        br.addWidget(b_imp)
        br.addStretch(1)
        self.lbl_backup = QLabel("")
        self.lbl_backup.setObjectName("PageSub")
        br.addWidget(self.lbl_backup)
        v.addLayout(br)

    def _avatar_icon(self, name):
        """列表里每行的小头像：有自己设的就用，没有就用首字母加底色。"""
        path = avatar.lookup(name or "")
        if path:
            pm = QPixmap(path)
            if not pm.isNull():
                pm = pm.scaled(24, 24, Qt.KeepAspectRatio,
                               Qt.SmoothTransformation)
                icon = QIcon()
                icon.addPixmap(pm)
                return icon
        pm = QPixmap(24, 24)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setBrush(QColor(avatar.default_color(name or "")))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(0, 0, 24, 24, 6, 6)
        f = QFont()
        f.setPixelSize(14)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#FFFFFF"))
        p.drawText(pm.rect(), Qt.AlignCenter, avatar.initial(name or "") or "?")
        p.end()
        icon = QIcon()
        icon.addPixmap(pm)
        return icon

    # ---------- 头像 ----------
    def _refresh_avatar(self, name):
        lb = getattr(self, "lbl_avatar", None)
        if lb is None:
            return
        path = avatar.lookup(name) if name else ""
        if path:
            pm = QPixmap(path)
            if not pm.isNull():
                lb.setText("")
                lb.setPixmap(pm.scaled(52, 52, Qt.KeepAspectRatio,
                                       Qt.SmoothTransformation))
                return
        lb.setPixmap(QPixmap())
        lb.setText(avatar.initial(name) if name else "无头像")

    def _on_row_selected(self):
        if accounts.current_user():
            return
        name = self._target_name()
        self.btn_del.setVisible(bool(name))
        self.btn_avatar.setVisible(bool(name))
        self._refresh_avatar(name)

    def _target_name(self):
        """要操作哪个账号：登录了就是登录的那个，没登录就看列表里选中的/第一个。"""
        u = accounts.current_user()
        if u:
            return u.get("name") or ""
        sel = self.list.currentItem()
        if sel:
            return (sel.text() or "").split("  (")[0].strip()
        if self.list.count():
            return (self.list.item(0).text() or "").split("  (")[0].strip()
        return ""

    def _pick_avatar(self):
        from ui.chat_dialog import AvatarPickerDialog
        name = self._target_name()
        if not name:
            QMessageBox.information(
                self, "还没有账号", "先在下面登录或注册一个账号，再给它设头像。")
            return
        dlg = AvatarPickerDialog(name, self)
        dlg.exec()
        self._refresh_avatar(name)
        self._avatars_dirty = True
        try:
            threading.Thread(
                target=frienddir.announce,
                args=(name, accounts.id_of(name) if hasattr(accounts, "id_of")
                      else name), daemon=True).start()
        except Exception:
            pass

    # ---------- 注销 ----------
    def _delete_account(self):
        target = self._target_name()
        if not target:
            QMessageBox.information(self, "还没有选中", "先在下面的列表里选一个要注销的账号。")
            return
        from ui.delete_account import DeleteAccountDialog
        dlg = DeleteAccountDialog(target, self.config, self)
        dlg.exec()
        if dlg.done_delete:
            self.lbl_backup.setText("已注销：%s" % target)
        self.refresh()

    def _toggle_dir(self, on):
        self.config.set("dir_allow", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        u = accounts.current_user()
        if on and u:
            threading.Thread(target=frienddir.announce,
                             args=(u.get("name"), u.get("id") or u.get("name")),
                             daemon=True).start()

    # ---------- 数据 ----------
    def refresh(self):
        u = accounts.current_user()
        if u:
            self.lbl_who.setText(u.get("name") or "")
            binds = accounts.binds_of(u.get("name"))
            parts = ["邮箱：" + (u.get("email") or "")]
            for kind, _t in accounts.KINDS:
                parts.append("%s：%s" % (accounts.kind_label(kind),
                                         accounts.bind_label(kind, binds.get(kind))
                                         if binds.get(kind) else "未绑定"))
            self.lbl_sub.setText("　·　".join(parts[:2]))
            self.lbl_binds.setText("　|　".join(parts[2:]))
            self.btn_logout.setVisible(True)
            self.btn_login.setVisible(False)
            self.btn_pwd.setVisible(True)
            self.btn_rename.setVisible(True)
            self.btn_del.setVisible(True)
            self.btn_avatar.setVisible(True)
            self._refresh_avatar(u.get("name") or "")
        else:
            self.lbl_who.setText("没有登录")
            self.lbl_sub.setText("随便玩玩完全不用登录；要绑定游戏账号、跨启动记住身份再登。")
            self.lbl_binds.setText("")
            self.btn_logout.setVisible(False)
            self.btn_login.setVisible(True)
            self.btn_pwd.setVisible(False)
            self.btn_rename.setVisible(False)
            # 没登录也能给本机已有的账号换头像 / 注销，头像照样显示
            tname = self._target_name()
            self.btn_del.setVisible(bool(tname))
            self.btn_avatar.setVisible(bool(tname))
            self._refresh_avatar(tname)

        self.list.clear()
        cur = (u or {}).get("name")
        for item in accounts.users():
            name = item.get("name") or ""
            rem = accounts.remember_of(name)
            tags = []
            if name == cur:
                tags.append("当前")
            if rem.get("password"):
                tags.append("记住密码")
            text = name + ("  (%s)" % "、".join(tags) if tags else "")
            row = QListWidgetItem(text)
            row.setIcon(self._avatar_icon(name))
            row.setSizeHint(QSize(0, 34))
            if name == cur:
                f = row.font()
                f.setBold(True)
                row.setFont(f)
            self.list.addItem(row)

        # 列表填好之后，没登录时也要把第一行的头像顶到上面预览里
        if not u and self.list.count():
            tname = self._target_name()
            if tname:
                self.btn_del.setVisible(True)
                self.btn_avatar.setVisible(True)
                self._refresh_avatar(tname)

    def _open_smtp(self):
        dlg = SmtpDialog(self.config, self)
        dlg.exec()
        self.refresh()

    def _open_login(self):
        dlg = LoginDialog(self.config, self)
        if dlg.exec() == QDialog.Accepted and dlg.result_name:
            self._after_login(dlg.result_name)
        self.refresh()

    def _after_login(self, name):
        """登录成功后把绑定的游戏身份灌给启动页。"""
        binds = accounts.binds_of(name)
        off = (binds.get("offline") or {}).get("name")
        self.config.set("username", off or name)
        if binds.get("msa"):
            self.config.set("account_mode", "msa")
            self.apply_bind("msa", binds["msa"])
        elif binds.get("third"):
            self.config.set("account_mode", "third_party")
            self.apply_bind("third", binds["third"])
        else:
            self.config.set("account_mode", "offline")
        try:
            self.config.save()
        except Exception:
            pass
        # 让好友页能按账号名搜到这个人
        try:
            if self.chk_dir.isChecked():
                u = accounts.find(name)
                threading.Thread(target=frienddir.announce,
                                 args=(name, (u or {}).get("id") or name),
                                 daemon=True).start()
        except Exception:
            pass
        self.refresh()

    def _logout(self):
        accounts.logout()
        self.config.set("account_mode", "offline")
        try:
            self.config.save()
        except Exception:
            pass
        self.refresh()

    def _change_pwd(self):
        u = accounts.current_user()
        if not u:
            return
        dlg = PasswordDialog(u.get("name"), self)
        dlg.exec()
        self.refresh()

    def _rename(self):
        """改用户名：同一台设备每天只能改一次。"""
        u = accounts.current_user()
        if not u:
            return
        ok, why = accounts.can_rename(u.get("name"))
        if not ok:
            QMessageBox.information(self, "今天改不了", why)
            return
        new, done = QInputDialog.getText(
            self, "改用户名",
            "新用户名（2-16 位字母数字下划线，%s）：" % why,
            text=u.get("name") or "")
        if not done or not new.strip():
            return
        ok, msg = accounts.rename(u.get("name"), new)
        if not ok:
            QMessageBox.warning(self, "没改成", msg)
            return
        QMessageBox.information(self, "用户名已改", msg)
        self.refresh()

    def _export_backup(self):
        from PySide6.QtWidgets import QFileDialog
        if not accounts.users():
            self.lbl_backup.setText("本机还没有账号可导。")
            return
        pwd, ok = QInputDialog.getText(
            self, "导出账号备份",
            "设一个备份口令（至少 4 位，导入时要输同一个）：", echo=QLineEdit.Password)
        if not ok or not pwd:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "存到哪", str(Path.home() / "Desktop" / "OMC账号备份.omcacc"),
            "OMC 账号备份 (*.omcacc)")
        if not path:
            return
        ok, msg = accounts.export_backup(path, pwd)
        self.lbl_backup.setText(msg)
        if ok:
            QMessageBox.information(self, "导出成功", "%s\n\n%s" % (msg, path))
        else:
            QMessageBox.warning(self, "没导成", msg)

    def _import_backup(self):
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "选备份文件", str(Path.home() / "Desktop"),
            "OMC 账号备份 (*.omcacc);;所有文件 (*)")
        if not path:
            return
        pwd, ok = QInputDialog.getText(
            self, "导入账号备份", "备份口令：", echo=QLineEdit.Password)
        if not ok or not pwd:
            return
        ok, msg = accounts.import_backup(path, pwd)
        self.lbl_backup.setText(msg)
        if ok:
            QMessageBox.information(self, "导入完成", msg)
            self.refresh()
        else:
            QMessageBox.warning(self, "没导进去", msg)

    def _switch(self, item):
        name = (item.text() or "").split("  (")[0].strip()
        if not name:
            return
        u = accounts.current_user()
        if u and u.get("name") == name:
            return
        if accounts.remember_of(name).get("password"):
            ok, msg = accounts.quick_login(name)
            if not ok:
                QMessageBox.warning(self, "切不过去", msg)
                return
            self._after_login(name)
            QMessageBox.information(self, "已切换", "现在用的是 %s" % name)
            return
        dlg = LoginDialog(self.config, self)
        dlg.in_key.setText(name)
        if dlg.exec() == QDialog.Accepted and dlg.result_name:
            self._after_login(dlg.result_name)
        self.refresh()

    # ---------- 绑定 ----------
    def _bind(self, kind):
        u = accounts.current_user()
        if not u:
            QMessageBox.information(self, "先登录", "绑定游戏账号前先登录一个账号。")
            return
        if kind == "offline":
            text, ok = QInputDialog.getText(self, "绑定离线昵称",
                                            "游戏里显示的名字（2-16 字符）：")
            if not ok or not (text or "").strip():
                return
            accounts.bind(u.get("name"), "offline", {"name": text.strip()})
        elif kind == "msa":
            from core import auth
            acct = auth.load_account()
            if not acct or acct.get("type") != "msa":
                QMessageBox.information(
                    self, "还没有微软账号",
                    "先在「启动游戏」页选「正版登录」，用微软账号登一次，再回来绑定。")
                return
            accounts.bind(u.get("name"), "msa", acct)
        else:
            self._bind_third(u.get("name"))
            return
        self._after_login(u.get("name"))
        QMessageBox.information(self, "绑定好了", accounts.kind_label(kind) + "已绑上")

    def _bind_third(self, name):
        from core import yggdrasil
        from .third_dialog import ThirdAuthDialog
        saved = (self.config.get("third_api") or "") if self.config else ""
        dlg = ThirdAuthDialog(self, api=saved)
        if dlg.exec() != QDialog.Accepted or not dlg.acct:
            return
        acct = dlg.acct
        api = yggdrasil.normalize_api(acct.get("api") or "")
        try:
            if self.config:
                self.config.set("third_api", api)
                self.config.save()
        except Exception:
            pass
        accounts.bind(name, "third", acct)
        self._after_login(name)
        QMessageBox.information(self, "绑定好了", "第三方账号已绑上：" + acct.get("name", ""))

    def _unbind_all(self):
        u = accounts.current_user()
        if not u:
            return
        if QMessageBox.question(self, "解除绑定",
                                "把 %s 的三个游戏身份都解开？" % u.get("name")) != QMessageBox.Yes:
            return
        for kind, _t in accounts.KINDS:
            accounts.unbind(u.get("name"), kind)
        self.refresh()
