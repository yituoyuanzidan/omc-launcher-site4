# -*- coding: utf-8 -*-
"""录屏页：设置帧率 / 画质 → 录 → 在启动器里回放 → 剪掉一段 → 导出。"""
import os
import shutil
import threading
import time

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (QComboBox, QDoubleSpinBox, QFileDialog,
                               QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox,
                               QProgressBar, QPushButton, QSlider,
                               QSplitter, QVBoxLayout, QWidget)

from core import screenrec, videocut
from . import media_compat as mc

try:
    from PySide6.QtMultimediaWidgets import QVideoWidget
except Exception:
    QVideoWidget = None


class CutWorker(QObject):
    """后台跑 PyAV 剪辑，进度和结果都用信号回到主线程。"""
    progress = Signal(int)
    done = Signal(bool, str)

    def __init__(self, src, dst, start, end):
        super().__init__()
        self.src, self.dst = src, dst
        self.start, self.end = start, end

    def run(self):
        ok, info = videocut.cut(self.src, self.dst, self.start, self.end,
                                on_progress=self.progress.emit)
        msg = "" if ok else str(info)
        self.done.emit(ok, msg)


class RecordPage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = host.config
        self.recorder = screenrec.Recorder(self)
        self._player = None
        self._audio = None
        self._video = None
        self._cur = None          # 当前选中的文件 dict
        self._dur = 0.0
        self._worker = None
        self._thread = None
        self._rec_t0 = 0.0
        self._tick = QTimer(self)
        self._tick.setInterval(500)
        self._tick.timeout.connect(self._update_state)

        self._build()
        self._load_cfg()
        self.connect_recorder()
        self.refresh_list()
        QTimer.singleShot(0, self._apply_support)

    # ---------- 界面 ----------
    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)

        top = QFrame()
        top.setObjectName("Card")
        tv = QVBoxLayout(top)
        tv.setContentsMargins(16, 14, 16, 14)
        tv.setSpacing(10)

        r1 = QHBoxLayout()
        r1.setSpacing(10)
        r1.addWidget(QLabel("帧率"))
        self.cb_fps = QComboBox()
        for fps, name in screenrec.FPS_CHOICES:
            self.cb_fps.addItem(name, fps)
        self.cb_fps.setFixedWidth(110)
        r1.addWidget(self.cb_fps)

        r1.addSpacing(8)
        r1.addWidget(QLabel("画质"))
        self.cb_q = QComboBox()
        for key, name, _cls, _br in screenrec.QUALITY_CHOICES:
            self.cb_q.addItem(name, key)
        self.cb_q.setFixedWidth(110)
        r1.addWidget(self.cb_q)
        r1.addStretch(1)
        self.btn_rec = QPushButton("开始录屏")
        self.btn_rec.setObjectName("Primary")
        self.btn_rec.setFixedHeight(38)
        self.btn_rec.setMinimumWidth(150)
        self.btn_rec.clicked.connect(self._on_rec_clicked)
        r1.addWidget(self.btn_rec)
        tv.addLayout(r1)

        r2 = QHBoxLayout()
        r2.setSpacing(10)
        r2.addWidget(QLabel("保存到"))
        self.ed_dir = QLineEdit()
        self.ed_dir.setReadOnly(False)
        r2.addWidget(self.ed_dir, 1)
        b1 = QPushButton("浏览")
        b1.clicked.connect(self._pick_dir)
        b2 = QPushButton("打开文件夹")
        b2.clicked.connect(self._open_dir)
        r2.addWidget(b1)
        r2.addWidget(b2)
        tv.addLayout(r2)

        self.lb_state = QLabel("就绪")
        self.lb_state.setObjectName("PageSub")
        tv.addWidget(self.lb_state)
        v.addWidget(top)

        split = QSplitter(Qt.Horizontal)
        split.setChildrenCollapsible(False)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        lh = QHBoxLayout()
        lh.addWidget(QLabel("录好的视频"))
        lh.addStretch(1)
        rb = QPushButton("刷新")
        rb.setFixedWidth(70)
        rb.clicked.connect(self.refresh_list)
        db = QPushButton("删除")
        db.setFixedWidth(70)
        db.clicked.connect(self._delete_cur)
        lh.addWidget(rb)
        lh.addWidget(db)
        lv.addLayout(lh)
        self.list = QListWidget()
        self.list.currentRowChanged.connect(self._on_pick)
        lv.addWidget(self.list, 1)
        left.setMinimumWidth(300)
        split.addWidget(left)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(8)
        # 视频控件建太早会初始化多媒体后端，拖慢启动；先放占位，选中文件再建
        self._video_box = QVBoxLayout()
        self._video_box.setContentsMargins(0, 0, 0, 0)
        self._video_hint = QLabel("选一个录屏，点播放就在这儿看"
                                  if QVideoWidget is not None
                                  else "当前运行环境没有视频播放组件")
        self._video_hint.setAlignment(Qt.AlignCenter)
        self._video_hint.setMinimumHeight(220)
        self._video_hint.setObjectName("PageSub")
        self._video_box.addWidget(self._video_hint, 1)
        rv.addLayout(self._video_box, 1)

        ctl = QHBoxLayout()
        ctl.setSpacing(8)
        self.btn_play = QPushButton("播放")
        self.btn_play.setFixedWidth(80)
        self.btn_play.clicked.connect(self._toggle_play)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.sliderMoved.connect(self._seek)
        self.lb_time = QLabel("00:00 / 00:00")
        ctl.addWidget(self.btn_play)
        ctl.addWidget(self.slider, 1)
        ctl.addWidget(self.lb_time)
        rv.addLayout(ctl)

        cut = QFrame()
        cut.setObjectName("Card")
        cv = QVBoxLayout(cut)
        cv.setContentsMargins(14, 12, 14, 12)
        cv.setSpacing(8)
        cv.addWidget(QLabel("剪辑：选好保留的起止时间，导出成新视频"))
        cr = QHBoxLayout()
        cr.setSpacing(8)
        cr.addWidget(QLabel("起点"))
        self.sp_start = QDoubleSpinBox()
        self.sp_start.setDecimals(1)
        self.sp_start.setSuffix(" 秒")
        self.sp_start.setMaximum(6000)
        self.sp_start.setSingleStep(0.5)
        self.sp_start.setFixedWidth(110)
        cr.addWidget(self.sp_start)
        cr.addWidget(QLabel("终点"))
        self.sp_end = QDoubleSpinBox()
        self.sp_end.setDecimals(1)
        self.sp_end.setSuffix(" 秒")
        self.sp_end.setMaximum(6000)
        self.sp_end.setSingleStep(0.5)
        self.sp_end.setFixedWidth(110)
        cr.addWidget(self.sp_end)
        self.btn_cut = QPushButton("导出片段")
        self.btn_cut.setObjectName("Primary")
        self.btn_cut.clicked.connect(self._do_cut)
        cr.addWidget(self.btn_cut)
        self.btn_save = QPushButton("另存为")
        self.btn_save.clicked.connect(self._save_as)
        cr.addWidget(self.btn_save)
        cr.addStretch(1)
        cv.addLayout(cr)
        self.pbar = QProgressBar()
        self.pbar.setRange(0, 100)
        self.pbar.setValue(0)
        self.pbar.setVisible(False)
        cv.addWidget(self.pbar)
        rv.addWidget(cut)
        right.setMinimumWidth(420)
        split.addWidget(right)
        split.setSizes([340, 620])
        v.addWidget(split, 1)

    # ---------- 配置 ----------
    def _load_cfg(self):
        d = self.cfg.get("rec_dir") or screenrec.default_dir()
        self.ed_dir.setText(str(d))
        fps = int(self.cfg.get("rec_fps") or 30)
        for i in range(self.cb_fps.count()):
            if self.cb_fps.itemData(i) == fps:
                self.cb_fps.setCurrentIndex(i)
                break
        q = self.cfg.get("rec_quality") or "high"
        for i in range(self.cb_q.count()):
            if self.cb_q.itemData(i) == q:
                self.cb_q.setCurrentIndex(i)
                break
        self.cb_fps.currentIndexChanged.connect(self._save_cfg)
        self.cb_q.currentIndexChanged.connect(self._save_cfg)
        self.ed_dir.editingFinished.connect(self._save_cfg)

    def _save_cfg(self, *_):
        try:
            self.cfg.set("rec_fps", int(self.cb_fps.currentData() or 30))
            self.cfg.set("rec_quality", self.cb_q.currentData() or "high")
            d = self.ed_dir.text().strip()
            if d:
                self.cfg.set("rec_dir", d)
        except Exception:
            pass

    def _dir(self):
        d = self.ed_dir.text().strip() or screenrec.default_dir()
        screenrec.ensure_dir(d)
        return d

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "选择录屏保存目录", self._dir())
        if d:
            self.ed_dir.setText(d)
            self._save_cfg()
            self.refresh_list()

    def _open_dir(self):
        d = self._dir()
        try:
            os.startfile(d)
        except Exception as e:
            QMessageBox.warning(self, "打不开", "打不开这个目录：%s" % e)

    # ---------- 能力 ----------
    def _apply_support(self):
        if not screenrec.HAS_CAPTURE:
            self.btn_rec.setEnabled(False)
            self.btn_rec.setText("本系统不支持")
            self.lb_state.setText(
                "这台系统（Qt5 / Win7 分支）的录屏组件不可用，录屏只能在新版 "
                "Windows 上用；剪辑和播放仍可用。")
        else:
            self.lb_state.setText("就绪：录屏开始后，屏幕右上角会出现停止按钮。")
        if not videocut.has_av():
            self.btn_cut.setEnabled(False)
            self.btn_save.setEnabled(True)
            self.pbar.setVisible(False)

    # ---------- 录制 ----------
    def connect_recorder(self):
        rec = self.recorder
        if rec.started is not None:
            rec.started.connect(self._on_started)
        if rec.finished is not None:
            rec.finished.connect(self._on_finished)
        if rec.failed is not None:
            rec.failed.connect(self._on_failed)

    def _on_rec_clicked(self):
        if self.recorder.is_recording():
            self.recorder.stop()
            self.btn_rec.setEnabled(False)
            self.lb_state.setText("正在收尾，马上好…")
            return
        self._save_cfg()
        ok = self.recorder.start(self._dir(),
                                 fps=int(self.cb_fps.currentData() or 30),
                                 quality=self.cb_q.currentData() or "high")
        if not ok:
            return
        self._tick.start()

    def _on_started(self, path):
        self._rec_t0 = time.time()
        self.btn_rec.setText("停止录屏")
        self.lb_state.setText("录制中：0 秒")
        bar = self.recorder.bar()
        if bar is not None and bar._excluded is False:
            self.lb_state.setText(
                "录制中，但本系统不允许把停止按钮排除出画面（需要 Win10 2004 以上），"
                "录出来的视频可能会带上那个按钮。")

    def _update_state(self):
        if not self.recorder.is_recording():
            return
        s = int(time.time() - self._rec_t0)
        self.lb_state.setText("录制中：%02d:%02d" % (s // 60, s % 60))

    def _on_finished(self, path, dur_ms):
        self._tick.stop()
        self.btn_rec.setEnabled(True)
        self.btn_rec.setText("开始录屏")
        self.lb_state.setText("已保存：%s（%s）"
                              % (os.path.basename(path), screenrec.human_dur(dur_ms)))
        self.refresh_list(select=path)

    def _on_failed(self, msg):
        self._tick.stop()
        self.btn_rec.setEnabled(True)
        self.btn_rec.setText("开始录屏")
        self.lb_state.setText("录制失败")
        QMessageBox.warning(self, "录屏失败", str(msg))

    # ---------- 列表 ----------
    def refresh_list(self, select=None):
        cur = select or (self._cur["path"] if self._cur else "")
        self.list.blockSignals(True)
        self.list.clear()
        rows = screenrec.list_recordings(self._dir())
        idx = -1
        for i, f in enumerate(rows):
            dur = self._cached_dur(f["path"])
            txt = "%s    %s    %s" % (f["name"],
                                      screenrec.human_dur(dur) if dur else "—",
                                      screenrec.human_size(f["size"]))
            it = QListWidgetItem(txt)
            it.setData(Qt.UserRole, f)
            self.list.addItem(it)
            if cur and f["path"] == cur:
                idx = i
        self.list.blockSignals(False)
        if idx >= 0:
            self.list.setCurrentRow(idx)
        elif rows:
            self.list.setCurrentRow(0)
        else:
            self._cur = None
            self.lb_time.setText("00:00 / 00:00")
            self.sp_start.setValue(0)
            self.sp_end.setValue(0)

    _DUR_CACHE = {}

    def _cached_dur(self, path):
        try:
            st = os.stat(path)
            key = (path, st.st_mtime, st.st_size)
            if key in RecordPage._DUR_CACHE:
                return RecordPage._DUR_CACHE[key]
            p = videocut.probe(path)
            dur = int(round((p["duration"] if p else 0) * 1000))
            if len(RecordPage._DUR_CACHE) > 200:
                RecordPage._DUR_CACHE.clear()
            RecordPage._DUR_CACHE[key] = dur
            return dur
        except Exception:
            return 0

    def _on_pick(self, row):
        it = self.list.item(row)
        if it is None:
            return
        f = it.data(Qt.UserRole)
        if not f:
            return
        self._cur = f
        self._load_file(f["path"])

    def _load_file(self, path):
        dur_ms = self._cached_dur(path)
        self._dur = max(0.0, dur_ms / 1000.0)
        self.sp_start.setValue(0.0)
        self.sp_end.setValue(round(self._dur, 1))
        self.lb_time.setText("00:00 / %s" % screenrec.human_dur(dur_ms))
        self.slider.setValue(0)
        self._ensure_player()
        if self._player is not None:
            try:
                mc.set_source(self._player, QUrl.fromLocalFile(path))
                self._player.pause()
            except Exception:
                pass
        self.btn_play.setText("播放")

    def _ensure_video(self):
        if self._video is not None or QVideoWidget is None:
            return self._video
        try:
            self._video = QVideoWidget()
            self._video.setMinimumHeight(220)
            self._video.setStyleSheet("background:#000;border-radius:8px;")
            self._video_hint.hide()
            self._video_box.addWidget(self._video, 1)
        except Exception:
            self._video = None
        return self._video

    def _ensure_player(self):
        if self._player is not None:
            return
        if not mc.HAS_MEDIA:
            return
        self._ensure_video()
        self._player = mc.make_player(self)
        if self._player is None:
            return
        self._audio = mc.make_audio(self._player, self, 0.8)
        if self._video is not None:
            self._player.setVideoOutput(self._video)
        self._player.positionChanged.connect(self._on_pos)
        self._player.durationChanged.connect(self._on_dur)
        try:
            self._player.playbackStateChanged.connect(self._on_play_state)
        except Exception:
            pass

    def _on_pos(self, pos):
        if self._player is None:
            return
        d = self._player.duration() or int(self._dur * 1000)
        if d > 0:
            self.slider.blockSignals(True)
            self.slider.setValue(int(pos / d * 1000))
            self.slider.blockSignals(False)
        self.lb_time.setText("%s / %s" % (screenrec.human_dur(pos),
                                          screenrec.human_dur(d)))

    def _on_dur(self, d):
        if d > 0:
            self._dur = d / 1000.0
            self.sp_end.setValue(round(self._dur, 1))

    def _on_play_state(self, st):
        try:
            playing = int(getattr(st, "value", st)) == int(
                getattr(mc.playing_state(), "value", mc.playing_state()))
        except Exception:
            playing = False
        self.btn_play.setText("暂停" if playing else "播放")

    def _toggle_play(self):
        self._ensure_player()
        if self._player is None:
            QMessageBox.information(self, "不能播放", "当前环境没有可用的播放组件。")
            return
        try:
            if int(getattr(self._player.playbackState(), "value",
                           self._player.playbackState())) == \
                    int(getattr(mc.playing_state(), "value", mc.playing_state())):
                self._player.pause()
            else:
                self._player.play()
        except Exception:
            pass

    def _seek(self, v):
        if self._player is None:
            return
        d = self._player.duration() or int(self._dur * 1000)
        try:
            self._player.setPosition(int(d * v / 1000.0))
        except Exception:
            pass

    def _delete_cur(self):
        if not self._cur:
            return
        p = self._cur["path"]
        if QMessageBox.question(self, "删除", "删掉这个录屏？\n%s"
                                % os.path.basename(p)) != QMessageBox.Yes:
            return
        try:
            if self._player is not None:
                self._player.stop()
            os.remove(p)
        except Exception as e:
            QMessageBox.warning(self, "删不掉", str(e))
            return
        self._cur = None
        self.refresh_list()

    # ---------- 剪辑 / 导出 ----------
    def _do_cut(self):
        if not self._cur:
            QMessageBox.information(self, "先选一个", "先在左边选一个录好的视频。")
            return
        if not videocut.has_av():
            QMessageBox.warning(self, "剪辑不可用",
                                "剪辑组件没装上：%s" % videocut.av_error())
            return
        s = float(self.sp_start.value())
        e = float(self.sp_end.value())
        if e <= s + 0.1:
            QMessageBox.warning(self, "时间不对", "终点要比起点晚至少 0.1 秒。")
            return
        src = self._cur["path"]
        base, _ext = os.path.splitext(src)
        dst = base + "_clip.mp4"
        i = 1
        while os.path.exists(dst):
            dst = "%s_clip_%d.mp4" % (base, i)
            i += 1

        self.btn_cut.setEnabled(False)
        self.pbar.setVisible(True)
        self.pbar.setValue(0)
        self.lb_state.setText("正在导出片段…")

        w = CutWorker(src, dst, s, e)
        th = threading.Thread(target=w.run, daemon=True)
        w.progress.connect(self.pbar.setValue)
        w.done.connect(lambda ok, msg, d=dst: self._cut_done(ok, msg, d))
        self._worker = w
        self._thread = th
        th.start()

    def _cut_done(self, ok, msg, dst):
        self.btn_cut.setEnabled(True)
        self.pbar.setVisible(False)
        if not ok:
            self.lb_state.setText("导出失败")
            QMessageBox.warning(self, "导出失败", msg)
            return
        self.lb_state.setText("已导出：%s（%s）"
                              % (os.path.basename(dst),
                                 screenrec.human_size(os.path.getsize(dst))))
        self.refresh_list(select=dst)

    def _save_as(self):
        if not self._cur:
            QMessageBox.information(self, "先选一个", "先在左边选一个视频。")
            return
        src = self._cur["path"]
        dst, _ = QFileDialog.getSaveFileName(
            self, "另存为", os.path.join(self._dir(), os.path.basename(src)),
            "视频 (*.mp4)")
        if not dst:
            return
        try:
            shutil.copy2(src, dst)
            self.lb_state.setText("已另存：%s" % dst)
        except Exception as e:
            QMessageBox.warning(self, "另存失败", str(e))

    # ---------- 关窗口 ----------
    def shutdown(self):
        try:
            if self.recorder.is_recording():
                self.recorder.stop()
        except Exception:
            pass
        try:
            if self._player is not None:
                self._player.stop()
        except Exception:
            pass
