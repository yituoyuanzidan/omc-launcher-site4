# -*- coding: utf-8 -*-
"""右下角消息提示条 + 「叮」音效。

要点：
- 提示条是**没有父窗口的顶层窗口**，所以主窗口最小化、甚至只停在托盘时，
  它照样出现在屏幕右下角（这是「最小化了也要提示」的做法）。
- 多条同时来会往上叠，最多 4 条，点一下就能打开对应的聊天。
- 音效优先用系统自带的 wav（Windows Ding），没有就退回 MessageBeep。
"""
import os
import queue
import threading

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
                               QPushButton, QVBoxLayout)

MARGIN = 12
GAP = 8
MAX_TOASTS = 4

_WAV_CANDIDATES = [
    r"C:\Windows\Media\Windows Ding.wav",
    r"C:\Windows\Media\Windows Notify System Generic.wav",
    r"C:\Windows\Media\Windows Notify.wav",
    r"C:\Windows\Media\ding.wav",
    r"C:\Windows\Media\notify.wav",
]

_sound_q = queue.Queue()
_sound_thread = None


def _sound_worker():
    """单独一条线程专管响声，避免卡住界面。"""
    while True:
        path = _sound_q.get()
        try:
            if path and os.path.isfile(path):
                import winsound
                winsound.PlaySound(path, winsound.SND_FILENAME)
            else:
                import winsound
                winsound.MessageBeep(winsound.MB_ICONASTERISK)
        except Exception:
            pass
        finally:
            _sound_q.task_done()


def ding():
    """叮一声（非阻塞）。"""
    global _sound_thread
    if _sound_thread is None:
        _sound_thread = threading.Thread(target=_sound_worker, daemon=True,
                                         name="omc-ding")
        _sound_thread.start()
    path = ""
    for p in _WAV_CANDIDATES:
        if os.path.isfile(p):
            path = p
            break
    try:
        _sound_q.put_nowait(path)
    except Exception:
        pass


def play_any(path):
    """播任意音频（wav；其它格式交给 Qt）。"""
    if not path:
        ding()
        return
    ext = os.path.splitext(path)[1].lower()
    if ext == ".wav" and os.path.isfile(path):
        global _sound_thread
        if _sound_thread is None:
            _sound_thread = threading.Thread(target=_sound_worker, daemon=True,
                                             name="omc-ding")
            _sound_thread.start()
        _sound_q.put_nowait(path)
    else:
        ToastCenter.player_once(path)


class Toast(QFrame):
    clicked = Signal(str, object)

    def __init__(self, kind, title, body, key, parent=None):
        super().__init__(parent, Qt.Window | Qt.FramelessWindowHint |
                         Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
        self.kind = kind
        self.key = key
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFixedWidth(330)
        self.setStyleSheet(
            "QFrame#Toast{background:#22262F;border:1px solid #3A4150;"
            "border-radius:10px;}"
            "QLabel#toastTitle{color:#FFFFFF;font-size:13px;font-weight:700;}"
            "QLabel#toastBody{color:#C6CEDB;font-size:12px;}"
            "QPushButton#toastClose{color:#98A2B3;border:none;font-size:14px;}")
        self.setObjectName("Toast")

        v = QVBoxLayout(self)
        v.setContentsMargins(12, 10, 10, 10)
        v.setSpacing(4)
        head = QHBoxLayout()
        self.lb_title = QLabel(title)
        self.lb_title.setObjectName("toastTitle")
        head.addWidget(self.lb_title, 1)
        self.btn_x = QPushButton("×")
        self.btn_x.setObjectName("toastClose")
        self.btn_x.setFixedSize(22, 22)
        self.btn_x.clicked.connect(self.close)
        head.addWidget(self.btn_x)
        v.addLayout(head)
        self.lb_body = QLabel(body)
        self.lb_body.setObjectName("toastBody")
        self.lb_body.setWordWrap(True)
        v.addWidget(self.lb_body)
        self.adjustSize()

    def mouseReleaseEvent(self, e):
        try:
            self.clicked.emit(self.kind, self.key)
        except Exception:
            pass
        self.close()
        super().mouseReleaseEvent(e)


class ToastCenter(QObject):
    """管理所有浮窗的位置、堆叠、自动消失。"""
    _inst = None
    open_chat = Signal(str, object)      # ("friend"/"group", key)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items = []
        self._one = None
        self.open_chat.connect(self._dispatch)

    @classmethod
    def get(cls):
        if cls._inst is None:
            cls._inst = ToastCenter()
        return cls._inst

    # ---------- 铃声只放一次的小工具 ----------
    @classmethod
    def player_once(cls, path):
        try:
            from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
            from PySide6.QtCore import QUrl
            if getattr(cls, "_pl", None) is None:
                cls._pl = QMediaPlayer()
                cls._out = QAudioOutput()
                cls._pl.setAudioOutput(cls._out)
            cls._pl.setSource(QUrl.fromLocalFile(path))
            cls._pl.play()
        except Exception:
            ding()

    def _dispatch(self, kind, key):
        target = getattr(self, "host", None)
        if target is None:
            return
        try:
            if kind == "friend":
                target._open_chat_by_name(key)
            elif kind == "group":
                target._open_group_by_id(key)
        except Exception:
            pass

    # ---------- 显示 ----------
    def show_toast(self, title, body, kind="friend", key=None, life=4200):
        if QApplication.instance() is None:
            return
        t = Toast(kind, title, body, key)
        t.clicked.connect(self._on_clicked)
        self.items.append(t)
        while len(self.items) > MAX_TOASTS:
            old = self.items.pop(0)
            try:
                old.close()
            except Exception:
                pass
        t.show()
        self._reflow()
        QTimer.singleShot(life, lambda: self._expire(t))
        return t

    def _on_clicked(self, kind, key):
        self.open_chat.emit(kind, key)

    def _expire(self, t):
        if t in self.items:
            self.items.remove(t)
        try:
            t.close()
        except Exception:
            pass
        self._reflow()

    def _reflow(self):
        screen = QApplication.primaryScreen()
        if screen is None:
            return
        geo = screen.availableGeometry()
        bottom = geo.bottom() - MARGIN
        for t in reversed(self.items):          # 新的在最下面
            t.adjustSize()
            h = t.height()
            y = bottom - h
            t.setGeometry(geo.right() - MARGIN - t.width(), y,
                          t.width(), h)
            bottom = y - GAP


def notify(host, title, body, kind="friend", key=None, sound=True):
    """统一入口：弹提示 + 可能响一声。"""
    center = ToastCenter.get()
    center.host = host
    if sound:
        ding()
    center.show_toast(title, body, kind, key)
