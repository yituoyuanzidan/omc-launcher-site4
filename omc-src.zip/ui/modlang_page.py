# -*- coding: utf-8 -*-
"""工具页「模组汉化」页签：把装了英文的模组翻成中文，做成一个资源包。

不改模组本体；结果放在 resourcepacks/OMC-模组汉化.zip，
游戏里启用一下这个资源包，模组里的英文就变中文。
"""
import os
import time

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton, QVBoxLayout,
    QWidget,
)

from core import modlang


class _ScanWorker(QThread):
    done = Signal(object)

    def __init__(self, game_dir, vid, parent=None):
        super().__init__(parent)
        self.game_dir = game_dir
        self.vid = vid

    def run(self):
        try:
            stats, entries = modlang.quick_stats(self.game_dir, self.vid)
            self.done.emit({"stats": stats, "entries": entries})
        except Exception as e:
            self.done.emit({"error": str(e)})


class _TrWorker(QThread):
    progress = Signal(int, int, str)
    done = Signal(str, int, int)

    def __init__(self, game_dir, entries, parent=None):
        super().__init__(parent)
        self.game_dir = game_dir
        self.entries = entries

    def run(self):
        try:
            texts = []
            for kv in self.entries.values():
                for v in kv.values():
                    if v and v not in texts:
                        texts.append(v)
            t0 = time.time()
            got = modlang.translate_texts(texts, progress=self._p)
            pack = modlang.default_pack_path(self.game_dir)
            n = modlang.build_pack(self.entries, got, pack)
            self.done.emit(pack, n, int(time.time() - t0))
        except Exception as e:
            self.done.emit("ERR:" + str(e), 0, 0)

    def _p(self, a, b, msg):
        # 节流：只在进度变化比较明显时发信号，别刷爆主线程
        if a == 0 or a == b or a - getattr(self, "_last", -99) >= 24:
            self._last = a
            self.progress.emit(int(a), int(b), msg)


class ModLangPage(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = getattr(host, "config", None)
        self._scan = None
        self._tr = None
        self._entries = {}

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 10, 0, 0)
        v.setSpacing(10)

        hint = QLabel("扫你已经装的模组，把里面的英文语言文件翻成中文，"
                      "生成一个资源包放进 resourcepacks。不改模组本体，删掉资源包就能恢复。")
        hint.setObjectName("PageSub")
        hint.setWordWrap(True)
        v.addWidget(hint)

        row = QHBoxLayout()
        row.setSpacing(8)
        self.btn_scan = QPushButton("扫描模组")
        self.btn_scan.clicked.connect(self.scan)
        row.addWidget(self.btn_scan)
        self.btn_tr = QPushButton("开始汉化")
        self.btn_tr.setEnabled(False)
        self.btn_tr.clicked.connect(self.translate_all)
        row.addWidget(self.btn_tr)
        self.btn_open = QPushButton("打开资源包文件夹")
        self.btn_open.clicked.connect(self.open_folder)
        row.addWidget(self.btn_open)
        row.addStretch(1)
        v.addLayout(row)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(True)
        self.bar.setFixedHeight(16)
        v.addWidget(self.bar)

        self.state = QLabel("点「扫描模组」先看看有多少条要翻。")
        self.state.setObjectName("PageSub")
        self.state.setWordWrap(True)
        v.addWidget(self.state)

        self.detail = QLabel("")
        self.detail.setObjectName("PageSub")
        self.detail.setWordWrap(True)
        try:
            self.detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
        except Exception:
            pass
        v.addWidget(self.detail)
        v.addStretch(1)

    # ---------- 配置 ----------
    def _game_dir(self):
        try:
            gd = (self.cfg.get("game_dir") if self.cfg else "") or ""
        except Exception:
            gd = ""
        return gd or os.path.join(os.path.expanduser("~"), ".minecraft")

    def _vid(self):
        try:
            return (self.cfg.get("last_version") if self.cfg else "") or ""
        except Exception:
            return ""

    # ---------- 扫描 ----------
    def scan(self):
        if self._scan is not None and self._scan.isRunning():
            return
        self.btn_scan.setEnabled(False)
        self.btn_tr.setEnabled(False)
        self.state.setText("正在读模组 jar…")
        self._scan = _ScanWorker(self._game_dir(), self._vid(), self)
        self._scan.done.connect(self._on_scanned)
        self._scan.start()

    def _on_scanned(self, res):
        self.btn_scan.setEnabled(True)
        if res.get("error"):
            self.state.setText("扫描失败：%s" % res["error"])
            return
        stats = res.get("stats") or {}
        self._entries = res.get("entries") or {}
        keys = stats.get("keys", 0)
        self.state.setText(
            "模组 %d 个：%d 个有英文语言文件，其中 %d 个自带中文（跳过），"
            "合计 %d 条待翻。%s"
            % (stats.get("mods", 0), stats.get("with_en", 0),
               stats.get("has_zh", 0), keys,
               "已有资源包：%s" % os.path.basename(stats.get("pack") or "")
               if stats.get("exists") else "还没有生成过资源包。"))
        names = list(self._entries.keys())
        self.detail.setText("涉及的模组 id：%s" % ("、".join(names[:12])
                                              + ("…" if len(names) > 12 else "")
                                              if names else "（没有需要翻的）"))
        if keys:
            self.btn_tr.setEnabled(True)
        elif stats.get("mods") == 0:
            self.state.setText("这个游戏目录的 mods 里没有 jar。装过模组再来。")

    # ---------- 翻译 ----------
    def translate_all(self):
        if not self._entries:
            self.state.setText("先扫描一次。")
            return
        if self._tr is not None and self._tr.isRunning():
            return
        keys = sum(len(v) for v in self._entries.values())
        if keys > 1200:
            ok = QMessageBox.question(
                self, "有点多",
                "要翻 %d 条，联网翻译估计要几分钟，可能触及免费接口的限流。继续吗？" % keys,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
        self.btn_tr.setEnabled(False)
        self.btn_scan.setEnabled(False)
        self.bar.setValue(0)
        self.state.setText("开始翻译…（第一次会慢些，翻过的会记在缓存里）")
        self._tr = _TrWorker(self._game_dir(), self._entries, self)
        self._tr.progress.connect(self._on_progress)
        self._tr.done.connect(self._on_translated)
        self._tr.start()

    def _on_progress(self, a, b, msg):
        self.bar.setValue(int(a * 100 / b) if b else 0)
        self.state.setText("%s（%d / %d）" % (msg, a, b))

    def _on_translated(self, pack, n, secs):
        self.btn_scan.setEnabled(True)
        self.btn_tr.setEnabled(True)
        if str(pack).startswith("ERR:"):
            self.state.setText("汉化失败：%s" % str(pack)[4:])
            return
        self.bar.setValue(100)
        try:
            size = os.path.getsize(pack) // 1024
        except OSError:
            size = 0
        self.state.setText(
            "好了：%d 个模组的中文语言写进了 %s（%d KB，用时 %d 秒）。\n"
            "去游戏里「选项 → 资源包」启用「OMC 模组汉化」就有了。"
            % (n, os.path.basename(pack), size, secs))

    # ---------- 打开目录 ----------
    def open_folder(self):
        p = modlang.resourcepacks_dir(self._game_dir())
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(p))
        except Exception:
            self.state.setText("打不开目录：%s" % p)
