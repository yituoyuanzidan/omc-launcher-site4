# -*- coding: utf-8 -*-
"""皮肤库页面：网格预览点选、搜索、热门主播、穿搭保存/选用、应用到游戏。"""
import os
import time
import zipfile

from PySide6.QtCore import QRect, QSize, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QImage, QPainter, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFrame, QGridLayout,
    QHBoxLayout, QInputDialog,
    QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget,
)

from core import outfitcode, skinapply, skinlib


# ---------------------------------------------------------------- 预览绘制
def skin_front_pixmap(path, scale=4):
    """按皮肤贴图 UV 拼出正面角色，和游戏里看到的一致。"""
    img = QImage(path)
    if img.isNull():
        return QPixmap()
    src = img.convertToFormat(QImage.Format_ARGB32)
    wide = src.width() >= 64
    slim = False
    if wide:
        slim = all(src.pixelColor(x, y).alpha() == 0
                   for x in (46, 47) for y in range(20, 32))
    head = (8, 8, 8, 8)
    hat = (40, 8, 8, 8)
    body = (20, 20, 8, 12)
    aw = 3 if slim else 4
    rarm = (44, 20, aw, 12)
    larm = (36, 52, aw, 12) if wide else rarm
    rleg = (4, 20, 4, 12)
    lleg = (20, 52, 4, 12) if wide else rleg
    W, H = 8 + 2 * aw, 32
    bx = aw
    canvas = QImage(W, H, QImage.Format_ARGB32)
    canvas.fill(Qt.transparent)
    p = QPainter(canvas)
    p.setRenderHint(QPainter.SmoothPixmapTransform, False)

    def blit(rect, dx, dy):
        x, y, rw, rh = rect
        p.drawImage(QRect(dx, dy, rw, rh), src, QRect(x, y, rw, rh))

    blit(rleg, bx, 20)
    blit(lleg, bx + 4, 20)
    blit(rarm, 0, 8)
    blit(larm, W - aw, 8)
    blit(body, bx, 8)
    blit(head, bx, 0)
    blit(hat, bx, 0)
    p.end()
    s = max(1, int(scale))
    return QPixmap.fromImage(canvas).scaled(W * s, H * s, Qt.KeepAspectRatio,
                                            Qt.FastTransformation)


def _blank_pix(size=64):
    pix = QPixmap(size, size)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor("#3A4150"))
    p.drawEllipse(0, 0, size, size)
    p.setPen(QColor("#C8CEDB"))
    f = QFont()
    f.setBold(True)
    p.setFont(f)
    p.drawText(QRect(0, 0, size, size), Qt.AlignCenter, "?")
    p.end()
    return pix


# 网格图标缓存：同一张贴图只合成一次，避免每次刷新都重解码
_ICON_CACHE = {}


def grid_icon(path, scale=3):
    if not path:
        return QIcon(_blank_pix(48))
    try:
        st = os.stat(path)
        key = (path, int(st.st_mtime), st.st_size, scale)
    except OSError:
        return QIcon(_blank_pix(48))
    ic = _ICON_CACHE.get(key)
    if ic is not None:
        return ic
    pix = skin_front_pixmap(path, scale)
    ic = QIcon(pix) if not pix.isNull() else QIcon(_blank_pix(48))
    if len(_ICON_CACHE) > 1500:
        _ICON_CACHE.clear()
    _ICON_CACHE[key] = ic
    return ic


# ---------------------------------------------------------------- 后台拉取
class SkinFetchWorker(QThread):
    one = Signal(str, str, str)     # name, skin_path, cape_path
    finished_all = Signal(int)
    log = Signal(str)

    def __init__(self, names, want_cape=True, force=False, workers=5):
        super().__init__()
        self.names = list(names)
        self.want_cape = want_cape
        self.force = force
        self.workers = workers

    def run(self):
        """并发拉取：一个名字一个任务，谁先回来先显示，不再排队等前面那个。"""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        done = []

        def job(nm):
            try:
                return skinlib.ensure_item(
                    nm, want_cape=self.want_cape, retry_bad=self.force,
                    log=lambda m: self.log.emit(m))
            except Exception as e:
                self.log.emit("拉取 %s 失败：%s" % (nm, e))
                return None

        with ThreadPoolExecutor(max_workers=max(1, self.workers)) as ex:
            futs = {ex.submit(job, nm): nm for nm in self.names}
            for f in as_completed(futs):
                try:
                    rec = f.result()
                except Exception:
                    rec = None
                nm = futs[f]
                if rec and rec.get("skin"):
                    done.append(rec.get("name") or nm)
                    self.one.emit(rec.get("name") or nm,
                                  rec.get("skin", ""), rec.get("cape", ""))
        self.finished_all.emit(len(done))


# ------------------------------------------------------ 未下载皮肤的临时预览
class SkinPreviewWorker(QThread):
    """只拉预览图（存临时文件，不进皮肤库），用来把没下载的格子也显示成样子。"""
    one = Signal(str, str)      # name, preview_path
    finished_all = Signal(int)

    def __init__(self, names, workers=6, parent=None):
        super().__init__(parent)
        self.names = list(names)
        self.workers = workers

    def run(self):
        from concurrent.futures import ThreadPoolExecutor

        hit = 0

        def job(nm):
            try:
                return nm, skinlib.fetch_preview(nm)
            except Exception:
                return nm, ("", "")

        with ThreadPoolExecutor(max_workers=max(1, self.workers)) as ex:
            for nm, res in ex.map(job, self.names):
                if res and res[0]:
                    hit += 1
                    self.one.emit(nm, res[0])
        self.finished_all.emit(hit)


# ---------------------------------------------------------------- 页面
class SkinLibraryPage(QWidget):
    def __init__(self, config, game_dir_getter=None, version_getter=None,
                 username_getter=None, log=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.game_dir_getter = game_dir_getter or (lambda: self.config.get("game_dir"))
        self.version_getter = version_getter or (lambda: self.config.get("last_version"))
        self.username_getter = username_getter or (lambda: self.config.get("username") or "Player")
        self._log = log or (lambda m: None)
        self._worker = None
        self._preview_worker = None
        self._previewing = set()
        self._preview_failed = set()
        self._preview_queue = []
        self._selected = {"name": "", "label": "", "skin": "", "cape": ""}
        self._page = 0            # 当前第几页（从 0 起）
        self._page_size = 60      # 每页格子数
        self._page_total = 1
        self._row_key = None      # 筛选条件指纹：一变就回到第一页
        self._build()
        self.refresh(reset_filter=True)
        QTimer.singleShot(1200, self._auto_fill_featured)

    # ---------- 构建
    def _build(self):
        self.setAcceptDrops(True)
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)

        head = QHBoxLayout()
        t = QLabel("皮肤库")
        t.setObjectName("PageTitle")
        head.addWidget(t)
        head.addStretch(1)
        self.btn_open_outfits = QPushButton("打开穿搭库文件夹")
        self.btn_open_outfits.clicked.connect(self._open_outfits)
        head.addWidget(self.btn_open_outfits)
        v.addLayout(head)

        sub = QLabel("搜正版 ID 就能拿到他的皮肤和披风；中文名会去国内皮肤站 LittleSkin 查。"
                     "内置了国际热门主播，点一下格子直接选。")
        sub.setObjectName("FieldLabel")
        sub.setWordWrap(True)
        v.addWidget(sub)

        # 搜索行
        row = QHBoxLayout()
        self.input_search = QLineEdit()
        self.input_search.setPlaceholderText("搜皮肤：主播名 / 正版 ID / 已下载的名字")
        self.input_search.returnPressed.connect(self._on_search)
        row.addWidget(self.input_search, 1)
        self.btn_search = QPushButton("搜索")
        self.btn_search.clicked.connect(self._on_search)
        row.addWidget(self.btn_search)
        self.combo_group = QComboBox()
        self.combo_group.addItem("精选", "__featured__")
        self.combo_group.addItem("全部", "")
        for g in skinlib.all_groups():
            self.combo_group.addItem(g, g)
        self.combo_group.currentIndexChanged.connect(lambda *_: self.refresh())
        row.addWidget(self.combo_group)

        self.combo_show = QComboBox()
        self.combo_show.addItem("全部外观", "")
        self.combo_show.addItem("只看皮肤", "skin")
        self.combo_show.addItem("只看披风", "cape")
        self.combo_show.currentIndexChanged.connect(lambda *_: self.refresh())
        row.addWidget(self.combo_show)
        self.btn_refresh = QPushButton("刷新热门")
        self.btn_refresh.clicked.connect(self._refresh_stars)
        row.addWidget(self.btn_refresh)
        v.addLayout(row)

        # 本机皮肤工具行：导入、文件夹、批量导出、只看收藏
        tools = QHBoxLayout()
        tools.setSpacing(8)
        self.btn_import = QPushButton("导入皮肤（png）")
        self.btn_import.clicked.connect(self._import_local)
        tools.addWidget(self.btn_import)
        self.btn_open_dir = QPushButton("皮肤文件夹")
        self.btn_open_dir.clicked.connect(self._open_skins_dir)
        tools.addWidget(self.btn_open_dir)
        self.btn_export = QPushButton("批量导出选中")
        self.btn_export.clicked.connect(self._export_selected)
        tools.addWidget(self.btn_export)
        self.chk_fav = QCheckBox("只看收藏")
        self.chk_fav.stateChanged.connect(lambda *_: self.refresh())
        tools.addWidget(self.chk_fav)
        tools.addStretch(1)
        tip_drop = QLabel("也能把 png 拖进来")
        tip_drop.setObjectName("FieldLabel")
        tools.addWidget(tip_drop)
        v.addLayout(tools)

        self.label_state = QLabel("")
        self.label_state.setObjectName("FieldLabel")
        self.label_state.setWordWrap(True)
        v.addWidget(self.label_state)

        # 主体：左网格 + 右详情
        body = QHBoxLayout()
        body.setSpacing(14)

        self.grid = QListWidget()
        self.grid.setViewMode(QListWidget.IconMode)
        self.grid.setIconSize(QSize(44, 88))
        self.grid.setGridSize(QSize(96, 132))
        self.grid.setResizeMode(QListWidget.Adjust)
        self.grid.setMovement(QListWidget.Static)
        self.grid.setSpacing(4)
        self.grid.setWordWrap(True)
        self.grid.setSelectionMode(QListWidget.ExtendedSelection)
        self.grid.currentItemChanged.connect(self._on_pick)
        body.addWidget(self.grid, 3)

        side = QVBoxLayout()
        side.setSpacing(10)

        card = QFrame()
        card.setObjectName("Card")
        cv = QVBoxLayout(card)
        cv.setContentsMargins(14, 14, 14, 14)
        cv.setSpacing(8)
        self.preview = QLabel()
        self.preview.setFixedHeight(150)
        self.preview.setAlignment(Qt.AlignCenter)
        cv.addWidget(self.preview)
        self.label_name = QLabel("还没选皮肤")
        self.label_name.setWordWrap(True)
        cv.addWidget(self.label_name)
        self.label_cape = QLabel("")
        self.label_cape.setObjectName("FieldLabel")
        self.label_cape.setWordWrap(True)
        cv.addWidget(self.label_cape)

        self.input_outfit_name = QLineEdit()
        self.input_outfit_name.setPlaceholderText("给这套穿搭起个名字")
        cv.addWidget(self.input_outfit_name)

        brow = QHBoxLayout()
        self.btn_fetch = QPushButton("拉取这个")
        self.btn_fetch.clicked.connect(self._fetch_selected)
        brow.addWidget(self.btn_fetch)
        self.btn_save_outfit = QPushButton("保存穿搭")
        self.btn_save_outfit.clicked.connect(self._save_outfit)
        brow.addWidget(self.btn_save_outfit)
        cv.addLayout(brow)
        self.btn_apply = QPushButton("应用到游戏")
        self.btn_apply.clicked.connect(self._apply_to_game)
        cv.addWidget(self.btn_apply)
        self.btn_fav = QPushButton("收藏这个")
        self.btn_fav.clicked.connect(self._toggle_fav)
        cv.addWidget(self.btn_fav)
        side.addWidget(card)

        side.addWidget(self._field_label("我的穿搭"))
        self.list_outfits = QListWidget()
        self.list_outfits.setIconSize(QSize(28, 56))
        self.list_outfits.setMinimumHeight(120)
        self.list_outfits.itemDoubleClicked.connect(self._on_outfit_double)
        side.addWidget(self.list_outfits, 1)

        orow = QHBoxLayout()
        self.btn_use_outfit = QPushButton("用这套")
        self.btn_use_outfit.clicked.connect(self._on_outfit_double)
        orow.addWidget(self.btn_use_outfit)
        self.btn_make_code = QPushButton("生成穿搭码")
        self.btn_make_code.clicked.connect(self._make_outfit_code)
        orow.addWidget(self.btn_make_code)
        self.btn_use_code = QPushButton("穿搭码导入")
        self.btn_use_code.clicked.connect(self._import_outfit_code)
        orow.addWidget(self.btn_use_code)
        side.addLayout(orow)

        wrap = QWidget()
        wrap.setLayout(side)
        wrap.setFixedWidth(280)
        body.addWidget(wrap)
        v.addLayout(body, 1)

        # 翻页行：格子太多时按页翻，别一次全堆进列表
        prow = QHBoxLayout()
        self.btn_prev = QPushButton("上一页")
        self.btn_prev.clicked.connect(lambda: self._turn_page(-1))
        prow.addWidget(self.btn_prev)
        self.label_page = QLabel("第 1 / 1 页")
        self.label_page.setObjectName("FieldLabel")
        self.label_page.setAlignment(Qt.AlignCenter)
        self.label_page.setMinimumWidth(140)
        prow.addWidget(self.label_page)
        self.btn_next = QPushButton("下一页")
        self.btn_next.clicked.connect(lambda: self._turn_page(1))
        prow.addWidget(self.btn_next)
        prow.addStretch(1)
        self.combo_page_size = QComboBox()
        for n in (30, 60, 120):
            self.combo_page_size.addItem("每页 %d 个" % n, n)
        self.combo_page_size.setCurrentIndex(1)
        self.combo_page_size.currentIndexChanged.connect(self._on_page_size)
        prow.addWidget(self.combo_page_size)
        b_first = QPushButton("回到第一页")
        b_first.clicked.connect(lambda: self._goto_page(0))
        prow.addWidget(b_first)
        v.addLayout(prow)

    def _turn_page(self, delta):
        self._goto_page(self._page + delta)

    def _goto_page(self, idx):
        total = max(1, int(getattr(self, "_page_total", 1)))
        idx = max(0, min(total - 1, int(idx)))
        if idx == self._page:
            self._sync_page_ui()
            return
        self._page = idx
        self.refresh()

    def _on_page_size(self, _i=None):
        try:
            self._page_size = max(10, int(self.combo_page_size.currentData() or 60))
        except Exception:
            self._page_size = 60
        self._page = 0
        self.refresh()

    def _sync_page_ui(self):
        total = max(1, int(getattr(self, "_page_total", 1)))
        cur = min(self._page, total - 1)
        self.label_page.setText("第 %d / %d 页" % (cur + 1, total))
        self.btn_prev.setEnabled(cur > 0)
        self.btn_next.setEnabled(cur < total - 1)

    def _field_label(self, text):
        lab = QLabel(text)
        lab.setObjectName("FieldLabel")
        lab.setWordWrap(True)
        return lab

    # ---------- 本地导入 / 批量导出 / 收藏
    def _open_skins_dir(self):
        try:
            from core import platform_utils
            platform_utils.open_path(skinlib.local_skins_dir())
        except Exception as e:
            self._log("打开皮肤文件夹失败：" + str(e))

    def _import_local(self):
        paths, _f = QFileDialog.getOpenFileNames(
            self, "选皮肤图片（可多选）", "", "皮肤图片 (*.png *.jpg *.jpeg)")
        if paths:
            self.import_paths(paths)

    def import_paths(self, paths):
        """批量导入；返回成功数量。"""
        ok, bad = 0, []
        for p in paths:
            p = str(p)
            if not p.lower().endswith((".png", ".jpg", ".jpeg")):
                bad.append(os.path.basename(p))
                continue
            try:
                skinlib.import_local(p)
                ok += 1
            except Exception as e:
                bad.append("%s（%s）" % (os.path.basename(p), e))
        self.refresh()
        msg = "导入 %d 张皮肤" % ok
        if bad:
            msg += "，%d 张没进来：%s" % (len(bad), "、".join(bad[:4]))
        self.label_state.setText(msg)
        self._log(msg)
        return ok

    def _export_selected(self):
        items = self.grid.selectedItems()
        if not items:
            QMessageBox.information(self, "先选皮肤",
                                    "在格子里点选要导出的皮肤（按住 Ctrl 可多选）。")
            return
        out, _f = QFileDialog.getSaveFileName(
            self, "导出皮肤", "OMC皮肤-%d.zip" % int(time.time()),
            "Zip 压缩包 (*.zip)")
        if not out:
            return
        n = 0
        try:
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                for it in items:
                    r = it.data(Qt.UserRole) or {}
                    sp, cp = r.get("skin") or "", r.get("cape") or ""
                    if sp and os.path.isfile(sp):
                        z.write(sp, "skins/" + os.path.basename(sp))
                        n += 1
                    if cp and os.path.isfile(cp):
                        z.write(cp, "capes/" + os.path.basename(cp))
                        n += 1
        except Exception as e:
            QMessageBox.warning(self, "导出失败", str(e))
            return
        QMessageBox.information(self, "导出好了",
                                "共 %d 个文件，已存到：\n%s" % (n, out))
        self._log("导出皮肤 %d 个文件 → %s" % (n, out))

    def _toggle_fav(self):
        name = (self._selected or {}).get("name") or ""
        if not name:
            QMessageBox.information(self, "先选一个", "点一个格子再收藏。")
            return
        now = skinlib.toggle_favorite(name)
        self.btn_fav.setText("取消收藏" if now else "收藏这个")
        self._log("%s %s" % ("已收藏" if now else "已取消收藏", name))
        self.refresh()

    def _sync_fav_btn(self):
        name = (self._selected or {}).get("name") or ""
        if hasattr(self, "btn_fav"):
            self.btn_fav.setText("取消收藏" if (name and skinlib.is_favorite(name))
                                 else "收藏这个")

    # ---------- 拖拽导入
    def dragEnterEvent(self, e):
        md = e.mimeData()
        if md.hasUrls():
            for u in md.urls():
                if u.toLocalFile().lower().endswith((".png", ".jpg", ".jpeg")):
                    e.acceptProposedAction()
                    return
        super().dragEnterEvent(e)

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            return
        super().dragMoveEvent(e)

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.toLocalFile()]
        if paths:
            self.import_paths(paths)
            e.acceptProposedAction()
            return
        super().dropEvent(e)

    # ---------- 列表刷新
    def _all_rows(self):
        """按当前筛选条件算出的全部行（不分页）。"""
        kw = self.input_search.text().strip()
        group = self.combo_group.currentData() or ""
        rows = skinlib.search(kw)
        if group == "__featured__":
            rows = [r for r in rows if r.get("featured")]
        elif group:
            rows = [r for r in rows if r.get("group") == group]
        show = self.combo_show.currentData() if hasattr(self, "combo_show") else ""
        if show == "cape":
            rows = [r for r in rows if r.get("cape")]
        elif show == "skin":
            rows = [r for r in rows if not r.get("cape")]
        # 已下载的排前面；收藏过的再往前挤一档
        order = {"已下载": 0, "本地导入": 1, "国际主播": 2, "HermitCraft": 3, "经典": 4}
        favs = {x.lower() for x in skinlib.load_favorites()}
        if hasattr(self, "chk_fav") and self.chk_fav.isChecked():
            rows = [r for r in rows if (r.get("name") or "").lower() in favs]
        rows.sort(key=lambda r: (0 if (r.get("name") or "").lower() in favs else 1,
                                 order.get(r.get("group"), 9),
                                 r.get("label") or ""))
        return rows

    def _rows(self):
        """当前页的行；筛选条件变了自动回到第一页。"""
        all_rows = self._all_rows()
        key = (self.input_search.text().strip(),
               self.combo_group.currentData() or "",
               self.combo_show.currentData() if hasattr(self, "combo_show") else "",
               bool(getattr(self, "chk_fav", None) and self.chk_fav.isChecked()))
        if key != self._row_key:
            self._row_key = key
            self._page = 0
        size = max(1, int(getattr(self, "_page_size", 60)))
        self._page_total = max(1, (len(all_rows) + size - 1) // size)
        if self._page > self._page_total - 1:
            self._page = self._page_total - 1
        self._page_rows_total = len(all_rows)
        start = self._page * size
        return all_rows[start:start + size]

    def refresh(self, reset_filter=False):
        if reset_filter:
            self.input_search.clear()
        rows = self._rows()
        self.grid.blockSignals(True)
        self.grid.clear()
        self.grid.blockSignals(False)
        # 图标合成很贵，分批填，先出前 36 个，剩下的排到事件循环后面补
        self._fill_gen = getattr(self, "_fill_gen", 0) + 1
        self._pending_rows = rows
        self._pending_pos = 0
        self._fill_batch(self._fill_gen)
        all_rows = skinlib.search("")
        done = len([r for r in all_rows if r.get("group") == "已下载"])
        self.label_state.setText(
            "共 %d 个格子（已下载 %d 个），当前筛出 %d 个，第 %d / %d 页。"
            "没下载的也会先显示样子（临时图，不占库）。"
            % (len(all_rows), done, getattr(self, "_page_rows_total", len(rows)),
               self._page + 1, max(1, self._page_total)))
        self._sync_page_ui()
        self._cleanup_previews()
        self._refresh_outfits()

    def _fill_batch(self, gen):
        if getattr(self, "_fill_gen", 0) != gen:
            return
        rows = getattr(self, "_pending_rows", [])
        pos = getattr(self, "_pending_pos", 0)
        if pos >= len(rows):
            return
        end = min(pos + 36, len(rows))
        self.grid.blockSignals(True)
        want_preview = []
        for r in rows[pos:end]:
            label = r.get("label") or r.get("name")
            item = QListWidgetItem()
            skin_path = r.get("skin") or ""
            if not skin_path:
                pp = skinlib.preview_path(r.get("name") or "")
                if pp and os.path.isfile(pp):
                    skin_path = pp
                else:
                    want_preview.append(r.get("name") or "")
            item.setIcon(grid_icon(skin_path, 3))
            tag = " +披风" if r.get("cape") else ""
            item.setText("%s%s" % (label, tag))
            item.setData(Qt.UserRole, dict(r))
            item.setToolTip("%s（%s）" % (label, r.get("group") or ""))
            self.grid.addItem(item)
        self.grid.blockSignals(False)
        self._pending_pos = end
        if want_preview:
            self._queue_previews(want_preview)
        if end < len(rows):
            QTimer.singleShot(0, lambda: self._fill_batch(gen))
        else:
            if rows and self.grid.currentRow() < 0:
                self.grid.setCurrentRow(0)

    # ---------- 未下载皮肤的临时预览
    def _queue_previews(self, names, limit=24):
        """格子填出来就顺手把缺的预览拉上，一次不超过 limit 个，剩下的排队。"""
        fresh = []
        for nm in names:
            if not nm or nm in self._previewing or nm in self._preview_failed:
                continue
            self._previewing.add(nm)
            fresh.append(nm)
        if not fresh:
            return
        self._preview_queue.extend(fresh)
        self._pump_previews(limit)

    def _pump_previews(self, limit=24):
        if self._preview_worker is not None:
            return
        if not self._preview_queue:
            return
        batch = self._preview_queue[:limit]
        del self._preview_queue[:len(batch)]
        w = SkinPreviewWorker(batch, workers=6, parent=self)
        w.one.connect(self._on_preview)
        w.finished_all.connect(self._on_preview_done)
        self._preview_worker = w
        w.start()

    def _on_preview(self, name, path):
        self._apply_row_preview(name, path)

    def _apply_row_preview(self, name, path):
        """只换这一格的图标；已经正式下载的格子不动。"""
        for i in range(self.grid.count()):
            it = self.grid.item(i)
            data = it.data(Qt.UserRole) or {}
            if (data.get("name") or "") != name:
                continue
            if data.get("skin"):
                return
            it.setIcon(grid_icon(path, 3))
            if (self._selected.get("name") or "") == name:
                self._on_pick(it, None)
            return

    def _on_preview_done(self, _hit):
        self._preview_worker = None
        for nm in list(self._previewing):
            pp = skinlib.preview_path(nm)
            if not (pp and os.path.isfile(pp)):
                self._preview_failed.add(nm)
            self._previewing.discard(nm)
        if self._preview_queue:
            QTimer.singleShot(60, lambda: self._pump_previews())

    def _cleanup_previews(self):
        """当前列表里不再出现的临时预览直接删掉（下载过的本来就已经转正）。"""
        rows = getattr(self, "_pending_rows", []) or []
        keep = [r.get("name") or "" for r in rows if not r.get("skin")]
        keep.extend(self._preview_queue)
        keep.extend(self._previewing)
        try:
            skinlib.clear_previews(keep)
        except Exception:
            pass

    def _refresh_outfits(self):
        self.list_outfits.clear()
        for o in skinlib.list_outfits():
            item = QListWidgetItem()
            pix = skin_front_pixmap(o["skin"], 2) if o.get("skin") else QPixmap()
            item.setIcon(QIcon(pix if not pix.isNull() else _blank_pix(32)))
            item.setText(o["name"] + ("  +披风" if o.get("cape") else ""))
            item.setData(Qt.UserRole, o)
            self.list_outfits.addItem(item)
        if not self.list_outfits.count():
            item = QListWidgetItem("还没有保存过穿搭")
            item.setFlags(Qt.NoItemFlags)
            self.list_outfits.addItem(item)

    # ---------- 选中
    def _on_pick(self, cur, _prev=None):
        if not cur:
            return
        data = cur.data(Qt.UserRole) or {}
        if not data:
            return
        self._selected = dict(data)
        self._selected.setdefault("label", data.get("name"))
        self._sync_fav_btn()
        self.label_name.setText(data.get("label") or data.get("name") or "")
        skin = data.get("skin") or ""
        if not skin:
            pp = skinlib.preview_path(data.get("name") or "")
            if pp and os.path.isfile(pp):
                skin = pp
        if skin:
            pix = skin_front_pixmap(skin, 5)
            if not pix.isNull():
                self.preview.setPixmap(pix.scaled(
                    pix.width(), pix.height(), Qt.KeepAspectRatio, Qt.FastTransformation))
        else:
            self.preview.setPixmap(_blank_pix(120))
        self.label_cape.setText(
            "有披风，会一起装上" if data.get("cape")
            else ("只有皮肤（这个玩家没设披风，或者还没拉下来）"
                  if data.get("skin") else
                  ("这是临时预览图，点「拉取这个」或直接保存才会存进库里"
                   if skin else "还没下载，点「拉取这个」或直接保存试试")))

    def _fetch_selected(self):
        """把当前选中的名字（正版 ID）拉到本地。"""
        name = self._selected.get("name") or ""
        if not name:
            self.label_state.setText("先在格子里选一个名字")
            return
        if self._selected.get("skin"):
            self.label_state.setText("「%s」已经在本地了" % name)
            return
        self.label_state.setText("正在拉 %s 的皮肤..." % name)
        self._start_fetch([name], force=True)

    # ---------- 搜索 / 拉取
    def _on_search(self):
        kw = self.input_search.text().strip()
        if not kw:
            self.refresh()
            return
        self.refresh()
        hits = [r for r in self._rows() if r.get("skin")]
        if hits:
            self.label_state.setText("本地/内置里找到 %d 个，已经列出来了。" % len(hits))
            return
        # 本地没有 -> 当成名字去拉（先官方档案，再国内皮肤站）
        self.label_state.setText("本地没有「%s」，正在去官方档案 / 国内皮肤站拉..." % kw)
        self._start_fetch([kw])

    def _refresh_stars(self):
        need = [r["name"] for r in skinlib.search("")
                if r.get("group") in ("国际主播", "HermitCraft", "经典")
                and not r.get("skin")]
        if not need:
            self.label_state.setText("热门主播的皮肤都已经在库里了。")
            return
        self.label_state.setText(
            "正在补 %d 位主播的皮肤：5 路同时拉，谁先回来先显示，不用等齐。" % len(need))
        self._start_fetch(need[:60], workers=5)

    def _auto_fill_featured(self):
        """首次打开时静默补一批精选，省得用户还得手动点「刷新热门」。"""
        if self._worker is not None and self._worker.isRunning():
            return
        need = [r["name"] for r in skinlib.search("")
                if r.get("featured") and not r.get("skin")]
        if not need:
            return
        self.label_state.setText(
            "后台在补 %d 个精选皮肤（5 路并发），先点哪个都能看。" % len(need[:20]))
        self._start_fetch(need[:20], workers=5)

    def _start_fetch(self, names, force=False, workers=5):
        if not names:
            return
        if self._worker is not None and self._worker.isRunning():
            self.label_state.setText("上一次还在拉，等它结束再来。")
            return
        w = SkinFetchWorker(names, force=force, workers=workers)
        w.one.connect(self._on_fetched)
        w.log.connect(self._log)
        w.finished_all.connect(self._on_fetch_done)
        self._worker = w
        self.btn_search.setEnabled(False)
        self.btn_refresh.setEnabled(False)
        w.start()

    def _on_fetched(self, name, skin, cape):
        self._log("皮肤入库：%s" % name)
        rec = getattr(self, "_code_rec", None)
        if rec and (rec.get("name") or "") == name and skin:
            self._code_rec = None
            ok, msg = skinlib.save_outfit(
                rec.get("label") or name, skin,
                cape if (rec.get("cape_name") and cape) else "",
                source="穿搭码")
            self._log(msg)
            self.label_state.setText(msg)
            self._refresh_outfits()
        # 只换这一格的图标，不整表重建（整表重建才是刷热门卡的主因）
        self._apply_row_skin(name, skin, cape)

    def _apply_row_skin(self, name, skin, cape):
        if not name:
            return
        # 正式下载好了，临时预览就可以删了
        try:
            skinlib.drop_preview(name)
        except Exception:
            pass
        self._previewing.discard(name)
        for i in range(self.grid.count()):
            it = self.grid.item(i)
            data = it.data(Qt.UserRole) or {}
            if (data.get("name") or "") != name:
                continue
            data = dict(data)
            data["skin"] = skin
            data["cape"] = cape
            it.setData(Qt.UserRole, data)
            it.setIcon(grid_icon(skin or "", 3))
            label = data.get("label") or data.get("name") or name
            it.setText("%s%s" % (label, " +披风" if cape else ""))
            if (self._selected.get("name") or "") == name:
                self._selected = dict(data)
                self._on_pick(it, None)
            break

    def _on_fetch_done(self, ok):
        self.btn_search.setEnabled(True)
        self.btn_refresh.setEnabled(True)
        self.label_state.setText("这次拉到了 %d 个皮肤。" % ok if ok else
                                 "这次一个都没拉到，网络不太行，过一会儿再试。")
        self._worker = None
        self.refresh()

    # ---------- 穿搭码
    def _make_outfit_code(self):
        cur = self._selected.get("skin") or ""
        if not cur:
            item = self.list_outfits.currentItem()
            data = item.data(Qt.UserRole) if item else None
            if not data:
                self.label_state.setText("先选一个皮肤，或在下面点选一套穿搭")
                return
            cur = data.get("skin") or ""
            name = os.path.basename(os.path.dirname(cur)) if cur else ""
            cape = data.get("cape") or ""
            label = data.get("name") or name
        else:
            name = self._selected.get("name") or ""
            cape = self._selected.get("cape") or ""
            label = self._selected.get("label") or name
        if not name:
            self.label_state.setText("这个皮肤没有名字，换一个已入库的皮肤再生成")
            return
        try:
            code = outfitcode.encode({
                "name": name,
                "label": label,
                "cape_name": os.path.basename(os.path.dirname(cape)) if cape else "",
                "group": self._selected.get("group") or "",
            })
        except Exception as e:
            self.label_state.setText("生成失败：%s" % e)
            return
        QApplication.clipboard().setText(code)
        dlg = QMessageBox(self)
        dlg.setWindowTitle("穿搭码（已复制）")
        dlg.setText("把这段发给别人，他点「穿搭码导入」粘进去就能用：")
        dlg.setDetailedText(code)
        dlg.exec()
        self.label_state.setText("穿搭码已复制到剪贴板")

    def _import_outfit_code(self):
        text, ok = QInputDialog.getMultiLineText(
            self, "穿搭码导入", "把别人给的穿搭码粘进来：")
        if not ok or not (text or "").strip():
            return
        try:
            rec = outfitcode.decode(text)
        except Exception as e:
            QMessageBox.warning(self, "穿搭码有问题", str(e))
            return
        name = rec["name"]
        skin = skinlib.item_path(name, "skin")
        cape = skinlib.item_path(name, "cape")
        if os.path.isfile(skin):
            ok2, msg = skinlib.save_outfit(
                rec.get("label") or name, skin,
                cape if (rec.get("cape_name") and os.path.isfile(cape)) else "",
                source="穿搭码")
            self._log(msg)
            self.label_state.setText(msg)
            if ok2:
                self._refresh_outfits()
            return
        # 本地没有这张皮肤：按名字联网拉，拉到后自动存成穿搭
        self._code_rec = rec
        self.label_state.setText("本地没有「%s」，正在按名字拉取......" % name)
        self._start_fetch([name])

    # ---------- 穿搭
    def _save_outfit(self):
        if not self._selected.get("skin"):
            self._log("先在格子里选一个下载好的皮肤")
            return
        name = self.input_outfit_name.text().strip()
        ok, msg = skinlib.save_outfit(name, self._selected.get("skin"),
                                      self._selected.get("cape") or "",
                                      source=self._selected.get("group") or "")
        self._log(msg)
        self.label_state.setText(msg)
        if ok:
            self.input_outfit_name.clear()
            self._refresh_outfits()

    def _current_outfit(self):
        item = self.list_outfits.currentItem()
        if not item:
            return None
        return item.data(Qt.UserRole)

    def _on_outfit_double(self, *_a):
        o = self._current_outfit()
        if not o:
            return
        self._selected = {"name": o["name"], "label": o["name"],
                          "skin": o.get("skin") or "", "cape": o.get("cape") or "",
                          "group": "我的穿搭"}
        self.label_name.setText(o["name"])
        pix = skin_front_pixmap(o["skin"], 5) if o.get("skin") else QPixmap()
        self.preview.setPixmap(pix if not pix.isNull() else _blank_pix(120))
        self.label_cape.setText("这套有披风" if o.get("cape") else "这套只有皮肤")
        self.input_outfit_name.setText(o["name"])
        self._log("已选中穿搭：%s" % o["name"])

    def _open_outfits(self):
        skinlib.open_outfits_dir()

    # ---------- 应用到游戏
    def _apply_to_game(self):
        skin = self._selected.get("skin") or ""
        if not skin:
            self._log("先选一个皮肤（最好先下载到本地）")
            return
        game_dir = self.game_dir_getter() or ""
        version = self.version_getter() or ""
        player = self.username_getter() or "Player"
        if not game_dir:
            self._log("还没设置游戏目录")
            return
        try:
            res = skinapply.apply(game_dir, version, player, skin,
                                  self._selected.get("cape") or "",
                                  log=self._log)
        except Exception as e:
            self._log("应用皮肤失败：%s" % e)
            return
        for m in res.get("messages") or []:
            self._log(m)
        if res.get("need_mod"):
            self.label_state.setText(
                "皮肤已写进本地皮肤目录，但这个版本没装 CustomSkinLoader，"
                "游戏里不会显示——去「模组与资源」装一下 CustomSkinLoader 就行。")
        else:
            self.label_state.setText("皮肤已经应用到「%s」，下次启动游戏就是这套。" % version)
