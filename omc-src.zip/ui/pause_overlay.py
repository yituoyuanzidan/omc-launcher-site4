# -*- coding: utf-8 -*-
"""暂停图案：任何「能暂停」的画面区，暂停时正中显示一个大大的暂停符号。

不用 emoji、不依赖字体，直接 QPainter 画：半透明黑圆底 + 两条白竖杠。
放上去的控件设成不吃鼠标（WA_TransparentForMouseEvents），点画面照样能被打到。
"""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QWidget


class PauseOverlay(QWidget):
    def __init__(self, parent=None, size=88):
        super().__init__(parent)
        self._size = int(size)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setStyleSheet("background:transparent;")
        self.hide()

    def set_active(self, on):
        on = bool(on)
        if on:
            self.raise_()
            self.show()
        else:
            self.hide()

    def fit(self, size=None):
        """跟着父控件居中铺满。

        图案大小默认跟着画面区走：窗口化时 92px 正好，全屏（1920×1080）还是
        92px 就小得像没显示出来——用户报的「全屏时暂停按钮不见了」就是这个。
        现在按画面区短边的 16% 自适应，夹在 72~180 之间；显式传 size 时以传入
        值为准（自检脚本还在用）。
        """
        p = self.parentWidget()
        if p is None:
            return
        self.setGeometry(0, 0, p.width(), p.height())
        if size is None:
            short = min(p.width(), p.height())
            # 下限保持原来的 92px：窗口化时手感不变，只有全屏（短边 ≥ 720）
            # 才跟着放大，1080p 下 172px、1440p 封顶 180px。
            self._size = int(max(92, min(180, short * 0.16)))
        else:
            self._size = int(size)

    def paintEvent(self, ev):
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            w = self.width()
            h = self.height()
            cx = w / 2.0
            cy = h / 2.0
            r = max(24.0, min(float(self._size), min(w, h) / 2.0 - 6.0))
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 140))
            p.drawEllipse(QPointF(cx, cy), r, r)
            bw = r * 0.23
            bh = r * 0.86
            gap = r * 0.24
            p.setBrush(QColor(255, 255, 255, 240))
            p.drawRoundedRect(
                QRectF(cx - gap / 2.0 - bw, cy - bh / 2.0, bw, bh),
                bw / 2.6, bw / 2.6)
            p.drawRoundedRect(
                QRectF(cx + gap / 2.0, cy - bh / 2.0, bw, bh),
                bw / 2.6, bw / 2.6)
        finally:
            p.end()


class PauseHost(QWidget):
    """留一个现成的小壳子，方便把 overlay 挂上去。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.overlay = PauseOverlay(self)
        self._paused = False

    def set_paused(self, on):
        self._paused = bool(on)
        self.overlay.fit()
        self.overlay.set_active(self._paused)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.overlay.fit()
