# -*- coding: utf-8 -*-
"""主窗口：侧边导航 + 启动页 + 设置页 + 模组页。"""
import json
import hashlib
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import zipfile

from PySide6.QtCore import (Qt, QTimer, QUrl, Signal, QRect, QSize, QEvent,
                            QBuffer,
                            QObject)
from PySide6.QtGui import (QColor, QDesktopServices, QFont, QFontMetrics,
                           QIcon, QImage, QImageReader, QKeySequence, QPainter,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog,
    QFrame, QFormLayout,
    QHBoxLayout,
    QInputDialog, QKeySequenceEdit, QLabel, QLineEdit, QLayout, QMenu,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QSlider, QScrollArea, QSpinBox, QStackedWidget, QSystemTrayIcon, QTabWidget, QTextEdit,
    QStyle, QSizePolicy,
    QVBoxLayout, QWidget, QGridLayout,
    QMessageBox, QListWidget, QListWidgetItem,
)

from core import (auth, avguard, autostart, backup, bedrock, config, crashlog,
                  netease,
                  datapacks,
                  diagnose, export_pack, feedback, friendbook, frienddir,
                  game_options, i18n,
                  java_utils,
                  jvmargs, lan, lanroom, launcher, latest,
                  loaders,
                  memrec, autobackup, hotkeys, javaman, qr, logview,
                  themes, favorites,
                  modblock, modconflict, modrinth, mods, modtags, modupdate, verclone,
                  packs, platform_utils,
                  pubserver,
                  screenshots, servers,
                  shaderpacks, shortcut, skins, skinlib, seedmap, seedcalc, seedart,
                  structures, streaming, syscheck, update,
                  updater,
                  worlds,
                  yggdrasil)
from core.config import Config
from . import style as style_mod
from .skins_page import SkinLibraryPage
from .mod_dialogs import ModBlacklistDialog, ModTagDialog
from .friend_dialog import FriendEditDialog
from .update_progress import UpdateProgressDialog
from .restart_progress import RestartProgressDialog
from .trailer_card import TrailerCard
from .cat_pet import CatPet
from .workers import (AvWhitelistWorker, DeviceLoginWorker, ExportPackWorker,
                      FileDownloadWorker, ImportWorker,
                      InstallWorker,
                      JavaDownloadWorker,
                      LanDetectWorker, LoaderInstallWorker, LoaderVersionsWorker,
                      LoginWorker, ModrinthDownloadWorker, ModrinthIconWorker,
                      ModrinthSearchWorker, ModsWorker, ProjectVersionsWorker,
                      PublicStatusWorker,
                      RoomMetaWorker,
                      RoomStartWorker, ThirdLoginWorker, UpdateWorker,
                      FriendSearchWorker,
                      SeedStructWorker, SeedBiomeMapWorker,
                      VersionListWorker, WorldImportWorker, WorldMapWorker,
                      WorldUrlWorker,
                      UpdateDownloadWorker, LatestVersionWorker)


# 常见第三方 Yggdrasil 服务商，允许在可编辑下拉框里手填自建皮肤站地址
THIRD_SERVERS = [
    ("LittleSkin（国内 · 支持中文名）", "https://littleskin.cn/api/yggdrasil"),
    ("红石皮肤站 MCskin（国内）", "https://mcskin.cn/api/yggdrasil"),
    ("Ely.by（国际 · 皮肤披风齐全）", "https://account.ely.by/api/authlib-injector"),
    ("自建 Blessing Skin（自己填地址）", ""),
]

# 模组"类型"筛选：用的是 Modrinth 官方的 categories 值，中文只是显示名
MOD_CATEGORIES = [
    ("adventure", "冒险"),
    ("decoration", "装饰"),
    ("equipment", "装备"),
    ("food", "食物"),
    ("game-mechanics", "机制改动"),
    ("library", "前置库 / API"),
    ("magic", "魔法"),
    ("management", "管理工具"),
    ("minigame", "小游戏"),
    ("mobs", "生物"),
    ("optimization", "优化 / 帧数"),
    ("social", "社交"),
    ("storage", "存储"),
    ("technology", "科技"),
    ("transportation", "交通"),
    ("utility", "实用工具"),
    ("worldgen", "世界生成"),
    ("cursed", "整活 / 诅咒"),
]


def card(layout):
    frame = QFrame()
    frame.setObjectName("Card")
    frame.setLayout(layout)
    return frame


class DropZone(QFrame):
    """接受文件拖放的区域，用于拖入模组或整合包。"""

    filesDropped = Signal(list)

    NORMAL = ("QFrame#DropZone{border:2px dashed rgba(255,255,255,60);"
              "border-radius:14px;background:rgba(255,255,255,14);}")
    HOVER = ("QFrame#DropZone{border:2px dashed #4C8DFF;border-radius:14px;"
             "background:rgba(76,141,255,40);}")

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setObjectName("DropZone")
        self.setAcceptDrops(True)
        self.setMinimumHeight(150)
        self.setStyleSheet(self.NORMAL)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 16, 16, 16)
        self.label = QLabel(text)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setObjectName("FieldLabel")
        lay.addWidget(self.label)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setStyleSheet(self.HOVER)
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.setStyleSheet(self.NORMAL)

    def dropEvent(self, event):
        self.setStyleSheet(self.NORMAL)
        paths = []
        for url in event.mimeData().urls():
            if url.isLocalFile():
                paths.append(url.toLocalFile())
        if paths:
            event.acceptProposedAction()
            self.filesDropped.emit(paths)


class ClickableLabel(QLabel):
    """能点的图片（列表封面），点了进详情。"""

    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(e)


BG_DIM_ALPHA = 0   # 壁纸压暗强度：0 = 跟老版本一样亮，要暗一点就调大（0-255）


class Backdrop(QWidget):

    def __init__(self, parent):
        super().__init__(parent)
        self._pix = QPixmap()
        self._scaled = QPixmap()
        self._pil = None
        self._for = (0, 0)
        self._debounce = None
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.dim = BG_DIM_ALPHA          # 壁纸压暗强度，设置页可调
        self.lift = 0                    # 壁纸提亮强度（亮度滑块往左拉时生效）
        parent.installEventFilter(self)

    def eventFilter(self, obj, event):
        if obj is self.parent() and event.type() == QEvent.Resize:
            self.setGeometry(self.parent().rect())
            self._schedule_rebuild()
        return False

    def _schedule_rebuild(self):
        """拖动窗口时不要每帧都做高质量重采样，停顿一下再重建，避免卡顿。"""
        if self._debounce is None:
            self._debounce = QTimer(self)
            self._debounce.setSingleShot(True)
            self._debounce.timeout.connect(self._rebuild)
        self._debounce.start(260)

    def set_image(self, path):
        # 同一张图（且文件没被改写）就不用重新解码重采样
        try:
            mt = os.path.getmtime(path) if path and os.path.exists(path) else 0
        except OSError:
            mt = 0
        key = (path or "", mt)
        if getattr(self, "_key", None) == key and not self._pix.isNull():
            return
        self._key = key
        # 用字节读入再解码，避免中文路径让 QPixmap 加载失败
        pix = QPixmap()
        if path:
            try:
                with open(path, "rb") as f:
                    data = f.read()
                img = QImage()
                if img.loadFromData(data):
                    # 4K / 8K 壁纸没必要整张参与每次重采样，先降到 2560 以内
                    if img.width() > 2560 or img.height() > 2560:
                        img = img.scaled(2560, 2560, Qt.KeepAspectRatio,
                                         Qt.SmoothTransformation)
                    pix = QPixmap.fromImage(img)
                try:
                    # PIL 留着做高质量放大，比 Qt 的平滑缩放清晰得多
                    from PIL import Image
                    import io as _io
                    self._pil = Image.open(_io.BytesIO(data)).convert("RGB")
                except Exception:
                    self._pil = None
            except OSError:
                pix = QPixmap()
        else:
            self._pil = None
        self._pix = pix
        # 关键：换图必须先把上一张成品丢掉。窗口尺寸没变时 _rebuild 会走
        # 「尺寸只小改就复用上一张成品」的快捷分支，不清空就会一直画旧壁纸，
        # 表现就是「已经用了一张壁纸，再选别的没反应」。
        self._scaled = QPixmap()
        self._for = (0, 0)
        self._rebuild()
        self.update()

    def _rebuild(self):
        size = (self.width(), self.height())
        self._for = size
        if self._pix.isNull() or size[0] <= 0 or size[1] <= 0:
            self._scaled = QPixmap()
            return
        # 按屏幕缩放倍率生成物理像素尺寸的图，避免被系统放大后发糊
        dpr = self.devicePixelRatioF() or 1.0
        tw = max(1, int(round(size[0] * dpr)))
        th = max(1, int(round(size[1] * dpr)))

        # 源图偏小时用 PIL 的 Lanczos 放大 + 轻锐化，比 Qt 平滑缩放清楚
        if self._pil is not None:
            try:
                import io as _io
                from PIL import Image, ImageFilter

                # 尺寸只是小改（拖窗口一点点）时，别整张重采样，
                # 拿上一张成品再缩一次就够，快一个数量级。
                prev = self._scaled
                if (not prev.isNull()
                        and abs(prev.width() - tw) <= max(8, tw // 8)
                        and abs(prev.height() - th) <= max(8, th // 8)):
                    self._scaled = prev.scaled(
                        QSize(tw, th), Qt.KeepAspectRatioByExpanding,
                        Qt.SmoothTransformation)
                    return

                src = self._pil
                scale = max(tw / float(src.width), th / float(src.height))
                nw = max(1, int(round(src.width * scale)))
                nh = max(1, int(round(src.height * scale)))
                # Pillow 新版把 LANCZOS 挪到 Image.Resampling，老版本只有 Image.LANCZOS
                resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
                big = src.resize((nw, nh), resample)
                if scale >= 1.5:
                    big = big.filter(ImageFilter.UnsharpMask(
                        radius=1.4, percent=110, threshold=3))
                # 直接交给 Qt，别走 PNG 编码再解码（一张大图来回要几十毫秒）
                try:
                    from PIL import ImageQt
                    qimg = ImageQt.toqimage(big.convert("RGB"))
                    if not qimg.isNull():
                        self._scaled = QPixmap.fromImage(qimg)
                        return
                except Exception:
                    pass
                buf = _io.BytesIO()
                big.save(buf, format="PNG")
                qimg = QImage()
                if qimg.loadFromData(buf.getvalue()):
                    self._scaled = QPixmap.fromImage(qimg)
                    return
            except Exception:
                pass

        self._scaled = self._pix.scaled(
            QSize(tw, th), Qt.KeepAspectRatioByExpanding,
            Qt.SmoothTransformation)

    def paintEvent(self, event):
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return
        if self._pix.isNull():
            # 没壁纸时什么都不画：底下交给窗口自己的 #Root 深色底，
            # 半透明面板透出来的就是那层深色，不会露出空白。
            return
        if self._for != (w, h):
            # 尺寸变了：先用旧图快速铺满（不阻塞），稍后空闲时再精确重建
            self._schedule_rebuild()
            if self._scaled.isNull():
                return
            p = QPainter(self)
            p.setRenderHint(QPainter.SmoothPixmapTransform, True)
            p.drawPixmap(QRect(0, 0, w, h), self._scaled)
            self._paint_extra(p, w, h)
            return
        if self._scaled.isNull():
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        dpr = self.devicePixelRatioF() or 1.0
        sw, sh = int(w * dpr), int(h * dpr)
        sx = max(0, (self._scaled.width() - sw) // 2)
        sy = max(0, (self._scaled.height() - sh) // 2)
        p.drawPixmap(QRect(0, 0, w, h), self._scaled, QRect(sx, sy, sw, sh))
        # 壁纸保持原亮度（以前这里整张压暗 74，壁纸会暗一档，观感上像换了张图）
        self._paint_extra(p, w, h)

    def _paint_extra(self, p, w, h):
        """提亮 / 压暗都画在壁纸上面：提亮用加法叠白，压暗用半透明黑。"""
        lift = int(getattr(self, "lift", 0) or 0)
        if lift > 0:
            # 加法混合叠白 = 整体提亮，比重新生成一张图快得多，拖动滑块也跟手
            p.setCompositionMode(QPainter.CompositionMode_Plus)
            p.fillRect(QRect(0, 0, w, h), QColor(lift, lift, lift))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
        if self.dim:
            p.fillRect(QRect(0, 0, w, h), QColor(0, 0, 0, self.dim))


class MobileBridge(QObject):
    """手机控制台与界面之间的桥：状态由界面定时写入，指令用信号回主线程。"""
    launchRequested = Signal()
    rescanRequested = Signal()
    # 手机端通用操作：动作名 + 参数。HTTP 线程 emit 信号，Qt 自动排队到主线程。
    actionRequested = Signal(str, str)

    def __init__(self):
        super().__init__()
        self.state = {}
        # 手机端看截图要用它定位 screenshots 目录
        self.game_dir = ""
        # 手机端指令队列：HTTP 线程只往这里塞，主线程定时取走执行。
        # 以前靠跨线程 emit 信号，实测（_test_mobile2）手机点「启动游戏」
        # 电脑端一次都没被调用，界面看着就是「点了没反应」。
        self._lock = threading.Lock()
        self._pending = []

    def snapshot(self):
        """手机端 /api/state 读的就是它。"""
        return self.state or {}

    def push(self, name, arg=""):
        """HTTP 线程调用：只入队，不碰界面。"""
        try:
            with self._lock:
                self._pending.append((str(name), str(arg or "")))
                if len(self._pending) > 32:
                    del self._pending[:-32]
        except Exception:
            pass

    def take(self, limit=8):
        """主线程调用：一次取几条待执行的动作。"""
        with self._lock:
            out = self._pending[:limit]
            if out:
                del self._pending[:len(out)]
        return out

    def do_action(self, name, arg=""):
        """由 HTTP 线程调用：只把动作投递到主线程，不在这里碰界面。"""
        self.push(name, arg)
        return {"ok": True, "msg": "已发送到电脑"}


class _PassWheelScroll(QScrollArea):
    """滚轮交给里面的页面，滚动区自己不抢。

    视频页设计成「一屏一条、滚一下切下一条」，外面套普通 QScrollArea 会把滚轮
    吃进滚动条里，切条就失灵。所以这一层把滚轮事件原样丢给内部页面，
    滚动条仍可用鼠标拖。
    """

    def wheelEvent(self, e):
        inner = self.widget()
        if inner is None:
            return super().wheelEvent(e)
        e.ignore()
        QApplication.sendEvent(inner, e)


class MainWindow(QWidget):
    # 后台收信线程把结果投递到主线程（Qt 界面只能在主线程碰）
    sig_inbox = Signal(dict)

    def __init__(self, config=None):
        super().__init__()
        self.setObjectName("Root")
        self.sig_inbox.connect(self._inbox_added)
        self._title_base = i18n.tr("app_title")
        self.setWindowTitle(self._title_base)
        self._upd_title_last = ""
        # 记住「当前正套着的那份 QSS」，换主题时同样就不用再折腾一遍
        self._qss_now = None
        self._qss_pending = ""
        self._qss_timer = None
        self.resize(940, 620)
        self.setAcceptDrops(True)
        self._drop_overlay = None
        # 外面已经读过配置就复用，别再构造第二次（Config() 一次要 0.4 秒）
        self.config = config if config is not None else Config()
        try:
            self._qss_now = style_mod.qss(
                self.config.get("theme") or "dark",
                self.config.get("ui_accent") or "blue",
                self.config.get("ui_button") or "round")
        except Exception:
            self._qss_now = None
        self.version_data = []
        self.install_worker = None
        self.login_worker = None
        self._pending_kind = None
        self._pending_ver = None
        self._pending_name = None
        self._workers = []
        self.ms_account = auth.load_account()
        self.launch_proc = None
        self.launch_log_path = ""
        self.launch_t0 = 0.0
        self.launch_mark = 0
        self.launch_timer = QTimer(self)
        self.launch_timer.timeout.connect(self._launch_tick)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        # 关键：别让「内容的总尺寸」变成窗口的最小尺寸。
        # 默认 QLayout 会把 layout 的最小尺寸推给窗口（SetDefaultConstraint），
        # 内容一多最小尺寸就涨到 1335×942，比 1536×864 的屏幕还高 —— Windows
        # 只好把窗口顶到屏幕外（y=-26），用户看到的就是「界面上/下一截被挡住」，
        # 按 F11 也因为窗口没法再缩小而像「切不动」。放开这条约束后窗口能压到
        # 屏幕以内，内部靠各自的滚动区消化。
        root.setSizeConstraint(QLayout.SetNoConstraint)
        root.addWidget(self._build_sidebar())
        root.addWidget(self._build_content(), 1)
        self.setMinimumSize(880, 520)
        # 首屏尺寸也别超出屏幕可用区（小屏 / 缩放 125% 时很常见）
        QTimer.singleShot(0, self._clamp_window_to_screen)

        self._sync_account_ui()
        self._load_versions()
        # 快捷键必须跟着窗口一起来：以前挂在 _setup_mobile 里，
        # 那条链路要开端口、发请求，任何一个环节慢或抛异常，
        # 后面建的 QShortcut 就一条都没有，按 F11 自然没反应。
        self._hotkey_scs = []
        self._dlq_tasks = []
        self._apply_hotkeys()
        # 再兜一层全局按键过滤：个别控件（刚录过键的录入框、某些列表）会把按键
        # 直接吃掉，QShortcut 根本收不到，用户看到的就是「按 F11 没反应」。
        try:
            _app = QApplication.instance()
            if _app is not None:
                _app.installEventFilter(self)
        except Exception:
            pass
        # 手机控制台 / 更新检查这些要开端口、发网络请求，等窗口先出来再做，
        # 不然这几百毫秒全算在「点了图标到看见界面」的时间里。
        QTimer.singleShot(1, self._setup_mobile)
        # 启动后自动补齐 Java 路径（延迟执行，避免拖慢启动）
        QTimer.singleShot(1200, lambda: self._java_follow_version())

    # ---------- 手机连电脑：地址 + 二维码 ----------
    def _build_mobile_card(self):
        box = QVBoxLayout()
        box.setContentsMargins(22, 14, 22, 14)
        box.setSpacing(8)
        head = QHBoxLayout()
        head.setSpacing(8)
        head.addWidget(self._field_label("手机连电脑 · 扫码遥控"), 1)
        self.b_mobile_toggle = QPushButton("收起")
        self.b_mobile_toggle.setToolTip("不想占地方就先收起，随时能再打开")
        self.b_mobile_toggle.clicked.connect(self._toggle_mobile_card)
        head.addWidget(self.b_mobile_toggle)
        box.addLayout(head)

        self.mobile_body = QWidget()
        body = QVBoxLayout(self.mobile_body)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(9)
        tip = QLabel("手机和电脑连同一个 Wi-Fi，手机相机扫下面的码就能打开控制台——"
                     "不用装 App、不用输 IP。启动器要保持开着，"
                     "手机上能启动游戏、切版本、看截图和日志。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        body.addWidget(tip)

        row = QHBoxLayout()
        row.setSpacing(14)
        self.lab_mobile_qr = QLabel("生成中…")
        self.lab_mobile_qr.setFixedSize(120, 120)
        self.lab_mobile_qr.setAlignment(Qt.AlignCenter)
        self.lab_mobile_qr.setWordWrap(True)
        self.lab_mobile_qr.setStyleSheet(
            "background: rgba(255,255,255,10); border-radius: 10px;")
        row.addWidget(self.lab_mobile_qr)

        right = QVBoxLayout()
        right.setSpacing(7)
        # 电脑上有虚拟网卡（Docker / WSL / 热点）时，扫码可能连错网段，
        # 所以把本机所有地址列出来，扫不通就换一个。
        self.combo_mobile_addr = QComboBox()
        self.combo_mobile_addr.setToolTip("连不上就换一个地址再扫一次")
        self.combo_mobile_addr.currentIndexChanged.connect(
            self._refresh_mobile_card)
        right.addWidget(self.combo_mobile_addr)
        self.lab_mobile_url = QLabel("启动中…")
        self.lab_mobile_url.setObjectName("FieldLabel")
        self.lab_mobile_url.setWordWrap(True)
        self.lab_mobile_url.setTextInteractionFlags(Qt.TextSelectableByMouse)
        right.addWidget(self.lab_mobile_url)
        btns = QHBoxLayout()
        btns.setSpacing(6)
        b_copy = QPushButton("复制地址")
        b_copy.clicked.connect(self._copy_mobile_url)
        b_qr = QPushButton("刷新")
        b_qr.clicked.connect(self._refresh_mobile_card)
        b_now = QPushButton("电脑上打开")
        b_now.clicked.connect(self._open_mobile_url)
        b_help = QPushButton("连不上？")
        b_help.setToolTip("同 Wi-Fi、关掉 VPN、放行防火墙，还可以换个地址")
        b_help.clicked.connect(self._mobile_help)
        for b in (b_copy, b_qr, b_now, b_help):
            btns.addWidget(b)
        right.addLayout(btns)
        right.addStretch(1)
        row.addLayout(right, 1)
        body.addLayout(row)
        box.addWidget(self.mobile_body)
        return card(box)

    def _toggle_mobile_card(self, _=False):
        """展开 / 收起手机连电脑那一块。"""
        body = getattr(self, "mobile_body", None)
        btn = getattr(self, "b_mobile_toggle", None)
        if body is None or btn is None:
            return
        show = not body.isVisible()
        body.setVisible(show)
        btn.setText("收起" if show else "展开扫码")
        if show:
            self._refresh_mobile_card()

    def _mobile_addr_list(self):
        """本机所有能用的 http 地址，第一个是……主地址。"""
        url = getattr(getattr(self, "mobile_server", None), "url", "") or ""
        port = 0
        try:
            port = QUrl(url).port() or 0
        except Exception:
            port = 0
        if not port:
            port = 8899
        addrs = []
        try:
            from core import mobile_server as ms
            addrs = ["http://%s:%d/" % (ip, port) for ip in ms.lan_ips()]
        except Exception:
            addrs = []
        if url and url not in addrs:
            addrs.insert(0, url)
        if not addrs and url:
            addrs = [url]
        return addrs

    def _refresh_mobile_card(self, *_):
        lab = getattr(self, "lab_mobile_qr", None)
        url_lab = getattr(self, "lab_mobile_url", None)
        combo = getattr(self, "combo_mobile_addr", None)
        if lab is None or url_lab is None:
            return
        url = getattr(getattr(self, "mobile_server", None), "url", "") or ""
        if not url:
            url_lab.setText("手机控制台没能启动（端口可能被占用了）。"
                            "关掉占用 8899 端口的程序，或重启启动器试试。")
            lab.setPixmap(QPixmap())
            lab.setText("没有地址")
            return
        # 地址下拉：按网段优先级排，第一个就是路由最容易连上的
        addrs = self._mobile_addr_list()
        if combo is not None:
            combo.blockSignals(True)
            combo.clear()
            for a in addrs:
                combo.addItem(a, a)
            idx = combo.findData(url)
            combo.setCurrentIndex(idx if idx >= 0 else 0)
            combo.blockSignals(False)
        cur = url
        if combo is not None and combo.count():
            cur = combo.currentData() or url
        url_lab.setText("%s\n（第 %d 个地址，共 %d 个）"
                        % (cur, addrs.index(cur) + 1 if cur in addrs else 1,
                           len(addrs)) if len(addrs) > 1 else cur)
        try:
            data = qr.png_bytes_sized(cur, 150)
        except Exception:
            data = None
        if not data:
            lab.setText("二维码生成失败\n请在手机上手动输入地址")
            return
        pix = QPixmap()
        pix.loadFromData(data)
        if pix.isNull():
            lab.setText("二维码生成失败\n请在手机上手动输入地址")
        else:
            lab.setPixmap(pix)

    def _mobile_help(self):
        QMessageBox.information(
            self, "手机连不上怎么办",
            "1. 确认手机和电脑连的是同一个 Wi-Fi（不是手机流量，也不是访客网络）。\n"
            "2. 关掉手机和电脑上的 VPN / 加速器，它们会把局域网地址挡掉。\n"
            "3. Windows 弹出防火墙询问时选「允许访问」，或者在设置里允许专用网络。\n"
            "4. 地址下拉里换一个地址再扫一次——电脑有 Docker / WSL / 热点时会有好几个网段。\n"
            "5. 还不行就用数据线连电脑，手机开「USB 网络共享」，再从下拉里选那个新地址。\n\n"
            "想在手机上流畅玩：这个控制台只是遥控器，游戏跑在电脑上。"
            "要手机里有画面，得用串流——电脑装 Sunshine，手机装 Moonlight，"
            "连同一个 Wi-Fi 就能把电脑画面投到手机上玩。")

    def _mobile_url(self):
        combo = getattr(self, "combo_mobile_addr", None)
        if combo is not None and combo.count():
            return combo.currentData() or combo.currentText() or ""
        return getattr(getattr(self, "mobile_server", None), "url", "") or ""

    def _copy_mobile_url(self, *_):
        url = self._mobile_url()
        if not url:
            self._refresh_mobile_card()
            return
        try:
            QApplication.clipboard().setText(url)
            self._log("已复制手机控制台地址：" + url)
        except Exception:
            pass

    def _open_mobile_url(self, *_):
        url = self._mobile_url()
        if url:
            QDesktopServices.openUrl(QUrl(url))

    # ---------- 手机控制台（同一 Wi-Fi 用手机浏览器操作） ----------
    def _setup_mobile(self):
        self.mobile_bridge = MobileBridge()
        # 手机端指令统一走队列（主线程定时取），不再依赖跨线程信号：
        # 实测那种写法在真机上收不到，手机点启动电脑端毫无反应。
        self.mobile_server = None
        try:
            from core import mobile_server
            self.mobile_server = mobile_server.MobileServer(self.mobile_bridge)
            url = self.mobile_server.start()
            if url:
                self._log(i18n.tr("mobile_ready") + url)
            else:
                self._log(i18n.tr("mobile_failed"))
        except Exception as e:
            self._log(i18n.tr("mobile_failed") + str(e))
        self.mobile_action_timer = QTimer(self)
        self.mobile_action_timer.timeout.connect(self._drain_mobile_actions)
        self.mobile_action_timer.start(120)
        self.mobile_timer = QTimer(self)
        self.mobile_timer.timeout.connect(self._publish_mobile_state)
        self.mobile_timer.start(2500)
        self._publish_mobile_state()
        self._refresh_mobile_card()
        # 启动完成过几秒，让小猫自己冒一句话（相当于开机小贴士）
        QTimer.singleShot(6500, self._cat_startup_tip)
        # 存档定时自动备份（配置里没开就是空操作）
        self._start_autobackup()
        QTimer.singleShot(3000, self._refresh_mobile_diag)
        # 全局快捷键要注册热键并跑消息循环，等界面彻底出来再开
        QTimer.singleShot(1500, self._setup_global_hotkeys)

        # 启动后自动查一次更新（后台线程，失败只写日志）
        self.update_timer = QTimer(self)
        self.update_timer.setSingleShot(True)
        self.update_timer.timeout.connect(lambda: self._check_update(True))
        self.update_timer.start(3000)
        # 配置兜底落盘：界面上不少地方改了 set 却没 save()，以前重启/更新后
        # 用户会看到「设置被重置」。config.set 会记成 dirty，这里两秒一次把它补上。
        self._cfg_flush = QTimer(self)
        self._cfg_flush.timeout.connect(self._flush_config)
        self._cfg_flush.start(2000)
        # 长时间开着也不会错过更新：每两小时再查一次
        self.update_repeat = QTimer(self)
        self.update_repeat.timeout.connect(lambda: self._check_update(True))
        self.update_repeat.start(2 * 3600 * 1000)
        # 首次运行问一次要不要加杀毒白名单（只问一次，选过就不再问）
        QTimer.singleShot(5000, self._maybe_ask_av)
        # F11 全屏那三条快捷键在窗口构造时就建好了，这里不用再建一遍
        # 上次是「退出后替换」的更新，这次启动把替换结果写进日志
        self._report_last_update()
        # 一封都没收到过（全新安装）就补一封当前版本的更新内容
        self._bootstrap_mail()
        # 勾了记住密码的账号，这次启动直接登进去
        self._auto_login_account()

    def _bootstrap_mail(self):
        try:
            from core import mailbox
            if mailbox.load("update"):
                self._update_mail_badge()
                return
            ok, mail = mailbox.update_mail(update.VERSION, "")
            if ok:
                self._log("邮件里已放入「%s」" % (mail.get("subject") or "更新内容"))
            self._update_mail_badge()
        except Exception as e:
            self._log("初始化邮件失败：%s" % e)

    def _update_mail_badge(self):
        try:
            page = getattr(self, "mail_page", None)
            n = page.badge() if page is not None else 0
            self.btn_mail.setText(("邮件 · %d" % n) if n else "邮件")
        except Exception:
            pass

    def _update_friend_badge(self):
        """左栏「好友」上挂未读数，跟邮件一个样：不用先点进去就知道有几条。

        免打扰的会话不算在内（跟右下角弹不弹是同一套判定），进了好友页就清零。
        """
        from core import chat as _chat
        from core import notifyprefs as _np
        if not hasattr(self, "_unread"):
            self._unread = {}
        gids = set()
        try:
            gids = set((g.get("id") or "") for g in _chat.group_list())
        except Exception:
            pass
        n = 0
        for k, c in (self._unread or {}).items():
            is_group = k in gids
            try:
                alert = bool(_np.should_alert(
                    gid=k if is_group else None,
                    name=None if is_group else k)[0])
            except Exception:
                alert = True
            if alert:
                n += int(c or 0)
        b = getattr(self, "btn_friends", None)
        if b is not None:
            b.setText(("好友 · %d" % n) if n else "好友")
            b.setToolTip(("%d 条未读消息（免打扰的不算）" % n) if n else "")


    def _send_update_mail(self, version, took=""):
        """更新完成后写一封「更新内容」；配了 SMTP 就顺带发到邮箱。"""
        try:
            from core import mailbox
            ok, mail = mailbox.update_mail(version, took)
            if ok:
                self._log("收到一封「更新内容」邮件：%s" % (mail.get("subject") or ""))
            smtp = self.config.get("smtp") or {}
            if ok and smtp and (smtp.get("host") or "").strip():
                sent, why = mailbox.smtp_send(smtp, mail.get("subject") or "",
                                              mail.get("body") or "")
                if sent:
                    self._log("上一封更新邮件已发到 %s" % (smtp.get("to") or ""))
                else:
                    self._log("更新邮件没发到邮箱：%s" % why)
            self._update_mail_badge()
        except Exception as e:
            self._log("写更新邮件失败：%s" % e)

    def _report_last_update(self):
        """读替换脚本留下的进度/耗时，确认「上次更新真的换上了」。"""
        d = updater.install_dir()
        if not d:
            return
        # 替换脚本判定「没换上」会留一个标记：这种情况下绝不能当成更新成功，
        # 否则用户下次启动还是旧版本、又被提示更新一遍，看起来就是无限更新。
        failed = ""
        try:
            failed = updater.read_fail_flag(d)
        except Exception:
            failed = ""
        # 上次排替换前记下的目标版本，和现在的实际版本对不上，就说明那次
        # 更新根本没换上（包是旧的 / 文件被占用），别再当成功处理。
        try:
            pending = updater.read_pending(d)
        except Exception:
            pending = ""
        if pending:
            if update.is_newer(pending, update.VERSION):
                failed = failed or ("目标 %s，现在仍是 %s"
                                    % (pending, update.VERSION))
            updater.clear_pending(d)
        if failed:
            self._log("上次自动更新没换成功：%s（当前版本 %s）"
                      % (failed, update.VERSION))
            # 本次运行里别再自动下整包了：包一样、占用一样，下第二遍也是白下
            # 两百多兆。让用户先按提示手动换，或者关掉多余实例再试。
            self._upd_just_failed = True
            for name in ("omc_update_progress.txt", "update_timing.txt"):
                try:
                    os.remove(os.path.join(d, name))
                except OSError:
                    pass
            QTimer.singleShot(1200, lambda: self._notice_update_failed(failed))
            return
        prog = os.path.join(d, "omc_update_progress.txt")
        timing = os.path.join(d, "update_timing.txt")
        try:
            # PS 5.1 的 Out-File -Encoding utf8 带 BOM，按 utf-8-sig 读才不会
            # 让 BOM 粘在第一个字符上（否则 startswith("took=") 永远不成立）
            with open(prog, encoding="utf-8-sig") as f:
                line = f.read().strip()
        except Exception:
            return
        if not line.endswith("|100"):
            return
        took = ""
        try:
            with open(timing, encoding="utf-8-sig") as f:
                raw = f.read().strip()
            if raw.startswith("took="):
                took = raw[5:]
        except Exception:
            pass
        self._log("上次更新已替换完成%s，当前版本 %s"
                  % (("，替换用时 %s 秒" % took) if took else "",
                     update.VERSION))
        # 每次真正换上去了，就往邮件里发一封「更新内容」
        self._send_update_mail(update.VERSION, took)
        for p in (prog, timing):
            try:
                os.remove(p)
            except OSError:
                pass

    def _notice_update_failed(self, info):
        """上次替换没换上：明说一句并给手动下载入口，不能静默重来一遍。"""
        try:
            box = QMessageBox(self)
            box.setWindowTitle("自动更新没有完成")
            box.setText("上次自动更新没把新版本换上去。")
            box.setInformativeText(
                "现在还是 %s（%s）。再自动更新一次可能还是同样结果，"
                "直接去下载页拿一个完整包解压覆盖最稳。"
                % (update.VERSION, info))
            b_site = box.addButton("打开下载页", QMessageBox.AcceptRole)
            box.addButton("知道了", QMessageBox.RejectRole)
            box.exec_()
            if box.clickedButton() is b_site:
                QDesktopServices.openUrl(QUrl(update.DEFAULT_SOURCE))
        except Exception:
            pass

    def _apply_hotkeys(self):
        """按配置重建快捷键（全屏、皮肤库、刷新房间）。"""
        for sc in getattr(self, "_hotkey_scs", []) or []:
            try:
                sc.setEnabled(False)
                sc.deleteLater()
            except RuntimeError:
                pass
        hk = self.config.get("hotkeys") or {}
        pairs = (
            (hk.get("fullscreen") or "F11", self._toggle_fullscreen),
            (hk.get("skin") or "Ctrl+Shift+K", self._goto_skins_page),
            (hk.get("refresh") or "F5", self._rescan_lan_rooms),
            # 音乐全局快捷键：在别的页面、游戏窗口前面一样能按
            (hk.get("music_play") or "Ctrl+Alt+M", self._music_toggle),
            (hk.get("music_next") or "Ctrl+Alt+N", self._music_next),
            (hk.get("music_prev") or "Ctrl+Alt+B", self._music_prev),
        )
        self._hotkey_scs = []
        for seq, slot in pairs:
            try:
                sc = QShortcut(QKeySequence(seq), self)
                # 用 ApplicationShortcut：焦点落在列表、输入框、弹窗里也照样触发，
                # 不然子控件吃掉按键，用户看到的就是「按了没反应」。
                sc.setContext(Qt.ApplicationShortcut)
                sc.activated.connect(slot)
                self._hotkey_scs.append(sc)
            except Exception as e:
                # 以前这里静默 continue，出问题完全看不见
                self._log("快捷键 %s 没绑上：%s" % (seq, e))
                continue
        names = "、".join(sc.key().toString() for sc in self._hotkey_scs)
        try:
            first = self._hotkey_scs[0]
            self._fs_seq = first.key().toString()
        except Exception:
            self._fs_seq = "F11"
        if names:
            self._log("快捷键已就绪：" + names)

    def _save_hotkeys(self):
        val = {
            "fullscreen": self.hk_full.keySequence().toString() or "F11",
            "skin": self.hk_skin.keySequence().toString() or "Ctrl+Shift+K",
            "refresh": self.hk_refresh.keySequence().toString() or "F5",
            "music_play": self.hk_mplay.keySequence().toString() or "Ctrl+Alt+M",
            "music_next": self.hk_mnext.keySequence().toString() or "Ctrl+Alt+N",
            "music_prev": self.hk_mprev.keySequence().toString() or "Ctrl+Alt+B",
        }
        self.config.set("hotkeys", val)
        self.config.save()
        self._apply_hotkeys()
        self._log("快捷键已保存：全屏 %s / 皮肤库 %s / 刷新 %s / 音乐 %s、%s、%s"
                  % (val["fullscreen"], val["skin"], val["refresh"],
                     val["music_play"], val["music_next"], val["music_prev"]))

    def minimumSizeHint(self):
        """窗口能缩到多小：按我们给的 880×520，而不是内容算出来的那个。

        默认的 minimumSizeHint 由布局按内容累加，页面上控件一多就变成
        940×959（比 864 高的屏幕还高）。Windows 在移动/缩放窗口时不会让窗口
        小于它，于是窗口被顶到 y=-241、上下一截看不见 —— 这就是「全屏之后
        上面一部分被挡住」和「F11 切不回去」的根因。这里直接接管。
        """
        return QSize(880, 520)

    def _toggle_fullscreen(self):
        """全屏 / 窗口来回切（快捷键可改，默认 F11）。

        以前这里按时间防抖：两次按键间隔不到 0.4 秒就直接丢掉。按得稍快一点
        第二次就「没反应」，用户看到的就是「F11 切不回去」。防抖改成同一时刻
        只跑一次（下一拍就放开），按几下就切几下。
        """
        if getattr(self, "_fs_busy", False):
            return
        self._fs_busy = True
        QTimer.singleShot(240, self._fs_unbusy)
        try:
            if getattr(self, "_fs_on", False) or self.isFullScreen():
                self._leave_fullscreen()
            else:
                self._enter_fullscreen()
        except Exception as e:
            self._fs_on = False
            self._log("全屏切换失败：%s" % e)

    def _fs_unbusy(self):
        self._fs_busy = False

    def _clamp_window_to_screen(self):
        """窗口别比屏幕还大、也别跑到屏幕上边外去。

        小屏或 125% 缩放时，内容很容易把窗口撑到 1335×942 这种比屏幕还高的尺寸，
        Windows 只能把它往上挪，顶部就有一截永远看不见。
        """
        try:
            scr = self.screen() or QApplication.primaryScreen()
            if scr is None:
                return
            av = scr.availableGeometry()
            g = self.geometry()
            if (g.width() <= av.width() and g.height() <= av.height()
                    and g.top() >= av.top() - 1 and g.left() >= av.left() - 1
                    and g.right() <= av.right() + 1 and g.bottom() <= av.bottom() + 1):
                return
            w0 = min(g.width(), av.width())
            h0 = min(g.height(), av.height())
            self.resize(w0, h0)
            self.move(av.x() + max(0, (av.width() - w0) // 2),
                      av.y() + max(0, (av.height() - h0) // 2))
        except Exception as e:
            self._log("窗口尺寸校正失败：%s" % e)

    def _sync_idle_timers(self):
        """最小化时把纯界面的轮询停掉，还原再启。

        全局热键轮询和宠物计时器只在窗口看得见时才有意义；最小化还每秒跑，
        纯属白烧 CPU。技能/对局这类真业务的定时器不动，免得回来发现状态没跟上。
        """
        try:
            mini = self.isMinimized() or not self.isVisible()
        except Exception:
            return
        self._idle_paused = bool(mini)
        ht = getattr(self, "_hotkey_timer", None)
        try:
            if ht is not None:
                if mini:
                    if ht.isActive():
                        ht.stop()
                        self._hotkey_was_active = True
                elif getattr(self, "_hotkey_was_active", False):
                    ht.start(600)
                    self._hotkey_was_active = False
        except Exception:
            pass
        # 最小化 / 窗口被藏起来时，刷视频页要是还在播就彻底停掉：
        # 光靠 VideoPage 的 hideEvent 管不到主窗最小化（窗口最小化不会给子控件
        # 发 hideEvent），结果就是缩到任务栏去玩游戏了，视频声音还在响。
        if mini:
            try:
                vp = getattr(self, "video_page", None)
                if vp is not None:
                    st = 0
                    try:
                        st = getattr(vp._player.playbackState(), "value", 0)
                    except Exception:
                        st = 1 if getattr(vp, "_want_play", False) else 0
                    if st == 1 or getattr(vp, "_want_play", False):
                        vp.stop()
            except Exception:
                pass

    def changeEvent(self, event):
        """切到别的软件再切回来 / 最小化还原 / 换屏幕之后，把窗口拉回屏幕内。

        用户报「切换软件之后 UI 会超出屏幕」：Windows 在这种来回激活里会把窗口
        几何恢复成之前那套（可能是大屏时的尺寸），在 125% 缩放的笔记本上就跑到
        屏幕外，顶部/右侧永远看不见。这里只要窗口状态或激活态变了就校正一次。
        """
        try:
            t = event.type()
            if t == QEvent.WindowStateChange:
                self._sync_idle_timers()
            if t in (QEvent.WindowStateChange, QEvent.ActivationChange,
                     QEvent.Show):
                if not getattr(self, "_fs_on", False) and not self.isFullScreen():
                    QTimer.singleShot(0, self._clamp_window_to_screen)
                    QTimer.singleShot(180, self._clamp_window_to_screen)
        except Exception:
            pass
        super().changeEvent(event)

    def _screen_rect(self):
        scr = self.screen()
        if scr is None:
            scr = QApplication.primaryScreen()
        return scr.geometry() if scr is not None else None

    def _enter_fullscreen(self):
        """进全屏：无边框 + 正好铺满整块屏幕。

        不再用 showFullScreen()：这台机器上它调完 isFullScreen() 还是 False，
        窗口会被内容顶到 1536×925（比屏幕高 61px），顶部一截永远在屏幕外，
        F11 也判断不出方向。这里改成自己把 flags 和几何控制住，进出都确定。
        """
        self._fs_geom = self.geometry()
        self._fs_min = self.minimumSize()
        self._fs_max = self.maximumSize()
        self._fs_was_max = self.isMaximized()
        self._fs_flags = self.windowFlags()
        g = self._screen_rect()
        if g is None:
            return
        self._fs_on = True
        self._fs_pending = True
        try:
            # 上下限一起卡成屏幕尺寸：窗口既缩不小也长不大，layout 顶不动它。
            self.setMinimumSize(g.width(), g.height())
            self.setMaximumSize(g.width(), g.height())
            self.setWindowFlags(self._fs_flags | Qt.FramelessWindowHint)
            self.showNormal()
            self.setGeometry(g)
            self.show()
            self.raise_()
            self.activateWindow()
        except Exception as e:
            self._fs_on = False
            self._fs_pending = False
            self._log("进全屏失败：%s" % e)
            return
        QTimer.singleShot(140, self._ensure_fullscreen)
        self._log("已进入全屏（按 %s 退出）" % (getattr(self, "_fs_seq", "F11") or "F11"))

    def _leave_fullscreen(self):
        self._fs_pending = False
        self._fs_on = False
        g = self._screen_rect()
        target = getattr(self, "_fs_geom", None)
        try:
            if getattr(self, "_fs_flags", None) is not None:
                self.setWindowFlags(self._fs_flags)
            self.setMinimumSize(0, 0)
            self.setMaximumSize(16777215, 16777215)
            self.showNormal()
            if target is not None and g is not None:
                # 目标几何先收进屏幕里，免得出去以后又被顶到屏幕外
                w0 = min(target.width(), g.width())
                h0 = min(target.height(), g.height())
                x0 = max(g.left(), min(target.x(), g.right() - w0 + 1))
                y0 = max(g.top(), min(target.y(), g.bottom() - h0 + 1))
                target = QRect(x0, y0, w0, h0)
            if target is not None:
                # 先按目标尺寸把窗口钉住（上下限都设成这个尺寸），
                # 否则 layout 会立刻把它撑回 940×959，又被顶出屏幕。
                self.setMinimumSize(target.width(), target.height())
                self.setMaximumSize(target.width(), target.height())
                self.setGeometry(target)
            self.show()
            if getattr(self, "_fs_was_max", False):
                self.showMaximized()
            self.raise_()
            self.activateWindow()
        except Exception as e:
            self._log("退全屏失败：%s" % e)
        QTimer.singleShot(90, self._after_leave_fullscreen)
        self._log("已退出全屏")

    def _after_leave_fullscreen(self):
        """窗口出来之后再把固定尺寸放开，回到进全屏前那个大小，最后按屏幕裁一次。"""
        try:
            self.setMinimumSize(880, 520)
            mx = getattr(self, "_fs_max", None)
            if mx is not None:
                self.setMaximumSize(mx)
            else:
                self.setMaximumSize(16777215, 16777215)
        except Exception:
            pass
        geom = getattr(self, "_fs_geom", None)
        if geom is not None and not getattr(self, "_fs_was_max", False):
            try:
                # 还是回到原来的窗口大小，别留成「差不多满屏」那种别扭尺寸
                self.resize(geom.width(), geom.height())
                self.move(geom.x(), geom.y())
            except Exception:
                pass
        self._clamp_window_to_screen()

    def _ensure_fullscreen(self):
        """下一拍复查：还在全屏就把几何强行对齐屏幕。"""
        if not getattr(self, "_fs_pending", False):
            return
        g = self._screen_rect()
        if g is None:
            return
        try:
            cur = self.geometry()
            if cur != g:
                self.setMinimumSize(g.width(), g.height())
                self.setMaximumSize(g.width(), g.height())
                self.setGeometry(g)
            self.raise_()
            self.activateWindow()
        except Exception as e:
            self._log("补全屏失败：%s" % e)

    def _music_toggle(self):
        """Ctrl+Alt+M：播放 / 暂停当前那首。"""
        mp = getattr(self, "music_page", None)
        if mp is None:
            return
        try:
            mp._toggle()
            self._log("音乐：播放 / 暂停已切换（Ctrl+Alt+M）")
        except Exception as e:
            self._log("音乐快捷键没生效：%s" % e)

    def _music_next(self):
        mp = getattr(self, "music_page", None)
        if mp is None:
            return
        try:
            mp._jump(1)
        except Exception as e:
            self._log("音乐快捷键没生效：%s" % e)

    def _music_prev(self):
        mp = getattr(self, "music_page", None)
        if mp is None:
            return
        try:
            mp._jump(-1)
        except Exception as e:
            self._log("音乐快捷键没生效：%s" % e)

    def _fs_seq_hit(self, ev):
        key = ev.key()
        if ev.modifiers() == Qt.NoModifier and key == Qt.Key_F11:
            return True
        try:
            got = QKeySequence(ev.keyCombination()).toString()
            return bool(got) and got == (getattr(self, "_fs_seq", "") or "F11")
        except Exception:
            return False

    def eventFilter(self, obj, ev):
        """全局兜底：全屏键被某个控件吃掉时也能切。

        只吃 ShortcutOverride 这一种事件（量极小，不会拖慢界面）：
        有的控件会接受它把快捷键压掉，那 QShortcut 就永远收不到按键，
        表现就是「按 F11 一点反应都没有」。这里抢在控件前面认领。
        录入框正在录键位时放行，不然改键位都没法改。
        """
        try:
            if ev.type() == QEvent.ShortcutOverride and self._fs_seq_hit(ev):
                fw = QApplication.focusWidget()
                if isinstance(fw, QKeySequenceEdit):
                    return super().eventFilter(obj, ev)
                ev.accept()
                # 不在事件过滤器里改窗口状态，挪到下一拍
                QTimer.singleShot(0, self._toggle_fullscreen)
                return True
        except Exception:
            pass
        return super().eventFilter(obj, ev)

    def keyPressEvent(self, ev):
        """兜底交给 super：全屏键已由 eventFilter 认领 ShortcutOverride，
        这里再处理一次会与 overrideride 路径重复触发（一次按键切两下，
        净效果等于没反应）。"""
        super().keyPressEvent(ev)

    def _build_update_bar(self, parent_layout):
        """窗口底部常驻的更新进度：下载/校验/解压/替换都能看见。"""
        wrap = QWidget()
        wrap.setObjectName("UpdateBar")
        vb = QVBoxLayout(wrap)
        vb.setContentsMargins(0, 10, 0, 0)
        vb.setSpacing(3)
        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(10)
        self.upd_label = QLabel("")
        self.upd_label.setObjectName("FieldLabel")
        self.upd_sub = QLabel("")
        self.upd_sub.setObjectName("FieldLabel")
        head.addWidget(self.upd_label, 1)
        head.addWidget(self.upd_sub, 0)
        self.upd_bar = QProgressBar()
        self.upd_bar.setRange(0, 100)
        self.upd_bar.setValue(0)
        self.upd_bar.setTextVisible(True)
        self.upd_bar.setFormat("%p%")
        self.upd_bar.setFixedHeight(18)
        vb.addLayout(head)
        vb.addWidget(self.upd_bar)
        wrap.setVisible(False)
        self.upd_bar_wrap = wrap
        parent_layout.addWidget(wrap)

    def _show_update_bar(self, pct=None, text=None, sub=None, busy=False):
        """pct 是整体进度 0-100：下载占 0-80，校验 80-90，解压 90-100。"""
        w = getattr(self, "upd_bar_wrap", None)
        if w is None:
            return
        if text is not None:
            self.upd_label.setText(text)
        if sub is not None:
            self.upd_sub.setText(sub)
        if busy:
            self.upd_bar.setRange(0, 0)          # 不确定进度（连接 / 替换阶段）
        elif pct is not None:
            self.upd_bar.setRange(0, 100)
            self.upd_bar.setValue(max(0, min(100, int(pct))))
        w.setVisible(True)
        d = getattr(self, "_upd_dlg", None)
        if d is not None and d.isVisible():
            d.set_state(pct=pct, text=text, sub=sub, busy=busy)

    def _hide_update_bar(self):
        w = getattr(self, "upd_bar_wrap", None)
        if w is not None:
            w.setVisible(False)

    def _set_update_title(self, note=""):
        """把“正在下载/已就绪”写到窗口标题，用户不点检查更新也看得见进度。"""
        self._upd_title_last = note or ""
        base = getattr(self, "_title_base", None) or i18n.tr("app_title")
        try:
            self.setWindowTitle(base + ("　|　" + note if note else ""))
        except Exception:
            pass

    # ---------- 更新 ----------
    def _auto_update_enabled(self):
        """默认开着：只要联网就自动检查并下载新版本，设置里能关。"""
        val = self.config.get("auto_update")
        return True if val is None else bool(val)

    def _on_auto_update_toggled(self, on):
        self.config.set("auto_update", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        self._log("自动更新已" + ("打开" if on else "关闭"))

    def _check_update(self, silent=True):
        if silent and not self._auto_update_enabled():
            return
        url = ""
        if hasattr(self, "input_update_url"):
            url = self.input_update_url.text().strip()
        self._update_worker = self._track(UpdateWorker(url or None))
        self._update_worker.done.connect(
            lambda m: self._on_update_result(m, silent))
        self._update_worker.failed.connect(
            lambda e: self._on_update_failed(e, silent))
        self._update_worker.start()

    def _retry_update_check(self, silent):
        """启动时的自动检查失败了就再试几次，别让一次网络抖动把更新彻底错过。"""
        if not silent or not self._auto_update_enabled():
            return
        tries = getattr(self, "_upd_check_tries", 0) + 1
        self._upd_check_tries = tries
        if tries > 3:
            self._log("自动检查更新连续失败，本次不再重试")
            return
        delay = 30000 if tries == 1 else 120000
        self._log("自动检查更新失败，%d 秒后重试（第 %d 次）" % (delay // 1000, tries))
        QTimer.singleShot(delay, lambda: self._check_update(True))

    def _on_update_failed(self, msg, silent=True):
        if silent:
            self._log("检查更新失败：%s" % msg)
            self._retry_update_check(True)
            return
        QMessageBox.warning(self, i18n.tr("update_title"),
                            i18n.tr("update_fail", msg))

    def _on_update_result(self, manifest, silent=True):
        manifest = manifest or {}
        self._upd_check_tries = 0
        # 清单里若给了新清单地址，就切过去，保证以后能持续收到更新
        nxt = (manifest.get("next_source") or "").strip()
        if nxt and nxt.startswith("http") and \
                nxt != (self.config.get("update_url") or "").strip():
            self.config.set("update_url", nxt)
            try:
                self.config.save()
            except Exception:
                pass
            self._log("更新源已切换到新清单地址")
        latest = manifest.get("latest")
        if not update.is_newer(latest):
            self._set_update_title("")
            # 已经是最新版本：顺手把以前更新留下的临时包清掉
            try:
                updater.cleanup_workdirs()
            except Exception:
                pass
            if silent:
                self._log("版本已是最新：%s" % update.VERSION)
            else:
                QMessageBox.information(
                    self, i18n.tr("update_title"),
                    i18n.tr("update_none", update.VERSION))
            return
        pc_url = (manifest.get("pc_url") or "").strip()
        try:
            from core import mailbox
            ok, _m = mailbox.new_version_mail(latest, pc_url)
            if ok:
                self._log("邮件里收到一封「发现新版本 %s」" % latest)
            self._update_mail_badge()
        except Exception:
            pass
        # 自动模式：不弹窗，直接后台下载，下完再问要不要现在重启
        if silent and self._auto_update_enabled():
            if getattr(self, "_upd_just_failed", False):
                self._set_update_title(
                    "有新版本 %s，上次没换上，建议按提示手动下载" % latest)
                self._log("上次自动更新刚失败过，这次不自动重下 %s" % latest)
                return
            if not pc_url:
                self._log("发现新版本 %s，但清单里没有下载地址" % latest)
                return
            self._start_auto_update(latest, pc_url)
            return

        box = QMessageBox(self)
        box.setWindowTitle(i18n.tr("update_title"))
        box.setText(i18n.tr("update_found", latest, update.VERSION))
        notes = (manifest.get("notes") or "").strip()
        if notes:
            box.setInformativeText(notes)
        btn_auto = None
        if pc_url and updater.can_auto_update():
            btn_auto = box.addButton("自动更新", QMessageBox.AcceptRole)
        btn_pc = box.addButton(i18n.tr("update_pc"), QMessageBox.AcceptRole)
        btn_mob = None
        if manifest.get("mobile_url"):
            btn_mob = box.addButton(i18n.tr("update_mobile"),
                                    QMessageBox.AcceptRole)
        box.addButton(i18n.tr("cancel"), QMessageBox.RejectRole)
        box.exec_()
        clicked = box.clickedButton()
        if btn_auto is not None and clicked is btn_auto:
            self._start_auto_update(latest, pc_url)
        elif clicked is btn_pc and pc_url:
            QDesktopServices.openUrl(QUrl(pc_url))
        elif btn_mob is not None and clicked is btn_mob:
            QDesktopServices.openUrl(QUrl(manifest["mobile_url"]))

    def _start_auto_update(self, latest, url):
        if getattr(self, "_upd_running", False):
            return
        if not updater.can_auto_update():
            self._log("发现新版本 %s，但当前是源码运行，不能自动替换。下载地址：%s"
                      % (latest, url))
            return
        self._upd_running = True
        self._upd_latest = latest
        self._upd_t0 = None
        self._upd_stage = "下载"
        self._log("发现新版本 %s，开始自动下载......" % latest)
        self._set_update_title("正在下载新版本 %s" % latest)
        self._upd_last_pct = -1
        self._show_update_bar(pct=0,
                              text="正在连接下载新版本 %s ..." % latest,
                              sub="")
        try:
            self._upd_dlg = UpdateProgressDialog(latest, self)
            self._upd_dlg.show()
        except Exception:
            self._upd_dlg = None
        self._udw = self._track(UpdateDownloadWorker(url))
        self._udw.log.connect(self._log)
        self._udw.progress.connect(self._on_update_progress)
        self._udw.stage.connect(self._on_update_stage)
        self._udw.done.connect(self._on_update_pkg_done)
        self._udw.failed.connect(self._on_update_pkg_failed)
        self._udw.start()

    @staticmethod
    def _fmt_speed(bps):
        if bps >= 1048576:
            return "%.1f MB/s" % (bps / 1048576.0)
        if bps >= 1024:
            return "%.0f KB/s" % (bps / 1024.0)
        return "%.0f B/s" % bps

    @staticmethod
    def _fmt_eta(sec):
        if sec <= 0:
            return "马上就好"
        if sec < 60:
            return "还剩约 %d 秒" % sec
        return "还剩约 %d 分 %d 秒" % (sec // 60, sec % 60)

    def _on_update_progress(self, cur, total):
        """下载阶段：整体进度占 0-80，右侧显示速度和剩余时间。"""
        if not total or total <= 0:
            if cur:
                self._show_update_bar(busy=True,
                                      text="正在下载新版本 %s ..." % self._upd_latest)
            return
        now = time.monotonic()
        if getattr(self, "_upd_t0", None) is None:
            self._upd_t0 = now
        elapsed = max(0.05, now - self._upd_t0)
        speed = cur / elapsed
        eta = int((total - cur) / speed) if speed > 1 else 0
        pct_dl = int(cur * 100 / total)
        self._show_update_bar(
            pct=pct_dl * 0.8,
            text="正在下载新版本 %s · %.1f / %.1f MB"
                 % (self._upd_latest, cur / 1048576.0, total / 1048576.0),
            sub="%s · %s" % (self._fmt_speed(speed), self._fmt_eta(eta)))
        if pct_dl >= getattr(self, "_upd_last_pct", -1) + 10:
            self._upd_last_pct = pct_dl
            self._log("正在下载新版本：%d%%" % pct_dl)
            self._set_update_title("正在下载新版本 %s（%d%%）"
                                   % (self._upd_latest, pct_dl))

    def _on_update_stage(self, name, pct):
        """校验/解压阶段：接手进度条，别让界面停在下完 100% 假象上。"""
        pct = max(0, min(100, int(pct)))
        self._upd_stage = name
        d = getattr(self, "_upd_dlg", None)
        if d is not None and d.isVisible():
            d.set_state(text=None, stage=name)
        if name == "校验":
            overall = 80 + pct * 0.1
            self._show_update_bar(
                pct=overall,
                text="正在校验更新包（确认没下坏）",
                sub="%d%%" % pct)
            if pct >= 100:
                self._log("更新包校验通过")
        elif name == "解压":
            overall = 90 + pct * 0.1
            self._show_update_bar(
                pct=overall,
                text="正在解压新版本", sub="%d%%" % pct)
            if pct >= 100:
                self._log("更新包已解压完成")

    def _on_update_pkg_done(self, payload, work):
        self._upd_running = False
        self._upd_last_pct = -1
        # 先确认下回来的包真的是 latest：清单一旦被缓存成上一版，pc_url
        # 就还指着旧包，装上去版本不变、下次启动又提示更新（更新完还要更新）。
        try:
            ver_ok = updater.payload_has_version(payload, self._upd_latest)
        except Exception:
            ver_ok = True
        if not ver_ok:
            self._hide_update_bar()
            self._set_update_title("")
            dlg = getattr(self, "_upd_dlg", None)
            if dlg is not None:
                try:
                    dlg.hide()
                except Exception:
                    pass
                self._upd_dlg = None
            self._log("下载到的包不是 %s，已取消替换" % self._upd_latest)
            try:
                updater.cleanup_workdirs()
            except Exception:
                pass
            box = QMessageBox(self)
            box.setWindowTitle("自动更新")
            box.setText("下载回来的包不是 %s 版。" % self._upd_latest)
            box.setInformativeText(
                "更新清单可能读到了缓存里的旧内容。稍后再试一次更新，"
                "或者直接去下载页拿完整包。")
            b_site = box.addButton("打开下载页", QMessageBox.AcceptRole)
            box.addButton("知道了", QMessageBox.RejectRole)
            box.exec_()
            if box.clickedButton() is b_site:
                QDesktopServices.openUrl(QUrl(update.DEFAULT_SOURCE))
            return
        self._show_update_bar(pct=100,
                              text="新版本 %s 已准备好，可以重启换上了"
                              % self._upd_latest,
                              sub="")
        self._log("新版本 %s 已下载完成" % self._upd_latest)
        self._set_update_title("新版本 %s 已就绪" % self._upd_latest)
        d = getattr(self, "_upd_dlg", None)
        if d is not None:
            try:
                d.finish("新版本 %s 已经准备好" % self._upd_latest)
            except Exception:
                pass
        box = QMessageBox(self)
        box.setWindowTitle("自动更新")
        box.setText("新版本 %s 已经下载好，重启后自动换上。" % self._upd_latest)
        box.setInformativeText(
            "现在重启会立刻换上；选「关掉时自动换上」也可以，"
            "你下次关闭启动器时它自己替换并重新打开。")
        box.addButton("现在重启", QMessageBox.AcceptRole)
        b_later = box.addButton("关掉时自动换上", QMessageBox.AcceptRole)
        b_skip = box.addButton("这次算了", QMessageBox.RejectRole)
        box.exec_()
        clicked = box.clickedButton()
        if clicked is b_skip:
            self._log("已跳过本次更新，下次启动会重新检查")
            self._set_update_title("")
            self._hide_update_bar()
            return
        if clicked is b_later:
            # 先排好替换脚本，退出即替换；关掉程序就等于完成更新
            try:
                updater.schedule_update(payload, latest=self._upd_latest)
                self._log("已排好替换：关闭启动器后自动换上 %s" % self._upd_latest)
            except Exception as e:
                self._log("排替换失败：%s" % e)
            self._log("新版本 %s 已就绪，关掉启动器时自动换上" % self._upd_latest)
            self._set_update_title("新版本 %s 已就绪，关掉即换上" % self._upd_latest)
            return
        self._apply_update(payload)

    def _on_update_pkg_failed(self, err):
        self._upd_running = False
        self._set_update_title("")
        self._hide_update_bar()
        d = getattr(self, "_upd_dlg", None)
        if d is not None:
            d.hide()
            self._upd_dlg = None
        self._log("自动更新失败：%s" % err)

    def _apply_update(self, payload):
        self._show_update_bar(busy=True,
                              text="正在替换文件并重启新版本（约 3 秒）",
                              sub="")
        try:
            updater.schedule_update(payload, latest=self._upd_latest)
        except Exception as e:
            QMessageBox.warning(self, "自动更新", str(e))
            return
        self._log("正在重启替换为新版本......")
        self._force_quit = True          # 别被「缩到托盘」拦下来
        try:
            self._ensure_tray_stop()
        except Exception:
            pass
        # 重启进度窗：主窗口马上要 hide，所以它不挂父窗口，独立显示到重启走完
        try:
            self._rst_dlg = RestartProgressDialog(
                version=getattr(self, "_upd_latest", "") or "",
                on_done=self._finish_update_restart)
            self._rst_dlg.start()
        except Exception:
            self._rst_dlg = None
        QApplication.processEvents()
        self.hide()
        QApplication.processEvents()
        if getattr(self, "_rst_dlg", None) is None:
            QTimer.singleShot(0, self._quit_for_update)

    def _finish_update_restart(self):
        """进度条走到 100% 后由它回调：立刻退出，让替换脚本接手。"""
        try:
            dlg = getattr(self, "_rst_dlg", None)
            if dlg is not None:
                dlg.set_progress(100)
        except Exception:
            pass
        self._quit_for_update()

    def _ensure_tray_stop(self):
        tray = getattr(self, "_tray", None)
        if tray is not None:
            try:
                tray.hide()
                tray.setContextMenu(None)
            except Exception:
                pass

    def _quit_for_update(self):
        """替换前的退出：shutdown 最多等 0.9 秒就硬退，别让替换脚本干等。

        旧版是先 quit 再挂 2.5 秒保底计时器，等于重启前白白多等两三秒；
        这里改成后台收尾 + 限时硬退，旧进程一消失替换脚本立刻接手。
        """
        import threading
        self._force_quit = True
        QApplication.processEvents()
        try:
            QApplication.instance().quit()
        except Exception:
            pass

        def _cleanup():
            try:
                self.shutdown()
            except Exception:
                pass

        t = threading.Thread(target=_cleanup, daemon=True)
        t.start()
        t.join(0.9)
        os._exit(0)

    def _mobile_account_text(self):
        account = self.ms_account or {}
        if self.radio_offline.isChecked():
            return (i18n.tr("radio_offline") + "：" +
                    (self.input_name.text().strip() or "Player"))
        if self.radio_msa.isChecked():
            if account.get("type") == "msa":
                return i18n.tr("radio_msa") + "：" + account.get("name", "")
            return i18n.tr("radio_msa") + "：" + i18n.tr("not_logged_in")
        if account.get("type") == "third_party":
            return i18n.tr("radio_third") + "：" + account.get("name", "")
        return i18n.tr("radio_third") + "：" + i18n.tr("not_logged_in")

    def _publish_mobile_state(self):
        if not getattr(self, "mobile_bridge", None):
            return
        self.mobile_bridge.game_dir = self.config.get("game_dir") or ""
        rooms = []
        for r in getattr(self, "_lan_rooms", []) or []:
            rooms.append("%s | %d/%d 人" % (
                r.get("motd") or "房间", r.get("online", 0), r.get("max", 0)))
        # 用环形缓存，不再每次去 QTextEdit 里扫全文
        log_lines = list(getattr(self, "_log_lines", []))[-18:]
        running = bool(self.launch_proc and self.launch_proc.poll() is None)
        tick = int(getattr(self, "_mobile_tick", 0)) + 1
        self._mobile_tick = tick
        # 版本列表和截图列表要读磁盘，10 秒刷一次就够，别每 2.5 秒扫目录
        if tick % 4 == 1:
            self._mobile_versions = self._local_version_ids()
            try:
                gd = self.config.get("game_dir") or ""
                self._mobile_shots = ([{"name": os.path.basename(p)} for p, _m, _k
                                       in screenshots.list_shots(gd)[:12]]
                                      if gd else [])
            except Exception:
                self._mobile_shots = []
            try:
                vid = self._selected_version_id() or ""
                jp = self.config.get("java_path") or ""
                if not jp and vid:
                    jp = javaman.resolve(self.config, vid)
                major = java_utils.java_major(jp) if jp else 0
                self._mobile_java = ("Java %d" % major) if major else "未检测到 Java"
            except Exception:
                self._mobile_java = "-"
            # 串流状态要跑 tasklist / 探端口，别每 2.5 秒查一次
            try:
                if not hasattr(self, "_mobile_stream"):
                    self._mobile_stream = {}
                if tick % 8 == 1 or not self._mobile_stream:
                    ip = lan.lan_ip() or ""
                    self._mobile_stream = streaming.detect(ip)
            except Exception:
                self._mobile_stream = {}
        try:
            import socket
            pc_name = socket.gethostname() or "这台电脑"
        except Exception:
            pc_name = "这台电脑"
        self._publish_screen_to_mobile()
        self.mobile_bridge.state = {
            "version": self.config.get("last_version") or "-",
            "account": self._mobile_account_text(),
            "rooms": rooms,
            "log": log_lines,
            "running": running,
            "pc": "%s · OMC %s" % (pc_name, update.VERSION),
            "memory": "%d MB" % int(self.config.get("memory_mb") or 0),
            "java": getattr(self, "_mobile_java", "-"),
            "versions": getattr(self, "_mobile_versions", []),
            "shots": getattr(self, "_mobile_shots", []),
            "diag": getattr(self, "_mobile_diag", []),
            "notice": getattr(self, "_mobile_notice", ""),
            "stream": getattr(self, "_mobile_stream", {}) or {},
        }

    def _publish_screen_to_mobile(self):
        """手机端要看电脑画面时，才截屏（截整屏，游戏窗口也在里面）。

        平时不截，避免白白占 CPU；手机端连续 12 秒没再要就不截了。
        """
        bridge = getattr(self, "mobile_bridge", None)
        if bridge is None:
            return
        try:
            want = float(getattr(bridge, "screen_want", 0) or 0)
        except Exception:
            want = 0
        if time.time() - want > 12:
            return
        try:
            scr = QApplication.primaryScreen()
            if scr is None:
                return
            pix = scr.grabWindow(0)
            if pix.isNull():
                return
            if pix.width() > 720:
                pix = pix.scaledToWidth(720, Qt.SmoothTransformation)
            buf = QBuffer()
            buf.open(QBuffer.WriteOnly)
            pix.save(buf, "PNG")
            bridge.screen_png = bytes(buf.data())
            buf.close()
            bridge.screen_ts = time.time()
        except Exception as e:
            self._log("手机端截图失败：%s" % e)

    def _local_version_ids(self):
        """versions 目录里能启动的实例（有同名 json 才算）。"""
        gd = self.config.get("game_dir") or ""
        d = os.path.join(gd, "versions") if gd else ""
        if not d or not os.path.isdir(d):
            return []
        out = []
        for name in sorted(os.listdir(d)):
            p = os.path.join(d, name)
            if os.path.isdir(p) and os.path.isfile(os.path.join(p, name + ".json")):
                out.append(name)
        return out

    def _refresh_mobile_diag(self):
        """日志诊断结果缓存给手机端看，不用每次都重新读几百 KB。"""
        try:
            gd = self.config.get("game_dir") or ""
            if not gd:
                return
            rep = logview.report(gd)
            self._mobile_diag = [{"title": it["title"], "advice": it["advice"]}
                                 for it in rep["items"][:4]]
        except Exception:
            self._mobile_diag = []
        # 五分钟后再算一次（游戏刚崩过时手机端就能看到结论）
        try:
            QTimer.singleShot(300000, self._refresh_mobile_diag)
        except Exception:
            pass

    def _drain_mobile_actions(self):
        """主线程定时把手机端塞进队列的动作取出来执行。"""
        items = []
        try:
            from core import mobile_server as _ms
            items = _ms.take_actions()
        except Exception:
            items = []
        bridge = getattr(self, "mobile_bridge", None)
        if bridge is not None:
            try:
                items = list(bridge.take()) + items
            except Exception:
                pass
        for name, arg in items:
            try:
                self._on_mobile_action(name, arg)
            except Exception as e:
                self._log("手机端操作失败：%s" % e)

    def _cat_startup_tip(self):
        """启动完成让小猫自己说一句小贴士（设置里关掉小猫就不说话）。"""
        pet = getattr(self, "cat_pet", None)
        if pet is None or not pet.isVisible():
            return
        try:
            tips = getattr(pet, "_short_tips", None) or []
            if not tips:
                return
            pet.say(tips[int(time.time()) % len(tips)])
        except Exception:
            pass

    def _set_mobile_notice(self, text):
        """给手机端的一句话提示：手机页面下次刷新会弹出来，也会记进运行日志。"""
        self._mobile_notice = text or ""
        if not text:
            return
        try:
            self._log(text)
        except Exception:
            pass

    def _start_stream_service(self):
        """手机端点了「让电脑启动它」：把电脑上的串流服务拉起来。"""
        st = streaming.detect(lan.lan_ip())
        exe = st.get("exe") or ""
        if not exe:
            self._set_mobile_notice(
                "电脑上没装 Sunshine，手机端给了安装说明（GitHub 搜 LizardByte/Sunshine）")
            return
        try:
            subprocess.Popen([exe], cwd=os.path.dirname(exe),
                             creationflags=getattr(subprocess,
                                                    "CREATE_NEW_PROCESS_GROUP", 0))
            self._set_mobile_notice("已尝试启动串流服务，几秒后手机页面会显示状态")
        except Exception as e:
            self._set_mobile_notice("启动串流服务失败：%s" % e)
            return
        # 立刻重查一次，让手机页面马上看到「正在运行」
        try:
            self._mobile_stream = streaming.detect(lan.lan_ip())
        except Exception:
            pass

    def _on_mobile_action(self, name, arg):
        """手机端点的动作，回到主线程执行。"""
        try:
            if name == "launch":
                vid = (self._selected_version_id()
                       or (self.config.get("last_version") or "") or "游戏")
                self._set_mobile_notice("手机端点了启动：正在启动 %s" % vid)
                self._on_primary()
            elif name == "rescan":
                self._rescan_lan_rooms()
                self._set_mobile_notice("手机端请求重扫局域网房间")
            elif name == "streamstart":
                self._start_stream_service()
            elif name == "switch":
                vid = (arg or "").strip()
                if vid:
                    self._select_version(vid)
                    self.btn_play.setChecked(True)
                    self.stack.setCurrentIndex(0)
                    self._log("手机端切换版本：" + vid)
            elif name == "memory":
                try:
                    mb = int(arg)
                except Exception:
                    mb = 0
                if mb > 0:
                    self.config.set("memory_mb", mb)
                    try:
                        self.config.save()
                    except Exception:
                        pass
                    if hasattr(self, "slider_mem"):
                        self.slider_mem.setValue(
                            max(self.slider_mem.minimum(),
                                min(mb, self.slider_mem.maximum())))
                    self._log("手机端改内存：%d MB" % mb)
            elif name in ("album", "shots"):
                self._refresh_tools()
                if getattr(self, "toolbox_page", None):
                    self.toolbox_page.tabs.setCurrentIndex(6)
            elif name == "logs":
                self._refresh_tools()
                if getattr(self, "toolbox_page", None):
                    self.toolbox_page.tabs.setCurrentIndex(2)
            elif name == "window":
                self.showNormal()
                self.raise_()
                self.activateWindow()
        except Exception as e:
            self._log("手机端操作失败：%s" % e)

    # ---------- 存档定时自动备份 ----------
    def _start_autobackup(self):
        self._stop_autobackup()
        self._autobackup = None
        try:
            interval = int(self.config.get("auto_backup_interval") or 0)
            keep = int(self.config.get("backup_keep") or 5)
            gd = self.config.get("game_dir") or ""
            if interval > 0 and gd:
                self._autobackup = autobackup.start(
                    gd, interval, keep, self._log,
                    lambda n: self._log("定时备份：%d 个存档" % n))
        except Exception as e:
            self._log("开定时备份失败：%s" % e)

    def _stop_autobackup(self):
        w = getattr(self, "_autobackup", None)
        if w is not None:
            try:
                w.stop()
            except Exception:
                pass
            self._autobackup = None

    # ---------- 全局快捷键 ----------
    def _setup_global_hotkeys(self):
        try:
            res = hotkeys.start()
        except Exception as e:
            self._log("全局快捷键没开起来：%s" % e)
            return
        self._log("全局快捷键：" + (res.get("msg") or "不可用"))
        if not res.get("ok"):
            return
        if getattr(self, "_hotkey_timer", None) is None:
            self._hotkey_timer = QTimer(self)
            self._hotkey_timer.timeout.connect(self._poll_global_hotkeys)
            # 300ms 一次等于每秒唤醒 3 次，纯轮询也吃 CPU；600ms 人感觉不到延迟，
            # 空闲时的唤醒次数直接砍一半。
            self._hotkey_timer.start(600)

    def _poll_global_hotkeys(self):
        try:
            names = hotkeys.poll()
        except Exception:
            return
        for n in names:
            try:
                if n == "toggle":
                    self.showNormal()
                    self.raise_()
                    self.activateWindow()
                elif n == "launch":
                    self._on_primary()
                elif n == "screenshot":
                    self._refresh_tools()
                    if getattr(self, "toolbox_page", None):
                        self.toolbox_page.tabs.setCurrentIndex(6)
            except Exception as e:
                self._log("快捷键执行失败：%s" % e)

    def _track(self, worker):
        """登记后台线程，退出时统一等待，避免 Qt 线程未收敛导致 0xC0000409。"""
        self._workers.append(worker)
        worker.finished.connect(lambda w=worker: self._untrack(w))
        return worker

    def _untrack(self, worker):
        try:
            self._workers.remove(worker)
        except ValueError:
            pass
        # 已被 deleteLater 的 QThread 不能再调 isRunning，先把引用清掉
        if getattr(self, "_lan_worker", None) is worker:
            self._lan_worker = None
        worker.deleteLater()

    def shutdown(self):
        for timer in ("lan_timer", "room_timer", "launch_timer", "mobile_timer",
                      "update_timer", "update_repeat"):
            t = getattr(self, timer, None)
            if t is not None:
                try:
                    t.stop()
                except RuntimeError:
                    pass
        if getattr(self, "mobile_server", None):
            try:
                self.mobile_server.stop()
            except Exception:
                pass
        if getattr(self, "room_meta", None):
            try:
                self.room_meta.stop()
            except Exception:
                pass
        if getattr(self, "room_server", None):
            try:
                self.room_server.stop()
            except Exception:
                pass
        # 预告片在播的话先停掉，别让音频线程拖住关窗
        if getattr(self, "trailer_card", None):
            try:
                self.trailer_card.shutdown()
            except RuntimeError:
                pass
        # 音乐页同理：正在放歌的话先停
        if getattr(self, "music_page", None):
            try:
                self.music_page.shutdown()
            except (RuntimeError, AttributeError):
                pass
        # 关窗别卡：先统一取消，再共享一个 400ms 的总预算
        alive = [w for w in list(self._workers) if w.isRunning()]
        for worker in alive:
            try:
                if hasattr(worker, "cancel"):
                    worker.cancel()
            except RuntimeError:
                pass
        deadline = time.time() + 0.4
        for worker in alive:
            left = max(1, int((deadline - time.time()) * 1000))
            try:
                worker.wait(left)
            except RuntimeError:
                pass
        self._workers.clear()
    # ---------- 侧边栏 ----------
    def _build_sidebar(self):
        bar = QFrame()
        bar.setObjectName("Sidebar")
        bar.setFixedWidth(200)
        v = QVBoxLayout(bar)
        v.setContentsMargins(18, 24, 18, 20)
        v.setSpacing(8)

        brand = QLabel("OMC")
        brand.setObjectName("Brand")
        sub = QLabel(i18n.tr("brand_sub"))
        sub.setObjectName("BrandSub")
        v.addWidget(brand)
        v.addWidget(sub)
        # 左上角署名：半透浅灰小字
        maker = QLabel("由一坨圆子弹独立制作")
        maker.setObjectName("Maker")
        maker.setStyleSheet(
            "color: rgba(200,205,215,120); font-size: 11px; letter-spacing: 1px;")
        v.addWidget(maker)
        v.addSpacing(28)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.btn_play = self._nav_button(i18n.tr("page_play"), 0)
        self.btn_mods = self._nav_button(i18n.tr("page_mods"), 2)
        # 附魔计算已并入工具页，左栏不再单列一页
        self.btn_skins = self._nav_button(i18n.tr("page_skins"), 5)
        self.btn_music = self._nav_button(i18n.tr("page_music"), 10)
        self.btn_lan = self._nav_button(i18n.tr("page_lan"), 4)
        self.btn_lan.clicked.connect(self._start_lan_watch)
        self.btn_tools = self._nav_button(i18n.tr("page_tools"), 11)
        self.btn_tools.clicked.connect(self._refresh_tools)
        self.btn_video = self._nav_button(i18n.tr("page_video"), 12)
        self.btn_video.clicked.connect(self._refresh_video)
        self.btn_enter = self._nav_button(i18n.tr("page_ent"), 13)
        self.btn_enter.clicked.connect(self._refresh_enter)
        self.btn_friends = self._nav_button(i18n.tr("page_friends"), 6)
        self.btn_mail = self._nav_button(i18n.tr("page_mail"), 7)
        self.btn_mail.clicked.connect(self._refresh_mail)
        self.btn_account = self._nav_button(i18n.tr("page_account"), 8)
        self.btn_account.clicked.connect(self._refresh_account)
        self.btn_settings = self._nav_button(i18n.tr("page_settings"), 1)
        v.addWidget(self.btn_play)
        v.addWidget(self.btn_mods)
        v.addWidget(self.btn_skins)
        v.addWidget(self.btn_music)
        v.addWidget(self.btn_lan)
        v.addWidget(self.btn_tools)
        v.addWidget(self.btn_video)
        v.addWidget(self.btn_enter)
        v.addWidget(self.btn_friends)
        v.addWidget(self.btn_mail)
        v.addWidget(self.btn_account)
        v.addWidget(self.btn_settings)
        self.btn_play.setChecked(True)
        v.addStretch(1)
        # 底部小挂件：点一下会「喵」，设置里能关掉
        self.cat_pet = CatPet()
        self.cat_pet.setVisible(
            True if self.config.get("ui_cat") is None else bool(self.config.get("ui_cat")))
        v.addWidget(self.cat_pet, 0, Qt.AlignHCenter)
        return bar

    def _nav_button(self, text, index):
        b = QPushButton(text)
        b.setObjectName("NavButton")
        b.setCheckable(True)
        b.clicked.connect(lambda: self.stack.setCurrentIndex(index))
        self.nav_group.addButton(b)
        return b

    # ---------- 邮件页 ----------
    def _build_mail_page(self):
        from .mail_page import MailPage
        self.mail_page = MailPage(self)
        # 邮件页里一标已读，左栏角标马上跟着变
        self.mail_page.on_unread = self._update_mail_badge
        return self.mail_page

    def _refresh_mail(self, *_):
        try:
            self.stack.setCurrentIndex(7)
            if getattr(self, "mail_page", None) is not None:
                self.mail_page.refresh()
            self._update_mail_badge()
        except Exception:
            pass

    # ---------- 娱乐页 ----------
    def _build_enter_page(self):
        from .play_page import PlayPage
        self.play_page = PlayPage(self)
        return self.play_page

    def _refresh_enter(self, *_):
        try:
            self.stack.setCurrentIndex(13)
            if getattr(self, "play_page", None) is not None:
                self.play_page.set_page()
        except Exception:
            pass

    # ---------- 账号页 ----------
    def _build_account_page(self):
        from .account_page import AccountPage
        self.account_page = AccountPage(self.config, self._apply_account_bind, self)
        return self.account_page

    def _refresh_account(self, *_):
        try:
            self.stack.setCurrentIndex(8)
            if getattr(self, "account_page", None) is not None:
                self.account_page.refresh()
        except Exception:
            pass

    def _apply_account_bind(self, kind, payload):
        """把账号里绑好的游戏身份灌进启动页：之后启动游戏不用再输密码。"""
        try:
            from core import auth
            payload = payload or {}
            if kind in ("msa", "third"):
                self.ms_account = payload
                auth.save_account(payload)
                if kind == "msa":
                    self.radio_msa.setChecked(True)
                else:
                    self.radio_third.setChecked(True)
                    if hasattr(self, "input_third_api") and payload.get("api"):
                        self.input_third_api.setEditText(payload["api"])
            if hasattr(self, "input_name") and payload.get("name") \
                    and kind == "offline":
                self.input_name.setText(payload["name"])
            if hasattr(self, "radio_msa"):
                self._sync_account_ui()
        except Exception as e:
            self._log("应用账号绑定失败：%s" % e)

    def _apply_account_logged(self, name):
        """登录成功后（含自动登录），按绑定情况把启动页调好。"""
        try:
            from core import accounts
            binds = accounts.binds_of(name)
            off = (binds.get("offline") or {}).get("name")
            if off and hasattr(self, "input_name"):
                self.input_name.setText(off)
            if binds.get("msa"):
                self._apply_account_bind("msa", binds["msa"])
            elif binds.get("third"):
                self._apply_account_bind("third", binds["third"])
            else:
                self.config.set("account_mode", "offline")
                if off:
                    self.config.set("username", off)
            # 登录着的账号挂到好友目录，别人才能按名字搜到
            if self.config.get("dir_allow") is not False:
                threading.Thread(target=frienddir.announce,
                                 args=(name, (accounts.find(name) or {}).get("id") or name),
                                 daemon=True).start()
        except Exception as e:
            self._log("同步账号绑定失败：%s" % e)

    def _auto_login_account(self):
        """勾了「记住密码」的账号，启动时直接登进去。"""
        try:
            from core import accounts
            cur = accounts.current_name()
            if cur:
                self._apply_account_logged(cur)
                self._log("当前账号：%s" % cur)
                return
            # 上次是用户自己点的「退出登录」：别再拿记住的密码把他登回去，
            # 否则退出完一重启又自动上线，等于退出无效。
            if accounts.logged_out_by_user():
                self._log("上次是主动退出登录，跳过自动登录")
                return
            for item in accounts.remembered_accounts():
                if not item.get("auto"):
                    continue
                ok, msg = accounts.quick_login(item.get("name"))
                if ok:
                    self._apply_account_logged(msg)
                    self._log("已自动登录账号：%s" % msg)
                    return
        except Exception as e:
            self._log("自动登录失败：%s" % e)

    def _goto_skins_page(self):
        """跳到皮肤库页，并把导航按钮的选中态一起切过去。"""
        try:
            self.btn_skins.setChecked(True)
            self.stack.setCurrentIndex(5)
            page = getattr(self, "skin_page", None)
            if page is not None and hasattr(page, "refresh"):
                page.refresh()
        except Exception:
            pass

    # ---------- 内容区 ----------
    def _scroll_wrap(self, inner):
        """把页面内容包进可滚轮滚动的区域，内容超出时出现滚动条。

        横向以前是 AlwaysOff —— 窗口一窄，右边那截（按钮、下拉框）直接被切掉，
        用户看到的就是「不全屏时有些 UI 只显示一半」。改成按需出现，
        任何窗口尺寸下内容都能看到、也不会挤在一起重叠。
        """
        sa = QScrollArea()
        sa.setWidget(inner)
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa.setStyleSheet("QScrollArea { background: transparent; }")
        return sa

    def _ensure_scroll(self, page, pass_wheel=False):
        """页面没自带滚动区就包一层，免得小窗口下被裁或控件叠在一起。

        pass_wheel：滚轮事件直接交给页面处理（视频页靠滚轮切上/下一条，
        以前外面套滚动区就把滚轮截走了，所以那页一直不敢包）。
        """
        if page is None:
            return page
        if isinstance(page, QScrollArea):
            return page
        if pass_wheel:
            sa = _PassWheelScroll()
            sa.setWidget(page)
            sa.setWidgetResizable(True)
            sa.setFrameShape(QFrame.NoFrame)
            sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            sa.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            sa.setStyleSheet("QScrollArea { background: transparent; }")
            return sa
        return self._scroll_wrap(page)
    def _build_tools_page(self):
        """工具中心：备份 / 冲突 / 日志 / Java / 批量 / 收藏 / 截图 / 主题…"""
        from .toolbox_page import ToolboxPage
        self.toolbox_page = ToolboxPage(self)
        return self.toolbox_page

    def _build_video_page(self):
        """刷视频：只推《我的世界》，一屏一条，滚轮/上下拖动切换。"""
        try:
            from .video_page import VideoPage
            self.video_page = VideoPage(self)
        except Exception as e:
            self.video_page = None
            w = QWidget()
            lay = QVBoxLayout(w)
            lay.addWidget(QLabel("刷视频加载失败：%s" % e))
            return w
        return self.video_page

    def _refresh_video(self, *_):
        try:
            self.stack.setCurrentIndex(12)
            if getattr(self, "video_page", None) is not None:
                self.video_page.refresh()
        except Exception:
            pass

    def _hide_floating_windows(self):
        """切页时把私聊 / 群聊 / 小矿 / 语音通话这些浮窗收起来。

        它们是非模态独立窗口：页面已经换过去了，弹窗还压在上面，看起来就像
        「点了没反应」。用 hide 不用 close——聊天记录和输入框状态留在实例里，
        再打开还是原样，不用重新拉一遍历史。
        """
        for attr in ("_chat_win", "_group_win", "_ai_win", "_ai_call"):
            w = getattr(self, attr, None)
            try:
                if w is not None and w.isVisible():
                    w.hide()
            except Exception:
                pass

    def _on_page_changed(self, idx):
        """离开刷视频页就停掉播放，别在后台占解码器和网络。"""
        prev = getattr(self, "_last_page_idx", None)
        self._last_page_idx = idx
        if prev == 13 and idx != 13:
            # 离开娱乐页：正在打的牌局自动认输，别让对局挂在后台
            pp = getattr(self, "play_page", None)
            if pp is not None:
                try:
                    pp.auto_leave_game()
                except Exception:
                    pass
        self._hide_floating_windows()
        if idx == 6:
            # 点进好友页就当看过了：角标清零，列表里的「N 条未读」也跟着清
            try:
                if getattr(self, "_unread", None):
                    self._unread = {}
                    self._reload_friends()
                    self._reload_groups()
            except Exception:
                pass
            try:
                self._update_friend_badge()
            except Exception:
                pass
        if idx != 12:
            vp = getattr(self, "video_page", None)
            if vp is not None:
                try:
                    vp.stop()
                except Exception:
                    pass
        # 进娱乐页时刷一下登录态和积分：可能在账号页刚登录/换了账号
        if idx == 13:
            pp = getattr(self, "play_page", None)
            if pp is not None:
                try:
                    pp.set_page()
                except Exception:
                    pass

    def _refresh_tools(self, *_):
        self.stack.setCurrentIndex(11)
        page = getattr(self, "toolbox_page", None)
        if page is not None and hasattr(page, "refresh"):
            try:
                page.refresh()
            except Exception:
                pass

    def _build_content(self):
        wrap = QFrame()
        wrap.setObjectName("Content")
        self.content_wrap = wrap
        outer = QVBoxLayout(wrap)
        outer.setContentsMargins(32, 28, 32, 28)
        self.stack = QStackedWidget()
        # 每页都套一层滚动区：窗口拉小/不全屏时内容按自身最小尺寸排开，
        # 放不下的部分给滚动条，而不是被父容器切掉或者几个控件叠在一起。
        self.stack.addWidget(self._ensure_scroll(self._build_play_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_settings_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_mods_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_detail_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_lan_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_skins_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_friends_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_mail_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_account_page()))
        # 位置占位：附魔计算已并进工具页，这里不再建独立页面（索引保持不变）
        self.stack.addWidget(self._ensure_scroll(QWidget()))
        self.stack.addWidget(self._ensure_scroll(self._build_music_page()))
        self.stack.addWidget(self._ensure_scroll(self._build_tools_page()))
        # 视频页要自己吃滚轮切条：包一层「不抢滚轮」的滚动区，
        # 滚轮照旧进页面，横/竖滚动条仍能拖，控件不会挤成一团
        self.stack.addWidget(self._ensure_scroll(self._build_video_page(),
                                                 pass_wheel=True))
        self.stack.addWidget(self._ensure_scroll(self._build_enter_page()))

        self.stack.currentChanged.connect(self._on_page_changed)
        outer.addWidget(self.stack)
        self._build_update_bar(outer)
        # 壁纸必须铺在整个窗口的最底层：面板现在是半透明深色，
        # 它们下面要垫着壁纸才有「深色玻璃」的层次。以前挂在 Content
        # 里面，等于壁纸盖在面板上，半透明就完全没效果了。
        self.backdrop = Backdrop(self)
        self.backdrop.setGeometry(self.rect())
        self.backdrop.lower()
        self._apply_background()
        return wrap

    def _apply_background(self):
        self._maybe_roll_random_wall()
        img = self.config.get("background_image") or ""
        if img.startswith("builtin:"):
            img = self._wall_path(img.split(":", 1)[1])
        try:
            v = int(self.config.get("bg_dim") or 0)
        except Exception:
            v = 0
        # 亮度滑块：负值是提亮、正值是压暗，0 就是原图亮度
        self.backdrop.dim = max(0, v)
        self.backdrop.lift = max(0, -v)
        if img and os.path.exists(img):
            self.backdrop.set_image(img)
        else:
            self.backdrop.set_image("")
            self.backdrop.setStyleSheet("")
            if img:
                # 文件丢了别静默变空：写进日志，不然看起来就像「换了没反应」
                self._log("壁纸文件找不到：%s" % img)
        self.backdrop.update()

    # 每日一条：实用的启动器用法，按日期轮换
    DAILY_TIPS = (
        "内存别硬填：按电脑实际内存推荐的那个值最稳，给多了反而更卡",
        "模组崩了先开工具页「日志诊断」，16 条常见原因直接给结论，不用自己翻 log",
        "换模组之前去工具页「版本备份」存一份，出问题一键还原，当前目录还会留底",
        "Ctrl+Alt+M 播放 / 暂停，Ctrl+Alt+N 下一首，游戏开着也按得动",
        "启动慢可以关掉启动页预告片：设置 → 启动与动画 → 预告片",
        "小内存电脑把内存调到 2G~4G，比拉高更流畅",
        "装不上就先看「兼容性自检」，缺 Java、缺运行库它会直说",
        "皮肤、头像换了没生效，重启启动器再进游戏就会刷新",
        "想让它开机就开，设置里勾上「开机自动打开启动器」，不用管理员权限",
        "侧栏小猫右键会随口给一句能用的提示，连点两下它会摇尾巴",
    )

    def _daily_tip(self):
        try:
            tip = self.DAILY_TIPS[time.localtime().tm_yday % len(self.DAILY_TIPS)]
        except Exception:
            tip = self.DAILY_TIPS[0]
        return "今日一条：" + tip

    def _maybe_roll_random_wall(self):
        """每次启动只随机一次；自己导入的图不碰。"""
        if getattr(self, "_rand_wall_rolled", False):
            return
        self._rand_wall_rolled = True
        try:
            if not self.config.get("bg_random"):
                return
            cur = self.config.get("background_image") or ""
            if not cur.startswith("builtin:"):
                return
            names = [fn for fn, _label in self.BUILTIN_WALLS
                     if os.path.exists(self._wall_path(fn))]
            if not names:
                return
            pick = random.choice(names)
            key = "builtin:" + pick
            self.config.set("background_image", key)
            self.config.save()
            try:
                self.combo_wall.blockSignals(True)
                i = self.combo_wall.findData(key)
                if i >= 0:
                    self.combo_wall.setCurrentIndex(i)
                self.combo_wall.blockSignals(False)
                self.label_bg_name.setText(self._wall_label(key) or pick)
            except Exception:
                pass
            self._log("随机壁纸换成了：" + (self._wall_label(key) or pick))
        except Exception as e:
            self._log("随机壁纸失败：%s" % e)

    def _on_rand_wall_toggled(self, on):
        self.config.set("bg_random", bool(on))
        self.config.save()
        # 「随机换壁纸」和「固定选一张」是互斥的：开了随机，固定那张就没意义了。
        # 勾随机 → 固定壁纸框直接收起来（不是清空，取消随机后原来那张还在）。
        self._sync_rand_wall_lock(bool(on))
        if on:
            self._rand_wall_rolled = False
            self._maybe_roll_random_wall()
            self.backdrop.update()
            self._log("随机壁纸：已打开")
        else:
            self._log("随机壁纸：已关闭")

    def _sync_rand_wall_lock(self, on):
        """固定壁纸选择框跟着「随机」开关互斥。"""
        try:
            self.combo_wall.setEnabled(not on)
            self.combo_wall.setToolTip(
                "已经开了「随机换壁纸」，这里先不用选；想固定一张就先把随机关掉"
                if on else "")
        except Exception:
            pass

    def _excl_dnd(self, on):
        """勾了全局免打扰 → 自动取消「只关提示音」（免打扰本来就不响了）。"""
        if not on:
            return
        try:
            if self.cb_no_sound.isChecked():
                self.cb_no_sound.setChecked(False)
                self._log("互斥：开了全局免打扰，「只关提示音」自动取消")
        except Exception:
            pass

    def _excl_no_sound(self, on):
        """勾了「只关提示音」→ 自动取消全局免打扰（两个同时亮只会打架）。"""
        if not on:
            return
        try:
            if self.cb_global_dnd.isChecked():
                self.cb_global_dnd.setChecked(False)
                self._log("互斥：选了「只关提示音」，全局免打扰自动取消")
        except Exception:
            pass

    def _build_play_page(self):
        page = QWidget()
        outer = QHBoxLayout(page)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(16)

        # ---- 左侧版本小栏（不是最外层导航），版本竖排可滚轮 ----
        rail = QFrame()
        rail.setObjectName("VersionRail")
        rail.setFixedWidth(226)
        rl = QVBoxLayout(rail)
        rl.setContentsMargins(16, 16, 16, 16)
        rl.setSpacing(10)
        rl.addWidget(self._field_label(i18n.tr("label_game_version")))
        self.group_combo = QComboBox()
        self.group_combo.addItem(i18n.tr("ver_local"), "local")
        self.group_combo.addItem(i18n.tr("ver_release"), "release")
        self.group_combo.addItem(i18n.tr("ver_snapshot"), "snapshot")
        self.group_combo.addItem(i18n.tr("ver_old"), "old")
        self.group_combo.currentIndexChanged.connect(self._refresh_version_list)
        rl.addWidget(self.group_combo)
        self.edit_version_filter = QLineEdit()
        self.edit_version_filter.setPlaceholderText(i18n.tr("filter_placeholder"))
        self.edit_version_filter.textChanged.connect(self._refresh_version_list)
        rl.addWidget(self.edit_version_filter)
        self.local_list = QListWidget()
        self._attach_ctx_menu(self.local_list, "version")
        self.local_list.itemSelectionChanged.connect(self._update_install_state)
        self.local_list.itemDoubleClicked.connect(
            lambda item: self._open_version_detail(
                item.data(Qt.UserRole) or item.text()))
        rl.addWidget(self.local_list, 1)
        self.btn_open_detail = QPushButton(i18n.tr("btn_open_detail"))
        self.btn_open_detail.clicked.connect(
            lambda: self._open_version_detail(self._selected_version_id()))
        rl.addWidget(self.btn_open_detail)
        # 每日一条：按日期轮换，不联网
        self.lbl_tip = QLabel(self._daily_tip())
        self.lbl_tip.setObjectName("FieldLabel")
        self.lbl_tip.setWordWrap(True)
        self.lbl_tip.setToolTip("每天换一条；侧栏小猫右键还能随机问一句")
        rl.addWidget(self.lbl_tip)
        outer.addWidget(rail)

        # ---- 右侧主区域 ----
        right = QWidget()
        v = QVBoxLayout(right)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(16)

        form = QVBoxLayout()
        form.setContentsMargins(22, 22, 22, 22)
        form.setSpacing(12)

        # 账号模式
        form.addWidget(self._field_label(i18n.tr("label_account")))
        self.radio_offline = QRadioButton(i18n.tr("radio_offline"))
        self.radio_msa = QRadioButton(i18n.tr("radio_msa"))
        self.radio_third = QRadioButton(i18n.tr("radio_third"))
        if self.config.get("account_mode") == "msa":
            self.radio_msa.setChecked(True)
        elif self.config.get("account_mode") == "third_party":
            self.radio_third.setChecked(True)
        else:
            self.radio_offline.setChecked(True)
        self.radio_offline.toggled.connect(self._sync_account_ui)
        self.radio_msa.toggled.connect(self._sync_account_ui)
        self.radio_third.toggled.connect(self._sync_account_ui)
        form.addWidget(self._row(self.radio_offline, self.radio_msa,
                                 self.radio_third))

        # 离线：用户名
        self.input_name = QLineEdit(self.config.get("username"))
        self.input_name.setMaxLength(16)
        form.addWidget(self.input_name)

        # 正版：状态 + 登录/退出
        self.msa_state = QLabel("")
        self.msa_state.setObjectName("FieldLabel")
        form.addWidget(self.msa_state)
        self.btn_login = QPushButton(i18n.tr("btn_login_ms"))
        self.btn_login.clicked.connect(self._login_msa)
        self.btn_logout = QPushButton(i18n.tr("btn_logout"))
        self.btn_logout.clicked.connect(self._logout_msa)
        form.addWidget(self._row(self.btn_login, self.btn_logout))

        # 第三方登录：服务器地址 + 用户名 + 密码
        self.third_panel = QWidget()
        tl = QVBoxLayout(self.third_panel)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(8)
        self.input_third_api = QComboBox()
        self.input_third_api.setEditable(True)
        self.input_third_api.setInsertPolicy(QComboBox.NoInsert)
        saved = self.config.get("third_api") or ""
        # 自己保存过的地址固定排第一项「我的第三方登录」
        self.input_third_api.addItem("我的第三方登录", saved or THIRD_SERVERS[0][1])
        for label, url in THIRD_SERVERS:
            self.input_third_api.addItem(label, url)
        self.input_third_api.setCurrentIndex(0)
        self.input_third_api.currentIndexChanged.connect(self._on_third_server_pick)
        if saved:
            self.input_third_api.setEditText(saved)
        else:
            self.input_third_api.setEditText(THIRD_SERVERS[0][1])
        third_tip = QLabel(
            "上面几家点一下就自动填地址；自建皮肤站直接填域名也行（会补成 "
            "https://你的站/api/yggdrasil），支持中文名要看该站有没有录入。")
        third_tip.setObjectName("FieldLabel")
        third_tip.setWordWrap(True)
        self.input_third_user = QLineEdit()
        self.input_third_user.setPlaceholderText(i18n.tr("third_user_ph"))
        self.input_third_pass = QLineEdit()
        self.input_third_pass.setEchoMode(QLineEdit.Password)
        self.input_third_pass.setPlaceholderText(i18n.tr("third_pass_ph"))
        self.btn_third_login = QPushButton(i18n.tr("btn_third_login"))
        self.btn_third_login.clicked.connect(self._login_third)
        tl.addWidget(self.input_third_api)
        tl.addWidget(third_tip)
        tl.addWidget(self.input_third_user)
        tl.addWidget(self.input_third_pass)
        tl.addWidget(self.btn_third_login)
        self.btn_third_reg = QPushButton("在这个服务器注册新账号")
        self.btn_third_reg.setToolTip(
            "填服务器地址+用户名+邮箱+密码，直接在你搭的服务器上开号并登录")
        self.btn_third_reg.clicked.connect(self._open_third_register)
        tl.addWidget(self.btn_third_reg)
        form.addWidget(self.third_panel)

        self.install_state = QLabel("")
        self.install_state.setObjectName("FieldLabel")
        form.addWidget(self.install_state)

        # 官方最新版本（版本号与封面每次启动自动刷新）
        v.addWidget(self._build_latest_card())

        # 官方最新版本预告片：循环播，可暂停可静音，跟着下载站清单换片
        # 建 QMediaPlayer / QVideoWidget 在 Windows 要初始化多媒体后端，实测吃掉
        # 2.4 秒启动时间，所以先用一个空占位，等窗口出来再把卡片挂上去。
        self.trailer_card = None
        self._trailer_host = QWidget()
        self._trailer_box = QVBoxLayout(self._trailer_host)
        self._trailer_box.setContentsMargins(0, 0, 0, 0)
        self._trailer_box.setSpacing(0)
        v.addWidget(self._trailer_host)
        QTimer.singleShot(280, self._mount_trailer)

        v.addWidget(card(form))

        # 模组加载器（跟随当前选中的游戏版本）
        v.addWidget(self._build_loader_card())

        # 安装后的版本名称，可自行起名，默认 版本名-加载器名
        nform = QVBoxLayout()
        nform.setContentsMargins(22, 18, 22, 18)
        nform.setSpacing(10)
        nform.addWidget(self._field_label(i18n.tr("label_instance_name")))
        self.input_instance_name = QLineEdit()
        nform.addWidget(self.input_instance_name)
        v.addWidget(card(nform))
        # 版本或加载器变化时，自动填默认名称（用户仍可手动改）
        self.combo_loader_kind.currentIndexChanged.connect(
            self._refresh_default_name)
        self.local_list.itemSelectionChanged.connect(
            self._refresh_default_name)

        # 皮肤全部搬到了「皮肤库」页：这里只留一个入口，别让两处各有一套
        sform = QVBoxLayout()
        sform.setContentsMargins(22, 18, 22, 18)
        sform.setSpacing(10)
        srow = QHBoxLayout()
        srow.setSpacing(10)
        b_goto_skin = QPushButton("去皮肤库")
        b_goto_skin.clicked.connect(self._goto_skins_page)
        srow.addWidget(b_goto_skin)
        tip = QLabel("皮肤在「皮肤库」页；附魔相关的都在左边「工具」页的「附魔计算」页签里。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        srow.addWidget(tip, 1)
        sform.addLayout(srow)
        v.addWidget(card(sform))

        # 手机连电脑：地址 + 二维码，扫一下就能用手机操作启动器
        v.addWidget(self._build_mobile_card())

        self.btn_primary = QPushButton(i18n.tr("btn_launch"))
        self.btn_primary.setObjectName("PrimaryButton")
        self.btn_primary.clicked.connect(self._on_primary)
        v.addWidget(self.btn_primary)

        self.btn_bedrock = QPushButton("启动基岩版（Windows 商店版）")
        self.btn_bedrock.clicked.connect(self._launch_bedrock)
        v.addWidget(self.btn_bedrock)

        self.btn_netease = QPushButton("启动网易版（用网易官方登录）")
        self.btn_netease.setToolTip(
            "只调用你自己装的网易版官方启动器，登录和启动都在它自己的界面里；"
            "OMC 不改它任何文件、不注入，对反作弊来说就是个快捷方式。")
        self.btn_netease.clicked.connect(self._launch_netease)
        v.addWidget(self.btn_netease)

        # 种子地图已搬到工具页（工具 → 种子地图），这里不再单开入口

        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setVisible(False)
        v.addWidget(self.progress)

        self.launch_state = QLabel("")
        self.launch_state.setObjectName("FieldLabel")
        self.launch_state.setVisible(False)
        v.addWidget(self.launch_state)
        self.launch_bar = QProgressBar()
        self.launch_bar.setRange(0, 100)
        self.launch_bar.setValue(0)
        self.launch_bar.setTextVisible(True)
        self.launch_bar.setVisible(False)
        v.addWidget(self.launch_bar)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.document().setMaximumBlockCount(600)   # 日志越长越卡，只留最近 600 行
        self.log_view.setFixedHeight(110)
        v.addWidget(self.log_view)
        v.addStretch(1)
        outer.addWidget(self._scroll_wrap(right), 1)
        return page

    def _mount_trailer(self):
        """窗口已经出来了再把预告片卡建出来（建播放器要 2 秒上下）。"""
        if self.trailer_card is not None or not getattr(self, "_trailer_host", None):
            return
        if self.config.get("trailer_on") is False:
            # 设置页关掉了预告片：不建播放器，只留一句说明
            try:
                tip = QLabel("预告片已在设置页关闭（想看得去「设置 · 启动与动画」重新打开）")
                tip.setObjectName("FieldLabel")
                self._trailer_box.addWidget(tip)
            except Exception:
                pass
            return
        if syscheck.low_memory() or syscheck.session_hints():
            # 低内存机器 / 远程桌面：视频播放器和解码缓冲都太重，
            # 直接不建，留一条说明，别让整窗卡住。
            why = "内存偏小" if syscheck.low_memory() else "远程桌面会话"
            tip = QLabel("这台电脑%s，预告片已跳过（不影响其它功能）" % why)
            tip.setObjectName("FieldLabel")
            self._trailer_box.addWidget(tip)
            return
        try:
            self.trailer_card = TrailerCard()
        except Exception:
            self.trailer_card = None
            return
        self._trailer_box.addWidget(self.trailer_card)

    def _build_settings_page(self):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(16)

        title = QLabel(i18n.tr("page_settings"))
        title.setObjectName("PageTitle")
        v.addWidget(title)

        form = QVBoxLayout()
        form.setContentsMargins(22, 22, 22, 22)
        form.setSpacing(12)

        form.addWidget(self._field_label(i18n.tr("label_gamedir")))
        self.input_gamedir = QLineEdit(self.config.get("game_dir"))
        form.addWidget(self.input_gamedir)
        b_dir = QPushButton(i18n.tr("btn_browse"))
        b_dir.clicked.connect(self._pick_gamedir)
        form.addWidget(self._row(b_dir))

        form.addWidget(self._field_label(i18n.tr("label_java")))
        self.chk_java_auto = QCheckBox(
            "全自动（推荐）：按你选的版本自动换 Java，缺了就自己下")
        self.chk_java_auto.setChecked(
            self.config.get("java_auto") is not False)
        self.chk_java_auto.toggled.connect(self._on_java_auto_toggled)
        form.addWidget(self.chk_java_auto)
        self.input_java = QLineEdit(self.config.get("java_path"))
        self.input_java.setReadOnly(self.chk_java_auto.isChecked())
        form.addWidget(self.input_java)
        b_java = QPushButton(i18n.tr("btn_browse"))
        b_java.clicked.connect(self._pick_java)
        b_autojava = QPushButton(i18n.tr("btn_auto_detect"))
        b_autojava.clicked.connect(self._auto_java)
        b_fixjava = QPushButton("一键修复 Java")
        b_fixjava.setToolTip(
            "按当前选中的版本要的 Java 主版本检查一遍，缺了就自动下载适配的版本")
        b_fixjava.clicked.connect(self._fix_java)
        form.addWidget(self._row(b_java, b_autojava, b_fixjava))
        self.java_state = QLabel("")
        self.java_state.setObjectName("FieldLabel")
        form.addWidget(self.java_state)
        # Java 自动下载的进度条：以前只有一行百分比文字，看不出来还要多久
        self.java_bar = QProgressBar()
        self.java_bar.setValue(0)
        self.java_bar.setVisible(False)
        self.java_bar.setFormat("下载 Java %p%")
        form.addWidget(self.java_bar)

        self.mem_label = self._field_label(
            i18n.tr("label_memory", self.config.get("memory_mb")))
        form.addWidget(self.mem_label)
        self.slider_mem = QSlider(Qt.Horizontal)
        self.slider_mem.setRange(1024, 16384)
        self.slider_mem.setSingleStep(512)
        self.slider_mem.setValue(self.config.get("memory_mb"))
        self.slider_mem.valueChanged.connect(
            lambda val: self.mem_label.setText(i18n.tr("label_memory", val))
        )
        form.addWidget(self.slider_mem)

        self.btn_mem_rec = QPushButton("按这台电脑推荐")
        self.btn_mem_rec.setToolTip(
            "按物理内存和当前选中的版本算一个合适的值，直接填到上面的滑杆")
        self.btn_mem_rec.clicked.connect(self._fill_recommended_mem)
        self.lbl_mem_rec = QLabel("")
        self.lbl_mem_rec.setObjectName("FieldLabel")
        self.lbl_mem_rec.setWordWrap(True)
        form.addWidget(self._row(self.btn_mem_rec, self.lbl_mem_rec))

        form.addWidget(self._field_label("进游戏自动进入的服务器（留空就停在主菜单）"))
        self.input_autoserver = QLineEdit(
            self.config.get("auto_join_server") or "")
        self.input_autoserver.setPlaceholderText("play.example.com:25565")
        form.addWidget(self.input_autoserver)
        tip_srv = QLabel("走官方 quickPlay 直连，只对 1.20 及以上版本有效；"
                         "填 host 或 host:端口，启动游戏后会自动进这个服。")
        tip_srv.setObjectName("FieldLabel")
        tip_srv.setWordWrap(True)
        form.addWidget(tip_srv)

        form.addWidget(self._field_label(i18n.tr("label_mirror")))
        self.radio_bmcl = QRadioButton(i18n.tr("mirror_bmcl"))
        self.radio_official = QRadioButton(i18n.tr("mirror_official"))
        if self.config.get("mirror") == "bmcl":
            self.radio_bmcl.setChecked(True)
        else:
            self.radio_official.setChecked(True)
        self.radio_bmcl.toggled.connect(self._load_versions)
        form.addWidget(self._row(self.radio_bmcl))
        form.addWidget(self._row(self.radio_official))

        form.addWidget(self._field_label(i18n.tr("label_language")))
        self.combo_language = QComboBox()
        for code, name, _game in i18n.LANGUAGES:
            self.combo_language.addItem(name, code)
        cur_lang = self.config.get("language") or "zh_CN"
        li = self.combo_language.findData(cur_lang)
        if li >= 0:
            self.combo_language.setCurrentIndex(li)
        form.addWidget(self.combo_language)

        # 游戏内语言：模组名 / 道具名跟着这个走（模组自带对应语言文件才生效）
        form.addWidget(self._field_label("游戏内语言（模组名、道具名跟随）"))
        self.combo_game_lang = QComboBox()
        self.combo_game_lang.addItem("跟随启动器语言", "")
        for code, label in (
                ("zh_cn", "简体中文"), ("zh_tw", "繁體中文"),
                ("en_us", "English"), ("ja_jp", "日本語"), ("ko_kr", "한국어"),
                ("ru_ru", "Русский"), ("de_de", "Deutsch"), ("fr_fr", "Français")):
            self.combo_game_lang.addItem(label, code)
        cur = self.config.get("game_language") or ""
        gi = self.combo_game_lang.findData(cur)
        if gi >= 0:
            self.combo_game_lang.setCurrentIndex(gi)
        self.combo_game_lang.currentIndexChanged.connect(self._on_game_lang_changed)
        form.addWidget(self.combo_game_lang)
        note = QLabel("改成别的语言后，下次启动游戏时生效；模组没有对应语言文件的话，"
                      "它的名字还是原样。")
        note.setObjectName("FieldLabel")
        note.setWordWrap(True)
        form.addWidget(note)

        # 界面主题：深色 / 浅色，切换即时生效并记住
        form.addWidget(self._field_label("界面主题"))
        self.combo_theme = QComboBox()
        self.combo_theme.addItem("深色（默认）", "dark")
        self.combo_theme.addItem("浅色", "light")
        self.combo_theme.addItem("暗夜（更黑，晚上看）", "night")
        self.combo_theme.addItem("樱花（浅粉）", "sakura")
        ti = self.combo_theme.findData(self.config.get("theme") or "dark")
        if ti >= 0:
            self.combo_theme.setCurrentIndex(ti)
        self.combo_theme.currentIndexChanged.connect(self._on_theme_changed)
        form.addWidget(self.combo_theme)

        # 按键颜色：一排色块，点一下立刻换
        form.addWidget(self._field_label("按键颜色"))
        row_color = QHBoxLayout()
        row_color.setSpacing(8)
        self._accent_btns = {}
        cur_accent = self.config.get("ui_accent") or "blue"
        for key, cname, color in style_mod.ACCENTS:
            b = QPushButton(cname)
            b.setFixedSize(58, 30)
            b.setCheckable(True)
            b.setChecked(key == cur_accent)
            b.setStyleSheet(
                "QPushButton{background:%s;border:1px solid rgba(255,255,255,40);"
                "border-radius:8px;color:#101318;font-weight:600;}"
                "QPushButton:checked{border:2px solid #FFFFFF;}"
                "QPushButton:hover{background:%s;}" % (color, color))
            b.clicked.connect(lambda _=False, k=key: self._on_accent_changed(k))
            row_color.addWidget(b)
            self._accent_btns[key] = b
        row_color.addStretch(1)
        form.addLayout(row_color)

        # 按键样式：圆角 / 方块 / 胶囊 / 描边
        form.addWidget(self._field_label("按键样式"))
        self.combo_btn_style = QComboBox()
        for key, label in style_mod.BUTTON_STYLES:
            self.combo_btn_style.addItem(label, key)
        bs = self.combo_btn_style.findData(self.config.get("ui_button") or "round")
        if bs >= 0:
            self.combo_btn_style.setCurrentIndex(bs)
        self.combo_btn_style.currentIndexChanged.connect(self._on_btn_style_changed)
        form.addWidget(self.combo_btn_style)
        tip_ui = QLabel("按键颜色和样式改了立刻生效，也会记住；"
                        "「描边」是把按键改成透明底 + 主色边框。")
        tip_ui.setObjectName("FieldLabel")
        tip_ui.setWordWrap(True)
        form.addWidget(tip_ui)

        # 整套主题预设：一键换「底色 + 主色 + 按键形状」，不用一项项调
        form.addWidget(self._field_label("整套主题预设"))
        row_theme = QHBoxLayout()
        row_theme.setSpacing(6)
        for pid in ("omc_dark", "stone", "amethyst", "ice"):
            p = themes.get(pid)
            if not p:
                continue
            b = QPushButton(p["name"])
            b.setToolTip(p["desc"])
            b.clicked.connect(lambda _c=False, x=pid: self._apply_theme_preset(x))
            row_theme.addWidget(b)
        b_more_theme = QPushButton("更多主题…")
        b_more_theme.setToolTip("主题商店：10 套整套预设，可导出、可导入")
        b_more_theme.clicked.connect(self._goto_theme_store)
        row_theme.addWidget(b_more_theme)
        row_theme.addStretch(1)
        form.addLayout(row_theme)

        # 侧栏小猫挂件
        self.chk_cat = QCheckBox("左下角放一只小猫（点它会喵）")
        self.chk_cat.setChecked(
            True if self.config.get("ui_cat") is None
            else bool(self.config.get("ui_cat")))
        self.chk_cat.toggled.connect(self._on_cat_toggled)
        form.addWidget(self.chk_cat)

        # 背景图：导入自定义图片，或恢复默认深色
        form.addWidget(self._field_label(i18n.tr("label_background")))
        _bg_cur = self.config.get("background_image") or ""
        if _bg_cur.startswith("builtin:"):
            _bg_cur = self._wall_label(_bg_cur) or "内置壁纸"
        self.label_bg_name = QLabel(_bg_cur or i18n.tr("bg_default"))
        self.label_bg_name.setObjectName("FieldLabel")
        form.addWidget(self.label_bg_name)

        # 内置壁纸：自带几张我的世界风景，点一下直接换
        form.addWidget(self._field_label("内置壁纸"))
        self.combo_wall = QComboBox()
        self.combo_wall.addItem("不用（纯深色）", "")
        for fn, label in self.BUILTIN_WALLS:
            p = self._wall_path(fn)
            if os.path.exists(p):
                self.combo_wall.addItem(label, "builtin:" + fn)
        cur_bg = self.config.get("background_image") or ""
        wi = self.combo_wall.findData(cur_bg)
        self.combo_wall.setCurrentIndex(wi if wi >= 0 else 0)
        self.combo_wall.currentIndexChanged.connect(self._on_wall_changed)
        form.addWidget(self.combo_wall)

        self.btn_pick_bg = QPushButton(i18n.tr("btn_import_bg"))
        self.btn_pick_bg.clicked.connect(self._pick_background)
        self.btn_reset_bg = QPushButton(i18n.tr("btn_reset_bg"))
        self.btn_reset_bg.clicked.connect(self._reset_background)
        form.addWidget(self._row(self.btn_pick_bg, self.btn_reset_bg))

        # 随机壁纸：勾上后每次开启动器从内置风景里换一张
        self.chk_randwall = QCheckBox("每次启动随机换一张内置壁纸")
        self.chk_randwall.setChecked(bool(self.config.get("bg_random")))
        self.chk_randwall.setToolTip(
            "勾上后每次打开启动器，从内置的几张风景里随机选一张；"
            "自己导入的图片不会被换掉")
        self.chk_randwall.toggled.connect(self._on_rand_wall_toggled)
        self._sync_rand_wall_lock(self.chk_randwall.isChecked())
        form.addWidget(self.chk_randwall)

        # 壁纸亮度：0 = 原图亮度；往左提亮（最高再亮 40），往右压暗
        form.addWidget(self._field_label("壁纸亮度"))
        self.slider_bgdim = QSlider(Qt.Horizontal)
        self.slider_bgdim.setRange(-40, 80)
        self.slider_bgdim.setValue(int(self.config.get("bg_dim") or 0))
        self.slider_bgdim.setToolTip(
            "中间是原图亮度；往左提亮（拉到底最亮），往右压暗")
        self.slider_bgdim.valueChanged.connect(self._on_bg_dim_changed)
        self.slider_bgdim.sliderReleased.connect(self._save_bg_dim)
        form.addWidget(self.slider_bgdim)
        self.lbl_bgdim = QLabel("")
        self.lbl_bgdim.setObjectName("FieldLabel")
        form.addWidget(self.lbl_bgdim)
        self._on_bg_dim_changed(self.slider_bgdim.value())

        b_save = QPushButton(i18n.tr("btn_save"))
        b_save.setObjectName("PrimaryButton")
        b_save.clicked.connect(self._save_settings)
        form.addWidget(b_save)

        b_fb = QPushButton("反馈 / 报 Bug")
        b_fb.clicked.connect(self._open_feedback)
        form.addWidget(b_fb)

        # 更新：显示当前版本，可手动检查；更新源可改
        form.addWidget(self._field_label(i18n.tr("update_section")))
        self.label_version = QLabel(
            i18n.tr("update_current", update.VERSION))
        self.label_version.setObjectName("FieldLabel")
        form.addWidget(self.label_version)
        self.input_update_url = QLineEdit(self.config.get("update_url") or "")
        self.input_update_url.setPlaceholderText(update.DEFAULT_SOURCE)
        form.addWidget(self.input_update_url)
        btn_chk = QPushButton(i18n.tr("update_check"))
        btn_chk.clicked.connect(lambda: self._check_update(False))
        form.addWidget(self._row(btn_chk))

        self.check_auto_update = QCheckBox(
            "联网时自动更新（发现新版本自动下载，确认后重启换上）")
        self.check_auto_update.setChecked(self._auto_update_enabled())
        self.check_auto_update.toggled.connect(self._on_auto_update_toggled)
        form.addWidget(self.check_auto_update)

        # ===== 维护与工具 =====
        form.addWidget(self._field_label("维护与工具"))

        self.mem_hint = QLabel("")
        self.mem_hint.setObjectName("FieldLabel")
        self.mem_hint.setWordWrap(True)
        form.addWidget(self.mem_hint)
        b_mem = QPushButton("按这台电脑推荐内存")
        b_mem.clicked.connect(self._apply_mem_recommend)
        b_integrity = QPushButton("完整性校验")
        b_integrity.clicked.connect(self._run_integrity_check)
        form.addWidget(self._row(b_mem, b_integrity))

        # 内存预设：常配的几档一键切，不用拖着滑杆找
        preset = QHBoxLayout()
        preset.addWidget(QLabel("内存预设"))
        for mb in (2048, 4096, 6144, 8192, 16384):
            b_pre = QPushButton("%dG" % (mb // 1024))
            b_pre.setToolTip("直接设成 %d MB" % mb)
            b_pre.clicked.connect(lambda _c=False, m=mb: self._set_mem_preset(m))
            preset.addWidget(b_pre)
        preset.addStretch(1)
        form.addLayout(preset)

        # 出问题要给别人看日志时，一键把该收的都收进一个 zip
        b_logs = QPushButton("一键打包日志")
        b_logs.setToolTip("启动器日志 + 游戏 latest.log + crash-reports + 模组清单")
        b_logs.clicked.connect(self._pack_logs)
        form.addWidget(self._row(b_logs))

        # 设置备份：升级、换电脑、手滑改坏，都能从这里捞回来
        form.addWidget(self._field_label("设置备份"))
        self.cfg_bak_hint = QLabel("")
        self.cfg_bak_hint.setObjectName("FieldLabel")
        self.cfg_bak_hint.setWordWrap(True)
        form.addWidget(self.cfg_bak_hint)
        b_cfgbak = QPushButton("备份当前设置")
        b_cfgbak.setToolTip("把现在的 config.json 另存一份带版本号+时间的快照")
        b_cfgbak.clicked.connect(self._backup_config)
        b_cfgres = QPushButton("恢复最近备份")
        b_cfgres.setToolTip("用最近一份快照覆盖当前设置，覆盖前会先备份现在的")
        b_cfgres.clicked.connect(self._restore_config)
        b_cfgdir = QPushButton("打开备份文件夹")
        b_cfgdir.clicked.connect(self._open_config_backups)
        form.addWidget(self._row(b_cfgbak, b_cfgres, b_cfgdir))
        self._refresh_cfg_hint()

        form.addWidget(self._field_label("快捷键"))
        hk = self.config.get("hotkeys") or {}
        self.hk_full = QKeySequenceEdit(
            QKeySequence(hk.get("fullscreen") or "F11"))
        self.hk_skin = QKeySequenceEdit(
            QKeySequence(hk.get("skin") or "Ctrl+Shift+K"))
        self.hk_refresh = QKeySequenceEdit(
            QKeySequence(hk.get("refresh") or "F5"))
        self.hk_mplay = QKeySequenceEdit(
            QKeySequence(hk.get("music_play") or "Ctrl+Alt+M"))
        self.hk_mnext = QKeySequenceEdit(
            QKeySequence(hk.get("music_next") or "Ctrl+Alt+N"))
        self.hk_mprev = QKeySequenceEdit(
            QKeySequence(hk.get("music_prev") or "Ctrl+Alt+B"))
        for lab, ed in (("全屏开/关", self.hk_full),
                        ("跳到皮肤库", self.hk_skin),
                        ("刷新联机房间", self.hk_refresh),
                        ("音乐 播放/暂停", self.hk_mplay),
                        ("音乐 下一首", self.hk_mnext),
                        ("音乐 上一首", self.hk_mprev)):
            form.addWidget(self._row(QLabel(lab), ed))
            # 录完就还焦点：QKeySequenceEdit 录完还攥着键盘/焦点时，
            # 后面在任何地方按 F11 都会先被这个录入框吃掉，看起来就是「按了没反应」。
            try:
                ed.editingFinished.connect(ed.clearFocus)
            except Exception:
                pass
        b_hk = QPushButton("保存快捷键")
        b_hk.setToolTip("改完点这里生效，下次开启动器也按这套")
        b_hk.clicked.connect(self._save_hotkeys)
        form.addWidget(self._row(b_hk))

        b_av = QPushButton("加入杀毒白名单")
        b_av.setToolTip("把启动器目录加进 Windows Defender 排除项，需要管理员确认一次")
        b_av.clicked.connect(self._on_add_av_exclusion)
        form.addWidget(self._row(b_av))

        form.addWidget(self._field_label("JVM 参数模板"))
        self.combo_jvm = QComboBox()
        for key in jvmargs.keys():
            self.combo_jvm.addItem(jvmargs.label(key), key)
        cur_jvm = self.config.get("jvm_template") or "none"
        ji = self.combo_jvm.findData(cur_jvm)
        if ji >= 0:
            self.combo_jvm.setCurrentIndex(ji)
        form.addWidget(self.combo_jvm)

        self.check_auto_backup = QCheckBox(
            "启动游戏前自动备份存档（只复制，不动原存档）")
        self.check_auto_backup.setChecked(bool(self.config.get("auto_backup")))
        form.addWidget(self.check_auto_backup)

        # 存档定时自动备份：玩游戏时每隔一段时间查一次，存档变了才备份
        form.addWidget(self._field_label("定时自动备份存档"))
        self.combo_auto_backup_int = QComboBox()
        for label, mins in (("关闭", 0), ("每 5 分钟检查一次", 5),
                            ("每 10 分钟检查一次", 10),
                            ("每 15 分钟检查一次", 15),
                            ("每 30 分钟检查一次", 30)):
            self.combo_auto_backup_int.addItem(label, mins)
        ab = int(self.config.get("auto_backup_interval") or 0)
        ai = self.combo_auto_backup_int.findData(ab)
        if ai >= 0:
            self.combo_auto_backup_int.setCurrentIndex(ai)
        self.combo_auto_backup_int.currentIndexChanged.connect(
            self._on_auto_backup_int_changed)
        form.addWidget(self.combo_auto_backup_int)
        ab_tip = QLabel("开着游戏时后台盯着 level.dat，存档有变化才备份一份，"
                        "不会一直占硬盘。存档出问题可以在「工具」页回滚。")
        ab_tip.setObjectName("FieldLabel")
        ab_tip.setWordWrap(True)
        form.addWidget(ab_tip)

        form.addWidget(self._field_label("每个存档保留备份数量"))
        self.combo_backup_keep = QComboBox()
        for n in (3, 5, 8, 10):
            self.combo_backup_keep.addItem("%d 份" % n, n)
        keep = int(self.config.get("backup_keep") or 5)
        ki = self.combo_backup_keep.findData(keep)
        if ki >= 0:
            self.combo_backup_keep.setCurrentIndex(ki)
        form.addWidget(self.combo_backup_keep)

        b_backup = QPushButton("立即备份存档")
        b_backup.clicked.connect(self._on_backup_now)
        b_restore = QPushButton("还原备份")
        b_restore.clicked.connect(self._on_restore_backup)
        form.addWidget(self._row(b_backup, b_restore))

        b_crash = QPushButton("分析崩溃日志")
        b_crash.clicked.connect(self._analyze_crash)
        b_servers = QPushButton("收藏服务器")
        b_servers.clicked.connect(self._open_servers)
        form.addWidget(self._row(b_crash, b_servers))

        self.check_multi = QCheckBox("允许多开同一个版本（同时开几个游戏窗口）")
        self.check_multi.setChecked(bool(self.config.get("multi_instance")))
        form.addWidget(self.check_multi)

        self.check_tray = QCheckBox("点关闭时缩到托盘，不退出启动器")
        self.check_tray.setChecked(bool(self.config.get("minimize_to_tray")))
        self.check_tray.toggled.connect(self._on_tray_toggled)
        form.addWidget(self.check_tray)

        # ===== 启动与动画 =====
        form.addWidget(self._field_label("启动与动画"))
        st_auto = autostart.state()
        self.chk_autostart = QCheckBox("开机自动打开启动器")
        self.chk_autostart.setChecked(bool(st_auto.get("enabled")))
        if not st_auto.get("supported"):
            self.chk_autostart.setChecked(False)
            self.chk_autostart.setEnabled(False)
            self.chk_autostart.setText("开机自动打开启动器（这台系统请到系统设置里手动加）")
        self.chk_autostart.toggled.connect(self._on_autostart_toggled)
        form.addWidget(self.chk_autostart)
        self.lbl_autostart = QLabel("")
        self.lbl_autostart.setObjectName("FieldLabel")
        self.lbl_autostart.setWordWrap(True)
        self.lbl_autostart.setText("开机启动项：" + (
            "已开启" if st_auto.get("enabled") else "未开启"))
        form.addWidget(self.lbl_autostart)

        self.chk_trailer = QCheckBox("启动页自动播放预告片")
        self.chk_trailer.setToolTip("关掉后不再加载播放器，启动更快、更省内存")
        self.chk_trailer.setChecked(self.config.get("trailer_on") is not False)
        self.chk_trailer.toggled.connect(self._on_trailer_toggled)
        form.addWidget(self.chk_trailer)

        self.chk_anim = QCheckBox("启动时播窗口淡入动画")
        self.chk_anim.setToolTip("关掉后窗口直接出现，看着更快；小内存机器建议关掉")
        self.chk_anim.setChecked(self.config.get("anim_on") is not False)
        self.chk_anim.toggled.connect(self._on_anim_toggled)
        form.addWidget(self.chk_anim)

        self.chk_modcheck = QCheckBox("启动前自动检查模组冲突")
        self.chk_modcheck.setToolTip(
            "启动前扫一遍 mods：缺前置、同一个模组装两份、版本对不上一律先提醒")
        self.chk_modcheck.setChecked(self.config.get("mod_precheck") is not False)
        self.chk_modcheck.toggled.connect(self._on_modcheck_toggled)
        form.addWidget(self.chk_modcheck)

        form.addWidget(self._field_label("新版本默认游戏设置"))
        self.check_gopt = QCheckBox("装完新版本就把这套游戏设置写进 options.txt")
        self.check_gopt.setChecked(bool(self.config.get("game_options_apply")))
        self.check_gopt.toggled.connect(self._on_gopt_toggled)
        form.addWidget(self.check_gopt)
        b_gopt = QPushButton("设置新版本的默认游戏选项")
        b_gopt.clicked.connect(self._open_game_options)
        b_gopt_all = QPushButton("对当前版本也写一次")
        b_gopt_all.clicked.connect(self._apply_game_options_now)
        form.addWidget(self._row(b_gopt, b_gopt_all))

        # 兼容性自检：老系统 / 缺运行库 / 内存吃紧的机器，用户点一下就能看到原因
        form.addWidget(self._field_label("这台电脑能不能跑"))
        b_syschk = QPushButton("运行兼容性自检")
        b_syschk.clicked.connect(self._show_syscheck)
        form.addWidget(self._row(b_syschk))
        sys_tip = QLabel("会检查系统版本、位数、CPU 指令集、运行库、内存和磁盘，"
                         "结果也会写进 crash 目录旁边的 syscheck.log。")
        sys_tip.setObjectName("FieldLabel")
        sys_tip.setWordWrap(True)
        form.addWidget(sys_tip)

        # 桌面快捷方式：有些机器首次启动时建失败了（桌面被重定向 / 权限被拦），
        # 这里给一个手动补一个的入口，顺便显示现在到底有没有。
        form.addWidget(self._field_label("桌面快捷方式"))
        self.lbl_shortcut = QLabel("")
        self.lbl_shortcut.setObjectName("FieldLabel")
        self.lbl_shortcut.setWordWrap(True)
        form.addWidget(self.lbl_shortcut)
        b_shortcut = QPushButton("添加到桌面")
        b_shortcut.clicked.connect(self._add_desktop_shortcut)
        form.addWidget(self._row(b_shortcut))
        self._refresh_shortcut_label()

        # 聊天违禁词：好友私聊和群聊都过一遍，默认开
        form.addWidget(self._field_label("聊天自动屏蔽违禁词"))
        self.cb_chat_filter = QCheckBox("好友私聊 / 群聊里出现脏话、引流、诈骗词自动打码")
        self.cb_chat_filter.setChecked(self._chat_filter_on())
        self.cb_chat_filter.stateChanged.connect(self._on_chat_filter_toggled)
        form.addWidget(self.cb_chat_filter)
        tip_cf = QLabel("默认打开。打码只在本机做，不联网、不上报；"
                        "发出去和收到的都会被替换成＊。关掉后原样显示。")
        tip_cf.setObjectName("FieldLabel")
        tip_cf.setWordWrap(True)
        form.addWidget(tip_cf)

        # 全局免打扰 + 静音
        from core import notifyprefs as _np0
        self.cb_global_dnd = QCheckBox("全局免打扰：除「特别关心」的好友外，"
                                       "谁发消息都不弹提示、不响")
        self.cb_global_dnd.setChecked(_np0.global_dnd())
        self.cb_global_dnd.stateChanged.connect(self._on_global_dnd)
        self.cb_global_dnd.toggled.connect(self._excl_dnd)
        form.addWidget(self.cb_global_dnd)
        self.cb_no_sound = QCheckBox("只关提示音，右下角提示还留着")
        self.cb_no_sound.setChecked(_np0.no_sound())
        self.cb_no_sound.stateChanged.connect(self._on_no_sound)
        self.cb_no_sound.toggled.connect(self._excl_no_sound)
        form.addWidget(self.cb_no_sound)
        tip_dnd = QLabel("注意：闹钟和计时器的铃声不受这里影响，永远是响的。"
                         "免打扰只挡聊天消息，消息照样收进列表，去点开就能看到。")
        tip_dnd.setObjectName("FieldLabel")
        tip_dnd.setWordWrap(True)
        form.addWidget(tip_dnd)

        # AI 搭子：默认本机引擎，填了接口就升级成大模型
        form.addWidget(self._field_label("AI 搭子「小矿」"))
        ai_tip = QLabel("好友列表里的「小矿」默认用本机引擎，能聊天、能改设置和放歌，"
                        "不联网也不花钱。想让它能回答任意问题，填一个 OpenAI 兼容接口"
                        "（比如你自己的中转地址 + key），留空就一直是本机模式。")
        ai_tip.setObjectName("FieldLabel")
        ai_tip.setWordWrap(True)
        form.addWidget(ai_tip)
        self.input_ai_base = QLineEdit(self.config.get("ai_api_base") or "")
        self.input_ai_base.setPlaceholderText(
            "接口地址，例如 https://api.openai.com/v1（留空=本机模式）")
        form.addWidget(self.input_ai_base)
        self.input_ai_key = QLineEdit(self.config.get("ai_api_key") or "")
        self.input_ai_key.setPlaceholderText("API Key（只存在本机，不上传）")
        self.input_ai_key.setEchoMode(QLineEdit.Password)
        form.addWidget(self.input_ai_key)
        row_ai = QHBoxLayout()
        self.input_ai_model = QLineEdit(self.config.get("ai_model") or "")
        self.input_ai_model.setPlaceholderText("模型名，例如 gpt-4o-mini")
        row_ai.addWidget(self.input_ai_model, 1)
        b_ai_save = QPushButton("保存接口")
        b_ai_save.clicked.connect(self._save_ai_api)
        row_ai.addWidget(b_ai_save)
        b_ai_test = QPushButton("试一句")
        b_ai_test.setToolTip("用当前配置问小矿一句话，看通不通")
        b_ai_test.clicked.connect(self._test_ai_api)
        row_ai.addWidget(b_ai_test)
        form.addLayout(row_ai)
        self.lbl_ai_state = QLabel("")
        self.lbl_ai_state.setObjectName("FieldLabel")
        self.lbl_ai_state.setWordWrap(True)
        form.addWidget(self.lbl_ai_state)

        v.addWidget(card(form))
        v.addStretch(1)
        return self._scroll_wrap(page)

    def _open_seed_map(self):
        """种子地图：本地算结构遗迹坐标和生物群系，也能渲染存档已探索区域。"""
        dlg = QDialog(self)
        dlg.setWindowTitle("种子地图")
        dlg.resize(980, 820)
        v = QVBoxLayout(dlg)

        # 顶部像素横幅：让这块有点画面感
        art_dir = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                               "maps")
        try:
            os.makedirs(art_dir, exist_ok=True)
        except OSError:
            art_dir = os.path.expanduser("~")
        banner = QLabel()
        banner.setObjectName("SeedBanner")
        banner.setAlignment(Qt.AlignCenter)
        try:
            try:
                dpr = float(self.devicePixelRatioF() or 1.0)
            except Exception:
                dpr = 1.0
            png = seedart.banner_png(os.path.join(art_dir, "seed_banner.png"),
                                     dpr=dpr)
            pm = QPixmap(png)
            if not pm.isNull():
                pm.setDevicePixelRatio(dpr)
                banner.setPixmap(pm)
                banner.setFixedHeight(int(round(pm.height() / dpr)))
        except Exception:
            pass
        v.addWidget(banner)

        tip = QLabel("全部在本机算，不联网也不跳网页。填种子就能算出村庄、要塞、"
                     "海底神殿、遗迹这些的坐标，也能查任意坐标是什么生物群系。"
                     "下面还能读你存档里的区块，画出已经探索过的区域。")
        tip.setWordWrap(True)
        tip.setObjectName("FieldLabel")
        v.addWidget(tip)
        if not seedcalc.available():
            bad = QLabel("本机计算器没找到（bin/omcseeds.exe），种子坐标暂时算不了；"
                         "看存档地图不受影响。")
            bad.setWordWrap(True)
            bad.setObjectName("FieldLabel")
            v.addWidget(bad)

        r1 = QHBoxLayout()
        r1.addWidget(QLabel("种子"))
        self.seed_input = QLineEdit()
        self.seed_input.setPlaceholderText("数字或文字种子，比如 123456 / abc")
        self.seed_input.setText(self.config.get("last_seed") or "")
        r1.addWidget(self.seed_input, 1)
        self.seed_ver = QComboBox()
        for ver in ("1.21", "1.20", "1.19", "1.18", "1.17", "1.16"):
            self.seed_ver.addItem(ver, ver)
        r1.addWidget(self.seed_ver)
        self.seed_radius = QComboBox()
        for txt, val in (("找 ±1000", 1000), ("找 ±3000", 3000),
                         ("找 ±5000", 5000), ("找 ±6000", 6000),
                         ("找 ±10000", 10000)):
            self.seed_radius.addItem(txt, val)
        self.seed_radius.setCurrentIndex(1)
        r1.addWidget(self.seed_radius)
        b_struct = QPushButton("算遗迹坐标")
        b_struct.clicked.connect(
            lambda: self._calc_seed_structures(struct_list, map_state))
        r1.addWidget(b_struct)
        v.addLayout(r1)

        struct_list = QListWidget()
        struct_list.setMaximumHeight(140)
        struct_list.itemDoubleClicked.connect(
            lambda it: self._copy_seed_text(it.text(), map_state))
        v.addWidget(struct_list)

        r3 = QHBoxLayout()
        r3.addWidget(QLabel("坐标 X"))
        self.seed_x = QLineEdit("0")
        self.seed_x.setFixedWidth(80)
        r3.addWidget(self.seed_x)
        r3.addWidget(QLabel("Z"))
        self.seed_z = QLineEdit("0")
        self.seed_z.setFixedWidth(80)
        r3.addWidget(self.seed_z)
        b_biome = QPushButton("查这个点的生物群系")
        b_biome.clicked.connect(lambda: self._query_seed_biome(map_state))
        r3.addWidget(b_biome)
        b_biomemap = QPushButton("画出附近群系图")
        b_biomemap.clicked.connect(
            lambda: self._draw_seed_biome_map(map_label, map_state, legend))
        r3.addWidget(b_biomemap)
        self.seed_map_size = QComboBox()
        for txt, val in (("图 ±1024", 1024), ("图 ±2048", 2048),
                         ("图 ±4096", 4096)):
            self.seed_map_size.addItem(txt, val)
        self.seed_map_size.setCurrentIndex(1)
        r3.addWidget(self.seed_map_size)
        r3.addStretch(1)
        v.addLayout(r3)

        # 标记 + 导出
        r3b = QHBoxLayout()
        r3b.addWidget(QLabel("标记名"))
        self.seed_mark_name = QLineEdit()
        self.seed_mark_name.setPlaceholderText("比如 出生点 / 我的基地")
        self.seed_mark_name.setMaximumWidth(220)
        r3b.addWidget(self.seed_mark_name)
        r3b.addStretch(1)
        b_mark = QPushButton("当前位置存为标记")
        b_mark.clicked.connect(lambda: self._add_seed_mark(map_state))
        r3b.addWidget(b_mark)
        b_clearmark = QPushButton("清空标记")
        b_clearmark.clicked.connect(lambda: self._clear_seed_marks(map_state))
        r3b.addWidget(b_clearmark)
        b_exports = QPushButton("导出这张图")
        b_exports.clicked.connect(lambda: self._export_seed_map(map_label, map_state))
        r3b.addWidget(b_exports)
        v.addLayout(r3b)

        r2 = QHBoxLayout()
        r2.addWidget(QLabel("存档"))
        self.seed_world = QComboBox()
        worlds = self._list_worlds()
        if worlds:
            for name, path in worlds:
                self.seed_world.addItem(name, path)
        else:
            self.seed_world.addItem("（游戏目录里还没有存档）", "")
        r2.addWidget(self.seed_world, 1)
        b_seed = QPushButton("用这个存档的种子")
        b_seed.clicked.connect(lambda: self._use_world_seed(map_state))
        r2.addWidget(b_seed)
        b_map = QPushButton("看这个存档的地图")
        b_map.clicked.connect(
            lambda: (legend.setVisible(False),
                     self._render_world_map(map_label, map_state)))
        r2.addWidget(b_map)
        v.addLayout(r2)
        self.seed_world.currentIndexChanged.connect(
            lambda *_: self._use_world_seed(map_state))

        scroll = QScrollArea()
        scroll.setWidgetResizable(False)
        map_label = QLabel("还没画。填种子点「画出附近群系图」，"
                           "或者选一个存档点「看这个存档的地图」。")
        map_label.setAlignment(Qt.AlignCenter)
        map_label.setObjectName("WorldMap")
        scroll.setWidget(map_label)
        v.addWidget(scroll, 1)

        legend = QLabel()
        legend.setObjectName("SeedLegend")
        legend.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        legend.setVisible(False)
        v.addWidget(legend)

        map_state = QLabel("")
        map_state.setObjectName("FieldLabel")
        map_state.setWordWrap(True)
        v.addWidget(map_state)

        foot = QHBoxLayout()
        foot.addStretch(1)
        bc = QPushButton("关闭")
        bc.clicked.connect(dlg.accept)
        foot.addWidget(bc)
        v.addLayout(foot)
        dlg.exec_()

    def _list_worlds(self):
        gd = self.config.get("game_dir") or ""
        saves = os.path.join(gd, "saves")
        out = []
        if not os.path.isdir(saves):
            return out
        try:
            for n in sorted(os.listdir(saves)):
                w = os.path.join(saves, n)
                if os.path.isdir(w) and os.path.isdir(os.path.join(w, "region")):
                    out.append((n, w))
        except OSError:
            pass
        return out

    def _seed_params(self, state=None):
        """取种子/版本，顺手记住上次填的种子。"""
        text = (self.seed_input.text() or "").strip()
        if not text:
            self.seed_input.setFocus()
            if state is not None:
                state.setText("先填种子。")
            return None
        seed = seedmap.java_seed(text)
        ver = seedcalc.norm_version(self.seed_ver.currentData() or "1.21")
        try:
            self.config.set("last_seed", text)
            self.config.save()
        except Exception:
            pass
        return text, seed, ver

    def _copy_seed_text(self, text, state=None):
        QApplication.clipboard().setText(text or "")
        if state is not None:
            state.setText("已复制到剪贴板：%s" % text)

    def _calc_seed_structures(self, listw, state):
        """本地算村庄、要塞、神殿、遗迹的坐标。"""
        if not seedcalc.available():
            state.setText("本地计算器缺失（bin/omcseeds.exe），算不了。")
            return
        got = self._seed_params(state)
        if not got:
            return
        text, seed, ver = got
        radius = self.seed_radius.currentData() or 3000
        listw.clear()
        state.setText("正在算遗迹坐标……（范围越大越久，几千格大概一两秒）")
        w = self._track(SeedStructWorker(ver, seed, radius))
        self._seed_worker = w

        def ok(data):
            items = data.get("structures") or []
            self._seed_last_structs = items
            sp = data.get("spawn") or {}

            def row(text, color):
                it = QListWidgetItem(text)
                try:
                    it.setIcon(QIcon(seedart.struct_icon(color, 14)))
                except Exception:
                    pass
                listw.addItem(it)

            if sp:
                row("出生点：X %d  Z %d" % (sp.get("x", 0), sp.get("z", 0)),
                    "#eeeeee")
            groups = {}
            order = []
            for s in items:
                t = s.get("type") or ""
                if t not in groups:
                    groups[t] = []
                    order.append(t)
                groups[t].append(s)
            for t in order:
                pts = groups[t]
                label = seedcalc.STRUCT_LABELS.get(t, t)
                desc = "   ".join("X %d Z %d" % (p.get("x", 0), p.get("z", 0))
                                  for p in pts[:3])
                row("%s：%s" % (label, desc), seedcalc.struct_color(t))
            if not listw.count():
                row("这个范围里没算出结构，把范围调大再试。", "#888888")
            state.setText("算好了：%d 类结构、%d 个点（种子 %s，版本 %s，"
                          "范围 ±%d）。双击某行可以把那一行复制走；"
                          "点「画出附近群系图」会把它们标在地图上。"
                          % (len(order), len(items), text, ver, radius))

        w.done.connect(ok)
        w.failed.connect(lambda e: state.setText("算失败：" + str(e)))
        w.start()

    def _query_seed_biome(self, state):
        """查某个坐标是什么生物群系。"""
        if not seedcalc.available():
            state.setText("本地计算器缺失（bin/omcseeds.exe），算不了。")
            return
        got = self._seed_params(state)
        if not got:
            return
        text, seed, ver = got
        try:
            x = int((self.seed_x.text() or "0").strip())
            z = int((self.seed_z.text() or "0").strip())
        except ValueError:
            state.setText("X / Z 要填整数。")
            return
        state.setText("正在查 X %d Z %d ……" % (x, z))
        try:
            r = seedcalc.biome_at(ver, seed, x, z)
        except Exception as e:
            state.setText("查询失败：" + str(e))
            return
        name = r.get("biome") or ""
        state.setText("种子 %s（版本 %s）在 X %d Z %d 的生物群系：%s（%s）"
                      % (text, ver, x, z, seedcalc.biome_cn(name), name))
        self._log("种子群系：%s @ %d,%d = %s" % (text, x, z, name))

    def _draw_seed_biome_map(self, lab, state, legend=None):
        """以当前坐标为中心，本地算一片区域并画成生物群系图。"""
        if not seedcalc.available():
            state.setText("本地计算器缺失（bin/omcseeds.exe），算不了。")
            return
        got = self._seed_params(state)
        if not got:
            return
        text, seed, ver = got
        try:
            cx = int((self.seed_x.text() or "0").strip())
            cz = int((self.seed_z.text() or "0").strip())
        except ValueError:
            state.setText("X / Z 要填整数。")
            return
        try:
            size = int(self.seed_map_size.currentData() or 2048)
        except Exception:
            size = 2048
        cache = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                             "maps")
        os.makedirs(cache, exist_ok=True)
        out = os.path.join(cache, "seedbiome_%d.png" % int(time.time()))
        marks = []
        for s in getattr(self, "_seed_last_structs", []) or []:
            marks.append((s.get("x", 0), s.get("z", 0), (255, 80, 80),
                          s.get("type") or ""))
        # 自己存的书签，用青色小方块标出来，跟结构的红框区分开
        for m in self._load_seed_marks(text):
            try:
                marks.append((int(m.get("x", 0)), int(m.get("z", 0)),
                              (80, 220, 255), m.get("name") or "标记"))
            except Exception:
                pass
        state.setText("正在算 %d×%d 范围的生物群系……" % (size, size))
        lab.setText("正在算……")
        w = self._track(SeedBiomeMapWorker(ver, seed, cx, cz, size, out,
                                           scale=4, marks=marks))
        self._seedmap_worker = w

        def ok(png, info):
            try:
                _apply_biome_map(png, info)
            except RuntimeError:
                pass   # 对话框已经被关掉了，别把结果往上贴

        def _apply_biome_map(png, info):
            pm = QPixmap(png)
            if pm.isNull():
                state.setText("画出来的图读不回来。")
                return
            pm = pm.scaled(pm.width() * 2, pm.height() * 2,
                           Qt.KeepAspectRatio, Qt.FastTransformation)
            lab.setPixmap(pm)
            lab.setFixedSize(pm.size())
            names = info.get("biomes") or []
            if legend is not None:
                try:
                    lp = seedart.legend_png(
                        names, os.path.join(cache, "legend_%d.png"
                                            % int(time.time())), width=900)
                    if lp:
                        legend.setPixmap(QPixmap(lp))
                        legend.setVisible(True)
                    else:
                        legend.setVisible(False)
                except Exception:
                    legend.setVisible(False)
            state.setText("已画好：中心 X %d Z %d，覆盖 %d 格 × %d 格，%d 种生物群系"
                          "（%s）。红框是从「算出结构」里带过来的位置。"
                          % (cx, cz, info.get("w", 0) * 4, info.get("h", 0) * 4,
                             len(names),
                             "、".join(seedcalc.biome_cn(n) for n in names[:8])))

        w.done.connect(ok)
        w.failed.connect(lambda e: (state.setText("算失败：" + str(e)),
                                    lab.setText("这片还没算出来")))
        w.start()

    # ---------- 种子地图：书签标记 / 导出图片
    def _seed_marks_path(self):
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher", "maps")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "seed_marks.json")

    def _load_all_marks(self):
        try:
            with open(self._seed_marks_path(), encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _load_seed_marks(self, text):
        items = self._load_all_marks().get(text or "") or []
        return [m for m in items if isinstance(m, dict)]

    def _add_seed_mark(self, state=None):
        text = (self.seed_input.text() or "").strip()
        if not text:
            if state is not None:
                state.setText("先填种子，再存标记。")
            return
        try:
            x = int((self.seed_x.text() or "0").strip())
            z = int((self.seed_z.text() or "0").strip())
        except ValueError:
            if state is not None:
                state.setText("X / Z 要填整数。")
            return
        name = (self.seed_mark_name.text() or "").strip() or "标记"
        data = self._load_all_marks()
        items = data.get(text) or []
        items.append({"x": x, "z": z, "name": name})
        data[text] = items
        try:
            with open(self._seed_marks_path(), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            if state is not None:
                state.setText("标记没存下来：" + str(e))
            return
        if state is not None:
            state.setText("已存标记「%s」X %d Z %d，重画群系图就会用青色标出来。"
                          % (name, x, z))
        self._log("种子标记：%s %d,%d（种子 %s）" % (name, x, z, text))

    def _clear_seed_marks(self, state=None):
        text = (self.seed_input.text() or "").strip()
        data = self._load_all_marks()
        n = len(data.get(text) or [])
        data.pop(text, None)
        try:
            with open(self._seed_marks_path(), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        if state is not None:
            state.setText("清掉了这个种子的 %d 个标记。" % n)

    def _export_seed_map(self, lab, state=None):
        pm = lab.pixmap()
        if pm is None or pm.isNull():
            if state is not None:
                state.setText("先画出一张图再导出。")
            return
        from PySide6.QtWidgets import QFileDialog
        out, _f = QFileDialog.getSaveFileName(
            self, "导出群系图", "群系图_%d.png" % int(time.time()),
            "PNG 图片 (*.png)")
        if not out:
            return
        if pm.save(out, "PNG"):
            if state is not None:
                state.setText("图已存到：%s" % out)
            self._log("导出群系图 → %s" % out)
        elif state is not None:
            state.setText("存图失败，换个路径试试。")

    def _use_world_seed(self, state=None):
        """把选中存档的种子读出来填进种子框。"""
        wd = self.seed_world.currentData()
        if not wd:
            return
        seed = seedmap.read_world_seed(wd)
        if seed is None:
            if state is not None:
                state.setText("这个存档的 level.dat 里没读到种子（可能是很老的存档格式）。")
            return
        self.seed_input.setText(str(seed))
        self.config.set("last_seed", str(seed))
        if state is not None:
            state.setText("已读到存档「%s」的种子：%d。点「算遗迹坐标」"
                          "看村庄、要塞、遗迹在哪。"
                          % (os.path.basename(wd), seed))
        self._log("存档种子：%d（%s）" % (seed, os.path.basename(wd)))

    def _render_world_map(self, lab, state):
        wd = self.seed_world.currentData()
        if not wd:
            state.setText("游戏目录里没找到带 region 的存档。")
            return
        cache = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                             "maps")
        os.makedirs(cache, exist_ok=True)
        out = os.path.join(cache, "world_%d.png" % int(time.time()))
        state.setText("正在读区块、画地图......（大存档要几秒）")
        lab.setText("正在画......")
        w = self._track(WorldMapWorker(wd, out, max_regions=12, scale=2))
        self._map_worker = w

        def ok(png, info):
            pm = QPixmap(png)
            if pm.isNull():
                state.setText("画出来的图读不回来。")
                return
            lab.setPixmap(pm)
            lab.setFixedSize(pm.size())
            names = info.get("biomes") or []
            cols = info.get("chunks", 0)
            state.setText("已画好：约 %d 个已探索区块，%d 种生物群系（%s）。"
                          "点「看这个存档的地图」换存档重画。"
                          % (max(1, cols // 256), len(names),
                             "、".join(n.replace("minecraft:", "")
                                       for n in names[:8])))

        w.done.connect(ok)
        w.failed.connect(lambda e: (
            state.setText("渲染失败：" + str(e)), lab.setText("这个存档还没画出来")))
        w.start()

    def _apply_ui_style(self, force=False):
        """按当前配置套一遍样式表（主题 + 按键颜色 + 按键样式）。

        以前是「下拉换一项就同步 setStyleSheet 一次」：QSS 一改，Qt 会把主窗
        里 1600 多个控件全部重新 polish 一遍，实测单次 2~3 秒；用户拖着主题
        下拉框上下浏览一遍，等于连着卡好几次，看起来就是界面卡死。
        现在三件事一起做：
          1. 生成的 QSS 和已经套着的那份一样就直接返回，不重复折腾；
          2. 250ms 内的连续改动合并，只应用最后一次；
          3. 真正应用前先把等待光标和标题里的提示画出来 —— 用户在「等」，
             而不是以为程序死了。
        """
        try:
            qss = style_mod.qss(
                self.config.get("theme") or "dark",
                self.config.get("ui_accent") or "blue",
                self.config.get("ui_button") or "round")
        except Exception as e:
            self._log("换样式失败：" + str(e))
            return
        if not force and qss == getattr(self, "_qss_now", None):
            return
        self._qss_pending = qss
        timer = getattr(self, "_qss_timer", None)
        if timer is None:
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._apply_ui_style_now)
            self._qss_timer = timer
        timer.start(250)

    def _apply_ui_style_now(self):
        """真正把待应用的样式表套上去（只在防抖计时到点后跑一次）。"""
        qss = getattr(self, "_qss_pending", "")
        if not qss or qss == getattr(self, "_qss_now", None):
            return
        app = QApplication.instance()
        if app is None:
            return
        base = getattr(self, "_title_base", None) or i18n.tr("app_title")
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
        except Exception:
            pass
        # 先给个反馈：改标题和刷一次事件都很便宜，套样式才是那两三秒
        try:
            self.setWindowTitle(base + "　|　正在换主题…")
            app.processEvents()
        except Exception:
            pass
        t0 = time.monotonic()
        try:
            # 套的过程中别让 Qt 一边重画一边等：先冻结重绘，套完统一刷一次
            self.setUpdatesEnabled(False)
            # 只把样式表套在「主窗 + 它的子控件」上，别用 app.setStyleSheet：
            # 实测主窗 1893 个控件，app 级要 2.9 秒，窗口级只要 0.6 秒
            # （app 级会把每个顶层窗口都再刷一遍，包括已经隐藏的那些）。
            self.setStyleSheet(qss)
            # 独立顶层窗口（提示条、闹钟响铃窗、AI 聊天窗）不在主窗的父子链里，
            # 单独补一遍；这类窗口控件很少，加起来也就几十毫秒。
            seen = [self]
            try:
                for tw in app.topLevelWidgets():
                    if tw is None or tw in seen:
                        continue
                    seen.append(tw)
                    if not tw.isWindow() or tw.parent() is not None:
                        continue
                    # 提示条这类窗口自带一套配色（自绘卡片），别拿主题覆盖掉
                    if tw.styleSheet():
                        continue
                    try:
                        tw.setStyleSheet(qss)
                    except Exception:
                        continue
            except Exception:
                pass
            self._qss_now = qss
        except Exception as e:
            self._log("换样式失败：" + str(e))
            self._log("换样式失败：" + str(e))
        finally:
            try:
                self.setUpdatesEnabled(True)
                self.update()
                app.processEvents()
            except Exception:
                pass
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass
            # 标题回到更新状态那一句（没更新任务就回到纯标题）
            try:
                self._set_update_title(getattr(self, "_upd_title_last", "") or "")
            except Exception:
                try:
                    self.setWindowTitle(base)
                except Exception:
                    pass
        self._log("换主题完成，用时 %.2f 秒" % (time.monotonic() - t0))

    def _on_accent_changed(self, key):
        self.config.set("ui_accent", key)
        try:
            self.config.save()
        except Exception:
            pass
        for k, b in getattr(self, "_accent_btns", {}).items():
            b.setChecked(k == key)
        self._apply_ui_style()
        self._log("按键颜色：%s" % (style_mod.ACCENT_MAP.get(key, key)))

    def _on_btn_style_changed(self, _idx=0):
        key = self.combo_btn_style.currentData() or "round"
        self.config.set("ui_button", key)
        try:
            self.config.save()
        except Exception:
            pass
        self._apply_ui_style()
        self._log("按键样式：%s" % key)

    def _on_cat_toggled(self, on):
        self.config.set("ui_cat", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        cat = getattr(self, "cat_pet", None)
        if cat is not None:
            cat.setVisible(bool(on))

    def _on_theme_changed(self, _idx=0):
        theme = self.combo_theme.currentData() or "dark"
        self.config.set("theme", theme)
        try:
            self.config.save()
        except Exception:
            pass
        self._apply_ui_style()
        name = {"light": "浅色", "night": "暗夜", "sakura": "樱花"}.get(
            theme, "深色")
        self._log("界面主题：%s" % name)

    def _on_game_lang_changed(self, _idx=0):
        code = self.combo_game_lang.currentData() or ""
        self.config.set("game_language", code)
        try:
            self.config.save()
        except Exception:
            pass
        if code:
            self._log("游戏内语言设为 %s，下次启动游戏生效" % code)

    def _on_gopt_toggled(self, on):
        self.config.set("game_options_apply", bool(on))
        try:
            self.config.save()
        except Exception:
            pass

    def _open_game_options(self):
        """一整套游戏内设置，装新版本时写进 options.txt。"""
        dlg = QDialog(self)
        dlg.setWindowTitle("新版本默认游戏设置")
        dlg.resize(780, 640)
        v = QVBoxLayout(dlg)
        tip = QLabel("这些设置只影响新装的版本；options.txt 里已经有的项不会被覆盖，"
                     "你自己在游戏里调过的不会被动。")
        tip.setWordWrap(True)
        tip.setObjectName("FieldLabel")
        v.addWidget(tip)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        form = QFormLayout(inner)
        cur = dict(self.config.get("game_options") or {})
        widgets = {}

        def set_widget(w, kind, val):
            if kind == "c":
                i = w.findData(str(val))
                w.setCurrentIndex(i if i >= 0 else 0)
            elif kind == "b":
                w.setChecked(bool(val))
            elif kind == "i":
                w.setValue(int(val))
            else:
                w.setValue(int(round(float(val) * 100)))

        for key, label, kind, choices, dflt in game_options.SPEC:
            val = cur.get(key, dflt)
            if kind == "c":
                w = QComboBox()
                for c in choices:
                    w.addItem(str(c), str(c))
            elif kind == "b":
                w = QCheckBox("开")
            elif kind == "i":
                w = QSpinBox()
                w.setRange(int(choices[0]), int(choices[1]))
            else:
                w = QSpinBox()
                w.setRange(0, 100)
                w.setSuffix(" %")
            set_widget(w, kind, val)
            form.addRow(QLabel(label), w)
            widgets[key] = (kind, w)

        scroll.setWidget(inner)
        v.addWidget(scroll, 1)

        row = QHBoxLayout()
        b_reset = QPushButton("全部恢复默认")
        b_cancel = QPushButton("取消")
        b_ok = QPushButton("保存")
        b_ok.setObjectName("PrimaryButton")
        row.addWidget(b_reset)
        row.addStretch(1)
        row.addWidget(b_cancel)
        row.addWidget(b_ok)
        v.addLayout(row)

        def do_reset():
            for key, (kind, w) in widgets.items():
                set_widget(w, kind, game_options.BY_KEY[key][4])

        def do_save():
            data = {}
            for key, (kind, w) in widgets.items():
                if kind == "c":
                    data[key] = w.currentData()
                elif kind == "b":
                    data[key] = bool(w.isChecked())
                elif kind == "i":
                    data[key] = int(w.value())
                else:
                    data[key] = round(w.value() / 100.0, 2)
            self.config.set("game_options", data)
            self.config.set("game_options_apply", True)
            try:
                self.config.save()
            except Exception as e:
                QMessageBox.warning(self, "保存失败", str(e))
                return
            if hasattr(self, "check_gopt"):
                self.check_gopt.setChecked(True)
            self._log("新版本默认游戏设置已保存（%d 项）" % len(data))
            dlg.accept()

        b_reset.clicked.connect(do_reset)
        b_cancel.clicked.connect(dlg.reject)
        b_ok.clicked.connect(do_save)
        dlg.exec_()

    def _apply_game_options(self, game_dir, only_missing=True):
        vals = dict(self.config.get("game_options") or {})
        gl = self.config.get("game_language") or ""
        if gl:
            vals["lang"] = gl
        if not vals or not game_dir:
            return 0
        try:
            changed, _path = game_options.apply_options(
                game_dir, vals, only_missing=only_missing)
        except Exception as e:
            self._log("写游戏设置失败：%s" % e)
            return 0
        if changed:
            self._log("已写入 %d 项游戏设置到 options.txt" % changed)
        return changed

    def _apply_game_options_now(self):
        gd = self.config.get("game_dir") or ""
        if not gd:
            QMessageBox.warning(self, "提示", "还没设置游戏目录。")
            return
        if not (self.config.get("game_options") or {}):
            QMessageBox.information(
                self, "还没有设置",
                "先点「设置新版本的默认游戏选项」配一套，再回来写。")
            return
        n = self._apply_game_options(gd)
        QMessageBox.information(
            self, "写好了",
            ("写入了 %d 项到 options.txt。\n游戏里还能自己改，重启游戏生效。"
             % n) if n else "options.txt 里这些项都已经是这套值了，没改动。")

    # ---------- 导出整合包 ----------
    def _export_pack(self):
        gd = self.config.get("game_dir") or ""
        if not gd:
            QMessageBox.warning(self, "提示", "还没设置游戏目录。")
            return
        name, ok = QInputDialog.getText(self, "导出整合包", "整合包名字：",
                                        text="我的整合包")
        if not ok:
            return
        name = (name or "我的整合包").strip() or "我的整合包"
        safe = "".join(c for c in name if c not in '\\/:*?"<>|') or "整合包"
        path, _f = QFileDialog.getSaveFileName(
            self, "保存整合包", os.path.join(
                os.path.expanduser("~"), "Desktop", safe + ".zip"),
            "Zip 整合包 (*.zip)")
        if not path:
            return
        if not path.lower().endswith(".zip"):
            path += ".zip"
        self._log("开始导出整合包：" + name)
        w = self._track(ExportPackWorker(gd, path, name,
                                         include_resourcepacks=True,
                                         include_shaders=True))
        self._export_worker = w
        w.done.connect(lambda p, c, s: self._on_export_done(p, c, s))
        w.failed.connect(lambda e: QMessageBox.warning(
            self, "导出失败", e))
        w.start()

    def _on_export_done(self, path, count, size):
        self._log("整合包导出完成：%s（%d 个文件，%.1f MB）"
                  % (path, count, size / 1048576.0))
        box = QMessageBox(self)
        box.setWindowTitle("整合包导出了")
        box.setText("已导出到：\n%s" % path)
        box.setInformativeText("%d 个文件，%.1f MB。里面带一份说明，"
                               "收到的人照着上面写的放就行。"
                               % (count, size / 1048576.0))
        b_open = box.addButton("打开所在文件夹", QMessageBox.AcceptRole)
        box.addButton("好", QMessageBox.AcceptRole)
        box.exec_()
        if box.clickedButton() is b_open:
            QDesktopServices.openUrl(
                QUrl.fromLocalFile(os.path.dirname(path)))

    def _build_mods_page(self):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        title = QLabel(i18n.tr("page_mods"))
        title.setObjectName("PageTitle")
        v.addWidget(title)

        tools = QHBoxLayout()
        b_upd = QPushButton("检查模组更新")
        b_upd.setToolTip("用 Modrinth 上收录的模组比对，列出可更新的旧版本")
        b_upd.clicked.connect(self._check_mod_updates)
        tools.addWidget(b_upd)
        b_exp = QPushButton("导出整合包")
        b_exp.setToolTip("把当前游戏目录的模组、配置、资源包、光影打成一个 zip 发给朋友")
        b_exp.clicked.connect(self._export_pack)
        tools.addWidget(b_exp)
        b_opt = QPushButton("新版本游戏设置")
        b_opt.setToolTip("装新版本时写进 options.txt 的那套设置")
        b_opt.clicked.connect(self._open_game_options)
        tools.addWidget(b_opt)
        tools.addStretch(1)
        v.addLayout(tools)

        self.mods_tabs = QTabWidget()
        self.mods_tabs.addTab(self._tab_installed(), i18n.tr("tab_installed"))
        self.mods_tabs.addTab(self._tab_browse("mod"), i18n.tr("tab_browse_mod"))
        self.mods_tabs.addTab(self._tab_installed_packs(), i18n.tr("tab_browse_rp"))
        self.mods_tabs.addTab(self._tab_browse("resourcepack"),
                              i18n.tr("tab_browse_rp_online"))
        self.mods_tabs.addTab(self._tab_shader_installed(), "已装光影")
        self.mods_tabs.addTab(self._tab_shader_online(), "在线光影")
        self.mods_tabs.addTab(self._tab_modpacks(), "整合包")
        self.mods_tabs.currentChanged.connect(self._on_mods_tab_changed)
        v.addWidget(self.mods_tabs, 1)
        return page

    def _on_mods_tab_changed(self, index):
        """下载页懒加载：只有真正切到该页签才发请求，避免启动时连发四个查询。"""
        if index == 1 and not getattr(self, "_browse_loaded_mod", False):
            self._browse_loaded_mod = True
            self._browse_search("mod")
        elif index == 3 and not getattr(self, "_browse_loaded_rp", False):
            self._browse_loaded_rp = True
            self._browse_search("resourcepack")
        elif index == 5 and not getattr(self, "_shader_loaded", False):
            self._shader_loaded = True
            self._shader_search(True)

    # ---------- 整合包（Modrinth .mrpack） ----------
    def _tab_modpacks(self):
        from core import modpack
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)

        tip = QLabel(
            "装整合包会自动建一个独立版本：它自己的模组、配置、资源包都放在"
            "那个版本目录里，不碰你现有的模组和存档。装完在返回版本列表里选它启动。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        bar = QHBoxLayout()
        self.mpk_query = QLineEdit()
        self.mpk_query.setPlaceholderText("搜整合包：机械动力 / 丧尸 / 枪械 / 肉鸽…")
        self.mpk_query.returnPressed.connect(lambda: self._mpk_search())
        b_search = QPushButton("搜索")
        b_search.clicked.connect(lambda: self._mpk_search())
        b_feat = QPushButton("回到精选")
        b_feat.clicked.connect(self._mpk_fill_featured)
        bar.addWidget(self.mpk_query, 1)
        bar.addWidget(b_search)
        bar.addWidget(b_feat)
        v.addLayout(bar)

        self.mpk_state = QLabel("")
        self.mpk_state.setObjectName("FieldLabel")
        self.mpk_state.setWordWrap(True)
        v.addWidget(self.mpk_state)
        self.mpk_bar = QProgressBar()
        self.mpk_bar.setVisible(False)
        v.addWidget(self.mpk_bar)

        holder = QWidget()
        self.mpk_box = QVBoxLayout(holder)
        self.mpk_box.setContentsMargins(0, 0, 0, 0)
        self.mpk_box.setSpacing(8)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(holder)
        v.addWidget(scroll, 1)

        self._mpk_labs = {}
        self._mpk_worker = None
        self._mpk_fill_featured()
        return page

    def _mpk_clear(self):
        while self.mpk_box.count():
            item = self.mpk_box.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
        self._mpk_labs = {}

    def _mpk_row(self, idx, title, sub, on_install, icon_url=""):
        from PySide6.QtWidgets import QFrame
        frame = QFrame()
        light = (self.config.get("theme") or "dark") in ("light", "sakura")
        if light:
            card = ("QFrame{background:rgba(0,0,0,0.035);"
                    "border:1px solid rgba(0,0,0,0.10);border-radius:10px;}")
            icon_qss = ("QLabel{background:#dfe6ef;color:#41536b;border-radius:8px;"
                        "font-size:18px;font-weight:600;}")
        else:
            card = ("QFrame{background:rgba(255,255,255,0.05);"
                    "border:1px solid rgba(255,255,255,0.09);border-radius:10px;}")
            icon_qss = ("QLabel{background:#2b3444;color:#cfe4ff;border-radius:8px;"
                        "font-size:18px;font-weight:600;}")
        frame.setStyleSheet(card)
        h = QHBoxLayout(frame)
        h.setContentsMargins(12, 10, 12, 10)
        h.setSpacing(12)
        icon = QLabel()
        icon.setFixedSize(52, 52)
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet(icon_qss)
        icon.setText((title or "?")[:1])
        h.addWidget(icon)
        col = QVBoxLayout()
        col.setSpacing(2)
        t = QLabel(title)
        t.setStyleSheet("font-size:15px;font-weight:600;")
        s = QLabel(sub)
        s.setObjectName("FieldLabel")
        s.setWordWrap(True)
        col.addWidget(t)
        col.addWidget(s)
        h.addLayout(col, 1)
        b = QPushButton("安装")
        b.setToolTip("下载并装成独立版本")
        b.clicked.connect(on_install)
        h.addWidget(b)
        self.mpk_box.addWidget(frame)
        self._mpk_labs[idx] = icon
        return icon_url

    def _mpk_fill_featured(self):
        from core import modpack
        self._mpk_clear()
        self.mpk_state.setText("精选 %d 个整合包（Modrinth 上真实可下载）"
                               % len(modpack.CATALOG))
        icon_jobs = []
        for idx, item in enumerate(modpack.catalog()):
            dl = item.get("hot") or 0
            sub = "%s · 约 %d 万次下载 · %s" % (
                item.get("tag") or "", int(dl / 10000),
                item.get("why") or "")
            slug = item["slug"]
            name = item.get("name") or slug
            self._mpk_row(idx, name, sub,
                          lambda _=False, s=slug, n=name: self._mpk_install(s, n))
        # 封面要问 Modrinth 要，放后台，别卡住页签
        try:
            from ui.workers import ModpackIconUrlWorker
            w = self._track(ModpackIconUrlWorker([c["slug"] for c in modpack.catalog()]))
            w.done.connect(self._mpk_icons)
            w.start()
        except Exception:
            pass

    def _mpk_icons(self, jobs):
        try:
            from ui.workers import ModrinthIconWorker
            iw = self._track(ModrinthIconWorker(jobs))
            iw.icon_ready.connect(self._mpk_icon_ready)
            iw.start()
        except Exception:
            pass

    def _mpk_icon_ready(self, idx, data):
        lab = (self._mpk_labs or {}).get(idx)
        if lab is None or not data:
            return
        try:
            pm = QPixmap()
            pm.loadFromData(data)
            if pm.isNull():
                return
            lab.setPixmap(pm.scaled(52, 52, Qt.KeepAspectRatio,
                                    Qt.SmoothTransformation))
            lab.setStyleSheet("QLabel{background:transparent;border-radius:8px;}")
        except Exception:
            pass

    def _mpk_search(self):
        q = (self.mpk_query.text() or "").strip()
        if not q:
            self._mpk_fill_featured()
            return
        self.mpk_state.setText("正在搜「%s」…" % q)
        try:
            from ui.workers import ModrinthSearchWorker
            w = self._track(ModrinthSearchWorker("modpack", None, q, None, 0))
            w.done.connect(self._mpk_show_hits)
            w.failed.connect(lambda e: self.mpk_state.setText("搜索失败：" + str(e)))
            w.start()
        except Exception as e:
            self.mpk_state.setText("搜索失败：" + str(e))

    def _mpk_show_hits(self, hits, total):
        self._mpk_clear()
        hits = hits or []
        self.mpk_state.setText("搜到 %d 个整合包，显示前 %d 个"
                               % (total or len(hits), len(hits)))
        jobs = []
        for idx, h in enumerate(hits):
            title = h.get("title") or h.get("slug") or "整合包"
            cats = [c for c in (h.get("categories") or [])
                    if c not in ("fabric", "forge", "neoforge", "quilt")]
            sub = "%s · %d 次下载 · %s" % (
                "/".join(cats[:3]) or "整合包",
                int(h.get("downloads") or 0),
                (h.get("description") or "")[:80])
            slug = h.get("slug") or ""
            url = h.get("icon_url") or ""
            self._mpk_row(idx, title, sub,
                          lambda _=False, s=slug, n=title: self._mpk_install(s, n))
            if url:
                jobs.append((idx, url))
        if jobs:
            self._mpk_icons(jobs)

    def _mpk_stage(self, name, pct):
        self.mpk_bar.setVisible(True)
        self.mpk_bar.setValue(max(0, min(100, int(pct))))
        self.mpk_state.setText(name or "")

    def _mpk_progress(self, cur, tot):
        if tot:
            self.mpk_state.setText("下载整合包 %.1f / %.1f MB"
                                   % (cur / 1048576.0, tot / 1048576.0))

    def _mpk_done(self, vid):
        self.mpk_bar.setValue(100)
        self.mpk_state.setText("装好了：版本列表里的「%s」" % vid)
        self._log("整合包安装完成：%s" % vid)
        try:
            self._refresh_version_list()
        except Exception:
            pass
        box = QMessageBox(self)
        box.setWindowTitle("整合包装好了")
        box.setText("「%s」已经装成一个独立版本。" % vid)
        box.setInformativeText("去版本列表里选中它就能启动；它的模组和配置"
                               "都在自己的目录里，不影响其它版本。")
        box.addButton("知道了", QMessageBox.AcceptRole)
        box.exec_()

    def _mpk_failed(self, err):
        self.mpk_bar.setVisible(False)
        self.mpk_state.setText("安装失败：" + str(err))
        self._log("整合包安装失败：" + str(err))
        QMessageBox.warning(self, "整合包安装失败", str(err))

    def _mpk_install(self, slug, title):
        if not slug:
            return
        w = getattr(self, "_mpk_worker", None)
        if w is not None and w.isRunning():
            QMessageBox.information(self, "先等一下",
                                    "上一个整合包还在装，装完再点。")
            return
        gd = self.config.get("game_dir") or ""
        if not gd or not os.path.isdir(gd):
            QMessageBox.warning(self, "装不了",
                                "先去设置里选一个游戏目录。")
            return
        java = self.config.get("java_path") or ""
        if not java:
            try:
                java = javaman.resolve(self.config, "")
            except Exception:
                java = ""
        self._log("开始安装整合包：%s" % title)
        self.mpk_bar.setVisible(True)
        self.mpk_bar.setValue(0)
        self.mpk_state.setText("正在准备：%s" % title)
        try:
            from ui.workers import ModpackInstallWorker
            w = self._track(ModpackInstallWorker(slug, gd, java))
            w.log.connect(self._log)
            w.stage.connect(self._mpk_stage)
            w.progress.connect(self._mpk_progress)
            w.done.connect(self._mpk_done)
            w.failed.connect(self._mpk_failed)
            w.start()
            self._mpk_worker = w
        except Exception as e:
            self._mpk_failed(str(e))

    # ---------- 版本详情 ----------
    def _build_detail_page(self):
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(14)

        top = QHBoxLayout()
        top.setSpacing(10)
        b_back = QPushButton(i18n.tr("btn_back"))
        b_back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        self.detail_title = QLabel("")
        self.detail_title.setObjectName("PageTitle")
        top.addWidget(b_back)
        top.addWidget(self.detail_title, 1)
        outer.addLayout(top)

        b_version = QPushButton(i18n.tr("open_version_folder"))
        b_version.clicked.connect(self._detail_open_version)
        b_mods = QPushButton(i18n.tr("open_mods_folder"))
        b_mods.clicked.connect(self._open_mods_dir)
        b_saves = QPushButton(i18n.tr("open_saves_folder"))
        b_saves.clicked.connect(self._open_saves_dir)
        b_dl = QPushButton(i18n.tr("download_mod"))
        b_dl.setObjectName("PrimaryButton")
        b_dl.clicked.connect(self._detail_goto_download)
        b_shot = QPushButton("截图")
        b_shot.clicked.connect(self._view_screenshots)
        b_fix = QPushButton("修复崩溃")
        b_fix.clicked.connect(self._fix_crash)
        b_pack = QPushButton("局内资源包")
        b_pack.clicked.connect(self._manage_ingame_packs)
        b_snap = QPushButton("版本快照")
        b_snap.setToolTip("把这个版本的文件和模组清单打个包存起来，改坏了能还原")
        b_snap.clicked.connect(self._version_snapshots)
        self.b_fav = QPushButton("收藏此版本")
        self.b_fav.setToolTip("收藏后这个版本会排到版本列表最前面")
        self.b_fav.clicked.connect(self._toggle_fav_detail)
        b_tool = QPushButton("备份 / 体检")
        b_tool.setToolTip("跳到工具页：整版本备份、模组冲突、日志诊断")
        b_tool.clicked.connect(self._refresh_tools)

        # 10 个按钮以前挤在一行：横向要 1172px，窗口一窄右边「下载模组」
        # 「备份/体检」全被切掉（用户报的「有些 UI 只显示一半」）。
        # 改成两行五列，最宽也就 600 出头，任何窗口都放得下。
        btns = QGridLayout()
        btns.setSpacing(10)
        _btns = [b_version, b_mods, b_saves, b_shot, b_pack,
                 b_snap, self.b_fav, b_fix, b_tool, b_dl]
        for _i, _b in enumerate(_btns):
            btns.addWidget(_b, _i // 5, _i % 5)
        outer.addLayout(btns)

        cols = QHBoxLayout()
        cols.setSpacing(14)
        lcol = QVBoxLayout()
        lcol.setSpacing(8)
        lcol.addWidget(self._field_label(i18n.tr("mods_label")))
        self.detail_mods = QListWidget()
        lcol.addWidget(self.detail_mods, 1)
        rcol = QVBoxLayout()
        rcol.setSpacing(8)
        rcol.addWidget(self._field_label(i18n.tr("saves_label")))
        rcol.addWidget(self._worlds_panel(), 1)
        cols.addLayout(lcol, 1)
        cols.addLayout(rcol, 1)
        outer.addLayout(cols, 1)
        self._detail_vid = ""
        return page

    def _build_lan_page(self):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)
        v.addWidget(self._title(i18n.tr("page_lan")))

        # 开放联机 / 加入联机彻底分开成两个页签
        self.lan_tabs = QTabWidget()
        self.lan_tabs.addTab(self._tab_host_room(), i18n.tr("lan_tab_host"))
        self.lan_tabs.addTab(self._tab_invite_room(), i18n.tr("lan_tab_invite"))
        self.lan_tabs.addTab(self._tab_join_room(), i18n.tr("lan_tab_join"))
        v.addWidget(self.lan_tabs, 1)

        self._invite_worker = None
        self._invite_code = ""

        self.room_server = None
        self.room_meta = None
        self._room_worker = None
        self._meta_worker = None
        self._room_cover_bytes = None
        self._room_meta_map = {}
        self._room_covers = {}
        self._lan_rooms = []
        self._lan_worker = None
        self._set_player_manage(False)
        self._load_room_cover()
        default_name = "%s 的房间" % (self.config.get("username") or "Player")
        self.input_room_name.setText(default_name)
        self.lan_timer = QTimer(self)
        self.lan_timer.timeout.connect(self._refresh_lan_rooms)
        return page

    def _build_friends_page(self):
        """好友：按账号名搜索添加 + 好友列表；私聊仍要后端。"""
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)
        v.addWidget(self._title("好友"))

        # ---- 按账号名搜索 ----
        card = QWidget()
        card.setObjectName("Card")
        sv = QVBoxLayout(card)
        sv.setSpacing(10)
        sv.addWidget(self._sub_title("按账号名加好友"))
        hint = QLabel(
            "输入对方的账号名（就是账号页注册时填的用户名），搜到后点「加为好友」。"
            "能搜到本机账号，以及最近 12 小时内登录过的账号——他们登录时会把自己挂到"
            "公共目录上（只挂账号名和一个随机编号，不带邮箱）。")
        hint.setWordWrap(True)
        hint.setObjectName("FieldLabel")
        sv.addWidget(hint)

        sr = QHBoxLayout()
        self.input_fsearch = QLineEdit()
        self.input_fsearch.setPlaceholderText("账号名，例如 Steve；留空看全部最近在线的")
        self.input_fsearch.returnPressed.connect(self._search_friends)
        sr.addWidget(self.input_fsearch, 1)
        self.btn_fsearch = QPushButton("搜索")
        self.btn_fsearch.setObjectName("PrimaryButton")
        self.btn_fsearch.setFixedWidth(96)
        self.btn_fsearch.clicked.connect(self._search_friends)
        sr.addWidget(self.btn_fsearch)
        sv.addLayout(sr)

        self.fsearch_state = QLabel("输入名字后点搜索。")
        self.fsearch_state.setObjectName("FieldLabel")
        sv.addWidget(self.fsearch_state)

        self.fsearch_list = QListWidget()
        self.fsearch_list.setMinimumHeight(110)
        self.fsearch_list.setMaximumHeight(160)
        sv.addWidget(self.fsearch_list)

        fr = QHBoxLayout()
        b_add = QPushButton("加为好友")
        b_add.clicked.connect(self._add_search_hit)
        fr.addWidget(b_add)
        b_up = QPushButton("把我也挂到目录")
        b_up.setToolTip("让别人也能按你的账号名搜到你（12 小时内有效）")
        b_up.clicked.connect(self._announce_self)
        fr.addWidget(b_up)
        b_pre = QPushButton("刷新在线状态")
        b_pre.setToolTip("看谁开着启动器、谁正在游戏里（15 分钟内算在线）")
        b_pre.clicked.connect(self._refresh_presence)
        fr.addWidget(b_pre)
        fr.addStretch(1)
        sv.addLayout(fr)
        card.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        v.addWidget(card)

        # ---- 好友列表 ----
        hr = QHBoxLayout()
        hr.addWidget(self._sub_title("好友列表"))
        hr.addStretch(1)
        hr.addWidget(QLabel("分组"))
        self.friend_group_filter = QComboBox()
        self.friend_group_filter.setFixedWidth(140)
        self.friend_group_filter.addItem("全部")
        self.friend_group_filter.currentIndexChanged.connect(
            lambda _i: self._reload_friends())
        hr.addWidget(self.friend_group_filter)
        v.addLayout(hr)
        self.friend_list = QListWidget()
        self.friend_list.setMinimumHeight(150)
        self.friend_list.itemDoubleClicked.connect(lambda _it: self._open_chat())
        self.friend_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.friend_list.customContextMenuRequested.connect(self._friend_menu)
        v.addWidget(self.friend_list, 1)
        fd = QHBoxLayout()
        b_chat = QPushButton("私聊")
        b_chat.setObjectName("PrimaryButton")
        b_chat.setToolTip("在启动器里和选中的好友聊天（双击好友也可以）")
        b_chat.clicked.connect(self._open_chat)
        fd.addWidget(b_chat)
        b_group = QPushButton("群聊")
        b_group.setToolTip("打开选中的群聊天；群号发给别人他也能进来")
        b_group.clicked.connect(self._open_group)
        fd.addWidget(b_group)
        b_ai = QPushButton("聊小矿")
        b_ai.setObjectName("PrimaryButton")
        b_ai.setToolTip("AI 搭子：会聊天、会关心人；能帮你改设置、放歌")
        b_ai.clicked.connect(self._open_ai_friend)
        fd.addWidget(b_ai)
        b_av = QPushButton("换头像")
        b_av.setToolTip("给自己挑一个内置头像，或者导入一张图片")
        b_av.clicked.connect(self._pick_avatar)
        fd.addWidget(b_av)
        b_edit = QPushButton("改备注 / 分组")
        b_edit.clicked.connect(self._edit_friend)
        fd.addWidget(b_edit)
        b_notify = QPushButton("提醒设置")
        b_notify.setToolTip("置顶、免打扰、特别关心（也可以右键点好友）")
        b_notify.clicked.connect(self._notify_menu_selected)
        fd.addWidget(b_notify)
        b_del = QPushButton("删除选中的好友")
        b_del.clicked.connect(self._remove_friend)
        fd.addWidget(b_del)
        fd.addStretch(1)
        v.addLayout(fd)

        # ---- 群聊 ----
        v.addWidget(self._sub_title("群聊"))
        gt = QLabel("建一个群会把群号给你，把群号发给朋友，他点「加入群聊」填进去就在同一个群里。"
                    "两边开着启动器（不用进游戏）就能聊。")
        gt.setObjectName("FieldLabel")
        gt.setWordWrap(True)
        v.addWidget(gt)

        self.group_list = QListWidget()
        self.group_list.setMinimumHeight(104)
        self.group_list.itemDoubleClicked.connect(lambda _it: self._open_group())
        self.group_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.group_list.customContextMenuRequested.connect(self._group_menu)
        v.addWidget(self.group_list)

        gr = QHBoxLayout()
        b_gnew = QPushButton("新建群聊")
        b_gnew.clicked.connect(self._new_group)
        gr.addWidget(b_gnew)
        b_gjoin = QPushButton("加入群聊")
        b_gjoin.clicked.connect(self._join_group)
        gr.addWidget(b_gjoin)
        b_gdel = QPushButton("退出选中的群")
        b_gdel.clicked.connect(self._leave_group)
        gr.addWidget(b_gdel)
        b_gn = QPushButton("提醒设置")
        b_gn.setToolTip("置顶、免打扰（也可以右键点群）")
        b_gn.clicked.connect(self._group_notify_menu)
        gr.addWidget(b_gn)
        gr.addStretch(1)
        v.addLayout(gr)

        # ---- 旧：手动加 ID（保留）----
        r4 = QHBoxLayout()
        self.input_friend = QLineEdit()
        self.input_friend.setPlaceholderText("也可以直接填对方的好友 ID")
        r4.addWidget(self.input_friend, 1)
        b_add_id = QPushButton("按 ID 加")
        b_add_id.setFixedWidth(96)
        b_add_id.clicked.connect(self._add_friend)
        r4.addWidget(b_add_id)
        v.addLayout(r4)

        # ---- 后端（私聊 / 在线状态）----
        v.addWidget(self._sub_title("私聊与在线状态（需要后端，选填）"))
        tip = QLabel(
            "私聊（文字 / 表情 / 图片 / 视频 / 文件）和好友在线状态，要靠一台在线服务器"
            "帮两边把消息接起来。填入你自己的 Supabase 项目地址和 anon key，保存后生效。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        r1 = QHBoxLayout()
        lab1 = QLabel("服务器地址")
        lab1.setFixedWidth(96)
        self.input_sb_url = QLineEdit()
        self.input_sb_url.setPlaceholderText("https://xxxx.supabase.co")
        self.input_sb_url.setText(self.config.get("supabase_url") or "")
        r1.addWidget(lab1)
        r1.addWidget(self.input_sb_url, 1)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        lab2 = QLabel("服务器密钥")
        lab2.setFixedWidth(96)
        self.input_sb_key = QLineEdit()
        self.input_sb_key.setPlaceholderText("anon public key（Supabase 里那一长串）")
        self.input_sb_key.setText(self.config.get("supabase_key") or "")
        r2.addWidget(lab2)
        r2.addWidget(self.input_sb_key, 1)
        v.addLayout(r2)

        r3 = QHBoxLayout()
        self.sb_state = QLabel(
            "已填好连接信息，重启后生效。" if (self.config.get("supabase_url")
                                       and self.config.get("supabase_key"))
            else "没接后端也不影响上面加好友；这里只是私聊和在线状态还要用。")
        self.sb_state.setObjectName("FieldLabel")
        r3.addWidget(self.sb_state, 1)
        b_save = QPushButton("保存连接")
        b_save.setObjectName("PrimaryButton")
        b_save.setFixedWidth(110)
        b_save.clicked.connect(self._save_supabase)
        r3.addWidget(b_save)
        v.addLayout(r3)

        r5 = QHBoxLayout()
        b_room = QPushButton("邀请好友进房间")
        b_room.clicked.connect(
            lambda: QMessageBox.information(
                self, "邀请好友", "连接信息填好并接上后端后，这里会列出你的房间和"
                "在线好友，点一下就能把邀请发过去。"))
        r5.addWidget(b_room)
        r5.addStretch(1)
        v.addLayout(r5)

        self._reload_friends()
        self._reload_groups()
        self._start_inbox()
        try:
            from core import chat as _chat2
            _chat2.set_filter(self._chat_filter_on())
        except Exception:
            pass
        return self._scroll_wrap(page)

    def _sub_title(self, text):
        lb = QLabel(text)
        f = QFont()
        f.setBold(True)
        f.setPointSize(10)
        lb.setFont(f)
        return lb

    def _save_supabase(self):
        url = (self.input_sb_url.text() or "").strip().rstrip("/")
        key = (self.input_sb_key.text() or "").strip()
        if not url or not key:
            self.sb_state.setText("两个都要填：Project URL 和 anon key。")
            return
        if not url.startswith("https://"):
            self.sb_state.setText("Project URL 要以 https:// 开头。")
            return
        self.config.set("supabase_url", url)
        self.config.set("supabase_key", key)
        try:
            self.config.save()
        except Exception as e:
            self.sb_state.setText("保存失败：%s" % e)
            return
        self.sb_state.setText("连接信息已保存，重启 OMC 后生效。")
        self._log("已保存好友服务器连接信息")

    def _save_ai_api(self):
        base = (self.input_ai_base.text() or "").strip().rstrip("/")
        key = (self.input_ai_key.text() or "").strip()
        model = (self.input_ai_model.text() or "").strip()
        if base and not base.startswith("http"):
            self.lbl_ai_state.setText("地址要以 http:// 或 https:// 开头")
            return
        self.config.set("ai_api_base", base)
        self.config.set("ai_api_key", key)
        self.config.set("ai_model", model)
        try:
            self.config.save()
        except Exception as e:
            self.lbl_ai_state.setText("保存失败：%s" % e)
            return
        self.lbl_ai_state.setText("已保存。%s"
                                  % ("小矿会用这个接口。" if (base and key)
                                     else "留空就是本机模式。"))

    def _test_ai_api(self):
        self.lbl_ai_state.setText("正在问小矿一句话……")

        def work():
            try:
                from core import ai_friend
                say, _act, engine = ai_friend.reply("在吗")
            except Exception as e:
                say, engine = "出错：%s" % str(e)[:80], "local"
            txt = "%s（%s）" % (say[:120], "模型在线" if engine == "remote"
                                else "本机模式")
            try:
                QTimer.singleShot(0, lambda: self.lbl_ai_state.setText(txt))
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()

    def _reload_friends(self):
        self.friend_list.clear()
        # 第一位永远是小矿：AI 搭子，不挂在任何服务器上，双击就聊
        ai_item = QListWidgetItem("小矿　·　AI 搭子　·　随时陪你聊，能改设置、能放歌")
        ai_item.setData(Qt.UserRole, {"name": "", "ai": True})
        ai_item.setSizeHint(QSize(0, 32))
        ai_item.setToolTip("双击打开和小矿的聊天窗。它只改设置和放音乐，"
                           "别的事一律拒绝。")
        try:
            ai_item.setIcon(self._ai_icon())
        except Exception:
            pass
        self.friend_list.addItem(ai_item)
        cb = getattr(self, "friend_group_filter", None)
        want = cb.currentText() if cb is not None else "全部"
        rows = friendbook.items()
        for g in friendbook.groups():
            if cb is not None and cb.findText(g) < 0:
                cb.blockSignals(True)
                cb.addItem(g)
                cb.blockSignals(False)
        if want and want != "全部":
            rows = [r for r in rows if (r.get("group") or "") == want]
        if not rows:
            self.friend_list.addItem(QListWidgetItem(
                "还没有真好友。上面搜账号名就能加；小矿一直在这。"))
            return
        from core import notifyprefs as _np
        # 置顶的排最前，特别关心的优先
        rows = sorted(rows, key=lambda r: (
            0 if _np.is_pinned_friend(r.get("name") or "") else 1,
            0 if _np.is_star(r.get("name") or "") else 1,
        ))
        for it in rows:
            name = friendbook.label_of(it)
            if (it.get("alias") or "").strip() and it.get("name"):
                name = "%s（%s）" % (name, it.get("name"))
            gp = it.get("group") or "未分组"
            text = "%s　·　%s　·　%s　·　加于 %s" % (
                name, gp, it.get("src") or "本地", it.get("since") or "")
            st = self._presence_text(it.get("name") or "")
            if st:
                text = "【%s】%s" % (st, text)
            if (it.get("note") or "").strip():
                text += "　·　" + it["note"].strip()
            true_name = (it.get("name") or "")
            marks = []
            if _np.is_pinned_friend(true_name):
                marks.append("置顶")
            if _np.is_star(true_name):
                marks.append("特别关心")
            if (_np.friend(true_name) or {}).get("dnd"):
                marks.append("免打扰")
            if marks:
                text = "[" + "/".join(marks) + "] " + text
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, it)
            item.setSizeHint(QSize(0, 32))
            try:
                item.setIcon(self._avatar_icon(it.get("name") or ""))
            except Exception:
                pass
            unread = (getattr(self, "_unread", {}) or {}).get(
                (it.get("name") or ""), 0)
            if unread:
                item.setText(text + "　·　%d 条未读" % unread)
            self.friend_list.addItem(item)

    def _open_chat(self):
        """在启动器里和选中的好友私聊（不跳外部聊天软件）。"""
        item = self.friend_list.currentItem()
        if not item:
            self.fsearch_state.setText("先在好友列表里点一个好友。")
            return
        it = item.data(Qt.UserRole) or {}
        if it.get("ai"):
            self._open_ai_friend()
            return
        peer = (it.get("name") or "").strip()
        if not peer:
            self.fsearch_state.setText("这条记录里没有账号名，没法私聊。")
            return
        me = self._chat_name()
        from ui.chat_dialog import ChatDialog
        old = getattr(self, "_chat_win", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._chat_win = ChatDialog(me, peer, self)
        self._chat_win.show()
        self._chat_win.raise_()
        self._chat_win.activateWindow()

    # ---------- 头像 / 群聊 / 后台收信 ----------
    def _ai_icon(self):
        from ui.ai_chat_dialog import _ai_avatar
        return QIcon(_ai_avatar(24))

    def _avatar_icon(self, name):
        """按账号名取头像图标；没有就画一个名字首字的色块。"""
        from core import avatar as _av
        p = _av.lookup(name)
        if p:
            pm = QPixmap(p)
            if not pm.isNull():
                return QIcon(pm.scaled(24, 24, Qt.KeepAspectRatio,
                                       Qt.SmoothTransformation))
        r, g, b = _av.default_color(name)
        pm = QPixmap(24, 24)
        pm.fill(QColor(r, g, b))
        p2 = QPainter(pm)
        p2.setPen(QColor("#FFFFFF"))
        f = QFont()
        f.setBold(True)
        f.setPointSize(9)
        p2.setFont(f)
        p2.drawText(pm.rect(), Qt.AlignCenter, _av.initial(name))
        p2.end()
        return QIcon(pm)

    def _pick_avatar(self):
        from core import accounts as _acc
        me = (_acc.current_name() or "").strip()
        if not me:
            QMessageBox.information(self, "先登录",
                                    "先在账号页登录一个账号，才能设置头像。")
            return
        from ui.chat_dialog import AvatarPickerDialog
        dlg = AvatarPickerDialog(me, self)
        dlg.exec_()
        self._reload_friends()
        self._reload_groups()

    def _reload_groups(self):
        lst = getattr(self, "group_list", None)
        if lst is None:
            return
        from core import chat as _chat
        lst.clear()
        rows = _chat.group_list()
        if not rows:
            item = QListWidgetItem("还没有群。点「新建群聊」建一个，或者用别人的群号加入。")
            item.setFlags(Qt.NoItemFlags)
            lst.addItem(item)
            return
        from core import notifyprefs as _np2
        rows = sorted(rows, key=lambda g: 0 if _np2.is_pinned_group(
            g.get("id") or "") else 1)
        for g in rows:
            gid = g.get("id") or ""
            title = g.get("title") or gid
            marks = []
            if _np2.is_pinned_group(gid):
                marks.append("置顶")
            if (_np2.group(gid) or {}).get("dnd"):
                marks.append("免打扰")
            lead = ("[" + "/".join(marks) + "] ") if marks else ""
            unread = (getattr(self, "_unread", {}) or {}).get(gid, 0)
            item = QListWidgetItem("%s群聊 · %s　·　群号 %s%s"
                                   % (lead, title, gid,
                                      ("　·　%d 条未读" % unread) if unread else ""))
            item.setData(Qt.UserRole, g)
            item.setSizeHint(QSize(0, 28))
            lst.addItem(item)

    def _new_group(self):
        from core import chat as _chat
        me = self._chat_name()
        title, ok = QInputDialog.getText(self, "新建群聊", "给群起个名字：")
        if not ok:
            return
        gid = _chat.new_group_id()
        _chat.group_add(gid, (title or "").strip() or "群 %s" % gid, [me],
                        owner=me)
        self._reload_groups()
        QMessageBox.information(
            self, "群建好了",
            "群号：%s（你是群主，可以踢人、禁言）\n\n把这个群号发给朋友，"
            "他在「加入群聊」里填进去就在同一个群里。"
            "两边开着启动器就能聊，不用进游戏。注意群号相当于门牌号，别公开贴出去。"
            % gid)

    def _join_group(self):
        from core import chat as _chat
        gid, ok = QInputDialog.getText(self, "加入群聊", "填群号：")
        if not ok:
            return
        gid = (gid or "").strip()
        if not gid:
            return
        title, ok2 = QInputDialog.getText(self, "加入群聊", "群名（可以随便写）：",
                                          text="群 %s" % gid)
        ok, why = _chat.group_add(gid, (title or "").strip() or gid,
                                  [self._chat_name()])
        self._reload_groups()
        if ok:
            QMessageBox.information(
                self, "进来了",
                "已经加入这个群。双击群名就能聊。\n"
                "群里有人说话后，群主那边会记下成员，他就能踢人/禁言了。")
        else:
            QMessageBox.warning(self, "没加进去", why)

    def _leave_group(self):
        from core import chat as _chat
        item = getattr(self, "group_list", None)
        if item is None:
            return
        cur = self.group_list.currentItem()
        g = (cur.data(Qt.UserRole) or {}) if cur else {}
        gid = (g.get("id") or "").strip()
        if not gid:
            QMessageBox.information(self, "先选一个群", "先在群列表里点一个群。")
            return
        if QMessageBox.question(self, "退出群聊",
                                "只是从本机这个群列表里删掉，聊天记录文件保留。继续？") \
                != QMessageBox.Yes:
            return
        _chat.group_remove(gid)
        self._reload_groups()

    def _chat_name(self):
        """聊天用的身份名：优先当前登录账号，其次启动器里填的游戏名。"""
        try:
            from core import accounts as _acc
            n = (_acc.current_name() or "").strip()
            if n:
                return n
        except Exception:
            pass
        n = (self.config.get("username") or "").strip()
        return n or "本机玩家"

    def _open_group(self):
        me = self._chat_name()
        cur = getattr(self, "group_list", None)
        cur = cur.currentItem() if cur is not None else None
        g = (cur.data(Qt.UserRole) or {}) if cur else {}
        gid = (g.get("id") or "").strip()
        if not gid:
            QMessageBox.information(self, "先选一个群", "先在群列表里点一个群。")
            return
        from ui.chat_dialog import GroupChatDialog
        old = getattr(self, "_group_win", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._group_win = GroupChatDialog(me, gid, g.get("title") or gid, self)
        self._group_win.show()
        self._group_win.raise_()
        self._group_win.activateWindow()

    def _chat_filter_on(self):
        """聊天违禁词开关：没设置过的默认就是开。"""
        v = self.config.get("filter_chat_words")
        if v is None:
            return True
        try:
            return bool(v)
        except Exception:
            return True

    def _on_chat_filter_toggled(self, state):
        from core import chat as _chat
        on = bool(state) and int(state) != 0
        self.config.set("filter_chat_words", bool(on))
        self.config.save()
        _chat.set_filter(on)
        self._log("聊天违禁词屏蔽：%s" % ("开" if on else "关"))

    def ai_run_action(self, act):
        """AI 搭子能动的动作，只有「改设置」和「音乐」两类。返回说明。"""
        if not isinstance(act, dict):
            return ""
        kind = (act.get("type") or "").strip()
        val = act.get("value")
        try:
            if kind == "set_theme":
                key = str(val or "")
                if key not in ("dark", "light", "night", "sakura"):
                    return "主题只能 dark / light / night / sakura"
                self.config.set("theme", key)
                self.config.save()
                self._apply_ui_style()
                try:
                    i = self.combo_theme.findData(key)
                    if i >= 0:
                        self.combo_theme.blockSignals(True)
                        self.combo_theme.setCurrentIndex(i)
                        self.combo_theme.blockSignals(False)
                except Exception:
                    pass
                return "主题已换成%s" % {"dark": "深色", "light": "浅色",
                                       "night": "暗夜",
                                       "sakura": "樱花"}.get(key, key)
            if kind == "set_accent":
                key = str(val or "")
                if key not in ("blue", "green", "violet", "orange", "pink",
                             "gold"):
                    return "主色只能是 blue / green / violet / orange / pink / gold"
                self._on_accent_changed(key)
                return "主色已改"
            if kind == "set_wall":
                kw = str(val or "").strip()
                return self._ai_set_wall(kw)
            if kind == "toggle_random_wall":
                on = bool(val)
                self._on_rand_wall_toggled(on)
                try:
                    self.chk_randwall.blockSignals(True)
                    self.chk_randwall.setChecked(on)
                    self.chk_randwall.blockSignals(False)
                except Exception:
                    pass
                return "随机壁纸已%s" % ("打开" if on else "关闭")
            if kind == "set_memory":
                return self._ai_set_memory(val)
            if kind == "set_username":
                name = str(val or "").strip()[:16]
                if not name:
                    return "名字是空的"
                self.config.set("username", name)
                self.config.save()
                try:
                    self.input_name.setText(name)
                except Exception:
                    pass
                return "游戏名已改成 %s" % name
            if kind == "set_game_lang":
                code = str(val or "")
                if code not in ("zh_cn", "en_us", "ja_jp", "zh_tw"):
                    return "只支持中文 / 英文 / 日语 / 繁体"
                self.config.set("game_language", code)
                self.config.save()
                return "游戏内语言已改（下次启动游戏生效）"
            if kind == "toggle_chat_filter":
                on = bool(val)
                self.config.set("filter_chat_words", on)
                self.config.save()
                try:
                    from core import chat as _chat
                    _chat.set_filter(on)
                except Exception:
                    pass
                try:
                    self.cb_chat_filter.blockSignals(True)
                    self.cb_chat_filter.setChecked(on)
                    self.cb_chat_filter.blockSignals(False)
                except Exception:
                    pass
                return "聊天违禁词屏蔽已%s" % ("开" if on else "关")
            if kind == "toggle_cat":
                on = bool(val)
                self._on_cat_toggled(on)
                try:
                    self.chk_cat.blockSignals(True)
                    self.chk_cat.setChecked(on)
                    self.chk_cat.blockSignals(False)
                except Exception:
                    pass
                return "桌面小猫已%s" % ("出现" if on else "收起来")
            if kind == "play_music":
                return self.music_page.ai_play_keyword(str(val or ""))
            if kind == "music_pause":
                return self.music_page.ai_pause()
            if kind == "music_next":
                return self.music_page.ai_next()
            if kind == "music_volume":
                return self.music_page.ai_volume(val)
        except Exception as e:
            return "没做成：%s" % str(e)[:80]
        return "这个我做不了（我只能改设置和放歌）"

    def _ai_set_wall(self, kw):
        """换壁纸：从内置壁纸里按名字模糊挑一张。"""
        name = (kw or "").strip()
        if name in ("", "换一个", "随便", "随便换", "随机"):
            cur = self.config.get("background_image") or ""
            cands = ["builtin:" + fn for fn, _l in self.BUILTIN_WALLS
                     if os.path.exists(self._wall_path(fn))]
            if not cands:
                return "没找到内置壁纸"
            pick = random.choice([c for c in cands if c != cur] or cands)
            self._ai_apply_wall(pick)
            return "壁纸换成「%s」" % (self._wall_label(pick) or pick)
        for fn, label in self.BUILTIN_WALLS:
            if name in (label or "") or (label or "") in name or name in fn:
                key = "builtin:" + fn
                self._ai_apply_wall(key)
                return "壁纸换成「%s」" % label
        return "内置壁纸里没有「%s」，设置页能看图挑" % name

    def _ai_apply_wall(self, key):
        self.config.set("background_image", key)
        self.config.save()
        try:
            self.combo_wall.blockSignals(True)
            i = self.combo_wall.findData(key)
            if i >= 0:
                self.combo_wall.setCurrentIndex(i)
            self.combo_wall.blockSignals(False)
        except Exception:
            pass
        try:
            self.backdrop.set_image(self._wall_path(key.split(":", 1)[1])
                                    if key.startswith("builtin:") else key)
            self.backdrop.update()
        except Exception:
            pass
        try:
            self.label_bg_name.setText(self._wall_label(key) or key)
        except Exception:
            pass

    def _ai_set_memory(self, val):
        cur = int(self.config.get("memory_mb") or 4096)
        if val == "more":
            new = min(32768, cur + 2048)
        elif val == "less":
            new = max(1024, cur - 2048)
        else:
            try:
                new = max(512, min(32768, int(val)))
            except Exception:
                return "内存数看不懂，给个数字就行，比如 4096"
        self.config.set("memory_mb", int(new))
        self.config.save()
        try:
            self.slider_mem.setValue(int(new))
        except Exception:
            pass
        return "内存改成 %d MB（下次启动游戏生效）" % int(new)

    def _open_ai_friend(self):
        """打开 AI 搭子聊天窗（好友列表里的「小矿」）。"""
        from ui.ai_chat_dialog import AIChatDialog
        old = getattr(self, "_ai_win", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._ai_win = AIChatDialog(self, self)
        self._ai_win.show()
        self._ai_win.raise_()
        self._ai_win.activateWindow()

    def _open_ai_call(self):
        """和小矿语音通话：离线识别你说的，它用嗓子回你。"""
        from core import stt
        from ui.ai_call_dialog import AICallDialog
        if not stt.available():
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(
                self, "语音通话开不了",
                "这台电脑没有可用的中文语音识别引擎。\n\n"
                "可以在 Windows「设置 → 时间和语言 → 语音」里装一下中文语音包，"
                "装完再回来试。文字聊天和语音朗读现在都能用。")
            return
        old = getattr(self, "_ai_call", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._ai_call = AICallDialog(self, self)
        self._ai_call.show()
        self._ai_call.raise_()
        self._ai_call.activateWindow()

    # ---------- 好友 / 群的提醒偏好（置顶、免打扰、特别关心） ----------
    def _on_global_dnd(self, state):
        from core import notifyprefs as _np
        on = bool(state) and int(state) != 0
        _np.set_global("global_dnd", on)
        self._log("全局免打扰%s" % ("打开" if on else "关闭"))

    def _on_no_sound(self, state):
        from core import notifyprefs as _np
        on = bool(state) and int(state) != 0
        _np.set_global("no_sound", on)
        self._log("聊天提示音%s" % ("关掉" if on else "打开"))

    def _friend_menu(self, pos):
        item = self.friend_list.itemAt(pos)
        if not item:
            return
        it = item.data(Qt.UserRole) or {}
        if it.get("ai"):
            from PySide6.QtWidgets import QMenu
            m = QMenu(self)
            m.addAction("打开和小矿聊天").triggered.connect(self._open_ai_friend)
            m.addAction("和小矿语音通话").triggered.connect(self._open_ai_call)
            m.exec_(self.friend_list.mapToGlobal(pos))
            return
        name = (it.get("name") or "").strip()
        if not name:
            return
        from core import notifyprefs as _np
        from PySide6.QtWidgets import QMenu
        cur = _np.friend(name)
        m = QMenu(self)
        a_pin = m.addAction("取消置顶" if _np.is_pinned_friend(name) else "置顶")
        a_star = m.addAction("取消特别关心" if _np.is_star(name) else
                             "设为特别关心")
        a_dnd = m.addAction("关闭免打扰" if cur.get("dnd") else "开启免打扰")
        m.addSeparator()
        m.addAction("私聊").triggered.connect(self._open_chat)
        a_pin.triggered.connect(lambda: self._np_set("friend", name, "pin",
                                                     not _np.is_pinned_friend(name)))
        a_star.triggered.connect(lambda: self._np_set("friend", name, "star",
                                                      not _np.is_star(name)))
        a_dnd.triggered.connect(lambda: self._np_set("friend", name, "dnd",
                                                     not bool(cur.get("dnd"))))
        m.exec_(self.friend_list.mapToGlobal(pos))

    def _group_menu(self, pos):
        item = self.group_list.itemAt(pos)
        if not item:
            return
        g = item.data(Qt.UserRole) or {}
        gid = (g.get("id") or "").strip()
        if not gid:
            return
        from core import notifyprefs as _np
        from PySide6.QtWidgets import QMenu
        cur = _np.group(gid)
        m = QMenu(self)
        a_pin = m.addAction("取消置顶" if _np.is_pinned_group(gid) else "置顶")
        a_dnd = m.addAction("关闭免打扰" if cur.get("dnd") else "开启免打扰")
        m.addSeparator()
        m.addAction("打开群聊").triggered.connect(self._open_group)
        a_pin.triggered.connect(lambda: self._np_set("group", gid, "pin",
                                                     not _np.is_pinned_group(gid)))
        a_dnd.triggered.connect(lambda: self._np_set("group", gid, "dnd",
                                                     not bool(cur.get("dnd"))))
        m.exec_(self.group_list.mapToGlobal(pos))

    def _notify_menu_selected(self):
        """按钮版的「提醒设置」：给当前选中的好友/群弹同一套菜单。"""
        from core import notifyprefs as _np
        from PySide6.QtWidgets import QMenu
        # 好友优先，没选好友就看看群
        it = self.friend_list.currentItem()
        if it is not None:
            name = ((it.data(Qt.UserRole) or {}).get("name") or "").strip()
            if name:
                cur = _np.friend(name)
                m = QMenu(self)
                a1 = m.addAction("取消置顶" if _np.is_pinned_friend(name)
                                 else "置顶")
                a2 = m.addAction("取消特别关心" if _np.is_star(name)
                                 else "设为特别关心")
                a3 = m.addAction("关闭免打扰" if cur.get("dnd")
                                 else "开启免打扰")
                a1.triggered.connect(lambda: self._np_set(
                    "friend", name, "pin", not _np.is_pinned_friend(name)))
                a2.triggered.connect(lambda: self._np_set(
                    "friend", name, "star", not _np.is_star(name)))
                a3.triggered.connect(lambda: self._np_set(
                    "friend", name, "dnd", not bool(cur.get("dnd"))))
                m.exec_(self.mapToGlobal(self.rect().center()))
                return
        g_it = self.group_list.currentItem()
        if g_it is not None:
            gid = ((g_it.data(Qt.UserRole) or {}).get("id") or "").strip()
            if gid:
                cur = _np.group(gid)
                m = QMenu(self)
                a1 = m.addAction("取消置顶" if _np.is_pinned_group(gid)
                                 else "置顶")
                a3 = m.addAction("关闭免打扰" if cur.get("dnd")
                                 else "开启免打扰")
                a1.triggered.connect(lambda: self._np_set(
                    "group", gid, "pin", not _np.is_pinned_group(gid)))
                a3.triggered.connect(lambda: self._np_set(
                    "group", gid, "dnd", not bool(cur.get("dnd"))))
                m.exec_(self.mapToGlobal(self.rect().center()))
                return
        QMessageBox.information(self, "先选一个",
                                "先在好友列表或群列表里点一个，再点「提醒设置」。")

    def _group_notify_menu(self):
        """群列表的「提醒设置」按钮版。"""
        from core import notifyprefs as _np
        from PySide6.QtWidgets import QMenu
        it = self.group_list.currentItem()
        gid = ((it.data(Qt.UserRole) or {}).get("id") or "").strip() \
            if it is not None else ""
        if not gid:
            QMessageBox.information(self, "先选一个群", "先在群列表里点一个群。")
            return
        cur = _np.group(gid)
        m = QMenu(self)
        a1 = m.addAction("取消置顶" if _np.is_pinned_group(gid) else "置顶")
        a3 = m.addAction("关闭免打扰" if cur.get("dnd") else "开启免打扰")
        a1.triggered.connect(lambda: self._np_set(
            "group", gid, "pin", not _np.is_pinned_group(gid)))
        a3.triggered.connect(lambda: self._np_set(
            "group", gid, "dnd", not bool(cur.get("dnd"))))
        m.exec_(self.mapToGlobal(self.rect().center()))

    def _np_set(self, kind, key, flag, value):
        from core import notifyprefs as _np
        if kind == "friend":
            _np.set_friend(key, **{flag: bool(value)})
            self._reload_friends()
        else:
            _np.set_group(key, **{flag: bool(value)})
            self._reload_groups()
        self._log("%s %s：%s=%s" % ("好友" if kind == "friend" else "群",
                                   key, flag, "开" if value else "关"))

    def _open_chat_by_name(self, name):
        """从右下角提示点进来：直接跟这个好友聊。"""
        name = (name or "").strip()
        if not name:
            return
        me = self._chat_name()
        from ui.chat_dialog import ChatDialog
        old = getattr(self, "_chat_win", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._chat_win = ChatDialog(me, name, self)
        self._chat_win.show()
        self._chat_win.raise_()
        self._chat_win.activateWindow()

    def _open_group_by_id(self, gid):
        from core import chat as _chat
        gid = (gid or "").strip()
        if not gid:
            return
        title = gid
        for g in _chat.group_list():
            if (g.get("id") or "") == gid:
                title = g.get("title") or gid
                break
        me = self._chat_name()
        from ui.chat_dialog import GroupChatDialog
        old = getattr(self, "_group_win", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self._group_win = GroupChatDialog(me, gid, title, self)
        self._group_win.show()
        self._group_win.raise_()
        self._group_win.activateWindow()

    # ---------- 闹钟服务 ----------
    def alarm_svc(self):
        if getattr(self, "_alarm_svc", None) is None:
            from ui.alarm_service import AlarmService
            self._alarm_svc = AlarmService(self)
            self._alarm_svc.fired.connect(
                lambda kind, txt: self._log("%s 响了：%s" % (kind, txt)))
        return self._alarm_svc

    def _alarm_refresh(self):
        """闹钟页数据变了，让它重画一遍。"""
        try:
            tb = getattr(self, "toolbox_page", None)
            page = getattr(tb, "alarm_page", None) if tb is not None else None
            if page is not None:
                page.refresh_alarms()
                page.refresh_timers()
        except Exception:
            pass

    def _start_inbox(self):
        """启动器一开就后台收信：双方都没进游戏也能收到私聊和群消息。"""
        if getattr(self, "_inbox_timer", None) is not None:
            return
        self._inbox_pending = False
        self._unread = {}
        try:
            self._update_friend_badge()
        except Exception:
            pass
        self._inbox_timer = QTimer(self)
        self._inbox_timer.setInterval(20000)
        self._inbox_timer.timeout.connect(self._inbox_tick)
        self._inbox_timer.start()
        QTimer.singleShot(3000, self._inbox_tick)

    def _inbox_tick(self):
        from core import chat as _chat
        me = self._chat_name()
        if not me or self._inbox_pending:
            return
        names = []
        try:
            names = [(it.get("name") or "") for it in friendbook.items()]
        except Exception:
            names = []
        gids = []
        try:
            gids = [(g.get("id") or "") for g in _chat.group_list()]
        except Exception:
            gids = []
        if not names and not gids:
            return
        self._inbox_pending = True

        def work():
            try:
                added = _chat.sync_inbox(me, names, gids)
            except Exception:
                added = {}
            # 顺便把每个会话最后一句带回来当提示正文；这些请求都在后台线程里，
            # 绝不放到界面线程上，否则会卡列表
            prevs = {}
            atme = {}
            for k in (added or {}):
                try:
                    if k in gids:
                        rows = _chat.fetch_group(k, since="2h", timeout=6)
                    else:
                        rows = _chat.fetch_remote(me, k, since="2h", timeout=6)
                    if rows:
                        # 这个群最近这批消息里，有没有 @ 我
                        if k in gids:
                            mine = [r for r in rows if _chat.at_me(r, me)]
                            if mine:
                                atme[k] = True
                        r = rows[-1]
                        who = r.get("from") or ""
                        txt = (r.get("text") or "").replace("\n", " ")
                        if len(txt) > 60:
                            txt = txt[:60] + "…"
                        prevs[k] = ("%s：%s" % (who, txt)) if who else txt
                except Exception:
                    pass
            self._inbox_pending = False
            if added:
                self.sig_inbox.emit({"added": added, "prev": prevs,
                                     "atme": atme})

        threading.Thread(target=work, daemon=True).start()

    def _inbox_added(self, payload):
        from core import notifyprefs as _np
        from core import chat as _chat
        added = (payload or {}).get("added") or {}
        prevs = (payload or {}).get("prev") or {}
        atme_map = (payload or {}).get("atme") or {}
        for k, n in (added or {}).items():
            self._unread[k] = self._unread.get(k, 0) + int(n)
        try:
            self._reload_friends()
            self._reload_groups()
        except Exception:
            pass
        # 右下角提示 + 叮：按「特别关心 > 全局免打扰 > 单个免打扰」判定
        gids = set()
        try:
            gids = set((g.get("id") or "") for g in _chat.group_list())
        except Exception:
            pass
        for k, n in (added or {}).items():
            is_group = k in gids
            atme = bool((atme_map or {}).get(k))
            alert, sound = _np.should_alert(gid=k if is_group else None,
                                            name=None if is_group else k,
                                            mention=atme)
            if not alert:
                continue
            try:
                if is_group and atme:
                    # 群里有人 @ 了我：标题里明确写出是哪个群，一眼就知道
                    title = "有人@你 · %s" % self._group_title(k)
                else:
                    title = ("群聊 · %s" % self._group_title(k)) if is_group \
                        else ("%s 给你发消息了" % k)
                body = prevs.get(k) or ("有 %d 条新消息" % int(n))
                if _np.is_star(k) and not is_group:
                    title = "特别关心 · %s" % k
                from ui import toast
                toast.notify(self, title, body,
                             "group" if is_group else "friend", k,
                             sound=sound or atme)
            except Exception:
                pass
        total = sum(self._unread.values())
        if total:
            self._log("收到 %d 条新聊天消息" % total)
        try:
            self._update_friend_badge()
        except Exception:
            pass

    def _group_title(self, gid):
        from core import chat as _chat
        try:
            for g in _chat.group_list():
                if (g.get("id") or "") == gid:
                    return g.get("title") or gid
        except Exception:
            pass
        return gid


    def _edit_friend(self):
        item = self.friend_list.currentItem()
        if not item:
            self.fsearch_state.setText("先在好友列表里点一个。")
            return
        it = item.data(Qt.UserRole) or {}
        if not it:
            return
        dlg = FriendEditDialog(it, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        v = dlg.values()
        ok, msg = friendbook.update_note(
            uid=it.get("uid"), name=it.get("name"), note=v["note"],
            group=v["group"], alias=v["alias"])
        self.fsearch_state.setText(msg)
        self._reload_friends()

    def _search_friends(self):
        q = (self.input_fsearch.text() or "").strip()
        from core import accounts
        names = [(u.get("name") or "") for u in accounts.users()]
        self.fsearch_list.clear()
        self.fsearch_state.setText("正在查目录…")
        self.btn_fsearch.setEnabled(False)
        self._friend_search = FriendSearchWorker(q, names)
        self._friend_search.done.connect(self._on_friend_search)
        self._friend_search.start()

    def _on_friend_search(self, hits):
        self.btn_fsearch.setEnabled(True)
        self.fsearch_list.clear()
        if not hits:
            self.fsearch_state.setText(
                "没搜到。让对方先在账号页登录一次、再点他账号页的「把我也挂到目录」；"
                "或者直接按好友 ID 加。")
            return
        self.fsearch_state.setText("找到 %d 个，选一个点「加为好友」：" % len(hits))
        for h in hits:
            text = "%s　·　%s" % (h.get("name") or "", h.get("src") or "")
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, h)
            item.setSizeHint(QSize(0, 30))
            try:
                item.setIcon(self._avatar_icon(h.get("name") or ""))
            except Exception:
                pass
            self.fsearch_list.addItem(item)

    def _add_search_hit(self):
        item = self.fsearch_list.currentItem()
        if not item:
            self.fsearch_state.setText("先在结果里点一个。")
            return
        h = item.data(Qt.UserRole) or {}
        ok, msg = friendbook.add(h.get("uid") or "", h.get("name") or "",
                                 src=h.get("src") or "")
        self.fsearch_state.setText(msg)
        self._reload_friends()

    def _remove_friend(self):
        item = self.friend_list.currentItem()
        if not item:
            self.fsearch_state.setText("先在好友列表里点一个。")
            return
        it = item.data(Qt.UserRole) or {}
        if not it:
            return
        if QMessageBox.question(self, "删除好友",
                                "把 %s 从好友列表里去掉？" % it.get("name")) != QMessageBox.Yes:
            return
        friendbook.remove(uid=it.get("uid"), name=it.get("name"))
        self._reload_friends()

    def _announce_self(self):
        from core import accounts
        u = accounts.current_user()
        if not u:
            QMessageBox.information(
                self, "先登录账号",
                "先到「账号」页登录一个账号，目录里才有你的名字。")
            return
        ok = frienddir.announce(u.get("name"), u.get("id") or u.get("name"))
        if ok:
            self.fsearch_state.setText(
                "已挂到目录：别人搜 %s 就能找到你（12 小时内有效）。" % u.get("name"))
            self._log("好友目录已公告当前账号")
        else:
            self.fsearch_state.setText("挂不上去，检查一下网络再试。")

    def _add_friend(self):
        fid = (self.input_friend.text() or "").strip()
        if not fid:
            self.fsearch_state.setText("先填对方的好友 ID。")
            return
        ok, msg = friendbook.add(uid=fid, name=fid, src="ID")
        self.fsearch_state.setText(msg)
        if ok:
            self.input_friend.clear()
            self._reload_friends()

    def _build_skins_page(self):
        """皮肤库：网格点选、搜索、穿搭、应用到游戏。

        整页放进滚动区：小屏或全屏 1536×864 时底部翻页行原来会被挤掉一半，
        包一层滚动后无论多高都能滚到底，不会再有内容被裁。
        """
        self.skin_page = SkinLibraryPage(
            self.config,
            game_dir_getter=lambda: self.config.get("game_dir"),
            version_getter=lambda: self.config.get("last_version"),
            username_getter=lambda: (self.config.get("username") or "Player"),
            log=self._log)
        wrap = QScrollArea()
        wrap.setObjectName("SkinLibScroll")
        wrap.setWidgetResizable(True)
        wrap.setFrameShape(QFrame.NoFrame)
        wrap.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        wrap.setWidget(self.skin_page)
        self.skin_scroll = wrap
        return wrap

    def _tab_host_room(self):
        """开放联机：自己开房，设名称封面，管理成员。"""
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        host = QVBoxLayout()
        host.setContentsMargins(22, 20, 22, 20)
        host.setSpacing(12)
        host.addWidget(self._field_label(i18n.tr("lan_open_title")))
        hrow = QHBoxLayout()
        hrow.setSpacing(14)
        self.room_cover_label = QLabel()
        self.room_cover_label.setFixedSize(76, 76)
        self.room_cover_label.setAlignment(Qt.AlignCenter)
        self.room_cover_label.setObjectName("RoomCover")
        hrow.addWidget(self.room_cover_label)
        col = QVBoxLayout()
        col.setSpacing(8)
        self.input_room_name = QLineEdit()
        self.input_room_name.setPlaceholderText(i18n.tr("lan_room_name_ph"))
        col.addWidget(self.input_room_name)
        brow = QHBoxLayout()
        brow.setSpacing(8)
        self.btn_room_cover = QPushButton(i18n.tr("lan_cover_pick"))
        self.btn_room_cover.clicked.connect(self._pick_room_cover)
        self.btn_room_cover_clear = QPushButton(i18n.tr("lan_cover_clear"))
        self.btn_room_cover_clear.clicked.connect(self._clear_room_cover)
        brow.addWidget(self.btn_room_cover)
        brow.addWidget(self.btn_room_cover_clear)
        brow.addStretch(1)
        col.addLayout(brow)
        # 房间密码：留空就是谁都能进；设了就写进房间广播，别人得先对上密码
        self.input_room_pass = QLineEdit()
        self.input_room_pass.setPlaceholderText("房间密码（留空 = 不设密码）")
        self.input_room_pass.setMaxLength(12)
        self.input_room_pass.setEchoMode(QLineEdit.Password)
        col.addWidget(self.input_room_pass)
        # 谁能进：公开 / 仅好友 / 邀请码（后两种都要求先对密码）
        self.combo_room_mode = QComboBox()
        self.combo_room_mode.addItem("公开：同 Wi-Fi 的人在列表里就能看到并加入",
                                    "public")
        self.combo_room_mode.addItem("仅好友：只有好友列表里的账号能进",
                                    "friends")
        self.combo_room_mode.addItem("邀请码：拿到房间码 / 密码才能进", "code")
        self.combo_room_mode.setToolTip(
            "仅好友会把好友的账号名写进服务端白名单；邀请码就是下面的房间密码")
        self.combo_room_mode.currentIndexChanged.connect(
            self._on_room_mode_changed)
        col.addWidget(self.combo_room_mode)

        # 房间标签：开房时挑几个，别人在房间列表里一眼看出这房怎么玩
        col.addWidget(QLabel("房间标签（可多选，最多 3 个）"))
        tagrow = QHBoxLayout()
        tagrow.setSpacing(6)
        self._room_tag_boxes = {}
        _cur_tags = set(self.config.get("room_tags") or [])
        for key, label in (("survival", "原版生存"), ("creative", "创造"),
                           ("build", "建筑"), ("redstone", "红石"),
                           ("mod", "模组"), ("minigame", "小游戏"),
                           ("newbie", "新手友好")):
            cb = QCheckBox(label)
            cb.setChecked(key in _cur_tags)
            cb.toggled.connect(self._on_room_tag_toggled)
            tagrow.addWidget(cb)
            self._room_tag_boxes[key] = cb
        tagrow.addStretch(1)
        col.addLayout(tagrow)
        hrow.addLayout(col, 1)
        self.btn_open_room = QPushButton(i18n.tr("lan_open"))
        self.btn_open_room.setObjectName("PrimaryButton")
        self.btn_open_room.clicked.connect(self._toggle_open_room)
        hrow.addWidget(self.btn_open_room)
        host.addLayout(hrow)
        self.label_open_state = QLabel(i18n.tr("lan_open_idle"))
        self.label_open_state.setObjectName("FieldLabel")
        self.label_open_state.setWordWrap(True)
        host.addWidget(self.label_open_state)
        self.btn_copy_code = QPushButton(i18n.tr("lan_copy_code"))
        self.btn_copy_code.clicked.connect(self._copy_room_code)
        host.addWidget(self.btn_copy_code)
        self.btn_copy_room_info = QPushButton("复制房间信息发给好友")
        self.btn_copy_room_info.setToolTip("把房间名、房间码、进入方式整理成一段话，直接粘给好友")
        self.btn_copy_room_info.clicked.connect(self._copy_room_info)
        host.addWidget(self.btn_copy_room_info)
        self.label_room_code = QLabel(i18n.tr("lan_no_room"))
        self.label_room_code.setObjectName("FieldLabel")
        host.addWidget(self.label_room_code)
        v.addWidget(card(host))

        # 我的房间成员（托管服务端可用 RCON 管理）
        mgr = QVBoxLayout()
        mgr.setContentsMargins(22, 20, 22, 20)
        mgr.setSpacing(10)
        mgr.addWidget(self._field_label(i18n.tr("lan_players")))
        self.label_lan_mgr = QLabel(i18n.tr("lan_mgr_hint"))
        self.label_lan_mgr.setObjectName("FieldLabel")
        self.label_lan_mgr.setWordWrap(True)
        mgr.addWidget(self.label_lan_mgr)
        prow = QHBoxLayout()
        prow.setSpacing(10)
        self.room_players = QListWidget()
        self.room_players.setMinimumHeight(110)
        prow.addWidget(self.room_players, 1)
        pcol = QVBoxLayout()
        pcol.setSpacing(8)
        self.btn_kick = QPushButton(i18n.tr("lan_kick"))
        self.btn_kick.clicked.connect(lambda: self._room_command("kick"))
        self.btn_op = QPushButton(i18n.tr("lan_op"))
        self.btn_op.clicked.connect(lambda: self._room_command("op"))
        self.btn_deop = QPushButton(i18n.tr("lan_deop"))
        self.btn_deop.clicked.connect(lambda: self._room_command("deop"))
        # MC 没有原生命令能只屏蔽聊天，所以这里的「禁言」= 踢出去并封禁，
        # 免得他重新进房继续刷屏；下次开房时 ban 列表不会自动清。
        self.btn_ban = QPushButton("禁言（踢出并封禁）")
        self.btn_ban.setToolTip("用 RCON 执行 ban：他会被踢出去，而且进不来，直到你解封")
        self.btn_ban.clicked.connect(self._room_ban)
        self.btn_unban = QPushButton("解除禁言")
        self.btn_unban.clicked.connect(self._room_unban)
        pcol.addWidget(self.btn_kick)
        pcol.addWidget(self.btn_op)
        pcol.addWidget(self.btn_deop)
        pcol.addWidget(self.btn_ban)
        pcol.addWidget(self.btn_unban)
        pcol.addStretch(1)
        prow.addLayout(pcol)
        mgr.addLayout(prow)
        v.addWidget(card(mgr))
        v.addStretch(1)
        return self._scroll_wrap(page)

    def _tab_invite_room(self):
        """纯邀请码联机：房主在游戏里「对局域网开放」后生成码，好友只靠码进入。

        不依赖启动器托管服务端，也不依赖房间列表刷新，就是最早那套用法。
        """
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        host = QVBoxLayout()
        host.setContentsMargins(22, 20, 22, 20)
        host.setSpacing(10)
        host.addWidget(self._field_label(i18n.tr("lan_invite_host_title")))
        hint = QLabel(i18n.tr("lan_invite_host_hint"))
        hint.setObjectName("FieldLabel")
        hint.setWordWrap(True)
        host.addWidget(hint)
        self.btn_invite_detect = QPushButton(i18n.tr("lan_invite_detect"))
        self.btn_invite_detect.clicked.connect(self._invite_generate)
        host.addWidget(self.btn_invite_detect)
        self.label_invite_code = QLabel(i18n.tr("lan_no_room"))
        self.label_invite_code.setObjectName("FieldLabel")
        self.label_invite_code.setWordWrap(True)
        self.label_invite_code.setTextInteractionFlags(Qt.TextSelectableByMouse)
        host.addWidget(self.label_invite_code)
        self.btn_invite_copy = QPushButton(i18n.tr("lan_copy_code"))
        self.btn_invite_copy.clicked.connect(self._invite_copy)
        host.addWidget(self.btn_invite_copy)
        note = QLabel(i18n.tr("lan_invite_net_note"))
        note.setObjectName("FieldLabel")
        note.setWordWrap(True)
        host.addWidget(note)
        v.addWidget(card(host))

        join = QVBoxLayout()
        join.setContentsMargins(22, 20, 22, 20)
        join.setSpacing(10)
        join.addWidget(self._field_label(i18n.tr("lan_invite_join_title")))
        self.input_invite_code = QLineEdit()
        self.input_invite_code.setPlaceholderText(i18n.tr("lan_invite_code_ph"))
        self.input_invite_code.returnPressed.connect(self._invite_join)
        join.addWidget(self.input_invite_code)
        b_join = QPushButton(i18n.tr("lan_invite_join"))
        b_join.setObjectName("PrimaryButton")
        b_join.clicked.connect(self._invite_join)
        join.addWidget(b_join)
        v.addWidget(card(join))
        v.addStretch(1)
        return self._scroll_wrap(page)

    def _invite_generate(self):
        if self._invite_busy():
            return
        self._invite_code = ""
        self.label_invite_code.setText(i18n.tr("lan_scanning"))
        self._invite_worker = self._track(LanDetectWorker(True))
        self._invite_worker.found.connect(self._on_invite_rooms)
        self._invite_worker.start()

    def _invite_busy(self):
        w = self._invite_worker
        if w is None:
            return False
        try:
            return w.isRunning()
        except RuntimeError:
            self._invite_worker = None
            return False

    def _on_invite_rooms(self, rooms):
        rooms = rooms or []
        if not rooms:
            self.label_invite_code.setText(i18n.tr("lan_invite_need_room"))
            return
        room = rooms[0]
        ip = room.get("ip") or lan.lan_ip()
        port = int(room["port"])
        self._invite_code = lan.make_code(ip, port)
        self.label_invite_code.setText(
            "%s\n%s" % (i18n.tr("lan_invite_code_n", self._invite_code),
                        i18n.tr("lan_invite_code_hint")))

    def _invite_copy(self):
        if not self._invite_code:
            return
        QApplication.clipboard().setText(self._invite_code)
        self._log(i18n.tr("lan_code_copied", self._invite_code))

    def _invite_join(self):
        code = self.input_invite_code.text().strip()
        if not code:
            return
        try:
            ip, port = lan.parse_code(code)
        except Exception:
            QMessageBox.warning(self, i18n.tr("tip"),
                                "邀请码看不懂，确认是从启动器里复制的整串")
            return
        self._join_endpoint(ip, port)

    # ---------- OMC 公共服（玩家不用注册任何平台，填地址就进） ----------
    def _pub_info(self):
        """当前生效的公共服信息：本地配置优先，其次站点上的配置。"""
        info = pubserver.load(self.config)
        if info:
            return info
        try:
            return pubserver.fetch_remote()
        except Exception:
            return None

    def _refresh_public_status(self):
        if not hasattr(self, "pub_state_label"):
            return
        info = self._pub_info()
        if not info:
            self.pub_name_label.setText("OMC 公共服")
            self.pub_addr_label.setText("还没有配置公共服地址")
            self.pub_state_label.setText(
                "管理员把服务器地址配好后，这里会自动出现，玩家不用注册任何平台。")
            self.btn_pub_join.setEnabled(False)
            self.btn_pub_copy.setEnabled(False)
            return
        self.pub_name_label.setText(info["name"])
        self.pub_addr_label.setText(info["addr"])
        self.btn_pub_join.setEnabled(True)
        self.btn_pub_copy.setEnabled(True)
        self.pub_state_label.setText("正在检测服务器状态…")
        worker = PublicStatusWorker(info["host"], info["port"], self)
        self._pub_worker = worker
        worker.done.connect(self._on_public_status)
        worker.start()

    def _on_public_status(self, result):
        info = self._pub_info()
        if not info or not hasattr(self, "pub_state_label"):
            return
        if result.get("online"):
            text = "在线 · %d/%d 人" % (result.get("players", 0),
                                      result.get("max_players", 0))
            if result.get("version"):
                text += " · 版本 %s" % result["version"]
            if result.get("latency_ms"):
                text += " · %d ms" % result["latency_ms"]
            motd = (result.get("motd") or "").strip()
            if motd:
                text += "\n" + motd.replace("\n", " ")
            self.pub_state_label.setText(text)
        else:
            self.pub_state_label.setText(
                "当前离线（%s）。服务器由作者维护，稍后再点一次刷新。"
                % (result.get("error") or "连接失败"))

    def _copy_public_addr(self):
        info = self._pub_info()
        if not info:
            QMessageBox.warning(self, "没有地址", "公共服地址还没配置。")
            return
        QApplication.clipboard().setText(pubserver.share_text(info))
        self._log("公共服地址已复制：%s" % info["addr"])

    def _edit_public_addr(self):
        """填/改公共服地址。配一次就存进配置，之后玩家打开启动器就能看到。"""
        info = pubserver.load(self.config)
        cur = info["addr"] if info else ""
        text, ok = QInputDialog.getText(self, "公共服地址",
                                        "填服务器地址，带端口，例如 1.2.3.4:25565：",
                                        text=cur)
        if not ok:
            return
        try:
            saved = pubserver.save(self.config, (text or "").strip())
        except Exception as e:
            QMessageBox.warning(self, "地址不对", str(e))
            return
        self._log("公共服地址已保存：%s" % saved["addr"])
        self._refresh_public_status()

    def _join_public(self):
        info = self._pub_info()
        if not info:
            QMessageBox.warning(self, "没有地址", "公共服地址还没配置。")
            return
        self._join_endpoint(info["host"], info["port"])

    def _tab_join_room(self):
        """加入联机：看别人的房间列表直接进，或用邀请码。"""
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(14)

        # OMC 公共服：作者维护的一台常开服务器，玩家不用注册任何平台就能进
        pv = QVBoxLayout()
        pv.setContentsMargins(22, 20, 22, 20)
        pv.setSpacing(8)
        self.pub_name_label = QLabel("OMC 公共服")
        self.pub_name_label.setObjectName("FieldLabel")
        pv.addWidget(self.pub_name_label)
        self.pub_addr_label = QLabel("正在读取地址…")
        self.pub_addr_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        pv.addWidget(self.pub_addr_label)
        self.pub_state_label = QLabel("")
        self.pub_state_label.setObjectName("FieldLabel")
        self.pub_state_label.setWordWrap(True)
        pv.addWidget(self.pub_state_label)
        hrow_pub = QHBoxLayout()
        hrow_pub.setSpacing(10)
        self.btn_pub_join = QPushButton("加入公共服")
        self.btn_pub_join.setObjectName("PrimaryButton")
        self.btn_pub_join.clicked.connect(self._join_public)
        self.btn_pub_copy = QPushButton("复制地址")
        self.btn_pub_copy.setToolTip("复制地址和进入方式，直接粘给朋友")
        self.btn_pub_copy.clicked.connect(self._copy_public_addr)
        self.btn_pub_refresh = QPushButton("刷新状态")
        self.btn_pub_refresh.clicked.connect(self._refresh_public_status)
        self.btn_pub_set = QPushButton("设置地址")
        self.btn_pub_set.setToolTip("填公共服地址（IP:端口），配一次就行")
        self.btn_pub_set.clicked.connect(self._edit_public_addr)
        hrow_pub.addWidget(self.btn_pub_join, 1)
        hrow_pub.addWidget(self.btn_pub_copy)
        hrow_pub.addWidget(self.btn_pub_refresh)
        hrow_pub.addWidget(self.btn_pub_set)
        pv.addLayout(hrow_pub)
        v.addWidget(card(pv))

        join = QVBoxLayout()
        join.setContentsMargins(22, 20, 22, 20)
        join.setSpacing(10)
        join.addWidget(self._field_label(i18n.tr("lan_join_title")))
        self.input_room_code = QLineEdit()
        self.input_room_code.setPlaceholderText(i18n.tr("lan_code_ph"))
        join.addWidget(self.input_room_code)
        b_join = QPushButton(i18n.tr("lan_join"))
        b_join.setObjectName("PrimaryButton")
        b_join.clicked.connect(self._join_room)
        join.addWidget(b_join)
        v.addWidget(card(join))

        det = QVBoxLayout()
        det.setContentsMargins(22, 20, 22, 20)
        det.setSpacing(10)
        det.addWidget(self._field_label(i18n.tr("lan_detect_hint")))
        hrow2 = QHBoxLayout()
        hrow2.setSpacing(10)
        self.btn_lan_refresh = QPushButton(i18n.tr("lan_refresh"))
        self.btn_lan_refresh.clicked.connect(self._rescan_lan_rooms)
        self.label_lan_state = QLabel(i18n.tr("lan_scan_wait"))
        self.label_lan_state.setObjectName("FieldLabel")
        hrow2.addWidget(self.btn_lan_refresh)
        hrow2.addWidget(self.label_lan_state, 1)
        det.addLayout(hrow2)

        self.lan_list = QListWidget()
        self.lan_list.setMinimumHeight(260)
        self.lan_list.setSpacing(2)
        self.lan_list.itemSelectionChanged.connect(self._on_room_selected)
        det.addWidget(self.lan_list)
        v.addWidget(card(det))

        # 最近连过的房间：不用再翻聊天记录找房间码
        his = QVBoxLayout()
        his.setContentsMargins(22, 20, 22, 20)
        his.setSpacing(10)
        his.addWidget(self._field_label("最近连过的房间"))
        hhint = QLabel("双击一行就直接连回那个房间（版本要对得上）。")
        hhint.setObjectName("FieldLabel")
        hhint.setWordWrap(True)
        his.addWidget(hhint)
        self.history_rooms = QListWidget()
        self.history_rooms.setMinimumHeight(108)
        self.history_rooms.itemDoubleClicked.connect(self._join_from_history)
        his.addWidget(self.history_rooms)
        hrow3 = QHBoxLayout()
        b_clear = QPushButton("清空记录")
        b_clear.clicked.connect(self._clear_room_history)
        hrow3.addWidget(b_clear)
        hrow3.addStretch(1)
        his.addLayout(hrow3)
        v.addWidget(card(his))
        self._reload_room_history()
        self._refresh_public_status()
        v.addStretch(1)
        return self._scroll_wrap(page)

    # ---------- 开放我的房间 ----------
    def _room_cover_path(self):
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher")
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            pass
        return os.path.join(d, "room_cover.png")

    def _load_room_cover(self):
        data = None
        p = self._room_cover_path()
        if os.path.exists(p):
            try:
                with open(p, "rb") as f:
                    data = f.read()
            except Exception:
                data = None
        self._room_cover_bytes = data
        self._apply_cover_preview(data)

    def _apply_cover_preview(self, data):
        if not hasattr(self, "room_cover_label"):
            return
        pix = QPixmap()
        if data and pix.loadFromData(data):
            self.room_cover_label.setPixmap(
                pix.scaled(76, 76, Qt.KeepAspectRatioByExpanding,
                           Qt.SmoothTransformation))
        else:
            self.room_cover_label.setPixmap(self._placeholder_pix("MC"))

    def _pick_room_cover(self):
        path, _ = QFileDialog.getOpenFileName(
            self, i18n.tr("lan_cover"), "",
            "图片 (*.png *.jpg *.jpeg *.bmp *.webp)")
        if not path:
            return
        try:
            with open(path, "rb") as f:
                data = f.read()
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        if len(data) > 8 * 1024 * 1024:
            QMessageBox.warning(self, i18n.tr("tip"), "图片过大（上限 8MB）")
            return
        try:
            lanroom.save_cover(self._room_cover_path(), data)
        except Exception:
            pass
        self._room_cover_bytes = data
        self._apply_cover_preview(data)

    def _clear_room_cover(self):
        self._room_cover_bytes = None
        p = self._room_cover_path()
        try:
            if os.path.exists(p):
                os.remove(p)
        except Exception:
            pass
        self._apply_cover_preview(None)

    def _toggle_open_room(self):
        srv = self.room_server
        if srv and srv.running():
            self._stop_open_room()
            return
        vid = self._selected_version_id()
        if not vid:
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("lan_no_room"))
            return
        jpath = self._version_json_path(vid)
        if not os.path.exists(jpath):
            QMessageBox.warning(self, i18n.tr("tip"),
                                i18n.tr("lan_open_failed", vid))
            return
        java = (self.config.get("java_path") or "").strip()
        if not java or not os.path.exists(java):
            java = java_utils.pick_for(launcher.required_java_major(jpath))
        if not java:
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("lan_open_failed",
                                                             "Java"))
            return
        name = self.input_room_name.text().strip()
        mem = int(self.config.get("memory_mb") or 4096)
        pwd = "omc%08x" % int.from_bytes(os.urandom(4), "big")
        self.btn_open_room.setEnabled(False)
        self.label_open_state.setText(i18n.tr("lan_opening"))
        w = RoomStartWorker(self.config.get("game_dir"), vid,
                            getattr(self, "version_data", []),
                            self.config.get("mirror") or "official",
                            java, mem, pwd, motd=name or None)
        w.log.connect(self._log)
        w.ready.connect(lambda server: self._on_room_ready(server, vid, pwd))
        w.failed.connect(self._on_room_failed)
        self._room_worker = self._track(w)
        w.start()

    def _on_room_ready(self, server, vid, pwd):
        self.room_server = server
        self._room_vid = vid
        self.btn_open_room.setEnabled(True)
        self.btn_open_room.setText(i18n.tr("lan_close"))
        self.input_room_name.setEnabled(False)

        def provider():
            pw = (self.input_room_pass.text() or "").strip()
            mode = self._room_mode()
            return {
                "name": self.input_room_name.text().strip() or "OMC Room",
                "version": vid,
                "host": self.config.get("username") or "Player",
                "ip": lan.lan_ip(),
                "port": server.port,
                "max": 20,
                "cover": bool(self._room_cover_bytes),
                "locked": bool(pw) or mode == "friends",
                "pass": self._room_pass_hash(pw) if pw else "",
                "mode": mode,
                "friends": self._friend_names() if mode == "friends" else [],
                "tags": self._room_tags(),
            }

        self.room_meta = lanroom.RoomMetaServer(
            server.port, provider, lambda: self._room_cover_bytes)
        meta_port = self.room_meta.start()
        if meta_port is None:
            self._log("封面服务端口被占用，房间仍可加入，只是没有自定义封面")
        code = lan.make_code(lan.lan_ip(), server.port)
        self.label_open_state.setText(i18n.tr("lan_open_ok", code))
        self.label_room_code.setText(i18n.tr("lan_code_n", code))
        self._log(i18n.tr("lan_room_started"))
        # 按「谁能进」把白名单/白名单开关落到这个房间的服务端
        try:
            self._apply_room_whitelist(self._room_mode(), vid, server)
        except Exception as e:
            self._log("设置房间权限失败：%s" % e)
        self._refresh_lan_rooms()

    def _on_room_failed(self, msg):
        self.btn_open_room.setEnabled(True)
        self.btn_open_room.setText(i18n.tr("lan_open"))
        self.input_room_name.setEnabled(True)
        self.label_open_state.setText(i18n.tr("lan_open_failed", msg))
        self._log(i18n.tr("lan_open_failed", msg))

    def _stop_open_room(self):
        if self.room_meta:
            try:
                self.room_meta.stop()
            except Exception:
                pass
            self.room_meta = None
        if self.room_server:
            try:
                self.room_server.stop()
            except Exception:
                pass
            self.room_server = None
        self.btn_open_room.setEnabled(True)
        self.btn_open_room.setText(i18n.tr("lan_open"))
        self.input_room_name.setEnabled(True)
        self.label_open_state.setText(i18n.tr("lan_open_idle"))
        self.label_room_code.setText(i18n.tr("lan_no_room"))
        self._set_player_manage(False)
        self.room_players.clear()
        self._refresh_lan_rooms()

    def _title(self, text):
        lab = QLabel(text)
        lab.setObjectName("PageTitle")
        return lab

    # ---------- 联机：检测本机局域网房间 ----------
    def _start_lan_watch(self):
        self._refresh_lan_rooms()
        if not self.lan_timer.isActive():
            self.lan_timer.start(7000)

    def _lan_busy(self):
        w = self._lan_worker
        if w is None:
            return False
        try:
            return w.isRunning()
        except RuntimeError:
            self._lan_worker = None
            return False

    def _rescan_lan_rooms(self):
        """手动重扫：允许全端口兜底，确保不管什么进程开房都能找到。"""
        if self._lan_busy():
            return
        self.label_lan_state.setText(i18n.tr("lan_scanning"))
        self._lan_worker = self._track(LanDetectWorker(True))
        self._lan_worker.found.connect(self._on_lan_rooms)
        self._lan_worker.start()

    def _refresh_lan_rooms(self):
        if self._lan_busy():
            return
        if not self._lan_rooms:
            self.label_lan_state.setText(i18n.tr("lan_scanning"))
        self._lan_worker = self._track(LanDetectWorker(False))
        self._lan_worker.found.connect(self._on_lan_rooms)
        self._lan_worker.start()

    def _on_lan_rooms(self, rooms):
        self._lan_rooms = rooms or []
        self._rebuild_room_list()
        if not self._lan_rooms:
            self.label_lan_state.setText(i18n.tr("lan_none"))
            self.label_room_code.setText(i18n.tr("lan_no_room"))
            self.room_players.clear()
            self._set_player_manage(False)
            return
        self.label_lan_state.setText(
            i18n.tr("lan_found_n", len(self._lan_rooms)))
        # 再异步拉房主发布的名称与封面（拿不到就退回 MOTD）
        if self._meta_worker is not None:
            try:
                if self._meta_worker.isRunning():
                    return
            except RuntimeError:
                self._meta_worker = None
        w = RoomMetaWorker(list(self._lan_rooms))
        w.ready.connect(self._on_room_metas)
        self._meta_worker = self._track(w)
        w.start()

    def _on_room_metas(self, results):
        for ip, port, meta, cover in results or []:
            key = (ip, int(port))
            if meta:
                self._room_meta_map[key] = meta
            if cover:
                self._room_covers[key] = cover
        self._rebuild_room_list()

    def _rebuild_room_list(self):
        cur = self._current_room()
        cur_key = (cur.get("ip"), int(cur["port"])) if cur else None
        self.lan_list.blockSignals(True)
        self.lan_list.clear()
        for r in self._lan_rooms:
            key = (r.get("ip") or "127.0.0.1", int(r["port"]))
            meta = self._room_meta_map.get(key)
            cover = self._room_covers.get(key)
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, 92))
            item.setData(Qt.UserRole, dict(r))
            self.lan_list.addItem(item)
            self.lan_list.setItemWidget(item, self._room_row(r, meta, cover))
        self.lan_list.blockSignals(False)
        if not self._lan_rooms:
            return
        idx = 0
        for i, r in enumerate(self._lan_rooms):
            if (r.get("ip"), int(r["port"])) == cur_key:
                idx = i
        self.lan_list.setCurrentRow(idx)
        self._on_room_selected()

    def _room_row(self, room, meta, cover):
        """房间卡片：左封面、中名称/信息、右「进入」，与模组列表同一套观感。"""
        meta = meta or {}
        name = (meta.get("name") or room.get("motd")
                or room.get("version") or ("端口 %d" % room["port"]))
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(10, 8, 10, 8)
        h.setSpacing(12)

        icon = QLabel()
        icon.setFixedSize(88, 68)
        icon.setAlignment(Qt.AlignCenter)
        icon.setObjectName("ModIcon")
        pix = QPixmap()
        if cover and pix.loadFromData(cover):
            icon.setPixmap(pix.scaled(88, 68, Qt.KeepAspectRatioByExpanding,
                                      Qt.SmoothTransformation))
        else:
            icon.setPixmap(self._placeholder_pix(str(name)[:2].upper()))
        h.addWidget(icon)

        col = QVBoxLayout()
        col.setSpacing(4)
        _tags = [t for t in (meta.get("tags") or []) if t][:3]
        _tag_txt = ("　· " + " / ".join(str(t) for t in _tags)) if _tags else ""
        title = QLabel(str(name) + ("　[有密码]" if meta.get("locked") else "")
                       + _tag_txt)
        tf = QFont()
        tf.setBold(True)
        title.setFont(tf)
        col.addWidget(title)

        tag = i18n.tr("lan_local_tag") if not room.get("remote") \
            else i18n.tr("lan_remote_tag")
        sub = i18n.tr("lan_room_sub", room.get("version") or "-",
                      int(room.get("online") or 0), int(room.get("max") or 0),
                      tag)
        host = meta.get("host")
        if host:
            sub = sub + " | " + str(host)
        s = QLabel(sub)
        s.setObjectName("FieldLabel")
        col.addWidget(s)
        h.addLayout(col, 1)

        btn = QPushButton(i18n.tr("lan_enter"))
        btn.setFixedWidth(92)
        btn.setObjectName("PrimaryButton")
        ip = room.get("ip") or "127.0.0.1"
        port = int(room["port"])
        btn.clicked.connect(
            lambda _=False, a=ip, b=port: self._join_endpoint(a, b))
        h.addWidget(btn)
        return row

    def _current_room(self):
        item = self.lan_list.currentItem()
        return item.data(Qt.UserRole) if item else None

    def _on_room_selected(self):
        room = self._current_room()
        if not room:
            return
        code = self._room_code()
        self.label_room_code.setText(i18n.tr("lan_code_n", code))
        self._refresh_room_players()

    def _room_code(self):
        room = self._current_room()
        if not room:
            return ""
        return lan.make_code(room.get("ip") or lan.lan_ip(), int(room["port"]))

    def _copy_room_code(self):
        code = self._room_code()
        if not code:
            return
        QApplication.clipboard().setText(code)
        self._log(i18n.tr("lan_code_copied", code))

    def _owned_server(self, room):
        """该端口是不是本启动器托管的服务端（只有它才有 RCON 可远程管理）。"""
        srv = self.room_server
        if not (srv and srv.running() and room):
            return None
        if room.get("pid") == getattr(srv.proc, "pid", None):
            return srv
        return None

    def _set_player_manage(self, enabled):
        for b in (self.btn_kick, self.btn_op, self.btn_deop):
            b.setEnabled(enabled)

    def _refresh_room_players(self):
        room = self._current_room()
        if not room:
            return
        srv = self._owned_server(room)
        self.room_players.clear()
        if srv:
            self.label_lan_mgr.setText(i18n.tr("lan_mgr_rcon"))
            self._set_player_manage(True)
            try:
                for nm in lan.player_list(srv):
                    it = QListWidgetItem(nm)
                    it.setSizeHint(QSize(0, 28))
                    try:
                        it.setIcon(self._avatar_icon(nm))
                    except Exception:
                        pass
                    self.room_players.addItem(it)
            except Exception:
                pass
            return
        self._set_player_manage(False)
        self.label_lan_mgr.setText(i18n.tr("lan_mgr_hint"))
        for name in room.get("names") or []:
            it = QListWidgetItem(name)
            it.setSizeHint(QSize(0, 28))
            try:
                it.setIcon(self._avatar_icon(name))
            except Exception:
                pass
            self.room_players.addItem(it)
        if not self.room_players.count():
            self.room_players.addItem(
                i18n.tr("lan_online_n", room["online"], room["max"]))

    def _room_command(self, kind):
        room = self._current_room()
        srv = self._owned_server(room)
        item = self.room_players.currentItem()
        if not (srv and item):
            QMessageBox.information(self, i18n.tr("tip"),
                                    i18n.tr("lan_mgr_hint"))
            return
        try:
            out = srv.command("%s %s" % (kind, item.text()))
            if out:
                self._log(out)
            self._refresh_room_players()
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))

    # ---------- 联机：加入 ----------
    def _room_mode(self):
        try:
            return self.combo_room_mode.currentData() or "public"
        except Exception:
            return "public"

    def _friend_names(self):
        names = []
        try:
            for it in friendbook.items():
                n = (it.get("name") or "").strip()
                if n and n.lower() not in [x.lower() for x in names]:
                    names.append(n)
        except Exception:
            pass
        return names

    def _room_tags(self):
        """当前勾选的房间标签（给房间广播用）。"""
        out = []
        for _k, cb in getattr(self, "_room_tag_boxes", {}).items():
            try:
                if cb.isChecked():
                    out.append(cb.text())
            except RuntimeError:
                continue
        return out[:3]

    def _on_room_tag_toggled(self, _on=False):
        tags = self._room_tags()
        if len(tags) > 3:
            # 最多三个，多勾的自动取消（从新勾的开始退）
            for _k, cb in getattr(self, "_room_tag_boxes", {}).items():
                if cb.isChecked() and cb.text() in tags[3:]:
                    try:
                        cb.blockSignals(True)
                        cb.setChecked(False)
                        cb.blockSignals(False)
                    except RuntimeError:
                        pass
            tags = self._room_tags()
            self._log("房间标签最多选 3 个，多的已取消")
        keys = [k for k, cb in getattr(self, "_room_tag_boxes", {}).items()
                if cb.isChecked()]
        self.config.set("room_tags", keys)
        try:
            self.config.save()
        except Exception:
            pass
        if getattr(self, "label_open_state", None) is not None:
            cur = " / ".join(tags) if tags else "没选标签"
            self._log("房间标签：" + cur)

    def _on_room_mode_changed(self, _i=0):
        """房间开着的时候改「谁能进」，立刻按新规则重写白名单。"""
        srv = self.room_server
        if not (srv and srv.running()):
            return
        try:
            self._apply_room_whitelist(self._room_mode(),
                                       getattr(self, "_room_vid", ""), srv)
        except Exception as e:
            self._log("切换房间权限失败：%s" % e)

    def _apply_room_whitelist(self, mode, vid, srv):
        """仅好友：把好友账号名写进服务端白名单，并打开 white-list。

        访客模式（公开 / 邀请码）会把白名单关掉，避免上次开仅好友留下的
        白名单把人挡在外面。
        """
        gd = self.config.get("game_dir") or ""
        if not gd or not vid:
            return
        try:
            d = lan.room_dir(gd, vid)
        except Exception as e:
            self._log("找不到房间目录：%s" % e)
            return
        names = self._friend_names() if mode == "friends" else []
        try:
            with open(os.path.join(d, "whitelist.json"), "w",
                      encoding="utf-8") as f:
                json.dump([{"name": n, "uuid": ""} for n in names], f,
                          ensure_ascii=False, indent=2)
        except Exception as e:
            self._log("写白名单失败：%s" % e)
            return
        path = os.path.join(d, "server.properties")
        try:
            lines = []
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    lines = f.read().splitlines()
            want = {
                "white-list": "true" if mode == "friends" else "false",
                "enforce-whitelist": "true" if mode == "friends" else "false",
            }
            keys = {ln.split("=", 1)[0]: i for i, ln in enumerate(lines)
                    if "=" in ln}
            for k, v in want.items():
                entry = "%s=%s" % (k, v)
                if k in keys:
                    lines[keys[k]] = entry
                else:
                    lines.append(entry)
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
        except Exception as e:
            self._log("改 server.properties 失败：%s" % e)
        # 服务端刚启动时还没开 RCON，等一会儿再让它重读白名单
        def reload_wl():
            try:
                if srv and srv.running():
                    srv.command("whitelist reload")
            except Exception as e:
                self._log("重读白名单失败：%s" % e)
        try:
            QTimer.singleShot(4000, reload_wl)
        except Exception:
            pass
        if mode == "friends":
            self._log("房间改为仅好友：白名单里 %d 个好友账号" % len(names))
        else:
            self._log("房间白名单已关闭（%s）" % mode)

    def _copy_room_info(self):
        srv = self.room_server
        if not (srv and srv.running()):
            QMessageBox.information(self, "还没开房",
                                    "先在上面点「开放我的房间」，房间开起来再复制。")
            return
        name = self.input_room_name.text().strip() or "OMC 房间"
        code = lan.make_code(lan.lan_ip(), srv.port)
        mode = self._room_mode()
        pw = (self.input_room_pass.text() or "").strip()
        vid = getattr(self, "_room_vid", "") or self._selected_version_id()
        text = ("我在 OMC 开了个《我的世界》房间：%s\n版本：%s\n房间码：%s\n"
                "进入方式：启动器 → 联机 → 加入联机 → 粘贴房间码 → 加入\n"
                % (name, vid or "-", code))
        if mode == "code":
            text += ("这个房间是邀请码模式，房间里密码是：%s\n"
                     % pw if pw else "这个房间是邀请码模式，密码我另外发你。\n")
        elif mode == "friends":
            text += "只有我的好友能进，你在我好友列表里直接加就行。\n"
        try:
            QApplication.clipboard().setText(text)
            self._log("房间信息已复制到剪贴板，直接粘给好友就行")
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))

    def _room_ban(self):
        room = self._current_room()
        srv = self._owned_server(room)
        item = self.room_players.currentItem()
        if not (srv and item):
            QMessageBox.information(self, i18n.tr("tip"),
                                    "先选一个房间里的玩家。")
            return
        name = item.text().strip()
        if QMessageBox.question(
                self, "禁言这个玩家",
                "把 %s 踢出去并封禁？\n"
                "MC 没有只关掉聊天的命令，所以「禁言」是用 ban 实现："
                "他会被踢出去，重新连也进不来，直到你解除禁言。" % name,
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No) != QMessageBox.Yes:
            return
        try:
            out = srv.command("ban %s 被房主禁言" % name)
            if out:
                self._log(out)
            self._refresh_room_players()
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))

    def _room_unban(self):
        room = self._current_room()
        srv = self._owned_server(room)
        if not srv:
            QMessageBox.information(self, i18n.tr("tip"), i18n.tr("lan_mgr_hint"))
            return
        name, ok = QInputDialog.getText(
            self, "解除禁言", "要解封的玩家账号名（就是游戏里的名字）：")
        if not ok or not (name or "").strip():
            return
        try:
            out = srv.command("pardon %s" % name.strip())
            if out:
                self._log(out)
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))

    def _room_pass_hash(self, text):
        """房间密码只广播一个短哈希，别把明文发到局域网上。"""
        if not text:
            return ""
        return hashlib.sha1(("omc:" + text).encode("utf-8")).hexdigest()[:12]

    def _join_room(self):
        code = self.input_room_code.text().strip()
        if not code:
            return
        try:
            ip, port = lan.parse_code(code)
        except Exception:
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("tip"))
            return
        self._join_endpoint(ip, port)

    def _join_endpoint(self, ip, port):
        """直接连进某个房间：选中版本后带 --server/--port 启动。"""
        meta = self._room_meta_map.get((ip, int(port))) or {}
        mode = str(meta.get("mode") or "public")
        if mode == "friends":
            host_name = str(meta.get("host") or "").strip()
            if host_name and not friendbook.has(name=host_name):
                QMessageBox.warning(
                    self, "这个房间只对房主的好友开放",
                    "房主是 %s。\n先在好友页按账号名加他，再回来连这个房间。"
                    % host_name)
                return
        elif meta.get("locked"):
            want = str(meta.get("pass") or "")
            pw, ok = QInputDialog.getText(self, "这个房间有密码", "输入房间密码：")
            if not ok:
                return
            if self._room_pass_hash((pw or "").strip()) != want:
                QMessageBox.warning(self, "密码不对",
                                    "房间密码对不上，问一下房主要密码。")
                return
        vid = self._selected_version_id()
        if not vid:
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("lan_no_room"))
            return
        jpath = self._version_json_path(vid)
        required = launcher.required_java_major(jpath)
        java = (self.config.get("java_path") or "").strip()
        if not java or not os.path.exists(java):
            java = java_utils.pick_for(required)
        if not java:
            QMessageBox.warning(self, i18n.tr("tip"),
                                i18n.tr("lan_open_failed", "Java"))
            return
        account = self._resolve_account()
        if not account:
            return
        extra = self._direct_join_arg(vid, ip, port)
        if not extra:
            QMessageBox.warning(self, "地址用不了",
                                "服务器地址里有不认识的字符，先在联机页把地址改成 "
                                "host:端口 这种写法。")
            return
        self._remember_room(ip, int(port), meta, vid)
        self._do_launch(vid, java, account, extra_game=extra)

    def _direct_join_arg(self, vid, ip, port):
        """点「加入」时拼的直连参数，规则在 launcher.join_arg 里（那处能单测）。"""
        return launcher.join_arg(ip, port, vid)

    def _remember_room(self, ip, port, meta, vid):
        """记下连过的房间，下次不用再翻房间码。"""
        try:
            hist = self.config.get("room_history") or []
            if not isinstance(hist, list):
                hist = []
            rec = {"ip": ip, "port": int(port), "at": int(time.time()),
                   "name": str((meta or {}).get("name") or "%s:%d" % (ip, port)),
                   "version": vid or "", "host": str((meta or {}).get("host") or ""),
                   "code": lan.make_code(ip, port)}
            hist = [h for h in hist if not (h.get("ip") == ip
                                            and h.get("port") == int(port))]
            hist.insert(0, rec)
            self.config.set("room_history", hist[:10])
            self.config.save()
        except Exception as e:
            self._log("记录房间历史失败：%s" % e)
            return
        try:
            self._reload_room_history()
        except Exception:
            pass

    def _reload_room_history(self):
        lst = getattr(self, "history_rooms", None)
        if lst is None:
            return
        lst.clear()
        hist = self.config.get("room_history") or []
        if not isinstance(hist, list):
            hist = []
        for h in hist[:10]:
            txt = "%s　%s　%s" % (h.get("name") or "-",
                                  h.get("version") or "-",
                                  time.strftime("%m-%d %H:%M",
                                                time.localtime(h.get("at") or 0)))
            it = QListWidgetItem(txt)
            it.setData(Qt.UserRole, h.get("code") or "")
            it.setToolTip("房间码：%s（双击直接连）" % (h.get("code") or ""))
            lst.addItem(it)

    def _join_from_history(self, item):
        code = (item.data(Qt.UserRole) or "").strip() if item else ""
        if not code:
            return
        try:
            ip, port = lan.parse_code(code)
        except Exception:
            QMessageBox.warning(self, "房间码已损坏", "这个历史记录用不了了，删掉再手动连一次。")
            return
        self._join_endpoint(ip, port)

    def _clear_room_history(self):
        self.config.set("room_history", [])
        try:
            self.config.save()
        except Exception:
            pass
        self._reload_room_history()

    def _open_version_detail(self, vid):
        self._detail_vid = vid
        loader_kind = self._detect_loader_kind(vid)
        loader_text = loaders.LABELS[loader_kind] if loader_kind else i18n.tr("vanilla")
        self.detail_title.setText("%s（%s）" % (vid, loader_text))

        gd = self.config.get("game_dir") or ""
        self.detail_mods.clear()
        for name in mods.list_mods(gd):
            info = mods.mod_info(os.path.join(gd, "mods", name))
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, 66))
            self.detail_mods.addItem(item)
            self.detail_mods.setItemWidget(
                item, self._local_row(info.get("icon"),
                                      info.get("name") or name,
                                      info.get("description"),
                                      name[:2].upper()))

        self._refresh_worlds()
        self._sync_fav_button(vid)
        self.stack.setCurrentIndex(3)

    def _detail_open_version(self):
        p = os.path.join(self.config.get("game_dir") or "",
                         "versions", self._detail_vid)
        if os.path.isdir(p):
            platform_utils.open_path(p)

    def _detail_goto_download(self):
        vid = self._detail_vid
        mc = self._loader_base_mc(vid)
        loader_kind = self._detect_loader_kind(vid)
        self.stack.setCurrentIndex(2)
        # 定位到下载模组标签页（mods_tabs 第 1 个索引）
        self.mods_tabs.setCurrentIndex(1)
        self.combo_browse_mc.setEditText(mc)
        if loader_kind:
            i = self.combo_browse_loader.findData(loader_kind)
            if i >= 0:
                self.combo_browse_loader.setCurrentIndex(i)
        else:
            self.combo_browse_loader.setCurrentIndex(0)
        self._browse_offset("mod", 0)
        self._browse_search("mod")

    # ---------- 加载器（启动页卡片） ----------
    # 徽章配色与文字：原版 + 四种加载器
    BADGES = {
        None: ("#7A8699", "原"),
        "fabric": ("#D9834F", "Fa"),
        "quilt": ("#9C7CD9", "Qu"),
        "forge": ("#3F6FE0", "Fo"),
        "neoforge": ("#E8593C", "Ne"),
    }

    def _badge_icon(self, kind):
        """用 QPainter 画圆角徽章，不依赖外部图片资源。"""
        color, text = self.BADGES[kind]
        pix = QPixmap(34, 34)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(color))
        p.drawRoundedRect(2, 2, 30, 30, 8, 8)
        p.setPen(QColor("white"))
        f = p.font()
        f.setBold(True)
        f.setPointSize(9)
        p.setFont(f)
        p.drawText(QRect(2, 2, 30, 30), Qt.AlignCenter, text)
        p.end()
        return QIcon(pix)

    def _build_latest_card(self):
        lay = QVBoxLayout()
        lay.setContentsMargins(22, 16, 22, 16)
        lay.setSpacing(10)
        lay.addWidget(self._field_label("官方最新版本（联网自动刷新）"))

        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(16)

        self.latest_cover = QLabel("封面加载中...")
        self.latest_cover.setFixedSize(360, 180)
        self.latest_cover.setAlignment(Qt.AlignCenter)
        self.latest_cover.setStyleSheet(
            "border-radius:12px;background:rgba(255,255,255,16);"
            "color:rgba(255,255,255,140);")
        h.addWidget(self.latest_cover)

        right = QVBoxLayout()
        right.setSpacing(6)
        self.latest_ver = QLabel("正在获取...")
        self.latest_ver.setStyleSheet("font-size:26px;font-weight:600;")
        self.latest_sub = QLabel("")
        self.latest_sub.setObjectName("FieldLabel")
        self.btn_latest = QPushButton("装这个版本")
        self.btn_latest.setObjectName("PrimaryButton")
        self.btn_latest.clicked.connect(self._install_latest)
        right.addWidget(self.latest_ver)
        right.addWidget(self.latest_sub)
        right.addStretch(1)
        right.addWidget(self.btn_latest)
        h.addLayout(right, 1)

        lay.addWidget(row)
        self._latest_info = {}
        # 先把本地已经下过的封面铺上，别让用户盯着「封面加载中」
        try:
            self._show_latest_cover(latest.cached_cover())
        except Exception:
            pass
        QTimer.singleShot(0, self._load_latest_info)
        return card(lay)

    def _show_latest_cover(self, path):
        if not path:
            return False
        pix = QPixmap(path)
        if pix.isNull():
            return False
        w, h = self.latest_cover.width(), self.latest_cover.height()
        if w <= 0 or h <= 0:
            return False
        scaled = pix.scaled(w, h, Qt.KeepAspectRatioByExpanding,
                            Qt.SmoothTransformation)
        x = max(0, (scaled.width() - w) // 2)
        y = max(0, (scaled.height() - h) // 2)
        self.latest_cover.setText("")
        self.latest_cover.setPixmap(scaled.copy(x, y, w, h))
        return True

    def _load_latest_info(self):
        self._lvw = self._track(LatestVersionWorker())
        self._lvw.done.connect(self._on_latest_info)
        self._lvw.failed.connect(
            lambda e: self.latest_sub.setText("最新版本获取失败：" + str(e)))
        self._lvw.start()

    def _on_latest_info(self, info):
        self._latest_info = info or {}
        ver = str(self._latest_info.get("release") or "-")
        snap = str(self._latest_info.get("snapshot") or "")
        self.latest_ver.setText(ver)
        tip = "官方最新正式版"
        if snap:
            tip += " | 最新快照 " + snap
        self.latest_sub.setText(tip)
        cover = self._latest_info.get("cover") or ""
        shown = self._show_latest_cover(cover) if cover else False
        if not shown:
            # 没拿到这个版本的图时，别把已经显示出来的旧图抹掉
            self._show_latest_cover(latest.cached_cover(ver))
            if not self.latest_cover.pixmap() or self.latest_cover.pixmap().isNull():
                self.latest_cover.setText("封面暂时拉不到，网络恢复后会自动补上")
        self._update_latest_btn()
        self._log("官方最新版本：%s" % ver)

    def _update_latest_btn(self):
        ver = str((self._latest_info or {}).get("release") or "")
        if not ver or not self.config.get("game_dir"):
            return
        try:
            installed = self._is_installed(ver)
        except Exception:
            installed = False
        self.btn_latest.setText(
            ("用 %s 启动" % ver) if installed else ("下载安装 %s" % ver))

    def _install_latest(self):
        ver = str((self._latest_info or {}).get("release") or "")
        if not ver:
            self.latest_sub.setText("还在获取最新版本，稍后再点")
            return
        idx = self.group_combo.findData("release")
        if idx >= 0 and self.group_combo.currentIndex() != idx:
            self.group_combo.setCurrentIndex(idx)
        self._refresh_version_list()
        target = -1
        for i in range(self.local_list.count()):
            it = self.local_list.item(i)
            if (it.data(Qt.UserRole) or it.text()) == ver:
                target = i
                break
        if target < 0:
            self.latest_sub.setText("版本列表还没加载好，稍后再点一次")
            self._load_versions()
            return
        self.local_list.setCurrentRow(target)
        self._on_primary()

    def _build_loader_card(self):
        lform = QVBoxLayout()
        lform.setContentsMargins(22, 18, 22, 18)
        lform.setSpacing(10)
        lform.addWidget(self._field_label(i18n.tr("label_loader")))

        self.combo_loader_kind = QComboBox()
        self.combo_loader_kind.addItem(i18n.tr("no_loader"), None)
        for kind in ("fabric", "quilt", "forge", "neoforge"):
            self.combo_loader_kind.addItem(loaders.LABELS[kind], kind)
        self.combo_loader_ver = QComboBox()
        self.combo_loader_kind.currentIndexChanged.connect(
            self._reload_loader_versions)
        self.combo_loader_kind.currentIndexChanged.connect(
            self._sync_fabric_api_cb)
        lform.addWidget(self._row(self.combo_loader_kind,
                                  self.combo_loader_ver))

        # 选了 Fabric 就多给一个勾：顺手把 Fabric API 一起装上。
        # 这个 API 是绝大多数 Fabric 模组的前置，少了它模组一律不加载，
        # 以前是装完加载器静默去下，用户既不知道有没有装上、也不知道能关。
        self.cb_fabric_api = QCheckBox("一并装 Fabric API（多数 Fabric 模组的前置）")
        _fapi = self.config.get("fabric_api_auto")
        self.cb_fabric_api.setChecked(True if _fapi is None else bool(_fapi))
        self.cb_fabric_api.setToolTip(
            "跟 Fabric 加载器装在同一个实例的 mods 目录里；"
            "取消勾选就只装加载器，之后也能在「模组」页单独装。")
        self.cb_fabric_api.toggled.connect(self._on_fabric_api_toggled)
        lform.addWidget(self.cb_fabric_api)

        self.loader_state = QLabel("")
        self.loader_state.setObjectName("FieldLabel")
        lform.addWidget(self.loader_state)

        # 装加载器时的进度条 + 速度。以前只有一行「正在安装加载器…」，
        # 库文件要下几十个，用户根本不知道是在下还是卡死了。
        self.loader_bar = QProgressBar()
        self.loader_bar.setRange(0, 100)
        self.loader_bar.setValue(0)
        self.loader_bar.setTextVisible(False)
        self.loader_bar.setFixedHeight(10)
        self.loader_bar.setVisible(False)
        lform.addWidget(self.loader_bar)
        self.loader_speed = QLabel("")
        self.loader_speed.setObjectName("FieldLabel")
        self.loader_speed.setVisible(False)
        lform.addWidget(self.loader_speed)

        # 版本切换时重新拉取该版本可用的加载器
        self.local_list.itemSelectionChanged.connect(
            self._reload_loader_versions)
        # 版本一切换，Java 也跟着换到该版本要的那一版（全自动）
        self.local_list.itemSelectionChanged.connect(
            self._java_follow_version)
        self._sync_fabric_api_cb()      # 初始是「不用加载器」，这个勾要先藏起来
        return card(lform)

    def _sync_fabric_api_cb(self, *_args):
        """只有真的选了 Fabric 才显示这个勾。"""
        if not hasattr(self, "cb_fabric_api"):
            return
        on = (self.combo_loader_kind.currentData() == "fabric")
        self.cb_fabric_api.setVisible(on)
        try:
            self.cb_fabric_api.setEnabled(
                on and self.combo_loader_kind.isEnabled())
        except Exception:
            pass

    def _on_fabric_api_toggled(self, on):
        try:
            self.config.set("fabric_api_auto", bool(on))
            self.config.save()
        except Exception:
            pass

    def _detect_loader_kind(self, vid):
        """根据版本 json 与目录名判断本地版本属于哪种加载器，原版返回 None。"""
        jpath = self._version_json_path(vid)
        if not os.path.exists(jpath):
            return None
        try:
            with open(jpath, "r", encoding="utf-8") as f:
                vj = json.load(f)
        except Exception:
            return None
        if not vj.get("inheritsFrom"):
            return None
        low = vid.lower()
        # neoforge 名字里含 forge，必须先判
        for kind in ("neoforge", "fabric", "quilt", "forge"):
            if kind in low:
                return kind
        return None

    def _sync_loader_lock(self):
        """只有「已经是带加载器的版本」或「正在安装」才锁；
        纯原版（哪怕已经下载过）也允许选加载器，用来基于它建一个新实例。"""
        if not hasattr(self, "combo_loader_kind"):
            return
        vid = self._selected_version_id()
        # InstallWorker 是 Qt 对象，跑完后可能已经被 Qt 回收。这时 Python 那边
        # 还留着引用，直接调 isRunning() 会抛「Internal C++ object already
        # deleted」，于是每次刷新版本列表都往 crash.log 里写一段异常。
        busy = False
        w = getattr(self, "install_worker", None)
        if w is not None:
            try:
                busy = bool(w.isRunning())
            except RuntimeError:
                self.install_worker = None
        has_loader = bool(vid) and bool(self._detect_loader_kind(vid))
        locked = busy or has_loader
        kind = self.combo_loader_kind.currentData()
        self.combo_loader_kind.setEnabled(not locked)
        self.combo_loader_ver.setEnabled(not locked and kind is not None)
        self.input_instance_name.setEnabled(not locked)
        self._sync_fabric_api_cb()      # 锁定时那个勾也要跟着不能点
        if locked and not busy:
            loader_kind = self._detect_loader_kind(vid)
            if loader_kind:
                text = i18n.tr("locked_loader", loaders.LABELS[loader_kind])
            else:
                text = i18n.tr("locked_vanilla")
            self.loader_state.setText(text)
        elif not busy:
            self.loader_state.setText(
                "这个版本还没装加载器：可以选 Fabric / Forge / NeoForge，"
                "装成一个独立实例，原版本身不会被改动。")

    # ---------- 版本命名 ----------
    BAD_NAME_CHARS = set('\\/:*?"<>|')

    def _default_instance_name(self):
        vid = self._selected_version_id()
        if not vid:
            return ""
        kind = self.combo_loader_kind.currentData()
        return "%s-%s" % (vid, loaders.LABELS[kind]) if kind else vid

    def _refresh_default_name(self, *_args):
        if not hasattr(self, "input_instance_name"):
            return
        # 已安装版本名字锁定，不覆盖
        vid = self._selected_version_id()
        if vid and self._is_installed(vid):
            self.input_instance_name.setText(vid)
        else:
            self.input_instance_name.setText(self._default_instance_name())

    def _validate_instance_name(self, name):
        name = (name or "").strip()
        if not name:
            return None, i18n.tr("empty_name")
        if any(ch in name for ch in self.BAD_NAME_CHARS):
            return None, i18n.tr("bad_chars")
        if name in (".", ".."):
            return None, i18n.tr("invalid_name")
        target = os.path.join(self.config.get("game_dir"), "versions", name)
        if os.path.exists(target):
            return None, i18n.tr("name_exists", name)
        return name, ""

    def _rename_installed_version(self, src_id, dst_name):
        """把安装好的版本目录改名为用户指定名称，并同步 json 文件名与 id 字段。"""
        vroot = os.path.join(self.config.get("game_dir"), "versions")
        src = os.path.join(vroot, src_id)
        if src_id == dst_name:
            return src_id
        dst = os.path.join(vroot, dst_name)
        if os.path.exists(dst):
            raise RuntimeError(i18n.tr("name_exists", dst_name))

        src_json = os.path.join(src, src_id + ".json")
        with open(src_json, "r", encoding="utf-8") as f:
            vj = json.load(f)
        vj["id"] = dst_name
        dst_json = os.path.join(src, dst_name + ".json")
        with open(dst_json, "w", encoding="utf-8") as f:
            json.dump(vj, f, ensure_ascii=False, indent=2)
        if os.path.abspath(dst_json) != os.path.abspath(src_json):
            os.remove(src_json)
        os.rename(src, dst)
        self._log(i18n.tr("named") + dst_name)
        return dst_name

    # ---------- 皮肤库 ----------
    def _refresh_skin_combo(self):
        if not hasattr(self, "combo_skin"):
            return
        self.combo_skin.clear()
        names = skins.list_skins()
        if not names:
            self.combo_skin.addItem(i18n.tr("empty_skin"), "")
            self._update_skin_preview()
            return
        for name in names:
            pix = self._skin_front_pix(skins.skin_path(name), scale=2)
            self.combo_skin.addItem(QIcon(pix), name, name)
        self._update_skin_preview()

    def _update_skin_preview(self, *_args):
        if not hasattr(self, "skin_preview") or not hasattr(self, "combo_skin"):
            return
        name = self.combo_skin.currentData() if self.combo_skin.count() else ""
        if not name:
            self.skin_preview.setPixmap(
                self._placeholder_pix("?", 64).scaled(
                    24, 48, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            return
        pix = self._skin_front_pix(skins.skin_path(name), scale=3)
        self.skin_preview.setPixmap(pix)

    def _skin_front_pix(self, path, scale=4):
        """按皮肤贴图 UV 拼出正面角色（头/帽层/身/双臂/双腿），与游戏内一致。"""
        img = QImage(path)
        if img.isNull():
            return self._placeholder_pix("?", 64)
        src = img.convertToFormat(QImage.Format_ARGB32)
        wide = src.width() >= 64

        # 细手臂（slim）判定：正常皮肤右臂正面占 44..47，46、47 列都透明才是 slim
        slim = False
        if wide:
            slim = all(src.pixelColor(x, y).alpha() == 0
                       for x in (46, 47) for y in range(20, 32))

        head = (8, 8, 8, 8)
        hat = (40, 8, 8, 8)
        body = (20, 20, 8, 12)
        aw = 3 if slim else 4
        rarm = (44, 20, aw, 12)
        larm = (36, 52, aw, 12) if wide else rarm
        rleg = (4, 20, 4, 12)
        lleg = (20, 52, 4, 12) if wide else rleg

        # 与游戏内正面一致：手臂紧贴身体，部件之间没有任何缝隙
        # slim 皮肤整体窄 2px（14 宽），正常皮肤 16 宽
        W, H = 8 + 2 * aw, 32
        bx = aw
        canvas = QImage(W, H, QImage.Format_ARGB32)
        canvas.fill(Qt.transparent)
        p = QPainter(canvas)
        p.setRenderHint(QPainter.SmoothPixmapTransform, False)

        def blit(rect, dx, dy):
            x, y, rw, rh = rect
            p.drawImage(QRect(dx, dy, rw, rh), src, QRect(x, y, rw, rh))

        blit(rleg, bx, 20)
        blit(lleg, bx + 4, 20)
        blit(rarm, 0, 8)
        blit(larm, W - aw, 8)
        blit(body, bx, 8)
        blit(head, bx, 0)
        blit(hat, bx, 0)
        p.end()

        s = max(1, int(scale))
        return QPixmap.fromImage(canvas).scaled(
            W * s, H * s, Qt.KeepAspectRatio, Qt.FastTransformation)

    def _on_skins_dropped(self, paths):
        pngs = [p for p in paths
                if str(p).lower().endswith((".png", ".jpg", ".jpeg"))]
        if not pngs:
            self._log("拖进来的不是皮肤图片（需要 .png）")
            return
        last = None
        for p in pngs:
            try:
                last = skins.import_skin(p)
                self._log(i18n.tr("skin_in_lib") + last)
            except Exception as e:
                self._log("皮肤导入失败：" + str(e))
        self._refresh_skin_combo()
        if hasattr(self, "combo_skin") and last:
            idx = self.combo_skin.findData(os.path.basename(last))
            if idx >= 0:
                self.combo_skin.setCurrentIndex(idx)

    def _import_skin(self):
        p, _ = QFileDialog.getOpenFileName(
            self, i18n.tr("choose_skin_png"), "", i18n.tr("skin_images"))
        if not p:
            return
        try:
            dest = skins.import_skin(p)
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("import_failed"), str(e))
            return
        self._refresh_skin_combo()
        idx = -1
        if hasattr(self, "combo_skin"):
            idx = self.combo_skin.findData(os.path.basename(dest))
        if idx >= 0:
            self.combo_skin.setCurrentIndex(idx)
        self._log(i18n.tr("skin_in_lib") + dest)

    def _open_skins_dir(self):
        platform_utils.open_path(skins.skins_dir())

    def _loader_base_mc(self, vid=None):
        """版本若本身是加载器版本，则取其父版本（inheritsFrom）。"""
        vid = vid or self._selected_version_id()
        jpath = self._version_json_path(vid)
        if os.path.exists(jpath):
            try:
                with open(jpath, "r", encoding="utf-8") as f:
                    vj = json.load(f)
                if vj.get("inheritsFrom"):
                    return vj["inheritsFrom"]
            except Exception:
                pass
        return vid

    def _reload_loader_versions(self, *_args):
        if not hasattr(self, "combo_loader_ver"):
            return
        kind = self.combo_loader_kind.currentData()
        mc = self._loader_base_mc()
        self.combo_loader_ver.clear()
        if kind is None:
            self.combo_loader_ver.setEnabled(False)
            if not self._is_installed(self._selected_version_id()):
                self.loader_state.setText(i18n.tr("no_loader_hint"))
            else:
                self._sync_loader_lock()
            return
        if not mc:
            self.loader_state.setText(i18n.tr("pick_version_first"))
            return
        self.combo_loader_ver.setEnabled(True)
        self.loader_state.setText(
            i18n.tr("fetching_versions", loaders.LABELS[kind]))
        self.lvw = self._track(
            LoaderVersionsWorker(kind, mc, self._current_mirror()))
        self.lvw.done.connect(self._on_loader_versions)
        self.lvw.failed.connect(
            lambda e: self.loader_state.setText(i18n.tr("fetch_failed", e)))
        self.lvw.start()

    def _on_loader_versions(self, versions, recommended):
        self.combo_loader_ver.clear()
        # 新的版本放最前面
        for ver in reversed(versions):
            self.combo_loader_ver.addItem(ver)
        if not versions:
            self.loader_state.setText(i18n.tr("no_loader_versions"))
            return
        pick = recommended[0] if recommended else versions[-1]
        idx = self.combo_loader_ver.findText(pick)
        if idx >= 0:
            self.combo_loader_ver.setCurrentIndex(idx)
        self.loader_state.setText(i18n.tr("loader_versions_count", len(versions)))

    # ---------- 下载后链式安装加载器 ----------
    def _pick_loader_java(self, kind, mc):
        game_dir = self.config.get("game_dir")
        java = java_utils.pick_for(17) or (self.config.get("java_path") or "")
        if kind in ("forge", "neoforge"):
            jpath = os.path.join(game_dir, "versions", mc, mc + ".json")
            need = launcher.required_java_major(jpath) \
                if os.path.exists(jpath) else 17
            java = java_utils.pick_for(need) or java
        return java

    def _start_chained_loader(self, kind, mc, ver):
        java = self._pick_loader_java(kind, mc)
        self._pending_mc = mc          # 装完 Fabric API 要按这个 MC 版本挑文件
        self.btn_primary.setEnabled(False)
        self.btn_primary.setText(i18n.tr("installing_loader"))
        self.loader_state.setText(
            i18n.tr("installing_loader_n", loaders.LABELS[kind], ver))
        self._log(i18n.tr("installing_loader_n",
                          loaders.LABELS[kind], ver)
                  + " (MC %s)" % mc)
        self.liw = self._track(LoaderInstallWorker(
            kind, mc, ver, self.config.get("game_dir"), java,
            self._current_mirror()))
        self.liw.log.connect(self._log)
        self.liw.log.connect(self.loader_state.setText)
        self.liw.progress.connect(self._on_loader_progress)
        self.liw.done.connect(self._on_chained_loader_done)
        self.liw.failed.connect(self._on_chained_loader_failed)
        self._show_loader_bar(True)
        self.liw.start()

    # ---------- 加载器安装进度 ----------
    def _show_loader_bar(self, on):
        for w in ("loader_bar", "loader_speed"):
            try:
                getattr(self, w).setVisible(bool(on))
            except Exception:
                pass
        if on:
            try:
                self.loader_bar.setRange(0, 0)     # 先转圈，等真实百分比
                self.loader_speed.setText("正在准备下载…")
            except Exception:
                pass

    def _on_loader_progress(self, done, total, speed):
        """done/total 是字节；total 为 0 表示这段没有可统计的总量。"""
        try:
            bar = self.loader_bar
            if total and total > 0:
                if bar.maximum() != 100:
                    bar.setRange(0, 100)
                pct = int(min(100.0, done * 100.0 / total))
                bar.setValue(pct)
                txt = "%d%%   %s / %s" % (pct, loaders._fmt_size(done),
                                          loaders._fmt_size(total))
            else:
                if bar.maximum() != 0:
                    bar.setRange(0, 0)             # 不确定：来回滚的忙碌条
                txt = "安装器正在下载并生成版本…"
            sp = loaders.format_speed(speed)
            if total and total > 0:
                self.loader_speed.setText(txt + ("   ·   " + sp if sp else ""))
            else:
                base_txt = ("已下载 " + loaders._fmt_size(done)) if done else "正在下载…"
                self.loader_speed.setText(
                    base_txt + ("   ·   " + sp if sp else ""))
        except Exception:
            pass

    def _on_chained_loader_done(self, vid):
        kind = getattr(self, "_pending_kind", None)
        self.btn_primary.setEnabled(True)
        self._show_loader_bar(False)
        self._log(i18n.tr("loader_done", vid))
        self._ensure_shortcut()
        self._ensure_java_path(17)
        self._pending_kind = None
        self._pending_ver = None
        # 按用户起的名字改名（默认名与默认逻辑一致时为 no-op）
        try:
            vid = self._rename_installed_version(
                vid, getattr(self, "_pending_name", "") or vid)
        except Exception as e:
            self._log(str(e))
        self._pending_name = None
        self.loader_state.setText(i18n.tr("loader_done", vid))
        self._refresh_version_list()
        self._select_version(vid)
        # Fabric 装完，按用户的勾选决定要不要顺手把 Fabric API 塞进 mods
        if kind == "fabric":
            want = True
            try:
                want = bool(self.cb_fabric_api.isChecked())
            except Exception:
                want = True
            if want:
                self._install_fabric_api(mc_version=getattr(self, "_pending_mc", None),
                                        vid=vid)
            else:
                self._log("按你的设置跳过了 Fabric API（之后要装，可在「模组」页单独装）")
        account = self._resolve_account()
        if account:
            self._start_game(vid, account)

    def _has_fabric_api(self, mods_dir):
        """mods 里是否已经躺着一个 Fabric API。"""
        try:
            for name in os.listdir(mods_dir):
                low = name.lower()
                if low.endswith(".jar") and low.startswith("fabric-api"):
                    return name
                if low.endswith(".jar") and "fabric-api" in low:
                    return name
        except Exception:
            pass
        return ""

    def _install_fabric_api(self, mc_version=None, vid=None):
        """异步装 Fabric API；失败只记日志，不挡游戏启动。"""
        try:
            gd = self.config.get("game_dir") or ""
            mods_dir = os.path.join(gd, "mods")
            mc = mc_version
            if not mc:
                src = vid or self._selected_version_id() or ""
                mc = None
                jpath = self._version_json_path(src)
                if os.path.isfile(jpath):
                    try:
                        with open(jpath, encoding="utf-8") as f:
                            mc = json.load(f).get("inheritsFrom") or src
                    except Exception:
                        mc = src
            if not mc:
                self._log("找不到对应的 MC 版本，跳过 Fabric API")
                return False
            have = self._has_fabric_api(mods_dir)
            if have:
                self._log("mods 里已经有 Fabric API（%s），不重复装" % have)
                return True
            self._log("正在装 Fabric API（MC %s）......" % mc)
            try:
                os.makedirs(mods_dir, exist_ok=True)
            except Exception:
                pass
            w = self._track(ModrinthDownloadWorker(
                "fabric-api", mc, "fabric", mods_dir))
            w.log.connect(self._log)
            w.done.connect(lambda p: (
                self._log("Fabric API 已装上：" + os.path.basename(str(p))),
                self._set_loader_state_tip(
                    "Fabric API 已一并装好：%s" % os.path.basename(str(p)))))
            w.failed.connect(lambda e: (
                self._log("Fabric API 没装上（不影响游戏本体）：" + str(e)),
                self._set_loader_state_tip(
                    "Fabric API 没装上（游戏本体不受影响，可稍后在「模组」页补装）")))
            w.start()
            return True
        except Exception as e:
            self._log("Fabric API 安装异常：" + str(e))
            return False

    def _set_loader_state_tip(self, text):
        try:
            if hasattr(self, "loader_state"):
                self.loader_state.setText(text)
        except Exception:
            pass

    def _on_chained_loader_failed(self, err):
        self.btn_primary.setEnabled(True)
        self._show_loader_bar(False)
        self.loader_state.setText(i18n.tr("loader_failed", err))
        self._log(i18n.tr("loader_failed", err))
        self._pending_kind = None
        self._pending_ver = None
        self._pending_name = None
        self._update_install_state()
        QMessageBox.warning(
            self, i18n.tr("installing_loader"),
            "%s\n\n%s" % (err, i18n.tr("loader_failed_body")))

    def _select_version(self, vid):
        items = self.local_list.findItems(vid, Qt.MatchExactly)
        if not items:
            # 显示名可能带「★ 」前缀，按 UserRole 再找一遍
            for i in range(self.local_list.count()):
                it = self.local_list.item(i)
                if (it.data(Qt.UserRole) or it.text()) == vid:
                    items = [it]
                    break
        if items:
            self.local_list.setCurrentItem(items[0])

    def _toggle_fav_version(self, vid=""):
        """收藏 / 取消收藏一个版本：收藏的会排在版本列表最前面。"""
        vid = (vid or self._selected_version_id() or "").strip()
        if not vid:
            return False
        try:
            on = favorites.toggle("version", vid, {"name": vid})
        except Exception as e:
            self._log("收藏失败：%s" % e)
            return False
        self._log(("已收藏版本：" if on else "已取消收藏：") + vid)
        try:
            self._refresh_version_list()
        except Exception:
            pass
        return on

    def _toggle_fav_detail(self):
        vid = getattr(self, "_detail_vid", "") or self._selected_version_id() or ""
        if not vid:
            return
        self._toggle_fav_version(vid)
        self._sync_fav_button(vid)

    def _sync_fav_button(self, vid=""):
        vid = vid or getattr(self, "_detail_vid", "") or self._selected_version_id() or ""
        btn = getattr(self, "b_fav", None)
        if btn is None:
            return
        try:
            on = favorites.has("version", vid) if vid else False
        except Exception:
            on = False
        btn.setText("取消收藏" if on else "收藏此版本")

    # ---------- 已装模组 ----------
    def _tab_installed(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)

        self.drop_zone = DropZone(i18n.tr("drop_text"))
        self.drop_zone.filesDropped.connect(self._on_mods_dropped)
        v.addWidget(self.drop_zone)

        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(10)
        b_pick = QPushButton(i18n.tr("choose_file"))
        b_pick.clicked.connect(self._pick_mods)
        b_open = QPushButton(i18n.tr("open_mods_folder"))
        b_open.clicked.connect(self._open_mods_dir)
        b_refresh = QPushButton(i18n.tr("btn_refresh"))
        b_refresh.clicked.connect(self._refresh_mods_list)
        b_delete = QPushButton(i18n.tr("btn_delete_mod"))
        b_delete.clicked.connect(self._delete_selected_mod)
        b_versions = QPushButton("版本与加载器")
        b_versions.setToolTip("列出所有已装版本，并标注每个版本用的是哪种模组加载器")
        b_versions.clicked.connect(self._open_loader_summary)
        h.addWidget(b_pick)
        h.addWidget(b_open)
        h.addWidget(b_refresh)
        h.addWidget(b_delete)
        h.addWidget(b_versions)
        b_on = QPushButton("全部启用")
        b_on.setToolTip("把 mods 里所有 .disabled 的模组重新装上")
        b_on.clicked.connect(lambda: self._mods_toggle_all(True))
        h.addWidget(b_on)
        b_off = QPushButton("全部停用")
        b_off.setToolTip("把所有模组改成 .disabled，游戏不会加载，文件不删")
        b_off.clicked.connect(lambda: self._mods_toggle_all(False))
        h.addWidget(b_off)
        b_one = QPushButton("启用/停用选中")
        b_one.clicked.connect(self._toggle_selected_mod)
        h.addWidget(b_one)
        b_conf = QPushButton("冲突检测")
        b_conf.setToolTip("查同一个模组 ID 装了多份、以及缺前置依赖的情况")
        b_conf.clicked.connect(self._detect_mod_conflicts)
        h.addWidget(b_conf)
        b_dlq = QPushButton("下载队列")
        b_dlq.setToolTip("同时下两个文件，每个都有自己的进度条")
        b_dlq.clicked.connect(self._open_download_queue)
        h.addWidget(b_dlq)
        # 按钮一多，窄窗口会被挤掉看不见：整个工具行放横向滚动区里
        row.setMinimumWidth(h.sizeHint().width())
        row_holder = QScrollArea()
        row_holder.setWidgetResizable(True)
        row_holder.setFrameShape(QFrame.NoFrame)
        row_holder.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        row_holder.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        row_holder.setStyleSheet("QScrollArea { background: transparent; }")
        row_holder.setWidget(row)
        row_holder.setFixedHeight(row.sizeHint().height() + 22)
        v.addWidget(row_holder)

        row2 = QHBoxLayout()
        lab_t = QLabel("标签筛选")
        row2.addWidget(lab_t)
        self.mod_tag_filter = QComboBox()
        self.mod_tag_filter.setFixedWidth(150)
        self.mod_tag_filter.addItem("全部")
        self.mod_tag_filter.currentIndexChanged.connect(
            lambda _i: self._refresh_mods_list())
        row2.addWidget(self.mod_tag_filter)
        b_tag = QPushButton("给选中模组打标签")
        b_tag.setToolTip("标签和备注只存在本机，不写进模组文件")
        b_tag.clicked.connect(self._tag_selected_mod)
        row2.addWidget(b_tag)
        b_block = QPushButton("模组黑名单")
        b_block.setToolTip("黑名单里的模组在导入、拖入时直接拦下来")
        b_block.clicked.connect(self._open_mod_blacklist)
        row2.addWidget(b_block)
        row2.addStretch(1)
        v.addLayout(row2)

        self.mods_list = QListWidget()
        self._attach_ctx_menu(self.mods_list, "mod")
        self.mods_list.setMinimumHeight(150)
        v.addWidget(self.mods_list, 1)

        self.mods_state = QLabel("")
        self.mods_state.setObjectName("FieldLabel")
        v.addWidget(self.mods_state)
        self._refresh_mods_list()
        return w

    def _pick_mods(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, i18n.tr("choose_file"), "",
            "*.jar *.mrpack *.zip")
        if files:
            self._on_mods_dropped(files)

    def _on_mods_dropped(self, paths):
        paths = [p for p in paths if os.path.isfile(p)]
        if not paths:
            return
        paths, bad = modblock.filter_paths(paths)
        if bad:
            lines = ["%s（命中规则 %s）" % (os.path.basename(p), r) for p, r in bad]
            QMessageBox.warning(
                self, "模组黑名单",
                "下面这些在黑名单里，已经拦下不装：\n\n" + "\n".join(lines))
            self._log("黑名单拦下 %d 个文件" % len(bad))
        if not paths:
            return
        game_dir = self.config.get("game_dir")
        if not game_dir:
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("need_game_dir"))
            return
        self.mods_state.setText(i18n.tr("installing_n", len(paths)))
        self._log(i18n.tr("installing_n", len(paths)))
        self.mods_worker = self._track(ModsWorker(paths, game_dir, self._current_mirror()))
        self.mods_worker.log.connect(self._log)
        self.mods_worker.log.connect(self.mods_state.setText)
        self.mods_worker.done.connect(self._on_mods_done)
        self.mods_worker.failed.connect(self._on_mods_failed)
        self.mods_worker.start()

    def _on_mods_done(self, results):
        packs = [r for r in results
                 if r.get("kind") in ("mrpack", "curseforge", "zip")]
        self.mods_state.setText(
            i18n.tr("mods_done_n",
                    len(mods.list_mods(self.config.get("game_dir")))))
        self._refresh_mods_list()
        msgs = []
        for r in packs:
            line = i18n.tr("pack_installed", r.get("name", ""))
            if r.get("loader"):
                line += "\n" + i18n.tr("need_loader", r["loader"])
            msgs.append(line)
        if msgs:
            QMessageBox.information(
                self, i18n.tr("pack_installed", ""), "\n\n".join(msgs))

    def _on_mods_failed(self, err):
        self.mods_state.setText(i18n.tr("mod_install_failed") + err)
        self._log(i18n.tr("mod_install_failed") + err)

    def _refresh_mods_list(self):
        if not hasattr(self, "mods_list"):
            return
        self.mods_list.clear()
        gd = self.config.get("game_dir") or ""
        self._mod_files = mods.list_mods(gd)
        # 停用的（xxx.jar.disabled）也要列出来，否则停了就再也点不回来
        _md = os.path.join(gd, "mods")
        if os.path.isdir(_md):
            try:
                self._mod_files += sorted(
                    f for f in os.listdir(_md)
                    if f.lower().endswith((".jar.disabled", ".zip.disabled")))
            except OSError:
                pass
        for name in self._mod_files:
            off = name.lower().endswith(".disabled")
            real = name[:-9] if off else name
            want = self.mod_tag_filter.currentText() if hasattr(
                self, "mod_tag_filter") else "全部"
            if want and want != "全部":
                if want == "（没标签）":
                    if modtags.tags_of(real):
                        continue
                elif not modtags.has_tag(real, want):
                    continue
            info = mods.mod_info(os.path.join(gd, "mods", real))
            zh = self.MOD_NAME_ZH.get(info.get("id", ""))
            title = zh or info.get("name") or real
            if off:
                title = "（已停用）" + title
            sub = info.get("description") or ""
            tagline = modtags.summary(real)
            if tagline:
                sub = ("%s · %s" % (tagline, sub)).strip()
            if zh and info.get("name") and info["name"] != zh:
                sub = ("%s | %s" % (info["name"], sub)).strip(" |")
            labs = sorted(info.get("loaders") or [])
            if labs:
                sub = ("[%s] %s" % ("/".join(loaders.LABELS.get(x, x) for x in labs),
                                    sub)).strip()
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, 72))
            item.setData(Qt.UserRole, name)
            self.mods_list.addItem(item)
            self.mods_list.setItemWidget(
                item, self._local_row(info.get("icon"), title, sub,
                                      name[:2].upper()))
        self._reload_tag_filter()

    def _reload_tag_filter(self):
        """标签下拉：全部 / 没标签 / 各标签。保留当前选择。"""
        cb = getattr(self, "mod_tag_filter", None)
        if cb is None:
            return
        cur = cb.currentText()
        cb.blockSignals(True)
        cb.clear()
        cb.addItem("全部")
        cb.addItem("（没标签）")
        for t in modtags.all_tags():
            cb.addItem(t)
        i = cb.findText(cur)
        cb.setCurrentIndex(i if i >= 0 else 0)
        cb.blockSignals(False)

    def _tag_selected_mod(self):
        """给选中的模组打标签 / 写备注。"""
        item = self.mods_list.currentItem() if hasattr(self, "mods_list") else None
        if item is None:
            self.mods_state.setText("先在列表里点一个模组。")
            return
        fname = item.data(Qt.UserRole) or ""
        real = fname[:-9] if fname.lower().endswith(".disabled") else fname
        if not real:
            return
        dlg = ModTagDialog(real, modtags.get(real), self)
        if dlg.exec_() != QDialog.Accepted:
            return
        tags, note = dlg.values()
        ok, msg = modtags.set_mod(real, tags=tags, note=note)
        self.mods_state.setText(msg)
        self._refresh_mods_list()
        self._log("模组标签：%s -> %s" % (real, ", ".join(tags) or "（无）"))

    def _open_mod_blacklist(self):
        dlg = ModBlacklistDialog(self)
        dlg.exec_()

    def _open_mods_dir(self):
        path = mods.mods_dir(self.config.get("game_dir") or "")
        platform_utils.open_path(path)

    # ---------- 附魔计算器
    # 附魔计算已整体搬进工具页（ui/toolbox_page.py 的「附魔计算」页签），
    # 这里原来的独立页面已删除，只保留一个空的占位索引。

    def _build_music_page(self):
        from .music_page import MusicPage
        self.music_page = MusicPage()
        v = QVBoxLayout()
        v.setContentsMargins(18, 16, 18, 16)
        v.addWidget(self.music_page)
        return card(v)

    # ---------- 模组批量启停 / 冲突检测
    def _mods_toggle_all(self, enabled):
        gd = self.config.get("game_dir") or ""
        md = os.path.join(gd, "mods")
        if not os.path.isdir(md):
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("need_game_dir"))
            return
        n, bad = 0, 0
        try:
            names = sorted(os.listdir(md))
        except OSError as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        for f in names:
            p = os.path.join(md, f)
            if not os.path.isfile(p):
                continue
            low = f.lower()
            try:
                if enabled and low.endswith((".jar.disabled", ".zip.disabled")):
                    os.rename(p, os.path.join(md, f[:-9]))
                    n += 1
                elif (not enabled) and low.endswith((".jar", ".zip")):
                    os.rename(p, p + ".disabled")
                    n += 1
            except OSError:
                bad += 1
        self._refresh_mods_list()
        msg = ("已启用 %d 个模组" if enabled else "已停用 %d 个模组") % n
        if bad:
            msg += "，%d 个改名失败（可能正被游戏占用）" % bad
        self.mods_state.setText(msg)
        self._log(msg)

    def _toggle_selected_mod(self):
        row = self.mods_list.currentRow()
        files = getattr(self, "_mod_files", [])
        if row < 0 or row >= len(files):
            self.mods_state.setText(i18n.tr("select_mod_first"))
            return
        gd = self.config.get("game_dir") or ""
        md = os.path.join(gd, "mods")
        name = files[row]
        p = os.path.join(md, name)
        try:
            if name.lower().endswith(".disabled"):
                os.rename(p, os.path.join(md, name[:-9]))
                self.mods_state.setText("已启用 " + name[:-9])
            else:
                os.rename(p, p + ".disabled")
                self.mods_state.setText("已停用 " + name)
        except OSError as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        self._refresh_mods_list()
        self._log(self.mods_state.text())

    def _detect_mod_conflicts(self):
        """查两类问题：同一个 modid 装了多份；缺前置依赖。"""
        gd = self.config.get("game_dir") or ""
        md = os.path.join(gd, "mods")
        if not os.path.isdir(md):
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("need_game_dir"))
            return
        by_id, deps_of, missing = {}, {}, []
        builtin = {"minecraft", "java", "fabricloader", "fabric", "fabric-api",
                   "quilt_loader", "forge", "neoforge", "minecraft_forge"}
        try:
            names = sorted(os.listdir(md))
        except OSError as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        for f in names:
            if f.lower().endswith(".disabled"):
                continue
            p = os.path.join(md, f)
            if not os.path.isfile(p):
                continue
            mid = ""
            try:
                with zipfile.ZipFile(p) as z:
                    if "fabric.mod.json" in z.namelist():
                        data = json.loads(z.read("fabric.mod.json")
                                          .decode("utf-8", "replace"))
                        mid = data.get("id") or ""
                        deps_of[f] = [d for d in (data.get("depends") or {})
                                      if d.lower() not in builtin]
                    elif f.lower().endswith(".jar"):
                        mid = (mods.mod_info(p).get("id") or "")
            except Exception:
                mid = ""
            if not mid:
                mid = os.path.basename(f).lower()
            by_id.setdefault(mid.lower(), []).append(f)
        dups = {k: v for k, v in by_id.items() if len(v) > 1}
        missing_ids = []
        for f, deps in deps_of.items():
            for d in deps:
                if d.lower() not in by_id:
                    missing.append("%s 需要 %s" % (f, d))
                    missing_ids.append({"id": d, "by": [f]})
        total = len([f for f in names if not f.lower().endswith(".disabled")])
        dlg = QDialog(self)
        dlg.setWindowTitle("模组冲突检测")
        dlg.resize(680, 460)
        v = QVBoxLayout(dlg)
        head = QLabel(
            "看了 %d 个启用中的模组：%d 组重复 ID，%d 处缺前置。"
            % (total, len(dups), len(missing)))
        head.setObjectName("FieldLabel")
        head.setWordWrap(True)
        v.addWidget(head)
        lst = QListWidget()
        for mid, fs in sorted(dups.items()):
            lst.addItem("重复 ID「%s」：%s" % (mid, " / ".join(fs)))
        for m in missing:
            lst.addItem("缺前置：" + m)
        if not dups and not missing:
            lst.addItem("没发现问题：没有重复 ID，前置也都齐。")
        v.addWidget(lst, 1)
        foot = QHBoxLayout()
        if missing_ids:
            b_fix = QPushButton("装缺失前置")
            b_fix.setToolTip("去 Modrinth 找这些前置，确认后直接下进 mods")
            def _fix():
                vid = (getattr(self, "_detail_vid", "")
                       or self._selected_version_id() or "")
                m = re.search(r"\d+\.\d+(?:\.\d+)?", str(vid))
                mc = m.group(0) if m else ""
                loader = "fabric"
                dlg.accept()
                self._install_missing_deps(missing_ids, mc, loader)
            b_fix.clicked.connect(_fix)
            foot.addWidget(b_fix)
        foot.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.clicked.connect(dlg.accept)
        foot.addWidget(b_close)
        v.addLayout(foot)
        self._log(head.text())
        dlg.exec_()

    # ---------- 下载队列（最多同时两个，各自独立进度）
    DLQ_CONCURRENCY = 2

    def _dlq_add(self, url, dest_dir, filename, size=None, sha1="", kind="mod"):
        if not (url or "").strip():
            return False
        os.makedirs(dest_dir, exist_ok=True)
        self._dlq_tasks.append({
            "title": filename or os.path.basename(urllib.parse.urlparse(url).path)
                     or "download.bin",
            "url": url.strip(),
            "dest": os.path.join(dest_dir, filename
                                 or os.path.basename(urllib.parse.urlparse(url).path)
                                 or "download.bin"),
            "size": size, "sha1": sha1, "kind": kind,
            "cur": 0, "tot": 0, "state": "排队", "worker": None,
        })
        self._dlq_pump()
        return True

    def _dlq_running(self):
        return [t for t in self._dlq_tasks if t.get("state") == "下载中"]

    def _dlq_pump(self):
        tasks = getattr(self, "_dlq_tasks", [])
        while len(self._dlq_running()) < self.DLQ_CONCURRENCY:
            nxt = next((t for t in tasks if t.get("state") == "排队"), None)
            if nxt is None:
                break
            nxt["state"] = "下载中"
            try:
                fw = self._track(FileDownloadWorker(
                    nxt["url"], nxt["dest"], size=nxt.get("size"),
                    sha1=nxt.get("sha1") or None))
            except Exception as e:
                nxt["state"] = "失败：" + str(e)
                continue
            nxt["worker"] = fw
            fw.progress.connect(lambda cur, tot, t=nxt: t.update(
                cur=int(cur), tot=int(tot)))
            fw.done.connect(lambda path, t=nxt: self._dlq_one_done(t, path))
            fw.failed.connect(lambda e, t=nxt: self._dlq_one_failed(t, e))
            fw.start()
            self._log("队列开始下载：" + nxt["title"])

    def _dlq_one_done(self, task, path):
        task["state"] = "完成"
        task["cur"] = task.get("tot") or task.get("cur")
        self._log("队列完成：" + os.path.basename(path))
        if task.get("kind") == "mod":
            try:
                self._refresh_mods_list()
            except Exception:
                pass
        self._dlq_pump()

    def _dlq_one_failed(self, task, err):
        task["state"] = "失败：" + str(err)
        self._log("队列失败：" + task["title"] + " → " + str(err))
        self._dlq_pump()

    def _open_download_queue(self):
        gd = self.config.get("game_dir") or ""
        dlg = QDialog(self)
        dlg.setWindowTitle("下载队列")
        dlg.resize(760, 520)
        v = QVBoxLayout(dlg)
        tip = QLabel("粘贴直链就能排队；同时最多下 %d 个，每条进度独立。"
                     % self.DLQ_CONCURRENCY)
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        entry = QHBoxLayout()
        self.dlq_url = QLineEdit()
        self.dlq_url.setPlaceholderText("https://.../xxx.jar")
        self.dlq_name = QLineEdit()
        self.dlq_name.setPlaceholderText("存成什么名字（可空）")
        self.dlq_name.setMaximumWidth(200)
        self.dlq_kind = QComboBox()
        for label, key in (("模组", "mod"), ("资源包", "pack"), ("光影", "shader")):
            self.dlq_kind.addItem(label, key)
        b_add = QPushButton("加入队列")
        entry.addWidget(self.dlq_url, 1)
        entry.addWidget(self.dlq_name)
        entry.addWidget(self.dlq_kind)
        entry.addWidget(b_add)
        v.addLayout(entry)

        holder = QWidget()
        hv = QVBoxLayout(holder)
        hv.setContentsMargins(0, 0, 0, 0)
        hv.setSpacing(6)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(holder)
        v.addWidget(scroll, 1)

        rows = {}

        def dest_for(kind):
            if kind == "shader":
                return os.path.join(gd, "shaderpacks")
            if kind == "pack":
                return os.path.join(gd, "resourcepacks")
            return mods.mods_dir(gd)

        def rebuild():
            for w in rows.values():
                w["wrap"].setParent(None)
            rows.clear()
            for i, t in enumerate(self._dlq_tasks):
                wrap = QWidget()
                h = QHBoxLayout(wrap)
                h.setContentsMargins(0, 0, 0, 0)
                h.setSpacing(8)
                lab = QLabel(t["title"][:46])
                lab.setMinimumWidth(200)
                bar = QProgressBar()
                bar.setMaximum(t.get("tot") or 100)
                bar.setValue(t.get("cur") or 0)
                st = QLabel(t["state"])
                st.setMinimumWidth(120)
                h.addWidget(lab)
                h.addWidget(bar, 1)
                h.addWidget(st)
                hv.addWidget(wrap)
                rows[i] = {"wrap": wrap, "bar": bar, "st": st}
            hv.addStretch(1)

        def add_clicked():
            k = self.dlq_kind.currentData() or "mod"
            if not gd:
                tip.setText("先到设置里选游戏目录。")
                return
            name = self.dlq_name.text().strip()
            if not name:
                name = os.path.basename(
                    urllib.parse.urlparse(self.dlq_url.text().strip()).path)
            self._dlq_add(self.dlq_url.text(), dest_for(k), name, kind=k)
            self.dlq_url.clear()
            self.dlq_name.clear()
            rebuild()

        b_add.clicked.connect(add_clicked)

        timer = QTimer(dlg)
        def tick():
            running = False
            for i, t in enumerate(self._dlq_tasks):
                r = rows.get(i)
                if not r:
                    continue
                tot = t.get("tot") or 0
                if tot:
                    r["bar"].setMaximum(tot)
                    r["bar"].setValue(t.get("cur") or 0)
                r["st"].setText(t["state"] + (
                    "  %.1f/%.1f MB" % ((t.get("cur") or 0) / 1048576.0,
                                        tot / 1048576.0) if tot else ""))
                if t["state"] in ("排队", "下载中"):
                    running = True
            return running
        timer.timeout.connect(lambda: tick())
        timer.start(250)

        def clear_done():
            self._dlq_tasks = [t for t in self._dlq_tasks
                               if t["state"] in ("排队", "下载中")]
            rebuild()

        b_clear = QPushButton("清掉完成的")
        b_clear.clicked.connect(clear_done)
        foot = QHBoxLayout()
        foot.addWidget(b_clear)
        foot.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.clicked.connect(dlg.accept)
        foot.addWidget(b_close)
        v.addLayout(foot)
        rebuild()
        tick()
        dlg.exec_()

    def _delete_selected_mod(self):
        row = self.mods_list.currentRow()
        files = getattr(self, "_mod_files", [])
        if row < 0 or row >= len(files):
            QMessageBox.warning(self, i18n.tr("tip"), i18n.tr("select_mod_first"))
            return
        target = os.path.join(
            mods.mods_dir(self.config.get("game_dir") or ""), files[row])
        if QMessageBox.question(
                self, i18n.tr("btn_delete"),
                i18n.tr("confirm_delete")) != QMessageBox.Yes:
            return
        try:
            os.remove(target)
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        self._refresh_mods_list()
        self._log(i18n.tr("btn_delete") + " " + files[row])

    # ---------- 版本克隆 ----------
    def _clone_version(self, vid):
        """把选中的版本整份复制成新实例（模组/配置可选，日志不带）。"""
        gd = self.config.get("game_dir") or ""
        vdir = os.path.join(gd, "versions")
        if not os.path.isdir(os.path.join(vdir, vid)):
            QMessageBox.warning(self, i18n.tr("tip"), "找不到这个版本目录")
            return
        default = verclone.default_new_name(vid, vdir)
        name, ok = QInputDialog.getText(
            self, "复制版本", "新版本叫什么名字？", text=default)
        if not ok or not name.strip():
            return
        name = name.strip()
        if name == vid:
            QMessageBox.warning(self, i18n.tr("tip"), "新名字不能跟原来一样")
            return
        want_mods = QMessageBox.question(
            self, "复制版本", "把模组和配置也复制过去？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes) == QMessageBox.Yes
        self._log("开始复制版本 %s → %s" % (vid, name))
        ok, msg, newname = verclone.clone(
            vdir, vid, name, with_mods=want_mods, with_config=want_mods,
            progress=lambda s: None)
        self._log(msg)
        if not ok:
            QMessageBox.warning(self, "复制没成功", msg)
            return
        self._load_versions()
        QMessageBox.information(self, "复制完成", msg)

    # ---------- 列表右键菜单 ----------
    def _attach_ctx_menu(self, lst, kind):
        """给任意列表挂上右键菜单：删除 / 打开所在文件夹。"""
        try:
            lst.setContextMenuPolicy(Qt.CustomContextMenu)
            lst.customContextMenuRequested.connect(
                lambda pos, l=lst, k=kind: self._show_ctx_menu(l, pos, k))
        except Exception:
            pass

    def _show_ctx_menu(self, lst, pos, kind):
        item = lst.itemAt(pos)
        if item is None:
            return
        lst.setCurrentItem(item)
        row = lst.currentRow()
        gd = self.config.get("game_dir") or ""
        m = QMenu(self)

        if kind == "version":
            vid = (item.data(Qt.UserRole) or item.text()).strip()
            if not vid:
                return
            try:
                is_fav = favorites.has("version", vid)
            except Exception:
                is_fav = False
            a6 = m.addAction("取消收藏（从顶部放下来）" if is_fav
                             else "收藏这个版本（置顶显示）")
            a0 = m.addAction("复制这个版本（做一份副本）")
            a1 = m.addAction("删除这个版本（只删它的文件）")
            a2 = m.addAction("打开版本文件夹")
            a4 = m.addAction("换封面图")
            a5 = m.addAction("清除封面")
            a6.triggered.connect(lambda: self._toggle_fav_version(vid))
            a0.triggered.connect(lambda: self._clone_version(vid))
            a1.triggered.connect(lambda: self._delete_version(vid))
            a2.triggered.connect(
                lambda: platform_utils.open_path(
                    os.path.join(gd, "versions", vid)))
            a4.triggered.connect(lambda: self._pick_version_cover(vid))
            a5.triggered.connect(lambda: self._clear_version_cover(vid))
        elif kind == "world":
            name = self._selected_world()
            if not name:
                return
            a1 = m.addAction("删除这个存档（先自动备份一次）")
            a2 = m.addAction("打开存档文件夹")
            a3 = m.addAction("管理存档数据包")
            a1.triggered.connect(lambda: self._delete_world(name))
            a2.triggered.connect(
                lambda: platform_utils.open_path(
                    os.path.join(worlds.saves_dir(gd), name)))
            a3.triggered.connect(self._manage_datapacks)
        elif kind == "mod":
            files = getattr(self, "_mod_files", [])
            if not (0 <= row < len(files)):
                return
            fname = files[row]
            try:
                is_fav = favorites.has("mod", fname)
            except Exception:
                is_fav = False
            a3 = m.addAction("取消收藏这个模组" if is_fav else "收藏这个模组")
            a1 = m.addAction("删除这个模组")
            a2 = m.addAction("打开模组文件夹")
            a3.triggered.connect(lambda: self._toggle_fav_pack("mod", fname))
            a1.triggered.connect(self._delete_selected_mod)
            a2.triggered.connect(
                lambda: platform_utils.open_path(mods.mods_dir(gd)))
        elif kind == "pack":
            names = mods.list_resourcepacks(gd)
            if not (0 <= row < len(names)):
                return
            nm = names[row]
            try:
                is_fav = favorites.has("resourcepack", nm)
            except Exception:
                is_fav = False
            a3 = m.addAction("取消收藏这个资源包" if is_fav
                             else "收藏这个资源包")
            a1 = m.addAction("删除这个资源包")
            a2 = m.addAction("打开资源包文件夹")
            a3.triggered.connect(
                lambda: self._toggle_fav_pack("resourcepack", nm))
            a1.triggered.connect(lambda: self._delete_pack(nm))
            a2.triggered.connect(self._open_packs_dir)
        elif kind == "shader":
            items = shaderpacks.list_shaderpacks(gd)
            if not (0 <= row < len(items)):
                return
            nm = items[row]
            try:
                is_fav = favorites.has("shader", nm)
            except Exception:
                is_fav = False
            a3 = m.addAction("取消收藏这个光影" if is_fav else "收藏这个光影")
            a1 = m.addAction("删除这个光影包")
            a2 = m.addAction("打开光影文件夹")
            a3.triggered.connect(lambda: self._toggle_fav_pack("shader", nm))
            a1.triggered.connect(lambda: self._delete_shader(items[row]))
            a2.triggered.connect(self._open_shader_dir)
        elif kind == "screenshot":
            path = item.data(Qt.UserRole)
            if not path:
                return
            a1 = m.addAction("删除这张截图")
            a2 = m.addAction("打开截图文件夹")
            a1.triggered.connect(lambda: self._delete_screenshot(path))
            a2.triggered.connect(
                lambda: platform_utils.open_path(
                    os.path.dirname(str(path))))
        else:
            return

        m.exec_(lst.mapToGlobal(pos))

    def _toggle_fav_pack(self, kind, key):
        """模组/资源包/光影的收藏开关（键就是文件名或包名）。"""
        try:
            added = favorites.toggle(kind, key, {"name": key})
        except Exception as e:
            QMessageBox.warning(self, i18n.tr("tip"), str(e))
            return
        self._log(("已收藏：" if added else "已取消收藏：") + key)

    def _confirm_del(self, text):
        return QMessageBox.question(
            self, "确认删除", text,
            QMessageBox.Yes
            | QMessageBox.No) == QMessageBox.Yes

    def _cover_dir(self):
        d = getattr(self, "_cover_dir_cache", None)
        if d and os.path.isdir(d):
            return d
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher", "covers")
        os.makedirs(d, exist_ok=True)
        self._cover_dir_cache = d
        return d

    def _cover_path(self, vid):
        return os.path.join(self._cover_dir(), str(vid) + ".png")

    def _pick_version_cover(self, vid):
        p, _ = QFileDialog.getOpenFileName(
            self, "给这个版本选一张封面图", "",
            "图片 (*.png *.jpg *.jpeg *.bmp *.webp)")
        if not p:
            return
        try:
            img = QImage(p)
            if img.isNull():
                raise RuntimeError("这张图读不出来")
            img = img.scaled(320, 180, Qt.KeepAspectRatioByExpanding,
                             Qt.SmoothTransformation)
            img.save(self._cover_path(vid), "PNG")
        except Exception as e:
            QMessageBox.warning(self, "换封面失败", str(e))
            return
        self._log("已换封面：" + vid)
        self._refresh_version_list()

    def _clear_version_cover(self, vid):
        p = self._cover_path(vid)
        if not os.path.isfile(p):
            return
        if not self._confirm_del("清除「%s」的自定义封面？" % vid):
            return
        try:
            os.remove(p)
        except Exception as e:
            QMessageBox.warning(self, "清除失败", str(e))
            return
        self._refresh_version_list()

    # ---------- 全窗口拖入识别
    def _show_drop_hint(self, on):
        if on:
            if self._drop_overlay is None:
                lb = QLabel(self)
                lb.setObjectName("DropHint")
                lb.setAlignment(Qt.AlignCenter)
                lb.setWordWrap(True)
                lb.setText(
                    "松手就会自动识别并导入：\n"
                    "模组 · 光影 · 材质包 · 存档 · 版本 · 整合包 · 皮肤")
                lb.setStyleSheet(
                    "QLabel{border:2px dashed #4C8DFF;border-radius:16px;"
                    "background:rgba(10,16,26,230);color:#cfe4ff;"
                    "font-size:17px;padding:24px;}")
                self._drop_overlay = lb
            self._drop_overlay.setGeometry(0, 0, self.width(), self.height())
            self._drop_overlay.show()
            self._drop_overlay.raise_()
        elif self._drop_overlay is not None:
            self._drop_overlay.hide()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._show_drop_hint(True)
        else:
            e.ignore()

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dragLeaveEvent(self, e):
        self._show_drop_hint(False)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self._drop_overlay is not None:
            self._drop_overlay.setGeometry(0, 0, self.width(), self.height())

    def dropEvent(self, e):
        self._show_drop_hint(False)
        paths = []
        for u in e.mimeData().urls():
            if u.isLocalFile():
                paths.append(u.toLocalFile())
        if paths:
            e.acceptProposedAction()
            self._on_drop_paths(paths)

    def _on_drop_paths(self, paths):
        gd = self.config.get("game_dir") or ""
        if not gd:
            QMessageBox.warning(self, "还没设置游戏目录",
                                "先去设置页选游戏目录，再把东西拖进来。")
            return
        self._log("开始识别拖进来的 %d 项......" % len(paths))
        self._import_worker = self._track(ImportWorker(paths, gd))
        self._import_worker.log.connect(self._log)
        self._import_worker.done.connect(self._on_import_done)
        self._import_worker.start()

    def _on_import_done(self, results):
        ok = [r for r in results if r[2]]
        bad = [r for r in results if not r[2]]
        for _p, kind, good, msg in results:
            self._log(("OK " if good else "跳过 ") + msg)
        try:
            self._refresh_version_list()
        except Exception:
            pass
        from core import importer as _imp

        parts = ['<div style="color:#9fd49f">成功 %d 项</div>' % len(ok)]
        for p, kind, _good, msg in ok:
            parts.append(
                '<div style="color:#7fe07f">%s · %s · %s</div>'
                % (os.path.basename(p.rstrip("\\/")), _imp.KIND_LABELS.get(kind, kind),
                   msg))
        if bad:
            parts.append('<div style="color:#ff5c5c"><b>下面这些没认出来：</b></div>')
            for p, kind, _good, msg in bad:
                parts.append(
                    '<div style="color:#ff5c5c">%s · 未知的文件或文件夹（%s）</div>'
                    % (os.path.basename(p.rstrip("\\/")), msg))
        dlg = QMessageBox(self)
        dlg.setWindowTitle("导入结果")
        dlg.setTextFormat(Qt.RichText)
        dlg.setText("<br>".join(parts))
        dlg.setStandardButtons(QMessageBox.Ok)
        dlg.exec_()

    def _delete_version(self, vid):
        gd = self.config.get("game_dir") or ""
        path = os.path.join(gd, "versions", vid)
        if not os.path.isdir(path):
            QMessageBox.warning(self, "提示", "找不到这个版本的目录：" + path)
            return
        if not self._confirm_del(
                "删除版本「%s」？\n只删这个版本的 json/jar/库文件，"
                "存档和其他版本不受影响。" % vid):
            return
        try:
            shutil.rmtree(path)
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self._log("已删除版本：" + vid)
        self._refresh_version_list()
        try:
            self._update_install_state()
        except Exception:
            pass

    def _delete_world(self, name):
        gd = self.config.get("game_dir") or ""
        if not self._confirm_del(
                "删除存档「%s」？\n删除前会先自动备份一份，"
                "之后可以在设置里「还原备份」找回来。" % name):
            return
        if self.config.get("auto_backup"):
            try:
                backup.backup_all(gd, int(self.config.get("backup_keep") or 5),
                                  self._log)
            except Exception as e:
                self._log("删除前备份失败：" + str(e))
        try:
            shutil.rmtree(os.path.join(worlds.saves_dir(gd), name))
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self._log("已删除存档：" + name)
        self._refresh_worlds()

    def _delete_pack(self, name):
        gd = self.config.get("game_dir") or ""
        path = os.path.join(gd, "resourcepacks", name)
        if not self._confirm_del("删除资源包「%s」？" % name):
            return
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self._log("已删除资源包：" + name)
        self._refresh_packs()

    def _delete_shader(self, info):
        path = (info or {}).get("path")
        name = (info or {}).get("name") or os.path.basename(str(path))
        if not path:
            return
        if not self._confirm_del("删除光影包「%s」？" % name):
            return
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self._log("已删除光影包：" + name)
        self._refresh_shaders()

    def _delete_screenshot(self, path):
        if not self._confirm_del("删除截图「%s」？" % os.path.basename(str(path))):
            return
        try:
            os.remove(str(path))
        except Exception as e:
            QMessageBox.warning(self, "删除失败", str(e))
            return
        self._log("已删除截图：" + os.path.basename(str(path)))
        try:
            self._refresh_screenshots()
        except Exception:
            pass

    # ---------- 在线下载（Modrinth） ----------
    def _tab_browse(self, kind):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)

        edit = QLineEdit()
        edit.setPlaceholderText(i18n.tr("search_placeholder"))
        edit.returnPressed.connect(lambda: self._browse_search(kind))
        b_search = QPushButton(i18n.tr("btn_search"))
        b_search.setObjectName("PrimaryButton")
        b_search.clicked.connect(lambda: self._browse_search(kind))
        v.addWidget(self._row(edit, b_search))

        # 版本与加载器：默认按当前版本推荐，可自行改选其他版本
        sel_row = QWidget()
        sh = QHBoxLayout(sel_row)
        sh.setContentsMargins(0, 0, 0, 0)
        sh.setSpacing(10)
        mc_label = QLabel(i18n.tr("mc_version_label"))
        self.combo_browse_mc = QComboBox()
        self.combo_browse_mc.setEditable(True)
        self._populate_browse_mc()
        combo_loader = QComboBox()
        if kind == "mod":
            combo_loader.addItem(i18n.tr("any_loader"), "")
            for lk in ("fabric", "quilt", "forge", "neoforge"):
                combo_loader.addItem(loaders.LABELS[lk], lk)
        else:
            mc_label.hide()
            self.combo_browse_mc.hide()
            combo_loader.hide()
        sh.addWidget(mc_label)
        sh.addWidget(self.combo_browse_mc, 1)
        sh.addWidget(combo_loader)

        # 模组"类型"筛选：Modrinth 的 categories。选"全部类型"就是不筛。
        if kind == "mod":
            cat_row = QWidget()
            ch = QHBoxLayout(cat_row)
            ch.setContentsMargins(0, 0, 0, 0)
            ch.setSpacing(10)
            ch.addWidget(QLabel("类型"))
            combo_cat = QComboBox()
            combo_cat.addItem("全部类型", "")
            for key, name in MOD_CATEGORIES:
                combo_cat.addItem(name, key)
            combo_cat.setMinimumWidth(150)
            ch.addWidget(combo_cat)
            ch.addStretch(1)
            self.combo_browse_cat = combo_cat
        v.addWidget(sel_row)
        if kind == "mod":
            v.addWidget(cat_row)

        lwidget = QListWidget()
        lwidget.setSpacing(6)
        v.addWidget(lwidget, 1)

        # 分页：上一页/下一页，基于 Modrinth offset，可翻全部结果
        prow = QHBoxLayout()
        prow.setSpacing(10)
        b_prev = QPushButton(i18n.tr("btn_prev_page"))
        b_next = QPushButton(i18n.tr("btn_next_page"))
        b_prev.clicked.connect(lambda: self._browse_flip_page(kind, -1))
        b_next.clicked.connect(lambda: self._browse_flip_page(kind, 1))
        self.page_label = QLabel(i18n.tr("page_n", 1))
        self.page_label.setAlignment(Qt.AlignCenter)
        prow.addWidget(b_prev)
        prow.addWidget(self.page_label, 1)
        prow.addWidget(b_next)
        v.addLayout(prow)

        self.browse_progress = QProgressBar()
        self.browse_progress.setHidden(True)
        self.browse_progress.setFormat(i18n.tr("downloading"))
        v.addWidget(self.browse_progress)

        state = QLabel("")
        state.setObjectName("FieldLabel")
        v.addWidget(state)

        if kind == "mod":
            self.edit_browse_mod = edit
            self.combo_browse_loader = combo_loader
            self.list_browse_mod = lwidget
            self.browse_mod_state = state
            self.page_label_mod = self.page_label
            self._browse_rows_mod = []
            self._browse_icons_mod = []
            self._browse_offset_mod = 0
        else:
            self.edit_browse_rp = edit
            self.list_browse_rp = lwidget
            self.browse_rp_state = state
            self.page_label_rp = self.page_label
            self._browse_rows_rp = []
            self._browse_icons_rp = []
            self._browse_offset_rp = 0
        self._sync_browse_recommendation()
        return w

    def _populate_browse_mc(self):
        """给下载页 MC 版本下拉填本地版本与清单版本，保留用户当前输入。"""
        if not hasattr(self, "combo_browse_mc"):
            return
        cur = self.combo_browse_mc.currentText()
        self.combo_browse_mc.blockSignals(True)
        self.combo_browse_mc.clear()
        ids = []
        gd = self.config.get("game_dir") or ""
        vroot = os.path.join(gd, "versions")
        if os.path.isdir(vroot):
            for name in os.listdir(vroot):
                jp = os.path.join(vroot, name, name + ".json")
                if os.path.isdir(os.path.join(vroot, name)) and os.path.exists(jp):
                    ids.append(name)
        for ver in getattr(self, "version_data", []) or []:
            if ver.get("id") and ver["id"] not in ids:
                ids.append(ver["id"])
        self.combo_browse_mc.addItems(ids)
        self.combo_browse_mc.setEditText(cur)
        self.combo_browse_mc.blockSignals(False)

    def _sync_browse_recommendation(self):
        """按启动页当前版本自动推荐 MC 版本与加载器（可被用户改选覆盖）。"""
        if not hasattr(self, "combo_browse_mc"):
            return
        vid = self._selected_version_id()
        if not vid:
            return
        mc = self._loader_base_mc()
        self.combo_browse_mc.setEditText(mc)
        loader_kind = self._detect_loader_kind(vid)
        if hasattr(self, "combo_browse_loader"):
            if loader_kind:
                i = self.combo_browse_loader.findData(loader_kind)
                if i >= 0:
                    self.combo_browse_loader.setCurrentIndex(i)
            else:
                self.combo_browse_loader.setCurrentIndex(0)

    def _browse_widgets(self, kind):
        if kind == "mod":
            return (self.edit_browse_mod, self.combo_browse_loader,
                    self.list_browse_mod, self.browse_mod_state)
        return (self.edit_browse_rp, None, self.list_browse_rp,
                self.browse_rp_state)

    def _browse_rows(self, kind):
        return self._browse_rows_mod if kind == "mod" else self._browse_rows_rp

    def _browse_icons(self, kind):
        return self._browse_icons_mod if kind == "mod" else self._browse_icons_rp

    # 常见模组内置译名（按 modId 匹配，其余显示原名）
    MOD_NAME_ZH = {
        "fabric-api": "Fabric API 模组接口",
        "fabricloader": "Fabric 加载器",
        "sodium": "Sodium 渲染优化",
        "lithium": "Lithium 逻辑优化",
        "iris": "Iris 光影",
        "modmenu": "Mod Menu 模组菜单",
        "jei": "JEI 物品管理器",
        "jade": "Jade 信息显示",
        "wthit": "WTHIT 方块信息",
    }

    def _placeholder_pix(self, text, size=56, color="#3A4150"):
        """无封面时画圆角占位图，保持行高与视觉一致。"""
        pix = QPixmap(size, size)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(color))
        p.drawRoundedRect(0, 0, size, size, 10, 10)
        p.setPen(QColor("#C8CEDB"))
        f = QFont()
        f.setBold(True)
        f.setPointSize(10)
        p.setFont(f)
        p.drawText(QRect(0, 0, size, size), Qt.AlignCenter, text)
        p.end()
        return pix

    def _local_row(self, icon_bytes, title, subtitle, ph="--"):
        """本地条目通用行：左侧封面，右侧加粗名称 + 一行说明。"""
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(10, 8, 10, 8)
        h.setSpacing(12)
        icon = QLabel()
        icon.setFixedSize(56, 56)
        icon.setAlignment(Qt.AlignCenter)
        pix = QPixmap()
        if icon_bytes and pix.loadFromData(icon_bytes):
            icon.setPixmap(pix.scaled(56, 56, Qt.KeepAspectRatio,
                                      Qt.SmoothTransformation))
        else:
            icon.setPixmap(self._placeholder_pix(ph))
        h.addWidget(icon)

        col = QVBoxLayout()
        col.setSpacing(4)
        t = QLabel(title)
        tf = QFont()
        tf.setBold(True)
        t.setFont(tf)
        s = QLabel(subtitle or "")
        s.setObjectName("FieldLabel")
        s.setText(QFontMetrics(s.font()).elidedText(
            s.text(), Qt.ElideRight, 430))
        col.addWidget(t)
        col.addWidget(s)
        h.addLayout(col, 1)
        return row

    def _make_browse_row(self, kind, idx, hit):
        """单行：封面 + 标题/作者/简介 + 独立下载按钮。"""
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(10, 8, 10, 8)
        h.setSpacing(12)

        icon = ClickableLabel()
        icon.setFixedSize(60, 60)
        icon.setAlignment(Qt.AlignCenter)
        icon.setObjectName("ModIcon")
        icon.setText(i18n.tr("no_icon"))
        icon.setToolTip("点这里看这个项目的所有版本")
        icon.clicked.connect(lambda h=hit, k=kind: self._open_pack_versions(k, h))
        h.addWidget(icon)

        col = QVBoxLayout()
        col.setSpacing(4)
        title = QLabel(hit.get("title", ""))
        tf = QFont()
        tf.setBold(True)
        tf.setPointSize(11)
        title.setFont(tf)
        author = QLabel(i18n.tr("author_line",
                                hit.get("author", ""),
                                hit.get("downloads", 0)))
        author.setObjectName("FieldLabel")
        desc_text = hit.get("description", "") or ""
        desc = QLabel(desc_text)
        desc.setObjectName("FieldLabel")
        desc.setText(QFontMetrics(desc.font()).elidedText(
            desc_text, Qt.ElideRight, 430))
        col.addWidget(title)
        col.addWidget(author)
        col.addWidget(desc)
        h.addLayout(col, 1)

        b = QPushButton(i18n.tr("btn_download"))
        b.setObjectName("PrimaryButton")
        b.setFixedWidth(88)
        b.clicked.connect(lambda _checked=False, i=idx:
                          self._browse_download_at(kind, i))
        h.addWidget(b)
        return row, icon

    def _browse_offset(self, kind, value=None):
        attr = "_browse_offset_" + kind
        if value is not None:
            setattr(self, attr, max(0, value))
        return getattr(self, attr, 0)

    def _browse_page_label(self, kind):
        return self.page_label_mod if kind == "mod" else self.page_label_rp

    def _browse_search(self, kind, reset_offset=True):
        edit, combo, lwidget, state = self._browse_widgets(kind)
        if reset_offset:
            self._browse_offset(kind, 0)
        # 只有模组按 MC 版本+加载器筛；资源包跨版本通用，带版本筛会直接筛成 0 条
        if kind == "mod" and hasattr(self, "combo_browse_mc"):
            mc = self.combo_browse_mc.currentText().strip()
        else:
            mc = ""
        loader = combo.currentData() if combo else None
        category = None
        if kind == "mod" and hasattr(self, "combo_browse_cat"):
            category = self.combo_browse_cat.currentData() or None
        query = edit.text().strip()
        offset = self._browse_offset(kind)
        state.setText(i18n.tr("searching"))
        lwidget.clear()
        self._sw = self._track(
            ModrinthSearchWorker(kind, mc, query, loader, offset=offset,
                                 category=category))
        self._sw.done.connect(lambda hits, total:
                              self._on_browse_results(kind, hits, total))
        self._sw.failed.connect(
            lambda e: state.setText(i18n.tr("search_failed_n", e)))
        self._sw.start()

    def _browse_flip_page(self, kind, direction):
        offset = self._browse_offset(kind)
        limit = modrinth.LIMIT
        new_offset = offset + direction * limit
        if new_offset < 0:
            return
        if getattr(self, "_browse_total_" + kind, 0) and \
                new_offset >= getattr(self, "_browse_total_" + kind):
            return
        self._browse_offset(kind, new_offset)
        self._browse_search(kind, reset_offset=False)

    def _on_browse_results(self, kind, hits, total):
        _edit, _combo, lwidget, state = self._browse_widgets(kind)
        lwidget.clear()
        rows, icons, icon_jobs = [], [], []
        for idx, hit in enumerate(hits):
            rows.append(hit)
            item = QListWidgetItem(lwidget)
            item.setSizeHint(QSize(0, 78))
            row, icon = self._make_browse_row(kind, idx, hit)
            lwidget.addItem(item)
            lwidget.setItemWidget(item, row)
            icons.append(icon)
            if hit.get("icon_url"):
                icon_jobs.append((idx, hit["icon_url"]))
        if kind == "mod":
            self._browse_rows_mod, self._browse_icons_mod = rows, icons
        else:
            self._browse_rows_rp, self._browse_icons_rp = rows, icons
        setattr(self, "_browse_total_" + kind, total)
        page = self._browse_offset(kind) // modrinth.LIMIT + 1
        self._browse_page_label(kind).setText(i18n.tr("page_n", page))
        state.setText(i18n.tr("results_count", total, len(hits)))
        if icon_jobs:
            iw = self._track(ModrinthIconWorker(icon_jobs))
            iw.icon_ready.connect(lambda idx, pm, k=kind:
                                  self._on_icon_ready(k, idx, pm))
            iw.start()

    def _on_icon_ready(self, kind, idx, data):
        icons = self._browse_icons(kind)
        if idx >= len(icons):
            return
        pix = data if isinstance(data, QPixmap) else QPixmap()
        if not isinstance(data, QPixmap):
            if not pix.loadFromData(data):
                return
        icons[idx].setPixmap(pix.scaled(60, 60, Qt.KeepAspectRatio,
                                        Qt.SmoothTransformation))

    def _open_pack_versions(self, kind, hit):
        """点封面 → 看这个项目所有版本，任意一个都能直接装。"""
        pid = hit.get("project_id")
        if not pid:
            return
        title = hit.get("title") or pid
        dlg = QDialog(self)
        dlg.setWindowTitle("%s · 所有版本" % title)
        dlg.resize(780, 560)
        v = QVBoxLayout(dlg)
        head = QLabel("正在拉取版本列表......")
        head.setObjectName("FieldLabel")
        head.setWordWrap(True)
        v.addWidget(head)
        lst = QListWidget()
        lst.setSpacing(4)
        v.addWidget(lst, 1)
        bar = QProgressBar()
        bar.setVisible(False)
        v.addWidget(bar)
        foot = QHBoxLayout()
        foot.addStretch(1)
        bc = QPushButton("关闭")
        bc.clicked.connect(dlg.accept)
        foot.addWidget(bc)
        v.addLayout(foot)

        icon_pm = {"pm": None}
        icon_labels = []

        def fill(versions):
            versions = versions or []
            lst.clear()
            del icon_labels[:]
            if not versions:
                head.setText("这个项目一个版本都没拉到。")
                return
            head.setText("共 %d 个版本（最新在最上面）。点「下载这个」就装进对应目录。"
                         % len(versions))
            for ver in versions:
                f = modrinth.pick_file(ver, prefer_zip=(kind != "mod"))
                if not f:
                    continue
                item = QListWidgetItem(lst)
                item.setSizeHint(QSize(0, 62))
                w = QWidget()
                hh = QHBoxLayout(w)
                hh.setContentsMargins(8, 4, 8, 4)
                ic = QLabel()
                ic.setFixedSize(52, 52)
                ic.setAlignment(Qt.AlignCenter)
                ic.setObjectName("ModIcon")
                if icon_pm["pm"] is not None:
                    ic.setPixmap(icon_pm["pm"])
                hh.addWidget(ic)
                icon_labels.append(ic)
                left = QVBoxLayout()
                left.setSpacing(2)
                t = QLabel("%s   ·   %s" % (
                    ver.get("version_number") or "",
                    ", ".join((ver.get("game_versions") or [])[:5]) or "通用"))
                tf = QFont()
                tf.setBold(True)
                t.setFont(tf)
                sub = QLabel("%s   ·   %s   ·   %.1f MB" % (
                    ver.get("version_type") or "",
                    (ver.get("date_published") or "")[:10],
                    (f.get("size") or 0) / 1048576.0))
                sub.setObjectName("FieldLabel")
                left.addWidget(t)
                left.addWidget(sub)
                hh.addLayout(left, 1)
                b = QPushButton("下载这个")
                b.setFixedWidth(96)
                b.clicked.connect(
                    lambda _c=False, ff=f: self._download_specific(
                        kind, ff, head, bar))
                hh.addWidget(b)
                lst.setItemWidget(item, w)

        pw = self._track(ProjectVersionsWorker(pid))
        self._ver_dlg_worker = pw
        pw.done.connect(fill)
        pw.failed.connect(lambda e: head.setText("拉取失败：" + str(e)))
        pw.start()

        icon_url = hit.get("icon_url") or ""
        if icon_url:
            iw = self._track(ModrinthIconWorker([(0, icon_url)]))

            def on_icon(_idx, data):
                pm = QPixmap()
                if not pm.loadFromData(data):
                    return
                pm = pm.scaled(QSize(52, 52), Qt.KeepAspectRatio,
                               Qt.SmoothTransformation)
                icon_pm["pm"] = pm
                for lab in icon_labels:
                    lab.setPixmap(pm)

            iw.icon_ready.connect(on_icon)
            self._ver_icon_worker = iw
            iw.start()
        dlg.exec_()

    def _download_specific(self, kind, file, head, bar):
        gd = self.config.get("game_dir") or ""
        if not gd:
            head.setText("还没设游戏目录，装不了。")
            return
        if kind == "mod":
            dest_dir = mods.mods_dir(gd)
        elif kind == "shader":
            dest_dir = os.path.join(gd, "shaderpacks")
        else:
            dest_dir = os.path.join(gd, "resourcepacks")
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, file.get("filename") or "download.bin")
        bar.setVisible(True)
        bar.setMaximum(100)
        bar.setValue(0)
        head.setText("正在下载 %s ......" % os.path.basename(dest))
        fw = self._track(FileDownloadWorker(
            file["url"], dest, size=file.get("size"),
            sha1=(file.get("hashes") or {}).get("sha1")))
        self._file_dl_worker = fw

        def on_prog(cur, tot):
            if tot:
                bar.setMaximum(int(tot))
                bar.setValue(int(cur))

        def on_done(path):
            bar.setVisible(False)
            head.setText("已下载：" + os.path.basename(path))
            self._log("已下载：" + os.path.basename(path))
            if kind == "mod":
                try:
                    self._refresh_mods_list()
                except Exception:
                    pass

        fw.progress.connect(on_prog)
        fw.done.connect(on_done)
        fw.failed.connect(lambda e: head.setText("下载失败：" + str(e)))
        fw.start()

    def _browse_download_at(self, kind, idx):
        rows = self._browse_rows(kind)
        if idx >= len(rows):
            return
        state = self._browse_widgets(kind)[3]
        pid = rows[idx].get("project_id")
        game_dir = self.config.get("game_dir")
        if kind == "mod":
            dest = mods.mods_dir(game_dir)
            loader = self.combo_browse_loader.currentData()
        else:
            dest = os.path.join(game_dir, "resourcepacks")
            os.makedirs(dest, exist_ok=True)
            loader = None
        mc = self.combo_browse_mc.currentText().strip() \
            if (kind == "mod" and hasattr(self, "combo_browse_mc")) else ""
        state.setText(i18n.tr("downloading"))
        self.browse_progress.setHidden(False)
        self.browse_progress.setValue(0)
        self._dw = self._track(ModrinthDownloadWorker(pid, mc, loader, dest,
                                                      project_type=kind))
        self._dw.log.connect(lambda m: state.setText(m))
        self._dw.progress.connect(self._on_browse_progress)
        self._dw.done.connect(lambda p: self._on_browse_download(kind, p))
        self._dw.failed.connect(
            lambda e, k=kind: self._on_browse_download_failed(k, e))
        self._dw.start()

    def _on_browse_progress(self, cur, total):
        if total:
            self.browse_progress.setMaximum(total)
            self.browse_progress.setValue(cur)

    def _on_browse_download_failed(self, kind, err):
        self.browse_progress.setHidden(True)
        self._browse_widgets(kind)[3].setText(
            i18n.tr("download_failed_n", err))

    def _on_browse_download(self, kind, path):
        _edit, _combo, _lw, state = self._browse_widgets(kind)
        self.browse_progress.setHidden(True)
        state.setText(i18n.tr("downloaded_n", os.path.basename(path)))
        if kind == "mod":
            self._refresh_mods_list()
        else:
            self._refresh_packs()

    # ---------- 光影 ----------
    def _tab_shader_installed(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)

        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(10)
        b_open = QPushButton("打开光影文件夹")
        b_open.clicked.connect(self._open_shader_dir)
        b_import = QPushButton("导入光影包")
        b_import.clicked.connect(self._import_shader)
        b_refresh = QPushButton(i18n.tr("btn_refresh"))
        b_refresh.clicked.connect(self._refresh_shaders)
        h.addWidget(b_open)
        h.addWidget(b_import)
        h.addWidget(b_refresh)
        h.addStretch(1)
        v.addWidget(row)

        self.shader_drop = DropZone("把光影包 .zip 直接拖到这里导入")
        self.shader_drop.setMinimumHeight(74)
        self.shader_drop.filesDropped.connect(self._on_shaders_dropped)
        v.addWidget(self.shader_drop)

        self.shaders_list = QListWidget()
        self._attach_ctx_menu(self.shaders_list, "shader")
        v.addWidget(self.shaders_list, 1)

        self.shaders_state = QLabel("")
        self.shaders_state.setObjectName("FieldLabel")
        v.addWidget(self.shaders_state)
        self._refresh_shaders()
        return w

    def _refresh_shaders(self):
        if not hasattr(self, "shaders_list"):
            return
        self.shaders_list.clear()
        gd = self.config.get("game_dir") or ""
        items = shaderpacks.list_shaderpacks(gd)
        for it in items:
            entry = QListWidgetItem()
            entry.setSizeHint(QSize(0, 72))
            self.shaders_list.addItem(entry)
            self.shaders_list.setItemWidget(
                entry, self._local_row(it.get("icon"), it["name"],
                                       "光影包 | " + it["size_text"], "光"))
        if items:
            self.shaders_state.setText("已安装 %d 个光影包" % len(items))
        else:
            self.shaders_state.setText(
                "还没有光影包，可在「在线光影」里下载，或点「导入光影包」")

    def _open_shader_dir(self):
        shaderpacks.open_dir(self.config.get("game_dir") or "")

    def _on_shaders_dropped(self, paths):
        gd = self.config.get("game_dir") or ""
        if not gd:
            self.shaders_state.setText("先在设置里选好游戏目录")
            return
        ok = 0
        for p in paths:
            try:
                shaderpacks.install_file(p, gd, self._log)
                ok += 1
            except Exception as e:
                self.shaders_state.setText(
                    "导入失败（%s）：%s" % (os.path.basename(str(p)), e))
        self._refresh_shaders()
        if ok:
            self.shaders_state.setText("已导入 %d 个光影包" % ok)

    def _import_shader(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "导入光影包", "", "光影包 (*.zip)")
        if not path:
            return
        try:
            shaderpacks.install_file(path, self.config.get("game_dir") or "",
                                     self._log)
            self._refresh_shaders()
        except Exception as e:
            QMessageBox.warning(self, "导入失败", str(e))

    def _tab_shader_online(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)

        edit = QLineEdit()
        edit.setPlaceholderText("搜索光影（如 Complementary / BSL / Sildurs）")
        edit.returnPressed.connect(lambda: self._shader_search(True))
        b = QPushButton(i18n.tr("btn_search"))
        b.setObjectName("PrimaryButton")
        b.clicked.connect(lambda: self._shader_search(True))
        self.shader_edit = edit
        v.addWidget(self._row(edit, b))

        self.shader_list = QListWidget()
        self.shader_list.setSpacing(6)
        v.addWidget(self.shader_list, 1)

        prow = QHBoxLayout()
        prow.setSpacing(10)
        b_prev = QPushButton(i18n.tr("btn_prev_page"))
        b_next = QPushButton(i18n.tr("btn_next_page"))
        b_prev.clicked.connect(lambda: self._shader_flip(-1))
        b_next.clicked.connect(lambda: self._shader_flip(1))
        self.shader_page_label = QLabel(i18n.tr("page_n", 1))
        self.shader_page_label.setAlignment(Qt.AlignCenter)
        prow.addWidget(b_prev)
        prow.addWidget(self.shader_page_label, 1)
        prow.addWidget(b_next)
        v.addLayout(prow)

        self.shader_progress = QProgressBar()
        self.shader_progress.setHidden(True)
        self.shader_progress.setFormat(i18n.tr("downloading"))
        v.addWidget(self.shader_progress)

        self.shader_state = QLabel("")
        self.shader_state.setObjectName("FieldLabel")
        v.addWidget(self.shader_state)

        self._shader_rows = []
        self._shader_icons = []
        self._shader_offset = 0
        self._shader_total = 0
        return w

    def _shader_mc(self):
        """光影包基本跨版本通用，这里不强绑当前 MC 版本，避免筛到 0 条。"""
        return ""

    def _shader_search(self, reset=False):
        if not hasattr(self, "shader_list"):
            return
        if reset:
            self._shader_offset = 0
        q = self.shader_edit.text().strip()
        self.shader_state.setText(i18n.tr("searching"))
        self.shader_list.clear()
        self._shader_rows = []
        self._shader_icons = []
        self._shw = self._track(ModrinthSearchWorker(
            "shader", self._shader_mc(), q, None, offset=self._shader_offset))
        self._shw.done.connect(self._on_shader_results)
        self._shw.failed.connect(
            lambda e: self.shader_state.setText(i18n.tr("search_failed_n", e)))
        self._shw.start()

    def _shader_flip(self, direction):
        new_offset = self._shader_offset + direction * modrinth.LIMIT
        if new_offset < 0:
            return
        if self._shader_total and new_offset >= self._shader_total:
            return
        self._shader_offset = new_offset
        self._shader_search(False)

    def _on_shader_results(self, hits, total):
        self.shader_list.clear()
        self._shader_rows = list(hits)
        self._shader_icons = []
        self._shader_total = total
        jobs = []
        for idx, hit in enumerate(hits):
            item = QListWidgetItem(self.shader_list)
            item.setSizeHint(QSize(0, 78))
            row, icon = self._shader_row(idx, hit)
            self.shader_list.addItem(item)
            self.shader_list.setItemWidget(item, row)
            self._shader_icons.append(icon)
            if hit.get("icon_url"):
                jobs.append((idx, hit["icon_url"]))
        page = self._shader_offset // modrinth.LIMIT + 1
        self.shader_page_label.setText(i18n.tr("page_n", page))
        self.shader_state.setText(i18n.tr("results_count", total, len(hits)))
        if jobs:
            iw = self._track(ModrinthIconWorker(jobs))
            iw.icon_ready.connect(self._on_shader_icon)
            iw.start()

    def _on_shader_icon(self, idx, data):
        icons = getattr(self, "_shader_icons", [])
        if idx >= len(icons):
            return
        pix = data if isinstance(data, QPixmap) else QPixmap()
        if not isinstance(data, QPixmap):
            if not pix.loadFromData(data):
                return
        icons[idx].setPixmap(pix.scaled(60, 60, Qt.KeepAspectRatio,
                                        Qt.SmoothTransformation))

    def _shader_row(self, idx, hit):
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(10, 8, 10, 8)
        h.setSpacing(12)

        icon = QLabel()
        icon.setFixedSize(60, 60)
        icon.setAlignment(Qt.AlignCenter)
        icon.setObjectName("ModIcon")
        icon.setText(i18n.tr("no_icon"))
        h.addWidget(icon)

        col = QVBoxLayout()
        col.setSpacing(4)
        title = QLabel(hit.get("title", ""))
        tf = QFont()
        tf.setBold(True)
        tf.setPointSize(11)
        title.setFont(tf)
        author = QLabel(i18n.tr("author_line",
                                hit.get("author", ""),
                                hit.get("downloads", 0)))
        author.setObjectName("FieldLabel")
        desc_text = hit.get("description", "") or ""
        desc = QLabel(desc_text)
        desc.setObjectName("FieldLabel")
        desc.setText(QFontMetrics(desc.font()).elidedText(
            desc_text, Qt.ElideRight, 430))
        col.addWidget(title)
        col.addWidget(author)
        col.addWidget(desc)
        h.addLayout(col, 1)

        b = QPushButton(i18n.tr("btn_download"))
        b.setObjectName("PrimaryButton")
        b.setFixedWidth(88)
        b.clicked.connect(lambda _checked=False, i=idx:
                          self._shader_download(i))
        h.addWidget(b)
        return row, icon

    def _shader_download(self, idx):
        if idx >= len(getattr(self, "_shader_rows", [])):
            return
        pid = self._shader_rows[idx].get("project_id")
        gd = self.config.get("game_dir") or ""
        dest = shaderpacks.shaderpacks_dir(gd)
        try:
            os.makedirs(dest, exist_ok=True)
        except Exception as e:
            self.shader_state.setText("创建 shaderpacks 目录失败：" + str(e))
            return
        self.shader_state.setText(i18n.tr("downloading"))
        self.shader_progress.setHidden(False)
        self.shader_progress.setValue(0)
        self._sdw = self._track(
            ModrinthDownloadWorker(pid, "", None, dest, project_type="shader"))
        self._sdw.log.connect(self.shader_state.setText)
        self._sdw.progress.connect(self._on_shader_progress)
        self._sdw.done.connect(self._on_shader_done)
        self._sdw.failed.connect(self._on_shader_failed)
        self._sdw.start()

    def _on_shader_progress(self, cur, total):
        if total:
            self.shader_progress.setMaximum(total)
            self.shader_progress.setValue(cur)

    def _on_shader_done(self, path):
        self.shader_progress.setHidden(True)
        self.shader_state.setText(i18n.tr("downloaded_n",
                                          os.path.basename(path)))
        self._refresh_shaders()
        self._log("光影已下载并装好：" + os.path.basename(path))
        self._ensure_shortcut()

    def _on_shader_failed(self, err):
        self.shader_progress.setHidden(True)
        self.shader_state.setText(i18n.tr("download_failed_n", err))

    # ---------- 存档 ----------
    def _tab_installed_packs(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)

        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(10)
        b_open = QPushButton(i18n.tr("open_packs_folder"))
        b_open.clicked.connect(self._open_packs_dir)
        b_refresh = QPushButton(i18n.tr("btn_refresh"))
        b_refresh.clicked.connect(self._refresh_packs)
        b_prev = QPushButton("预览选中")
        b_prev.setToolTip("看这个资源包的封面图，以及它现在是不是启用的")
        b_prev.clicked.connect(self._preview_pack)
        h.addWidget(b_open)
        h.addWidget(b_refresh)
        h.addWidget(b_prev)
        h.addStretch(1)
        v.addWidget(row)

        self.pack_drop = DropZone("把资源包 .zip 直接拖到这里导入")
        self.pack_drop.setMinimumHeight(74)
        self.pack_drop.filesDropped.connect(self._on_packs_dropped)
        v.addWidget(self.pack_drop)

        self.packs_list = QListWidget()
        self._attach_ctx_menu(self.packs_list, "pack")
        v.addWidget(self.packs_list, 1)
        self.packs_state = QLabel("")
        self.packs_state.setObjectName("FieldLabel")
        v.addWidget(self.packs_state)
        self._refresh_packs()
        return w

    def _on_packs_dropped(self, paths):
        gd = self.config.get("game_dir") or ""
        if not gd:
            self.packs_state.setText("先在设置里选好游戏目录")
            return
        dest_dir = os.path.join(gd, "resourcepacks")
        os.makedirs(dest_dir, exist_ok=True)
        ok = 0
        for p in paths:
            try:
                base = os.path.basename(str(p).rstrip("\\/"))
                if not base:
                    continue
                dest = os.path.join(dest_dir, base)
                if os.path.isdir(p):
                    shutil.copytree(p, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(p, dest)
                ok += 1
                self._log("已导入资源包：" + base)
            except Exception as e:
                self.packs_state.setText("导入失败：" + str(e))
        self._refresh_packs()
        if ok:
            self.packs_state.setText("已导入 %d 个资源包" % ok)

    def _refresh_packs(self):
        if not hasattr(self, "packs_list"):
            return
        self.packs_list.clear()
        gd = self.config.get("game_dir") or ""
        for name in mods.list_resourcepacks(gd):
            info = mods.resourcepack_info(gd, name)
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, 72))
            self.packs_list.addItem(item)
            self.packs_list.setItemWidget(
                item, self._local_row(info.get("icon"), name,
                                      i18n.tr("packs_line"), "包"))

    def _open_packs_dir(self):
        d = os.path.join(self.config.get("game_dir") or "", "resourcepacks")
        os.makedirs(d, exist_ok=True)
        platform_utils.open_path(d)

    def _preview_pack(self):
        """资源包大图预览：pack.png 按像素放大，顺手标出启用状态。"""
        row = self.packs_list.currentRow()
        gd = self.config.get("game_dir") or ""
        names = mods.list_resourcepacks(gd)
        if row < 0 or row >= len(names):
            self.packs_state.setText("先在列表里点一个资源包。")
            return
        name = names[row]
        info = mods.resourcepack_info(gd, name)
        enabled = False
        try:
            enabled = packs.pack_id(name) in (packs.read_enabled(gd) or [])
        except Exception:
            enabled = False
        dlg = QDialog(self)
        dlg.setWindowTitle("资源包预览 · " + name)
        v = QVBoxLayout(dlg)
        pic = QLabel()
        pic.setAlignment(Qt.AlignCenter)
        raw = info.get("icon")
        if raw:
            img = QImage()
            img.loadFromData(raw)
            if not img.isNull():
                pm = QPixmap.fromImage(img)
                pic.setPixmap(pm.scaled(max(1, pm.width() * 6),
                                        max(1, pm.height() * 6),
                                        Qt.KeepAspectRatio,
                                        Qt.FastTransformation))
            else:
                pic.setText("pack.png 读不出来")
        else:
            pic.setText("这个资源包没有 pack.png 封面")
        v.addWidget(pic)
        size_mb = 0.0
        try:
            p = os.path.join(gd, "resourcepacks", name)
            if os.path.isfile(p):
                size_mb = os.path.getsize(p) / 1048576.0
        except OSError:
            size_mb = 0.0
        lab = QLabel("大小 %.1f MB · %s"
                     % (size_mb, "已在游戏里启用" if enabled else "还没启用"))
        lab.setObjectName("FieldLabel")
        v.addWidget(lab)
        foot = QHBoxLayout()
        foot.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.clicked.connect(dlg.accept)
        foot.addWidget(b_close)
        v.addLayout(foot)
        dlg.exec_()

    def _worlds_panel(self):
        """存档管理面板：放版本详情页右栏（原来的「模组与资源-存档」页签）。"""
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)

        r1 = QHBoxLayout()
        r1.setContentsMargins(0, 0, 0, 0)
        r1.setSpacing(8)
        b_folder = QPushButton("导入存档文件夹")
        b_folder.clicked.connect(lambda: self._import_world("folder"))
        b_zip = QPushButton("导入存档 zip")
        b_zip.clicked.connect(lambda: self._import_world("zip"))
        b_open = QPushButton(i18n.tr("open_saves_folder"))
        b_open.clicked.connect(self._open_saves_dir)
        r1.addWidget(b_folder)
        r1.addWidget(b_zip)
        r1.addWidget(b_open)
        r1.addStretch(1)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        r2.setContentsMargins(0, 0, 0, 0)
        r2.setSpacing(8)
        b_dp = QPushButton("存档数据包")
        b_dp.clicked.connect(self._manage_datapacks)
        b_struct = QPushButton("导入结构 .nbt")
        b_struct.clicked.connect(self._import_structure)
        r2.addWidget(b_dp)
        r2.addWidget(b_struct)
        r2.addStretch(1)
        v.addLayout(r2)

        self.world_drop = DropZone(
            "把存档 zip / 文件夹拖到这里装存档；把 .nbt 结构拖到这里装进当前选中的存档")
        self.world_drop.setMinimumHeight(64)
        self.world_drop.filesDropped.connect(self._on_worlds_dropped)
        v.addWidget(self.world_drop)

        urow = QHBoxLayout()
        urow.setContentsMargins(0, 0, 0, 0)
        urow.setSpacing(8)
        self.world_url_edit = QLineEdit()
        self.world_url_edit.setPlaceholderText(
            "粘贴存档下载直链（http/https 的 .zip）")
        self.world_url_edit.returnPressed.connect(self._download_world_url)
        b_url = QPushButton("从链接下载存档")
        b_url.setObjectName("PrimaryButton")
        b_url.clicked.connect(self._download_world_url)
        urow.addWidget(self.world_url_edit, 1)
        urow.addWidget(b_url)
        v.addLayout(urow)

        self.worlds_progress = QProgressBar()
        self.worlds_progress.setHidden(True)
        self.worlds_progress.setFormat("下载存档")
        v.addWidget(self.worlds_progress)

        self.worlds_list = QListWidget()
        self._attach_ctx_menu(self.worlds_list, "world")
        v.addWidget(self.worlds_list, 1)

        self.worlds_state = QLabel("")
        self.worlds_state.setObjectName("FieldLabel")
        v.addWidget(self.worlds_state)
        self._refresh_worlds()
        return w

    def _download_world_url(self):
        url = self.world_url_edit.text().strip()
        if not url:
            self.worlds_state.setText("先粘贴一个存档下载链接（.zip）")
            return
        if not url.lower().startswith(("http://", "https://")):
            self.worlds_state.setText("链接要以 http:// 或 https:// 开头")
            return
        self.worlds_state.setText("开始下载存档......")
        self.worlds_progress.setHidden(False)
        self.worlds_progress.setValue(0)
        self._uww = self._track(
            WorldUrlWorker(url, self.config.get("game_dir") or ""))
        self._uww.log.connect(lambda m: self.worlds_state.setText(m))
        self._uww.progress.connect(self._on_world_url_progress)
        self._uww.done.connect(self._on_world_url_done)
        self._uww.failed.connect(self._on_world_url_failed)
        self._uww.start()

    def _on_world_url_progress(self, cur, total):
        if total:
            self.worlds_progress.setMaximum(total)
            self.worlds_progress.setValue(cur)

    def _on_world_url_done(self, name):
        self.worlds_progress.setHidden(True)
        self.worlds_state.setText("存档已装好：" + name)
        self._log("存档已下载并装好：" + name)
        self.world_url_edit.clear()
        self._refresh_worlds()
        self._ensure_shortcut()

    def _on_world_url_failed(self, err):
        self.worlds_progress.setHidden(True)
        self.worlds_state.setText("存档下载失败：" + err)

    def _import_world(self, mode):
        if mode == "folder":
            p = QFileDialog.getExistingDirectory(self, i18n.tr("choose_world_folder"))
        else:
            p, _ = QFileDialog.getOpenFileName(
                self, i18n.tr("choose_world_zip"), "", i18n.tr("world_zip_filter"))
        if not p:
            return
        self.worlds_state.setText(i18n.tr("importing"))
        self._iw = self._track(WorldImportWorker(p, self.config.get("game_dir")))
        self._iw.log.connect(lambda m: self.worlds_state.setText(m))
        self._iw.done.connect(self._on_world_done)
        self._iw.failed.connect(
            lambda e: self.worlds_state.setText(i18n.tr("import_failed_n", e)))
        self._iw.start()

    def _on_world_done(self, name):
        self.worlds_state.setText(i18n.tr("imported_n", name))
        self._refresh_worlds()

    def _refresh_worlds(self):
        if not hasattr(self, "worlds_list"):
            return
        self.worlds_list.clear()
        gd = self.config.get("game_dir")
        if not gd:
            return
        for name in worlds.list_saves(gd):
            icon = worlds.world_icon(gd, name)
            item = QListWidgetItem()
            item.setSizeHint(QSize(0, 72))
            self.worlds_list.addItem(item)
            self.worlds_list.setItemWidget(
                item, self._local_row(icon, name, i18n.tr("saves_line"), "档"))

    def _selected_world(self):
        gd = self.config.get("game_dir")
        if not gd or not hasattr(self, "worlds_list"):
            return None
        names = worlds.list_saves(gd)
        row = self.worlds_list.currentRow()
        if row < 0 or row >= len(names):
            return None
        return names[row]

    def _manage_datapacks(self):
        name = self._selected_world()
        if not name:
            self.worlds_state.setText("先在下面的列表里点选一个存档，再点「存档数据包」")
            return
        gd = self.config.get("game_dir")
        save_path = os.path.join(worlds.saves_dir(gd), name)

        dlg = QDialog(self)
        dlg.setWindowTitle("存档数据包：" + name)
        dlg.resize(660, 470)
        v = QVBoxLayout(dlg)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(10)

        tip = QLabel("数据包放进这个存档后，进游戏用 /datapack list 能看到；"
                     "支持 .zip 或数据包文件夹。")
        tip.setObjectName("FieldLabel")
        v.addWidget(tip)

        lst = QListWidget()
        v.addWidget(lst, 1)
        state = QLabel("")
        state.setObjectName("FieldLabel")
        v.addWidget(state)

        brow = QWidget()
        bh = QHBoxLayout(brow)
        bh.setContentsMargins(0, 0, 0, 0)
        bh.setSpacing(8)
        b_zip = QPushButton("导入 zip")
        b_dir = QPushButton("导入文件夹")
        b_open = QPushButton("打开目录")
        b_del = QPushButton("删除选中")
        b_close = QPushButton("关闭")
        for b in (b_zip, b_dir, b_open, b_del, b_close):
            bh.addWidget(b)
        bh.addStretch(1)
        v.addWidget(brow)

        def refresh():
            lst.clear()
            items = datapacks.list_datapacks(save_path)
            for it in items:
                if it["size"] >= 1048576:
                    size = "%.1f MB" % (it["size"] / 1048576.0)
                else:
                    size = "%.0f KB" % (it["size"] / 1024.0)
                label = "%s  |  %s" % (it["name"], size)
                if it.get("desc"):
                    label += "  |  " + str(it["desc"])[:60]
                if it.get("pack_format"):
                    label += "  |  format " + str(it["pack_format"])
                row = QListWidgetItem(label)
                row.setData(Qt.UserRole, it["name"])
                lst.addItem(row)
            state.setText("共 %d 个数据包" % len(items) if items
                          else "这个存档还没有数据包")

        def do_import(mode):
            if mode == "zip":
                p, _ = QFileDialog.getOpenFileName(
                    dlg, "选择数据包 zip", "", "数据包 (*.zip)")
            else:
                p = QFileDialog.getExistingDirectory(dlg, "选择数据包文件夹")
            if not p:
                return
            try:
                got = datapacks.install_pack(save_path, p)
                state.setText("已加入：" + got)
                self._log("存档 %s 加入数据包 %s" % (name, got))
            except Exception as e:
                state.setText("导入失败：" + str(e))
            refresh()

        def do_del():
            it = lst.currentItem()
            if it is None:
                state.setText("先在列表里选中要删的数据包")
                return
            nm = it.data(Qt.UserRole)
            ok = QMessageBox.question(
                dlg, "删除数据包",
                "确定把「%s」从这个存档里删掉吗？" % nm,
                QMessageBox.Yes | QMessageBox.No)
            if ok != QMessageBox.Yes:
                return
            try:
                datapacks.remove_pack(save_path, nm)
                state.setText("已删除：" + nm)
            except Exception as e:
                state.setText("删除失败：" + str(e))
            refresh()

        b_zip.clicked.connect(lambda: do_import("zip"))
        b_dir.clicked.connect(lambda: do_import("dir"))
        b_open.clicked.connect(lambda: datapacks.open_dir(save_path))
        b_del.clicked.connect(do_del)
        b_close.clicked.connect(dlg.accept)
        refresh()
        dlg.exec_()

    def _import_structure(self):
        name = self._selected_world()
        if not name:
            self.worlds_state.setText("先在下面的列表里点选一个存档，再导入结构")
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, "导入结构文件", "", "结构文件 (*.nbt)")
        if not paths:
            return
        self._do_import_structures(name, paths)

    def _do_import_structures(self, world_name, paths):
        gd = self.config.get("game_dir")
        save_path = os.path.join(worlds.saves_dir(gd), world_name)
        try:
            got = structures.install_structures(save_path, paths, self._log)
            self.worlds_state.setText(
                "已把 %d 个结构导入「%s」：%s"
                % (len(got), world_name, "、".join(got[:3])))
        except Exception as e:
            self.worlds_state.setText("结构导入失败：" + str(e))

    def _on_worlds_dropped(self, paths):
        gd = self.config.get("game_dir")
        if not gd:
            self.worlds_state.setText("先在设置里选好游戏目录")
            return
        nbts = [p for p in paths if str(p).lower().endswith(".nbt")]
        others = [p for p in paths if not str(p).lower().endswith(".nbt")]
        if nbts:
            name = self._selected_world()
            if not name:
                self.worlds_state.setText(
                    "拖进来的是 .nbt 结构，请先在列表里点选一个存档")
            else:
                self._do_import_structures(name, nbts)
        for p in others:
            self.worlds_state.setText("正在导入存档：" + os.path.basename(p))
            self._iw = self._track(WorldImportWorker(p, gd))
            self._iw.log.connect(lambda m: self.worlds_state.setText(m))
            self._iw.done.connect(self._on_world_done)
            self._iw.failed.connect(
                lambda e: self.worlds_state.setText("导入失败：" + str(e)))
            self._iw.start()

    def _open_saves_dir(self):
        path = worlds.saves_dir(self.config.get("game_dir") or "")
        platform_utils.open_path(path)

    # ---------- 小工具 ----------
    def _field_label(self, text):
        lab = QLabel(text)
        lab.setObjectName("FieldLabel")
        return lab

    def _row(self, *widgets):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        for x in widgets:
            h.addWidget(x)
        h.addStretch(1)
        return w

    def _log(self, msg):
        self.log_view.append(msg)
        lines = getattr(self, "_log_lines", None)
        if lines is None:
            lines = self._log_lines = []
        lines.append(str(msg))
        if len(lines) > 240:
            del lines[:-240]

    def _is_msa_mode(self):
        return self.radio_msa.isChecked()

    def _current_mirror(self):
        return "bmcl" if self.radio_bmcl.isChecked() else "official"

    # ---------- 正版账号 ----------
    def _sync_account_ui(self):
        if not hasattr(self, "input_name"):
            return
        msa = self.radio_msa.isChecked()
        third = self.radio_third.isChecked()
        acct = self.ms_account
        acct_type = (acct or {}).get("type")
        # 离线：只显示昵称输入
        self.input_name.setVisible(not msa and not third)
        # 正版模式始终给"登录"按钮，方便换号/重登
        self.btn_login.setVisible(msa)
        self.msa_state.setVisible(msa or third)
        self.third_panel.setVisible(third)
        self.btn_logout.setVisible(
            (msa and acct_type == "msa")
            or (third and acct_type == "third_party"))
        if msa:
            if acct_type == "msa":
                self.msa_state.setText(i18n.tr(
                    "logged_in_n", acct["name"], acct["uuid"]))
            else:
                self.msa_state.setText(i18n.tr("not_logged_in"))
        elif third:
            if acct_type == "third_party":
                self.msa_state.setText(i18n.tr(
                    "logged_in_n", acct["name"], acct["uuid"]))
            else:
                self.msa_state.setText(i18n.tr("not_logged_in"))

    def _login_msa(self):
        self.btn_login.setEnabled(False)
        self.msa_state.setText(i18n.tr("ms_device_wait"))
        self._log(i18n.tr("start_login"))
        self.device_worker = self._track(DeviceLoginWorker())
        self.device_worker.log.connect(self._log)
        self.device_worker.code_ready.connect(self._on_device_code)
        self.device_worker.success.connect(self._on_login_success)
        self.device_worker.failed.connect(self._on_login_failed)
        self.device_worker.start()

    def _on_device_code(self, user_code, uri):
        QApplication.clipboard().setText(user_code)
        self.msa_state.setText(i18n.tr("ms_device_code", user_code))
        self._log(i18n.tr("ms_device_log", user_code, uri))
        box = QMessageBox(self)
        box.setWindowTitle(i18n.tr("ms_device_title"))
        box.setText(i18n.tr("ms_device_body", user_code))
        box.setInformativeText(i18n.tr("ms_device_tip", uri))
        box.setStandardButtons(QMessageBox.Ok)
        box.setWindowModality(Qt.NonModal)
        box.show()
        self._code_box = box   # 保持引用，避免对话框被回收

    def _ask_login_code(self):
        text, ok = QInputDialog.getMultilineText(
            self, i18n.tr("ms_code_title"), i18n.tr("ms_code_body"))
        self.login_worker.provide_code(text if ok else "")

    def _on_login_success(self, account):
        self.ms_account = account
        self.btn_login.setEnabled(True)
        self.config.set("account_mode", "msa")
        self.config.save()
        self._log(i18n.tr("login_success_log") + account["name"])
        self._sync_account_ui()
        QMessageBox.information(
            self, i18n.tr("login_success_title"),
            i18n.tr("login_success_n", account["name"]))

    def _on_login_failed(self, err):
        self.btn_login.setEnabled(True)
        self._log(i18n.tr("login_failed_title") + " " + err)
        QMessageBox.warning(self, i18n.tr("login_failed_title"), err)

    def _logout_msa(self):
        auth.logout()
        self.ms_account = None
        self._log(i18n.tr("logout_done"))
        self._sync_account_ui()

    def _login_third(self):
        api = yggdrasil.normalize_api(self.input_third_api.currentText())
        user = self.input_third_user.text().strip()
        pwd = self.input_third_pass.text()
        if not api or not user or not pwd:
            QMessageBox.warning(self, i18n.tr("tip"),
                                i18n.tr("fill_all_fields"))
            return
        from .captcha_dialog import require_human
        if not require_human(self, "登录"):
            return
        self.input_third_api.setEditText(api)
        self.config.set("third_api", api)
        self.config.save()
        self.btn_third_login.setEnabled(False)
        self.third_worker = self._track(ThirdLoginWorker(api, user, pwd))
        self.third_worker.log.connect(self._log)
        self.third_worker.success.connect(self._on_third_success)
        self.third_worker.failed.connect(self._on_third_failed)
        self.third_worker.start()

    def _open_third_register(self):
        """在第三方服务器上注册并直接登录（自建服务器也能用）。"""
        from .third_dialog import ThirdAuthDialog
        api = yggdrasil.normalize_api(self.input_third_api.currentText())
        if not self.input_third_api.currentText().strip():
            api = self.config.get("third_api") or api
        dlg = ThirdAuthDialog(self, api=api,
                              user=self.input_third_user.text().strip())
        if dlg.exec_() != QDialog.Accepted or not dlg.acct:
            return
        self.input_third_api.setEditText(dlg.acct.get("api") or api)
        self.config.set("third_api", dlg.acct.get("api") or api)
        try:
            self.config.save()
        except Exception:
            pass
        self._on_third_success(dlg.acct)

    def _on_third_server_pick(self, _idx=None):
        """选了下拉里的服务商就自动把地址填进去。"""
        url = self.input_third_api.currentData() or ""
        if url:
            self.input_third_api.setEditText(url)
        else:
            self.input_third_api.setEditText("")

    def _on_third_success(self, account):
        self.ms_account = account
        self.btn_third_login.setEnabled(True)
        self.config.set("account_mode", "third_party")
        self.config.save()
        self._log(i18n.tr("login_success_log") + account["name"])
        self._sync_account_ui()
        QMessageBox.information(
            self, i18n.tr("login_success_title"),
            i18n.tr("login_success_n", account["name"]))

    def _on_third_failed(self, err):
        self.btn_third_login.setEnabled(True)
        self._log(i18n.tr("login_failed_title") + " " + err)
        QMessageBox.warning(self, i18n.tr("login_failed_title"), err)

    # ---------- 版本 ----------
    def _load_versions(self):
        if not hasattr(self, "group_combo"):
            return
        self._start_version_worker(self._current_mirror(), False)

    def _start_version_worker(self, mirror, is_retry):
        self._log(i18n.tr("loading_versions", mirror))
        self.vw = self._track(VersionListWorker(mirror))
        self.vw.versions.connect(self._on_versions)

        def on_failed(err):
            alt = "official" if mirror == "bmcl" else "bmcl"
            if not is_retry:
                self._log(i18n.tr("source_failed", mirror, err, alt))
                self._start_version_worker(alt, True)
            else:
                self._log(i18n.tr("fetch_versions_failed") + err)

        self.vw.failed.connect(on_failed)
        self.vw.start()

    # 版本分组：正式版 / 快照 / 远古
    GROUPS = {
        "release": ("正式版", ("release",)),
        "snapshot": ("快照版", ("snapshot",)),
        "old": ("远古版", ("old_beta", "old_alpha")),
    }

    def _current_group(self):
        return self.group_combo.currentData()

    def _set_group(self, group):
        idx = self.group_combo.findData(group)
        if idx >= 0:
            self.group_combo.setCurrentIndex(idx)

    def _group_of_type(self, vtype):
        if vtype == "release":
            return "release"
        if vtype == "snapshot":
            return "snapshot"
        return "old"

    def _on_versions(self, versions):
        self.version_data = versions
        self._populate_browse_mc()
        self._log(i18n.tr("version_list_updated",
                          self._count(versions, "release"),
                          self._count(versions, "snapshot"),
                          self._count(versions, "old")))
        # 打开软件时：若上次版本已安装，切到「已有版本」并选中它
        last = self.config.get("last_version")
        if last and last in self._all_local_versions():
            self._set_group("local")
            self._refresh_version_list()
            self._select_version(last)
            QTimer.singleShot(0, self._java_follow_version)
            return
        for ver in versions:
            if ver.get("id") == last:
                self._set_group(self._group_of_type(ver.get("type")))
                self._refresh_version_list()
                self._select_version(last)
                QTimer.singleShot(0, self._java_follow_version)
                return
        self._refresh_version_list()
        QTimer.singleShot(0, self._java_follow_version)

    def _count(self, versions, group):
        return sum(1 for v in versions
                   if self._group_of_type(v.get("type")) == group)

    def _version_counts(self, versions):
        return i18n.tr("version_list_updated",
                       self._count(versions, "release"),
                       self._count(versions, "snapshot"),
                       self._count(versions, "old"))

    def _refresh_version_list(self, *_args):
        if not hasattr(self, "local_list"):
            return
        keyword = self.edit_version_filter.text().strip().lower()
        group = self._current_group()
        last = self.config.get("last_version")
        select = 0
        self.local_list.blockSignals(True)
        self.local_list.clear()

        if group == "local":
            items = self._all_local_versions()
            if keyword:
                items = [v for v in items if keyword in v.lower()]
            # 收藏的版本排在最前，名字前面加个星
            fav_ids = set()
            try:
                fav_ids = {it.get("id") for it in favorites.listing("version")}
            except Exception:
                fav_ids = set()
            if fav_ids:
                items = ([v for v in items if v in fav_ids]
                         + [v for v in items if v not in fav_ids])
            for i, vid in enumerate(items):
                kind = self._detect_loader_kind(vid)
                label = ("★ " if vid in fav_ids else "") + vid
                item = QListWidgetItem(self._badge_icon(kind), label)
                item.setData(Qt.UserRole, vid)   # 名字带星，选中时按真实 id 取
                tip = i18n.tr("local_version_n", vid,
                              loaders.LABELS[kind] if kind else i18n.tr("vanilla"))
                stat = self._launch_stat(vid)
                if stat:
                    tip += "\n上次启动：准备用了 %.1f 秒（%s）" % (
                        stat.get("sec") or 0, stat.get("at") or "")
                item.setToolTip(tip)
                self.local_list.addItem(item)
                if vid == last:
                    select = i
        else:
            versions = getattr(self, "version_data", None)
            if versions:
                types = self.GROUPS[group][1]
                items = [v for v in versions if v.get("type") in types]
                if keyword:
                    items = [v for v in items if keyword in v["id"].lower()]
                items.sort(key=lambda v: v.get("releaseTime") or v.get("time") or "",
                           reverse=True)
                for i, ver in enumerate(items):
                    self.local_list.addItem(QListWidgetItem(ver["id"]))
                    if ver.get("id") == last:
                        select = i
        self.local_list.blockSignals(False)
        if self.local_list.count():
            self.local_list.setCurrentRow(select)
        self._update_install_state()

    def _all_local_versions(self):
        """本地 versions 目录下所有含有效 json 的版本。"""
        game_dir = self.config.get("game_dir")
        vdir = os.path.join(game_dir or "", "versions")
        if not os.path.isdir(vdir):
            return []
        result = []
        for name in os.listdir(vdir):
            if os.path.exists(os.path.join(vdir, name, name + ".json")):
                result.append(name)
        return sorted(result, key=lambda s: s.lower(), reverse=True)

    def _local_loader_versions(self):
        """扫描本地带 inheritsFrom 的版本目录（即各加载器安装出来的版本）。"""
        game_dir = self.config.get("game_dir")
        vdir = os.path.join(game_dir or "", "versions")
        if not os.path.isdir(vdir):
            return []
        result = []
        for name in os.listdir(vdir):
            path = os.path.join(vdir, name, name + ".json")
            if not os.path.exists(path):
                continue
            try:
                with open(path, "r", encoding="utf-8") as f:
                    vj = json.load(f)
                if vj.get("inheritsFrom"):
                    result.append(name)
            except Exception:
                pass
        return sorted(result, key=lambda s: s.lower(), reverse=True)

    def _selected_version_id(self):
        item = self.local_list.currentItem()
        if not item:
            return ""
        # 本地版本项的真实 id 存在 UserRole（显示名可能带收藏星标）
        return item.data(Qt.UserRole) or item.text()

    def _version_json_path(self, vid):
        return os.path.join(self.config.get("game_dir"), "versions", vid, vid + ".json")

    def _is_installed(self, vid):
        json_path = self._version_json_path(vid)
        if not os.path.exists(json_path):
            return False
        return not launcher.check_ready(json_path, self.config.get("game_dir"))

    def _update_install_state(self):
        vid = self._selected_version_id()
        if not vid:
            self.install_state.setText("该分组下暂无版本")
            self.btn_primary.setText("下载并启动")
            self._sync_loader_lock()
            return
        if self._is_installed(vid):
            self.install_state.setText("该版本已安装，可直接启动")
            self.btn_primary.setText("启动游戏")
        else:
            self.install_state.setText("该版本尚未安装，点击按钮将先下载安装")
            self.btn_primary.setText("下载并启动")
        self._sync_loader_lock()

    # ---------- 主按钮 ----------
    def _on_primary(self):
        w = getattr(self, "install_worker", None)
        if w is not None:
            try:
                if w.isRunning():
                    w.cancel()
                    return
            except RuntimeError:
                # 同上：Qt 已经把 worker 回收了，就当它没在跑
                self.install_worker = None

        vid = self._selected_version_id()
        if not vid:
            # 手机端或热键触发时，界面可能没选中任何版本；退到上次用的那个，
            # 否则这里直接 return，手机上看着就是「点了启动没反应」。
            last = (self.config.get("last_version") or "").strip()
            if last and self._is_installed(last):
                vid = last
                try:
                    self._select_version(last)
                except Exception:
                    pass
        if not vid:
            self._load_versions()
            self._set_mobile_notice("没有可启动的版本，先在电脑上装一个，"
                                    "或者在手机上点「切到这个」选一个已装版本")
            return

        # 记录下载时选定的加载器，下载完成后按此链式安装
        kind = self.combo_loader_kind.currentData()
        lver = self.combo_loader_ver.currentText()
        if kind and not lver:
            QMessageBox.warning(self, "提示", "加载器版本还在加载，请稍候再点")
            return

        # 未安装时校验用户起的名字；已安装版本直接用现有名字
        if not self._is_installed(vid):
            name, err = self._validate_instance_name(
                self.input_instance_name.text())
            if err:
                QMessageBox.warning(self, "提示", err)
                return
        else:
            name = vid

        account = self._resolve_account()
        if account is None:
            return

        self._pending_kind = kind
        self._pending_ver = lver
        self._pending_name = name
        self.config.set("last_version", vid)
        self.config.set("account_mode", "msa" if self._is_msa_mode() else "offline")
        self.config.save()

        if not self._is_installed(vid):
            self._start_install(vid)
        else:
            self._start_game(vid, account)

    def _resolve_account(self):
        if self._is_msa_mode():
            if not self.ms_account \
                    or self.ms_account.get("type") != "msa":
                QMessageBox.warning(self, i18n.tr("tip"),
                                    i18n.tr("not_logged_in"))
                self._login_msa()
                return None
            try:
                self.ms_account = auth.ensure_valid(self.ms_account)
            except Exception as e:
                QMessageBox.warning(self, i18n.tr("login_failed_title"),
                                    str(e))
                self._logout_msa()
                return None
            return self.ms_account
        if self.radio_third.isChecked():
            if not self.ms_account \
                    or self.ms_account.get("type") != "third_party":
                QMessageBox.warning(self, i18n.tr("tip"),
                                    i18n.tr("not_logged_in"))
                return None
            return self.ms_account
        username = self.input_name.text().strip()
        if not username:
            QMessageBox.warning(self, i18n.tr("tip"),
                                i18n.tr("empty_name"))
            return None
        self.config.set("username", username)
        return launcher.offline_account(username)

    def _start_install(self, vid):
        url = None
        for ver in getattr(self, "version_data", []) or []:
            if ver.get("id") == vid:
                url = ver.get("url")
                break
        if not url:
            # 本地加载器版本等没有清单 URL 的情况，安装器会自行处理
            url = ""
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.progress.setFormat("下载中 %p%（%v/%m）")
        self.btn_primary.setText("取消安装")
        self._log("开始安装 " + vid)
        self.install_worker = self._track(InstallWorker(
            self.config.get("game_dir"), self._current_mirror(), vid, url
        ))
        self.install_worker.log.connect(self._log)
        self.install_worker.progress.connect(self._on_progress)
        self.install_worker.finished_ok.connect(self._on_installed)
        self.install_worker.failed.connect(self._on_install_failed)
        self.install_worker.start()

    def _on_progress(self, cur, total):
        if total:
            self.progress.setMaximum(total)
            self.progress.setValue(cur)

    def _ensure_shortcut(self):
        """下载/安装完成后立刻确保桌面有快捷方式（已存在就跳过）。"""
        try:
            from core import shortcut
            path = shortcut.ensure_desktop_shortcut()
            if path:
                self._log("桌面快捷方式已就绪：" + path)
        except Exception as e:
            self._log("桌面快捷方式创建失败：" + str(e))

    def _on_installed(self, json_path):
        self.progress.setVisible(False)
        self._log("游戏本体安装完成：" + self._selected_version_id())
        if self.config.get("game_options_apply") and self.config.get("game_options"):
            self._apply_game_options(self.config.get("game_dir"))
        self._ensure_shortcut()
        self._update_latest_btn()
        self._ensure_java_path()
        kind = getattr(self, "_pending_kind", None)
        ver = getattr(self, "_pending_ver", None)
        if kind:
            # 下载时选了加载器：链式安装，完成后再启动（改名在加载器完成后处理）
            self._start_chained_loader(kind, self._selected_version_id(), ver)
            return
        # 纯净版：按用户起的名字改名后再启动
        vid = self._selected_version_id()
        try:
            vid = self._rename_installed_version(
                vid, getattr(self, "_pending_name", "") or vid)
        except Exception as e:
            self._log("改名失败，保留原名称：" + str(e))
        self._pending_name = None
        self.btn_primary.setText("启动游戏")
        self._refresh_version_list()
        self._select_version(vid)
        account = self._resolve_account()
        if account:
            self._start_game(vid, account)

    def _on_install_failed(self, err):
        self.progress.setVisible(False)
        self.btn_primary.setText("重试")
        self._log("安装失败：" + err)

    def _ensure_game_language(self):
        """游戏内语言：模组名 / 道具名都靠 options.txt 的 lang 决定。

        设了"游戏内语言"就每次启动前强制写成它；没设就只在 options.txt 不存在时
        用启动器语言，游戏里自己改的不动。
        """
        gd = self.config.get("game_dir")
        if not gd:
            return
        opts = os.path.join(gd, "options.txt")
        forced = self.config.get("game_language") or ""
        if not forced and os.path.exists(opts):
            return
        code = forced or i18n.game_lang_code(self.config.get("language"))
        if not code:
            return
        try:
            lines = []
            if os.path.exists(opts):
                with open(opts, "r", encoding="utf-8", errors="replace") as f:
                    lines = [ln.rstrip("\r\n") for ln in f
                             if ln.strip() and not ln.startswith("lang:")]
            lines.append("lang:%s" % code)
            os.makedirs(gd, exist_ok=True)
            with open(opts, "w", encoding="utf-8", newline="\n") as f:
                f.write("\n".join(lines) + "\n")
            self._log("游戏内语言：" + code + ("（按设置固定）" if forced else ""))
        except Exception as e:
            self._log("写入游戏语言失败：" + str(e))

    def _safe_memory(self, game_dir, vid):
        """内存给太多反而打不开：按物理内存 60% 和「当前可用」双重封顶。"""
        try:
            mem = int(self.config.get("memory_mb") or 0)
        except Exception:
            mem = 0
        total = memrec.total_ram_mb()
        cap = min(int(total * 0.6), 12288) if total else 12288
        avail = memrec.avail_ram_mb()
        if avail:
            # 别的程序占着的时候，理论上限没有意义：只剩 300M 时给 6G 必崩
            cap = min(cap, int(avail * 0.75))
        if mem and mem <= cap:
            return mem
        try:
            new = min(memrec.recommend(game_dir, vid)[0], max(cap, 1024))
        except Exception:
            new = min(4096, max(cap, 1024))
        self._log("内存设置 %d MB 超出安全上限（总 %d MB，当前可用 %d MB），"
                  "已自动降为 %d MB" % (mem or 0, total, avail, new))
        self.config.set("memory_mb", new)
        try:
            self.config.save()
        except Exception:
            pass
        return new

    def _check_mem_headroom(self, need_mb):
        """可用内存连 -Xmx 都盖不住时，Java 会在进主菜单前 native malloc 失败直接崩。

        hs_err 里的样子是「insufficient memory / Chunk::new」，
        玩家看到的只是「游戏一打开就闪退」，很容易误会成模组或服务器的问题。
        """
        avail = memrec.avail_ram_mb()
        if not avail or avail >= need_mb + 900:
            return True
        ans = QMessageBox.question(
            self, "内存不够",
            "现在系统只剩 %d MB 可用内存，游戏这次要 %d MB。\n"
            "这样启动大概率在加载界面就崩（跟模组、服务器地址都没关系）。\n\n"
            "先关掉这些再启动：浏览器、QQ/微信、剪映、录屏、游戏加速器。\n"
            "已经关完了就点「是」，我会把内存降到能用的档位继续启动。"
            % (avail, need_mb),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        return ans == QMessageBox.Yes

    def _launch_stat(self, vid):
        """上次启动这个版本准备了多久（存在 config 里，只做展示）。"""
        try:
            stats = self.config.get("launch_stats") or {}
            if isinstance(stats, dict):
                return stats.get(vid)
        except Exception:
            pass
        return None

    def _record_launch_stat(self, vid, sec):
        try:
            stats = self.config.get("launch_stats") or {}
            if not isinstance(stats, dict):
                stats = {}
            stats[vid] = {"sec": round(float(sec), 1),
                          "at": time.strftime("%Y-%m-%d %H:%M")}
            if len(stats) > 30:
                keep = sorted(stats.items(),
                              key=lambda kv: (kv[1] or {}).get("at") or "",
                              reverse=True)[:30]
                stats = dict(keep)
            self.config.set("launch_stats", stats)
            self.config.save()
        except Exception as e:
            self._log("记启动耗时失败：%s" % e)

    def _start_game(self, vid, account):
        _t0 = time.time()
        json_path = self._version_json_path(vid)
        if not os.path.exists(json_path):
            QMessageBox.warning(self, "提示", "版本信息缺失，请先下载安装")
            return

        # 0. 已经有一个游戏在跑：默认不允许再开，除非设置里开了多开
        running = self.launch_proc is not None and self.launch_proc.poll() is None
        if running and not self.config.get("multi_instance"):
            ans = QMessageBox.question(
                self, "已经在运行",
                "当前已经有一个游戏进程在运行。\n"
                "设置里可以打开「允许多开同一个版本」。\n\n仍然再开一个吗？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans != QMessageBox.Yes:
                return

        # 0.5 启动前自动备份存档（只复制，不改原存档）
        if self.config.get("auto_backup"):
            try:
                backup.backup_all(self.config.get("game_dir"),
                                  int(self.config.get("backup_keep") or 5),
                                  self._log)
            except Exception as e:
                self._log("自动备份存档失败：" + str(e))

        self._ensure_game_language()

        # 0.8 启动前扫一遍模组：缺前置 / 装两份 / 版本不对，先提醒再启动
        if self.config.get("mod_precheck") is not False:
            try:
                res = modconflict.scan(self.config.get("game_dir") or "",
                                       (vid or "").split("-")[0])
                issues = res.get("issues") or []
                errs = [i for i in issues if i.get("level") == "error"]
                if errs:
                    self._log("启动前模组检查：%d 条会让游戏直接崩的问题"
                              % len(errs))
                    detail = "\n".join("· " + (i.get("title") or "")
                                       for i in errs[:6])
                    more = ("\n……还有 %d 条" % (len(errs) - 6)) if len(errs) > 6 else ""
                    ans = QMessageBox.question(
                        self, "模组有问题",
                        "启动前扫到 %d 个会让游戏直接崩的问题：\n%s%s\n\n"
                        "工具页的「模组冲突」能看到完整说明。现在照旧启动吗？"
                        % (len(errs), detail, more),
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if ans != QMessageBox.Yes:
                        self._log("按提示取消了这次启动")
                        return
                elif issues:
                    self._log("模组检查：%d 条小问题（不影响启动）" % len(issues))
            except Exception as e:
                self._log("启动前模组检查没跑成：%s" % e)

        # 1. 完整性自检，缺文件就先补齐再启动（这是之前崩溃的主因）
        problems = launcher.check_ready(json_path, self.config.get("game_dir"))
        if problems:
            self._log("安装不完整：" + "；".join(problems[:3]))
            QMessageBox.warning(
                self, "安装不完整",
                "该版本缺少 %d 个文件，先自动补全后再启动。\n\n%s"
                % (len(problems), "\n".join(problems[:5])))
            self._start_install(vid)
            return

        # 2. 选匹配的 Java（全自动：按这个版本要的主版本精确挑，缺了就自己下）
        game_dir = self.config.get("game_dir")
        required = launcher.required_java_major(json_path)
        if not required:
            required = java_utils.version_major(vid)
        java = self._ensure_java_path(required)
        if not java or not os.path.exists(java):
            if required:
                self._pending_launch_vid = vid
                self._log("这个版本需要 Java %d，本机没有，正在自动下载......"
                          % required)
                return
            QMessageBox.warning(self, "提示",
                                "未找到合适的 Java，请在设置中指定 %s 路径"
                                % platform_utils.java_binary_name())
            self.stack.setCurrentIndex(1)
            return

        self._log("使用 Java：%s（Java %d）" % (java, java_utils.java_major(java)))

        picked_major = java_utils.java_major(java)
        if (required and picked_major and picked_major > required
                and self.config.get("java_auto") is False):
            ans = QMessageBox.question(
                self, "Java 版本偏高",
                "该版本要求 Java %d，本机只找到 Java %d。\n"
                "高版本 Java 跑旧版本游戏经常直接崩溃。\n\n仍要尝试启动吗？"
                % (required, picked_major),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans != QMessageBox.Yes:
                self._log("已取消启动：Java 版本与版本要求不符")
                return

        log_path = os.path.join(game_dir, "logs", "simplemc-%s.log" % vid)
        mem_mb = self._safe_memory(game_dir, vid)
        if not self._check_mem_headroom(mem_mb):
            self._log("已取消启动：可用内存不足")
            return
        try:
            proc = launcher.launch(
                json_path, game_dir, java,
                mem_mb, account,
                self._extra_jvm(), extra_game=self._auto_join_arg(vid),
                log_path=log_path,
            )
            self._log("游戏进程已启动 (PID %d)，日志：%s" % (proc.pid, log_path))
            self._record_launch_stat(vid, time.time() - _t0)
            self._announce_presence("game")
            self._start_launch_progress(proc, log_path)
            QTimer.singleShot(8000, lambda: self._check_process(proc, log_path))
        except Exception as e:
            QMessageBox.critical(self, "启动失败", str(e))

    def _vram_free_mb(self):
        """NVIDIA 显卡当前剩余显存（MB）。查不到就返回 None，不当错误处理。"""
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=memory.free",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5,
                creationflags=getattr(platform_utils, "no_window_flags", lambda: 0)())
            vals = []
            for line in (out.stdout or "").splitlines():
                s = line.strip()
                if s.isdigit():
                    vals.append(int(s))
            return min(vals) if vals else None
        except Exception:
            return None

    def _check_vram(self):
        """显存不够就提醒：4G 卡上别的程序把显存吃满，游戏会一进去就崩。"""
        free = self._vram_free_mb()
        if free is None or free >= 1200:
            return True
        ans = QMessageBox.question(
            self, "显存不够",
            "显卡只剩 %d MB 显存，游戏很可能一进去就崩"
            "（GL_OUT_OF_MEMORY）。\n\n"
            "建议先关掉占显存的程序：浏览器、QQ、小红书、剪映、录屏、游戏加速器。\n"
            "也可以把游戏里的渲染距离调到 8 以下。\n\n仍要启动吗？" % free,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        return ans == QMessageBox.Yes

    def _do_launch(self, vid, java, account, extra_game=""):
        if not self._check_vram():
            self._log("已取消启动：显存不足")
            return
        game_dir = self.config.get("game_dir")
        json_path = self._version_json_path(vid)
        log_path = os.path.join(game_dir, "logs", "simplemc-%s.log" % vid)
        try:
            mem_mb = self._safe_memory(game_dir, vid)
            if not self._check_mem_headroom(mem_mb):
                self._log("已取消启动：可用内存不足")
                return
            proc = launcher.launch(
                json_path, game_dir, java,
                mem_mb, account,
                self._extra_jvm(),
                # 显式指定了要进的服务器，就别再拼设置里的「自动加入」：
                # 两套直连参数同时塞进去，客户端会按后一个走，等于点哪都不对
                extra_game=(extra_game or self._auto_join_arg(vid)).strip(),
                log_path=log_path)
            self._log("游戏进程已启动 (PID %d)" % proc.pid)
            self._announce_presence("game")
            self._start_launch_progress(proc, log_path)
            QTimer.singleShot(8000, lambda: self._check_process(proc, log_path))
        except Exception as e:
            QMessageBox.critical(self, i18n.tr("tip"), str(e))

    def _check_process(self, proc, log_path):
        code = proc.poll()
        if code is None:
            return
        self._log("游戏进程已退出，退出码 %s" % code)
        self._announce_presence("launcher")
        tail = ""
        try:
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                    tail = "\n".join(f.read().strip().splitlines()[-8:])
        except Exception:
            pass
        if code != 0:
            QMessageBox.critical(self, "游戏启动失败",
                                 "退出码：%s\n\n%s" % (code, tail or "详见日志 " + log_path))

    # ---------- 启动进度条 ----------
    def _start_launch_progress(self, proc, log_path):
        self.launch_proc = proc
        self.launch_log_path = log_path
        self.launch_t0 = time.time()
        self.launch_mark = 0
        self.launch_bar.setRange(0, 100)
        self.launch_bar.setValue(6)
        self.launch_bar.setFormat(i18n.tr("launch_loading") + " %p%")
        self.launch_bar.setVisible(True)
        self.launch_state.setVisible(True)
        self.launch_state.setText(i18n.tr("launch_loading"))
        self.launch_timer.start(600)

    def _tail_launch_log(self, chars=8000):
        try:
            with open(self.launch_log_path, "r", encoding="utf-8",
                      errors="replace") as f:
                return f.read()[-chars:]
        except OSError:
            return ""

    def _launch_tick(self):
        proc = self.launch_proc
        if proc is None:
            self._finish_launch_progress(False, i18n.tr("launch_failed"))
            return
        if proc.poll() is not None:
            self._finish_launch_progress(False, i18n.tr("launch_failed"))
            return
        text = self._tail_launch_log()
        # 按游戏日志真实节点推进，未命中时用时间缓慢兜底
        pct = 8 + int((time.time() - self.launch_t0) / 2.0)
        for key, val in (("Setting user", 32),
                         ("Backend library", 58),
                         ("Sound engine started", 92)):
            if key in text:
                pct = max(pct, val)
        pct = min(pct, 95)
        if pct > self.launch_bar.value():
            self.launch_bar.setValue(pct)
        if "Sound engine started" in text:
            self.launch_mark += 1
            if self.launch_mark >= 3:
                self._finish_launch_progress(True, i18n.tr("launch_ok"))

    def _finish_launch_progress(self, ok, text):
        self.launch_timer.stop()
        if ok:
            self.launch_bar.setValue(100)
            self.launch_bar.setFormat("100%")
        self.launch_state.setText(text)
        QTimer.singleShot(2600, self._hide_launch_progress)

    def _hide_launch_progress(self):
        self.launch_bar.setVisible(False)
        self.launch_state.setVisible(False)
        self.launch_proc = None

    # ---------- 设置 ----------
    def _pick_gamedir(self):
        p = QFileDialog.getExistingDirectory(self, "选择游戏目录", self.input_gamedir.text())
        if p:
            self.input_gamedir.setText(p)

    def _on_java_auto_toggled(self, on):
        self.config.set("java_auto", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        try:
            self.input_java.setReadOnly(bool(on))
        except Exception:
            pass
        self._log("Java 全自动：" + ("打开（按版本自动换）" if on else "关闭（手动指定）"))
        if on:
            self._java_follow_version()

    def _pick_java(self):
        start = (os.path.dirname(self.config.get("java_path") or "")
                 or os.path.expanduser("~"))
        exe = platform_utils.java_binary_name()
        p, _ = QFileDialog.getOpenFileName(self, "选择 " + exe, start,
                                           "Java (%s);;所有文件 (*)" % exe)
        if p:
            self.input_java.setText(p)
            self.java_state.setText("Java 版本：" + java_utils.java_version(p))

    def _apply_java(self, path, why=""):
        """把自动挑出来的 Java 写回配置，并在设置页显示出来。"""
        self.config.set("java_path", path)
        try:
            self.config.save()
        except Exception:
            pass
        try:
            self.input_java.setText(path)
            self.java_state.setText("Java 版本：" + java_utils.java_version(path)
                                    + "（全自动）")
        except Exception:
            pass
        if why:
            self._log("%s：%s" % (why, path))
        return path

    def _ensure_java_path(self, required=0, force=False, ver=""):
        """全自动：按「当前版本要哪一版 Java」精确挑，缺了它自己去下，用户不用管。

        required 为 0 时可以用 ver（版本号，比如 1.20.1）推出来。
        """
        if not required and ver:
            try:
                required = java_utils.version_major(ver)
            except Exception:
                required = 0
        cur = (self.config.get("java_path") or "").strip()
        if cur and not os.path.exists(cur):
            cur = ""
        if not required:
            if cur:
                return cur
            p = java_utils.auto_pick()
            return self._apply_java(p, "没有指定版本，自动挑一个 Java") if p else ""
        # 1) 本机有恰好这一版的 Java：换过去（换版本就自动换 Java）
        try:
            exact = java_utils.pick_exact(required)
        except Exception:
            exact = ""
        if exact:
            if exact != cur:
                self._apply_java(exact, "这个版本要用 Java %d，已自动切换" % required)
            return exact
        # 2) 手上这个刚好也是这一版
        if cur:
            try:
                if java_utils.java_major(cur) == required:
                    return cur
            except Exception:
                pass
        # 3) 这一版没有：后台下一份，先拿最接近的顶着，别让用户干等
        self._log("本机没有 Java %d，开始自动下载（这次是缺哪个版本下哪个版本）"
                  % required)
        self._start_java_download(required)
        try:
            fallback = java_utils.pick_for(required)
        except Exception:
            fallback = ""
        if fallback:
            self._apply_java(fallback,
                             "Java %d 还在下，先用 Java %d 顶着"
                             % (required, java_utils.java_major(fallback)))
        return fallback

    def _java_follow_version(self):
        """选中哪个版本，就按那个版本要的 Java 自动换过去。"""
        if not getattr(self, "java_state", None):
            return
        if self.config.get("java_auto") is False:
            return
        vid = self._selected_version_id()
        if not vid:
            return
        jpath = self._version_json_path(vid)
        required = 0
        if os.path.exists(jpath):
            required = launcher.required_java_major(jpath)
        if not required:
            required = java_utils.version_major(vid)
        try:
            p = self._ensure_java_path(required)
        except Exception as e:
            self._log("自动换 Java 失败：%s" % e)
            return
        if p:
            self._log("「%s」要 Java %d，已自动用：%s" % (vid, required, p))


    def _start_java_download(self, major=17):
        if getattr(self, "_java_dl_running", False):
            return
        # 同一版本刚失败过就歇一会儿，别每次切版本都重下一遍
        bad = getattr(self, "_java_dl_bad", {})
        info = bad.get(major)
        if info and info.get("tries", 0) >= 2 and time.time() - info.get("t", 0) < 900:
            self._log("Java %d 已经连续下载失败，先不重复下载（15 分钟后再试）"
                      % major)
            return
        self._java_dl_running = True
        self._java_dl_major = int(major)
        try:
            self.java_state.setText("没找到 Java，正在自动下载 JRE %d......" % major)
        except Exception:
            pass
        self._log("没找到 Java，开始自动下载 JRE %d" % major)
        self._jdw = self._track(JavaDownloadWorker(major))
        self._jdw.log.connect(self._log)
        self._jdw.progress.connect(self._on_java_progress)
        self._jdw.done.connect(self._on_java_downloaded)
        self._jdw.failed.connect(self._on_java_download_failed)
        self._jdw.start()

    def _on_java_progress(self, cur, total):
        if total:
            try:
                self.java_state.setText(
                    "正在下载 Java：%d%%（%.1f / %.1f MB）"
                    % (int(cur * 100 / total), cur / 1048576.0,
                       total / 1048576.0))
                if getattr(self, "java_bar", None):
                    self.java_bar.setVisible(True)
                    self.java_bar.setMaximum(int(total))
                    self.java_bar.setValue(int(cur))
            except Exception:
                pass

    def _on_java_downloaded(self, path):
        self._java_dl_running = False
        try:
            if getattr(self, "java_bar", None):
                self.java_bar.setVisible(False)
                self.java_bar.setValue(0)
        except Exception:
            pass
        self.config.set("java_path", path)
        try:
            self.config.save()
            self.input_java.setText(path)
            self.java_state.setText("Java 版本：" + java_utils.java_version(path))
        except Exception:
            pass
        self._log("已自动下载并配置 Java：" + path)
        # 用户刚才就是因为缺 Java 才没启动成功：装好直接续上
        vid = getattr(self, "_pending_launch_vid", None)
        if vid:
            self._pending_launch_vid = None
            QTimer.singleShot(300, lambda: self._retry_pending_launch(vid))

    def _retry_pending_launch(self, vid):
        """Java 刚装完，把刚才被打断的那次启动接着做完。"""
        try:
            account = self._resolve_account()
        except Exception as e:
            self._log("续启动失败：%s" % e)
            return
        if account:
            self._start_game(vid, account)

    def _on_java_download_failed(self, err):
        self._java_dl_running = False
        try:
            if getattr(self, "java_bar", None):
                self.java_bar.setVisible(False)
                self.java_bar.setValue(0)
        except Exception:
            pass
        try:
            bad = getattr(self, "_java_dl_bad", {})
            major = int(getattr(self, "_java_dl_major", 0) or 0)
            if major:
                info = bad.get(major) or {"tries": 0}
                info["tries"] = int(info.get("tries") or 0) + 1
                info["t"] = time.time()
                bad[major] = info
                self._java_dl_bad = bad
        except Exception:
            pass
        try:
            self.java_state.setText("Java 自动下载失败：" + err)
        except Exception:
            pass
        self._log("Java 自动下载失败：" + err)

    def _auto_java(self):
        p = self._ensure_java_path(force=True)
        if p:
            self.java_state.setText("Java 版本：" + java_utils.java_version(p))
        else:
            self.java_state.setText("未检测到 Java，请先安装或手动选择")

    def _fix_java(self):
        """一键修复：按当前版本要的 Java 主版本查一遍，缺了/不对就自动下适配的。"""
        vid = ""
        try:
            it = self.local_list.currentItem()
            if it is not None:
                vid = it.data(Qt.UserRole) or ""
        except Exception:
            vid = ""
        vid = vid or (self.config.get("last_version") or "")
        required = 0
        try:
            if vid:
                required = launcher.required_java_major(self._version_json_path(vid))
        except Exception:
            required = 0
        if not required and vid:
            required = java_utils.version_major(vid)
        self.java_state.setText("正在检查 Java%s…"
                                % ((" %d" % required) if required else ""))
        p = self._ensure_java_path(required, force=True, ver=vid)
        if p:
            self.config.set("java_path", p)
            try:
                self.config.save()
            except Exception:
                pass
            self.java_state.setText("已修好：%s（Java %s）"
                                    % (p, java_utils.java_major(p)))
            self._log("Java 一键修复完成：%s" % p)
        else:
            self.java_state.setText(
                "没找到也没下成 Java %s，可以点「浏览」手动选一个"
                % (required or "（版本未识别）"))
            self._log("Java 一键修复没成功，需要 Java %s" % (required or "未知"))

    # 内置壁纸（文件名, 显示名）；文件在 assets/ 里，打包后从 _MEIPASS 取
    BUILTIN_WALLS = (
        ("wall_meadow.jpg", "草原 · 蘑菇与山"),
        ("wall_sunset.jpg", "落日 · 河畔小村"),
        ("wall_valley.jpg", "山谷 · 云上村落"),
        ("wall_cliff.jpg", "悬崖 · 河边小屋"),
        ("wall_sky.jpg", "空岛 · 浮空石林"),
        ("wall_castle.jpg", "海上 · 巨石城堡"),
    )

    def _wall_path(self, name):
        base = getattr(sys, "_MEIPASS", None) or os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base, "assets", name)

    def _wall_label(self, key):
        for fn, label in self.BUILTIN_WALLS:
            if "builtin:" + fn == key or fn == key:
                return label
        return ""

    def _stop_rand_wall_after_manual(self):
        """手动换壁纸就把「每次启动随机换一张」关掉。

        不关的话：这一轮看着是换了，下次打开启动器又被随机挑走一张，
        用户感知就是「我选的壁纸根本没生效」。
        """
        try:
            if not self.config.get("bg_random"):
                return False
            self.config.set("bg_random", False)
            self.config.save()
            chk = getattr(self, "chk_randwall", None)
            if chk is not None:
                chk.blockSignals(True)
                chk.setChecked(False)
                chk.blockSignals(False)
            self._rand_wall_rolled = True
            self._log("手动换了壁纸，已关掉「每次启动随机换一张」，"
                      "免得下次打开又被换走")
            return True
        except Exception:
            return False

    def _on_wall_changed(self, _i=None):
        key = self.combo_wall.currentData() or ""
        if not key:
            self.config.set("background_image", "")
            self.config.save()
            try:
                self.label_bg_name.setText(i18n.tr("bg_default"))
            except Exception:
                pass
            self._apply_background()
            return
        self.config.set("background_image", key)
        self.config.save()
        self._stop_rand_wall_after_manual()
        try:
            self.label_bg_name.setText(self._wall_label(key) or key)
        except Exception:
            pass
        self._apply_background()
        self._log("已换成内置壁纸：" + (self._wall_label(key) or key))

    def _pick_background(self):
        path, _ = QFileDialog.getOpenFileName(
            self, i18n.tr("btn_import_bg"), "",
            "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            self._apply_background_path(path)

    def _apply_background_path(self, path):
        self.config.set("background_image", path)
        self.config.save()
        self._stop_rand_wall_after_manual()
        try:
            self.label_bg_name.setText(path)
            self.combo_wall.blockSignals(True)
            self.combo_wall.setCurrentIndex(0)   # 自定义图了，内置那一栏回到「不用」
            self.combo_wall.blockSignals(False)
        except Exception:
            pass
        self._apply_background()
        self._log("已把图片设为启动器背景：" + os.path.basename(path))

    def _reset_background(self):
        self.config.set("background_image", "")
        self.config.save()
        try:
            self.label_bg_name.setText(i18n.tr("bg_default"))
            self.combo_wall.blockSignals(True)
            self.combo_wall.setCurrentIndex(0)
            self.combo_wall.blockSignals(False)
        except Exception:
            pass
        self._apply_background()

    # ---------- 截图 ----------
    _THUMB_CACHE = {}

    def _thumb(self, path, box=(180, 104)):
        """按比例缩略，避免 4K 截图整张读进内存把列表拖卡。

        同一张图（文件没改）算过一次就缓存住，列表反复刷新时不再重读磁盘。
        """
        try:
            key = (path, os.path.getmtime(path), box)
        except OSError:
            key = (path, 0, box)
        hit = self._THUMB_CACHE.get(key)
        if hit is not None:
            return hit
        reader = QImageReader(path)
        reader.setAutoTransform(True)
        size = reader.size()
        if size.isValid() and size.width() and size.height():
            scale = min(float(box[0]) / size.width(),
                        float(box[1]) / size.height())
            reader.setScaledSize(QSize(max(1, int(size.width() * scale)),
                                       max(1, int(size.height() * scale))))
        img = reader.read()
        if img.isNull():
            return QPixmap()
        pm = QPixmap.fromImage(img)
        # 缓存上限，超了就清空（简单够用，别把内存吃光）
        if len(self._THUMB_CACHE) > 600:
            self._THUMB_CACHE.clear()
        self._THUMB_CACHE[key] = pm
        return pm

    def _view_screenshots(self):
        gd = self.config.get("game_dir") or ""
        rows = screenshots.list_shots(gd)
        if not rows:
            if QMessageBox.question(
                    self, "还没有截图",
                    "screenshots 文件夹里还没有截图（游戏里按 F2 截图）。\n\n"
                    "要打开这个文件夹吗？") == QMessageBox.Yes:
                platform_utils.open_path(screenshots.open_dir(gd))
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("游戏截图（%d 张）" % len(rows))
        dlg.resize(800, 580)
        v = QVBoxLayout(dlg)
        lst = QListWidget()
        lst.setViewMode(QListWidget.IconMode)
        lst.setIconSize(QSize(180, 104))
        lst.setGridSize(QSize(196, 140))
        lst.setResizeMode(QListWidget.Adjust)
        lst.setSpacing(6)
        self._attach_ctx_menu(lst, "screenshot")
        for path, mtime, kb in rows:
            pix = self._thumb(path)
            if pix.isNull():
                continue
            item = QListWidgetItem(QIcon(pix), time.strftime(
                "%m-%d %H:%M", time.localtime(mtime)))
            item.setData(Qt.UserRole, path)
            item.setToolTip("%s\n%.0f KB" % (os.path.basename(path), kb))
            lst.addItem(item)
        v.addWidget(lst, 1)

        def current():
            it = lst.currentItem()
            return it.data(Qt.UserRole) if it else ""

        def open_one():
            p = current()
            if p:
                platform_utils.open_path(p)

        def set_bg():
            p = current()
            if p:
                self._apply_background_path(p)
                dlg.accept()

        def open_dir():
            platform_utils.open_path(screenshots.open_dir(gd))

        row = QHBoxLayout()
        for text, fn in (("打开原图", open_one), ("设为启动器背景", set_bg),
                         ("打开截图文件夹", open_dir)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        lst.itemDoubleClicked.connect(lambda _i: open_one())
        dlg.exec_()

    # ---------- 修复崩溃 ----------
    def _fix_crash(self):
        gd = self.config.get("game_dir") or ""
        if not gd or not os.path.isdir(gd):
            QMessageBox.warning(self, "提示", "先在设置里选好游戏目录")
            return
        vid = self._selected_version_id() or ""
        loader = self._detect_loader_kind(vid) if vid else None
        mc = self._loader_base_mc(vid) if vid else ""

        try:
            res = crashlog.analyze_game_dir(gd)
        except Exception:
            res = {}
        head = []
        if res.get("source"):
            head.append("崩溃日志：" + os.path.basename(res["source"]))
            for verdict, _advice, _s in res["hits"][:3]:
                head.append("| 可能原因：" + verdict)
        else:
            head.append("没找到崩溃日志，下面只做模组体检。")

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            plan = diagnose.plan(gd, loader)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "体检失败", str(e))
            return
        QApplication.restoreOverrideCursor()

        lines = list(head)
        lines.append("")
        lines.append("当前实例：%s（%s）"
                     % (vid or "未选版本",
                        loaders.LABELS.get(loader or "", "原版")))
        lines.append("模组总数：%d" % plan["total"])
        if plan["mismatch"]:
            lines.append("加载器不符：%d 个" % len(plan["mismatch"]))
            for m in plan["mismatch"][:8]:
                lines.append("  %s（只支持 %s）"
                             % (m["file"], "/".join(m["supports"])))
        if plan["missing"]:
            lines.append("缺前置：%d 个" % len(plan["missing"]))
            for m in plan["missing"][:8]:
                lines.append("  %s（被 %s 需要）" % (m["id"], m["by"][0]))
        if not plan["mismatch"] and not plan["missing"]:
            lines.append("没发现加载器不符或缺前置的模组。")

        box = QMessageBox(self)
        box.setWindowTitle("修复崩溃")
        box.setIcon(QMessageBox.Warning if (plan["mismatch"] or plan["missing"])
                    else QMessageBox.Information)
        box.setText("\n".join(lines[:36]))
        box.setDetailedText("\n".join(lines))
        box.exec_()

        if plan["mismatch"]:
            names = [m["file"] for m in plan["mismatch"]]
            text = ("下面这些模组和当前实例的加载器不符，放进 mods 会导致启动崩溃：\n\n"
                    + "\n".join(names[:12]))
            if len(names) > 12:
                text += "\n...... 共 %d 个" % len(names)
            text += "\n\n要现在删掉这些 jar 吗？"
            if QMessageBox.question(self, "删除不符的模组", text) == QMessageBox.Yes:
                n = diagnose.delete_files([m["path"] for m in plan["mismatch"]],
                                          self._log)
                self._refresh_mods_list()
                QMessageBox.information(self, "已处理", "删除 %d 个模组文件" % n)

        if plan["missing"]:
            self._install_missing_deps(plan["missing"], mc, loader)

    def _install_missing_deps(self, missing, mc, loader):
        gd = self.config.get("game_dir") or ""
        dest = mods.mods_dir(gd)
        installed = 0
        for dep in missing[:8]:
            mid = dep["id"]
            found = diagnose.resolve_dependency(mid, mc, loader or "")
            if not found:
                self._log("Modrinth 上没认出前置：" + mid)
                continue
            pid, title = found
            if QMessageBox.question(
                    self, "安装前置",
                    "%s 需要前置「%s」。\n\n在 Modrinth 上找到：%s\n要下载安装吗？"
                    % (dep["by"][0], mid, title)) != QMessageBox.Yes:
                continue
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                modrinth.download_project(pid, mc, loader or None, dest,
                                          self._log, project_type="mod")
                installed += 1
            except Exception as e:
                QMessageBox.warning(self, "安装失败", "%s：%s" % (mid, e))
            finally:
                QApplication.restoreOverrideCursor()
        if installed:
            self._refresh_mods_list()
            QMessageBox.information(self, "前置已装",
                                    "装了 %d 个前置，重启游戏试试。" % installed)

    # ---------- 局内资源包 ----------
    def _snapshot_root(self):
        d = os.path.join(os.path.expanduser("~"), ".simple_mc_launcher",
                         "version_snapshots")
        os.makedirs(d, exist_ok=True)
        return d

    def _version_snapshots(self):
        """版本快照：打包版本目录 + 模组清单，改坏了可以一键还原。"""
        vid = getattr(self, "_detail_vid", "") or self._selected_version_id() or ""
        if not vid:
            QMessageBox.information(self, "先选版本", "先选一个版本再看快照。")
            return
        gd = self.config.get("game_dir") or ""
        dlg = QDialog(self)
        dlg.setWindowTitle("版本快照 · " + vid)
        dlg.resize(680, 470)
        v = QVBoxLayout(dlg)
        tip = QLabel("快照会把 versions/%s 整个目录、以及当时的模组清单存成 zip；"
                     "还原时用快照覆盖回去（原件会先另存一份）。" % vid)
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)
        lst = QListWidget()
        v.addWidget(lst, 1)
        state = QLabel("")
        state.setObjectName("FieldLabel")
        v.addWidget(state)

        def fill():
            lst.clear()
            root = self._snapshot_root()
            rows = []
            for f in os.listdir(root):
                if f.startswith(vid + "_") and f.endswith(".zip"):
                    rows.append(f)
            rows.sort(reverse=True)
            for f in rows:
                p = os.path.join(root, f)
                lst.addItem("%s    %.1f MB" % (f, os.path.getsize(p) / 1048576.0))
            if not rows:
                lst.addItem("还没有这个版本的快照。")

        def make():
            src = os.path.join(gd, "versions", vid)
            if not os.path.isdir(src):
                state.setText("找不到 versions/%s 目录。" % vid)
                return
            out = os.path.join(self._snapshot_root(),
                               "%s_%s.zip" % (vid, time.strftime("%Y%m%d_%H%M%S")))
            n = 0
            try:
                with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                    for base, _dirs, files in os.walk(src):
                        for f in files:
                            p = os.path.join(base, f)
                            arc = os.path.join("versions", vid,
                                               os.path.relpath(p, src))
                            z.write(p, arc)
                            n += 1
                    md = os.path.join(gd, "mods")
                    if os.path.isdir(md):
                        z.writestr("mods.txt", "\n".join(sorted(
                            f for f in os.listdir(md)
                            if not f.endswith(".disabled"))))
                        n += 1
                    opt = os.path.join(gd, "options.txt")
                    if os.path.isfile(opt):
                        z.write(opt, "options.txt")
                        n += 1
            except Exception as e:
                state.setText("快照失败：" + str(e))
                return
            state.setText("快照好了：%s（%d 个文件，%.1f MB）"
                          % (os.path.basename(out), n,
                             os.path.getsize(out) / 1048576.0))
            self._log("版本快照：" + os.path.basename(out))
            fill()

        def restore():
            i = lst.currentRow()
            root = self._snapshot_root()
            rows = sorted([f for f in os.listdir(root)
                           if f.startswith(vid + "_") and f.endswith(".zip")],
                          reverse=True)
            if i < 0 or i >= len(rows):
                state.setText("先在列表里选一个快照。")
                return
            p = os.path.join(root, rows[i])
            if QMessageBox.question(
                    self, "还原快照",
                    "用「%s」覆盖 versions/%s？当前目录会先另存一份备份。"
                    % (rows[i], vid)) != QMessageBox.Yes:
                return
            dst = os.path.join(gd, "versions")
            bak = os.path.join(gd, "versions",
                               "%s.bak_%s" % (vid, time.strftime("%H%M%S")))
            cur = os.path.join(dst, vid)
            try:
                if os.path.isdir(cur):
                    shutil.copytree(cur, bak, dirs_exist_ok=True)
                with zipfile.ZipFile(p) as z:
                    z.extractall(gd)
            except Exception as e:
                state.setText("还原失败：" + str(e))
                return
            state.setText("已还原，原目录备份在 versions/%s" % os.path.basename(bak))
            self._log("还原版本快照：" + rows[i])

        brow = QHBoxLayout()
        b_make = QPushButton("现在存一个快照")
        b_make.clicked.connect(make)
        b_restore = QPushButton("用选中的还原")
        b_restore.clicked.connect(restore)
        b_open = QPushButton("打开快照文件夹")
        b_open.clicked.connect(lambda: platform_utils.open_path(self._snapshot_root()))
        brow.addWidget(b_make)
        brow.addWidget(b_restore)
        brow.addWidget(b_open)
        brow.addStretch(1)
        v.addLayout(brow)
        foot = QHBoxLayout()
        foot.addStretch(1)
        b_close = QPushButton("关闭")
        b_close.clicked.connect(dlg.accept)
        foot.addWidget(b_close)
        v.addLayout(foot)
        fill()
        dlg.exec_()

    def _manage_ingame_packs(self):
        gd = self.config.get("game_dir") or ""
        path = packs.options_path(gd)
        if not os.path.exists(path):
            QMessageBox.information(
                self, "还没进过游戏",
                "options.txt 还不存在。先启动一次游戏、进到主菜单退出，"
                "再来改资源包顺序。")
            return
        enabled = packs.read_enabled(gd)
        avail = packs.available(gd)

        dlg = QDialog(self)
        dlg.setWindowTitle("局内资源包")
        dlg.resize(540, 500)
        v = QVBoxLayout(dlg)
        tip = QLabel("勾选＝游戏里启用；列表越靠下优先级越高（盖在上面）。"
                     "改完重启游戏生效。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        lst = QListWidget()
        v.addWidget(lst, 1)

        enabled_names = [packs.display_name(p) for p in enabled
                         if p != packs.VANILLA]
        shown = list(enabled_names)
        for name in avail:
            if name not in shown:
                shown.append(name)
        for name in shown:
            it = QListWidgetItem(name)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if name in enabled_names else Qt.Unchecked)
            it.setData(Qt.UserRole, name)
            lst.addItem(it)

        def move(step):
            row = lst.currentRow()
            target = row + step
            if row < 0 or target < 0 or target >= lst.count():
                return
            it = lst.takeItem(row)
            lst.insertItem(target, it)
            lst.setCurrentRow(target)

        def set_all(state):
            for i in range(lst.count()):
                lst.item(i).setCheckState(state)

        def save():
            ids = []
            for i in range(lst.count()):
                it = lst.item(i)
                if it.checkState() == Qt.Checked:
                    ids.append(packs.pack_id(it.data(Qt.UserRole)))
            try:
                packs.write_enabled(gd, ids)
            except Exception as e:
                QMessageBox.warning(dlg, "保存失败", str(e))
                return
            self._log("局内资源包已更新：%d 个启用" % len(ids))
            QMessageBox.information(dlg, "已保存", "重启游戏后生效。")
            dlg.accept()

        row1 = QHBoxLayout()
        for text, fn in (("上移", lambda: move(-1)), ("下移", lambda: move(1)),
                         ("全选", lambda: set_all(Qt.Checked)),
                         ("全不选", lambda: set_all(Qt.Unchecked))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row1.addWidget(b)
        row1.addStretch(1)
        v.addLayout(row1)

        def rescan():
            dlg.accept()
            QTimer.singleShot(0, self._manage_ingame_packs)

        row2 = QHBoxLayout()
        b_save = QPushButton("保存")
        b_save.setObjectName("PrimaryButton")
        b_save.clicked.connect(save)
        b_scan = QPushButton("重新扫描资源包")
        b_scan.clicked.connect(rescan)
        row2.addWidget(b_scan)
        row2.addStretch(1)
        row2.addWidget(b_save)
        v.addLayout(row2)
        dlg.exec_()

    # ---------- 版本与加载器一览 ----------
    def _open_loader_summary(self):
        gd = self.config.get("game_dir") or ""
        root = os.path.join(gd, "versions")
        rows = []
        if os.path.isdir(root):
            for name in sorted(os.listdir(root)):
                jp = os.path.join(root, name, name + ".json")
                if not os.path.isfile(jp):
                    continue
                kind = self._detect_loader_kind(name)
                rows.append((name, loaders.LABELS.get(kind or "", "原版")))
        dlg = QDialog(self)
        dlg.setWindowTitle("已装版本与加载器")
        dlg.resize(460, 460)
        v = QVBoxLayout(dlg)
        lst = QListWidget()
        cur = self._selected_version_id()
        for name, label in rows:
            text = "%s    [%s]" % (name, label)
            if name == cur:
                text += "    ← 当前"
            lst.addItem(text)
        if not rows:
            lst.addItem("versions 目录里还没有版本")
        v.addWidget(lst, 1)
        tip = QLabel("方括号里是加载器；点「打开模组」看到的 mods 目录由当前实例共用。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)
        b = QPushButton("关闭")
        b.clicked.connect(dlg.accept)
        v.addWidget(b)
        dlg.exec_()

    # ---------- 维护与工具 ----------
    def _extra_jvm(self):
        """设置里手填的参数 + 选中的模板参数。"""
        base = (self.config.get("extra_jvm_args") or "").strip()
        tpl = jvmargs.args_for(self.config.get("jvm_template") or "none")
        return (base + " " + tpl).strip()

    # ---------- 反馈 ----------
    def _feedback_body(self):
        """把用户写的内容 + 自动收集的环境信息拼成一段可直接发的文本。"""
        import platform as _pf
        import datetime as _dt
        kind = self.fb_kind.currentText() if hasattr(self, "fb_kind") else ""
        text = self.fb_text.toPlainText().strip() if hasattr(self, "fb_text") else ""
        try:
            ver = update.VERSION
        except Exception:
            ver = "?"
        log_tail = ""
        try:
            log_tail = "\n".join(
                self.log_view.toPlainText().splitlines()[-30:])
        except Exception:
            pass
        out = [
            "【反馈类型】" + kind,
            "",
            "【内容】",
            text or "（没写内容）",
            "",
            "----- 以下自动附上，方便定位问题 -----",
            "时间：" + _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "启动器版本：OMC " + str(ver),
            "系统：" + _pf.platform() + " / " + _pf.version(),
            "游戏目录：" + (self.config.get("game_dir") or ""),
            "Java：" + (self.config.get("java_path") or ""),
            "内存设置：%s MB" % self.config.get("memory_mb"),
            "当前版本：" + (self.config.get("last_version") or ""),
            "",
            "----- 启动器日志末尾 -----",
            log_tail or "（空）",
        ]
        return "\n".join(out)

    def _open_feedback(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("反馈 / 报 Bug")
        dlg.resize(600, 560)
        v = QVBoxLayout(dlg)
        v.setContentsMargins(16, 16, 16, 16)
        v.setSpacing(10)

        head = QLabel("写完点「直接匿名发送」就行：不用登录、不用邮箱、不用填联系方式，"
                      "点一下我这边就收到了。")
        head.setWordWrap(True)
        v.addWidget(head)

        self.fb_kind = QComboBox()
        for t in ("遇到问题 / Bug", "功能建议", "其他"):
            self.fb_kind.addItem(t)
        v.addWidget(self.fb_kind)

        self.fb_text = QTextEdit()
        self.fb_text.setPlaceholderText(
            "比如：点启动后闪一下就没了；存档列表里右键删除报错；"
            "希望加一个 xxx 功能")
        v.addWidget(self.fb_text, 1)

        tip = QLabel("会自动附上启动器版本、系统、Java、游戏目录和最近 30 行日志；"
                     "你的电脑用户名会被替换成 %USER%，别的内容原样发出。")
        tip.setObjectName("FieldLabel")
        tip.setWordWrap(True)
        v.addWidget(tip)

        row = QHBoxLayout()
        b_send = QPushButton("直接匿名发送")
        b_copy = QPushButton("复制内容")
        b_save = QPushButton("保存成文件")
        b_close = QPushButton("关闭")
        row.addWidget(b_send)
        row.addWidget(b_copy)
        row.addWidget(b_save)
        row.addStretch(1)
        row.addWidget(b_close)
        v.addLayout(row)
        b_send.setDefault(True)

        def do_copy():
            if not self.fb_text.toPlainText().strip():
                tip.setText("先把遇到的问题写上两句，再复制。")
                return
            QApplication.clipboard().setText(self._feedback_body())
            tip.setText("已复制。粘到 QQ / 微信 / 群里发给我就能看到。")

        def do_save():
            body = self._feedback_body()
            base = os.path.join(os.path.expanduser("~"),
                                ".simple_mc_launcher", "feedback")
            try:
                os.makedirs(base, exist_ok=True)
                fn = "OMC反馈-%s.txt" % time.strftime("%Y%m%d-%H%M%S")
                p = os.path.join(base, fn)
                with open(p, "w", encoding="utf-8") as f:
                    f.write(body)
                tip.setText("已保存：" + p)
                platform_utils.open_path(base)
            except Exception as e:
                tip.setText("保存失败：" + str(e))

        def do_send():
            text = self.fb_text.toPlainText().strip()
            if not text:
                tip.setText("先写两句：出了什么问题、在做什么的时候出的。")
                self.fb_text.setFocus()
                return
            try:
                ver = update.VERSION
            except Exception:
                ver = "?"
            log_tail = ""
            try:
                log_tail = "\n".join(
                    self.log_view.toPlainText().splitlines()[-30:])
            except Exception:
                pass
            extra = {
                "game_dir": self.config.get("game_dir") or "",
                "java": self.config.get("java_path") or "",
                "mem": "%s MB" % self.config.get("memory_mb"),
                "last_version": self.config.get("last_version") or "",
                "language": self.config.get("language") or "",
            }
            payload = feedback.build(self.fb_kind.currentText(), text, ver,
                                     extra, log_tail, app="OMC")
            b_send.setEnabled(False)
            tip.setText("正在匿名发送......")
            QApplication.processEvents()
            try:
                ok, mid = feedback.submit(payload)
            except Exception as e:
                b_send.setEnabled(True)
                tip.setText("发送没成功（多半是网络不通）：%s。"
                            "可以点「复制内容」或「保存成文件」，一样能发我。" % e)
                return
            b_send.setEnabled(True)
            self._log("已匿名发送反馈（编号 %s）" % (mid or "-"))
            tip.setText("已经匿名发出去了（编号 %s），我这边收件箱能看到。"
                        "想说更多可以再发一条。" % (mid or "已收到"))

        b_send.clicked.connect(do_send)
        b_copy.clicked.connect(do_copy)
        b_save.clicked.connect(do_save)
        b_close.clicked.connect(dlg.close)
        dlg.exec_()

    def _launch_bedrock(self):
        """检测商店版基岩版并启动；没装就引导去商店。"""
        self._log("正在检测基岩版......")
        try:
            found = bedrock.list_installed()
        except Exception as e:
            self._log("检测基岩版失败：" + str(e))
            found = []
        if not found:
            msg = ("没检测到 Windows 商店版《我的世界》基岩版。\n\n"
                   "打开微软商店的基岩版页面去安装吗？装完回来再点这个按钮就行。")
            if QMessageBox.question(
                    self, "没有找到基岩版", msg,
                    QMessageBox.Yes
                    | QMessageBox.No) == QMessageBox.Yes:
                if not bedrock.open_store():
                    QMessageBox.warning(
                        self, "打不开商店",
                        "请手动在微软商店搜索「Minecraft for Windows」。")
            return
        first = found[0]
        if len(found) > 1:
            labels = [x["label"] for x in found]
            pick, ok = QInputDialog.getItem(
                self, "选择基岩版", "要启动哪个版本？", labels, 0, False)
            if not ok:
                return
            first = found[labels.index(pick)]
        ok, msg = bedrock.launch(first)
        self._log(msg)
        if not ok:
            QMessageBox.warning(self, "启动失败", msg)

    def _launch_netease(self):
        """启动网易版：只调它自己的官方启动器，登录也在它那里完成。

        这里刻意不做任何"代登录 / 注入 / 改客户端文件"的事——网易版的反作弊
        看的就是这些。OMC 只负责把 MCLauncher.exe 拉起来，等于一个快捷方式。
        """
        self._log("正在找网易版官方启动器......")
        saved = (self.config.get("netease_exe") or "").strip()
        try:
            found = netease.list_installed(saved)
        except Exception as e:
            self._log("检测网易版失败：%s" % e)
            found = []

        if not found:
            box = QMessageBox(self)
            box.setWindowTitle("没找到网易版")
            box.setIcon(QMessageBox.Question)
            box.setText("这台电脑上没找到网易版《我的世界》的官方启动器。")
            box.setInformativeText(
                "网易版的登录和启动必须用它自己的客户端，OMC 不能代登录。\n"
                "你要么先装网易版，要么手动指一下已经装好的 MCLauncher.exe。")
            b_site = box.addButton("去官网下载", QMessageBox.AcceptRole)
            b_pick = box.addButton("我自己选启动器", QMessageBox.ActionRole)
            box.addButton("取消", QMessageBox.RejectRole)
            box.exec()
            clicked = box.clickedButton()
            if clicked == b_site:
                if not netease.open_site():
                    QMessageBox.warning(self, "打不开网页",
                                        "请手动打开 mc.163.com 下载网易版。")
            elif clicked == b_pick:
                path, _f = QFileDialog.getOpenFileName(
                    self, "选择网易版启动器", r"C:\Program Files (x86)\Netease",
                    "启动器 (MCLauncher*.exe);;程序 (*.exe)")
                if path:
                    self.config.set("netease_exe", path)
                    found = [{"label": path, "path": path}]
                else:
                    return
            else:
                return

        first = found[0]
        if len(found) > 1:
            labels = [x["label"] for x in found]
            pick, ok = QInputDialog.getItem(
                self, "选择网易版", "找到多个，要启动哪个？", labels, 0, False)
            if not ok:
                return
            first = found[labels.index(pick)]

        # 第一次用记下来，下次直接命中，不用再扫
        if not saved or os.path.normcase(saved) != os.path.normcase(first["path"]):
            self.config.set("netease_exe", first["path"])

        ok, msg = netease.launch(first)
        self._log(msg)
        if ok:
            QMessageBox.information(
                self, "网易版已启动",
                "网易版官方启动器已经打开了。\n\n"
                "登录、实名、下载都在网易自己的界面里完成——OMC 没有碰它任何文件，"
                "也没有注入，不会被反作弊当成外挂。")
        else:
            QMessageBox.warning(self, "启动失败", msg)

    def _auto_join_arg(self, vid=""):
        """设置里填了服务器就追加直连参数（1.20+ 走 quickPlay，老版本走 --server）。"""
        srv = (self.config.get("auto_join_server") or "").strip()
        if not srv:
            return ""
        host, port = pubserver.split_addr(srv)
        if not host:
            return ""
        return launcher.join_arg(host, port, vid)

    def _apply_mem_recommend(self):
        vid = self._selected_version_id() or ""
        try:
            mb, reason = memrec.recommend(self.config.get("game_dir"), vid)
        except Exception as e:
            mb, reason = 4096, "推荐失败：%s" % e
        self.slider_mem.setValue(min(int(mb), self.slider_mem.maximum()))
        self.mem_hint.setText(reason)
        self._log("内存推荐：" + reason)

    def _set_mem_preset(self, mb):
        """内存预设档位：直接跳到位并记住，不用拖滑杆。"""
        self.slider_mem.setValue(max(self.slider_mem.minimum(),
                                     min(int(mb), self.slider_mem.maximum())))
        self.config.set("memory_mb", int(self.slider_mem.value()))
        try:
            self.config.save()
        except Exception:
            pass
        self._log("内存设为 %d MB" % self.slider_mem.value())

    def _on_auto_backup_int_changed(self, _i=0):
        """改完立即生效：停掉旧的后台线程，按新间隔重开一个。"""
        mins = int(self.combo_auto_backup_int.currentData() or 0)
        self.config.set("auto_backup_interval", mins)
        try:
            self.config.save()
        except Exception:
            pass
        self._start_autobackup()
        self._log("定时备份：%s" % ("关闭" if not mins else "每 %d 分钟检查一次"
                                  % mins))

    def _apply_theme_preset(self, pid):
        try:
            p = themes.apply(self.config, pid)
        except Exception as e:
            self._log("换主题失败：%s" % e)
            return
        try:
            for k, b in getattr(self, "_accent_btns", {}).items():
                b.setChecked(k == (self.config.get("ui_accent") or "blue"))
            ti = self.combo_theme.findData(self.config.get("theme") or "dark")
            if ti >= 0:
                self.combo_theme.setCurrentIndex(ti)
            bi = self.combo_btn_style.findData(
                self.config.get("ui_button") or "round")
            if bi >= 0:
                self.combo_btn_style.setCurrentIndex(bi)
        except Exception:
            pass
        self._apply_ui_style()
        self._log("换主题：%s（%s）" % (p.get("name", pid), p.get("desc", "")))

    def _goto_theme_store(self):
        self._refresh_tools()
        if getattr(self, "toolbox_page", None):
            self.toolbox_page.tabs.setCurrentIndex(7)

    def _pack_logs(self):
        """把启动器日志、游戏 latest.log、崩溃报告和模组清单打成一个 zip。

        config.json 里有登录令牌，故意不收进去。
        """
        out, _f = QFileDialog.getSaveFileName(
            self, "打包日志", "OMC日志_%d.zip" % int(time.time()),
            "Zip 压缩包 (*.zip)")
        if not out:
            return
        gd = self.config.get("game_dir") or ""
        n = 0
        try:
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                tail = "\n".join(getattr(self, "_log_lines", []) or [])
                z.writestr("launcher_log.txt",
                           "OMC %s\n%s\n" % (update.VERSION, tail))
                n += 1
                if gd:
                    lp = os.path.join(gd, "logs", "latest.log")
                    if os.path.isfile(lp):
                        z.write(lp, "game/latest.log")
                        n += 1
                    cr = os.path.join(gd, "crash-reports")
                    if os.path.isdir(cr):
                        files = sorted(
                            (os.path.join(cr, f) for f in os.listdir(cr)
                             if f.lower().endswith((".txt", ".log"))),
                            key=os.path.getmtime, reverse=True)[:5]
                        for p in files:
                            z.write(p, "game/crash-reports/" + os.path.basename(p))
                            n += 1
                    md = os.path.join(gd, "mods")
                    if os.path.isdir(md):
                        rows = []
                        for f in sorted(os.listdir(md)):
                            p = os.path.join(md, f)
                            if os.path.isfile(p):
                                rows.append("%s\t%d B" % (f, os.path.getsize(p)))
                        z.writestr("game/mods.txt", "\n".join(rows))
                        n += 1
        except Exception as e:
            QMessageBox.warning(self, "打包失败", str(e))
            return
        QMessageBox.information(
            self, "打包好了",
            "收进 %d 个文件，已存到：\n%s\n（含账号信息的 config.json 没有放进去）"
            % (n, out))
        self._log("日志打包 → %s（%d 项）" % (out, n))

    def _desktop_dir(self):
        home = os.path.expanduser("~")
        for name in ("Desktop", "桌面"):
            p = os.path.join(home, name)
            if os.path.isdir(p):
                return p
        return home

    # ---------- 设置备份 ----------
    def _refresh_cfg_hint(self):
        try:
            items = config.list_backups()
        except Exception:
            items = []
        base = ("设置存在用户目录，换新版本解压到哪都一样读得到；每次保存都会留一份 .bak，"
                "升级后第一次启动还会自动存一份快照。")
        rec = getattr(self.config, "recovered", "") or ""
        if rec:
            base = ("注意：上次的 config.json 打不开，已经自动从 %s 恢复了设置。\n"
                    % os.path.basename(rec)) + base
        if items:
            newest = items[0]
            try:
                t = time.strftime("%Y-%m-%d %H:%M",
                                  time.localtime(os.path.getmtime(newest)))
            except Exception:
                t = ""
            txt = "%s\n最近一份备份：%s（%s），共 %d 份。" % (
                base, os.path.basename(newest), t, len(items))
        else:
            txt = base + "现在还没有快照，点「备份当前设置」可以立刻留一份。"
        try:
            self.cfg_bak_hint.setText(txt)
        except Exception:
            pass

    def _backup_config(self):
        try:
            p = self.config.backup("手动")
        except Exception as e:
            p = ""
            self._log("设置备份失败：%s" % e)
        if p:
            self._refresh_cfg_hint()
            self._log("设置已备份：%s" % p)
            QMessageBox.information(
                self, "已备份设置",
                "这份设置已存到：\n%s\n\n升级后想换回来，点「恢复最近备份」就行。"
                % p)
        else:
            QMessageBox.warning(
                self, "备份失败",
                "没能写出备份文件，检查一下这个目录能不能写：\n%s"
                % getattr(config, "BACKUP_DIR", ""))

    def _restore_config(self):
        try:
            items = config.list_backups()
        except Exception:
            items = []
        if not items:
            QMessageBox.information(
                self, "没有备份",
                "还没有可恢复的备份。先点「备份当前设置」，"
                "或者升级一次后系统会自动留一份。")
            return
        newest = items[0]
        ok = QMessageBox.question(
            self, "恢复设置",
            "会用这份备份覆盖当前设置：\n%s\n\n现在的内容会先另存一份再覆盖。继续吗？"
            % os.path.basename(newest),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ok != QMessageBox.Yes:
            return
        try:
            self.config.backup("恢复前")
        except Exception:
            pass
        ok2 = False
        try:
            ok2 = self.config.restore(newest)
        except Exception as e:
            self._log("恢复设置失败：%s" % e)
        if ok2:
            self._refresh_cfg_hint()
            self._log("设置已恢复：%s" % newest)
            QMessageBox.information(
                self, "已恢复",
                "设置已经换成这份备份的内容。重启启动器后全部生效"
                "（当前这次运行里有些选项要重新打开才看得见）。")
        else:
            QMessageBox.warning(self, "恢复失败",
                                "这个备份文件读不出来：\n%s" % newest)

    def _open_config_backups(self):
        d = getattr(config, "BACKUP_DIR", "")
        try:
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            if platform_utils.WINDOWS:
                os.startfile(d)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", d])
        except Exception as e:
            QMessageBox.warning(self, "打不开这个目录",
                                "备份目录：\n%s\n\n%s" % (d, e))

    def _pack_logs_quick(self):
        """不弹保存框：日志 + 崩溃报告 + 环境报告 + 模组清单直接打到桌面。

        config.json 里有登录令牌，仍然不收。成功返回 zip 路径，失败抛异常。
        """
        out = os.path.join(self._desktop_dir(),
                           "OMC日志_%s.zip" % time.strftime("%Y%m%d_%H%M%S"))
        gd = self.config.get("game_dir") or ""
        n = 0
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            tail = "\n".join(getattr(self, "_log_lines", []) or [])
            z.writestr("launcher_log.txt",
                       "OMC %s\n%s\n" % (update.VERSION, tail))
            n += 1
            try:
                z.writestr("env_report.txt", syscheck.report_text())
                n += 1
            except Exception as e:
                z.writestr("env_report.txt", "环境报告生成失败：%s" % e)
                n += 1
            if gd:
                lp = os.path.join(gd, "logs", "latest.log")
                if os.path.isfile(lp):
                    z.write(lp, "game/latest.log")
                    n += 1
                cr = os.path.join(gd, "crash-reports")
                if os.path.isdir(cr):
                    files = sorted(
                        (os.path.join(cr, f) for f in os.listdir(cr)
                         if f.lower().endswith((".txt", ".log"))),
                        key=os.path.getmtime, reverse=True)[:5]
                    for p in files:
                        z.write(p, "game/crash-reports/" + os.path.basename(p))
                        n += 1
                md = os.path.join(gd, "mods")
                if os.path.isdir(md):
                    rows = []
                    for f in sorted(os.listdir(md)):
                        p = os.path.join(md, f)
                        if os.path.isfile(p):
                            rows.append("%s\t%d B" % (f, os.path.getsize(p)))
                    z.writestr("game/mods.txt", "\n".join(rows))
                    n += 1
        try:
            QApplication.clipboard().setText(out)
        except Exception:
            pass
        self._log("一键打包日志 → %s（%d 项）" % (out, n))
        return out

    def _open_local_path(self, path):
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
            return True
        except Exception as e:
            self._log("打开路径失败：%s" % e)
            return False

    def _on_backup_now(self):
        game_dir = self.config.get("game_dir")
        keep = int(self.combo_backup_keep.currentData() or 5)
        try:
            n = backup.backup_all(game_dir, keep, self._log)
        except Exception as e:
            QMessageBox.warning(self, "备份失败", str(e))
            return
        if not n:
            QMessageBox.information(self, "提示", "存档目录里还没有可备份的世界。")
            return
        QMessageBox.information(
            self, "备份完成",
            "已备份 %d 个存档。\n位置：%s" % (n, backup.backups_root(game_dir)))

    def _on_restore_backup(self):
        rows = backup.list_backups(self.config.get("game_dir"))
        if not rows:
            QMessageBox.information(
                self, "还没有备份",
                "开启「启动前自动备份」后，每次进游戏前都会自动备份；\n"
                "也可以点「立即备份存档」先存一份。")
            return
        labels = ["%s　%s　%.1f MB" % (r[0], r[1], r[3]) for r in rows]
        text, ok = QInputDialog.getItem(self, "还原存档", "选择要还原的备份：",
                                        labels, 0, False)
        if not ok or not text:
            return
        idx = labels.index(text)
        world, stamp, path, _mb = rows[idx]
        if QMessageBox.question(
                self, "确认还原",
                "把 %s 的备份（%s）复制回存档目录？\n"
                "原有存档不会被覆盖，会另存为带后缀的新存档。"
                % (world, stamp)) != QMessageBox.Yes:
            return
        try:
            name = backup.restore(self.config.get("game_dir"), path, self._log)
        except Exception as e:
            QMessageBox.critical(self, "还原失败", str(e))
            return
        QMessageBox.information(self, "已还原", "存档已还原为：" + name)

    def _version_choices(self):
        vids = [it.get("id") for it in (self.version_data or []) if it.get("id")]
        if not vids:
            try:
                base = os.path.join(self.config.get("game_dir"), "versions")
                vids = sorted(os.listdir(base)) if os.path.isdir(base) else []
            except Exception:
                vids = []
        return vids

    # ---------- 杀毒白名单 ----------
    def _on_add_av_exclusion(self):
        if not avguard.supported():
            QMessageBox.information(self, "提示", "只有 Windows 需要这一步。")
            return
        self._log("正在请求加入杀毒白名单（系统弹出确认时请点「是」）")
        self._av_worker = self._track(AvWhitelistWorker())
        self._av_worker.done.connect(self._on_av_done)
        self._av_worker.start()

    def _on_av_done(self, ok, msg):
        # 问过一次就不再问（成功、失败、取消都算问过），要再加去设置里点
        try:
            self.config.set("av_ask_skip", True)
            if ok:
                self.config.set("av_whitelisted", True)
            self.config.save()
        except Exception:
            pass
        if ok:
            self._log("白名单：" + msg)
            QMessageBox.information(
                self, "已加入",
                msg + "\n\n以后更新覆盖文件也不会再被杀毒软件拦。")
        else:
            self._log("白名单没加成：" + msg)
            QMessageBox.warning(self, "没加成功", msg)

    def _maybe_ask_av(self):
        """打包版首次运行时问一次，不重复骚扰。"""
        if not avguard.supported() or not getattr(sys, "frozen", False):
            return
        if self.config.get("av_whitelisted") or self.config.get("av_ask_skip"):
            return
        # 已经加过（不管是本程序加的、批处理加的，还是手动在 Defender 里加的）
        # 就别再问第二遍
        try:
            if avguard.already_excluded():
                self.config.set("av_whitelisted", True)
                self.config.save()
                self._log("检测到已在杀毒白名单里，不再提示")
                return
        except Exception:
            pass
        if getattr(self, "_av_prompt_open", False):
            return
        self._av_prompt_open = True
        try:
            box = QMessageBox(self)
            box.setWindowTitle("加入杀毒白名单")
            box.setIcon(QMessageBox.Question)
            box.setText("要不要把启动器加入杀毒软件白名单？")
            box.setInformativeText(
                "不点也能正常用；万一被杀毒软件误杀导致启动不了，可以随时在设置里点"
                "「加入杀毒白名单」。这一步需要管理员确认一次。")
            b_yes = box.addButton("现在加入", QMessageBox.AcceptRole)
            b_no = box.addButton("不用了", QMessageBox.RejectRole)
            box.exec_()
            if box.clickedButton() is b_yes:
                self._on_add_av_exclusion()
            elif box.clickedButton() is b_no:
                # 只有明确点了「不用了」才记住不再问；直接按 Esc / 关掉不算拒绝，
                # 下次启动还会再问一次，免得用户手滑关掉后再也看不到这个入口。
                try:
                    self.config.set("av_ask_skip", True)
                    self.config.save()
                except Exception:
                    pass
        finally:
            self._av_prompt_open = False

    def _run_integrity_check(self):
        vids = self._version_choices()
        if not vids:
            QMessageBox.information(self, "提示", "还没有安装任何版本。")
            return
        cur = self._selected_version_id() or vids[0]
        idx = vids.index(cur) if cur in vids else 0
        vid, ok = QInputDialog.getItem(self, "完整性校验", "选择版本：",
                                       vids, idx, False)
        if not ok or not vid:
            return
        json_path = self._version_json_path(vid)
        if not os.path.exists(json_path):
            QMessageBox.warning(self, "提示", "版本信息缺失，先下载安装。")
            return
        self._log("开始校验版本 %s ......" % vid)
        try:
            problems = launcher.check_ready(json_path, self.config.get("game_dir"))
        except Exception as e:
            QMessageBox.critical(self, "校验失败", str(e))
            return
        if not problems:
            QMessageBox.information(self, "校验通过",
                                    "%s 的文件完整，可以直接启动。" % vid)
            self._log("校验通过：" + vid)
            return
        if QMessageBox.question(
                self, "发现缺文件",
                "%s 缺少或损坏 %d 项：\n\n%s\n\n要现在重新下载补齐吗？"
                % (vid, len(problems), "\n".join(problems[:8])) ) == QMessageBox.Yes:
            self._start_install(vid)

    def _refresh_shortcut_label(self):
        """把「桌面上到底有没有」写在标签里，不用点开才知道。"""
        try:
            st = shortcut.shortcut_state()
        except Exception as e:
            self.lbl_shortcut.setText("读不到桌面路径：%s" % e)
            return
        if not st["supported"]:
            self.lbl_shortcut.setText(
                "这个系统不用生成快捷方式：macOS 直接把 OMC.app 拖进「应用程序」就行。")
        elif st["exists"]:
            self.lbl_shortcut.setText("桌面上已经有「%s」了：%s"
                                      % (shortcut.SHORTCUT_NAME, st["path"]))
        else:
            self.lbl_shortcut.setText("桌面上现在没有「%s」的图标，点下面的按钮补一个。"
                                      % shortcut.SHORTCUT_NAME)

    def _add_desktop_shortcut(self):
        """手动补一个桌面快捷方式（已存在时问要不要重建）。"""
        st = shortcut.shortcut_state()
        if not st["supported"]:
            QMessageBox.information(
                self, "不需要快捷方式",
                "macOS 上把 OMC.app 拖进「应用程序」文件夹就行，"
                "系统会自己给它加入启动台，不需要单独建快捷方式。")
            return
        force = False
        if st["exists"]:
            ans = QMessageBox.question(
                self, "桌面上已经有了",
                "桌面上已经有「%s」了：\n%s\n\n要覆盖重建一份吗？"
                % (shortcut.SHORTCUT_NAME, st["path"]),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans != QMessageBox.Yes:
                self._refresh_shortcut_label()
                return
            force = True

        # 源码运行也允许建：指向当前解释器 + main.py，双击就能开
        lnk = shortcut.ensure_desktop_shortcut(force=force, allow_source=True)
        if lnk and os.path.exists(lnk):
            self._refresh_shortcut_label()
            QMessageBox.information(self, "已添加到桌面",
                                    "已经建好了：\n%s\n\n"
                                    "如果桌面看不到，按 F5 刷新一下桌面再找。" % lnk)
        else:
            QMessageBox.warning(
                self, "没建成",
                "快捷方式没能创建成功。常见原因：\n"
                "1. 桌面被 OneDrive / 企业策略重定向了；\n"
                "2. 安全软件拦了脚本（这里是用 PowerShell 调 WScript.Shell 建的 .lnk）；\n"
                "3. 桌面目录不可写。\n\n"
                "可以先手动把程序目录里的 OMC.exe 拖一份到桌面，效果一样。")

    def _show_syscheck(self):
        """把启动前那套自检结果给用户看一遍（同一个 syscheck 模块，结果一致）。"""
        try:
            res = syscheck.checks()
            text = syscheck.report_text(res)
        except Exception as e:
            QMessageBox.critical(self, "自检失败", str(e))
            return
        box = QMessageBox(self)
        box.setWindowTitle("兼容性自检")
        box.setIcon(QMessageBox.Warning if res["blockers"] else QMessageBox.Information)
        box.setText("跑不起来" if res["blockers"] else "能跑")
        box.setDetailedText(text)
        box.setStandardButtons(QMessageBox.Ok)
        box.exec_()

    def _analyze_crash(self):
        game_dir = self.config.get("game_dir")
        try:
            res = crashlog.analyze_game_dir(game_dir)
        except Exception as e:
            QMessageBox.critical(self, "分析失败", str(e))
            return
        if not res.get("source"):
            QMessageBox.information(
                self, "没有找到日志",
                "游戏目录里没有 crash-reports 或 logs/latest.log。\n先启动一次游戏再看。")
            return
        lines = ["日志：%s" % res["source"], ""]
        if res["hits"]:
            for verdict, advice, _snip in res["hits"][:4]:
                lines.append("● %s" % verdict)
                lines.append("   " + advice)
        else:
            lines.append("没匹配到常见问题，看下面的日志末尾。")
        if res["suspects"]:
            lines.append("")
            lines.append("日志里出现的模组/关键字：" + "、".join(res["suspects"][:8]))
        lines.append("")
        lines.append("日志末尾：")
        lines.extend("  " + ln for ln in res["tail"][-6:])
        box = QMessageBox(self)
        box.setWindowTitle("崩溃日志分析")
        box.setIcon(QMessageBox.Warning if res["hits"] else QMessageBox.Information)
        box.setText("\n".join(lines[:40]))
        box.setDetailedText("\n".join(res["tail"]))
        box.exec_()

    def _check_mod_updates(self):
        game_dir = self.config.get("game_dir")
        if not mods.list_mods(game_dir):
            QMessageBox.information(self, "提示", "mods 目录里还没有模组。")
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self._log("开始检查模组更新......")
            items = modupdate.check(game_dir, self._log)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "检查失败", str(e))
            return
        finally:
            QApplication.restoreOverrideCursor()
        if not items:
            QMessageBox.information(
                self, "都是最新",
                "Modrinth 上认出来的模组都已经是最新版本。\n"
                "（只有 Modrinth 收录的模组才能查，自制模组查不到属正常）")
            return
        lines = ["%d 个模组有更新：" % len(items), ""]
        for it in items[:20]:
            lines.append("%s：%s -> %s"
                         % (it["file"] or it["project"],
                            it["current_version"], it["latest_version"]))
        if any(it["url"] for it in items):
            lines.append("")
            lines.append("下载链接：")
            for it in items[:5]:
                if it["url"]:
                    lines.append(it["url"])
        box = QMessageBox(self)
        box.setWindowTitle("模组更新")
        box.setText("\n".join(lines[:40]))
        box.setDetailedText("\n".join(it["url"] for it in items if it["url"]))
        box.exec_()

    def _open_servers(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("收藏服务器")
        dlg.resize(600, 420)
        v = QVBoxLayout(dlg)
        lst = QListWidget()
        v.addWidget(lst, 1)

        def refresh():
            lst.clear()
            items = servers.list_servers()
            for it in items:
                row = QListWidgetItem("%s　%s:%s"
                                      % (it.get("name"), it.get("host"),
                                         it.get("port")))
                row.setData(Qt.UserRole, (it.get("host"),
                                          int(it.get("port") or 25565)))
                lst.addItem(row)
            if not items:
                lst.addItem("还没有收藏服务器，点下面的「添加」")

        def add():
            text, ok = QInputDialog.getText(
                dlg, "添加服务器",
                "地址（例如 mc.hypixel.net 或 1.2.3.4:25565）：")
            if not ok or not text.strip():
                return
            try:
                servers.add("", text.strip())
            except Exception as e:
                QMessageBox.warning(dlg, "添加失败", str(e))
                return
            refresh()

        def remove():
            row = lst.currentRow()
            if row < 0:
                return
            if servers.remove(row):
                refresh()

        def ping_all():
            for i in range(lst.count()):
                item = lst.item(i)
                data = item.data(Qt.UserRole)
                if not data:
                    continue
                res = servers.ping({"host": data[0], "port": data[1]})
                if res["online"]:
                    item.setText("%s:%s　在线 %s　%d ms　%s"
                                 % (data[0], data[1], res["players"],
                                    res["latency"], res["version"]))
                else:
                    item.setText("%s:%s　离线 / 无响应" % (data[0], data[1]))

        def join():
            row = lst.currentRow()
            item = lst.item(row) if row >= 0 else None
            data = item.data(Qt.UserRole) if item else None
            if not data:
                return
            dlg.accept()
            self._join_endpoint(data[0], data[1])

        btns = QHBoxLayout()
        for text, fn in (("添加", add), ("删除", remove),
                         ("刷新状态", ping_all), ("进服", join)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            btns.addWidget(b)
        v.addLayout(btns)
        refresh()
        dlg.exec_()

    # ---------- 托盘 ----------
    def _ensure_tray(self):
        tray = getattr(self, "_tray", None)
        if tray:
            return tray
        icon = self.windowIcon()
        if icon.isNull():
            icon = QApplication.style().standardIcon(
                QStyle.SP_ComputerIcon)
        tray = QSystemTrayIcon(icon, self)
        tray.setToolTip("OMC 启动器")
        menu = QMenu()
        act_show = menu.addAction("显示启动器")
        act_show.triggered.connect(self._restore_from_tray)
        act_quit = menu.addAction("退出")
        act_quit.triggered.connect(self._quit_from_tray)
        tray.setContextMenu(menu)
        tray.activated.connect(lambda _r: self._restore_from_tray())
        tray.show()
        self._tray = tray
        return tray

    def _on_tray_toggled(self, on):
        self.config.set("minimize_to_tray", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        if on:
            self._ensure_tray()

    def _on_bg_dim_changed(self, val):
        """壁纸亮度：负值提亮、正值压暗；拖动时只改画面（不写盘），松手再存。"""
        try:
            val = int(val)
            if getattr(self, "backdrop", None) is not None:
                self.backdrop.dim = max(0, val)
                self.backdrop.lift = max(0, -val)
                self.backdrop.update()
        except Exception:
            pass
        try:
            self.config.set("bg_dim", int(val))
        except Exception:
            pass
        if getattr(self, "lbl_bgdim", None) is not None:
            if int(val) < 0:
                self.lbl_bgdim.setText(
                    "壁纸提亮 %d%%（比原图更亮）"
                    % int(round(-int(val) / 40.0 * 100)))
            elif int(val) == 0:
                self.lbl_bgdim.setText("壁纸原亮度（跟之前一样亮）")
            else:
                pct = int(round(int(val) / 255.0 * 100))
                self.lbl_bgdim.setText("壁纸压暗 %d%%" % pct)

    def _save_bg_dim(self):
        try:
            self.config.save()
        except Exception:
            pass

    def _flush_config(self):
        """把 config.set 过但没 save 的改动统一写盘（定时器 + 关窗都会调）。"""
        try:
            if hasattr(self.config, "flush"):
                self.config.flush()
            else:
                self.config.save()
        except Exception:
            pass

    def _on_autostart_toggled(self, on):
        ok, msg = (autostart.enable() if on else autostart.disable())
        if getattr(self, "lbl_autostart", None) is not None:
            self.lbl_autostart.setText(msg)
        self._log("开机自启：" + msg)
        if not ok:
            # 没设上就把勾去掉，别让界面显示一个假状态
            try:
                self.chk_autostart.blockSignals(True)
                self.chk_autostart.setChecked(not on)
                self.chk_autostart.blockSignals(False)
            except RuntimeError:
                pass

    def _on_trailer_toggled(self, on):
        self.config.set("trailer_on", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        self._log("启动页预告片：" + ("开" if on else "关（下次启动不再加载播放器）"))
        if not on:
            card = getattr(self, "trailer_card", None)
            if card is not None:
                try:
                    card.setParent(None)
                    card.deleteLater()
                except RuntimeError:
                    pass
                self.trailer_card = None

    def _fill_recommended_mem(self):
        """按物理内存和当前选中的版本算一个合适值，直接填到滑杆上。"""
        vid = ""
        try:
            it = self.local_list.currentItem()
            if it is not None:
                vid = it.data(Qt.UserRole) or ""
        except Exception:
            vid = ""
        vid = vid or (self.config.get("last_version") or "")
        try:
            mb, reason = memrec.recommend(self.config.get("game_dir"), vid)
        except Exception as e:
            self.lbl_mem_rec.setText("推荐失败：%s" % e)
            return
        self.slider_mem.setValue(int(mb))
        self.lbl_mem_rec.setText("已填 %d MB%s" % (mb, ("：" + reason) if reason else ""))
        self._log("内存按本机推荐填成 %d MB（%s）" % (mb, vid or "没选版本"))

    def _on_anim_toggled(self, on):
        self.config.set("anim_on", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        self._log("启动动画：" + ("开" if on else "关（窗口直接出现，不淡入）"))

    def _on_modcheck_toggled(self, on):
        self.config.set("mod_precheck", bool(on))
        try:
            self.config.save()
        except Exception:
            pass
        self._log("启动前模组检查：" + ("开" if on else "关"))

    def _play_intro_anim(self):
        """内容轻微淡入；关掉动画就什么都不做，页面直接出现。"""
        if self.config.get("anim_on") is False:
            return
        try:
            target = getattr(self, "stack", None) or self.centralWidget()
        except Exception:
            target = None
        if target is None:
            return
        try:
            from PySide6.QtCore import QPropertyAnimation, QEasingCurve
            from PySide6.QtWidgets import QGraphicsOpacityEffect
            eff = QGraphicsOpacityEffect(target)
            eff.setOpacity(0.72)
            target.setGraphicsEffect(eff)
            anim = QPropertyAnimation(eff, b"opacity", self)
            anim.setDuration(240)
            anim.setStartValue(0.72)
            anim.setEndValue(1.0)
            anim.setEasingCurve(QEasingCurve.OutCubic)

            def _done():
                try:
                    target.setGraphicsEffect(None)
                except Exception:
                    pass

            anim.finished.connect(_done)
            anim.start()
            # 兜底：就算动画因为窗口被遮挡之类没跑完，0.42 秒后也把效果收掉
            QTimer.singleShot(420, _done)
            self._intro_anim = anim
        except Exception as e:
            try:
                target.setGraphicsEffect(None)
            except Exception:
                pass
            self._log("启动动画没播成（直接显示）：%s" % e)

    def _announce_presence(self, status="launcher"):
        """把自己的在线状态挂到好友目录：launcher=开着启动器，game=正在游戏。"""
        try:
            if self.config.get("dir_allow") is False:
                return
            from core import accounts
            name = (accounts.current_name() or "").strip()
            if not name:
                name = (self.config.get("username") or "").strip()
            if not name:
                return
            uid = (accounts.find(name) or {}).get("id") or name
            threading.Thread(target=frienddir.announce,
                             args=(name, uid, True, status), daemon=True).start()
        except Exception as e:
            self._log("广播在线状态失败：%s" % e)

    def _presence_text(self, name):
        """好友行后面的状态文字：正在游戏 / 在启动器 / 多久前在线。"""
        row = (getattr(self, "_presence", {}) or {}).get((name or "").strip())
        if not row:
            return ""
        try:
            ago = max(0, int(time.time() - int(row.get("ts") or 0)))
        except Exception:
            ago = 0
        if ago < 900:
            return "正在游戏" if row.get("st") == "game" else "在启动器"
        if ago < 3600:
            return "%d 分钟前在线" % (ago // 60)
        return "%d 小时前在线" % (ago // 3600)

    def _refresh_presence(self):
        """拉一次好友目录，把谁在启动器、谁在游戏里记下来。"""
        self.fsearch_state.setText("正在刷新在线状态…")
        self._friend_search = FriendSearchWorker("", [])
        self._friend_search.done.connect(self._on_presence)
        self._friend_search.start()

    def _on_presence(self, hits):
        self._presence = {}
        for h in hits or []:
            n = (h.get("name") or "").strip()
            if n:
                self._presence[n] = {"ts": h.get("ts") or 0,
                                     "st": h.get("st") or "launcher"}
        online = sum(1 for r in self._presence.values()
                     if time.time() - (r.get("ts") or 0) < 900)
        self.fsearch_state.setText(
            "在线面板已刷新：%d 个账号最近 15 分钟内活动过" % online)
        self._reload_friends()

    def _restore_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _quit_from_tray(self):
        self._force_quit = True
        # 真退出：闹钟还想响就提示一句，让用户知道关了就没了
        try:
            n = self.alarm_svc().active_count()
            if n:
                rest = QMessageBox.question(
                    self, "还有闹钟没到点",
                    "你还有 %d 个闹钟/计时器没到点。现在退出，它们就不会响了。"
                    "\n\n要退出吗？" % n,
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if rest != QMessageBox.Yes:
                    self._force_quit = False
                    return
        except Exception:
            pass
        self.close()
        try:
            QApplication.quit()
        except Exception:
            pass

    def _save_settings(self):
        old_lang = self.config.get("language") or "zh_CN"
        self.config.set("game_dir", self.input_gamedir.text().strip())
        self.config.set("java_path", self.input_java.text().strip())
        self.config.set("memory_mb", int(self.slider_mem.value()))
        self.config.set("mirror", self._current_mirror())
        self.config.set("language", self.combo_language.currentData())
        self.config.set("username", self.input_name.text().strip())
        if hasattr(self, "input_update_url"):
            self.config.set("update_url", self.input_update_url.text().strip())
        if hasattr(self, "combo_jvm"):
            self.config.set("jvm_template", self.combo_jvm.currentData() or "none")
        if hasattr(self, "check_auto_backup"):
            self.config.set("auto_backup", bool(self.check_auto_backup.isChecked()))
        if hasattr(self, "combo_backup_keep"):
            self.config.set("backup_keep",
                            int(self.combo_backup_keep.currentData() or 5))
        if hasattr(self, "combo_auto_backup_int"):
            self.config.set("auto_backup_interval",
                            int(self.combo_auto_backup_int.currentData() or 0))
        if hasattr(self, "check_multi"):
            self.config.set("multi_instance", bool(self.check_multi.isChecked()))
        if hasattr(self, "check_tray"):
            self.config.set("minimize_to_tray",
                            bool(self.check_tray.isChecked()))
        if hasattr(self, "input_autoserver"):
            self.config.set("auto_join_server",
                            self.input_autoserver.text().strip())
        self.config.save()
        self._update_install_state()
        # 游戏目录/间隔可能变了，把后台备份线程按新配置重启
        self._start_autobackup()
        # 换了界面语言：光提示「重启生效」多数人不会真去重启，直接问一句帮他重启
        new_lang = self.config.get("language") or "zh_CN"
        if new_lang != old_lang:
            ans = QMessageBox.question(
                self, i18n.tr("lang_restart_title"),
                i18n.tr("lang_restart_body"),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if ans == QMessageBox.Yes:
                self._restart_app()
                return
        QMessageBox.information(self, "已保存",
                                "设置已保存\n" + i18n.tr("restart_hint"))

    def _restart_app(self):
        """重启自己：先把新进程拉起来，再干净退出（否则改了语言的界面看着没反应）。"""
        import sys as _sys
        from PySide6.QtCore import QProcess
        try:
            if getattr(_sys, "frozen", False):
                QProcess.startDetached(_sys.executable, [])
            else:
                QProcess.startDetached(_sys.executable,
                                       [_sys.argv[0]] + _sys.argv[1:])
        except Exception:
            return
        self._force_quit = True
        try:
            self.shutdown()
            self._stop_autobackup()
            hotkeys.stop()
        except Exception:
            pass
        self.close()
        try:
            QApplication.quit()
        except Exception:
            pass

    def closeEvent(self, event):
        # 录屏还在跑就先停掉，别让半截文件烂在硬盘上
        try:
            rp = getattr(getattr(self, "toolbox_page", None),
                         "record_page", None)
            if rp is not None:
                rp.shutdown()
        except Exception:
            pass
        # 走之前把没写盘的设置补上（闹钟缩托盘的路径也算「离开界面」）
        self._flush_config()
        # 有闹钟/计时器还没到点：不能真退，否则闹钟就永远响不了
        # （用户明确要求：关掉软件闹钟也要响）
        pending_alarm = False
        try:
            pending_alarm = self.alarm_svc().active_count() > 0
        except Exception:
            pending_alarm = False
        if pending_alarm and not getattr(self, "_force_quit", False):
            try:
                self._ensure_tray()
                self.hide()
                try:
                    self._tray.showMessage(
                        "OMC 还开着",
                        "你还有闹钟/计时器没到点，我把它缩到托盘里了，"
                        "到点照样响。")
                except Exception:
                    pass
                event.ignore()
                return
            except Exception:
                pass
        # 设置了「缩到托盘」就只隐藏窗口，游戏进程和手机控制台继续跑
        if (self.config.get("minimize_to_tray")
                and not getattr(self, "_force_quit", False)):
            try:
                self._ensure_tray()
                self.hide()
                event.ignore()
                return
            except Exception:
                pass
        self.shutdown()
        # 关掉后台线程和热键，别让进程退不干净
        self._stop_autobackup()
        try:
            hotkeys.stop()
        except Exception:
            pass
        try:
            self.config.set("username", self.input_name.text().strip())
            self.config.save()
        except Exception:
            pass
        event.accept()
