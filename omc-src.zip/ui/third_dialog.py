# -*- coding: utf-8 -*-
"""第三方（Yggdrasil）登录 / 注册对话框。自建服务器也能用。

要点：
- 所有联网动作走后台线程，按钮期间置灰 + 显示「正在…」，不会再出现点了没反应
- 地址框旁边一个状态灯，改完地址自动探一次（绿=通、黄=探测中、红=连不上）
- 登录成功后停在窗口里，把角色名 / UUID 摆出来，能复制，确认无误再点「完成绑定」
- 注册成功接着自动登录，少点一次按钮
"""
import re
import threading

from PySide6.QtCore import Qt, QObject, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QVBoxLayout, QWidget)

from core import yggdrasil

from .captcha_dialog import require_human

_CARD_QSS = "QDialog#Card{background:#1E2128;}"

SERVERS = [
    ("我自己搭的（本机 8080）", "http://127.0.0.1:8080/api/yggdrasil"),
    ("LittleSkin", "https://littleskin.cn/api/yggdrasil"),
    ("McSkin", "https://mcskin.cn/api/yggdrasil"),
    ("Ely.by", "https://account.ely.by/api/authlib-injector"),
]

# 网页版登录中心：不用开启动器也能注册 / 验证账号
REGISTER_SITE = ("https://link.wtturl.cn/?target=https%3A%2F%2Fyituoyuanzidan.github.io"
                 "%2Fomc-login%2F&scene=im&aid=582478&lang=zh")

# 地址只允许 URL 安全字符，避免把「我自己搭的（本机 8080）」这种中文标签当域名发出去
_URL_OK = re.compile(r"https?://[A-Za-z0-9._:/\-~%+]+$", re.I)

_LAMP_STYLE = {
    "idle": "background:#5A6272;",
    "wait": "background:#FBBF24;",
    "ok": "background:#4ADE80;",
    "bad": "background:#F87171;",
}


def _url_ok(u):
    return bool(u) and bool(_URL_OK.match(u)) and " " not in u


class _Sig(QObject):
    """后台线程把结果丢回主线程用（Qt 会自动排队）。"""
    done = Signal(str, object)


class ThirdAuthDialog(QDialog):
    """填地址 + 用户名 + 密码 → 登录；也能在上一步先注册新账号。

    成功后 self.acct 是启动器账号字典。
    """

    def __init__(self, parent=None, api="", user=""):
        super().__init__(parent)
        self.acct = None
        self._alive = True
        self._busy = False
        self.setObjectName("Card")
        self.setWindowTitle("第三方登录 / 注册")
        self.setStyleSheet(_CARD_QSS)
        self.setMinimumWidth(520)

        self._sig = _Sig()
        self._sig.done.connect(self._on_done)

        v = QVBoxLayout(self)
        v.setSpacing(10)
        head = QLabel("用外置登录服务器（Yggdrasil）。自己搭的服务器也能填，"
                      "但服务器要在跑，地址形如 http://127.0.0.1:8080/api/yggdrasil。")
        head.setWordWrap(True)
        v.addWidget(head)

        f = QFormLayout()
        f.setSpacing(8)

        srow = QHBoxLayout()
        srow.setSpacing(6)
        self.cb_api = QComboBox()
        self.cb_api.setEditable(True)
        self.cb_api.setToolTip("从下拉里选一个现成的，或者直接粘贴自己的地址")
        # 自己收藏/保存过的地址排第一项，名字叫「我的第三方登录」
        mine = (api or "").strip()
        items = list(SERVERS)
        if mine and all(mine != u for _l, u in items):
            items.insert(0, ("我的第三方登录", mine))
        else:
            items.insert(0, ("我的第三方登录", mine or SERVERS[0][1]))
        for label, url in items:
            self.cb_api.addItem(label, url)
        self.cb_api.setEditText(mine or SERVERS[0][1])
        self.cb_api.editTextChanged.connect(self._on_api_edited)
        srow.addWidget(self.cb_api, 1)

        self.btn_paste = QPushButton("粘贴")
        self.btn_paste.setFixedWidth(56)
        self.btn_paste.setToolTip("从剪贴板取地址（别人发你的地址直接复制过来点这里）")
        self.btn_paste.clicked.connect(self._paste)
        srow.addWidget(self.btn_paste)

        self.lamp = QLabel()
        self.lamp.setFixedSize(10, 10)
        self.lamp.setToolTip("灰=没探过，黄=正在探，绿=连得上，红=连不上")
        srow.addWidget(self.lamp)
        f.addRow("服务器", self._wrap(srow))

        # 这一行就是「网页版注册入口」：地址选好之后想建号，直接开浏览器
        site_row = QHBoxLayout()
        site_row.setSpacing(6)
        self.btn_site = QPushButton("打开网页版登录中心")
        self.btn_site.setToolTip("还没账号就在这里注册；注册完回来点「登录并绑定」\n" + REGISTER_SITE)
        self.btn_site.clicked.connect(self._open_site)
        site_row.addWidget(self.btn_site)
        self.lbl_link = QLabel(
            '<a style="color:#4ADE80" href="%s">yituoyuanzidan.github.io/omc-login</a>'
            % REGISTER_SITE)
        self.lbl_link.setOpenExternalLinks(True)
        self.lbl_link.setWordWrap(False)
        self.lbl_link.setToolTip("网页版登录中心：" + REGISTER_SITE)
        site_row.addWidget(self.lbl_link, 1)
        f.addRow("登录中心", self._wrap(site_row))

        self.in_user = QLineEdit(user)
        self.in_user.setPlaceholderText("这个服务器上的用户名")
        self.in_user.returnPressed.connect(self._go)
        f.addRow("用户名", self.in_user)

        self.in_pwd = QLineEdit()
        self.in_pwd.setEchoMode(QLineEdit.Password)
        self.in_pwd.setPlaceholderText("密码（至少 6 位）")
        self.in_pwd.returnPressed.connect(self._go)
        prow = QHBoxLayout()
        prow.setSpacing(6)
        prow.addWidget(self.in_pwd, 1)
        self.btn_eye = QPushButton("显示")
        self.btn_eye.setFixedWidth(56)
        self.btn_eye.setCheckable(True)
        self.btn_eye.setToolTip("看看密码有没有打错")
        self.btn_eye.toggled.connect(self._toggle_pwd)
        prow.addWidget(self.btn_eye)
        f.addRow("密码", self._wrap(prow))

        self.in_email = QLineEdit()
        self.in_email.setPlaceholderText("只在注册新账号时用")
        self.in_email.returnPressed.connect(self._go)
        f.addRow("邮箱", self.in_email)
        v.addLayout(f)

        self.state = QLabel("")
        self.state.setObjectName("PageSub")
        self.state.setWordWrap(True)
        self.state.setTextInteractionFlags(Qt.TextSelectableByMouse)
        v.addWidget(self.state)

        # 登录成功后的结果卡（角色名 / UUID / 复制）
        self.card = QWidget()
        self.card.setVisible(False)
        cv = QVBoxLayout(self.card)
        cv.setContentsMargins(10, 8, 10, 8)
        cv.setSpacing(6)
        self.lbl_who = QLabel("")
        self.lbl_who.setStyleSheet("font-size:15px;font-weight:700;color:#FFFFFF;")
        cv.addWidget(self.lbl_who)
        self.lbl_uuid = QLabel("")
        self.lbl_uuid.setObjectName("PageSub")
        self.lbl_uuid.setWordWrap(True)
        self.lbl_uuid.setTextInteractionFlags(Qt.TextSelectableByMouse)
        cv.addWidget(self.lbl_uuid)
        crow = QHBoxLayout()
        self.btn_copy_uuid = QPushButton("复制 UUID")
        self.btn_copy_uuid.clicked.connect(self._copy_uuid)
        crow.addWidget(self.btn_copy_uuid)
        crow.addStretch(1)
        cv.addLayout(crow)
        self.card.setStyleSheet("QWidget{background:#252A33;border-radius:8px;}")
        v.addWidget(self.card)

        row = QHBoxLayout()
        self.btn_test = QPushButton("测试连接")
        self.btn_test.setToolTip("先看看这个地址通不通；连不上会把原因写清楚（防火墙 / 端口 / 路径）")
        self.btn_test.clicked.connect(self._test)
        row.addWidget(self.btn_test)
        self.btn_reg = QPushButton("在这个服务器注册")
        self.btn_reg.clicked.connect(self._register)
        row.addWidget(self.btn_reg)
        row.addStretch(1)
        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_cancel)
        self.btn_login = QPushButton("登录并绑定")
        self.btn_login.setObjectName("PrimaryButton")
        self.btn_login.clicked.connect(self._go)
        row.addWidget(self.btn_login)
        v.addLayout(row)

        self._tone("idle")
        self._sync_reg_btn()
        self._api_used = ""
        self._probe_timer = QTimer(self)
        self._probe_timer.setSingleShot(True)
        self._probe_timer.setInterval(700)
        self._probe_timer.timeout.connect(self._auto_probe)
        QTimer.singleShot(300, self._auto_probe)      # 打开就先探一下存着的地址

    # ---------- 小工具 ----------
    @staticmethod
    def _wrap(layout):
        w = QWidget()
        layout.setContentsMargins(0, 0, 0, 0)
        w.setLayout(layout)
        return w

    def _toggle_pwd(self, shown):
        self.in_pwd.setEchoMode(QLineEdit.Normal if shown else QLineEdit.Password)
        self.btn_eye.setText("隐藏" if shown else "显示")

    def _tone(self, kind, tip=""):
        self.lamp.setStyleSheet("border-radius:5px;" + _LAMP_STYLE.get(kind, _LAMP_STYLE["idle"]))
        if tip:
            self.lamp.setToolTip(tip)

    def _set_btns(self, on):
        for b in (self.btn_test, self.btn_reg, self.btn_login, self.btn_paste):
            b.setEnabled(on)

    def _api(self):
        text = self.cb_api.currentText().strip()
        idx = self.cb_api.currentIndex()
        shown = (self.cb_api.itemText(idx) or "").strip() if idx >= 0 else ""
        data = (self.cb_api.currentData() or "").strip()
        # 下拉没被手动改过（框里显示的还是那一项的标题）→ 用它存的真实地址
        raw = data if (data and text == shown) else text
        if not raw:
            self.state.setText("先填服务器地址。")
            return ""
        api = yggdrasil.normalize_api(raw)
        if not _url_ok(api):
            self.state.setText(
                "这个地址不像网址：%s\n请填形如 http(s)://域名/api/yggdrasil 的地址，"
                "不要直接填服务器名字。" % api)
            return ""
        if api != text:
            self.cb_api.setEditText(api)
        return api

    def _paste(self):
        try:
            txt = (QApplication.clipboard().text() or "").strip()
        except Exception:
            txt = ""
        txt = txt.strip().strip('"').strip("'")
        if not txt:
            self.state.setText("剪贴板里没有地址。先复制服务器地址再点这里。")
            return
        if "\n" in txt:
            txt = txt.splitlines()[0].strip()
        self.cb_api.setEditText(txt)
        self.state.setText("已从剪贴板填入地址，正在探一下……")
        self._auto_probe()

    def _copy_uuid(self):
        uuid = (self.acct or {}).get("uuid", "")
        if not uuid:
            return
        try:
            QApplication.clipboard().setText(uuid)
            self.btn_copy_uuid.setText("已复制")
            QTimer.singleShot(1500, lambda: self.btn_copy_uuid.setText("复制 UUID"))
        except Exception:
            pass

    def _open_site(self):
        ok = QDesktopServices.openUrl(QUrl(REGISTER_SITE))
        if not ok:
            try:
                QApplication.clipboard().setText(REGISTER_SITE)
            except Exception:
                pass
            self.state.setText("浏览器没打开。链接已复制到剪贴板，粘到浏览器里访问即可：\n"
                               + REGISTER_SITE)
            return
        self.state.setText("已经在浏览器里打开登录中心了。注册完回来点「登录并绑定」。")

    # ---------- 后台任务 ----------
    def _start(self, kind, fn, quiet=False):
        if not quiet and self._busy:
            return
        if not quiet:
            self._busy = True
            self._set_btns(False)
            QApplication.setOverrideCursor(Qt.WaitCursor)
        t = threading.Thread(target=self._worker, args=(kind, fn), daemon=True)
        t.start()
    def _worker(self, kind, fn):
        try:
            res = fn()
            payload = (True, res)
        except Exception as e:                       # 网络/解析异常不许静默吞掉
            payload = (False, e)
        try:
            self._sig.done.emit(kind, payload)
        except RuntimeError:
            pass

    def _on_done(self, kind, payload):
        if not self._alive:
            return
        ok, res = payload
        if kind != "probe":
            self._busy = False
            self._set_btns(True)
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass

        if kind == "probe":
            real_ok, msg = res if isinstance(res, tuple) else (ok, str(res))
            self._tone("ok" if real_ok else "bad")
            if real_ok:
                self.state.setText("服务器在线：%s" % msg)
            elif (self.state.text().startswith("正在") or not self.state.text()
                  or "服务器在线" in self.state.text()):
                self.state.setText("地址暂时连不上。点「测试连接」看具体原因。")
            return

        if kind == "test":
            real_ok, msg = res if isinstance(res, tuple) else (ok, str(res))
            self._tone("ok" if real_ok else "bad")
            self.state.setText(str(msg))
            return

        if kind == "register":
            if ok:
                acct = res if isinstance(res, dict) else None
                if acct:
                    self.state.setText("注册成功，已经直接登上了。")
                    self._show_account(acct)
                else:
                    self.state.setText("注册成功，正在用刚填的密码登录……")
                    api, user, pwd = (self._api_used, self.in_user.text().strip(),
                                      self.in_pwd.text())
                    self._start("login", lambda: self._do_login(api, user, pwd))
            else:
                text = str(res)
                if "已经注册" in text:
                    text += "\n（账号已经有了，把密码填对直接点「登录并绑定」就行）"
                elif "没开注册接口" in text:
                    text += "\n（只有自建服务器能这样注册；公共皮肤站得去它自己的网页注册）"
                self.state.setText(text)
            return

        if kind == "login":
            if ok:
                self._show_account(res)
            else:
                try:
                    self.state.setText(self._friendly(res))
                except Exception as e:          # 兜底：别因为翻译失败就把错误吞掉
                    self.state.setText("登录没成功：%s" % res)
                    print("[third] friendly 出错：%s" % e)
                self._busy = False
                self._set_btns(True)
            return

    def _friendly(self, err):
        text = str(err)
        low = text.lower()
        # Yggdrasil 用 403 表示账号密码不对，别一律说成被防火墙挡了
        if "401" in text or "403" in text or "forbiddenoperation" in low:
            return "用户名或密码不对，或者这个账号还没在这台服务器上注册。"
        if "404" in text:
            return "这个地址没有认证接口（HTTP 404）。地址一般要是 http(s)://域名/api/yggdrasil。"
        if "timed out" in low or "timeout" in low:
            return "连接超时：服务器没响应，先点「测试连接」看看是不是被防火墙拦了。"
        return "登不上：%s" % text

    def _show_account(self, acct):
        self.acct = dict(acct or {})
        # 绑定那步会读 acct["api"]，这里就补齐，别让外层再猜
        if not self.acct.get("api"):
            self.acct["api"] = self.acct.get("api_url") or self._api()
        uuid = self.acct.get("uuid", "")
        dash = ("%s-%s-%s-%s-%s" % (uuid[0:8], uuid[8:12], uuid[12:16], uuid[16:20], uuid[20:])
                if len(uuid) == 32 else uuid)
        self.lbl_who.setText("角色：%s" % (self.acct.get("name") or ""))
        self.lbl_uuid.setText("UUID：%s" % dash)
        self.card.setVisible(True)
        self._tone("ok")
        self.state.setText("登录成功。确认是这个角色，就点「完成绑定」。")
        self.btn_login.setText("完成绑定")
        self.btn_login.setEnabled(True)
        self.btn_cancel.setText("先不绑")

    # ---------- 动作 ----------
    def _do_login(self, api=None, user=None, pwd=None):
        """登录取值都在主线程做好再传进来，后台线程不碰任何控件。"""
        api = api or self._api_used
        user = (self.in_user.text().strip() if user is None else user)
        pwd = (self.in_pwd.text() if pwd is None else pwd)
        if not api:
            raise ValueError("没有可用的服务器地址")
        if not user or not pwd:
            raise ValueError("用户名和密码都要填")
        return yggdrasil.authenticate(api, user, pwd)

    def _auto_probe(self):
        api = self._api()
        if not api:
            self._tone("idle")
            return
        self._tone("wait")

        def fn():
            real_ok, msg = yggdrasil.probe_api(api, timeout=6)
            if real_ok:
                msg = msg.split("\n")[0].replace("连上了：", "")
            return (real_ok, msg)
        self._start("probe", fn, quiet=True)
    def _on_api_edited(self, _text):
        self._tone("idle")
        self._sync_reg_btn()
        self._probe_timer.start()

    def _sync_reg_btn(self):
        """公共皮肤站没有注册接口，把按钮文案换成「去网页注册」，别让人白点。"""
        try:
            api = self.cb_api.currentText().strip()
            site = yggdrasil.public_register_url(api)
        except Exception:
            site = ""
        if site:
            self.btn_reg.setText("去这个站的网页注册")
            self.btn_reg.setToolTip("这个公共皮肤站只能在它自己的网站上注册\n" + site)
        else:
            self.btn_reg.setText("在这个服务器注册")
            self.btn_reg.setToolTip("在自己搭的服务器上开新账号（要支持 /authserver/register）")

    def _test(self):
        api = self._api()
        if not api:
            return
        self.state.setText("正在测试 %s ……" % api)
        self._tone("wait")

        def fn():
            real_ok, msg = yggdrasil.probe_api(api)
            if not real_ok:
                msg += ("\n\n（如果这是你自己搭的服务器：脚本启动时加过 Windows 防火墙"
                        "规则了吗？云服务器安全组放行同一端口了吗？）")
            return (real_ok, msg)
        self._start("test", fn)

    def _register(self):
        api = self._api()
        if not api:
            return
        user = self.in_user.text().strip()
        email = self.in_email.text().strip()
        pwd = self.in_pwd.text()

        # 公共皮肤站（LittleSkin / McSkin / Ely.by）没有 /authserver/register，
        # 在这儿点注册永远只会报「没开注册接口」，直接带去它们的网页注册页。
        site = yggdrasil.public_register_url(api)
        if site:
            self.state.setText(
                "这个站只能到它自己的网页上注册（%s 不支持从启动器建号）。\n"
                "注册好之后回到这里，用同一个用户名密码点「登录并绑定」。" % site)
            QDesktopServices.openUrl(QUrl(site))
            return

        if not user:
            self.state.setText("先填用户名（1-16 个字符，进游戏就显示这个名字）。")
            self.in_user.setFocus()
            return
        if len(user) > 16:
            self.state.setText("用户名太长了，最多 16 个字符。")
            self.in_user.setFocus()
            return
        if not email:
            self.state.setText("注册要填邮箱，用来找回账号。")
            self.in_email.setFocus()
            return
        if "@" not in email or "." not in email.split("@")[-1]:
            self.state.setText("邮箱格式不对，要像 name@example.com 这样。")
            self.in_email.setFocus()
            return
        if not pwd:
            self.state.setText("密码也要填。")
            self.in_pwd.setFocus()
            return
        if len(pwd) < 6:
            self.state.setText("密码至少 6 位。")
            self.in_pwd.setFocus()
            return
        if not require_human(self, "注册账号"):
            return

        self.state.setText("正在 %s 注册 %s ……" % (api, user))
        self._api_used = api

        def fn():
            # 服务端带回 token 就直接用，省掉注册完再登录的那一次往返
            ok, msg, acct = yggdrasil.register_full(api, email, pwd, user)
            if not ok:
                raise RuntimeError(msg)
            return acct
        self._register_acct = None
        self._start("register", fn)

    def _login(self):
        api = self._api()
        if not api:
            return
        user = self.in_user.text().strip()
        pwd = self.in_pwd.text()
        if not user or not pwd:
            self.state.setText("用户名和密码都要填。")
            return
        if not require_human(self, "登录"):
            return
        self.state.setText("正在登录 %s ……" % api)
        self._api_used = api
        self._start("login", lambda: self._do_login(api, user, pwd))

    def _go(self):
        """底部主按钮：已登录成功过 → 完成绑定；否则就是去登录。"""
        if self.acct:
            self.accept()
            return
        self._login()

    # ---------- 生命周期 ----------
    def closeEvent(self, ev):
        self._alive = False
        super().closeEvent(ev)

    def accept(self):
        if self.acct:
            self.acct["api"] = self.acct.get("api") or self._api()
        super().accept()
